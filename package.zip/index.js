"use strict";var Cc=Object.create;var jo=Object.defineProperty;var $c=Object.getOwnPropertyDescriptor;var Ic=Object.getOwnPropertyNames;var Ec=Object.getPrototypeOf,Tc=Object.prototype.hasOwnProperty;var Ac=(e,t,i)=>t in e?jo(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i;var Bc=(e,t,i,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of Ic(t))!Tc.call(e,o)&&o!==i&&jo(e,o,{get:()=>t[o],enumerable:!(n=$c(t,o))||n.enumerable});return e};var Kn=(e,t,i)=>(i=e!=null?Cc(Ec(e)):{},Bc(t||!e||!e.__esModule?jo(i,"default",{value:e,enumerable:!0}):i,e));var be=(e,t,i)=>Ac(e,typeof t!="symbol"?t+"":t,i);const pe=require("siyuan");async function mt(e,t){const i=await pe.fetchSyncPost(e,t);return i.code===0?i.data:null}async function Mc(){return mt("/api/notebook/lsNotebooks","")}async function Dc(e,t,i){return mt("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:i})}async function Xr(e,t){const i=new FormData;i.append("assetsDirPath",e);for(const o of t)i.append("file[]",o);return mt("/api/asset/upload",i)}async function Ti(e,t,i,n,o){return mt("/api/block/insertBlock",{dataType:e,data:t,nextID:i,previousID:n,parentID:o})}async function rs(e,t,i){return mt("/api/block/appendBlock",{dataType:e,data:t,parentID:i})}async function rr(e,t,i){return mt("/api/block/updateBlock",{dataType:e,data:t,id:i})}async function Qr(e){return mt("/api/block/deleteBlock",{id:e})}async function Lc(e){return mt("/api/block/getBlockKramdown",{id:e})}async function uo(e){return mt("/api/block/getChildBlocks",{id:e})}async function Oc(e){return mt("/api/block/getDocBlocksOrders",{id:e})}async function Ne(e,t){return mt("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function $s(e){return mt("/api/attr/getBlockAttrs",{id:e})}async function tn(e){return mt("/api/query/sql",{stmt:e})}async function ls(e,t,i){const n=new FormData;return n.append("path",e),n.append("isDir",t.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",i),mt("/api/file/putFile",n)}async function el(e){const t="/api/ai/chatGPT";try{const i=await mt(t,{msg:e});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function Pc(){return mt("/api/storage/getInlineStyles","")}const tl=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function Rc(e){const t=[];if(!e)return t;const i=new RegExp(tl.source,"g");let n;for(;(n=i.exec(e))!==null;){const o=n[2]??n[3]??n[4];t.push({fullMatch:n[0],blockId:n[1],anchorText:o?o.trim():void 0})}return t}function Nc(e,t){if(!e)return"";const i=new RegExp(tl.source,"g");return e.replace(i,(n,o,s,l,r)=>{const a=(s??l??r??"").trim();if(t&&t[o]){const d=t[o].trim();return`<div class="slidev-block-ref" data-ref-id="${o}">${d}</div>`}const c=a||`Ref(${o.slice(0,8)})`;return`<a href="siyuan://blocks/${o}" data-ref-id="${o}" class="slidev-ref-tag">🔗 ${c}</a>`})}const $n="custom-slidev-theme",In="custom-slidev-aspect-ratio",il="custom-slidev-highlighter",En="custom-slidev-default-transition",nl="custom-slidev-color-schema",as="custom-slidev-spacing",Ii="custom-slidev-slide",fe="custom-slidev-layout",tt="custom-slidev-transition",je="custom-slidev-background",Dt="custom-slidev-image",Ui="custom-slidev-notes",Vi="custom-slidev-class",vn="custom-slidev-spacing",yt="custom-slidev-layout-ratio",Ki="custom-slidev-mask",qi="custom-slidev-mask-ratio",Gi="custom-slidev-mask-style",Zi="custom-slidev-mask-initial",Ze="custom-slidev-click",Kt="custom-slidev-motion",Pi="custom-slidev-shiki-lines",Ce="custom-slidev-slot",nt="custom-slidev-note",qe="custom-slidev-role",Tn="custom-slidev-max-height",Ei="custom-slidev-autoplay",fo="custom-slidev-loop",Wi="custom-slidev-muted",po="custom-slidev-controls",ol="background",ho="image-left",mo="image-right";function An(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function zc(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function Fc(e){const t={};if(!e)return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(i))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";t[s]=l}return t}function sl(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function rl(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function Et(e,t){if(!sl(e))return e;const i=rl(e);return t!=null&&t.base64Map&&t.base64Map[i]?t.base64Map[i]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function Hc(e,t){if(!e)return"";let i=e;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,o,s)=>{const l=Et(s,t);return`![${o}](${l})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,o,s,l)=>{const r=Et(s,t);return`${o}${r}${l}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,o,s,l)=>{const r=Et(s,t);return`${o}${r}${l}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Is(e){const t=Object.create(null);for(const i of e.split(","))t[i]=1;return i=>i in t}const We={},Yi=[],qt=()=>{},ll=()=>!1,$o=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),Io=e=>e.startsWith("onUpdate:"),dt=Object.assign,Es=(e,t)=>{const i=e.indexOf(t);i>-1&&e.splice(i,1)},jc=Object.prototype.hasOwnProperty,Re=(e,t)=>jc.call(e,t),$e=Array.isArray,Ji=e=>zn(e)==="[object Map]",ln=e=>zn(e)==="[object Set]",lr=e=>zn(e)==="[object Date]",Ee=e=>typeof e=="function",it=e=>typeof e=="string",Rt=e=>typeof e=="symbol",He=e=>e!==null&&typeof e=="object",al=e=>(He(e)||Ee(e))&&Ee(e.then)&&Ee(e.catch),cl=Object.prototype.toString,zn=e=>cl.call(e),Wc=e=>zn(e).slice(8,-1),dl=e=>zn(e)==="[object Object]",Ts=e=>it(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,bn=Is(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Eo=e=>{const t=Object.create(null);return(i=>t[i]||(t[i]=e(i)))},Uc=/-\w/g,wt=Eo(e=>e.replace(Uc,t=>t.slice(1).toUpperCase())),Vc=/\B([A-Z])/g,yi=Eo(e=>e.replace(Vc,"-$1").toLowerCase()),To=Eo(e=>e.charAt(0).toUpperCase()+e.slice(1)),Wo=Eo(e=>e?`on${To(e)}`:""),Vt=(e,t)=>!Object.is(e,t),to=(e,...t)=>{for(let i=0;i<e.length;i++)e[i](...t)},ul=(e,t,i,n=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:n,value:i})},Ao=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let ar;const Bo=()=>ar||(ar=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function Bn(e){if($e(e)){const t={};for(let i=0;i<e.length;i++){const n=e[i],o=it(n)?Zc(n):Bn(n);if(o)for(const s in o)t[s]=o[s]}return t}else if(it(e)||He(e))return e}const Kc=/;(?![^(]*\))/g,qc=/:([^]+)/,Gc=/\/\*[^]*?\*\//g;function Zc(e){const t={};return e.replace(Gc,"").split(Kc).forEach(i=>{if(i){const n=i.split(qc);n.length>1&&(t[n[0].trim()]=n[1].trim())}}),t}function _e(e){let t="";if(it(e))t=e;else if($e(e))for(let i=0;i<e.length;i++){const n=_e(e[i]);n&&(t+=n+" ")}else if(He(e))for(const i in e)e[i]&&(t+=i+" ");return t.trim()}const Yc="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",Jc=Is(Yc);function fl(e){return!!e||e===""}function Xc(e,t){if(e.length!==t.length)return!1;let i=!0;for(let n=0;i&&n<e.length;n++)i=an(e[n],t[n]);return i}function an(e,t){if(e===t)return!0;let i=lr(e),n=lr(t);if(i||n)return i&&n?e.getTime()===t.getTime():!1;if(i=Rt(e),n=Rt(t),i||n)return e===t;if(i=$e(e),n=$e(t),i||n)return i&&n?Xc(e,t):!1;if(i=He(e),n=He(t),i||n){if(!i||!n)return!1;const o=Object.keys(e).length,s=Object.keys(t).length;if(o!==s)return!1;for(const l in e){const r=e.hasOwnProperty(l),a=t.hasOwnProperty(l);if(r&&!a||!r&&a||!an(e[l],t[l]))return!1}}return String(e)===String(t)}function As(e,t){return e.findIndex(i=>an(i,t))}const pl=e=>!!(e&&e.__v_isRef===!0),we=e=>it(e)?e:e==null?"":$e(e)||He(e)&&(e.toString===cl||!Ee(e.toString))?pl(e)?we(e.value):JSON.stringify(e,hl,2):String(e),hl=(e,t)=>pl(t)?hl(e,t.value):Ji(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((i,[n,o],s)=>(i[Uo(n,s)+" =>"]=o,i),{})}:ln(t)?{[`Set(${t.size})`]:[...t.values()].map(i=>Uo(i))}:Rt(t)?Uo(t):He(t)&&!$e(t)&&!dl(t)?String(t):t,Uo=(e,t="")=>{var i;return Rt(e)?`Symbol(${(i=e.description)!=null?i:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let lt;class Qc{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&lt&&(lt.active?(this.parent=lt,this.index=(lt.scopes||(lt.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,i;if(this.scopes){const n=this.scopes.slice();for(t=0,i=n.length;t<i;t++)n[t].pause()}for(t=0,i=this.effects.length;t<i;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,i;if(this.scopes){const o=this.scopes.slice();for(t=0,i=o.length;t<i;t++)o[t].resume()}const n=this.effects.slice();for(t=0,i=n.length;t<i;t++)n[t].resume()}}run(t){if(this._active){const i=lt;try{return lt=this,t()}finally{lt=i}}}on(){++this._on===1&&(this.prevScope=lt,lt=this)}off(){if(this._on>0&&--this._on===0){if(lt===this)lt=this.prevScope;else{let t=lt;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let i,n;for(i=0,n=this.effects.length;i<n;i++)this.effects[i].stop();for(this.effects.length=0,i=0,n=this.cleanups.length;i<n;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const o=this.scopes.slice();for(i=0,n=o.length;i<n;i++)o[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const o=this.parent.scopes.pop();o&&o!==this&&(this.parent.scopes[this.index]=o,o.index=this.index)}this.parent=void 0}}}function ed(){return lt}let Ke;const Vo=new WeakSet;class ml{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,lt&&(lt.active?lt.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,Vo.has(this)&&(Vo.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||vl(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,cr(this),bl(this);const t=Ke,i=Pt;Ke=this,Pt=!0;try{return this.fn()}finally{yl(this),Ke=t,Pt=i,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)Ds(t);this.deps=this.depsTail=void 0,cr(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?Vo.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){cs(this)&&this.run()}get dirty(){return cs(this)}}let gl=0,yn,kn;function vl(e,t=!1){if(e.flags|=8,t){e.next=kn,kn=e;return}e.next=yn,yn=e}function Bs(){gl++}function Ms(){if(--gl>0)return;if(kn){let t=kn;for(kn=void 0;t;){const i=t.next;t.next=void 0,t.flags&=-9,t=i}}let e;for(;yn;){let t=yn;for(yn=void 0;t;){const i=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(n){e||(e=n)}t=i}}if(e)throw e}function bl(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function yl(e){let t,i=e.depsTail,n=i;for(;n;){const o=n.prevDep;n.version===-1?(n===i&&(i=o),Ds(n),td(n)):t=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=o}e.deps=t,e.depsTail=i}function cs(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(kl(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function kl(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===Mn)||(e.globalVersion=Mn,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!cs(e))))return;e.flags|=2;const t=e.dep,i=Ke,n=Pt;Ke=e,Pt=!0;try{bl(e);const o=e.fn(e._value);(t.version===0||Vt(o,e._value))&&(e.flags|=128,e._value=o,t.version++)}catch(o){throw t.version++,o}finally{Ke=i,Pt=n,yl(e),e.flags&=-3}}function Ds(e,t=!1){const{dep:i,prevSub:n,nextSub:o}=e;if(n&&(n.nextSub=o,e.prevSub=void 0),o&&(o.prevSub=n,e.nextSub=void 0),i.subs===e&&(i.subs=n,!n&&i.computed)){i.computed.flags&=-5;for(let s=i.computed.deps;s;s=s.nextDep)Ds(s,!0)}!t&&!--i.sc&&i.map&&i.map.delete(i.key)}function td(e){const{prevDep:t,nextDep:i}=e;t&&(t.nextDep=i,e.prevDep=void 0),i&&(i.prevDep=t,e.nextDep=void 0)}let Pt=!0;const wl=[];function oi(){wl.push(Pt),Pt=!1}function si(){const e=wl.pop();Pt=e===void 0?!0:e}function cr(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const i=Ke;Ke=void 0;try{t()}finally{Ke=i}}}let Mn=0;class id{constructor(t,i){this.sub=t,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class Ls{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!Ke||!Pt||Ke===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==Ke)i=this.activeLink=new id(Ke,this),Ke.deps?(i.prevDep=Ke.depsTail,Ke.depsTail.nextDep=i,Ke.depsTail=i):Ke.deps=Ke.depsTail=i,xl(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const n=i.nextDep;n.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=n),i.prevDep=Ke.depsTail,i.nextDep=void 0,Ke.depsTail.nextDep=i,Ke.depsTail=i,Ke.deps===i&&(Ke.deps=n)}return i}trigger(t){this.version++,Mn++,this.notify(t)}notify(t){Bs();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{Ms()}}}function xl(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let n=t.deps;n;n=n.nextDep)xl(n)}const i=e.dep.subs;i!==e&&(e.prevSub=i,i&&(i.nextSub=e)),e.dep.subs=e}}const ds=new WeakMap,Mi=Symbol(""),us=Symbol(""),Dn=Symbol("");function pt(e,t,i){if(Pt&&Ke){let n=ds.get(e);n||ds.set(e,n=new Map);let o=n.get(i);o||(n.set(i,o=new Ls),o.map=n,o.key=i),o.track()}}function Qt(e,t,i,n,o,s){const l=ds.get(e);if(!l){Mn++;return}const r=a=>{a&&a.trigger()};if(Bs(),t==="clear")l.forEach(r);else{const a=$e(e),c=a&&Ts(i);if(a&&i==="length"){const d=Number(n);l.forEach((p,v)=>{(v==="length"||v===Dn||!Rt(v)&&v>=d)&&r(p)})}else switch((i!==void 0||l.has(void 0))&&r(l.get(i)),c&&r(l.get(Dn)),t){case"add":a?c&&r(l.get("length")):(r(l.get(Mi)),Ji(e)&&r(l.get(us)));break;case"delete":a||(r(l.get(Mi)),Ji(e)&&r(l.get(us)));break;case"set":Ji(e)&&r(l.get(Mi));break}}Ms()}function Hi(e){const t=Pe(e);return t===e?t:(pt(t,"iterate",Dn),Bt(e)?t:t.map(Nt))}function Mo(e){return pt(e=Pe(e),"iterate",Dn),e}function Wt(e,t){return ri(e)?nn(Di(e)?Nt(t):t):Nt(t)}const nd={__proto__:null,[Symbol.iterator](){return Ko(this,Symbol.iterator,e=>Wt(this,e))},concat(...e){return Hi(this).concat(...e.map(t=>$e(t)?Hi(t):t))},entries(){return Ko(this,"entries",e=>(e[1]=Wt(this,e[1]),e))},every(e,t){return Yt(this,"every",e,t,void 0,arguments)},filter(e,t){return Yt(this,"filter",e,t,i=>i.map(n=>Wt(this,n)),arguments)},find(e,t){return Yt(this,"find",e,t,i=>Wt(this,i),arguments)},findIndex(e,t){return Yt(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return Yt(this,"findLast",e,t,i=>Wt(this,i),arguments)},findLastIndex(e,t){return Yt(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return Yt(this,"forEach",e,t,void 0,arguments)},includes(...e){return qo(this,"includes",e)},indexOf(...e){return qo(this,"indexOf",e)},join(e){return Hi(this).join(e)},lastIndexOf(...e){return qo(this,"lastIndexOf",e)},map(e,t){return Yt(this,"map",e,t,void 0,arguments)},pop(){return fn(this,"pop")},push(...e){return fn(this,"push",e)},reduce(e,...t){return dr(this,"reduce",e,t)},reduceRight(e,...t){return dr(this,"reduceRight",e,t)},shift(){return fn(this,"shift")},some(e,t){return Yt(this,"some",e,t,void 0,arguments)},splice(...e){return fn(this,"splice",e)},toReversed(){return Hi(this).toReversed()},toSorted(e){return Hi(this).toSorted(e)},toSpliced(...e){return Hi(this).toSpliced(...e)},unshift(...e){return fn(this,"unshift",e)},values(){return Ko(this,"values",e=>Wt(this,e))}};function Ko(e,t,i){const n=Mo(e),o=n[t]();return n!==e&&!Bt(e)&&(o._next=o.next,o.next=()=>{const s=o._next();return s.done||(s.value=i(s.value)),s}),o}const od=Array.prototype;function Yt(e,t,i,n,o,s){const l=Mo(e),r=l!==e&&!Bt(e),a=l[t];if(a!==od[t]){const p=a.apply(e,s);return r?Nt(p):p}let c=i;l!==e&&(r?c=function(p,v){return i.call(this,Wt(e,p),v,e)}:i.length>2&&(c=function(p,v){return i.call(this,p,v,e)}));const d=a.call(l,c,n);return r&&o?o(d):d}function dr(e,t,i,n){const o=Mo(e),s=o!==e&&!Bt(e);let l=i,r=!1;o!==e&&(s?(r=n.length===0,l=function(c,d,p){return r&&(r=!1,c=Wt(e,c)),i.call(this,c,Wt(e,d),p,e)}):i.length>3&&(l=function(c,d,p){return i.call(this,c,d,p,e)}));const a=o[t](l,...n);return r?Wt(e,a):a}function qo(e,t,i){const n=Pe(e);pt(n,"iterate",Dn);const o=n[t](...i);return(o===-1||o===!1)&&Rs(i[0])?(i[0]=Pe(i[0]),n[t](...i)):o}function fn(e,t,i=[]){oi(),Bs();const n=Pe(e)[t].apply(e,i);return Ms(),si(),n}const sd=Is("__proto__,__v_isRef,__isVue"),Sl=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Rt));function rd(e){Rt(e)||(e=String(e));const t=Pe(this);return pt(t,"has",e),t.hasOwnProperty(e)}class _l{constructor(t=!1,i=!1){this._isReadonly=t,this._isShallow=i}get(t,i,n){if(i==="__v_skip")return t.__v_skip;const o=this._isReadonly,s=this._isShallow;if(i==="__v_isReactive")return!o;if(i==="__v_isReadonly")return o;if(i==="__v_isShallow")return s;if(i==="__v_raw")return n===(o?s?gd:El:s?Il:$l).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(n)?t:void 0;const l=$e(t);if(!o){let a;if(l&&(a=nd[i]))return a;if(i==="hasOwnProperty")return rd}const r=Reflect.get(t,i,Ye(t)?t:n);if((Rt(i)?Sl.has(i):sd(i))||(o||pt(t,"get",i),s))return r;if(Ye(r)){const a=l&&Ts(i)?r:r.value;return o&&He(a)?ps(a):a}return He(r)?o?ps(r):Do(r):r}}class Cl extends _l{constructor(t=!1){super(!1,t)}set(t,i,n,o){let s=t[i];const l=$e(t)&&Ts(i);if(!this._isShallow){const c=ri(s);if(!Bt(n)&&!ri(n)&&(s=Pe(s),n=Pe(n)),!l&&Ye(s)&&!Ye(n))return c||(s.value=n),!0}const r=l?Number(i)<t.length:Re(t,i),a=Reflect.set(t,i,n,Ye(t)?t:o);return t===Pe(o)&&a&&(r?Vt(n,s)&&Qt(t,"set",i,n):Qt(t,"add",i,n)),a}deleteProperty(t,i){const n=Re(t,i);t[i];const o=Reflect.deleteProperty(t,i);return o&&n&&Qt(t,"delete",i,void 0),o}has(t,i){const n=Reflect.has(t,i);return(!Rt(i)||!Sl.has(i))&&pt(t,"has",i),n}ownKeys(t){return pt(t,"iterate",$e(t)?"length":Mi),Reflect.ownKeys(t)}}class ld extends _l{constructor(t=!1){super(!0,t)}set(t,i){return!0}deleteProperty(t,i){return!0}}const ad=new Cl,cd=new ld,dd=new Cl(!0);const fs=e=>e,qn=e=>Reflect.getPrototypeOf(e);function ud(e,t,i){return function(...n){const o=this.__v_raw,s=Pe(o),l=Ji(s),r=e==="entries"||e===Symbol.iterator&&l,a=e==="keys"&&l,c=o[e](...n),d=i?fs:t?nn:Nt;return!t&&pt(s,"iterate",a?us:Mi),dt(Object.create(c),{next(){const{value:p,done:v}=c.next();return v?{value:p,done:v}:{value:r?[d(p[0]),d(p[1])]:d(p),done:v}}})}}function Gn(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function fd(e,t){const i={get(o){const s=this.__v_raw,l=Pe(s),r=Pe(o);e||(Vt(o,r)&&pt(l,"get",o),pt(l,"get",r));const{has:a}=qn(l),c=t?fs:e?nn:Nt;if(a.call(l,o))return c(s.get(o));if(a.call(l,r))return c(s.get(r));s!==l&&s.get(o)},get size(){const o=this.__v_raw;return!e&&pt(Pe(o),"iterate",Mi),o.size},has(o){const s=this.__v_raw,l=Pe(s),r=Pe(o);return e||(Vt(o,r)&&pt(l,"has",o),pt(l,"has",r)),o===r?s.has(o):s.has(o)||s.has(r)},forEach(o,s){const l=this,r=l.__v_raw,a=Pe(r),c=t?fs:e?nn:Nt;return!e&&pt(a,"iterate",Mi),r.forEach((d,p)=>o.call(s,c(d),c(p),l))}};return dt(i,e?{add:Gn("add"),set:Gn("set"),delete:Gn("delete"),clear:Gn("clear")}:{add(o){const s=Pe(this),l=qn(s),r=Pe(o),a=!t&&!Bt(o)&&!ri(o)?r:o;return l.has.call(s,a)||Vt(o,a)&&l.has.call(s,o)||Vt(r,a)&&l.has.call(s,r)||(s.add(a),Qt(s,"add",a,a)),this},set(o,s){!t&&!Bt(s)&&!ri(s)&&(s=Pe(s));const l=Pe(this),{has:r,get:a}=qn(l);let c=r.call(l,o);c||(o=Pe(o),c=r.call(l,o));const d=a.call(l,o);return l.set(o,s),c?Vt(s,d)&&Qt(l,"set",o,s):Qt(l,"add",o,s),this},delete(o){const s=Pe(this),{has:l,get:r}=qn(s);let a=l.call(s,o);a||(o=Pe(o),a=l.call(s,o)),r&&r.call(s,o);const c=s.delete(o);return a&&Qt(s,"delete",o,void 0),c},clear(){const o=Pe(this),s=o.size!==0,l=o.clear();return s&&Qt(o,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(o=>{i[o]=ud(o,e,t)}),i}function Os(e,t){const i=fd(e,t);return(n,o,s)=>o==="__v_isReactive"?!e:o==="__v_isReadonly"?e:o==="__v_raw"?n:Reflect.get(Re(i,o)&&o in n?i:n,o,s)}const pd={get:Os(!1,!1)},hd={get:Os(!1,!0)},md={get:Os(!0,!1)};const $l=new WeakMap,Il=new WeakMap,El=new WeakMap,gd=new WeakMap;function vd(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Do(e){return ri(e)?e:Ps(e,!1,ad,pd,$l)}function bd(e){return Ps(e,!1,dd,hd,Il)}function ps(e){return Ps(e,!0,cd,md,El)}function Ps(e,t,i,n,o){if(!He(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const s=o.get(e);if(s)return s;const l=vd(Wc(e));if(l===0)return e;const r=new Proxy(e,l===2?n:i);return o.set(e,r),r}function Di(e){return ri(e)?Di(e.__v_raw):!!(e&&e.__v_isReactive)}function ri(e){return!!(e&&e.__v_isReadonly)}function Bt(e){return!!(e&&e.__v_isShallow)}function Rs(e){return e?!!e.__v_raw:!1}function Pe(e){const t=e&&e.__v_raw;return t?Pe(t):e}function yd(e){return!Re(e,"__v_skip")&&Object.isExtensible(e)&&ul(e,"__v_skip",!0),e}const Nt=e=>He(e)?Do(e):e,nn=e=>He(e)?ps(e):e;function Ye(e){return e?e.__v_isRef===!0:!1}function he(e){return kd(e,!1)}function kd(e,t){return Ye(e)?e:new wd(e,t)}class wd{constructor(t,i){this.dep=new Ls,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?t:Pe(t),this._value=i?t:Nt(t),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(t){const i=this._rawValue,n=this.__v_isShallow||Bt(t)||ri(t);t=n?t:Pe(t),Vt(t,i)&&(this._rawValue=t,this._value=n?t:Nt(t),this.dep.trigger())}}function ge(e){return Ye(e)?e.value:e}const xd={get:(e,t,i)=>t==="__v_raw"?e:ge(Reflect.get(e,t,i)),set:(e,t,i,n)=>{const o=e[t];return Ye(o)&&!Ye(i)?(o.value=i,!0):Reflect.set(e,t,i,n)}};function Tl(e){return Di(e)?e:new Proxy(e,xd)}class Sd{constructor(t,i,n){this.fn=t,this.setter=i,this._value=void 0,this.dep=new Ls(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=Mn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Ke!==this)return vl(this,!0),!0}get value(){const t=this.dep.track();return kl(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function _d(e,t,i=!1){let n,o;return Ee(e)?n=e:(n=e.get,o=e.set),new Sd(n,o,i)}const Zn={},go=new WeakMap;let $i;function Cd(e,t=!1,i=$i){if(i){let n=go.get(i);n||go.set(i,n=[]),n.push(e)}}function $d(e,t,i=We){const{immediate:n,deep:o,once:s,scheduler:l,augmentJob:r,call:a}=i,c=A=>o?A:Bt(A)||o===!1||o===0?ei(A,1):ei(A);let d,p,v,u,h=!1,f=!1;if(Ye(e)?(p=()=>e.value,h=Bt(e)):Di(e)?(p=()=>c(e),h=!0):$e(e)?(f=!0,h=e.some(A=>Di(A)||Bt(A)),p=()=>e.map(A=>{if(Ye(A))return A.value;if(Di(A))return c(A);if(Ee(A))return a?a(A,2):A()})):Ee(e)?t?p=a?()=>a(e,2):e:p=()=>{if(v){oi();try{v()}finally{si()}}const A=$i;$i=d;try{return a?a(e,3,[u]):e(u)}finally{$i=A}}:p=qt,t&&o){const A=p,M=o===!0?1/0:o;p=()=>ei(A(),M)}const b=ed(),k=()=>{d.stop(),b&&b.active&&Es(b.effects,d)};if(s&&t){const A=t;t=(...M)=>{const E=A(...M);return k(),E}}let x=f?new Array(e.length).fill(Zn):Zn;const _=A=>{if(!(!(d.flags&1)||!d.dirty&&!A))if(t){const M=d.run();if(A||o||h||(f?M.some((E,w)=>Vt(E,x[w])):Vt(M,x))){v&&v();const E=$i;$i=d;try{const w=[M,x===Zn?void 0:f&&x[0]===Zn?[]:x,u];x=M,a?a(t,3,w):t(...w)}finally{$i=E}}}else d.run()};return r&&r(_),d=new ml(p),d.scheduler=l?()=>l(_,!1):_,u=A=>Cd(A,!1,d),v=d.onStop=()=>{const A=go.get(d);if(A){if(a)a(A,4);else for(const M of A)M();go.delete(d)}},t?n?_(!0):x=d.run():l?l(_.bind(null,!0),!0):d.run(),k.pause=d.pause.bind(d),k.resume=d.resume.bind(d),k.stop=k,k}function ei(e,t=1/0,i){if(t<=0||!He(e)||e.__v_skip||(i=i||new Map,(i.get(e)||0)>=t))return e;if(i.set(e,t),t--,Ye(e))ei(e.value,t,i);else if($e(e))for(let n=0;n<e.length;n++)ei(e[n],t,i);else if(ln(e)||Ji(e))e.forEach(n=>{ei(n,t,i)});else if(dl(e)){for(const n in e)ei(e[n],t,i);for(const n of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,n)&&ei(e[n],t,i)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Fn(e,t,i,n){try{return n?e(...n):e()}catch(o){Lo(o,t,i)}}function zt(e,t,i,n){if(Ee(e)){const o=Fn(e,t,i,n);return o&&al(o)&&o.catch(s=>{Lo(s,t,i)}),o}if($e(e)){const o=[];for(let s=0;s<e.length;s++)o.push(zt(e[s],t,i,n));return o}}function Lo(e,t,i,n=!0){const o=t?t.vnode:null,{errorHandler:s,throwUnhandledErrorInProduction:l}=t&&t.appContext.config||We;if(t){let r=t.parent;const a=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const d=r.ec;if(d){for(let p=0;p<d.length;p++)if(d[p](e,a,c)===!1)return}r=r.parent}if(s){oi(),Fn(s,null,10,[e,a,c]),si();return}}Id(e,i,o,n,l)}function Id(e,t,i,n=!0,o=!1){if(o)throw e;console.error(e)}const bt=[];let jt=-1;const Xi=[];let pi=null,ji=0;const Al=Promise.resolve();let vo=null;function Bl(e){const t=vo||Al;return e?t.then(this?e.bind(this):e):t}function Ed(e){let t=jt+1,i=bt.length;for(;t<i;){const n=t+i>>>1,o=bt[n],s=Ln(o);s<e||s===e&&o.flags&2?t=n+1:i=n}return t}function Ns(e){if(!(e.flags&1)){const t=Ln(e),i=bt[bt.length-1];!i||!(e.flags&2)&&t>=Ln(i)?bt.push(e):bt.splice(Ed(t),0,e),e.flags|=1,Ml()}}function Ml(){vo||(vo=Al.then(Ll))}function Td(e){$e(e)?Xi.push(...e):pi&&e.id===-1?pi.splice(ji+1,0,e):e.flags&1||(Xi.push(e),e.flags|=1),Ml()}function ur(e,t,i=jt+1){for(;i<bt.length;i++){const n=bt[i];if(n&&n.flags&2){if(e&&n.id!==e.uid)continue;bt.splice(i,1),i--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function Dl(e){if(Xi.length){const t=[...new Set(Xi)].sort((i,n)=>Ln(i)-Ln(n));if(Xi.length=0,pi){pi.push(...t);return}for(pi=t,ji=0;ji<pi.length;ji++){const i=pi[ji];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}pi=null,ji=0}}const Ln=e=>e.id==null?e.flags&2?-1:1/0:e.id;function Ll(e){try{for(jt=0;jt<bt.length;jt++){const t=bt[jt];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),Fn(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;jt<bt.length;jt++){const t=bt[jt];t&&(t.flags&=-2)}jt=-1,bt.length=0,Dl(),vo=null,(bt.length||Xi.length)&&Ll()}}let ct=null,Ol=null;function bo(e){const t=ct;return ct=e,Ol=e&&e.type.__scopeId||null,t}function Pl(e,t=ct,i){if(!t||e._n)return e;const n=(...o)=>{n._d&&Sr(-1);const s=bo(t),l=ii.length;let r;try{r=e(...o)}finally{for(let a=ii.length;a>l;a--)Us();bo(s),n._d&&Sr(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Tt(e,t){if(ct===null)return e;const i=No(ct),n=e.dirs||(e.dirs=[]);for(let o=0;o<t.length;o++){let[s,l,r,a=We]=t[o];s&&(Ee(s)&&(s={mounted:s,updated:s}),s.deep&&ei(l),n.push({dir:s,instance:i,value:l,oldValue:void 0,arg:r,modifiers:a}))}return e}function wi(e,t,i,n){const o=e.dirs,s=t&&t.dirs;for(let l=0;l<o.length;l++){const r=o[l];s&&(r.oldValue=s[l].value);let a=r.dir[n];a&&(oi(),zt(a,i,8,[e.el,r,e,t]),si())}}function Ad(e,t){if(ht){let i=ht.provides;const n=ht.parent&&ht.parent.provides;n===i&&(i=ht.provides=Object.create(n)),i[e]=t}}function ti(e,t,i=!1){const n=Eu();if(n||en){let o=en?en._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(o&&e in o)return o[e];if(arguments.length>1)return i&&Ee(t)?t.call(n&&n.proxy):t}}const Bd=Symbol.for("v-scx"),Md=()=>ti(Bd);function Li(e,t,i){return Rl(e,t,i)}function Rl(e,t,i=We){const{immediate:n,deep:o,flush:s,once:l}=i,r=dt({},i),a=t&&n||!t&&s!=="post";let c;if(Pn){if(s==="sync"){const u=Md();c=u.__watcherHandles||(u.__watcherHandles=[])}else if(!a){const u=()=>{};return u.stop=qt,u.resume=qt,u.pause=qt,u}}const d=ht;r.call=(u,h,f)=>zt(u,d,h,f);let p=!1;s==="post"?r.scheduler=u=>{St(u,d&&d.suspense)}:s!=="sync"&&(p=!0,r.scheduler=(u,h)=>{h?u():Ns(u)}),r.augmentJob=u=>{t&&(u.flags|=4),p&&(u.flags|=2,d&&(u.id=d.uid,u.i=d))};const v=$d(e,t,r);return Pn&&(c?c.push(v):a&&v()),v}function Dd(e,t,i){const n=this.proxy,o=it(e)?e.includes(".")?Nl(n,e):()=>n[e]:e.bind(n,n);let s;Ee(t)?s=t:(s=t.handler,i=t);const l=jn(this),r=Rl(o,s.bind(n),i);return l(),r}function Nl(e,t){const i=t.split(".");return()=>{let n=e;for(let o=0;o<i.length&&n;o++)n=n[i[o]];return n}}const Ld=Symbol("_vte"),Od=e=>e.__isTeleport,Go=Symbol("_leaveCb");function zs(e,t){e.shapeFlag&6&&e.component?(e.transition=t,zs(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function xt(e,t){return Ee(e)?dt({name:e.name},t,{setup:e}):e}function zl(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function fr(e,t){let i;return!!((i=Object.getOwnPropertyDescriptor(e,t))&&!i.configurable)}const yo=new WeakMap;function wn(e,t,i,n,o=!1){if($e(e)){e.forEach((f,b)=>wn(f,t&&($e(t)?t[b]:t),i,n,o));return}if(Qi(n)&&!o){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&wn(e,t,i,n.component.subTree);return}const s=n.shapeFlag&4?No(n.component):n.el,l=o?null:s,{i:r,r:a}=e,c=t&&t.r,d=r.refs===We?r.refs={}:r.refs,p=r.setupState,v=Pe(p),u=p===We?ll:f=>fr(d,f)?!1:Re(v,f),h=(f,b)=>!(b&&fr(d,b));if(c!=null&&c!==a){if(pr(t),it(c))d[c]=null,u(c)&&(p[c]=null);else if(Ye(c)){const f=t;h(c,f.k)&&(c.value=null),f.k&&(d[f.k]=null)}}if(Ee(a))Fn(a,r,12,[l,d]);else{const f=it(a),b=Ye(a);if(f||b){const k=()=>{if(e.f){const x=f?u(a)?p[a]:d[a]:h()||!e.k?a.value:d[e.k];if(o)$e(x)&&Es(x,s);else if($e(x))x.includes(s)||x.push(s);else if(f)d[a]=[s],u(a)&&(p[a]=d[a]);else{const _=[s];h(a,e.k)&&(a.value=_),e.k&&(d[e.k]=_)}}else f?(d[a]=l,u(a)&&(p[a]=l)):b&&(h(a,e.k)&&(a.value=l),e.k&&(d[e.k]=l))};if(l){const x=()=>{k(),yo.delete(e)};x.id=-1,yo.set(e,x),St(x,i)}else pr(e),k()}}}function pr(e){const t=yo.get(e);t&&(t.flags|=8,yo.delete(e))}Bo().requestIdleCallback;Bo().cancelIdleCallback;const Qi=e=>!!e.type.__asyncLoader,Fl=e=>e.type.__isKeepAlive;function Pd(e,t){Hl(e,"a",t)}function Rd(e,t){Hl(e,"da",t)}function Hl(e,t,i=ht){const n=e.__wdc||(e.__wdc=()=>{let o=i;for(;o;){if(o.isDeactivated)return;o=o.parent}return e()});if(Oo(t,n,i),i){let o=i.parent;for(;o&&o.parent;)Fl(o.parent.vnode)&&Nd(n,t,i,o),o=o.parent}}function Nd(e,t,i,n){const o=Oo(t,e,n,!0);Hs(()=>{Es(n[t],o)},i)}function Oo(e,t,i=ht,n=!1){if(i){const o=i[e]||(i[e]=[]),s=t.__weh||(t.__weh=(...l)=>{oi();const r=jn(i),a=zt(t,i,e,l);return r(),si(),a});return n?o.unshift(s):o.push(s),s}}const ai=e=>(t,i=ht)=>{(!Pn||e==="sp")&&Oo(e,(...n)=>t(...n),i)},zd=ai("bm"),Hn=ai("m"),Fd=ai("bu"),Hd=ai("u"),Fs=ai("bum"),Hs=ai("um"),jd=ai("sp"),Wd=ai("rtg"),Ud=ai("rtc");function Vd(e,t=ht){Oo("ec",e,t)}const Kd="components";function qd(e,t){return Zd(Kd,e,!0,t)||e}const Gd=Symbol.for("v-ndc");function Zd(e,t,i=!0,n=!1){const o=ct||ht;if(o){const s=o.type;{const r=Du(s,!1);if(r&&(r===t||r===wt(t)||r===To(wt(t))))return s}const l=hr(o[e]||s[e],t)||hr(o.appContext[e],t);return!l&&n?s:l}}function hr(e,t){return e&&(e[t]||e[wt(t)]||e[To(wt(t))])}function kt(e,t,i,n){let o;const s=i,l=$e(e);if(l||it(e)){const r=l&&Di(e);let a=!1,c=!1;r&&(a=!Bt(e),c=ri(e),e=Mo(e)),o=new Array(e.length);for(let d=0,p=e.length;d<p;d++)o[d]=t(a?c?nn(Nt(e[d])):Nt(e[d]):e[d],d,void 0,s)}else if(typeof e=="number"){o=new Array(e);for(let r=0;r<e;r++)o[r]=t(r+1,r,void 0,s)}else if(He(e))if(e[Symbol.iterator])o=Array.from(e,(r,a)=>t(r,a,void 0,s));else{const r=Object.keys(e);o=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const d=r[a];o[a]=t(e[d],d,a,s)}}else o=[];return o}function Yn(e,t,i={},n,o,s){if(ct.ce||ct.parent&&Qi(ct.parent)&&ct.parent.ce){const c=i,d=Object.keys(c).length>0;return t!=="default"&&(c.name=t),ee(),Ot(Ue,null,[re("slot",c,n&&n())],d?-2:64)}let l=e[t];l&&l._c&&(l._d=!1);const r=ii.length;ee();let a;try{const c=l&&jl(l(i)),d=i.key||s||c&&c.key;a=Ot(Ue,{key:(d&&!Rt(d)?d:`_${t}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&e._===1?64:-2)}catch(c){for(let d=ii.length;d>r;d--)Us();throw c}finally{l&&l._c&&(l._d=!0)}return a}function jl(e){return e.some(t=>Vs(t)?!(t.type===li||t.type===Ue&&!jl(t.children)):!0)?e:null}const hs=e=>e?aa(e)?No(e):hs(e.parent):null,xn=dt(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>hs(e.parent),$root:e=>hs(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>Ul(e),$forceUpdate:e=>e.f||(e.f=()=>{Ns(e.update)}),$nextTick:e=>e.n||(e.n=Bl.bind(e.proxy)),$watch:e=>Dd.bind(e)}),Zo=(e,t)=>e!==We&&!e.__isScriptSetup&&Re(e,t),Yd={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:i,setupState:n,data:o,props:s,accessCache:l,type:r,appContext:a}=e;if(t[0]!=="$"){const v=l[t];if(v!==void 0)switch(v){case 1:return n[t];case 2:return o[t];case 4:return i[t];case 3:return s[t]}else{if(Zo(n,t))return l[t]=1,n[t];if(o!==We&&Re(o,t))return l[t]=2,o[t];if(Re(s,t))return l[t]=3,s[t];if(i!==We&&Re(i,t))return l[t]=4,i[t];ms&&(l[t]=0)}}const c=xn[t];let d,p;if(c)return t==="$attrs"&&pt(e.attrs,"get",""),c(e);if((d=r.__cssModules)&&(d=d[t]))return d;if(i!==We&&Re(i,t))return l[t]=4,i[t];if(p=a.config.globalProperties,Re(p,t))return p[t]},set({_:e},t,i){const{data:n,setupState:o,ctx:s}=e;return Zo(o,t)?(o[t]=i,!0):n!==We&&Re(n,t)?(n[t]=i,!0):Re(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(s[t]=i,!0)},has({_:{data:e,setupState:t,accessCache:i,ctx:n,appContext:o,props:s,type:l}},r){let a;return!!(i[r]||e!==We&&r[0]!=="$"&&Re(e,r)||Zo(t,r)||Re(s,r)||Re(n,r)||Re(xn,r)||Re(o.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(e,t,i){return i.get!=null?e._.accessCache[t]=0:Re(i,"value")&&this.set(e,t,i.value,null),Reflect.defineProperty(e,t,i)}};function mr(e){return $e(e)?e.reduce((t,i)=>(t[i]=null,t),{}):e}let ms=!0;function Jd(e){const t=Ul(e),i=e.proxy,n=e.ctx;ms=!1,t.beforeCreate&&gr(t.beforeCreate,e,"bc");const{data:o,computed:s,methods:l,watch:r,provide:a,inject:c,created:d,beforeMount:p,mounted:v,beforeUpdate:u,updated:h,activated:f,deactivated:b,beforeDestroy:k,beforeUnmount:x,destroyed:_,unmounted:A,render:M,renderTracked:E,renderTriggered:w,errorCaptured:P,serverPrefetch:R,expose:z,inheritAttrs:G,components:S,directives:L,filters:y}=t;if(c&&Xd(c,n,null),l)for(const T in l){const D=l[T];Ee(D)&&(n[T]=D.bind(i))}if(o){const T=o.call(i,i);He(T)&&(e.data=Do(T))}if(ms=!0,s)for(const T in s){const D=s[T],N=Ee(D)?D.bind(i,i):Ee(D.get)?D.get.bind(i,i):qt,X=!Ee(D)&&Ee(D.set)?D.set.bind(i):qt,Z=xe({get:N,set:X});Object.defineProperty(n,T,{enumerable:!0,configurable:!0,get:()=>Z.value,set:U=>Z.value=U})}if(r)for(const T in r)Wl(r[T],n,i,T);if(a){const T=Ee(a)?a.call(i):a;Reflect.ownKeys(T).forEach(D=>{Ad(D,T[D])})}d&&gr(d,e,"c");function F(T,D){$e(D)?D.forEach(N=>T(N.bind(i))):D&&T(D.bind(i))}if(F(zd,p),F(Hn,v),F(Fd,u),F(Hd,h),F(Pd,f),F(Rd,b),F(Vd,P),F(Ud,E),F(Wd,w),F(Fs,x),F(Hs,A),F(jd,R),$e(z))if(z.length){const T=e.exposed||(e.exposed={});z.forEach(D=>{Object.defineProperty(T,D,{get:()=>i[D],set:N=>i[D]=N,enumerable:!0})})}else e.exposed||(e.exposed={});M&&e.render===qt&&(e.render=M),G!=null&&(e.inheritAttrs=G),S&&(e.components=S),L&&(e.directives=L),R&&zl(e)}function Xd(e,t,i=qt){$e(e)&&(e=gs(e));for(const n in e){const o=e[n];let s;He(o)?"default"in o?s=ti(o.from||n,o.default,!0):s=ti(o.from||n):s=ti(o),Ye(s)?Object.defineProperty(t,n,{enumerable:!0,configurable:!0,get:()=>s.value,set:l=>s.value=l}):t[n]=s}}function gr(e,t,i){zt($e(e)?e.map(n=>n.bind(t.proxy)):e.bind(t.proxy),t,i)}function Wl(e,t,i,n){let o=n.includes(".")?Nl(i,n):()=>i[n];if(it(e)){const s=t[e];Ee(s)&&Li(o,s)}else if(Ee(e))Li(o,e.bind(i));else if(He(e))if($e(e))e.forEach(s=>Wl(s,t,i,n));else{const s=Ee(e.handler)?e.handler.bind(i):t[e.handler];Ee(s)&&Li(o,s,e)}}function Ul(e){const t=e.type,{mixins:i,extends:n}=t,{mixins:o,optionsCache:s,config:{optionMergeStrategies:l}}=e.appContext,r=s.get(t);let a;return r?a=r:!o.length&&!i&&!n?a=t:(a={},o.length&&o.forEach(c=>ko(a,c,l,!0)),ko(a,t,l)),He(t)&&s.set(t,a),a}function ko(e,t,i,n=!1){const{mixins:o,extends:s}=t;s&&ko(e,s,i,!0),o&&o.forEach(l=>ko(e,l,i,!0));for(const l in t)if(!(n&&l==="expose")){const r=Qd[l]||i&&i[l];e[l]=r?r(e[l],t[l]):t[l]}return e}const Qd={data:vr,props:br,emits:br,methods:mn,computed:mn,beforeCreate:vt,created:vt,beforeMount:vt,mounted:vt,beforeUpdate:vt,updated:vt,beforeDestroy:vt,beforeUnmount:vt,destroyed:vt,unmounted:vt,activated:vt,deactivated:vt,errorCaptured:vt,serverPrefetch:vt,components:mn,directives:mn,watch:tu,provide:vr,inject:eu};function vr(e,t){return t?e?function(){return dt(Ee(e)?e.call(this,this):e,Ee(t)?t.call(this,this):t)}:t:e}function eu(e,t){return mn(gs(e),gs(t))}function gs(e){if($e(e)){const t={};for(let i=0;i<e.length;i++)t[e[i]]=e[i];return t}return e}function vt(e,t){return e?[...new Set([].concat(e,t))]:t}function mn(e,t){return e?dt(Object.create(null),e,t):t}function br(e,t){return e?$e(e)&&$e(t)?[...new Set([...e,...t])]:dt(Object.create(null),mr(e),mr(t??{})):t}function tu(e,t){if(!e)return t;if(!t)return e;const i=dt(Object.create(null),e);for(const n in t)i[n]=vt(e[n],t[n]);return i}function Vl(){return{app:null,config:{isNativeTag:ll,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let iu=0;function nu(e,t){return function(n,o=null){Ee(n)||(n=dt({},n)),o!=null&&!He(o)&&(o=null);const s=Vl(),l=new WeakSet,r=[];let a=!1;const c=s.app={_uid:iu++,_component:n,_props:o,_container:null,_context:s,_instance:null,version:Ou,get config(){return s.config},set config(d){},use(d,...p){return l.has(d)||(d&&Ee(d.install)?(l.add(d),d.install(c,...p)):Ee(d)&&(l.add(d),d(c,...p))),c},mixin(d){return s.mixins.includes(d)||s.mixins.push(d),c},component(d,p){return p?(s.components[d]=p,c):s.components[d]},directive(d,p){return p?(s.directives[d]=p,c):s.directives[d]},mount(d,p,v){if(!a){const u=c._ceVNode||re(n,o);return u.appContext=s,v===!0?v="svg":v===!1&&(v=void 0),e(u,d,v),a=!0,c._container=d,d.__vue_app__=c,No(u.component)}},onUnmount(d){r.push(d)},unmount(){a&&(zt(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(d,p){return s.provides[d]=p,c},runWithContext(d){const p=en;en=c;try{return d()}finally{en=p}}};return c}}let en=null;const ou=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${wt(t)}Modifiers`]||e[`${yi(t)}Modifiers`];function su(e,t,...i){if(e.isUnmounted)return;const n=e.vnode.props||We;let o=i;const s=t.startsWith("update:"),l=s&&ou(n,t.slice(7));l&&(l.trim&&(o=i.map(d=>it(d)?d.trim():d)),l.number&&(o=i.map(Ao)));let r,a=n[r=Wo(t)]||n[r=Wo(wt(t))];!a&&s&&(a=n[r=Wo(yi(t))]),a&&zt(a,e,6,o);const c=n[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,zt(c,e,6,o)}}const ru=new WeakMap;function Kl(e,t,i=!1){const n=i?ru:t.emitsCache,o=n.get(e);if(o!==void 0)return o;const s=e.emits;let l={},r=!1;if(!Ee(e)){const a=c=>{const d=Kl(c,t,!0);d&&(r=!0,dt(l,d))};!i&&t.mixins.length&&t.mixins.forEach(a),e.extends&&a(e.extends),e.mixins&&e.mixins.forEach(a)}return!s&&!r?(He(e)&&n.set(e,null),null):($e(s)?s.forEach(a=>l[a]=null):dt(l,s),He(e)&&n.set(e,l),l)}function Po(e,t){return!e||!$o(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),Re(e,t[0].toLowerCase()+t.slice(1))||Re(e,yi(t))||Re(e,t))}function yr(e){const{type:t,vnode:i,proxy:n,withProxy:o,propsOptions:[s],slots:l,attrs:r,emit:a,render:c,renderCache:d,props:p,data:v,setupState:u,ctx:h,inheritAttrs:f}=e,b=bo(e);let k,x;try{if(i.shapeFlag&4){const A=o||n,M=A;k=Ut(c.call(M,A,d,p,u,v,h)),x=r}else{const A=t;k=Ut(A.length>1?A(p,{attrs:r,slots:l,emit:a}):A(p,null)),x=t.props?r:lu(r)}}catch(A){ii.length=0,Lo(A,e,1),k=re(li)}let _=k;if(x&&f!==!1){const A=Object.keys(x),{shapeFlag:M}=_;A.length&&M&7&&(s&&A.some(Io)&&(x=au(x,s)),_=on(_,x,!1,!0))}return i.dirs&&(_=on(_,null,!1,!0),_.dirs=_.dirs?_.dirs.concat(i.dirs):i.dirs),i.transition&&zs(_,i.transition),k=_,bo(b),k}const lu=e=>{let t;for(const i in e)(i==="class"||i==="style"||$o(i))&&((t||(t={}))[i]=e[i]);return t},au=(e,t)=>{const i={};for(const n in e)(!Io(n)||!(n.slice(9)in t))&&(i[n]=e[n]);return i};function cu(e,t,i){const{props:n,children:o,component:s}=e,{props:l,children:r,patchFlag:a}=t,c=s.emitsOptions;if(t.dirs||t.transition)return!0;if(i&&a>=0){if(a&1024)return!0;if(a&16)return n?kr(n,l,c):!!l;if(a&8){const d=t.dynamicProps;for(let p=0;p<d.length;p++){const v=d[p];if(ql(l,n,v)&&!Po(c,v))return!0}}}else return(o||r)&&(!r||!r.$stable)?!0:n===l?!1:n?l?kr(n,l,c):!0:!!l;return!1}function kr(e,t,i){const n=Object.keys(t);if(n.length!==Object.keys(e).length)return!0;for(let o=0;o<n.length;o++){const s=n[o];if(ql(t,e,s)&&!Po(i,s))return!0}return!1}function ql(e,t,i){const n=e[i],o=t[i];return i==="style"&&He(n)&&He(o)?!an(n,o):n!==o}function du({vnode:e,parent:t,suspense:i},n){for(;t;){const o=t.subTree;if(o.suspense&&o.suspense.activeBranch===e&&(o.suspense.vnode.el=o.el=n,e=o),o===e)(e=t.vnode).el=n,t=t.parent;else break}i&&i.activeBranch===e&&(i.vnode.el=n)}const Gl={},Zl=()=>Object.create(Gl),Yl=e=>Object.getPrototypeOf(e)===Gl;function uu(e,t,i,n=!1){const o={},s=Zl();e.propsDefaults=Object.create(null),Jl(e,t,o,s);for(const l in e.propsOptions[0])l in o||(o[l]=void 0);i?e.props=n?o:bd(o):e.type.props?e.props=o:e.props=s,e.attrs=s}function fu(e,t,i,n){const{props:o,attrs:s,vnode:{patchFlag:l}}=e,r=Pe(o),[a]=e.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const d=e.vnode.dynamicProps;for(let p=0;p<d.length;p++){let v=d[p];if(Po(e.emitsOptions,v))continue;const u=t[v];if(a)if(Re(s,v))u!==s[v]&&(s[v]=u,c=!0);else{const h=wt(v);o[h]=vs(a,r,h,u,e,!1)}else u!==s[v]&&(s[v]=u,c=!0)}}}else{Jl(e,t,o,s)&&(c=!0);let d;for(const p in r)(!t||!Re(t,p)&&((d=yi(p))===p||!Re(t,d)))&&(a?i&&(i[p]!==void 0||i[d]!==void 0)&&(o[p]=vs(a,r,p,void 0,e,!0)):delete o[p]);if(s!==r)for(const p in s)(!t||!Re(t,p))&&(delete s[p],c=!0)}c&&Qt(e.attrs,"set","")}function Jl(e,t,i,n){const[o,s]=e.propsOptions;let l=!1,r;if(t)for(let a in t){if(bn(a))continue;const c=t[a];let d;o&&Re(o,d=wt(a))?!s||!s.includes(d)?i[d]=c:(r||(r={}))[d]=c:Po(e.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(s){const a=Pe(i),c=r||We;for(let d=0;d<s.length;d++){const p=s[d];i[p]=vs(o,a,p,c[p],e,!Re(c,p))}}return l}function vs(e,t,i,n,o,s){const l=e[i];if(l!=null){const r=Re(l,"default");if(r&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&Ee(a)){const{propsDefaults:c}=o;if(i in c)n=c[i];else{const d=jn(o);n=c[i]=a.call(null,t),d()}}else n=a;o.ce&&o.ce._setProp(i,n)}l[0]&&(s&&!r?n=!1:l[1]&&(n===""||n===yi(i))&&(n=!0))}return n}const pu=new WeakMap;function Xl(e,t,i=!1){const n=i?pu:t.propsCache,o=n.get(e);if(o)return o;const s=e.props,l={},r=[];let a=!1;if(!Ee(e)){const d=p=>{a=!0;const[v,u]=Xl(p,t,!0);dt(l,v),u&&r.push(...u)};!i&&t.mixins.length&&t.mixins.forEach(d),e.extends&&d(e.extends),e.mixins&&e.mixins.forEach(d)}if(!s&&!a)return He(e)&&n.set(e,Yi),Yi;if($e(s))for(let d=0;d<s.length;d++){const p=wt(s[d]);wr(p)&&(l[p]=We)}else if(s)for(const d in s){const p=wt(d);if(wr(p)){const v=s[d],u=l[p]=$e(v)||Ee(v)?{type:v}:dt({},v),h=u.type;let f=!1,b=!0;if($e(h))for(let k=0;k<h.length;++k){const x=h[k],_=Ee(x)&&x.name;if(_==="Boolean"){f=!0;break}else _==="String"&&(b=!1)}else f=Ee(h)&&h.name==="Boolean";u[0]=f,u[1]=b,(f||Re(u,"default"))&&r.push(p)}}const c=[l,r];return He(e)&&n.set(e,c),c}function wr(e){return e[0]!=="$"&&!bn(e)}const js=e=>e==="_"||e==="_ctx"||e==="$stable",Ws=e=>$e(e)?e.map(Ut):[Ut(e)],hu=(e,t,i)=>{if(t._n)return t;const n=Pl((...o)=>Ws(t(...o)),i);return n._c=!1,n},Ql=(e,t,i)=>{const n=e._ctx;for(const o in e){if(js(o))continue;const s=e[o];if(Ee(s))t[o]=hu(o,s,n);else if(s!=null){const l=Ws(s);t[o]=()=>l}}},ea=(e,t)=>{const i=Ws(t);e.slots.default=()=>i},ta=(e,t,i)=>{for(const n in t)(i||!js(n))&&(e[n]=t[n])},mu=(e,t,i)=>{const n=e.slots=Zl();if(e.vnode.shapeFlag&32){const o=t._;o?(ta(n,t,i),i&&ul(n,"_",o,!0)):Ql(t,n)}else t&&ea(e,t)},gu=(e,t,i)=>{const{vnode:n,slots:o}=e;let s=!0,l=We;if(n.shapeFlag&32){const r=t._;r?i&&r===1?s=!1:ta(o,t,i):(s=!t.$stable,Ql(t,o)),l=t}else t&&(ea(e,t),l={default:1});if(s)for(const r in o)!js(r)&&l[r]==null&&delete o[r]},St=wu;function vu(e){return bu(e)}function bu(e,t){const i=Bo();i.__VUE__=!0;const{insert:n,remove:o,patchProp:s,createElement:l,createText:r,createComment:a,setText:c,setElementText:d,parentNode:p,nextSibling:v,setScopeId:u=qt,insertStaticContent:h}=e,f=(O,j,g,q=null,H=null,$=null,I=void 0,C=null,W=!!j.dynamicChildren)=>{if(O===j)return;O&&!pn(O,j)&&(q=Te(O),U(O,H,$,!0),O=null),j.patchFlag===-2&&(W=!1,j.dynamicChildren=null);const{type:K,ref:V,shapeFlag:Q}=j;switch(K){case Ro:b(O,j,g,q);break;case li:k(O,j,g,q);break;case io:O==null&&x(j,g,q,I);break;case Ue:S(O,j,g,q,H,$,I,C,W);break;default:Q&1?M(O,j,g,q,H,$,I,C,W):Q&6?L(O,j,g,q,H,$,I,C,W):(Q&64||Q&128)&&K.process(O,j,g,q,H,$,I,C,W,Y)}V!=null&&H?wn(V,O&&O.ref,$,j||O,!j):V==null&&O&&O.ref!=null&&wn(O.ref,null,$,O,!0)},b=(O,j,g,q)=>{if(O==null)n(j.el=r(j.children),g,q);else{const H=j.el=O.el;j.children!==O.children&&c(H,j.children)}},k=(O,j,g,q)=>{O==null?n(j.el=a(j.children||""),g,q):j.el=O.el},x=(O,j,g,q)=>{[O.el,O.anchor]=h(O.children,j,g,q,O.el,O.anchor)},_=({el:O,anchor:j},g,q)=>{let H;for(;O&&O!==j;)H=v(O),n(O,g,q),O=H;n(j,g,q)},A=({el:O,anchor:j})=>{let g;for(;O&&O!==j;)g=v(O),o(O),O=g;o(j)},M=(O,j,g,q,H,$,I,C,W)=>{if(j.type==="svg"?I="svg":j.type==="math"&&(I="mathml"),O==null)E(j,g,q,H,$,I,C,W);else{const K=O.el&&O.el._isVueCE?O.el:null;try{K&&K._beginPatch(),R(O,j,H,$,I,C,W)}finally{K&&K._endPatch()}}},E=(O,j,g,q,H,$,I,C)=>{let W,K;const{props:V,shapeFlag:Q,transition:oe,dirs:ne}=O;if(W=O.el=l(O.type,$,V&&V.is,V),Q&8?d(W,O.children):Q&16&&P(O.children,W,null,q,H,Yo(O,$),I,C),ne&&wi(O,null,q,"created"),w(W,O,O.scopeId,I,q),V){for(const Se in V)Se!=="value"&&!bn(Se)&&s(W,Se,null,V[Se],$,q);"value"in V&&s(W,"value",null,V.value,$),(K=V.onVnodeBeforeMount)&&Ht(K,q,O)}ne&&wi(O,null,q,"beforeMount");const ue=yu(H,oe);ue&&oe.beforeEnter(W),n(W,j,g),((K=V&&V.onVnodeMounted)||ue||ne)&&St(()=>{try{K&&Ht(K,q,O),ue&&oe.enter(W),ne&&wi(O,null,q,"mounted")}finally{}},H)},w=(O,j,g,q,H)=>{if(g&&u(O,g),q)for(let $=0;$<q.length;$++)u(O,q[$]);if(H){let $=H.subTree;if(j===$||sa($.type)&&($.ssContent===j||$.ssFallback===j)){const I=H.vnode;w(O,I,I.scopeId,I.slotScopeIds,H.parent)}}},P=(O,j,g,q,H,$,I,C,W=0)=>{for(let K=W;K<O.length;K++){const V=O[K]=C?Xt(O[K]):Ut(O[K]);f(null,V,j,g,q,H,$,I,C)}},R=(O,j,g,q,H,$,I)=>{const C=j.el=O.el;let{patchFlag:W,dynamicChildren:K,dirs:V}=j;W|=O.patchFlag&16;const Q=O.props||We,oe=j.props||We;let ne;if(g&&xi(g,!1),(ne=oe.onVnodeBeforeUpdate)&&Ht(ne,g,j,O),V&&wi(j,O,g,"beforeUpdate"),g&&xi(g,!0),K&&(!O.dynamicChildren||O.dynamicChildren.length!==K.length)&&(W=0,I=!1,K=null),(Q.innerHTML&&oe.innerHTML==null||Q.textContent&&oe.textContent==null)&&d(C,""),K?z(O.dynamicChildren,K,C,g,q,Yo(j,H),$):I||D(O,j,C,null,g,q,Yo(j,H),$,!1),W>0){if(W&16)G(C,Q,oe,g,H);else if(W&2&&Q.class!==oe.class&&s(C,"class",null,oe.class,H),W&4&&s(C,"style",Q.style,oe.style,H),W&8){const ue=j.dynamicProps;for(let Se=0;Se<ue.length;Se++){const ke=ue[Se],Me=Q[ke],Ve=oe[ke];(Ve!==Me||ke==="value")&&s(C,ke,Me,Ve,H,g)}}W&1&&O.children!==j.children&&d(C,j.children)}else!I&&K==null&&G(C,Q,oe,g,H);((ne=oe.onVnodeUpdated)||V)&&St(()=>{ne&&Ht(ne,g,j,O),V&&wi(j,O,g,"updated")},q)},z=(O,j,g,q,H,$,I)=>{for(let C=0;C<j.length;C++){const W=O[C],K=j[C],V=W.el&&(W.type===Ue||!pn(W,K)||W.shapeFlag&198)?p(W.el):g;f(W,K,V,null,q,H,$,I,!0)}},G=(O,j,g,q,H)=>{if(j!==g){if(j!==We)for(const $ in j)!bn($)&&!($ in g)&&s(O,$,j[$],null,H,q);for(const $ in g){if(bn($))continue;const I=g[$],C=j[$];I!==C&&$!=="value"&&s(O,$,C,I,H,q)}"value"in g&&s(O,"value",j.value,g.value,H)}},S=(O,j,g,q,H,$,I,C,W)=>{const K=j.el=O?O.el:r(""),V=j.anchor=O?O.anchor:r("");let{patchFlag:Q,dynamicChildren:oe,slotScopeIds:ne}=j;ne&&(C=C?C.concat(ne):ne),O==null?(n(K,g,q),n(V,g,q),P(j.children||[],g,V,H,$,I,C,W)):Q>0&&Q&64&&oe&&O.dynamicChildren&&O.dynamicChildren.length===oe.length?(z(O.dynamicChildren,oe,g,H,$,I,C),(j.key!=null||H&&j===H.subTree)&&ia(O,j,!0)):D(O,j,g,V,H,$,I,C,W)},L=(O,j,g,q,H,$,I,C,W)=>{j.slotScopeIds=C,O==null?j.shapeFlag&512?H.ctx.activate(j,g,q,I,W):y(j,g,q,H,$,I,W):B(O,j,W)},y=(O,j,g,q,H,$,I)=>{const C=O.component=Iu(O,q,H);if(Fl(O)&&(C.ctx.renderer=Y),Tu(C,!1,I),C.asyncDep){if(H&&H.registerDep(C,F,I),!O.el){const W=C.subTree=re(li);k(null,W,j,g),O.placeholder=W.el}}else F(C,O,j,g,H,$,I)},B=(O,j,g)=>{const q=j.component=O.component;if(cu(O,j,g))if(q.asyncDep&&!q.asyncResolved){T(q,j,g);return}else q.next=j,q.update();else j.el=O.el,q.vnode=j},F=(O,j,g,q,H,$,I)=>{const C=()=>{if(O.isMounted){let{next:Q,bu:oe,u:ne,parent:ue,vnode:Se}=O;{const Je=na(O);if(Je){Q&&(Q.el=Se.el,T(O,Q,I)),Je.asyncDep.then(()=>{St(()=>{O.isUnmounted||K()},H)});return}}let ke=Q,Me;xi(O,!1),Q?(Q.el=Se.el,T(O,Q,I)):Q=Se,oe&&to(oe),(Me=Q.props&&Q.props.onVnodeBeforeUpdate)&&Ht(Me,ue,Q,Se),xi(O,!0);const Ve=yr(O),Ge=O.subTree;O.subTree=Ve,f(Ge,Ve,p(Ge.el),Te(Ge),O,H,$),Q.el=Ve.el,ke===null&&du(O,Ve.el),ne&&St(ne,H),(Me=Q.props&&Q.props.onVnodeUpdated)&&St(()=>Ht(Me,ue,Q,Se),H)}else{let Q;const{el:oe,props:ne}=j,{bm:ue,m:Se,parent:ke,root:Me,type:Ve}=O,Ge=Qi(j);xi(O,!1),ue&&to(ue),!Ge&&(Q=ne&&ne.onVnodeBeforeMount)&&Ht(Q,ke,j),xi(O,!0);{Me.ce&&Me.ce._hasShadowRoot()&&Me.ce._injectChildStyle(Ve,O.parent?O.parent.type:void 0);const Je=O.subTree=yr(O);f(null,Je,g,q,O,H,$),j.el=Je.el}if(Se&&St(Se,H),!Ge&&(Q=ne&&ne.onVnodeMounted)){const Je=j;St(()=>Ht(Q,ke,Je),H)}(j.shapeFlag&256||ke&&Qi(ke.vnode)&&ke.vnode.shapeFlag&256)&&O.a&&St(O.a,H),O.isMounted=!0,j=g=q=null}};O.scope.on();const W=O.effect=new ml(C);O.scope.off();const K=O.update=W.run.bind(W),V=O.job=W.runIfDirty.bind(W);V.i=O,V.id=O.uid,W.scheduler=()=>Ns(V),xi(O,!0),K()},T=(O,j,g)=>{j.component=O;const q=O.vnode.props;O.vnode=j,O.next=null,fu(O,j.props,q,g),gu(O,j.children,g),oi(),ur(O),si()},D=(O,j,g,q,H,$,I,C,W=!1)=>{const K=O&&O.children,V=O?O.shapeFlag:0,Q=j.children,{patchFlag:oe,shapeFlag:ne}=j;if(oe>0){if(oe&128){X(K,Q,g,q,H,$,I,C,W);return}else if(oe&256){N(K,Q,g,q,H,$,I,C,W);return}}ne&8?(V&16&&ve(K,H,$),Q!==K&&d(g,Q)):V&16?ne&16?X(K,Q,g,q,H,$,I,C,W):ve(K,H,$,!0):(V&8&&d(g,""),ne&16&&P(Q,g,q,H,$,I,C,W))},N=(O,j,g,q,H,$,I,C,W)=>{O=O||Yi,j=j||Yi;const K=O.length,V=j.length,Q=Math.min(K,V);let oe;for(oe=0;oe<Q;oe++){const ne=j[oe]=W?Xt(j[oe]):Ut(j[oe]);f(O[oe],ne,g,null,H,$,I,C,W)}K>V?ve(O,H,$,!0,!1,Q):P(j,g,q,H,$,I,C,W,Q)},X=(O,j,g,q,H,$,I,C,W)=>{let K=0;const V=j.length;let Q=O.length-1,oe=V-1;for(;K<=Q&&K<=oe;){const ne=O[K],ue=j[K]=W?Xt(j[K]):Ut(j[K]);if(pn(ne,ue))f(ne,ue,g,null,H,$,I,C,W);else break;K++}for(;K<=Q&&K<=oe;){const ne=O[Q],ue=j[oe]=W?Xt(j[oe]):Ut(j[oe]);if(pn(ne,ue))f(ne,ue,g,null,H,$,I,C,W);else break;Q--,oe--}if(K>Q){if(K<=oe){const ne=oe+1,ue=ne<V?j[ne].el:q;for(;K<=oe;)f(null,j[K]=W?Xt(j[K]):Ut(j[K]),g,ue,H,$,I,C,W),K++}}else if(K>oe)for(;K<=Q;)U(O[K],H,$,!0),K++;else{const ne=K,ue=K,Se=new Map;for(K=ue;K<=oe;K++){const st=j[K]=W?Xt(j[K]):Ut(j[K]);st.key!=null&&Se.set(st.key,K)}let ke,Me=0;const Ve=oe-ue+1;let Ge=!1,Je=0;const De=new Array(Ve);for(K=0;K<Ve;K++)De[K]=0;for(K=ne;K<=Q;K++){const st=O[K];if(Me>=Ve){U(st,H,$,!0);continue}let Xe;if(st.key!=null)Xe=Se.get(st.key);else for(ke=ue;ke<=oe;ke++)if(De[ke-ue]===0&&pn(st,j[ke])){Xe=ke;break}Xe===void 0?U(st,H,$,!0):(De[Xe-ue]=K+1,Xe>=Je?Je=Xe:Ge=!0,f(st,j[Xe],g,null,H,$,I,C,W),Me++)}const Zt=Ge?ku(De):Yi;for(ke=Zt.length-1,K=Ve-1;K>=0;K--){const st=ue+K,Xe=j[st],Ft=j[st+1],Ni=st+1<V?Ft.el||oa(Ft):q;De[K]===0?f(null,Xe,g,Ni,H,$,I,C,W):Ge&&(ke<0||K!==Zt[ke]?Z(Xe,g,Ni,2):ke--)}}},Z=(O,j,g,q,H=null)=>{const{el:$,type:I,transition:C,children:W,shapeFlag:K}=O;if(K&6){Z(O.component.subTree,j,g,q);return}if(K&128){O.suspense.move(j,g,q);return}if(K&64){I.move(O,j,g,Y);return}if(I===Ue){n($,j,g);for(let Q=0;Q<W.length;Q++)Z(W[Q],j,g,q);n(O.anchor,j,g);return}if(I===io){_(O,j,g);return}if(q!==2&&K&1&&C)if(q===0)C.persisted&&!$[Go]?n($,j,g):(C.beforeEnter($),n($,j,g),St(()=>C.enter($),H));else{const{leave:Q,delayLeave:oe,afterLeave:ne}=C,ue=()=>{O.ctx.isUnmounted?o($):n($,j,g)},Se=()=>{const ke=$._isLeaving||!!$[Go];$._isLeaving&&$[Go](!0),C.persisted&&!ke?ue():Q($,()=>{ue(),ne&&ne()})};oe?oe($,ue,Se):Se()}else n($,j,g)},U=(O,j,g,q=!1,H=!1)=>{const{type:$,props:I,ref:C,children:W,dynamicChildren:K,shapeFlag:V,patchFlag:Q,dirs:oe,cacheIndex:ne,memo:ue}=O;if(Q===-2&&(H=!1),C!=null&&(oi(),wn(C,null,g,O,!0),si()),ne!=null&&(j.renderCache[ne]=void 0),V&256){j.ctx.deactivate(O);return}const Se=V&1&&oe,ke=!Qi(O);let Me;if(ke&&(Me=I&&I.onVnodeBeforeUnmount)&&Ht(Me,j,O),V&6)le(O.component,g,q);else{if(V&128){O.suspense.unmount(g,q);return}Se&&wi(O,null,j,"beforeUnmount"),V&64?O.type.remove(O,j,g,Y,q):K&&!K.hasOnce&&($!==Ue||Q>0&&Q&64)?ve(K,j,g,!1,!0):($===Ue&&Q&384||!H&&V&16)&&ve(W,j,g),q&&ie(O)}const Ve=ue!=null&&ne==null;(ke&&(Me=I&&I.onVnodeUnmounted)||Se||Ve)&&St(()=>{Me&&Ht(Me,j,O),Se&&wi(O,null,j,"unmounted"),Ve&&(O.el=null)},g)},ie=O=>{const{type:j,el:g,anchor:q,transition:H}=O;if(j===Ue){se(g,q);return}if(j===io){A(O);return}const $=()=>{o(g),H&&!H.persisted&&H.afterLeave&&H.afterLeave()};if(O.shapeFlag&1&&H&&!H.persisted){const{leave:I,delayLeave:C}=H,W=()=>I(g,$);C?C(O.el,$,W):W()}else $()},se=(O,j)=>{let g;for(;O!==j;)g=v(O),o(O),O=g;o(j)},le=(O,j,g)=>{const{bum:q,scope:H,job:$,subTree:I,um:C,m:W,a:K}=O;xr(W),xr(K),q&&to(q),H.stop(),$&&($.flags|=8,U(I,O,j,g)),C&&St(C,j),St(()=>{O.isUnmounted=!0},j)},ve=(O,j,g,q=!1,H=!1,$=0)=>{for(let I=$;I<O.length;I++)U(O[I],j,g,q,H)},Te=O=>{if(O.shapeFlag&6)return Te(O.component.subTree);if(O.shapeFlag&128)return O.suspense.next();const j=v(O.anchor||O.el),g=j&&j[Ld];return g?v(g):j};let ye=!1;const ae=(O,j,g)=>{let q;O==null?j._vnode&&(U(j._vnode,null,null,!0),q=j._vnode.component):f(j._vnode||null,O,j,null,null,null,g),j._vnode=O,ye||(ye=!0,ur(q),Dl(),ye=!1)},Y={p:f,um:U,m:Z,r:ie,mt:y,mc:P,pc:D,pbc:z,n:Te,o:e};return{render:ae,hydrate:void 0,createApp:nu(ae)}}function Yo({type:e,props:t},i){return i==="svg"&&e==="foreignObject"||i==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:i}function xi({effect:e,job:t},i){i?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function yu(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function ia(e,t,i=!1){const n=e.children,o=t.children;if($e(n)&&$e(o))for(let s=0;s<n.length;s++){const l=n[s];let r=o[s];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=o[s]=Xt(o[s]),r.el=l.el),!i&&r.patchFlag!==-2&&ia(l,r)),r.type===Ro&&(r.patchFlag===-1&&(r=o[s]=Xt(r)),r.el=l.el),r.type===li&&!r.el&&(r.el=l.el)}}function ku(e){const t=e.slice(),i=[0];let n,o,s,l,r;const a=e.length;for(n=0;n<a;n++){const c=e[n];if(c!==0){if(o=i[i.length-1],e[o]<c){t[n]=o,i.push(n);continue}for(s=0,l=i.length-1;s<l;)r=s+l>>1,e[i[r]]<c?s=r+1:l=r;c<e[i[s]]&&(s>0&&(t[n]=i[s-1]),i[s]=n)}}for(s=i.length,l=i[s-1];s-- >0;)i[s]=l,l=t[l];return i}function na(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:na(t)}function xr(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function oa(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?oa(t.subTree):null}const sa=e=>e.__isSuspense;function wu(e,t){t&&t.pendingBranch?$e(e)?t.effects.push(...e):t.effects.push(e):Td(e)}const Ue=Symbol.for("v-fgt"),Ro=Symbol.for("v-txt"),li=Symbol.for("v-cmt"),io=Symbol.for("v-stc"),ii=[];let It=null;function ee(e=!1){ii.push(It=e?null:[])}function Us(){ii.pop(),It=ii[ii.length-1]||null}let On=1;function Sr(e,t=!1){On+=e,e<0&&It&&t&&(It.hasOnce=!0)}function ra(e){return e.dynamicChildren=On>0?It||Yi:null,Us(),On>0&&It&&It.push(e),e}function te(e,t,i,n,o,s){return ra(m(e,t,i,n,o,s,!0))}function Ot(e,t,i,n,o){return ra(re(e,t,i,n,o,!0))}function Vs(e){return e?e.__v_isVNode===!0:!1}function pn(e,t){return e.type===t.type&&e.key===t.key}const la=({key:e})=>e??null,no=({ref:e,ref_key:t,ref_for:i})=>(typeof e=="number"&&(e=""+e),e!=null?it(e)||Ye(e)||Ee(e)?{i:ct,r:e,k:t,f:!!i}:e:null);function m(e,t=null,i=null,n=0,o=null,s=e===Ue?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&la(t),ref:t&&no(t),scopeId:Ol,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:n,dynamicProps:o,dynamicChildren:null,appContext:null,ctx:ct};return r?(wo(a,i),s&128&&e.normalize(a)):i&&(a.shapeFlag|=it(i)?8:16),On>0&&!l&&It&&(a.patchFlag>0||s&6)&&a.patchFlag!==32&&It.push(a),a}const re=xu;function xu(e,t=null,i=null,n=0,o=null,s=!1){if((!e||e===Gd)&&(e=li),Vs(e)){const r=on(e,t,!0);return i&&wo(r,i),On>0&&!s&&It&&(r.shapeFlag&6?It[It.indexOf(e)]=r:It.push(r)),r.patchFlag=-2,r}if(Lu(e)&&(e=e.__vccOpts),t){t=Su(t);let{class:r,style:a}=t;r&&!it(r)&&(t.class=_e(r)),He(a)&&(Rs(a)&&!$e(a)&&(a=dt({},a)),t.style=Bn(a))}const l=it(e)?1:sa(e)?128:Od(e)?64:He(e)?4:Ee(e)?2:0;return m(e,t,i,n,o,l,s,!0)}function Su(e){return e?Rs(e)||Yl(e)?dt({},e):e:null}function on(e,t,i=!1,n=!1){const{props:o,ref:s,patchFlag:l,children:r,transition:a}=e,c=t?_u(o||{},t):o,d={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&la(c),ref:t&&t.ref?i&&s?$e(s)?s.concat(no(t)):[s,no(t)]:no(t):s,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Ue?l===-1?16:l|16:l,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:a,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&on(e.ssContent),ssFallback:e.ssFallback&&on(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return a&&n&&zs(d,a.clone(d)),d}function $t(e=" ",t=0){return re(Ro,null,e,t)}function gt(e,t){const i=re(io,null,e);return i.staticCount=t,i}function Oe(e="",t=!1){return t?(ee(),Ot(li,null,e)):re(li,null,e)}function Ut(e){return e==null||typeof e=="boolean"?re(li):$e(e)?re(Ue,null,e.slice()):Vs(e)?Xt(e):re(Ro,null,String(e))}function Xt(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:on(e)}function wo(e,t){let i=0;const{shapeFlag:n}=e;if(t==null)t=null;else if($e(t))i=16;else if(typeof t=="object")if(n&65){const o=t.default;o&&(o._c&&(o._d=!1),wo(e,o()),o._c&&(o._d=!0));return}else{i=32;const o=t._;!o&&!Yl(t)?t._ctx=ct:o===3&&ct&&(ct.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(Ee(t)){if(n&65){wo(e,{default:t});return}t={default:t,_ctx:ct},i=32}else t=String(t),n&64?(i=16,t=[$t(t)]):i=8;e.children=t,e.shapeFlag|=i}function _u(...e){const t={};for(let i=0;i<e.length;i++){const n=e[i];for(const o in n)if(o==="class")t.class!==n.class&&(t.class=_e([t.class,n.class]));else if(o==="style")t.style=Bn([t.style,n.style]);else if($o(o)){const s=t[o],l=n[o];l&&s!==l&&!($e(s)&&s.includes(l))?t[o]=s?[].concat(s,l):l:l==null&&s==null&&!Io(o)&&(t[o]=l)}else o!==""&&(t[o]=n[o])}return t}function Ht(e,t,i,n=null){zt(e,t,7,[i,n])}const Cu=Vl();let $u=0;function Iu(e,t,i){const n=e.type,o=(t?t.appContext:e.appContext)||Cu,s={uid:$u++,vnode:e,type:n,parent:t,appContext:o,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Qc(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(o.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Xl(n,o),emitsOptions:Kl(n,o),emit:null,emitted:null,propsDefaults:We,inheritAttrs:n.inheritAttrs,ctx:We,data:We,props:We,attrs:We,slots:We,refs:We,setupState:We,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return s.ctx={_:s},s.root=t?t.root:s,s.emit=su.bind(null,s),e.ce&&e.ce(s),s}let ht=null;const Eu=()=>ht||ct;let xo,bs;{const e=Bo(),t=(i,n)=>{let o;return(o=e[i])||(o=e[i]=[]),o.push(n),s=>{o.length>1?o.forEach(l=>l(s)):o[0](s)}};xo=t("__VUE_INSTANCE_SETTERS__",i=>ht=i),bs=t("__VUE_SSR_SETTERS__",i=>Pn=i)}const jn=e=>{const t=ht;return xo(e),e.scope.on(),()=>{e.scope.off(),xo(t)}},_r=()=>{ht&&ht.scope.off(),xo(null)};function aa(e){return e.vnode.shapeFlag&4}let Pn=!1;function Tu(e,t=!1,i=!1){t&&bs(t);const{props:n,children:o}=e.vnode,s=aa(e);uu(e,n,s,t),mu(e,o,i||t);const l=s?Au(e,t):void 0;return t&&bs(!1),l}function Au(e,t){const i=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,Yd);const{setup:n}=i;if(n){oi();const o=e.setupContext=n.length>1?Mu(e):null,s=jn(e),l=Fn(n,e,0,[e.props,o]),r=al(l);if(si(),s(),(r||e.sp)&&!Qi(e)&&zl(e),r){if(l.then(_r,_r),t)return l.then(a=>{Cr(e,a)}).catch(a=>{Lo(a,e,0)});e.asyncDep=l}else Cr(e,l)}else ca(e)}function Cr(e,t,i){Ee(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:He(t)&&(e.setupState=Tl(t)),ca(e)}function ca(e,t,i){const n=e.type;e.render||(e.render=n.render||qt);{const o=jn(e);oi();try{Jd(e)}finally{si(),o()}}}const Bu={get(e,t){return pt(e,"get",""),e[t]}};function Mu(e){const t=i=>{e.exposed=i||{}};return{attrs:new Proxy(e.attrs,Bu),slots:e.slots,emit:e.emit,expose:t}}function No(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(Tl(yd(e.exposed)),{get(t,i){if(i in t)return t[i];if(i in xn)return xn[i](e)},has(t,i){return i in t||i in xn}})):e.proxy}function Du(e,t=!0){return Ee(e)?e.displayName||e.name:e.name||t&&e.__name}function Lu(e){return Ee(e)&&"__vccOpts"in e}const xe=(e,t)=>_d(e,t,Pn),Ou="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let ys;const $r=typeof window<"u"&&window.trustedTypes;if($r)try{ys=$r.createPolicy("vue",{createHTML:e=>e})}catch{}const da=ys?e=>ys.createHTML(e):e=>e,Pu="http://www.w3.org/2000/svg",Ru="http://www.w3.org/1998/Math/MathML",Jt=typeof document<"u"?document:null,Ir=Jt&&Jt.createElement("template"),Nu={insert:(e,t,i)=>{t.insertBefore(e,i||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,i,n)=>{const o=t==="svg"?Jt.createElementNS(Pu,e):t==="mathml"?Jt.createElementNS(Ru,e):i?Jt.createElement(e,{is:i}):Jt.createElement(e);return e==="select"&&n&&n.multiple!=null&&o.setAttribute("multiple",n.multiple),o},createText:e=>Jt.createTextNode(e),createComment:e=>Jt.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>Jt.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,i,n,o,s){const l=i?i.previousSibling:t.lastChild;if(o&&(o===s||o.nextSibling))for(;t.insertBefore(o.cloneNode(!0),i),!(o===s||!(o=o.nextSibling)););else{Ir.innerHTML=da(n==="svg"?`<svg>${e}</svg>`:n==="mathml"?`<math>${e}</math>`:e);const r=Ir.content;if(n==="svg"||n==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}t.insertBefore(r,i)}return[l?l.nextSibling:t.firstChild,i?i.previousSibling:t.lastChild]}},zu=Symbol("_vtc");function Fu(e,t,i){const n=e[zu];n&&(t=(t?[t,...n]:[...n]).join(" ")),t==null?e.removeAttribute("class"):i?e.setAttribute("class",t):e.className=t}const So=Symbol("_vod"),ua=Symbol("_vsh"),ks={name:"show",beforeMount(e,{value:t},{transition:i}){e[So]=e.style.display==="none"?"":e.style.display,i&&t?i.beforeEnter(e):hn(e,t)},mounted(e,{value:t},{transition:i}){i&&t&&i.enter(e)},updated(e,{value:t,oldValue:i},{transition:n}){!t!=!i&&(n?t?(n.beforeEnter(e),hn(e,!0),n.enter(e)):n.leave(e,()=>{hn(e,!1)}):hn(e,t))},beforeUnmount(e,{value:t}){hn(e,t)}};function hn(e,t){e.style.display=t?e[So]:"none",e[ua]=!t}const Hu=Symbol(""),ju=/(?:^|;)\s*display\s*:/;function Wu(e,t,i){const n=e.style,o=it(i);let s=!1;if(i&&!o){if(t)if(it(t))for(const l of t.split(";")){const r=l.slice(0,l.indexOf(":")).trim();i[r]==null&&gn(n,r,"")}else for(const l in t)i[l]==null&&gn(n,l,"");for(const l in i){l==="display"&&(s=!0);const r=i[l];r!=null?Vu(e,l,!it(t)&&t?t[l]:void 0,r)||gn(n,l,r):gn(n,l,"")}}else if(o){if(t!==i){const l=n[Hu];l&&(i+=";"+l),n.cssText=i,s=ju.test(i)}}else t&&e.removeAttribute("style");So in e&&(e[So]=s?n.display:"",e[ua]&&(n.display="none"))}const Er=/\s*!important$/;function gn(e,t,i){if($e(i))i.forEach(n=>gn(e,t,n));else if(i==null&&(i=""),t.startsWith("--"))e.setProperty(t,i);else{const n=Uu(e,t);Er.test(i)?e.setProperty(yi(n),i.replace(Er,""),"important"):e[n]=i}}const Tr=["Webkit","Moz","ms"],Jo={};function Uu(e,t){const i=Jo[t];if(i)return i;let n=wt(t);if(n!=="filter"&&n in e)return Jo[t]=n;n=To(n);for(let o=0;o<Tr.length;o++){const s=Tr[o]+n;if(s in e)return Jo[t]=s}return t}function Vu(e,t,i,n){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&it(n)&&i===n}const Ar="http://www.w3.org/1999/xlink";function Br(e,t,i,n,o,s=Jc(t)){n&&t.startsWith("xlink:")?i==null?e.removeAttributeNS(Ar,t.slice(6,t.length)):e.setAttributeNS(Ar,t,i):i==null||s&&!fl(i)?e.removeAttribute(t):e.setAttribute(t,s?"":Rt(i)?String(i):i)}function Mr(e,t,i,n,o){if(t==="innerHTML"||t==="textContent"){i!=null&&(e[t]=t==="innerHTML"?da(i):i);return}const s=e.tagName;if(t==="value"&&s!=="PROGRESS"&&!s.includes("-")){const r=s==="OPTION"?e.getAttribute("value")||"":e.value,a=i==null?e.type==="checkbox"?"on":"":String(i);(r!==a||!("_value"in e))&&(e.value=a),i==null&&e.removeAttribute(t),e._value=i;return}let l=!1;if(i===""||i==null){const r=typeof e[t];r==="boolean"?i=fl(i):i==null&&r==="string"?(i="",l=!0):r==="number"&&(i=0,l=!0)}try{e[t]=i}catch{}l&&e.removeAttribute(o||t)}function hi(e,t,i,n){e.addEventListener(t,i,n)}function Ku(e,t,i,n){e.removeEventListener(t,i,n)}const Dr=Symbol("_vei");function qu(e,t,i,n,o=null){const s=e[Dr]||(e[Dr]={}),l=s[t];if(n&&l)l.value=n;else{const[r,a]=Yu(t);if(n){const c=s[t]=Qu(n,o);hi(e,r,c,a)}else l&&(Ku(e,r,l,a),s[t]=void 0)}}const Gu=/(Once|Passive|Capture)$/,Zu=/^on:?(?:Once|Passive|Capture)$/;function Yu(e){let t,i;for(;(i=e.match(Gu))&&!Zu.test(e);)t||(t={}),e=e.slice(0,e.length-i[1].length),t[i[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):yi(e.slice(2)),t]}let Xo=0;const Ju=Promise.resolve(),Xu=()=>Xo||(Ju.then(()=>Xo=0),Xo=Date.now());function Qu(e,t){const i=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=i.attached)return;const o=i.value;if($e(o)){const s=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{s.call(n),n._stopped=!0};const l=o.slice(),r=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&zt(c,t,5,r)}}else zt(o,t,5,[n])};return i.value=e,i.attached=Xu(),i}const Lr=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,ef=(e,t,i,n,o,s)=>{const l=o==="svg";t==="class"?Fu(e,n,l):t==="style"?Wu(e,i,n):$o(t)?Io(t)||qu(e,t,i,n,s):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):tf(e,t,n,l))?(Mr(e,t,n),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&Br(e,t,n,l,s,t!=="value")):e._isVueCE&&(nf(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!it(n)))?Mr(e,wt(t),n,s,t):(t==="true-value"?e._trueValue=n:t==="false-value"&&(e._falseValue=n),Br(e,t,n,l))};function tf(e,t,i,n){if(n)return!!(t==="innerHTML"||t==="textContent"||t in e&&Lr(t)&&Ee(i));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const o=e.tagName;if(o==="IMG"||o==="VIDEO"||o==="CANVAS"||o==="SOURCE")return!1}return Lr(t)&&it(i)?!1:t in e}function nf(e,t){const i=e._def.props;if(!i)return!1;const n=wt(t);return Array.isArray(i)?i.some(o=>wt(o)===n):Object.keys(i).some(o=>wt(o)===n)}const sn=e=>{const t=e.props["onUpdate:modelValue"]||!1;return $e(t)?i=>to(t,i):t};function of(e){e.target.composing=!0}function Or(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const ni=Symbol("_assign");function Pr(e,t,i){return t&&(e=e.trim()),i&&(e=Ao(e)),e}const _o={created(e,{modifiers:{lazy:t,trim:i,number:n}},o){e[ni]=sn(o);const s=n||o.props&&o.props.type==="number";hi(e,t?"change":"input",l=>{l.target.composing||e[ni](Pr(e.value,i,s))}),(i||s)&&hi(e,"change",()=>{e.value=Pr(e.value,i,s)}),t||(hi(e,"compositionstart",of),hi(e,"compositionend",Or),hi(e,"change",Or))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:i,modifiers:{lazy:n,trim:o,number:s}},l){if(e[ni]=sn(l),e.composing)return;const r=(s||e.type==="number")&&!/^0\d/.test(e.value)?Ao(e.value):e.value,a=t??"";if(r===a)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(n&&t===i||o&&e.value.trim()===a)||(e.value=a)}},Jn={deep:!0,created(e,t,i){e[ni]=sn(i),hi(e,"change",()=>{const n=e._modelValue,o=Rn(e),s=e.checked,l=e[ni];if($e(n)){const r=As(n,o),a=r!==-1;if(s&&!a)l(n.concat(o));else if(!s&&a){const c=[...n];c.splice(r,1),l(c)}}else if(ln(n)){const r=new Set(n);s?r.add(o):r.delete(o),l(r)}else l(fa(e,s))})},mounted:Rr,beforeUpdate(e,t,i){e[ni]=sn(i),Rr(e,t,i)}};function Rr(e,{value:t,oldValue:i},n){e._modelValue=t;let o;if($e(t))o=As(t,n.props.value)>-1;else if(ln(t))o=t.has(n.props.value);else{if(t===i)return;o=an(t,fa(e,!0))}e.checked!==o&&(e.checked=o)}const sf={deep:!0,created(e,{value:t,modifiers:{number:i}},n){e._modelValue=t,hi(e,"change",()=>{const o=Array.prototype.filter.call(e.options,s=>s.selected).map(s=>i?Ao(Rn(s)):Rn(s));e[ni](e.multiple?ln(e._modelValue)?new Set(o):o:o[0]),e._assigning=!0,Bl(()=>{e._assigning=!1})}),e[ni]=sn(n)},mounted(e,{value:t}){Nr(e,t)},beforeUpdate(e,{value:t},i){e._modelValue=t,e[ni]=sn(i)},updated(e,{value:t}){e._assigning||Nr(e,t)}};function Nr(e,t){const i=e.multiple,n=$e(t);if(!(i&&!n&&!ln(t))){for(let o=0,s=e.options.length;o<s;o++){const l=e.options[o],r=Rn(l);if(i)if(n){const a=typeof r;a==="string"||a==="number"?l.selected=t.some(c=>String(c)===String(r)):l.selected=As(t,r)>-1}else l.selected=t.has(r);else if(an(Rn(l),t)){e.selectedIndex!==o&&(e.selectedIndex=o);return}}!i&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function Rn(e){return"_value"in e?e._value:e.value}function fa(e,t){const i=t?"_trueValue":"_falseValue";return i in e?e[i]:t}const rf=["ctrl","shift","alt","meta"],lf={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>rf.some(i=>e[`${i}Key`]&&!t.includes(i))},Lt=(e,t)=>{if(!e)return e;const i=e._withMods||(e._withMods={}),n=t.join(".");return i[n]||(i[n]=((o,...s)=>{for(let l=0;l<t.length;l++){const r=lf[t[l]];if(r&&r(o,t))return}return e(o,...s)}))},af={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},cf=(e,t)=>{const i=e._withKeys||(e._withKeys={}),n=t.join(".");return i[n]||(i[n]=(o=>{if(!("key"in o))return;const s=yi(o.key);if(t.some(l=>l===s||af[l]===s))return e(o)}))},df=dt({patchProp:ef},Nu);let zr;function uf(){return zr||(zr=vu(df))}const Ks=((...e)=>{const t=uf().createApp(...e),{mount:i}=t;return t.mount=n=>{const o=pf(n);if(!o)return;const s=t._component;!Ee(s)&&!s.render&&!s.template&&(s.template=o.innerHTML),o.nodeType===1&&(o.textContent="");const l=i(o,!1,ff(o));return o instanceof Element&&(o.removeAttribute("v-cloak"),o.setAttribute("data-v-app","")),l},t});function ff(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function pf(e){return it(e)?document.querySelector(e):e}const hf="slidev-config.json",rn={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1},mi=Do({...rn});function mf(e){if(!e||typeof e!="object")return{...rn};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():rn.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes}}function Ai(e){if(!e||typeof e!="object")return{...mi};const t=e;return t.enableWebServeJump!==void 0&&(mi.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(mi.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(mi.normalizeHeadingSizes=!!t.normalizeHeadingSizes),{...mi}}function zo(){return{...mi}}function pa(e,t,i){const n=(e||rn.webServeUrl).trim(),o=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,s=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(o);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",t),i!=null&&i.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",s),l.toString()}catch{const l=i!=null&&i.focus?"&focus=1":"";return`${o.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${l}&r=${s}`}}const Si={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1};function gf(e){var i,n,o,s,l,r;const t=zo();return e?{theme:((i=e[$n])==null?void 0:i.trim())||Si.theme,aspectRatio:((n=e[In])==null?void 0:n.trim())||Si.aspectRatio,highlighter:((o=e[il])==null?void 0:o.trim())||Si.highlighter,defaultTransition:((s=e[En])==null?void 0:s.trim())||Si.defaultTransition,colorSchema:((l=e[nl])==null?void 0:l.trim())||Si.colorSchema,spacing:((r=e[as])==null?void 0:r.trim())||Si.spacing,normalizeHeadingSizes:t.normalizeHeadingSizes}:{...Si,normalizeHeadingSizes:t.normalizeHeadingSizes}}function Co(e){var i,n,o,s,l;const t=(i=e.ial)==null?void 0:i[Ii];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((n=e.markdown)==null?void 0:n.trim())==="---"||((o=e.markdown)==null?void 0:o.trim())==="***"||e.type==="b"&&(((s=e.markdown)==null?void 0:s.trim())==="---"||((l=e.content)==null?void 0:l.trim())==="---"))}function Fr(e){const t={};let i="";if(!e)return{frontmatter:t,notes:i};e[fe]&&(t.layout=e[fe].trim()),e[tt]&&(t.transition=e[tt].trim()),e[je]&&(t.background=e[je].trim()),e[Dt]&&(t.image=e[Dt].trim()),e[Vi]&&(t.class=e[Vi].trim()),e[vn]&&(t.spacing=e[vn].trim()),e[yt]&&(t.layoutRatio=e[yt].trim()),e[Ki]&&(t.mask=e[Ki].trim()),e[qi]&&(t.maskRatio=e[qi].trim()),e[Gi]&&(t.maskStyle=e[Gi].trim()),e[Zi]&&(t.maskInitial=e[Zi].trim()),e[Ui]&&(i=e[Ui].trim());for(const[n,o]of Object.entries(e))if(n.startsWith("custom-slidev-")&&![fe,yt,Ki,qi,Gi,Zi,tt,je,Dt,Vi,vn,Ui,Ii].includes(n)){const s=n.replace(/^custom-slidev-/,"");try{t[s]=JSON.parse(o)}catch{t[s]=o}}return{frontmatter:t,notes:i}}function vf(e){const t={};if(!e)return t;const i=e[nt]??e["slidev-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(t.isNote=!0);const n=e[qe]??e["slidev-role"],o=e[je]??e["slidev-background"];(n===ol||o==="true"||o==="1")&&(t.isBackground=!0);const s=e[fe]??e["slidev-layout"];s===ho||s===mo?t.imageLayout=s:(n===ho||n===mo)&&(t.imageLayout=n);const l=e[Ze]??e["custom-slidev-clicks"]??e["slidev-click"]??e["slidev-clicks"];if(l!=null&&(t.clicks=l.trim()),e[Kt])try{const r=JSON.parse(e[Kt]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[Kt].trim()}}return e[Pi]&&(t.shikiLines=e[Pi].trim()),e[Tn]&&(t.maxHeight=e[Tn].trim()),e[Ce]&&(t.slot=e[Ce].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function bi(e,t){const i=(e||t||"").trim();if(!i)return null;const n=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const o=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(o)return o[1].trim();const s=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(s)?s:null}function Sn(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const i=t[0],n=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return e;const o=n[1].length,s=n[2].trim(),l=i.length-n[2].length;if(t.length===1)return s;const r=[s];for(let a=1;a<t.length;a++){const c=t[a];if(!c.trim()){r.push("");continue}const d=c.match(/^(\s*)/),p=d?d[1].length:0;p>=l?r.push(c.slice(l)):p>o?r.push(c.slice(p)):r.push(c)}return r.join(`
`)}function Ri(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const i=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function Qo(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const i=e.trim();if(!i)return`repeat(${t}, 1fr)`;if(i.includes(":")){const o=i.split(":").map(s=>parseFloat(s.trim())).filter(s=>!isNaN(s)&&s>0);if(o.length>=2)return o.map(s=>`${s}fr`).join(" ")}const n=i.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${t}, 1fr)`}function _n(e){if(!e)return[];if(ot(e)&&Gt(e)&&!ci(e)){const n=cn(e),o=[];for(const s of n)o.push(..._n(s));return o}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const l=e.children.filter(Ri);if(l.length>0)return l}const o=(e.markdown||e.content||"").trim().split(/\r?\n/),s=[];for(let l=0;l<o.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(o[l])&&s.push(l);if(s.length>=2){const l=[];for(let r=0;r<s.length;r++){const a=s[r],c=r+1<s.length?s[r+1]:o.length,d=o.slice(a,c).join(`
`);l.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:d,content:d,ial:{...e.ial||{}}})}return l}}return Ri(e)?[e]:[]}function qs(e){var o;if(!e||!ot(e)||!Gt(e)||ci(e))return null;const t=cn(e);if(t.length===0)return null;if(t.length===1&&ot(t[0])&&Gt(t[0])){const s=qs(t[0]);return s?{items:s.items,nestedSuperBlocks:[t[0],...s.nestedSuperBlocks]}:null}const i=[];for(const s of t)if(ot(s)){i.push(s);const l=((o=s.children)==null?void 0:o.filter(ot))||[];i.push(...l)}const n=t.map(_n);if(n.length>=2&&n.every(s=>s.length>0)){const s=n.flat();if(s.length>=2&&s.length<=6)return{items:s,nestedSuperBlocks:i}}if(t.length===2){const s=_n(t[0]),l=_n(t[1]);if(s.length+l.length>=2&&s.length+l.length<=6&&(s.length>0||l.length>0))return{items:[...s,...l],nestedSuperBlocks:i}}return null}function bf(e){if(!e||!ot(e)||!Gt(e)||ci(e))return null;const t=qs(e);if(!t)return null;const{items:i,nestedSuperBlocks:n}=t;if(i.length<2||i.length>6)return null;const o=Gs(e)||void 0,s=i.length;return{superBlockNode:e,nestedSuperBlocks:n,count:s,layout:"cols-header",items:i,slots:i.map((l,r)=>`col-${r+1}`),ratio:o}}function ha(e){if(!e||!ot(e)||!Gt(e)||ci(e))return null;const t=cn(e);if(t.length===0)return null;const i=[];for(const n of t){const o=_n(n);if(o.length===0)return null;i.push(...o)}return i}function yf(e){if(!e||!ot(e)||!Gt(e)||ci(e))return null;const t=ha(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function kf(e){if(!e||!ot(e)||!Gt(e)||ci(e))return null;const t=qs(e);if(t&&t.items.length===4)return t.items;const i=ha(e);if(i&&i.length===4)return i;const n=cn(e);return n.length===4?n:null}function wf(e,t){if(!e||e.length===0)return null;const i=[];function n(r,a){if(ot(r)){const c=kf(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,a)}for(let r=0;r<e.length;r++)n(e[r],r);if(i.length===0)return null;let o=null;t&&(o=i.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const a=c=>c.id===t?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),o||(o=i[0]);const l=e.slice(0,o.topLevelIndex).slice().reverse().find(r=>ma(r));return{superBlockNode:o.sbNode,items:o.items,headerNode:l}}function xf(e,t,i){var d,p,v,u,h;const n=[],o=[],s=(i==null?void 0:i.tracked)||[],l=[];let r={pageTargetId:e,blocks:[]};l.push(r);for(let f=0;f<t.length;f++){const b=t[f];if(Co(b)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=b.id,r.blocks.push(b);continue}r={pageTargetId:b.id,blocks:[b]},l.push(r)}else r.blocks.push(b)}function a(f){const b=[];for(const k of f)ot(k)&&b.push(k),k.children&&k.children.length>0&&b.push(...a(k.children));return b}function c(f,b,k){const x={blockId:f,attrs:b,previousAttrs:k};n.push(x),i!=null&&i.onTagChange&&i.onTagChange(x)}for(const f of l){const b=f.pageTargetId,k=t.find(E=>E.id===b),x=s.find(E=>E.pageTargetId===b);if(f.blocks.some(E=>{var w,P;return!!(ci(E)||ws(E)&&(((w=E.ial)==null?void 0:w[fe])==="image-left"||((P=E.ial)==null?void 0:P[fe])==="image-right"))})){if(x){const E=x.headerId;if(E){c(E,{[Ce]:""});const w=t.find(P=>P.id===E);w!=null&&w.ial&&(w.ial[Ce]="")}for(const w of x.itemIds){c(w,{[Ce]:""});const P=t.find(R=>R.id===w);P!=null&&P.ial&&(P.ial[Ce]="")}}continue}let A=null,M=-1;for(let E=0;E<f.blocks.length;E++){const w=f.blocks[E],P=ot(w)?[w,...a(w.children||[])]:w.children?a(w.children):[];for(const R of P){const z=bf(R);if(z){A=z,M=E;break}}if(A)break}if(A){const{superBlockNode:E,layout:w,items:P,slots:R}=A,G=f.blocks.slice(0,M).find(T=>ma(T)),S=G==null?void 0:G.id,L=((d=k==null?void 0:k.ial)==null?void 0:d[fe])||"",y=L==="clover",B=y?"clover":w;if(L!==B&&(c(b,{[fe]:B},{[fe]:L}),k&&(k.ial||(k.ial={}),k.ial[fe]=B)),G){const T=((p=G.ial)==null?void 0:p[Ce])||"";T!=="header"&&(c(G.id,{[Ce]:"header"},{[Ce]:T}),G.ial||(G.ial={}),G.ial[Ce]="header")}if(x!=null&&x.headerId&&x.headerId!==S){c(x.headerId,{[Ce]:""});const T=t.find(D=>D.id===x.headerId);T&&(T.ial||(T.ial={}),T.ial[Ce]="")}const F=[];for(let T=0;T<P.length;T++){const D=P[T],N=R[T];F.push(D.id);const X=((v=D.ial)==null?void 0:v[Ce])||"";if(X!==N&&(c(D.id,{[Ce]:N},{[Ce]:X}),D.ial||(D.ial={}),D.ial[Ce]=N),D.children&&D.children.length>0)for(const Z of D.children)Z.ial||(Z.ial={}),Z.ial[Ce]!==N&&(Z.ial[Ce]=N)}if(x!=null&&x.itemIds){for(const T of x.itemIds)if(!F.includes(T)){c(T,{[Ce]:""});const D=t.find(N=>N.id===T);D&&(D.ial||(D.ial={}),D.ial[Ce]="")}}o.push({superBlockId:E.id,nestedSuperBlockIds:(u=A.nestedSuperBlocks)==null?void 0:u.map(T=>T.id),pageTargetId:b,headerId:S,itemIds:F,layout:y?"clover":w})}else{let E=!1;const w=[];for(const z of f.blocks){const G=ot(z)?[z,...a(z.children||[])]:z.children?a(z.children):[];for(const S of G){const L=yf(S);if(L){E=!0;for(const y of L.items)w.push(y.id)}}}const P=((h=k==null?void 0:k.ial)==null?void 0:h[fe])||"",R=An(P);if(x||E&&R){c(b,{[fe]:""},{[fe]:P}),k&&(k.ial||(k.ial={}),k.ial[fe]="");const z=x==null?void 0:x.headerId;if(z){c(z,{[Ce]:""});const S=t.find(L=>L.id===z);S&&(S.ial||(S.ial={}),S.ial[Ce]="")}const G=new Set([...(x==null?void 0:x.itemIds)||[],...w]);for(const S of G){c(S,{[Ce]:""});const L=t.find(y=>y.id===S);L&&(L.ial||(L.ial={}),L.ial[Ce]="")}}}}return{changes:n,newTracked:o}}function ot(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function Gt(e){if(!ot(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const n=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(e.children&&e.children.length>0){for(const n of e.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const o=(n.content||n.markdown||"").trim().toLowerCase();if(o==="col"||o==="h")return!0;if(o==="row"||o==="v")return!1}}const i=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function ws(e){return!e||Ri(e)||ot(e)||!bi(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function Gs(e){var v;if(!e||!ot(e)||!Gt(e))return null;const t=cn(e);if(!t||t.length<2)return null;const i=[];let n=!1;for(const u of t){const h=(((v=u.ial)==null?void 0:v.style)||u.style||"").trim();let f=null;if(h){const b=h.match(/calc\(\s*([\d.]+)%/i);if(b)f=parseFloat(b[1]);else{const k=h.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);k&&(f=parseFloat(k[1]))}}f!==null&&!isNaN(f)&&f>0?(i.push(f),n=!0):i.push(null)}if(!n)return null;const o=t.length,s=i.reduce((u,h)=>u+(h||0),0),l=i.filter(u=>u===null).length,r=Math.max(0,100-s),a=l>0?r/l:100/o,c=i.map(u=>u!==null?u:a),d=c.reduce((u,h)=>u+h,0);if(d<=0)return null;const p=c.map(u=>u/d*100);if(p.length===2){const[u]=p;if(u>=48&&u<=52)return"1:1";if(u>=31&&u<=35)return"1:2";if(u>=65&&u<=69)return"2:1";if(u>=28&&u<=32)return"3:7";if(u>=68&&u<=72)return"7:3";if(u>=38&&u<=42)return"4:6";if(u>=58&&u<=62)return"6:4";if(u>=23&&u<=27)return"1:3";if(u>=73&&u<=77)return"3:1";const h=Math.round(u),f=100-h;return`${h}:${f}`}if(p.length===3){const[u,h,f]=p;if(u>=31&&u<=35&&h>=31&&h<=35&&f>=31&&f<=35)return"1:1:1";if(u>=23&&u<=27&&h>=48&&h<=52&&f>=23&&f<=27)return"1:2:1";if(u>=48&&u<=52&&h>=23&&h<=27&&f>=23&&f<=27)return"2:1:1";if(u>=23&&u<=27&&h>=23&&h<=27&&f>=48&&f<=52)return"1:1:2";if(u>=18&&u<=22&&h>=58&&h<=62&&f>=18&&f<=22)return"1:3:1";const b=Math.round(u),k=Math.round(h),x=100-b-k;return`${b}:${k}:${x}`}return p.map(u=>Math.round(u)).join(":")}function ci(e){if(!e||!ot(e)||!Gt(e))return null;const t=(e.children||[]).filter(s=>{const l=s.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const i=ws(t[0]),n=ws(t[t.length-1]),o=Gs(e)||void 0;if(i&&!n){const s=bi(t[0].markdown,t[0].content);if(s)return{imageNode:t[0],imageUrl:s,layout:ho,contentNodes:t.slice(1),ratio:o}}if(!i&&n){const s=bi(t[t.length-1].markdown,t[t.length-1].content);if(s)return{imageNode:t[t.length-1],imageUrl:s,layout:mo,contentNodes:t.slice(0,t.length-1),ratio:o}}return null}function Sf(e,t){const i=[];function n(o){for(const s of o){const l=ci(s);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const d=r.ial[fe];if(d!==a){const v={blockId:r.id,layout:a,previousLayout:d,ratio:c};r.ial[fe]=a,i.push(v),t&&t(v)}}s.children&&s.children.length>0&&n(s.children)}}return n(e),i}function cn(e){return(e.children||[]).filter(t=>{const i=t.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const n=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function ma(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const i=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function _i(e,t,i){let n="",o=0;const s=/<div\b([^>]*)>/gi;for(;o<e.length;){s.lastIndex=o;let l,r=!1,a=-1,c=0;for(;(l=s.exec(e))!==null;){const k=l[1].match(/\bclass=["']([^"']*)["']/i);if(k){const x=k[1];if(typeof t=="string"?x.split(/\s+/).includes(t):t.test(x)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){n+=e.slice(o);break}n+=e.slice(o,a);const d=a+c;let p=1,v=-1,u=-1;const h=/<\/?div\b[^>]*>/gi;h.lastIndex=d;let f;for(;(f=h.exec(e))!==null;)if(f[0].startsWith("</")){if(p--,p===0){v=f.index,u=f.index+f[0].length;break}}else p++;if(v!==-1&&u!==-1){const b=e.slice(d,v);n+=i(b),o=u}else n+=e.slice(a,d),o=d}return n}function _f(e){const t=[];let i="",n=0;const o=/<div\b([^>]*)>/gi;for(;n<e.length;){o.lastIndex=n;let s,l=!1,r=-1,a=0;for(;(s=o.exec(e))!==null;){const f=s[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(f)){l=!0,r=s.index,a=s[0].length;break}}if(!l){i+=e.slice(n);break}i+=e.slice(n,r);const c=r+a;let d=1,p=-1,v=-1;const u=/<\/?div\b[^>]*>/gi;u.lastIndex=c;let h;for(;(h=u.exec(e))!==null;)if(h[0].startsWith("</")){if(d--,d===0){p=h.index,v=h.index+h[0].length;break}}else d++;if(p!==-1&&v!==-1){const f=e.slice(r,v),b=`__VUE_DIV_TOKEN_${t.length}__`;t.push(f),i+=b,n=v}else i+=e.slice(r,c),n=c}return{text:i,tokens:t}}function Cf(e){const t=[];let i=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});const n=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),a});const{text:o,tokens:s}=_f(i);i=o;const l=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=_i(i,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),p=c[3].trim();return`**${d}:**
\`\`\`yaml
${p}
\`\`\``}).join(`

`)+`
`:r}),i=_i(i,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),i=_i(i,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let p="-";return d.includes("warn")?p="- ⚠️":d.includes("bad")?p="- ❌":d.includes("ok")&&(p="- ✅"),`${p} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=_i(i,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const v=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${v}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=_i(i,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=_i(i,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=_i(i,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((p,v)=>Math.max(p,v.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,d,p)=>{const v=p.trim();return v.includes("<")||v.includes(`
`)?r:`[${v}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,l[r]);for(let r=0;r<s.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,s[r]);for(let r=0;r<n.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,n[r]);for(let r=0;r<t.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,t[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function ga(e){if(!e||typeof e!="string")return"";const t=[];let i=e.replace(/`([^`]+)`/g,n=>(t.push(n),`%%INLINE_CODE_${t.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(n,o)=>t[parseInt(o,10)]||""),i}function $f(e){const t=Object.entries(e).filter(([n,o])=>o!=null&&o!=="");return t.length===0?"":`---
${t.map(([n,o])=>typeof o=="string"?o.includes(":")||o.includes(`
`)||o.includes("#")?`${n}: "${o.replace(/"/g,'\\"')}"`:`${n}: ${o}`:`${n}: ${JSON.stringify(o)}`).join(`
`)}
---`}function If(e,t){if(!t||!e.startsWith("```"))return e;const i=e.indexOf(`
`);if(i===-1)return e;const n=e.slice(0,i).trim(),o=e.slice(i);return n.includes("{")?e:`${n} {${t}}${o}`}function va(e,t){if(t==null)return e;const i=t.trim();return i===""||i==="+1"?`<v-click>

${e}

</v-click>`:i==="hide"?`<v-click hide>

${e}

</v-click>`:`<v-click at="${i}">

${e}

</v-click>`}function Ef(e){if(!e||!e.preset)return null;const t=e.preset.toLowerCase().trim();if(!t||t==="none")return null;let i={opacity:0},n={opacity:1};switch(t){case"slide-up":i={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},n={opacity:1};break}e.initial&&typeof e.initial=="object"&&(i={...i,...e.initial}),e.enter&&typeof e.enter=="object"&&(n={...n,...e.enter});const o={...n.transition||{}};return typeof e.duration=="number"&&e.duration>0&&(o.duration=e.duration),typeof e.delay=="number"&&e.delay>0&&(o.delay=e.delay),Object.keys(o).length>0&&(n.transition=o),{initial:i,enter:n}}function Xn(e,t,i,n){const o=t!=null&&t.trim()!=="",s=Ef(i),l=n==null?void 0:n.trim(),r=l!==void 0&&l!=="",a=r?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!s)return r?`<div${a}>

${e}

</div>`:e;if(o&&!s){if(r){const h=t.trim();let f="v-click";return h==="hide"?f="v-click.hide":h!==""&&h!=="+1"&&(f=`v-click="${h}"`),`<div ${f}${a}>

${e}

</div>`}return va(e,t)}const c=JSON.stringify(s.initial).replace(/"/g,"'"),d=JSON.stringify(s.enter).replace(/"/g,"'"),p=`v-motion :initial="${c}" :enter="${d}"`;if(!o)return`<div ${p}${a}>

${e}

</div>`;const v=t.trim();let u="v-click";return v==="hide"?u="v-click.hide":v!==""&&v!=="+1"&&(u=`v-click="${v}"`),`<div ${u} ${p}${a}>

${e}

</div>`}function ba(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let o=t.split(/\r?\n/).map(s=>s.trim().replace(/^>\s*/,"")).join(`
`).trim();return o=o.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),o=o.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),o=o.replace(/^[-*+]\s+/,""),o=o.replace(/^\d+\.\s+/,""),o.trim()}function Tf(e){var n;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const i=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:e.type==="h"?(n=e.ial)!=null&&n.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function ya(e,t=2){const i=Math.max(2,t);if(!e||e.length===0)return Array.from({length:i},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,d=Array.from({length:i},()=>[]),p=Math.min(i,c.length),v=Math.floor(c.length/p),u=c.length%p;let h=0;for(let f=0;f<p;f++){const b=v+(f<u?1:0);d[f]=c.slice(h,h+b),h+=b}return d}const n=c=>{const d=(c.slot||"").trim();if(!d)return null;if(d==="left")return 1;if(d==="center")return 2;if(d==="right")return i===2?2:i;const p=d.match(/^col-(\d+)$/i);if(p){const v=parseInt(p[1],10);if(v>=1&&v<=i)return v}return null},o=e.map(n);if(o.some(c=>c!==null)){if(o.some(u=>u!==null&&u>=2)){const u=Array.from({length:i},()=>[]);let h=1;for(const f of e){const b=n(f);b!==null&&(h=b),u[h-1].push(f)}return u}const d=e.filter(u=>n(u)===1),p=e.filter(u=>n(u)===null),v=i-1;if(p.length>=v){const u=Math.floor(p.length/v),h=p.length%v,f=[d];let b=0;for(let k=0;k<v;k++){const x=u+(k<h?1:0);f.push(p.slice(b,b+x)),b+=x}return f}else if(p.length>0){const u=[d];for(let h=0;h<v;h++)u.push(h<p.length?[p[h]]:[]);return u}else return[d,...Array.from({length:v},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const d=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(d)},r=e.map((c,d)=>l(c)?d:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let d=0;d<i;d++){const p=r[d],v=d+1<i?r[d+1]:e.length;c[d]=e.slice(p,v)}return c}if(e.length>=i){const c=Array.from({length:i},()=>[]);let d=0;for(let p=0;p<i;p++){const v=i-p,u=e.length-d,h=Math.ceil(u/v);c[p]=e.slice(d,d+h),d+=h}return c}if(e.length>1&&e.length<i){const c=Array.from({length:i},()=>[]);for(let d=0;d<e.length;d++)c[d]=[e[d]];return c}if(e.length===1){const c=e[0],d=(c.rawMarkdown||c.content||"").trim(),p=d.split(/\r?\n/),v=[];for(let f=0;f<p.length;f++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(p[f])&&v.push(f);if(v.length>=i){const f=Array.from({length:i},()=>[]);let b=0;for(let k=0;k<i;k++){const x=i-k,_=v.length-b,A=Math.ceil(_/x),M=v[b],E=b+A<v.length?v[b+A]:p.length,w=p.slice(M,E).join(`
`);f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:w,content:w}],b+=A}return f}const u=d.match(/<li[\s\S]*?<\/li>/gi);if(u&&u.length>=i){const f=Array.from({length:i},()=>[]);let b=0;for(let k=0;k<i;k++){const x=i-k,_=u.length-b,A=Math.ceil(_/x),M=`<ul>
${u.slice(b,b+A).join(`
`)}
</ul>`;f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:M,content:M}],b+=A}return f}const h=d.split(/\r?\n\s*\r?\n/).filter(f=>f.trim()!=="");if(h.length>=i){const f=Array.from({length:i},()=>[]);let b=0;for(let k=0;k<i;k++){const x=i-k,_=h.length-b,A=Math.ceil(_/x),M=h.slice(b,b+A).join(`

`);f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:M,content:M}],b+=A}return f}}const a=Array.from({length:i},()=>[]);return a[0]=e,a}function Hr(e,t,i,n){var d;const o=gf(t),s=[],l=Fr(t);let r={pageIndex:1,startBlockId:e,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};r.frontmatter.background&&(r.frontmatter.background=Et(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Et(r.frontmatter.image,n)),s.push(r);let a=[];for(const p of i){if(Co(p)){a=[];const u=Fr(p.ial);if(s.length===1&&r.blocks.length===0){r.startBlockId=p.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(p.id)||r.allBlockIds.push(p.id),u.frontmatter.layout&&(r.frontmatter.layout=u.frontmatter.layout),Object.assign(r.frontmatter,u.frontmatter),!u.frontmatter.image&&l.frontmatter.image&&(r.frontmatter.image=l.frontmatter.image),!u.frontmatter.background&&l.frontmatter.background&&(r.frontmatter.background=l.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=Et(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Et(r.frontmatter.image,n));continue}r={pageIndex:s.length+1,startBlockId:p.id,frontmatter:{layout:u.frontmatter.layout||"default",...u.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[p.id]},r.frontmatter.background&&(r.frontmatter.background=Et(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Et(r.frontmatter.image,n)),s.push(r);continue}const v=(u,h)=>{var F,T,D,N;if(r.allBlockIds||(r.allBlockIds=[]),u.id&&!r.allBlockIds.includes(u.id)&&r.allBlockIds.push(u.id),u.children&&u.children.length>0){const X=Z=>{for(const U of Z)U.id&&!r.allBlockIds.includes(U.id)&&r.allBlockIds.push(U.id),U.children&&U.children.length>0&&X(U.children)};X(u.children)}let f=zc(u),b=u.ial?{...u.ial}:{};const k=f.match(/\{:\s*([^}]+)\s*\}\s*$/);k&&(b={...Fc(k[0]),...b},f=f.slice(0,k.index).trim()),u.type!=="c"&&!f.startsWith("```")&&(f=ga(f));let x=f.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(x)||x==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(x)&&/\r?\n\}\}\}$/.test(x)&&(f=x.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),x=f.trim());const _=vf(b);if(f=Hc(f,n),f=Nc(f,n==null?void 0:n.refContentMap),u.children&&u.children.length>0){const X=["custom-slidev-autoplay","custom-slidev-loop","custom-slidev-muted","custom-slidev-controls"],Z=U=>{for(const ie of U){if(ie.ial)for(const[se,le]of Object.entries(ie.ial))X.includes(se)&&!b[se]&&(b[se]=le);ie.children&&ie.children.length>0&&Z(ie.children)}};Z(u.children)}const A=u.type==="video"||u.type==="NodeVideo"||/<video\b/i.test(f);if(A){const X=b["custom-slidev-autoplay"]==="true",Z=b["custom-slidev-loop"]==="true",U=b["custom-slidev-muted"]==="true"||X,ie=b["custom-slidev-controls"]==="false";f=f.replace(/<video\b([^>]*)>/gi,(se,le)=>{let ve=le;return ie?ve=ve.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(ve)||(ve+=" controls"),X&&!/autoplay/i.test(ve)?ve+=" autoplay playsinline":!X&&b["custom-slidev-autoplay"]==="false"&&(ve=ve.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),Z&&!/loop/i.test(ve)?ve+=" loop":!Z&&b["custom-slidev-loop"]==="false"&&(ve=ve.replace(/\bloop\b/gi,"").trim()),U&&!/muted/i.test(ve)?ve+=" muted":!U&&b["custom-slidev-muted"]==="false"&&(ve=ve.replace(/\bmuted\b/gi,"").trim()),`<video ${ve.trim()}>`})}if(_.isBackground){const X=bi(f,u.content);if(X){r.frontmatter.background=Et(X,n);return}}const M=ci(u);if(M){r.frontmatter.layout=M.layout,r.frontmatter.image=Et(M.imageUrl,n),!r.frontmatter.layoutRatio&&M.ratio&&(r.frontmatter.layoutRatio=M.ratio);for(const X of M.contentNodes)v(X);return}if(_.imageLayout==="image-left"||_.imageLayout==="image-right"){const X=bi(f,u.content);if(X){r.frontmatter.layout=_.imageLayout,r.frontmatter.image=Et(X,n),!r.frontmatter.layoutRatio&&((F=u.ial)!=null&&F[yt])&&(r.frontmatter.layoutRatio=u.ial[yt]);return}}if(ot(u)&&u.children&&u.children.length>0){for(const X of u.children)v(X);return}const E=!!(_.slot||h!=null&&h.defaultSlot||r.frontmatter.layout==="clover"||An(r.frontmatter.layout)||r.frontmatter.layout==="two-cols");if((u.type==="l"||u.type==="NodeList"||u.type==="list")&&u.children&&u.children.length>0&&(u.children.some(X=>{var Z,U;return((Z=X.ial)==null?void 0:Z[Ce])||((U=X.ial)==null?void 0:U[Ze])})||_.slot||_.clicks||E)){for(const X of u.children)_.slot&&(!X.ial||!X.ial[Ce])&&(X.ial||(X.ial={}),X.ial[Ce]=_.slot),v(X,{...h,parentClicks:_.clicks||(h==null?void 0:h.parentClicks),defaultSlot:_.slot||(h==null?void 0:h.defaultSlot)});return}const w=!!(u.children&&u.children.length>=2)||!!_.clicks||!!((T=u.children)!=null&&T.some(X=>{var Z;return(Z=X.ial)==null?void 0:Z[Ze]}))||!u.markdown&&!!(u.children&&u.children.length>0);if(Ri(u)&&u.children&&u.children.length>0&&(E||_.clicks||u.children.some(X=>{var Z;return(Z=X.ial)==null?void 0:Z[Ze]}))&&w){const X=!!(u.children&&u.children.length>=2),Z=u.children.find(ye=>!!(ye.markdown||ye.content||"").trim())||u.children[0],U=((D=Z==null?void 0:Z.ial)==null?void 0:D[Ze])||((N=Z==null?void 0:Z.ial)==null?void 0:N["custom-slidev-click"]),ie=!!(!_.clicks&&X&&U),se=_.clicks||(ie?U:void 0)||(h==null?void 0:h.parentClicks),le=u.id||(h==null?void 0:h.parentContainerId),ve=_.slot||(h==null?void 0:h.defaultSlot);let Te=!0;for(const ye of u.children){ve&&(!ye.ial||!ye.ial[Ce])&&(ye.ial||(ye.ial={}),ye.ial[Ce]=ve);const ae=!!(ye.markdown||ye.content||"").trim(),Y=Te&&ae;Y&&(ye.markdown&&(ye.markdown=Sn(ye.markdown)),ye.content&&(ye.content=Sn(ye.content)),Te=!1);let ce=ye;Y&&se&&X&&(ce={...ye,ial:{...ye.ial||{}}},delete ce.ial[Ze],delete ce.ial["custom-slidev-click"]),v(ce,{parentClicks:se,parentContainerId:le,defaultSlot:ve})}return}if(_.isNote){const X=ba(f);X&&(r.notes?r.notes+=`

`+X:r.notes=X),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:u.id,type:u.type,content:X||u.content||"",rawMarkdown:f,isNote:!0,attributes:u.ial});return}_.shikiLines&&(f=If(f,_.shikiLines)),x=f.trim();const P=(u.content||"").trim();if(x==="::right::"||P==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(x)||x.startsWith("::right::")){r.blocks.push({id:u.id,type:u.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:u.ial});return}const z=Tf(u);let G=_.slot,S=_.clicks,L=_.motion,y={...u.ial||{}};if(z!==null){for(;a.length>0&&a[a.length-1].level>=z;)a.pop();const X=a.length>0?a[a.length-1]:void 0;!G&&(X!=null&&X.slot)&&(G=X.slot),!S&&(X!=null&&X.clicks)&&!(h!=null&&h.parentContainerId)&&(S=X.clicks),!L&&(X!=null&&X.motion)&&(L=X.motion);const Z={...(X==null?void 0:X.customAttrs)||{}};if(u.ial)for(const[U,ie]of Object.entries(u.ial))U.startsWith("custom-slidev-")&&!U.startsWith("custom-slidev-slide")&&(Z[U]=ie);h!=null&&h.parentContainerId||a.push({level:z,slot:G,clicks:S,motion:L,customAttrs:Z})}else{const X=a.length>0?a[a.length-1]:void 0;X&&(!G&&X.slot&&X.slot!=="header"&&(G=X.slot),!S&&X.clicks&&!(h!=null&&h.parentContainerId)&&(S=X.clicks),!L&&X.motion&&(L=X.motion),X.customAttrs&&(y={...X.customAttrs,...y}))}!G&&r.blocks.some(X=>X.slot==="slot-divider-right")&&(G="right"),!G&&(h!=null&&h.defaultSlot)&&(G=h.defaultSlot),G&&(y[Ce]=G),S&&!y[Ze]&&(y[Ze]=S),L&&!y[Kt]&&(y[Kt]=JSON.stringify(L)),(A||b["custom-slidev-autoplay"]||b["custom-slidev-muted"])&&(b["custom-slidev-autoplay"]&&(y["custom-slidev-autoplay"]=b["custom-slidev-autoplay"],b["custom-slidev-autoplay"]==="true"&&!b["custom-slidev-muted"]&&(y["custom-slidev-muted"]="true")),b["custom-slidev-loop"]&&(y["custom-slidev-loop"]=b["custom-slidev-loop"]),b["custom-slidev-muted"]&&(y["custom-slidev-muted"]=b["custom-slidev-muted"]),b["custom-slidev-controls"]&&(y["custom-slidev-controls"]=b["custom-slidev-controls"]));const B={id:u.id,type:u.type,content:u.content||"",rawMarkdown:f,clicks:S,parentClicks:h==null?void 0:h.parentClicks,parentContainerId:h==null?void 0:h.parentContainerId,motion:L,shikiLines:_.shikiLines,slot:G,attributes:y,rawNode:u};r.blocks.push(B)};v(p)}for(let p=0;p<s.length;p++){const v=s[p],u=[],h={...v.frontmatter};p===0&&(h.theme=o.theme,h.aspectRatio=o.aspectRatio,h.highlighter=o.highlighter,h.transition=v.frontmatter.transition||o.defaultTransition);const f=$f(h);f&&u.push(f);const b=v.blocks.filter(M=>M.slot!=="slot-divider-right"),k=M=>M.filter(E=>!!(E.rawMarkdown||E.content||"").trim()).map(E=>{var w;return Xn(E.rawMarkdown,E.clicks,E.motion,(w=E.attributes)==null?void 0:w.style)}).join(`

`),x=M=>{const E=M.filter(z=>!!(z.rawMarkdown||z.content||"").trim());if(E.length===0)return;const w=E[0],P=(w.rawMarkdown||w.content||"").trim();(Ri(w)||/^(?:[-*+]|\d+\.)\s+/.test(P))&&(w.rawMarkdown=Sn(w.rawMarkdown||w.content||""),w.content=w.rawMarkdown)},_=M=>{var z,G;if(M.length===0)return"";x(M);const E=(z=M.find(S=>S.parentClicks))==null?void 0:z.parentClicks;if(!E)return M.filter(S=>!!(S.rawMarkdown||S.content||"").trim()).map(S=>{var L;return Xn(S.rawMarkdown,S.clicks,S.motion,(L=S.attributes)==null?void 0:L.style)}).join(`

`);const w=[];let P=[];const R=()=>{if(P.length===0)return;const S=P.map(L=>(L.rawMarkdown||L.content||"").trim()).filter(Boolean).join(`

`);S&&w.push(va(S,E)),P=[]};for(const S of M){if(!(S.rawMarkdown||S.content||"").trim())continue;!!(S.clicks&&S.clicks.trim()!=="")?(R(),w.push(Xn(S.rawMarkdown,S.clicks,S.motion,(G=S.attributes)==null?void 0:G.style))):P.push(S)}return R(),w.join(`

`)},A=v.frontmatter.layout||"default";if(A==="clover"||An(A)){let M=[];const E=b.filter(S=>S.slot==="header");if(E.length>0)M=E;else if(b.length>0){const S=b.find(L=>L.type==="h"&&(!L.slot||L.slot==="default"));S&&(M=[S])}const w=b.filter(S=>!M.includes(S));let P=2;if(A==="clover")P=4;else if(A==="three-cols-header")P=3;else if(A==="two-cols-header")P=2;else{let S=0;for(const L of w){const y=(L.slot||"").match(/^col-(\d+)$/i);y&&(S=Math.max(S,parseInt(y[1],10)))}if(S>=2)P=S;else if(v.frontmatter.layoutRatio){const L=v.frontmatter.layoutRatio.trim();if(L.includes(":")){const y=L.split(":").map(B=>parseFloat(B.trim())).filter(B=>!isNaN(B)&&B>0);y.length>=2&&(P=y.length)}else{const y=L.split(/\s+/).filter(Boolean);y.length>=2&&(P=y.length)}}else w.length===1&&w[0].children&&w[0].children.length>=2&&(P=Math.min(6,w[0].children.length))}const R=ya(w,P);R.forEach((S,L)=>{const y=`col-${L+1}`;for(const B of S)(!B.slot||B.slot==="default")&&(B.slot=y);x(S)});const z=R.flat();if(w.length===1&&z.length>1){const S=v.blocks.findIndex(L=>L.id===w[0].id);S!==-1&&v.blocks.splice(S,1,...z)}const G=k(M);if(G&&u.push(G),A==="two-cols-header"&&P===2){const S=_(R[0]||[]),L=_(R[1]||[]);S&&u.push(`::left::

${S}`),L&&u.push(`::right::

${L}`)}else R.forEach((S,L)=>{const y=_(S);y&&u.push(`::col-${L+1}::

${y}`)})}else if(A==="two-cols"){const M=b.filter(R=>R.slot==="left"),E=b.filter(R=>R.slot==="right");x(M),x(E);const w=k(M.length>0?M:b.filter(R=>R.slot!=="right")),P=k(E);u.push(w),P&&u.push(`::right::

${P}`)}else for(const M of b)u.push(Xn(M.rawMarkdown,M.clicks,M.motion,(d=M.attributes)==null?void 0:d.style));v.notes&&u.push(`<!--
${v.notes}
-->`),v.rawMarkdown=u.join(`

`).trim()}const c=s.map(p=>p.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:e,config:o,slides:s,fullMarkdown:c}}const xs=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function Af(e){var o,s,l,r,a,c,d,p,v,u,h,f;if(!e||typeof e!="object")return"";const t=[],i=[];if(Array.isArray(e.styles))for(const b of e.styles){if(!b||!b.id)continue;const k=`--b3-inline-style-${b.id}`;(o=b.light)!=null&&o.color&&t.push(`  ${k}-color: ${b.light.color};`),(s=b.light)!=null&&s.backgroundColor&&t.push(`  ${k}-background-color: ${b.light.backgroundColor};`),(l=b.dark)!=null&&l.color&&i.push(`  ${k}-color: ${b.dark.color};`),(r=b.dark)!=null&&r.backgroundColor&&i.push(`  ${k}-background-color: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const b of e.builtin.colors){if(!b||typeof b.index!="number")continue;const k=b.index;(a=b.light)!=null&&a.color&&t.push(`  --b3-font-color${k}: ${b.light.color};`),(c=b.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${k}: ${b.light.backgroundColor};`),(d=b.dark)!=null&&d.color&&i.push(`  --b3-font-color${k}: ${b.dark.color};`),(p=b.dark)!=null&&p.backgroundColor&&i.push(`  --b3-font-background${k}: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const b of e.builtin.styles){if(!b||!b.id)continue;const k=b.id;(v=b.light)!=null&&v.color&&t.push(`  --b3-card-${k}-color: ${b.light.color};`),(u=b.light)!=null&&u.backgroundColor&&t.push(`  --b3-card-${k}-background: ${b.light.backgroundColor};`),(h=b.dark)!=null&&h.color&&i.push(`  --b3-card-${k}-color: ${b.dark.color};`),(f=b.dark)!=null&&f.backgroundColor&&i.push(`  --b3-card-${k}-background: ${b.dark.backgroundColor};`)}if(t.length===0&&i.length===0)return"";const n=[];return t.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),i.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),n.join(`

`)}function Cn(e){const t=Af(e);return t?`${xs}

/* Custom Workspace Inline Styles */
${t}`:xs}function es(e){const t={};if(!e||typeof e!="string")return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(i))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";t[s]=l}return t}function Bf(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function Mf(e,t){const i=new Map,n=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:i,rebuildRoots:n};const o=new Map;for(const s of t)s!=null&&s.id&&o.set(s.id,s);for(const s of e||[]){if(!(s!=null&&s.id))continue;const l=o.get(s.id);if(!l)continue;const r=s.content??"",a=s.markdown??"";(l.content??"")===r&&(l.markdown??"")===a||(Bf(l)?n.push(s.id):i.set(s.id,{content:r,markdown:a}))}return{usable:!0,reason:"",leafPatch:i,rebuildRoots:n}}function Df(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function Ss(e){return ot(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function Lf(e,t,i,n=8,o){const s=new Map;for(const v of t)v!=null&&v.id&&s.set(v.id,v);const l=v=>({id:v.id,parent_id:v.parent_id,root_id:v.root_id||e,type:v.type,subType:v.subtype??v.subType??"",content:v.content||"",markdown:v.markdown||"",ial:i(v.id,v.ial),children:[]}),r=v=>{let u=v.parent_id,h=0;for(;u&&u!==e&&h++<16;){const f=s.get(u);if(!f||!Df(f))return u;u=f.parent_id}return u||e},a=new Map;for(const v of t){if(!(v!=null&&v.id)||v.id===e||o&&o.size>0&&!o.has(v.id))continue;const u=r(v),h=a.get(u);h?h.push(v):a.set(u,[v])}if(o&&o.size>0)for(const v of a.values())v.sort((u,h)=>(o.get(u.id)??Number.MAX_SAFE_INTEGER)-(o.get(h.id)??Number.MAX_SAFE_INTEGER));const c=new Map,d=(v,u)=>{const h=l(v);if(c.set(h.id,h),u>=n||!Ss(h))return h;const f=a.get(h.id);return f&&f.length>0&&(h.children=f.map(b=>d(b,u+1))),h};return{topLevel:(a.get(e)||[]).map(v=>d(v,0)),byId:c}}const Of={getBlockAttrs:$s,getChildBlocks:uo,getDocBlocksOrders:Oc,setBlockAttrs:Ne,sql:tn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:Pc};class Pf{constructor(t){be(this,"deps");be(this,"attrOverrides",new Map);be(this,"trackedListSuperBlocks",new Map);be(this,"fallbackWarnedDocId","");this.deps={...Of,...t||{}}}setBlockAttrOverride(t,i){if(!t||!i)return;const o={...this.attrOverrides.get(t)||{}};for(const[s,l]of Object.entries(i))l===""||l===null||l===void 0?delete o[s]:o[s]=String(l);Object.keys(o).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,o)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,i){if(!t)return;if(!i){this.attrOverrides.delete(t);return}const n=this.attrOverrides.get(t);n&&(delete n[i],Object.keys(n).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const i=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},n=this.attrOverrides.get(t);n&&Object.assign(i,n);const o=await this.deps.getChildBlocks(t).catch(()=>[])||[],s=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],l=new Map;for(let B=0;B<s.length;B++)s[B]&&l.set(s[B],B);const r=l.size>0,a=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[],d=Mf(o,c),p=new Map;if(Array.isArray(c))for(const B of c)B.id&&B.ial&&p.set(B.id,es(B.ial));const v=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,u=await this.deps.sql(v).catch(()=>[])||[];if(Array.isArray(u)){for(const B of u)if(B.block_id&&B.name){let F=p.get(B.block_id);F||(F={},p.set(B.block_id,F)),F[B.name]=B.value||""}}const h=(B,F)=>{const T={...p.get(B)||(F?es(F):{})},D=this.attrOverrides.get(B);return D&&Object.assign(T,D),T},f=Array.isArray(c)&&c.length>0?Lf(t,c,h,8,l):null,b=o.map(B=>B.id).filter(Boolean),k=B=>({id:B.id,parent_id:B.parent_id,root_id:B.root_id||t,type:B.type,subType:B.subType,content:B.content||"",markdown:B.markdown||"",ial:h(B.id,B.ial),children:B.children}),x=async(B,F=0)=>{if(!B||F>8||!Ss(B))return;const T=await this.deps.getChildBlocks(B.id).catch(()=>[])||[];if(!(!Array.isArray(T)||T.length===0)){B.children=T.filter(D=>D==null?void 0:D.id).map(D=>({id:D.id,parent_id:B.id,root_id:t,type:D.type,subType:D.subType,content:D.content||"",markdown:D.markdown||"",ial:h(D.id,D.ial),children:[]}));for(const D of B.children)await x(D,F+1)}},_=new Map;for(const B of c)B!=null&&B.id&&_.set(B.id,B);const A=b.every(B=>{const F=_.get(B);return!F||!!F.type});let M=[],E=!1;if(f&&d.usable&&r&&A){this.fallbackWarnedDocId="";for(const[F,T]of d.leafPatch){const D=f.byId.get(F);D&&(D.content=T.content,D.markdown=T.markdown)}const B=new Map;for(const F of o)F!=null&&F.id&&B.set(F.id,F);for(const F of d.rebuildRoots){const T=f.byId.get(F),D=B.get(F);T&&D&&(T.content=D.content||"",T.markdown=D.markdown||""),await x(T)}for(const F of o){if(!(F!=null&&F.id)||f.byId.has(F.id))continue;const T=k(F);await x(T),f.byId.set(T.id,T),f.topLevel.push(T)}M=f.topLevel.filter(F=>l.has(F.id)).sort((F,T)=>(l.get(F.id)??0)-(l.get(T.id)??0))}else b.length>0?(E=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${b.length} 索引行=${c.length} 文档序=${s.length} 原因=${d.reason||"缺少实时文档序"}`)),M=o.map(B=>k(B))):f&&(M=f.topLevel);const w=async(B,F=0)=>{if(!(!B||B.length===0||F>8))for(const T of B){if(Ss(T)&&(!T.children||T.children.length===0)){let N=await this.deps.getChildBlocks(T.id).catch(()=>[]);if(!N||N.length===0){const X=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${T.id}' ORDER BY sort ASC, created ASC`;N=await this.deps.sql(X).catch(()=>[])||[]}if(Array.isArray(N)&&N.length>0){const X=new Set(M.map(U=>U.id)),Z=N.filter(U=>U.id!==T.id&&!X.has(U.id));Z.length>0&&(T.children=Z.map(U=>{const ie=p.get(U.id)||(U.ial?es(U.ial):{}),se=this.attrOverrides.get(U.id);return se&&Object.assign(ie,se),{id:U.id,parent_id:U.parent_id||T.id,root_id:U.root_id||t,type:U.type,subType:U.subType,content:U.content||"",markdown:U.markdown||"",ial:ie}}))}}T.children&&T.children.length>0&&await w(T.children,F+1)}};E&&await w(M);const P=B=>{var F,T;for(const D of B)if(D.children&&D.children.length>0){P(D.children);for(const N of D.children)if(N.ial)for(const[X,Z]of Object.entries(N.ial))X.startsWith("custom-slidev-")&&!((F=D.ial)!=null&&F[X])&&(D.ial||(D.ial={}),D.ial[X]=Z);if(D.ial){for(const[N,X]of Object.entries(D.ial))if(N.startsWith("custom-slidev-"))for(const Z of D.children)(Z.type==="video"||Z.type==="NodeVideo"||/<video\b/i.test(Z.markdown||Z.content||""))&&!((T=Z.ial)!=null&&T[N])&&(Z.ial||(Z.ial={}),Z.ial[N]=X)}}};P(M),Sf(M,B=>{const F={[fe]:B.layout};this.setBlockAttrOverride(B.blockId,F),(this.deps.setBlockAttrs||Ne)(B.blockId,F).catch(D=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",D)})});const R=this.trackedListSuperBlocks.get(t)||[],z=xf(t,M,{tracked:R,onTagChange:B=>{this.setBlockAttrOverride(B.blockId,B.attrs),B.blockId===t&&Object.assign(i,B.attrs);const F=D=>{for(const N of D)N.id===B.blockId&&(N.ial||(N.ial={}),Object.assign(N.ial,B.attrs)),N.children&&N.children.length>0&&F(N.children)};F(M),(this.deps.setBlockAttrs||Ne)(B.blockId,B.attrs).catch(D=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",D)})}});this.trackedListSuperBlocks.set(t,z.newTracked);const G=new Set;for(const B of M){const F=B.markdown||B.content||"";if(F.includes("((")){const T=Rc(F);for(const D of T)G.add(D.blockId)}}const S={};if(G.size>0){const B=Array.from(G).map(T=>`'${T}'`).join(","),F=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${B})`).catch(()=>[])||[];if(Array.isArray(F))for(const T of F)T.id&&(S[T.id]=T.markdown||T.content||"")}const L=this.deps.getBaseUrl?this.deps.getBaseUrl():"",y=Hr(t,i,M,{baseUrl:L,refContentMap:S});try{const B=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;y.customThemeCss=Cn(B)}catch{y.customThemeCss=Cn(null)}return y}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const n=Hr(t,{},[],{});return n.customThemeCss=Cn(null),n}}}const Be=new Pf;class Zs{constructor(t){be(this,"devServerUrl","http://localhost:3030");be(this,"isConnected",!1);be(this,"lastSyncTime",null);t&&(this.devServerUrl=t)}getUrl(){return this.devServerUrl}setUrl(t){this.devServerUrl=t.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(t=1500){try{const i=new AbortController,n=setTimeout(()=>i.abort(),t),o=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!o,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(t){const i=t.config,n=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.colorSchema&&i.colorSchema!=="auto"&&n.push(`colorSchema: ${i.colorSchema}`),n.push("drawings:","  persist: false","---","");const o=n.join(`
`),s=t.slides.map((r,a)=>{const c=r.frontmatter||{},d=[],p=a===0;c.layout&&c.layout!=="default"&&d.push(`layout: ${c.layout}`),c.transition&&d.push(`transition: ${c.transition}`),c.background&&d.push(`background: ${c.background}`),c.class&&d.push(`class: "${c.class}"`);let v="";d.length>0?v=p?"":`---
${d.join(`
`)}
---

`:p||(v=`---

`);let u="";if(c.layout==="two-cols"){const f=r.blocks.filter(_=>_.slot!=="right"),b=r.blocks.filter(_=>_.slot==="right"),k=f.map(_=>_.rawMarkdown||_.content||"").join(`

`),x=b.map(_=>_.rawMarkdown||_.content||"").join(`

`);u=`${k}

::right::

${x}`}else u=r.blocks.map(f=>f.rawMarkdown||f.content||"").join(`

`);let h="";return r.notes&&r.notes.trim()&&(h=`

<!--
${r.notes.trim()}
-->`),`${v}${u}${h}`}).join(`

`);let l="";return t.config.normalizeHeadingSizes&&(l=`

<style>
/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}
</style>`),`${o}${s}${l}
`}async syncToWorkspaceFile(t,i="/data/storage/petal/siyuan-slidev/slides.md",n){const o=this.buildStandardSlidevMarkdown(t);if(this.lastSyncTime=Date.now(),n)try{const s=typeof Blob<"u"?new Blob([o],{type:"text/markdown;charset=utf-8"}):Buffer.from(o,"utf-8");return await n(i,!1,s),{success:!0,path:i}}catch(s){return{success:!1,path:i,error:String(s)}}return{success:!0,path:i}}downloadSlidesMd(t,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(t),o=new Blob([n],{type:"text/markdown;charset=utf-8"}),s=URL.createObjectURL(o),l=document.createElement("a");return l.href=s,l.download=i,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(s),!0}}function Rf(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function Ct(e){const t=Rf();if(t)try{return t(e)}catch{try{const i=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(i)}catch{}}}function Ys(){var t;if(typeof window<"u"&&window.process)return window.process;const e=Ct("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function ka(){var t,i;const e=Ys();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const n=Ct("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function Nf(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function Nn(){const e=Ys();if(e!=null&&e.platform)return e.platform;if(typeof process<"u"&&process.platform)return process.platform;const t=Ct("os");if(t&&typeof t.platform=="function")return t.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function wa(){var n,o;const e=Ys(),t={...(e==null?void 0:e.env)||{}};if(Nn()==="win32"){const s=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=e==null?void 0:e.env)!=null&&n.APPDATA?`${e.env.APPDATA}\\npm`:"",(o=e==null?void 0:e.env)!=null&&o.USERPROFILE?`${e.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(t).find(c=>c.toLowerCase()==="path")||"PATH",a=(t[l]||"").split(";").filter(Boolean);for(const c of s)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);t[l]=a.join(";")}return t}function _s(e){var i,n,o;if(!e)return"";if(/^[a-zA-Z]:[/\\]/.test(e))return e.replace(/\\/g,"/");let t="";if(typeof window<"u"&&((o=(n=(i=window.siyuan)==null?void 0:i.config)==null?void 0:n.system)!=null&&o.dataDir)&&(t=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),t&&e.startsWith("/data/")){const s=e.slice(6);return`${t}/${s}`.replace(/\\/g,"/")}return e}function zf(){const e=Ct("os"),t=Ct("path");if(e&&typeof e.tmpdir=="function"){const i=e.tmpdir();return t&&typeof t.join=="function"?t.join(i,"siyuan-slidev-pro").replace(/\\/g,"/"):`${i}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class Js{constructor(t){be(this,"runner");this.runner=t||Js.defaultRunner}static async defaultRunner(t,i){var n;try{let o=(n=Ct("child_process"))==null?void 0:n.execFile;if(!o){const a=await import("node:child_process").catch(()=>({}));o=a==null?void 0:a.execFile}if(!o)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=Nn()==="win32",r=wa();return await new Promise(a=>{o(t,i,{timeout:5e3,shell:l,env:r},(c,d,p)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:p?String(p).trim():""})})})}catch(o){return{code:-1,stdout:"",stderr:String(o)}}}async detect(){const t=ka(),i=Nn();if(!t)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,o,s=!1,l;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,o=r.stdout)}catch{}if(n){try{const r=i==="win32"?"slidev.cmd":"slidev",a=await this.runner(r,["--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}if(!s)try{const r=i==="win32"?"npx.cmd":"npx",a=await this.runner(r,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:o,hasSlidevCli:s,slidevVersion:l,platform:i,isDesktop:t}}}class Ff{constructor(){be(this,"iframe",null);be(this,"isReady",!1);be(this,"pageChangedHandlers",[]);be(this,"readyHandlers",[]);be(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(t,i){var o;if(!((o=this.iframe)!=null&&o.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:t,...i};try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[NativeSlidevBridge] postMessage error:",s)}}navigateToPage(t){this.postMessage("navigate",{no:t})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(t){return this.pageChangedHandlers.push(t),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==t)}}onReady(t){return this.readyHandlers.push(t),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){const i=t.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(i.type==="update-state"&&i.navState){const n=i.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const o of this.pageChangedHandlers)o(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const n of this.pageChangedHandlers)n(i.no,this.currentState.total||1,this.currentState)}}}}class Hf{constructor(t){be(this,"childProcess",null);be(this,"activePort",null);be(this,"isRunning",!1);be(this,"defaultPort");be(this,"maxPortRetries");be(this,"probeTimeoutMs");be(this,"customSpawner");be(this,"customPortChecker");this.defaultPort=(t==null?void 0:t.defaultPort)||3030,this.maxPortRetries=(t==null?void 0:t.maxPortRetries)||20,this.probeTimeoutMs=(t==null?void 0:t.probeTimeoutMs)||1e4,this.customSpawner=t==null?void 0:t.customSpawner,this.customPortChecker=t==null?void 0:t.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(t){if(this.customPortChecker)return this.customPortChecker(t);try{let i=Ct("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(n=>{const o=i.createServer();o.once("error",()=>n(!1)),o.once("listening",()=>{o.close(()=>n(!0))}),o.listen(t,"127.0.0.1")}):!0}catch{return!0}}async allocPort(t){const i=t||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const o=i+n;if(await this.isPortAvailable(o))return o}return i}async pollServerReady(t,i=8e3,n=300){const o=Date.now();for(;Date.now()-o<i;){try{const s=new AbortController,l=setTimeout(()=>s.abort(),n),r=await fetch(t,{method:"HEAD",mode:"no-cors",signal:s.signal}).catch(()=>null);if(clearTimeout(l),r)return!0}catch{}await new Promise(s=>setTimeout(s,n))}return!1}async startServer(t,i){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(i);this.activePort=n;const s=Nn()==="win32"?"npx.cmd":"npx",l=_s(t),r=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(s,r,{detached:!1});else{let p=(a=Ct("child_process"))==null?void 0:a.spawn;if(!p){const h=await import("node:child_process").catch(()=>({}));p=h==null?void 0:h.spawn}if(!p)throw new Error("child_process spawn not available in current runtime");const v=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,u=wa();this.childProcess=p(s,r,{cwd:v,detached:!1,shell:!0,env:{...u,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var t;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),Nn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(t=Ct("child_process"))==null?void 0:t.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:o})=>{var s;o(`taskkill /pid ${(s=this.childProcess)==null?void 0:s.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Xs{constructor(){be(this,"iframe",null);be(this,"isReady",!1);be(this,"pendingMessages",[]);be(this,"slideChangedHandlers",[]);be(this,"blockClickedHandlers",[]);be(this,"openInEditorHandlers",[]);be(this,"clientReadyHandlers",[]);be(this,"openPeekDrawerHandlers",[]);be(this,"toggleFullscreenHandlers",[]);be(this,"openPresenterHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(t,i){var o;const n={source:"siyuan-slidev-host",action:t,payload:i};if(!((o=this.iframe)!=null&&o.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[WebSandboxBridge] postMessage error:",s)}}updateSlides(t,i,n,o){this.postMessage("UPDATE_SLIDES",{slides:t,config:i,fullMarkdown:n,customThemeCss:o})}navigatePage(t){this.postMessage("NAVIGATE_PAGE",{pageIndex:t})}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(i=>i!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){var n;const i=t.data;if(!(!i||i.source!=="siyuan-slidev-client"))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const o=i.payload.blockId||i.payload.clickedBlockId||"";for(const s of this.openInEditorHandlers)s(o,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const o=i.payload.blockId||i.payload.url||"",s={peekType:i.payload.peekType,target:o,title:i.payload.title};for(const l of this.openPeekDrawerHandlers)l(s)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break;case"OPEN_PRESENTER":for(const o of this.openPresenterHandlers)o();break}}}const xa={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},jf=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,Wf=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,Uf=`<script setup lang="ts">
import { useSlots } from 'vue'

const slots = useSlots()
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-2 grid-rows-2 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
    </div>
  </div>
</template>
`,Vf=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slidev-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,Kf=`${xs}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function qf(e){var o;const t=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=i.exec(e))!==null;){const s=(o=n[1])==null?void 0:o.trim();s&&!t.includes(s)&&t.push(s)}return t}class Gf{constructor(t){be(this,"workspacePath");be(this,"slidesFileName");be(this,"cliBridge",new Zs);const i=zf();!(t!=null&&t.workspacePath)||t.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=i:this.workspacePath=t.workspacePath,this.slidesFileName=(t==null?void 0:t.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(t="default"){const i={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return t&&t!=="default"&&(i.dependencies[`@slidev/theme-${t}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(t){return this.cliBridge.buildStandardSlidevMarkdown(t)}async scaffold(t,i){const n=this.buildSlidesMarkdown(t),o=this.generatePackageJson(t.config.theme),s=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,r=_s(s),a=_s(l),c=qf(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const _ of c){const A=xa[_]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${_}
// #endregion snippet
`;d.set(_,A)}t.slides.some(_=>{var A;return((A=_.frontmatter)==null?void 0:A.layout)==="cols-header"})&&d.set("layouts/cols-header.vue",jf),t.slides.some(_=>{var A;return((A=_.frontmatter)==null?void 0:A.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",Wf),t.slides.some(_=>{var A;return((A=_.frontmatter)==null?void 0:A.layout)==="clover"})&&d.set("layouts/clover.vue",Uf),d.set("setup/root.ts",Vf),d.set("styles/index.css",Kf);const h=Ct("fs"),f=Ct("path");let b=!1;const k=f!=null&&f.dirname?f.dirname(r):"",x=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-slidev-pro");if(h&&f&&x)try{h.existsSync(k)||h.mkdirSync(k,{recursive:!0}),h.writeFileSync(a,o,"utf-8"),h.writeFileSync(r,n,"utf-8");for(const[_,A]of d.entries()){const M=f.join(k,_),E=f.dirname(M);h.existsSync(E)||h.mkdirSync(E,{recursive:!0}),h.existsSync(M)||h.writeFileSync(M,A,"utf-8")}b=!0}catch{}if(!b&&i)try{const _=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),A=typeof Blob<"u"?new Blob([o],{type:"application/json;charset=utf-8"}):Buffer.from(o,"utf-8");await i(l,!1,A),await i(s,!1,_);for(const[M,E]of d.entries()){const w=`${this.workspacePath}/${M}`,P=typeof Blob<"u"?new Blob([E],{type:"text/plain;charset=utf-8"}):Buffer.from(E,"utf-8");await i(w,!1,P).catch(()=>{})}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}catch(_){return{success:!1,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l,error:String(_)}}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}}class Zf{constructor(){be(this,"mode","web-sandbox");be(this,"webBridge");be(this,"cliBridge");be(this,"nativeBridge");be(this,"processManager");be(this,"scaffolder");be(this,"envDetector");this.webBridge=new Xs,this.cliBridge=new Zs,this.nativeBridge=new Ff,this.processManager=new Hf,this.scaffolder=new Gf,this.envDetector=new Js}getMode(){return this.mode}setMode(t){this.mode=t}async startProMode(t,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const o=await this.scaffolder.scaffold(t,i);if(!o.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${o.error}`};const s=o.physicalSlidesPath||o.slidesPath,l=await this.processManager.startServer(s);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const Yf={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Jf={key:0},Xf={key:1},Qf={key:2},ep={key:3},tp={key:4},ip={key:5},np={key:6},op={key:7},sp={key:8},rp={key:9},lp={key:10},ap={key:11},cp={key:12},dp={key:13},up={key:14},fp={key:15},pp={key:16},hp={key:17},mp={key:18},gp={key:19},vp={key:20},bp={key:21},yp={key:22},kp={key:23},wp={key:24},xp={key:25},Sp={key:26},_p={key:27},Cp={key:28},$p={key:29},Ip={key:30},Ep={key:31},Tp={key:32},Ap={key:33},Bp={key:34},Mp={key:35},Dp={key:36},Lp={key:37},Op={key:38},Pp={key:39},Rp={key:40},Np={key:41},zp={key:42},Fp={key:43},Hp={key:44},jp={key:45},Wp={key:46},Up={key:47},Vp={key:48},Kp={key:49},qp={key:50},Gp={key:51},Zp={key:52},Yp={key:53},Jp={key:54},Xp={key:55},Qp={key:56},eh={key:57},th={key:58},ih={key:59},nh={key:60},oh={key:61},sh={key:62},rh={key:63},lh={key:64},ah={key:65},ch={key:66},dh=xt({__name:"SlidevIcon",props:{name:{}},setup(e){return(t,i)=>(ee(),te("svg",Yf,[e.name==="fullscreen"||e.name==="maximize"?(ee(),te("g",Jf,[...i[0]||(i[0]=[m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("polyline",{points:"9 21 3 21 3 15"},null,-1),m("polyline",{points:"21 15 21 21 15 21"},null,-1),m("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(ee(),te("g",Xf,[...i[1]||(i[1]=[m("polyline",{points:"4 14 10 14 10 20"},null,-1),m("polyline",{points:"20 10 14 10 14 4"},null,-1),m("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),m("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(ee(),te("g",Qf,[...i[2]||(i[2]=[m("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),m("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(ee(),te("g",ep,[...i[3]||(i[3]=[m("path",{d:"M12 20h9"},null,-1),m("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(ee(),te("g",tp,[...i[4]||(i[4]=[m("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),m("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(ee(),te("g",ip,[...i[5]||(i[5]=[m("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(ee(),te("g",np,[...i[6]||(i[6]=[m("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),m("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(ee(),te("g",op,[...i[7]||(i[7]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(ee(),te("g",sp,[...i[8]||(i[8]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(ee(),te("g",rp,[...i[9]||(i[9]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(ee(),te("g",lp,[...i[10]||(i[10]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),m("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(ee(),te("g",ap,[...i[11]||(i[11]=[m("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),m("polyline",{points:"7 9 12 14 17 9"},null,-1),m("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(ee(),te("g",cp,[...i[12]||(i[12]=[m("path",{d:"M2 3h20"},null,-1),m("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),m("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(ee(),te("g",dp,[...i[13]||(i[13]=[m("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),m("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(ee(),te("g",up,[...i[14]||(i[14]=[m("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(ee(),te("g",fp,[...i[15]||(i[15]=[m("path",{d:"M5 12h14"},null,-1),m("path",{d:"m12 5 7 7-7 7"},null,-1),m("path",{d:"M5 6h4"},null,-1),m("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(ee(),te("g",pp,[...i[16]||(i[16]=[m("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),m("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="code"?(ee(),te("g",hp,[...i[17]||(i[17]=[m("polyline",{points:"16 18 22 12 16 6"},null,-1),m("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="insert-above"?(ee(),te("g",mp,[...i[18]||(i[18]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),m("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),m("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(ee(),te("g",gp,[...i[19]||(i[19]=[m("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),m("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(ee(),te("g",vp,[...i[20]||(i[20]=[m("path",{d:"m18 15-6-6"},null,-1),m("path",{d:"M4 20h16"},null,-1),m("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(ee(),te("g",bp,[...i[21]||(i[21]=[m("path",{d:"M3 6h18"},null,-1),m("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),m("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(ee(),te("g",yp,[...i[22]||(i[22]=[m("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(ee(),te("g",kp,[...i[23]||(i[23]=[gt('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-57969535></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-57969535></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-57969535></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-57969535></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-57969535></path>',5)])])):e.name==="ratio"?(ee(),te("g",wp,[...i[24]||(i[24]=[m("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(ee(),te("g",xp,[...i[25]||(i[25]=[m("path",{d:"M8 3 4 7l4 4"},null,-1),m("path",{d:"M4 7h16"},null,-1),m("path",{d:"m16 21 4-4-4-4"},null,-1),m("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(ee(),te("g",Sp,[...i[26]||(i[26]=[m("polyline",{points:"16 16 12 12 8 16"},null,-1),m("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),m("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(ee(),te("g",_p,[...i[27]||(i[27]=[m("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),m("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),m("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(ee(),te("g",Cp,[...i[28]||(i[28]=[m("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),m("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(ee(),te("g",$p,[...i[29]||(i[29]=[m("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),m("path",{d:"M21 3v5h-5"},null,-1),m("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),m("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(ee(),te("g",Ip,[...i[30]||(i[30]=[m("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),m("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),m("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="outline"?(ee(),te("g",Ep,[...i[31]||(i[31]=[m("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),m("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),m("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):e.name==="chevron-left"?(ee(),te("g",Tp,[...i[32]||(i[32]=[m("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(ee(),te("g",Ap,[...i[33]||(i[33]=[m("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="copy"?(ee(),te("g",Bp,[...i[34]||(i[34]=[m("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),m("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"?(ee(),te("g",Mp,[...i[35]||(i[35]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),m("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),m("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(ee(),te("g",Dp,[...i[36]||(i[36]=[m("circle",{cx:"11",cy:"11",r:"7"},null,-1),m("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(ee(),te("g",Lp,[...i[37]||(i[37]=[m("circle",{cx:"12",cy:"12",r:"3"},null,-1),m("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(ee(),te("g",Op,[...i[38]||(i[38]=[gt('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-57969535></path><polyline points="14 2 14 8 20 8" data-v-57969535></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-57969535></line><line x1="16" y1="17" x2="8" y2="17" data-v-57969535></line><line x1="10" y1="9" x2="8" y2="9" data-v-57969535></line>',5)])])):e.name==="focus"||e.name==="target"?(ee(),te("g",Pp,[...i[39]||(i[39]=[m("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),m("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),m("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(ee(),te("g",Rp,[...i[40]||(i[40]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),m("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),m("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(ee(),te("g",Np,[...i[41]||(i[41]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-57969535></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-57969535></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-57969535></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-57969535></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(ee(),te("g",zp,[...i[42]||(i[42]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-57969535></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-57969535></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-57969535></line><line x1="5" y1="15" x2="8" y2="15" data-v-57969535></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-57969535></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-57969535></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-57969535></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(ee(),te("g",Fp,[...i[43]||(i[43]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-57969535></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-57969535></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-57969535></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-57969535></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-57969535></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(ee(),te("g",Hp,[...i[44]||(i[44]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-57969535></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-57969535></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-57969535></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-57969535></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-57969535></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-57969535></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-57969535></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(ee(),te("g",jp,[...i[45]||(i[45]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="7" x2="13" y2="7" data-v-57969535></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-57969535></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-57969535></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-57969535></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-57969535></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(ee(),te("g",Wp,[...i[46]||(i[46]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="12" y1="4" x2="12" y2="20" data-v-57969535></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-57969535></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-57969535></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-57969535></line><circle cx="15.5" cy="8.5" r="1.2" data-v-57969535></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-57969535></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(ee(),te("g",Up,[...i[47]||(i[47]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="12" y1="4" x2="12" y2="20" data-v-57969535></line><circle cx="6" cy="8.5" r="1.2" data-v-57969535></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-57969535></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-57969535></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-57969535></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-57969535></line>',7)])])):e.name==="layout-center"||e.name==="center"?(ee(),te("g",Vp,[...i[48]||(i[48]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(ee(),te("g",Kp,[...i[49]||(i[49]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><circle cx="8" cy="9" r="1.5" data-v-57969535></circle><line x1="14" y1="8" x2="9" y2="14" data-v-57969535></line><circle cx="15" cy="13" r="1.5" data-v-57969535></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-57969535></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(ee(),te("g",qp,[...i[50]||(i[50]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><circle cx="7.5" cy="9.5" r="2" data-v-57969535></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-57969535></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-57969535></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-57969535></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-57969535></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(ee(),te("g",Gp,[...i[51]||(i[51]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-57969535></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-57969535></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-57969535></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-57969535></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(ee(),te("g",Zp,[...i[52]||(i[52]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(ee(),te("g",Yp,[...i[53]||(i[53]=[m("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),m("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(ee(),te("g",Jp,[...i[54]||(i[54]=[m("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),m("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),m("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(ee(),te("g",Xp,[...i[55]||(i[55]=[m("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),m("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(ee(),te("g",Qp,[...i[56]||(i[56]=[m("path",{d:"m17 1 4 4-4 4"},null,-1),m("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),m("path",{d:"m7 23-4-4 4-4"},null,-1),m("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(ee(),te("g",eh,[...i[57]||(i[57]=[m("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),m("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),m("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(ee(),te("g",th,[...i[58]||(i[58]=[gt('<line x1="4" y1="21" x2="4" y2="14" data-v-57969535></line><line x1="4" y1="10" x2="4" y2="3" data-v-57969535></line><line x1="12" y1="21" x2="12" y2="12" data-v-57969535></line><line x1="12" y1="8" x2="12" y2="3" data-v-57969535></line><line x1="20" y1="21" x2="20" y2="16" data-v-57969535></line><line x1="20" y1="12" x2="20" y2="3" data-v-57969535></line><line x1="1" y1="14" x2="7" y2="14" data-v-57969535></line><line x1="9" y1="8" x2="15" y2="8" data-v-57969535></line><line x1="17" y1="16" x2="23" y2="16" data-v-57969535></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(ee(),te("g",ih,[...i[59]||(i[59]=[m("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),m("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),m("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),m("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(ee(),te("g",nh,[...i[60]||(i[60]=[m("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(ee(),te("g",oh,[...i[61]||(i[61]=[m("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),m("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),m("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),m("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(ee(),te("g",sh,[...i[62]||(i[62]=[m("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),m("path",{d:"m13 8 2 2"},null,-1),m("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(ee(),te("g",rh,[...i[63]||(i[63]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-57969535></rect><line x1="13" y1="8" x2="19" y2="8" data-v-57969535></line><line x1="13" y1="12" x2="19" y2="12" data-v-57969535></line><line x1="13" y1="16" x2="17" y2="16" data-v-57969535></line>',5)])])):e.name==="image-right"?(ee(),te("g",lh,[...i[64]||(i[64]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-57969535></rect><line x1="5" y1="8" x2="11" y2="8" data-v-57969535></line><line x1="5" y1="12" x2="11" y2="12" data-v-57969535></line><line x1="5" y1="16" x2="9" y2="16" data-v-57969535></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(ee(),te("g",ah,[...i[65]||(i[65]=[m("circle",{cx:"12",cy:"12",r:"10"},null,-1),m("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),m("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(ee(),te("g",ch,[...i[66]||(i[66]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Mt=(e,t)=>{const i=e.__vccOpts||e;for(const[n,o]of t)i[n]=o;return i},de=Mt(dh,[["__scopeId","data-v-57969535"]]);function et(e,t){var o;if(typeof document>"u"||!e)return;const i=(o=globalThis.CSS)!=null&&o.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${i}"]`);!n||n.length===0||n.forEach(s=>{for(const[l,r]of Object.entries(t))r!=null&&r!==""?s.setAttribute(l,String(r)):s.removeAttribute(l)})}function uh(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${fe}], .protyle-wysiwyg [${qe}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,i=document.querySelectorAll(t);!i||i.length===0||i.forEach(n=>{const o=n.getAttribute("data-node-id");if(!o){n.removeAttribute(fe),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(qe),n.removeAttribute("custom-slidev-role");return}const s=e.get(o),l=(s==null?void 0:s[fe])||(s==null?void 0:s["custom-slidev-layout"])||"",r=n.getAttribute(fe)||n.getAttribute("custom-slidev-layout");r&&r!==l&&(l?n.setAttribute(fe,l):(n.removeAttribute(fe),n.removeAttribute("custom-slidev-layout")));const a=(s==null?void 0:s[qe])||(s==null?void 0:s["custom-slidev-role"])||"",c=n.getAttribute(qe)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(qe,a):(n.removeAttribute(qe),n.removeAttribute("custom-slidev-role")))})}const fh={class:"spm-layout-picker"},ph={class:"spm-layout-picker__grid"},hh=["title","onClick"],mh={class:"spm-layout-icon"},gh={class:"spm-layout-label"},vh=xt({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=e,n=t,o=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"4 项超级块 2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function s(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function l(r){n("update:modelValue",r),n("change",r)}return(r,a)=>(ee(),te("div",fh,[a[0]||(a[0]=m("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),m("div",ph,[(ee(),te(Ue,null,kt(o,c=>m("div",{key:c.name,class:_e(["spm-layout-item",{active:s(c.name)}]),title:c.desc,onClick:d=>l(c.name)},[m("div",mh,[re(de,{name:"layout-"+c.name},null,8,["name"])]),m("span",gh,we(c.label),1)],10,hh)),64))])]))}}),Sa=Mt(vh,[["__scopeId","data-v-1964d02c"]]),bh={key:0,class:"spm-transition-selector__header"},yh={class:"spm-transition-list"},kh=["onClick"],wh={class:"spm-transition-meta"},xh={class:"spm-transition-label"},Sh={class:"spm-transition-name"},_h={class:"spm-transition-preview-box"},Ch=xt({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=t,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function o(s){i("update:modelValue",s),i("change",s)}return(s,l)=>(ee(),te("div",{class:_e(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Oe("",!0):(ee(),te("div",bh,we(e.title||"转场动效"),1)),m("div",yh,[(ee(),te(Ue,null,kt(n,r=>m("div",{key:r.name,class:_e(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:a=>o(r.name)},[m("div",wh,[m("span",xh,we(r.label),1),m("span",Sh,"("+we(r.name)+")",1)]),m("div",_h,[m("div",{class:_e(["spm-anim-cube","anim-"+r.name])},null,2)])],10,kh)),64))])],2))}}),Qs=Mt(Ch,[["__scopeId","data-v-8597e99e"]]),$h={class:"spm-divider-popover"},Ih={class:"spm-divider-popover__title"},Eh={class:"spm-form-item"},Th={class:"spm-popover-footer"},Ah={class:"spm-save-hint"},Bh=xt({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(e,{emit:t}){var v,u,h;const i=e,n=t,o=he(((v=i.initialAttrs)==null?void 0:v[fe])||"default"),s=he(((u=i.initialAttrs)==null?void 0:u[tt])||"slide-left"),l=he(((h=i.initialAttrs)==null?void 0:h[je])||""),r=he("");Li(()=>i.initialAttrs,f=>{o.value=(f==null?void 0:f[fe])||"default",s.value=(f==null?void 0:f[tt])||"slide-left",l.value=(f==null?void 0:f[je])||""},{deep:!0});async function a(f,b){if(i.blockId){r.value="正在同步...",Be.setBlockAttrOverride(i.blockId,{[f]:b}),et(i.blockId,{[f]:b});try{await Ne(i.blockId,{[f]:b}),r.value="已同步至块属性",n("updated",{[f]:b}),setTimeout(()=>{r.value=""},1500)}catch{r.value="同步失败"}}}function c(f){a(fe,f)}function d(f){a(tt,f)}function p(){a(je,l.value.trim())}return(f,b)=>(ee(),te("div",$h,[m("div",Ih,[b[4]||(b[4]=m("span",null,"幻灯片页面设置",-1)),m("button",{class:"spm-close-btn",onClick:b[0]||(b[0]=k=>n("close"))},"✕")]),re(Sa,{modelValue:o.value,"onUpdate:modelValue":b[1]||(b[1]=k=>o.value=k),onChange:c},null,8,["modelValue"]),re(Qs,{modelValue:s.value,"onUpdate:modelValue":b[2]||(b[2]=k=>s.value=k),onChange:d},null,8,["modelValue"]),m("div",Eh,[b[5]||(b[5]=m("label",{class:"spm-form-label"},"页面背景",-1)),Tt(m("input",{"onUpdate:modelValue":b[3]||(b[3]=k=>l.value=k),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:p},null,544),[[_o,l.value]])]),m("div",Th,[m("span",Ah,we(r.value),1)])]))}}),Mh=Mt(Bh,[["__scopeId","data-v-e4871368"]]),Dh={class:"spm-slide-inspector"},Lh={class:"spm-inspector-header"},Oh={class:"spm-inspector-list"},Ph=["onClick"],Rh={class:"spm-card-top"},Nh={class:"spm-card-badge"},zh={class:"spm-card-layout"},Fh=["onClick"],Hh={class:"spm-card-preview"},jh={key:0,class:"spm-card-notes",title:"演讲备忘录"},Wh={class:"spm-inspector-modal-content"},Uh=xt({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(e,{emit:t}){const i=t,n=he(null);function o(c){n.value=c}function s(c){const d={};return c.frontmatter.layout&&(d[fe]=c.frontmatter.layout),c.frontmatter.transition&&(d[tt]=c.frontmatter.transition),c.frontmatter.background&&(d[je]=c.frontmatter.background),c.notes&&(d[Ui]=c.notes),d}function l(c){n.value&&(c[fe]&&(n.value.frontmatter.layout=c[fe]),c[tt]&&(n.value.frontmatter.transition=c[tt]),c[je]&&(n.value.frontmatter.background=c[je]),c[Ui]&&(n.value.notes=c[Ui]),i("refresh"))}function r(c){i("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const d=c.blocks[0],p=d.content||d.rawMarkdown||"";return p.slice(0,40)+(p.length>40?"...":"")}return(c,d)=>(ee(),te("div",Dh,[m("div",Lh,[m("span",null,"幻灯片大纲 ("+we(e.slides.length)+" 页)",1)]),m("div",Oh,[(ee(!0),te(Ue,null,kt(e.slides,p=>(ee(),te("div",{key:p.pageIndex,class:_e(["spm-card",{active:e.currentActivePage===p.pageIndex}]),onClick:v=>r(p.pageIndex)},[m("div",Rh,[m("span",Nh,"P"+we(p.pageIndex),1),m("span",zh,we(p.frontmatter.layout||"default"),1),m("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Lt(v=>o(p),["stop"])},[re(de,{name:"settings"})],8,Fh)]),m("div",Hh,we(a(p)),1),p.notes?(ee(),te("div",jh,[re(de,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),m("span",null,we(p.notes),1)])):Oe("",!0)],10,Ph))),128))]),n.value?(ee(),te("div",{key:0,class:"spm-inspector-modal-mask",onClick:d[1]||(d[1]=Lt(p=>n.value=null,["self"]))},[m("div",Wh,[re(Mh,{"block-id":n.value.startBlockId,"initial-attrs":s(n.value),onClose:d[0]||(d[0]=p=>n.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Oe("",!0)]))}}),Vh=Mt(Uh,[["__scopeId","data-v-68b25edd"]]),Kh={class:"spm-immersion-header"},qh={class:"spm-immersion-header__left"},Gh={class:"spm-immersion-title"},Zh={class:"spm-immersion-header__center"},Yh={class:"spm-immersion-header__actions"},Jh=["aria-label"],Xh={class:"spm-immersion-body"},Qh=xt({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const i=e,n=t;function o(){n("update:visible",!1),n("close")}function s(){i.closeOnClickMask&&o()}function l(){n("update:isMaximized",!i.isMaximized),n("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),o())}return(a,c)=>Tt((ee(),te("div",{class:_e(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:Lt(r,["stop"])},[m("div",{class:"spm-immersion-mask",onClick:s}),m("div",{class:_e(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[m("div",Kh,[m("div",qh,[Yn(a.$slots,"header-left",{},()=>[m("span",Gh,we(e.title),1)])]),m("div",Zh,[Yn(a.$slots,"header-center",{},void 0)]),m("div",Yh,[Yn(a.$slots,"header-actions",{},void 0),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[re(de,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,Jh),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:o},[re(de,{name:"close"})])])]),m("div",Xh,[Yn(a.$slots,"default",{},void 0)])],2)],34)),[[ks,e.visible]])}}),em=Mt(Qh,[["__scopeId","data-v-3f1665db"]]),tm={class:"spm-protyle-drawer"},im={class:"spm-protyle-drawer__subbar"},nm={class:"spm-protyle-drawer__nav"},om=["title"],sm={class:"spm-protyle-drawer__actions"},rm=["aria-label"],lm=["aria-label"],am=xt({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,o=he(n.blockId),s=he(n.title||""),l=he(!1),r=he(!0),a=he(!1),c=he(""),d=mi,p=he([]),v=he(null);let u=null;Li(()=>n.blockId,w=>{w&&w!==o.value&&(o.value=w,s.value=n.title||"",p.value=[],f(w))}),Hn(()=>{o.value&&f(o.value)}),Fs(()=>{b()});async function h(w){try{const P=await tn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${w}' LIMIT 1`);if(Array.isArray(P)&&P.length>0){const R=P[0];c.value=R.root_id||"";const z=R.id===R.root_id||R.type==="d";a.value=z,r.value=!z,!s.value&&R.content&&(s.value=R.content.trim().slice(0,30));return}}catch(P){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",P)}a.value=!1,r.value=!0}async function f(w,P){if(!v.value||!w)return;b(),await h(w),typeof P=="boolean"&&(r.value=!a.value&&P);let R,z;r.value&&!a.value?(R=["cb-get-all","cb-get-hl","cb-get-focus"],z={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(R=["cb-get-context","cb-get-hl"],z={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{u=new pe.Protyle(n.plugin.app,v.value,{blockId:w,action:R,render:z}),!l.value&&u&&typeof u.disable=="function"&&u.disable()}catch(G){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",G)}}function b(){if(u){try{typeof u.destroy=="function"&&u.destroy()}catch(w){console.warn("[ProtylePeekDrawer] Error destroying protyle:",w)}u=null}v.value&&(v.value.innerHTML="")}function k(){a.value||(r.value=!r.value,f(o.value,r.value))}function x(){l.value=!l.value,u&&(l.value?(typeof u.enable=="function"&&u.enable(),typeof u.focus=="function"&&u.focus()):typeof u.disable=="function"&&u.disable())}function _(){if(o.value)try{pe.openWindow({doc:{id:o.value},alwaysOnTop:!0})}catch(w){console.warn("[ProtylePeekDrawer] openWindow failed:",w)}}function A(){var R;if(!o.value)return;const w=zo(),P=pa(w.webServeUrl,o.value,{focus:!a.value});if(typeof window<"u"){const z=Ct("electron");(R=z==null?void 0:z.shell)!=null&&R.openExternal?z.shell.openExternal(P).catch(()=>{window.open(P,"_blank")}):window.open(P,"_blank")}i("external-jump",P)}function M(){if(p.value.length>0){const w=p.value.pop();w&&(o.value=w.blockId,s.value=w.title,r.value=w.isFocusMode,a.value=w.isDoc,f(w.blockId,w.isFocusMode))}}function E(w){const P=w.target;if(!P)return;const R=P.closest('[data-type="block-ref"]');if(R){const G=R.getAttribute("data-id");if(G&&G!==o.value){w.preventDefault(),w.stopPropagation(),p.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=G,s.value=R.innerText.trim()||G,f(G);return}}const z=P.closest("a");if(z&&z.href&&z.href.startsWith("siyuan://blocks/")){w.preventDefault(),w.stopPropagation();const G=z.href.replace("siyuan://blocks/","").split("?")[0];G&&G!==o.value&&(p.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=G,s.value=z.innerText.trim()||G,f(G))}}return(w,P)=>(ee(),te("div",tm,[m("div",im,[m("div",nm,[p.value.length>0?(ee(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:M},[re(de,{name:"arrow-left"}),P[0]||(P[0]=m("span",null,"返回",-1))])):Oe("",!0),m("span",{class:_e(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},we(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),m("span",{class:"spm-protyle-id",title:s.value||o.value},we(s.value||o.value),9,om)]),m("div",sm,[a.value?Oe("",!0):(ee(),te("button",{key:0,class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:k},[re(de,{name:r.value?"focus":"file-text"},null,8,["name"]),m("span",null,we(r.value?"块聚焦":"展开全文"),1)],10,rm)),m("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:x},[re(de,{name:l.value?"edit":"eye"},null,8,["name"]),m("span",null,we(l.value?"编辑中":"只读"),1)],10,lm),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:_},[re(de,{name:"window"}),P[1]||(P[1]=m("span",null,"独立窗口",-1))]),ge(d).enableWebServeJump?(ee(),te("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:A},[re(de,{name:"external-link"}),P[2]||(P[2]=m("span",null,"外跳",-1))])):Oe("",!0)])]),m("div",{ref_key:"mountEl",ref:v,class:_e(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:E},null,2)]))}}),cm=Mt(am,[["__scopeId","data-v-7e586ef3"]]),dm=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,um=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function jr(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(i)return`/assets/${i[1]}`;const n=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return n?`/plugins/${n[1]}`:null}function _a(e){const t=(e||"").replace(/^file:\/\//i,"");let i=t;try{i=decodeURIComponent(t)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const n=i.indexOf("/");return n>=0?i.slice(n):i}function fm(e){const t=e.split(/[/?#]/)[0];return!t||um.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function pm(e){const t=e.indexOf("#"),i=t>=0?e.slice(t):"",n=t>=0?e.slice(0,t):e,o=n.indexOf("?"),s=o>=0?n.slice(0,o):n,l=o>=0?n.slice(o+1):"";if(!/^\/?assets\/.+\.html?$/i.test(s))return e;const r=new URLSearchParams(l);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${s}?${r.toString()}${i}`)}function Ca(e){const t=hm(e);return t.external||!t.url?t:{url:pm(t.url),external:!1}}function hm(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(sl(t))return{url:`/${rl(t)}`,external:!1};if(/^file:/i.test(t)){const n=jr(_a(t));return n?{url:n,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const n=jr(t);return n?{url:n,external:!1}:{url:t,external:!0}}return dm.test(t)?{url:t,external:!0}:fm(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const mm={class:"spm-webview-drawer"},gm={class:"spm-webview-toolbar"},vm={class:"spm-webview-toolbar__nav"},bm=["disabled"],ym=["disabled"],km=["aria-label"],wm={class:"spm-webview-toolbar__address"},xm=["aria-label"],Sm={class:"spm-webview-toolbar__actions"},_m=["aria-label"],Cm={class:"spm-zoom-controller"},$m=["disabled"],Im=["disabled"],Em={key:1,class:"spm-webview-fallback"},Tm=["src"],Am={key:2,class:"spm-load-error"},Bm={class:"spm-load-error__code"},Mm={class:"spm-load-error__code-num"},Dm={class:"spm-load-error__url"},Lm={class:"spm-load-error__hint"},Om={class:"spm-load-error__actions"},Wr="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",$a="siyuan-slidev-peek-view-mode";let Ia="desktop";function Pm(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem($a);if(e==="mobile"||e==="desktop")return e}catch{}return Ia}function Rm(e){if(Ia=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem($a,e)}catch{}}function Nm(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const zm=xt({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,o=he(ka()&&!Nf()),s=he(n.url),l=he(n.url),r=n.url,a=he(!1),c=he(null),d=he(!1),p=he(!1),v=he(1),u=he(!1),h=he(Pm());let f=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const b=xe(()=>h.value==="mobile"?Wr:f||void 0),k=he(null),x=he(null);let _=null,A=null,M=null;Li(()=>n.url,Y=>{Y&&Y!==s.value&&(s.value=Y,l.value=Y,h.value==="mobile"&&z(!1),k.value&&typeof k.value.loadURL=="function"&&k.value.loadURL(Y))}),Li(()=>n.visible,Y=>{if(Y)ie(),h.value==="mobile"&&z(!1);else if(k.value)try{typeof k.value.stop=="function"&&k.value.stop()}catch{}}),Hn(()=>{E(),x.value&&typeof ResizeObserver<"u"&&(_=new ResizeObserver(()=>{const Y=k.value;if(Y&&typeof Y.invalidate=="function")try{Y.invalidate()}catch{}}),_.observe(x.value)),A=Y=>{var O;const ce=Y.message||((O=Y.error)==null?void 0:O.message);if(typeof ce=="string"&&ce.includes("Invalid guestInstanceId"))return Y.preventDefault(),Y.stopImmediatePropagation(),!0},window.addEventListener("error",A,!0),M=Y=>{const ce=Y.reason,O=typeof ce=="string"?ce:ce==null?void 0:ce.message;typeof O=="string"&&O.includes("Invalid guestInstanceId")&&Y.preventDefault()},window.addEventListener("unhandledrejection",M)}),Fs(()=>{if(w(),_&&(_.disconnect(),_=null),A&&(window.removeEventListener("error",A,!0),A=null),M&&(window.removeEventListener("unhandledrejection",M),M=null),k.value)try{typeof k.value.stop=="function"&&k.value.stop()}catch{}});function E(){const Y=k.value;Y&&(Y.addEventListener("dom-ready",P),Y.addEventListener("did-start-loading",G),Y.addEventListener("did-stop-loading",y),Y.addEventListener("did-navigate",B),Y.addEventListener("did-navigate-in-page",F),Y.addEventListener("new-window",T),Y.addEventListener("did-fail-load",S),Y.addEventListener("did-fail-provisional-load",S))}function w(){const Y=k.value;if(Y)try{Y.removeEventListener("dom-ready",P),Y.removeEventListener("did-start-loading",G),Y.removeEventListener("did-stop-loading",y),Y.removeEventListener("did-navigate",B),Y.removeEventListener("did-navigate-in-page",F),Y.removeEventListener("new-window",T),Y.removeEventListener("did-fail-load",S),Y.removeEventListener("did-fail-provisional-load",S)}catch{}}function P(){const Y=k.value;if(Y&&typeof Y.getUserAgent=="function"&&!f)try{const ce=Y.getUserAgent();ce&&!ce.includes("iPhone")&&(f=ce)}catch{}h.value==="mobile"&&z(!1),ie(),D()}function R(){const Y=h.value==="mobile"?"desktop":"mobile";h.value=Y,Rm(Y),z(!0)}function z(Y=!1){const ce=k.value;if(!ce)return;const O=h.value==="mobile"?Wr:f;if(typeof ce.setUserAgent=="function"&&O)try{ce.setUserAgent(O)}catch(j){console.warn("[WebviewPeekDrawer] setUserAgent error:",j)}if(Y&&typeof ce.reload=="function")try{ce.reload()}catch(j){console.warn("[WebviewPeekDrawer] reload error:",j)}}function G(){a.value=!0,c.value=null}function S(Y){if(Y&&Y.isMainFrame===!1||Y&&Number(Y.errorCode)===-3)return;const ce=String((Y==null?void 0:Y.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((Y==null?void 0:Y.errorCode)??0),description:ce,validatedURL:String((Y==null?void 0:Y.validatedURL)||s.value),hint:Nm(ce)},a.value=!1}function L(){c.value=null,Z()}function y(){if(a.value=!1,D(),k.value&&typeof k.value.getURL=="function"){const Y=k.value.getURL();Y&&Y!=="about:blank"&&(s.value=Y,l.value=Y)}}function B(Y){Y!=null&&Y.url&&(s.value=Y.url,l.value=Y.url),D()}function F(Y){Y!=null&&Y.url&&(s.value=Y.url,l.value=Y.url),D()}function T(Y){Y&&Y.url&&(Y.preventDefault(),k.value&&typeof k.value.loadURL=="function"&&k.value.loadURL(Y.url))}function D(){const Y=k.value;Y&&(typeof Y.canGoBack=="function"&&(d.value=Y.canGoBack()),typeof Y.canGoForward=="function"&&(p.value=Y.canGoForward()))}function N(){k.value&&typeof k.value.goBack=="function"&&k.value.goBack()}function X(){k.value&&typeof k.value.goForward=="function"&&k.value.goForward()}function Z(){k.value&&typeof k.value.reload=="function"&&k.value.reload()}function U(){const Y=Ca(l.value);if(Y.url){if(Y.external){s.value=Y.url,ae();return}s.value=Y.url,l.value=Y.url,k.value&&typeof k.value.loadURL=="function"&&k.value.loadURL(Y.url)}}function ie(){const Y=k.value;if(Y&&typeof Y.setZoomFactor=="function")try{Y.setZoomFactor(v.value)}catch(ce){console.warn("[WebviewPeekDrawer] setZoomFactor error:",ce)}}function se(){v.value=Math.min(2.5,Math.round((v.value+.1)*10)/10),ie()}function le(){v.value=Math.max(.5,Math.round((v.value-.1)*10)/10),ie()}function ve(){v.value=1,ie()}function Te(Y){Y.preventDefault(),Y.deltaY<0?se():Y.deltaY>0&&le()}async function ye(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(s.value),u.value=!0,setTimeout(()=>{u.value=!1},2e3)}catch(Y){console.warn("Copy url failed:",Y)}}function ae(){var ce;const Y=s.value;if(typeof window<"u"){const O=Ct("electron");(ce=O==null?void 0:O.shell)!=null&&ce.openExternal?O.shell.openExternal(Y).catch(()=>{window.open(Y,"_blank")}):window.open(Y,"_blank")}i("external-jump",Y)}return(Y,ce)=>{const O=qd("webview");return ee(),te("div",mm,[m("div",gm,[m("div",vm,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!d.value,"aria-label":"后退",onClick:N},[re(de,{name:"arrow-left"})],8,bm),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!p.value,"aria-label":"前进",onClick:X},[re(de,{name:"arrow-right"})],8,ym),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":a.value?"正在加载...":"刷新页面",onClick:Z},[re(de,{name:"refresh"})],8,km)]),m("div",wm,[Tt(m("input",{"onUpdate:modelValue":ce[0]||(ce[0]=j=>l.value=j),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:cf(U,["enter"])},null,544),[[_o,l.value]]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":u.value?"已复制地址！":"复制网址",onClick:ye},[re(de,{name:"copy"})],8,xm)]),m("div",Sm,[m("button",{class:_e(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":h.value==="mobile"}]),"aria-label":h.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:R},[re(de,{name:h.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,_m),m("div",Cm,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:v.value<=.5,onClick:le},[re(de,{name:"minus"})],8,$m),m("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:ve},we(Math.round(v.value*100))+"% ",1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:v.value>=2.5,onClick:se},[re(de,{name:"plus"})],8,Im)]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:ae},[re(de,{name:"external-link"}),ce[1]||(ce[1]=m("span",null,"外跳",-1))])])]),m("div",{ref_key:"containerEl",ref:x,class:_e(["spm-webview-body",{"is-mobile":h.value==="mobile"}]),onWheel:Lt(Te,["ctrl"])},[m("div",{class:_e(["spm-webview-viewport",{"is-mobile":h.value==="mobile"}])},[o.value?(ee(),Ot(O,{key:0,ref_key:"webviewRef",ref:k,class:"spm-webview-frame",src:ge(r),useragent:b.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(ee(),te("div",Em,[m("iframe",{class:"spm-webview-fallback-frame",src:s.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Tm),m("div",{class:"spm-fallback-bar"},[ce[2]||(ce[2]=m("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),m("button",{class:"spm-icon-btn is-primary",onClick:ae}," 在新标签页中打开 ↗ ")])])),c.value?(ee(),te("div",Am,[re(de,{name:"alert",class:"spm-load-error__icon"}),ce[5]||(ce[5]=m("div",{class:"spm-load-error__title"},"页面加载失败",-1)),m("div",Bm,[$t(we(c.value.description)+" ",1),m("span",Mm,"("+we(c.value.errorCode)+")",1)]),m("div",Dm,we(c.value.validatedURL),1),m("p",Lm,we(c.value.hint),1),m("div",Om,[m("button",{class:"spm-icon-btn","aria-label":"重试",onClick:L},[re(de,{name:"refresh"}),ce[3]||(ce[3]=m("span",null,"重试",-1))]),m("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:ae},[re(de,{name:"external-link"}),ce[4]||(ce[4]=m("span",null,"用系统浏览器打开 ↗",-1))])])])):Oe("",!0)],2)],34)])}}}),Fm=Mt(zm,[["__scopeId","data-v-192d3665"]]);class Hm{constructor(){be(this,"timers",new Map)}debounce(t,i,n=150){this.cancel(t);const o=setTimeout(()=>{this.timers.delete(t),i()},n);this.timers.set(t,o)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class jm{constructor(t){be(this,"blockToPageMap",new Map);be(this,"debounceCtrl",new Hm);be(this,"activeBlockId","");be(this,"activePageIndex",1);be(this,"currentDocId","");be(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t}updateSlidesIndex(t){this.blockToPageMap.clear();for(const i of t){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const n of i.blocks)this.blockToPageMap.set(n.id,i.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;this.activeBlockId=t;let i=this.getPageByBlockId(t);!i&&(t===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t;const i=this.getPageByBlockId(t);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Oi(e,t){var s,l;if(!e||typeof document>"u")return!1;const i=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!n){if(t)try{return pe.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(r){console.warn("[SelectionMirror] openTab fallback failed:",r)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const o=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=o},1200),!0}function Wm(e){if(!e)return"";const t=e.split(`
`).map(l=>l.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(l=>/^#{1,6}\s+/.test(l)))return t.map(l=>rt(l)).join("<br/>");const n=[];let o=[];const s=()=>{if(o.length>0){const l=o.map(r=>rt(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${l}</p>`),o=[]}};for(const l of t){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){s();const a=r[1].length,c=r[2].trim();n.push(`<h${a} class="slide-list-item-title">${rt(c)}</h${a}>`)}else o.push(l)}return s(),n.join(`
`)}function Um(e){if(e.length===0)return"";const t=[],i=e[0],n=i.match(/^(#{1,6})\s+(.*)$/);if(n){const o=n[1].length,s=n[2].trim();t.push(`<h${o} class="slide-list-item-title">${rt(s)}</h${o}>`)}else t.push(`<p class="slide-list-item-title">${rt(i)}</p>`);if(e.length>1){const o=e.slice(1);let s=[];const l=()=>{if(s.length>0){const r=s.map(a=>rt(a)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),s=[]}};for(const r of o){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,d=a[2].trim();t.push(`<h${c} class="slide-list-item-title">${rt(d)}</h${c}>`)}else s.push(r)}l()}return t.join(`
`)+(t.length>0?`
`:"")}function Ea(e,t,i){var v,u,h,f;const n=e.split(`
`);if(!n.some(b=>/^(\s*)([-*+]|\d+\.)\s+/.test(b)))return null;const s=[],l=[];let r=!1;for(let b=0;b<n.length;b++){const k=n[b];if(!k.trim())continue;const x=k.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(x){const E=x[1].length,w=Math.floor(E/2);l.push({type:"task",level:w,checked:x[2].toLowerCase()==="x",text:x[3],media:[]});continue}const _=k.match(/^(\s*)[-*+]\s+(.*)$/);if(_){const E=_[1].length,w=Math.floor(E/2);l.push({type:"unordered",level:w,text:_[2],media:[]});continue}const A=k.match(/^(\s*)\d+\.\s+(.*)$/);if(A){l.length===0&&(r=!0);const E=A[1].length,w=Math.floor(E/2);l.push({type:"ordered",level:w,text:A[2],media:[]});continue}const M=k.trim();if(!(!M||/^\{:.*?\}$/.test(M)))if(l.length>0){const E=M.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(E){const R=/\.gif(?:\?|$)/i.test(E[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${at(E[1])}" src="${E[2]}" class="${R}" /></div>`);continue}if(M.match(/^<img\b[\s\S]*?\/?>$/i)){const P=M.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${P}</div>`);continue}if(/<video\b/i.test(M)){let P=M;if(!/<\/video>/i.test(P))for(;b+1<n.length&&!/<\/video>/i.test(P);)b++,P+=" "+n[b].trim();const R=((v=i==null?void 0:i.attributes)==null?void 0:v["custom-slidev-autoplay"])==="true"||/autoplay/i.test(P),z=((u=i==null?void 0:i.attributes)==null?void 0:u["custom-slidev-loop"])==="true"||/loop/i.test(P),G=((h=i==null?void 0:i.attributes)==null?void 0:h["custom-slidev-muted"])==="true"||R||/muted/i.test(P),S=((f=i==null?void 0:i.attributes)==null?void 0:f["custom-slidev-controls"])==="false",L=P.match(/\bsrc=["']([^"']+)["']/i),y=L?L[1]:"",B=['class="slide-video-player"'];S||B.push("controls"),R&&(B.push("autoplay"),B.push("playsinline")),z&&B.push("loop"),G&&B.push("muted"),B.push('preload="metadata"'),y&&B.push(`src="${y}"`);const F=P.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let T=F?F[1].trim():"";!T&&y&&(T=`<source src="${y}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${R?"true":"false"}" data-muted="${G?"true":"false"}"><video ${B.join(" ")}>${T}</video></div>`);continue}l[l.length-1].text+=`
`+M}else s.push(M)}if(l.length===0)return null;const a=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),d=l.map(b=>{const k=Wm(b.text),x=b.media&&b.media.length>0?`
${b.media.join(`
`)}`:"",_=b.level||0,A=_>0?` style="margin-left:${(_*1.25).toFixed(2)}em;${b.type==="unordered"?`list-style-type:${_%2===1?"circle":"square"} !important;`:""}"`:"",M=_>0?" slide-list-item--nested":"";if(b.type==="task"){const w=b.checked?' checked=""':"";return`<li class="pdf-task-item${M}"${A}><label><input type="checkbox" disabled=""${w}/> <span>${k}</span></label>${x}</li>`}return`<li${M?` class="${M.trim()}"`:""}${A}>${k}${x}</li>`}).join(`
`);return`${Um(s)}<${a} class="${c}">
${d}
</${a}>`}function Vm(e,t,i){const n=(t==null?void 0:t.containerClassName)||"pdf-block",o=e.split(/\r?\n/),s=[];let l=[];for(let c=0;c<o.length;c++){const d=o[c],p=d.trim();if(/^#{1,6}\s+/.test(p)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(p);continue}if(!p){l.length>0&&(s.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(p)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(p);continue}if(/<video\b/i.test(p)){l.length>0&&(s.push(l.join(`
`)),l=[]);let v=p;if(!/<\/video>/i.test(v))for(;c+1<o.length&&!/<\/video>/i.test(v);)c++,v+=`
`+o[c];s.push(v);continue}l.push(d)}l.length>0&&s.push(l.join(`
`));let r=!0;return s.map(c=>{var h,f,b,k;const d=c.trim();if(!d)return"";const p=d.match(/^(#{1,6})\s+(.*)$/);if(p){r=!1;const x=p[1].length;return`<h${x} class="slide-list-item-title">${rt(p[2].trim())}</h${x}>`}const v=d.match(/^!\[(.*?)\]\((.*?)\)$/);if(v){const x=/\.gif(?:\?|$)/i.test(v[2]),_=(t==null?void 0:t.imageClassName)||(x?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${at(v[1])}" src="${v[2]}" class="${_}" /></div>`}if(/<video\b/i.test(d)){const x=((h=i==null?void 0:i.attributes)==null?void 0:h["custom-slidev-autoplay"])==="true"||/autoplay/i.test(d),_=((f=i==null?void 0:i.attributes)==null?void 0:f["custom-slidev-loop"])==="true"||/loop/i.test(d),A=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slidev-muted"])==="true"||x||/muted/i.test(d),M=((k=i==null?void 0:i.attributes)==null?void 0:k["custom-slidev-controls"])==="false",E=d.match(/\bsrc=["']([^"']+)["']/i),w=E?E[1]:"",P=['class="slide-video-player"'];M||P.push("controls"),x&&P.push("autoplay playsinline"),_&&P.push("loop"),A&&P.push("muted"),P.push('preload="metadata"'),w&&P.push(`src="${w}"`);const R=d.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let z=R?R[1].trim():"";return!z&&w&&(z=`<source src="${w}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${x?"true":"false"}" data-muted="${A?"true":"false"}"><video ${P.join(" ")}>${z}</video></div>`}const u=Ea(d,t,i);if(u)return r=!1,u;if(r){r=!1;const x=d.split(/\r?\n/).map(E=>E.trim()).filter(Boolean);if(x.length===1)return`<p class="slide-list-item-title">${rt(x[0])}</p>`;const _=x[0],M=x.slice(1).map(E=>rt(E)).join("<br/>");return`<p class="slide-list-item-title">${rt(_)}</p>
<p class="slide-list-item-desc">${M}</p>`}return`<p class="slide-list-item-desc">${rt(d)}</p>`}).filter(Boolean).join(`
`)}function ts(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function Km(e,t){var r,a,c,d,p,v,u,h;const i=((r=e.frontmatter)==null?void 0:r.layout)||"default",o=(e.blocks||[]).filter(f=>f.slot!=="slot-divider-right"),l=i==="cover"?null:o.find(ts);if(i==="two-cols"){const f=o.some(G=>G.slot==="right");let b=[],k=[];if(f)b=o.filter(G=>G.slot!=="right"),k=o.filter(G=>G.slot==="right");else{const G=Math.ceil(o.length/2);b=o.slice(0,G),k=o.slice(G)}const x=G=>{const S=G.filter(L=>!!(L.rawMarkdown||L.content||"").trim());if(S.length>0){const L=S[0],y=(L.rawMarkdown||L.content||"").trim();(Ri(L)||/^(?:[-*+]|\d+\.)\s+/.test(y))&&(L.rawMarkdown=Sn(L.rawMarkdown||L.content||""),L.content=L.rawMarkdown)}};x(b),x(k);const _=b.map(G=>fi(G,t)).join(`
`),A=k.map(G=>fi(G,t)).join(`
`),M="pdf-two-cols-wrapper layout-two-cols-grid",E=(a=e.frontmatter)!=null&&a.layoutClass?` ${e.frontmatter.layoutClass}`:"",w="pdf-col pdf-col--left",P="pdf-col pdf-col--right",z=`style="grid-template-columns: ${Qo((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${M}${E}" ${z}>
        <div class="${w}">${_}</div>
        <div class="${P}">${A}</div>
      </div>
    `}if(i==="clover"||An(i)){const f=i==="clover";let b=[];const k=o.filter(B=>B.slot==="header");if(k.length>0)b=k;else if(o.length>0){const B=o.find(F=>F.type==="h"&&(!F.slot||F.slot==="default"));B&&(b=[B])}const x=o.filter(B=>!b.includes(B));let _=2;if(f)_=4;else if(i==="three-cols-header")_=3;else if(i==="two-cols-header")_=2;else{let B=0;for(const F of x){const T=(F.slot||"").match(/^col-(\d+)$/i);T&&(B=Math.max(B,parseInt(T[1],10)))}if(B>=2)_=B;else if((d=e.frontmatter)!=null&&d.layoutRatio){const F=e.frontmatter.layoutRatio.trim();if(F.includes(":")){const T=F.split(":").map(D=>parseFloat(D.trim())).filter(D=>!isNaN(D)&&D>0);T.length>=2&&(_=T.length)}else{const T=F.split(/\s+/).filter(Boolean);T.length>=2&&(_=T.length)}}else x.length===1&&x[0].children&&x[0].children.length>=2&&(_=Math.min(6,x[0].children.length))}const A=ya(x,_),M=x.some(B=>B.slot&&/^(?:col-\d+|left|right)$/i.test(B.slot)),E=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||An(i)&&M,w=B=>{const F=B.filter(D=>!!(D.rawMarkdown||D.content||"").trim());if(E&&F.length>0){const D=F[0],N=(D.rawMarkdown||D.content||"").trim();(Ri(D)||/^(?:[-*+]|\d+\.)\s+/.test(N))&&(D.rawMarkdown=Sn(D.rawMarkdown||D.content||""),D.content=D.rawMarkdown),D.isColFirst=!0}const T=E?F.find(ts):null;return F.map(D=>fi(D,{...t,extraClassName:D===T?"slidev-col-first-heading-block":""})).join(`
`)},P=b.find(ts),R=b.map(B=>fi(B,{...t,extraClassName:B===P?"slidev-page-first-heading-block":""})).join(`
`),z=f?"repeat(2, minmax(0, 1fr))":Qo((p=e.frontmatter)==null?void 0:p.layoutRatio,_),G=f?`style="grid-template-columns: ${z}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${z};"`,S=[f?"layout-clover-container":"layout-cols-header-container",_===2?"layout-two-cols-header-container":"",_===3?"layout-three-cols-header-container":"",`layout-${i}-container`,E?"has-superblock-cols":""].filter(Boolean).join(" "),L=[f?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",_===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",_===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",E?"has-superblock-cols":""].filter(Boolean).join(" "),y=A.map((B,F)=>{const T=F+1;return`<div class="${["pdf-col",_===2&&T===1?"pdf-col--left":"",_===2&&T===2?"pdf-col--right":"",`pdf-col--${T}`,`col-${T}`].filter(Boolean).join(" ")}">${w(B)}</div>`}).join(`
`);return`
      <div class="${S}">
        <div class="layout-header-section">${R}</div>
        <div class="${L}" ${G}>
          ${y}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const f=i==="image-right",b=o.map(E=>fi(E,t)).join(`
`),k=((v=e.frontmatter)==null?void 0:v.image)||((u=e.frontmatter)==null?void 0:u.background)||"",x=`<div class="pdf-image-col" style="background-image:url('${at(k)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${at(k)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,_=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${b}</div>`,A=f?`${_}
${x}`:`${x}
${_}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${Qo((h=e.frontmatter)==null?void 0:h.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${A}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${o.map(b=>fi(b,t)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${o.map(b=>fi(b,t)).join(`
`)}</div>`:o.map(f=>fi(f,{...t,extraClassName:f===l?"slidev-page-first-heading-block":""})).join(`
`)}function at(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function qm(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,i=e.split("|");for(const n of i){const o=n.trim();if(o==="all")return"all";if(o.includes("-")){const[s,l]=o.split("-"),r=parseInt(s,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)t.add(c)}else{const s=parseInt(o,10);isNaN(s)||t.add(s)}}return t}const Gm=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function rt(e){if(!e)return"";const t=ga(e),i=[],n=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,l)=>{const r=l.toLowerCase();if(!Gm.has(r)||/on\w+\s*=|javascript:/i.test(s))return s;if(r==="v-mark"){const a=s.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return s.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(s),`%%SAFE_HTML_${i.length-1}%%`});let o=at(n);return o=o.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,l,r,a,c,d,p)=>{const u=(r??a??c??d??p??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${u}</a>`}),o=o.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),o=o.replace(/\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),o=o.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${r}</a>`),o=o.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),o=o.replace(/\*(.*?)\*/g,"<em>$1</em>"),o=o.replace(/~~(.*?)~~/g,"<del>$1</del>"),o=o.replace(/`([^`]+)`/g,"<code>$1</code>"),o=o.replace(/%%SAFE_HTML_(\d+)%%/g,(s,l)=>{const r=parseInt(l,10);return i[r]||""}),o}function Zm(e,t="pdf-table"){if(e.length<2)return"";const i=e.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=i[0];let o=[],s=1;e.length>=2&&i[1].every(a=>/^:?-+:?$/.test(a))&&(o=i[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),s=2);const l=`<thead><tr>${n.map((a,c)=>`<th${o[c]?` style="text-align: ${o[c]}"`:""}>${rt(a)}</th>`).join("")}</tr></thead>`,r=i.slice(s).map(a=>`<tr>${a.map((c,d)=>`<td${o[d]?` style="text-align: ${o[d]}"`:""}>${rt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${l}<tbody>${r}</tbody></table>`}function is(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Ur(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${is(e)}</span>`;const i=[];function n(s,l){return i.push(`<span class="${s}">${is(l)}</span>`),`__TOK_${i.length-1}__`}let o=e.replace(/(['"`])(.*?)\1/g,(s,l,r)=>n("token-string",`${l}${r}${l}`));return o=o.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,s=>n("token-keyword",s)),o=o.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,s=>n("token-type",s)),o=o.replace(/\b(\d+)\b/g,s=>n("token-number",s)),o=is(o),o=o.replace(/__TOK_(\d+)__/g,(s,l)=>i[parseInt(l,10)]||""),o}function Ym(e,t){if(!e)return null;const i=e.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let n=(i.title||"").trim(),o=i.level?parseInt(i.level,10):0;if(!n){const s=e.blocks||[];for(const l of s){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){o||(o=a[1].length),n=a[2].trim();break}}}return n?((!o||isNaN(o))&&(o=1),{pageIndex:e.pageIndex||t,title:n,level:o}):null}function Jm(e,t=1,i={}){const n=i.minDepth!==void 0?Number(i.minDepth):1,o=i.maxDepth!==void 0?Number(i.maxDepth):1/0,s=[];Array.isArray(e)&&e.forEach((c,d)=>{const p=Ym(c,d+1);p&&s.push(p)});const l=[];let r=null;for(const c of s){const d={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),r=d):r?(d.active&&(r.hasActiveChild=!0),r.children.push(d)):l.push(d)}function a(c,d=1){if(d>o)return[];const p=[];for(const v of c){const u=a(v.children,d+1);d>=n?p.push({...v,children:u}):p.push(...u)}return p}return a(l,1)}function Xm(e,t=1,i={}){const n=Jm(e,t,i),o=i.columns?Number(i.columns):1,s=o>1?` style="column-count: ${o};"`:"",l=i.textSm?" text-sm":"";function r(c,d=1){if(!c||c.length===0)return"";const p=`slidev-toc-list slidev-toc-list-level-${d}`,v=c.map(u=>{const h=u.active?" slidev-toc-item-active":u.hasActiveChild?" slidev-toc-item-parent-active":"",f=u.children&&u.children.length>0?r(u.children,d+1):"";let b=rt(u.title);return b.includes("LaTeX")&&(b=b.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${h}" data-page="${u.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${b}</span>
          </a>
          ${f}
        </li>
      `}).join("");return`<ol class="${p}">${v}</ol>`}const a=r(n,1);return`<div class="slidev-toc${l}"${s}>${a}</div>`}function fi(e,t){var _,A,M,E,w,P,R,z,G,S;let i="",n="",o="";const s=[];(_=e.motion)!=null&&_.preset&&e.motion.preset!=="none"&&(i=` slidev-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&s.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&s.push(`--motion-delay:${e.motion.delay}ms`));const l=((A=e.attributes)==null?void 0:A.style)||"";l&&(s.push(l),o=" slide-styled-block"),s.length>0&&(n=` style="${at(s.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",a=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=`${r}${i}${o}${a}`,d=(e.rawMarkdown||e.content||"").trim();if(!d)return`<div class="${c}"${n}></div>`;if(d.includes('class="slidev-block-ref"')||d.includes('class="slidev-ref-tag"'))return`<div class="${c}"${n}>${d}</div>`;if(d.startsWith("$$")&&d.endsWith("$$")){const L=d.slice(2,-2).trim();return`<div class="${c} katex-display-container"${n}><div class="katex-display font-math"><em>${at(L)}</em></div></div>`}const p=d.match(/^(#{1,6})\s+(.*)$/);if(p){const L=p[1].length,y=rt(p[2]),F=!!(e.isColFirst||e.type==="i"&&((M=t==null?void 0:t.extraClassName)!=null&&M.includes("slidev-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><h${L}${F}>${y}</h${L}></div>`}if(d.startsWith(":::")){const L=d.split(`
`),B=L[0].replace(/^:::\s*/,"").trim()||"info",F=L.slice(1,L[L.length-1].startsWith(":::")?-1:void 0).join(`
`),T=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${c}"${n}><div class="${T} ${T}--${B}"><div class="${T}-title">${B.toUpperCase()}</div><div class="${T}-body">${rt(F)}</div></div></div>`}if(d.startsWith("<<<")){const B=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((N,X)=>`<span class="code-line shiki-focus"><span class="line-no">${X+1}</span><span class="line-content">${Ur(N,"ts")}</span></span>`).join(`
`),F=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",T=((E=e.attrs)==null?void 0:E["custom-slidev-max-height"])||e.maxHeight||"",D=T?` style="max-height:${at(T)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${F}"${D}><span class="lang-badge">TS</span><code>${B}</code></pre></div>`}if(d.startsWith("<style")||d.startsWith("<!-- Inline style -->")||d.startsWith(`<!--
Notes`))return"";if(d.startsWith("```")){const L=d.split(`
`),y=L[0].slice(3).trim(),B=y.match(/^([^\s{\[]+)/),F=B?B[1]:"",T=y.match(/\[([^\]]+)\]/),D=T?T[1]:"",N=y.includes("twoslash"),X=e.shikiLines||((w=y.match(/\{([^}]+)\}/))==null?void 0:w[1])||"",Z=qm(X),U=L.length>2?L[L.length-1]==="```"?L.slice(1,-1):L.slice(1):[d.slice(3).replace(/```$/,"")],ie=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",se=D?`${ie} has-filename`:ie,le=Z!=="all",ve=U.map((ce,O)=>{const j=O+1,q=Z==="all"||Z.has(j)?"code-line shiki-focus":le?"code-line shiki-dimmed":"code-line";let $=(t==null?void 0:t.highlight)===!0?Ur(ce,F):at(ce);return N&&ce.includes("doubled.value = 2")?($=$.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${q}"><span class="line-no">${j}</span><span class="line-content">${$}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${q}"><span class="line-no">${j}</span><span class="line-content">${$}</span></span>`}).join(`
`),Te=F?`<span class="lang-badge">${at(F)}</span>`:"",ye=D?`<span class="code-filename">${at(D)}</span>`:"",ae=((P=e.attrs)==null?void 0:P["custom-slidev-max-height"])||e.maxHeight||"",Y=ae?` style="max-height:${at(ae)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${se}"${Y}>${ye}${Te}<code>${ve}</code></pre></div>`}if(d.includes("|")&&d.split(`
`).filter(L=>L.trim().startsWith("|")).length>=2){const L=d.split(`
`).filter(B=>B.trim().startsWith("|")),y=Zm(L,t==null?void 0:t.tableClassName);return`<div class="${c}"${n}>${y}</div>`}if(d.startsWith("> ")){const L=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${c}"${n}><blockquote class="${L}"><p>${rt(d.slice(2))}</p></blockquote></div>`}const v=/<video\b/i.test(d)||e.type==="video"||e.type==="NodeVideo",u=/^(\s*)([-*+]|\d+\.)\s+/m.test(d),h=/(?:^|\n)\s*#{1,6}\s+/.test(d);if(v&&!u&&!h&&!d.includes(`
`)){const L=((R=e.attributes)==null?void 0:R["custom-slidev-autoplay"])==="true"||/autoplay/i.test(d),y=((z=e.attributes)==null?void 0:z["custom-slidev-loop"])==="true"||/loop/i.test(d),B=((G=e.attributes)==null?void 0:G["custom-slidev-muted"])==="true"||L||/muted/i.test(d),F=((S=e.attributes)==null?void 0:S["custom-slidev-controls"])==="false",T=d.match(/\bsrc=["']([^"']+)["']/i),D=T?T[1]:"",N=['class="slide-video-player"'];F||N.push("controls"),L&&(N.push("autoplay"),N.push("playsinline")),y&&N.push("loop"),B&&N.push("muted"),N.push('preload="metadata"'),D&&N.push(`src="${D}"`);const X=d.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let Z=X?X[1].trim():"";return!Z&&D&&(Z=`<source src="${D}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${c} ${c}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${L?"true":"false"}" data-muted="${B?"true":"false"}"${n}><video ${N.join(" ")}>${Z}</video></div>`}const f=d.match(/^!\[(.*?)\]\((.*?)\)$/);if(f){const L=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${c} ${c}--image slide-media-block slide-media-container"${n}><img alt="${at(f[1])}" src="${f[2]}" class="${L}" /></div>`}const b=Ea(d,t,e);if(b)return`<div class="${c} pdf-list-item"${n}>${b}</div>`;if(/<(?:Toc|toc)\b/i.test(d)&&!d.startsWith("```")){const L=d.match(/minDepth=["']?(\d+)["']?/i),y=d.match(/maxDepth=["']?(\d+)["']?/i),B=d.match(/columns=["']?(\d+)["']?/i),F=(t==null?void 0:t.allSlides)||[];return`<div class="${c}"${n}>${Xm(F,(t==null?void 0:t.currentPageIndex)||1,{minDepth:L?parseInt(L[1],10):1,maxDepth:y?parseInt(y[1],10):1/0,columns:B?parseInt(B[1],10):1,textSm:d.includes("text-sm")})}</div>`}if(d.includes(`
`)||h){const L=Vm(d,t,e);if(L)return`<div class="${c}"${n}>${L}</div>`}const x=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><p${x}>${rt(d)}</p></div>`}function Qm(e){return`
    ${Cn(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slidev-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slidev-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slidev-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slidev-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slidev-padding-y, 32px)) !important;
      padding-left: var(--slidev-padding-x, 48px) !important;
      padding-right: var(--slidev-padding-x, 48px) !important;
      padding-bottom: var(--slidev-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slidev-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slidev-mask-body-container--has-mask:first-child,
    .slide-content > .slidev-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slidev-padding-y, 32px)) !important;
      padding-top: var(--slidev-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slidev-padding-x: 0px !important;
      --slidev-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slidev-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slidev-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slidev-mask-layer--solid .slidev-mask-overlay,
    .slidev-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slidev-mask-layer--solid .slidev-mask-overlay,
    [data-theme="dark"] .slidev-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slidev-mask-layer--blur .slidev-mask-overlay,
    .slidev-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slidev-mask-layer--blur .slidev-mask-overlay,
    [data-theme="dark"] .slidev-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slidev-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slidev-mask-layer--down .slidev-mask-divider-line,
    .slidev-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slidev-mask-layer--right .slidev-mask-divider-line,
    .slidev-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }`}function eg(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function tg(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slidev-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slidev-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slidev-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slidev-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slidev-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slidev-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slidev-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slidev-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slidev-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slidev-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slidev-overview-canvas *{scrollbar-width:none;}.slidev-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slidev-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slidev-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slidev-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slidev-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function ig(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr) {
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: 2, breakpoints: [50, 100] };
        }
        const clean = ratioStr.trim();
        if (!clean) return { steps: 2, breakpoints: [50, 100] };
        const parts = clean.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
        if (parts.length === 0) return { steps: 2, breakpoints: [50, 100] };
        if (parts.length === 1) {
          const val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        const isMonotonic = parts.every((val, idx) => idx === 0 || val > parts[idx - 1]);
        const maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(p => p > 10))) {
          const bps = parts.map(p => Math.min(100, Math.round(p * 100) / 100));
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        const totalWeight = parts.reduce((acc, cur) => acc + cur, 0);
        if (totalWeight <= 0) return { steps: 2, breakpoints: [50, 100] };
        let accumulated = 0;
        const bps = [];
        for (let i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex - 1);
      }

`}function ng(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

`}function og(){return`      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        if (maskDir === "down" || maskDir === "right") {
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: maskDir,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          currentMaskStep = 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slidev-mask-layer slidev-mask-layer--" + currentMaskConfig.style + " slidev-mask-layer--" + currentMaskConfig.direction;
          const overlay = document.createElement("div");
          overlay.className = "slidev-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slidev-mask-divider-line";
          divider.style.opacity = "0";
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slidev-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slidev-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slidev-mask-body-container slidev-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slidev-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slidev-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slidev-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slidev-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function sg(){return`      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function rg(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function lg(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slidev-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slidev-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slidev-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background;
          if (bg) {
            if (/^(http|/|data:|assets/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slidev-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slidev-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slidev-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slidev-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slidev-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function ag(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slidev-viewport") || cur.classList.contains("slidev-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) return;
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slidev-lightbox-img, .slidev-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function cg(){return[eg(),tg(),ig(),ng(),og(),sg(),rg(),lg(),ag()].join("")}function Ta(e,t){const i="Slidev 演示文稿";let n=e.slides;const o=JSON.stringify(n),s=JSON.stringify(e.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${at(i)}</title>
  <style>
${Qm(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${o},
      config: ${s}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
    <div class="slide-viewport slidev-theme-${e.config.theme||"default"}" id="viewport" data-slidev-theme="${e.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${cg()}
  <\/script>
</body>
</html>`}function Aa(e,t){if(typeof document>"u")return!1;const i=new Blob([t],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(i),o=document.createElement("a");return o.href=n,o.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(o),o.click(),document.body.removeChild(o),URL.revokeObjectURL(n),!0}function dg(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function ug(e){const t=dg(e==null?void 0:e.pageRatio);return`
    ${Cn(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slidev-mask-layer,
      .slidev-mask-overlay,
      .slidev-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
      }
      .slidev-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function fg(e,t){const i="Slidev 演示讲义",n="16:9",o="light",s=e.slides.map((l,r)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,d=c&&c!=="inherit"?c:e.config.spacing||"normal",p=Km(l),v=`${r+1} / ${e.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${o} spacing-${d}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${at(i)}</span>
          ${`<span class="pdf-page-badge">P. ${v}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${p}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${at(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${at(i)} - 高保真讲义</title>
  <style>
    ${ug({pageRatio:n,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
  ${s}
</body>
</html>`}function Ba(e,t){var o;if(typeof window>"u"||typeof document>"u")return!1;const i=fg(e,t);try{const s=document.createElement("iframe");s.style.position="fixed",s.style.right="0",s.style.bottom="0",s.style.width="0",s.style.height="0",s.style.border="none",s.style.visibility="hidden",document.body.appendChild(s);const l=(o=s.contentWindow)==null?void 0:o.document;if(l)return l.open(),l.write(i),l.close(),setTimeout(()=>{var r,a;try{(r=s.contentWindow)==null||r.focus(),(a=s.contentWindow)==null||a.print()}finally{setTimeout(()=>{s.remove()},2e3)}},350),!0}catch(s){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",s)}const n=window.open("","_blank");return n?(n.document.write(i),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const pg=1500,hg=500,mg=4,gg=new Set(["INPUT","TEXTAREA","SELECT"]);function Ma(e){const t=e;return!t||!t.tagName?!1:gg.has(t.tagName)||t.isContentEditable===!0}function vg(e){let t="",i=!1,n=null,o=null;function s(){e.onStateChange&&e.onStateChange({display:t,invalid:i})}function l(){n&&(clearTimeout(n),n=null),o&&(clearTimeout(o),o=null)}function r(){l(),t="",i=!1,s()}function a(){n&&clearTimeout(n),n=setTimeout(r,pg)}function c(){n&&(clearTimeout(n),n=null),i=!0,s(),o&&clearTimeout(o),o=setTimeout(r,hg)}function d(p){if(e.isEnabled&&!e.isEnabled()||Ma(p.target)||p.isComposing||p.ctrlKey||p.metaKey||p.altKey)return!1;if(/^[0-9]$/.test(p.key))return i||t.length>=mg||(t+=p.key,s(),a()),!0;if(p.key==="Enter"){if(!t||i)return!1;const u=parseInt(t,10),h=e.getTotalPages();return!isNaN(u)&&u>=1&&h>0&&u<=h?(r(),e.onJump(u),!0):(c(),!0)}return p.key==="Escape"&&(t||i)?(r(),!0):!1}return{handleKeydown:d,getState:()=>({display:t,invalid:i}),clear:r}}const bg={class:"spm-slidev-tab__toolbar"},yg={class:"spm-slidev-tab__nav"},kg=["disabled"],wg={class:"spm-page-badge"},xg=["disabled"],Sg=["aria-label"],_g=["aria-label"],Cg={class:"spm-slidev-tab__tools"},$g=["src"],Ig=xt({__name:"SlidevPreviewTab",setup(e,{expose:t}){const i=ti("plugin"),n=ti("sandboxBridge",new Xs),o=new jm(n),s=new Zf,l=he("web-sandbox"),r=he(3030),a=he(null),c=he(!1),d=he(null),p=he(1),v=he(1),u=he([]),h=he(!1),f=he(!1),b=he(!1),k=he("siyuan"),x=he(""),_=he(""),A=he(""),M=he(!1),E=he(!1),w=he(""),P=he(""),R=he(!1),z=vg({getTotalPages:()=>v.value,isEnabled:()=>!f.value,onJump:C=>L(C),onStateChange:C=>{P.value=C.display,R.value=C.invalid}});function G(C){if(C.key==="o"||C.key==="O"){if(f.value||C.isComposing||C.ctrlKey||C.metaKey||C.altKey||Ma(C.target))return;C.preventDefault(),S();return}z.handleKeydown(C)&&C.preventDefault()}function S(){var C,W;if(l.value==="pro-cli"){(C=d.value)==null||C.focus(),pe.showMessage("Pro 模式使用官方原生总览：在画面内按 O 呼出");return}n.toggleOverview(),(W=d.value)==null||W.focus()}function L(C){var W;p.value=C,l.value==="pro-cli"?s.nativeBridge.navigateToPage(C):n.navigatePage(C),(W=d.value)==null||W.focus()}const y=he("/plugins/siyuan-slidev/slidev-client/index.html");let B=null,F=null,T=null,D=null,N=null,X=null,Z=null,U=null;Hn(()=>{d.value&&(n.attach(d.value),s.nativeBridge.attach(d.value)),B=n.onSlideChanged((C,W)=>{p.value=C,v.value=W}),F=n.onBlockClicked((C,W)=>{p.value=W,o.setActiveBlockId(C),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide(C,W):Oi(C,i==null?void 0:i.app)}),T=n.onOpenInEditor((C,W)=>{p.value=W,o.setActiveBlockId(C),Oi(C,i==null?void 0:i.app)}),D=s.nativeBridge.onPageChanged((C,W)=>{p.value=C,v.value=W}),N=n.onOpenPeekDrawer(async C=>{const W=zo();if(C.peekType==="siyuan"&&W.enableWebServeJump){let K=!1;if(U&&U.docId===C.target)K=!0;else if(U&&U.slides&&U.slides.some(V=>{var Q;return(Q=V.blocks)==null?void 0:Q.some(oe=>oe.id===C.target)}))K=!1;else try{const V=await tn(`SELECT id, root_id, type FROM blocks WHERE id = '${C.target}' LIMIT 1`);V&&V.length>0&&(K=V[0].type==="d"||V[0].id===V[0].root_id)}catch(V){console.warn("[SlidevPreviewTab] detect block type failed:",V)}k.value="web",M.value=!0,_.value=pa(W.webServeUrl,C.target,{focus:!K}),A.value=C.title||`${K?"思源文档":"思源块"}: ${C.target.slice(0,8)}`,f.value=!0,n.freezeKeyboardNav(!0)}else{if(k.value=C.peekType,C.peekType==="siyuan")x.value=C.target,A.value=C.title||`块速览: ${C.target.slice(0,8)}`;else{const K=Ca(C.target);if(K.external){j(C.target);return}M.value=!0,_.value=K.url,A.value=C.title||K.url}f.value=!0,n.freezeKeyboardNav(!0)}}),X=n.onRequestToggleFullscreen(()=>{q()}),Z=n.onOpenPresenter(()=>{H()}),typeof document<"u"&&document.addEventListener("fullscreenchange",g)}),Hs(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",g),N&&N(),X&&X(),Z&&Z(),B&&B(),F&&F(),T&&T(),D&&D(),n.detach(),z.clear(),o.destroy(),s.destroy()});async function ie(){if(l.value==="web-sandbox"){if(!U){pe.showMessage("请先在主编辑区打开演示文档");return}pe.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const C=await s.startProMode(U,ls);if(!C.success){pe.showMessage(`无法启动官方 Pro 模式：${C.error}`);return}l.value="pro-cli",r.value=C.port||3030,y.value=C.url,d.value&&s.nativeBridge.attach(d.value),pe.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else s.stopProMode(),l.value="web-sandbox",y.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&n.attach(d.value),pe.showMessage("已切回内置高保真沙箱")}function se(){E.value=!E.value,E.value?(w.value=(U==null?void 0:U.docId)||"",i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",w.value)):(w.value="",Y(),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader())}let le=0;function ve(C){if(f.value||Math.abs(C.deltaY)<Math.abs(C.deltaX)||Math.abs(C.deltaY)<15)return;const W=Date.now();W-le<280||(le=W,C.deltaY>0?ye():Te())}function Te(){if(p.value>1){const C=p.value-1;p.value=C,l.value==="pro-cli"?s.nativeBridge.navigateToPage(C):n.navigatePage(C)}}function ye(){if(p.value<v.value){const C=p.value+1;p.value=C,l.value==="pro-cli"?s.nativeBridge.navigateToPage(C):n.navigatePage(C)}}function ae(C){p.value=C,l.value==="pro-cli"?s.nativeBridge.navigateToPage(C):n.navigatePage(C)}function Y(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slidev:request-compile")}function ce(){f.value=!1,n.freezeKeyboardNav(!1)}function O(){ce()}function j(C){var Q,oe;const W=/^file:/i.test(C),K=W||/^[a-zA-Z]:[\\/]/.test(C),V=Ct("electron");if(K&&typeof((Q=V==null?void 0:V.shell)==null?void 0:Q.openPath)=="function"){V.shell.openPath(W?_a(C):C),pe.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((oe=V==null?void 0:V.shell)==null?void 0:oe.openExternal)=="function"?V.shell.openExternal(C).catch(()=>{typeof window<"u"&&window.open(C,"_blank")}):typeof window<"u"&&window.open(C,"_blank"),pe.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function g(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function q(){const C=a.value||d.value;C&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):C.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function H(){i&&typeof i.openPresenterTab=="function"&&i.openPresenterTab()}function $(){if(!U){pe.showMessage("请先在主编辑区打开幻灯片文档");return}const C=Ta(U);Aa("presentation.html",C)&&pe.showMessage("已开始下载单文件离线 HTML 演示包")}function I(){if(!U){pe.showMessage("请先在主编辑区打开幻灯片文档");return}Ba(U)&&pe.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return t({updateDocument(C,W){E.value&&w.value&&W&&W!==w.value||(U=C,E.value&&!w.value&&(w.value=C.docId),u.value=C.slides,v.value=C.slides.length,o.setDocId(C.docId),o.updateSlidesIndex(C.slides),l.value==="pro-cli"?s.scaffolder.scaffold(C,ls).catch(()=>{}):n.updateSlides(C.slides,C.config,C.fullMarkdown,C.customThemeCss),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",C.docId))},navigateToBlock(C){o.onCursorFocusBlock(C)},isPinned:E,pinnedDocId:w,engineMode:l,toggleEngineMode:ie}),(C,W)=>(ee(),te("div",{class:"spm-slidev-preview-tab",onKeydown:G},[m("div",bg,[m("div",yg,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value<=1,"aria-label":"上一页",onClick:Te},[re(de,{name:"chevron-left"})],8,kg),m("span",wg,we(p.value)+" / "+we(v.value||1),1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value>=v.value,"aria-label":"下一页",onClick:ye},[re(de,{name:"chevron-right"})],8,xg),m("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":E.value}]),"aria-label":E.value?"已锁定当前文档（点击解除）："+w.value:"点击锁定当前文档（不随主编辑区切换）",onClick:se},[re(de,{name:"pin"}),m("span",null,we(E.value?"已锁定":"跟随"),1)],10,Sg),m("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:ie},[re(de,{name:"rocket"}),m("span",null,we(l.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,_g)]),m("div",Cg,[m("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":h.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:W[0]||(W[0]=K=>h.value=!h.value)},[re(de,{name:"outline"})],2),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:S},[re(de,{name:"columns"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:H},[re(de,{name:"presenter"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:$},[re(de,{name:"export-html"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:I},[re(de,{name:"export-pdf"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:Y},[re(de,{name:"refresh"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:q},[re(de,{name:"fullscreen"})])])]),m("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container",onWheel:ve},[m("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:y.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,$g),re(em,{visible:f.value,"onUpdate:visible":W[1]||(W[1]=K=>f.value=K),"is-maximized":b.value,"onUpdate:isMaximized":W[2]||(W[2]=K=>b.value=K),title:A.value,onClose:ce},{default:Pl(()=>[k.value==="siyuan"&&x.value?(ee(),Ot(cm,{key:0,"block-id":x.value,title:A.value,plugin:ge(i),onExternalJump:O},null,8,["block-id","title","plugin"])):Oe("",!0),M.value?Tt((ee(),Ot(Fm,{key:1,visible:f.value&&k.value==="web",url:_.value,title:A.value,onExternalJump:O},null,8,["visible","url","title"])),[[ks,k.value==="web"]]):Oe("",!0)]),_:1},8,["visible","is-maximized","title"]),Tt(m("div",{class:_e(["spm-jump-badge",{"is-invalid":R.value}])},we(P.value),3),[[ks,P.value]])],544),h.value&&u.value.length>0?(ee(),Ot(Vh,{key:0,slides:u.value,"current-active-page":p.value,onNavigate:ae,onRefresh:Y},null,8,["slides","current-active-page"])):Oe("",!0)],32))}}),Eg=Mt(Ig,[["__scopeId","data-v-3d9b9312"]]),Tg={class:"spm-presenter-tab"},Ag=xt({__name:"SlidevPresenterTab",setup(e){return(t,i)=>(ee(),te("div",Tg,[...i[0]||(i[0]=[m("iframe",{class:"spm-presenter-tab__iframe",src:"/plugins/siyuan-slidev/slidev-client/presenter.html",frameborder:"0",allow:"fullscreen; autoplay"},null,-1)])]))}}),Bg=Mt(Ag,[["__scopeId","data-v-809e655c"]]),Mg={class:"spm-section spm-section--page"},Dg={class:"spm-section-header"},Lg={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},Og={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Pg={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},Rg={key:1,class:"spm-card-control"},Ng={class:"spm-control-header"},zg={class:"spm-control-title-group"},Fg={class:"spm-control-title"},Hg={class:"spm-quick-chips"},jg=["onClick"],Wg={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},Ug=["value"],Vg=["aria-label"],Kg={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__w",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},qg={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Gg={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},Zg={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Yg={class:"spm-card-control"},Jg={class:"spm-control-header"},Xg={class:"spm-control-title-group"},Qg={class:"spm-control-title"},ev={class:"spm-segmented-group"},tv={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},iv={style:{display:"flex","align-items":"center","justify-content":"space-between"}},nv={class:"b3-tooltips b3-tooltips__w","aria-label":`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},ov={class:"spm-quick-chips"},sv=["onClick"],rv={class:"b3-tooltips b3-tooltips__n",style:{width:"100%",display:"block"},"aria-label":"输入权重比例（如 1:2:1）或绝对累计百分比断点（如 25:75:100），冒号项数决定点击步数"},lv=["value"],av={style:{display:"flex",gap:"8px","margin-top":"2px"}},cv={style:{flex:"1"}},dv={class:"spm-segmented-group"},uv={style:{flex:"1"}},fv={class:"spm-segmented-group"},pv={class:"spm-card-control"},hv={class:"spm-control-header"},mv={class:"spm-control-title-group"},gv={class:"spm-control-title"},vv={class:"spm-segmented-group"},bv={class:"spm-card-control"},yv={class:"spm-control-header"},kv={class:"spm-control-title-group"},wv={class:"spm-control-title"},xv={class:"spm-quick-chips"},Sv=["onClick"],_v=["value"],Cv={key:2,class:"spm-card-control"},$v={class:"spm-control-header"},Iv={class:"spm-control-title-group"},Ev={class:"spm-control-title"},Tv={class:"spm-quick-chips"},Av=["onClick"],Bv=["value"],Mv={class:"spm-card-control"},Dv={class:"spm-control-header"},Lv={class:"spm-control-title-group"},Ov={class:"spm-control-title"},Pv={key:0,class:"spm-note-status-box"},Rv=["title"],Nv={class:"spm-action-grid",style:{"margin-top":"6px"}},zv={key:1,class:"spm-note-empty-box"},Fv={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},Hv={class:"spm-action-grid"},jv=["disabled"],Wv=["disabled"],Uv={class:"spm-card-control"},Vv={class:"spm-action-grid"},Kv=xt({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(e,{emit:t}){const i=e,n=t,o=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],s=xe(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),l=xe(()=>{var f,b;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const u=(i.pageLayoutRatio||"").trim();if(u.includes(":")){const k=u.split(":").filter(Boolean).length;if(k>=2&&k<=6)return k}const h=(i.detectedSbRatio||"").trim();if(h.includes(":")){const k=h.split(":").filter(Boolean).length;if(k>=2&&k<=6)return k}if((f=i.detectedSbInfo)!=null&&f.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((b=i.detectedSbInfo)!=null&&b.slots&&Array.isArray(i.detectedSbInfo.slots)){const k=i.detectedSbInfo.slots.length;if(k>=2&&k<=6)return k}return 2}),r=xe(()=>{const u=l.value;return u===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:u===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:u===5?[{label:"默认 1:1:1:1:1",value:""}]:u===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),a=xe(()=>i.pageLayoutRatio||"");function c(){const u=l.value||2,h=Array(u).fill("1").join(":");n("update:pageLayoutRatio",h),n("resetSuperblockRatio")}const d=xe(()=>{if(!i.pageNotes)return"";const u=i.pageNotes.replace(/[\r\n]+/g," ").trim();return u.length>50?u.slice(0,50)+"...":u}),p=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],v=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(u,h)=>(ee(),te("div",Mg,[m("div",Dg,[m("span",null,"幻灯片页面设置"+we(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),re(Sa,{"model-value":e.pageLayout,onChange:h[0]||(h[0]=f=>u.$emit("update:pageLayout",f))},null,8,["model-value"]),!s.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(ee(),te("div",Lg,[m("div",Og,[m("div",Pg,[re(de,{name:"sparkles"}),m("span",null,[h[31]||(h[31]=$t("检测到本页横向超级块列宽比例：",-1)),m("b",null,we(e.detectedSbRatio),1)])]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__w","aria-label":"一键将本页版式设为分栏并应用超级块列宽",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:h[1]||(h[1]=f=>u.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[re(de,{name:"columns"}),h[32]||(h[32]=m("span",null,"设为分栏",-1))])])])):Oe("",!0),s.value?(ee(),te("div",Rg,[m("div",Ng,[m("div",zg,[m("div",Fg,[re(de,{name:"ratio"}),h[33]||(h[33]=m("span",null,"分栏比例 (Ratio)",-1))]),h[34]||(h[34]=m("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),m("div",Hg,[(ee(!0),te(Ue,null,kt(r.value,f=>(ee(),te("button",{key:f.value,class:_e(["spm-chip",{active:a.value===f.value}]),onClick:b=>u.$emit("update:pageLayoutRatio",f.value)},we(f.label),11,jg))),128))]),m("div",Wg,[m("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:h[2]||(h[2]=f=>u.$emit("update:pageLayoutRatio",f.target.value)),onChange:h[3]||(h[3]=f=>u.$emit("update:pageLayoutRatio",f.target.value))},null,40,Ug),e.detectedSbRatio?(ee(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":`从当前页思源超级块读取实际宽度比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:h[4]||(h[4]=f=>u.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[re(de,{name:"sparkles"}),h[35]||(h[35]=m("span",null,"读取",-1))],8,Vg)):(ee(),te("button",Kg,[re(de,{name:"sparkles"}),h[36]||(h[36]=m("span",null,"读取",-1))])),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":"重置渲染比例为平均分布，并立即重置文档中超级块内容分布比例",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:c},[re(de,{name:"reset"}),h[37]||(h[37]=m("span",null,"重置",-1))])]),e.detectedSbRatio?(ee(),te("div",qg,[re(de,{name:"ratio"}),h[38]||(h[38]=m("span",null,"检测到思源超级块宽度：",-1)),m("code",Gg,we(e.detectedSbRatio),1)])):(ee(),te("div",Zg,[re(de,{name:"ratio"}),h[39]||(h[39]=m("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Oe("",!0),re(Qs,{"model-value":e.pageTransition,onChange:h[5]||(h[5]=f=>u.$emit("update:pageTransition",f))},null,8,["model-value"]),m("div",Yg,[m("div",Jg,[m("div",Xg,[m("div",Qg,[re(de,{name:"sparkles"}),h[40]||(h[40]=m("span",null,"页面动态蒙版 (Dynamic Mask)",-1))]),h[41]||(h[41]=m("span",{class:"spm-control-desc"},"随着点击操作分段展露正文内容",-1))])]),m("div",ev,[m("button",{class:_e(["spm-segmented-item",{active:!e.pageMask}]),onClick:h[6]||(h[6]=f=>u.$emit("update:pageMask",""))}," 关闭 ",2),m("button",{class:_e(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:h[7]||(h[7]=f=>u.$emit("update:pageMask","down"))}," 从上至下 ",2),m("button",{class:_e(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:h[8]||(h[8]=f=>u.$emit("update:pageMask","right"))}," 从左至右 ",2)]),e.pageMask?(ee(),te("div",tv,[m("div",iv,[h[43]||(h[43]=m("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),m("span",nv,[re(de,{name:"help"}),h[42]||(h[42]=m("span",null,"输入规则",-1))])]),m("div",ov,[(ee(),te(Ue,null,kt(o,f=>m("button",{key:f.value,class:_e(["spm-chip",{active:(e.pageMaskRatio||"1:1")===f.value}]),onClick:b=>u.$emit("update:pageMaskRatio",f.value)},we(f.label),11,sv)),64))]),m("div",rv,[m("input",{value:e.pageMaskRatio||"1:1",class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:h[9]||(h[9]=f=>u.$emit("update:pageMaskRatio",f.target.value)),onChange:h[10]||(h[10]=f=>u.$emit("update:pageMaskRatio",f.target.value))},null,40,lv)]),h[46]||(h[46]=m("div",{style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}}," 提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数 ",-1)),m("div",av,[m("div",cv,[h[44]||(h[44]=m("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),m("div",dv,[m("button",{class:_e(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:h[11]||(h[11]=f=>u.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),m("button",{class:_e(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:h[12]||(h[12]=f=>u.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),m("div",uv,[h[45]||(h[45]=m("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),m("div",fv,[m("button",{class:_e(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:h[13]||(h[13]=f=>u.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),m("button",{class:_e(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:h[14]||(h[14]=f=>u.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Oe("",!0)]),m("div",pv,[m("div",hv,[m("div",mv,[m("div",gv,[re(de,{name:"ratio"}),h[47]||(h[47]=m("span",null,"页面间距 (Spacing)",-1))]),h[48]||(h[48]=m("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),m("div",vv,[m("button",{class:_e(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:h[15]||(h[15]=f=>u.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),m("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="compact"}]),onClick:h[16]||(h[16]=f=>u.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),m("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="normal"}]),onClick:h[17]||(h[17]=f=>u.$emit("update:pageSpacing","normal"))}," 标准 ",2),m("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="loose"}]),onClick:h[18]||(h[18]=f=>u.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),m("div",bv,[m("div",yv,[m("div",kv,[m("div",wv,[re(de,{name:"palette"}),h[49]||(h[49]=m("span",null,"页面背景 (Background)",-1))]),h[50]||(h[50]=m("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),m("div",xv,[(ee(),te(Ue,null,kt(p,f=>m("button",{key:f.value,class:_e(["spm-chip",{active:e.pageBackground===f.value}]),onClick:b=>u.$emit("update:pageBackground",f.value)},we(f.label),11,Sv)),64))]),m("input",{value:e.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:h[19]||(h[19]=f=>u.$emit("update:pageBackground",f.target.value)),onChange:h[20]||(h[20]=f=>u.$emit("update:pageBackground",f.target.value))},null,40,_v)]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(ee(),te("div",Cv,[m("div",$v,[m("div",Iv,[m("div",Ev,[re(de,{name:"image"}),h[51]||(h[51]=m("span",null,"页面图片 (Image)",-1))]),h[52]||(h[52]=m("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),m("div",Tv,[(ee(),te(Ue,null,kt(v,f=>m("button",{key:f.value,class:_e(["spm-chip",{active:e.pageImage===f.value}]),onClick:b=>u.$emit("update:pageImage",f.value)},we(f.label),11,Av)),64))]),m("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:h[21]||(h[21]=f=>u.$emit("update:pageImage",f.target.value)),onChange:h[22]||(h[22]=f=>u.$emit("update:pageImage",f.target.value))},null,40,Bv)])):Oe("",!0),m("div",Mv,[m("div",Dv,[m("div",Lv,[m("div",Ov,[re(de,{name:"presenter"}),h[53]||(h[53]=m("span",null,"演讲者提词 (Notes)",-1))]),h[54]||(h[54]=m("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),m("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:h[23]||(h[23]=f=>u.$emit("generateNotes"))},[re(de,{name:"sparkles"}),h[55]||(h[55]=m("span",null,"AI 讲稿",-1))])]),e.pageNotes?(ee(),te("div",Pv,[h[58]||(h[58]=m("div",{class:"spm-note-status-badge"},[m("span",{class:"spm-badge-dot"}),m("span",null,"已配置正文讲稿")],-1)),m("div",{class:"spm-note-preview-text",title:e.pageNotes},we(d.value),9,Rv),m("div",Nv,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:h[24]||(h[24]=f=>u.$emit("locateNoteBlock"))},[re(de,{name:"search"}),h[56]||(h[56]=m("span",null,"定位讲稿块",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:h[25]||(h[25]=f=>u.$emit("addNoteBlock"))},[re(de,{name:"insert-below"}),h[57]||(h[57]=m("span",null,"追加讲稿块",-1))])])])):(ee(),te("div",zv,[h[60]||(h[60]=m("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:h[26]||(h[26]=f=>u.$emit("addNoteBlock"))},[re(de,{name:"insert-below"}),h[59]||(h[59]=m("span",null,"添加讲稿备注块",-1))])])),m("div",Fv,[m("div",Hv,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",disabled:e.isBatchProcessing,style:Bn(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:h[27]||(h[27]=f=>u.$emit("batchAppendNotes"))},[re(de,{name:"insert-below"}),h[61]||(h[61]=m("span",null,"全部追加",-1))],12,jv),m("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s",disabled:e.isBatchProcessing,style:Bn(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:h[28]||(h[28]=f=>u.$emit("batchDeleteNotes"))},[re(de,{name:"trash"}),h[62]||(h[62]=m("span",null,"全部删除",-1))],12,Wv)])])]),m("div",Uv,[h[65]||(h[65]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),m("div",Vv,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:h[29]||(h[29]=f=>u.$emit("insertDividerAfter"))},[re(de,{name:"insert-below"}),h[63]||(h[63]=m("span",null,"插入新页",-1))]),m("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:h[30]||(h[30]=f=>u.$emit("deleteDivider"))},[re(de,{name:"trash"}),h[64]||(h[64]=m("span",null,"删除此页",-1))])])])]))}}),qv=Mt(Kv,[["__scopeId","data-v-1f9d4630"]]),Gv={class:"spm-section spm-section--block"},Zv={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},Yv={class:"spm-control-header"},Jv={class:"spm-control-title-group"},Xv={class:"spm-control-title"},Qv={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},eb={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},tb={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},ib={key:0},nb={key:1},ob={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},sb={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},rb={class:"spm-action-grid"},lb={class:"spm-card-control"},ab={class:"spm-control-header"},cb={class:"spm-control-title-group"},db={class:"spm-control-title"},ub=["aria-label"],fb=["checked"],pb={key:1,class:"spm-card-control"},hb={class:"spm-control-header"},mb={class:"spm-control-title-group"},gb={class:"spm-control-title"},vb={class:"spm-quick-chips"},bb={key:2,class:"spm-card-control"},yb={class:"spm-control-header"},kb={class:"spm-control-title-group"},wb={class:"spm-control-title"},xb={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},Sb={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},_b={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Cb=["aria-label"],$b=["checked"],Ib={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Eb={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Tb=["aria-label"],Ab=["checked"],Bb={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Mb={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Db=["aria-label"],Lb=["checked"],Ob={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Pb={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Rb=["aria-label"],Nb=["checked"],zb={class:"spm-card-control"},Fb={class:"spm-control-header"},Hb={class:"spm-control-title-group"},jb={class:"spm-control-title"},Wb=["aria-label"],Ub=["checked"],Vb={key:0,class:"spm-quick-chips"},Kb=["onClick"],qb={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Gb={class:"spm-card-control"},Zb={class:"spm-control-header"},Yb={class:"spm-control-title-group"},Jb={class:"spm-control-title"},Xb=["aria-label"],Qb=["checked"],e1={key:0,class:"spm-quick-chips"},t1=["onClick"],i1={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},n1={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},o1={style:{display:"flex",gap:"6px"}},s1=["value"],r1=["value"],l1={key:3,class:"spm-card-control"},a1={class:"spm-control-header"},c1={class:"spm-control-title-group"},d1={class:"spm-control-title"},u1={class:"spm-control-desc"},f1={class:"spm-segmented-group"},p1=["onClick"],h1={key:4,class:"spm-card-control"},m1={class:"spm-control-header"},g1={class:"spm-control-title-group"},v1={class:"spm-control-title"},b1={class:"spm-quick-chips"},y1=["onClick"],k1=["value"],w1={key:5,class:"spm-card-control"},x1={class:"spm-control-header"},S1={class:"spm-control-title-group"},_1={class:"spm-control-title"},C1={class:"spm-quick-chips"},$1=["onClick"],I1=["value"],E1={class:"spm-card-control"},T1={class:"spm-action-grid"},A1=["aria-label"],B1=xt({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const i=e,n=xe(()=>{const E=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":E}),o=xe(()=>{const E=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(E)}),s=xe(()=>{var w,P,R,z;if((w=i.detectedSbInfo)!=null&&w.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const E=(P=i.elemSlot)==null?void 0:P.match(/^col-(\d+)$/);if(E){const G=parseInt(E[1],10);if(G>=2&&G<=6)return Math.max(G,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((z=(R=i.detectedSbInfo)==null?void 0:R.ratio)!=null&&z.includes(":")){const G=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(G.length>=2)return Math.min(G.length,6)}return 3}),l=xe(()=>{const E=n.value;return E==="cols-header"?"多栏插槽归属 (Slot)":E==="three-cols-header"?"三栏插槽归属 (Slot)":E==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),r=xe(()=>{const E=n.value;return E==="cols-header"?`在 cols-header 表头多栏（${s.value} 栏）中的内容块位置`:E==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":E==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":E==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=xe(()=>{const E=n.value;if(E==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(E==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(E==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const w=s.value,P=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let R=1;R<=w;R++)P.push({value:`col-${R}`,label:`第 ${R} 栏`});return P});function c(E){const w=i.elemSlot||"";return E?w===E||E==="col-1"&&w==="left"||E==="col-2"&&w==="center"||E==="col-3"&&w==="right"&&s.value===3||E==="col-2"&&w==="right"&&s.value===2||E==="left"&&w==="col-1"||E==="right"&&(w==="col-2"||w==="col-3"):!w||w==="default"}const d=t,p=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],v=xe(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const E=JSON.parse(i.elemMotion);if(typeof E=="object"&&E!==null)return{preset:E.preset||E.type||"slide-up",duration:typeof E.duration=="number"?E.duration:0,delay:typeof E.delay=="number"?E.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),u=xe(()=>!!v.value),h=xe(()=>{var E;return((E=v.value)==null?void 0:E.preset)||"slide-up"}),f=xe(()=>{var E;return((E=v.value)==null?void 0:E.duration)||0}),b=xe(()=>{var E;return((E=v.value)==null?void 0:E.delay)||0});function k(){u.value?d("update:elemMotion",""):d("update:elemMotion","slide-up")}function x(E){M(E,f.value,b.value)}function _(E){M(h.value,E,b.value)}function A(E){M(h.value,f.value,E)}function M(E,w,P){if(!E||E==="none"){d("update:elemMotion","");return}if(!w&&!P){d("update:elemMotion",E);return}const R={preset:E};w>0&&(R.duration=w),P>0&&(R.delay=P),d("update:elemMotion",JSON.stringify(R))}return(E,w)=>{var P,R,z,G,S,L;return ee(),te("div",Gv,[w[62]||(w[62]=m("div",{class:"spm-section-header"},[m("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(P=e.detectedSbInfo)!=null&&P.hasSuperBlock?(ee(),te("div",Zv,[m("div",Yv,[m("div",Jv,[m("div",Xv,[re(de,{name:"ratio"}),w[24]||(w[24]=m("span",null,"超级块列宽与布局",-1))]),w[25]||(w[25]=m("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),m("div",Qv,[m("div",eb,[m("div",tb,[re(de,{name:"ratio"}),(R=e.detectedSbInfo)!=null&&R.isCustomWidth?(ee(),te("span",ib,"已识别自定义列宽比例")):(ee(),te("span",nb,"识别到 "+we(((z=e.detectedSbInfo)==null?void 0:z.colCount)||2)+" 列超级块分栏",1))]),m("code",ob,we(((G=e.detectedSbInfo)==null?void 0:G.ratio)||"1:1"),1)]),m("div",sb,we((S=e.detectedSbInfo)!=null&&S.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),m("div",rb,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:w[0]||(w[0]=y=>E.$emit("applySuperBlockLayout",e.detectedSbInfo))},[re(de,{name:"sparkles"}),w[26]||(w[26]=m("span",null,"应用版式与比例",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:w[1]||(w[1]=y=>{var B;return E.$emit("applySuperBlockRatio",((B=e.detectedSbInfo)==null?void 0:B.ratio)||"1:1")})},[re(de,{name:"check"}),m("span",null,"应用比例 ("+we(((L=e.detectedSbInfo)==null?void 0:L.ratio)||"1:1")+")",1)])])])):Oe("",!0),m("div",lb,[m("div",ab,[m("div",cb,[m("div",db,[re(de,{name:"presenter"}),w[27]||(w[27]=m("span",null,"设为讲稿备注",-1))]),w[28]||(w[28]=m("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.isNote?"取消讲稿备注":"设为讲稿备注"},[m("input",{type:"checkbox",checked:!!e.isNote,onChange:w[2]||(w[2]=y=>E.$emit("toggleNote"))},null,40,fb),w[29]||(w[29]=m("span",{class:"spm-switch-slider"},null,-1))],8,ub)])]),e.isImage||e.imageRole?(ee(),te("div",pb,[m("div",hb,[m("div",mb,[m("div",gb,[re(de,{name:"image"}),w[30]||(w[30]=m("span",null,"图片角色与分栏 (Image & Layout)",-1))]),w[31]||(w[31]=m("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),m("div",vb,[m("button",{class:_e(["spm-chip",{active:!e.imageRole}]),onClick:w[3]||(w[3]=y=>E.$emit("update:imageRole",""))}," 普通内容 ",2),m("button",{class:_e(["spm-chip",{active:e.imageRole==="background"}]),onClick:w[4]||(w[4]=y=>E.$emit("update:imageRole","background"))},[re(de,{name:"image"}),w[32]||(w[32]=m("span",null,"背景图",-1))],2),m("button",{class:_e(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:w[5]||(w[5]=y=>E.$emit("update:imageRole","image-left"))},[re(de,{name:"image-left"}),w[33]||(w[33]=m("span",null,"图左",-1))],2),m("button",{class:_e(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:w[6]||(w[6]=y=>E.$emit("update:imageRole","image-right"))},[re(de,{name:"image-right"}),w[34]||(w[34]=m("span",null,"图右",-1))],2)])])):Oe("",!0),e.isVideo?(ee(),te("div",bb,[m("div",yb,[m("div",kb,[m("div",wb,[re(de,{name:"video"}),w[35]||(w[35]=m("span",null,"视频播放设置 (Video Playback)",-1))]),w[36]||(w[36]=m("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),m("div",xb,[m("div",Sb,[m("span",_b,[re(de,{name:"sliders"}),w[37]||(w[37]=$t(" 控制条",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[m("input",{type:"checkbox",checked:!!e.videoControls,onChange:w[7]||(w[7]=y=>E.$emit("toggleVideoControls"))},null,40,$b),w[38]||(w[38]=m("span",{class:"spm-switch-slider"},null,-1))],8,Cb)]),m("div",Ib,[m("span",Eb,[re(de,{name:"video"}),w[39]||(w[39]=$t(" 自动播放",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[m("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:w[8]||(w[8]=y=>E.$emit("toggleVideoAutoplay"))},null,40,Ab),w[40]||(w[40]=m("span",{class:"spm-switch-slider"},null,-1))],8,Tb)]),m("div",Bb,[m("span",Mb,[re(de,{name:"repeat"}),w[41]||(w[41]=$t(" 循环播放",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[m("input",{type:"checkbox",checked:!!e.videoLoop,onChange:w[9]||(w[9]=y=>E.$emit("toggleVideoLoop"))},null,40,Lb),w[42]||(w[42]=m("span",{class:"spm-switch-slider"},null,-1))],8,Db)]),m("div",Ob,[m("span",Pb,[re(de,{name:"volume-x"}),w[43]||(w[43]=$t(" 静音播放",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoMuted?"关闭静音":"开启静音"},[m("input",{type:"checkbox",checked:!!e.videoMuted,onChange:w[10]||(w[10]=y=>E.$emit("toggleVideoMuted"))},null,40,Nb),w[44]||(w[44]=m("span",{class:"spm-switch-slider"},null,-1))],8,Rb)])])])):Oe("",!0),m("div",zb,[m("div",Fb,[m("div",Hb,[m("div",jb,[re(de,{name:"step"}),w[45]||(w[45]=m("span",null,"逐步呈现 (v-click)",-1))]),w[46]||(w[46]=m("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[m("input",{type:"checkbox",checked:!!e.elemClick,onChange:w[11]||(w[11]=y=>E.$emit("toggleElemClick"))},null,40,Ub),w[47]||(w[47]=m("span",{class:"spm-switch-slider"},null,-1))],8,Wb)]),e.elemClick?(ee(),te("div",Vb,[(ee(),te(Ue,null,kt(["+1","1","2","hide"],y=>m("button",{key:y,class:_e(["spm-chip",{active:e.elemClick===y}]),onClick:B=>E.$emit("update:elemClick",y)},we(y==="+1"?"顺延 (+1)":y==="hide"?"隐藏 (hide)":"第 "+y+" 步"),11,Kb)),64))])):e.parentElemClick?(ee(),te("div",qb,[re(de,{name:"check"}),w[48]||(w[48]=m("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Oe("",!0)]),m("div",Gb,[m("div",Zb,[m("div",Yb,[m("div",Jb,[re(de,{name:"motion"}),w[49]||(w[49]=m("span",null,"入场微动效 (v-motion)",-1))]),w[50]||(w[50]=m("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":u.value?"关闭微动效":"开启微动效 (slide-up)"},[m("input",{type:"checkbox",checked:u.value,onChange:k},null,40,Qb),w[51]||(w[51]=m("span",{class:"spm-switch-slider"},null,-1))],8,Xb)]),u.value?(ee(),te("div",e1,[(ee(),te(Ue,null,kt(p,y=>m("button",{key:y.value,class:_e(["spm-chip",{active:h.value===y.value}]),onClick:B=>x(y.value)},we(y.label),11,t1)),64))])):Oe("",!0),u.value?(ee(),te("div",i1,[m("div",n1,[m("span",null,"时长: "+we(f.value?f.value+"ms":"默认 (450ms)"),1),m("span",null,"延迟: "+we(b.value?b.value+"ms":"0ms"),1)]),m("div",o1,[m("select",{class:"spm-select",style:{flex:"1"},value:f.value,onChange:w[12]||(w[12]=y=>_(Number(y.target.value)))},[...w[52]||(w[52]=[m("option",{value:0},"默认耗时",-1),m("option",{value:200},"极速 (200ms)",-1),m("option",{value:350},"较快 (350ms)",-1),m("option",{value:500},"平滑 (500ms)",-1),m("option",{value:800},"缓慢 (800ms)",-1)])],40,s1),m("select",{class:"spm-select",style:{flex:"1"},value:b.value,onChange:w[13]||(w[13]=y=>A(Number(y.target.value)))},[...w[53]||(w[53]=[m("option",{value:0},"无延迟",-1),m("option",{value:150},"延迟 150ms",-1),m("option",{value:300},"延迟 300ms",-1),m("option",{value:500},"延迟 500ms",-1)])],40,r1)])])):Oe("",!0)]),o.value||e.elemSlot?(ee(),te("div",l1,[m("div",a1,[m("div",c1,[m("div",d1,[re(de,{name:"columns"}),m("span",null,we(l.value),1)]),m("span",u1,we(r.value),1)])]),m("div",f1,[(ee(!0),te(Ue,null,kt(a.value,y=>(ee(),te("button",{key:y.value,class:_e(["spm-segmented-item",{active:c(y.value)}]),onClick:B=>E.$emit("update:elemSlot",y.value)},we(y.label),11,p1))),128))])])):Oe("",!0),e.isCodeBlock?(ee(),te("div",h1,[m("div",m1,[m("div",g1,[m("div",v1,[re(de,{name:"code"}),w[54]||(w[54]=m("span",null,"代码逐行聚光 (Shiki)",-1))]),w[55]||(w[55]=m("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),m("div",b1,[(ee(),te(Ue,null,kt(["1-3","all","1|2|3","2-5"],y=>m("button",{key:y,class:_e(["spm-chip",{active:e.elemShikiLines===y}]),onClick:B=>E.$emit("update:elemShikiLines",y)},we(y),11,y1)),64)),e.elemShikiLines?(ee(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[14]||(w[14]=y=>E.$emit("update:elemShikiLines",""))}," 清空 ")):Oe("",!0)]),m("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:w[15]||(w[15]=y=>E.$emit("update:elemShikiLines",y.target.value)),onChange:w[16]||(w[16]=y=>E.$emit("update:elemShikiLines",y.target.value))},null,40,k1)])):Oe("",!0),e.isCodeBlock?(ee(),te("div",w1,[m("div",x1,[m("div",S1,[m("div",_1,[re(de,{name:"code"}),w[56]||(w[56]=m("span",null,"代码块限高 (Max Height)",-1))]),w[57]||(w[57]=m("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),m("div",C1,[(ee(),te(Ue,null,kt(["240px","320px","400px","50vh"],y=>m("button",{key:y,class:_e(["spm-chip",{active:e.elemMaxHeight===y}]),onClick:B=>E.$emit("update:elemMaxHeight",y)},we(y),11,$1)),64)),e.elemMaxHeight?(ee(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[17]||(w[17]=y=>E.$emit("update:elemMaxHeight",""))}," 自适应 ")):Oe("",!0)]),m("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:w[18]||(w[18]=y=>E.$emit("update:elemMaxHeight",y.target.value)),onChange:w[19]||(w[19]=y=>E.$emit("update:elemMaxHeight",y.target.value))},null,40,I1)])):Oe("",!0),m("div",E1,[w[61]||(w[61]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"快捷操作")])],-1)),m("div",T1,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:w[20]||(w[20]=y=>E.$emit("insertDividerBefore"))},[re(de,{name:"insert-above"}),w[58]||(w[58]=m("span",null,"上方分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:w[21]||(w[21]=y=>E.$emit("insertDividerAfter"))},[re(de,{name:"insert-below"}),w[59]||(w[59]=m("span",null,"下方分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:w[22]||(w[22]=y=>E.$emit("setTwoColsContrast"))},[re(de,{name:"columns"}),m("span",null,we(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,A1),e.hasBlockAttrs?(ee(),te("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:w[23]||(w[23]=y=>E.$emit("clearBlockAttrs"))},[re(de,{name:"broom"}),w[60]||(w[60]=m("span",null,"清除属性",-1))])):Oe("",!0)])])])}}}),M1={class:"spm-section spm-section--doc"},D1={class:"spm-card-control"},L1={class:"spm-control-header"},O1={class:"spm-control-title-group"},P1={class:"spm-control-title"},R1={class:"spm-segmented-group"},N1=["aria-label","onClick"],z1={class:"spm-card-control"},F1={class:"spm-control-header"},H1={class:"spm-control-title-group"},j1={class:"spm-control-title"},W1={class:"spm-segmented-group"},U1={class:"spm-card-control"},V1={class:"spm-control-header"},K1={class:"spm-control-title-group"},q1={class:"spm-control-title"},G1={class:"spm-segmented-group"},Z1={class:"spm-card-control"},Y1={class:"spm-control-header"},J1={class:"spm-control-title-group"},X1={class:"spm-control-title"},Q1={class:"spm-card-control"},ey={class:"spm-control-header"},ty={class:"spm-control-title-group"},iy={class:"spm-control-title"},ny=["aria-label"],oy=["checked"],sy={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},ry=["value"],ly={class:"spm-card-control"},ay={class:"spm-control-header"},cy={class:"spm-control-title-group"},dy={class:"spm-control-title"},uy=["aria-label"],fy=["checked"],py={class:"spm-card-control"},hy={class:"spm-action-grid"},my=xt({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(e){const t=ti("plugin"),i=mi,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function o(a){Ai({enableWebServeJump:a}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({enableWebServeJump:a})}async function s(a){var c;Ai({normalizeHeadingSizes:a}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({normalizeHeadingSizes:a}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((c=t.getActiveDocumentId)==null?void 0:c.call(t)))}function l(a){Ai({webServeUrl:a})}function r(a){Ai({webServeUrl:a}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({webServeUrl:a})}return(a,c)=>(ee(),te("div",M1,[c[39]||(c[39]=m("div",{class:"spm-section-header"},[m("span",null,"全局演示配置")],-1)),m("div",D1,[m("div",L1,[m("div",O1,[m("div",P1,[re(de,{name:"palette"}),c[18]||(c[18]=m("span",null,"幻灯片主题 (Theme)",-1))]),c[19]||(c[19]=m("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),m("div",R1,[(ee(),te(Ue,null,kt(n,d=>m("button",{key:d.value,class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.docTheme===d.value}]),"aria-label":d.desc,onClick:p=>a.$emit("update:docTheme",d.value)},we(d.label),11,N1)),64))])]),m("div",z1,[m("div",F1,[m("div",H1,[m("div",j1,[re(de,{name:"ratio"}),c[20]||(c[20]=m("span",null,"画幅比例 (Aspect Ratio)",-1))]),c[21]||(c[21]=m("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),m("div",W1,[m("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:c[0]||(c[0]=d=>a.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),m("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:c[1]||(c[1]=d=>a.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),m("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:c[2]||(c[2]=d=>a.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),m("div",U1,[m("div",V1,[m("div",K1,[m("div",q1,[re(de,{name:"ratio"}),c[22]||(c[22]=m("span",null,"间距风格 (Spacing)",-1))]),c[23]||(c[23]=m("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),m("div",G1,[m("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:c[3]||(c[3]=d=>a.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),m("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:c[4]||(c[4]=d=>a.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),m("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:c[5]||(c[5]=d=>a.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),m("div",Z1,[m("div",Y1,[m("div",J1,[m("div",X1,[re(de,{name:"transition"}),c[24]||(c[24]=m("span",null,"全局默认转场",-1))]),c[25]||(c[25]=m("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),re(Qs,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:c[6]||(c[6]=d=>a.$emit("update:docDefaultTransition",d))},null,8,["model-value"])]),m("div",Q1,[m("div",ey,[m("div",ty,[m("div",iy,[re(de,{name:"external-link"}),c[26]||(c[26]=m("span",null,"本地网络伺服预览 (Web Serve)",-1))]),c[27]||(c[27]=m("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ge(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[m("input",{type:"checkbox",checked:ge(i).enableWebServeJump,onChange:c[7]||(c[7]=d=>o(d.target.checked))},null,40,oy),c[28]||(c[28]=m("span",{class:"spm-switch-slider"},null,-1))],8,ny)]),ge(i).enableWebServeJump?(ee(),te("div",sy,[m("input",{value:ge(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:c[8]||(c[8]=Lt(()=>{},["stop"])),onKeyup:c[9]||(c[9]=Lt(()=>{},["stop"])),onInput:c[10]||(c[10]=d=>l(d.target.value)),onChange:c[11]||(c[11]=d=>r(d.target.value))},null,40,ry),c[29]||(c[29]=m("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Oe("",!0)]),m("div",ly,[m("div",ay,[m("div",cy,[m("div",dy,[re(de,{name:"type"}),c[30]||(c[30]=m("span",null,"固定特定标题大小",-1))]),c[31]||(c[31]=m("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ge(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[m("input",{type:"checkbox",checked:ge(i).normalizeHeadingSizes,onChange:c[12]||(c[12]=d=>s(d.target.checked))},null,40,fy),c[32]||(c[32]=m("span",{class:"spm-switch-slider"},null,-1))],8,uy)])]),m("div",py,[c[38]||(c[38]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"演示全局操作")])],-1)),m("div",hy,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:c[13]||(c[13]=d=>a.$emit("openBottomPreview"))},[re(de,{name:"split-preview"}),c[33]||(c[33]=m("span",null,"分屏预览",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:c[14]||(c[14]=d=>a.$emit("openPresenter"))},[re(de,{name:"presenter"}),c[34]||(c[34]=m("span",null,"演讲者视图",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:c[15]||(c[15]=d=>a.$emit("aiAutoSplit"))},[re(de,{name:"sparkles"}),c[35]||(c[35]=m("span",null,"AI 智能分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:c[16]||(c[16]=d=>a.$emit("exportHtml"))},[re(de,{name:"export-html"}),c[36]||(c[36]=m("span",null,"导出 HTML",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:c[17]||(c[17]=d=>a.$emit("exportPdf"))},[re(de,{name:"export-pdf"}),c[37]||(c[37]=m("span",null,"导出 PDF",-1))])])])]))}});var Qn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function gy(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function eo(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var ns={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var Vr;function vy(){return Vr||(Vr=1,(function(e,t){(function(i){e.exports=i()})(function(){return(function i(n,o,s){function l(c,d){if(!o[c]){if(!n[c]){var p=typeof eo=="function"&&eo;if(!d&&p)return p(c,!0);if(r)return r(c,!0);var v=new Error("Cannot find module '"+c+"'");throw v.code="MODULE_NOT_FOUND",v}var u=o[c]={exports:{}};n[c][0].call(u.exports,function(h){var f=n[c][1][h];return l(f||h)},u,u.exports,i,n,o,s)}return o[c].exports}for(var r=typeof eo=="function"&&eo,a=0;a<s.length;a++)l(s[a]);return l})({1:[function(i,n,o){var s=i("./utils"),l=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";o.encode=function(a){for(var c,d,p,v,u,h,f,b=[],k=0,x=a.length,_=x,A=s.getTypeOf(a)!=="string";k<a.length;)_=x-k,p=A?(c=a[k++],d=k<x?a[k++]:0,k<x?a[k++]:0):(c=a.charCodeAt(k++),d=k<x?a.charCodeAt(k++):0,k<x?a.charCodeAt(k++):0),v=c>>2,u=(3&c)<<4|d>>4,h=1<_?(15&d)<<2|p>>6:64,f=2<_?63&p:64,b.push(r.charAt(v)+r.charAt(u)+r.charAt(h)+r.charAt(f));return b.join("")},o.decode=function(a){var c,d,p,v,u,h,f=0,b=0,k="data:";if(a.substr(0,k.length)===k)throw new Error("Invalid base64 input, it looks like a data url.");var x,_=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&_--,a.charAt(a.length-2)===r.charAt(64)&&_--,_%1!=0)throw new Error("Invalid base64 input, bad content length.");for(x=l.uint8array?new Uint8Array(0|_):new Array(0|_);f<a.length;)c=r.indexOf(a.charAt(f++))<<2|(v=r.indexOf(a.charAt(f++)))>>4,d=(15&v)<<4|(u=r.indexOf(a.charAt(f++)))>>2,p=(3&u)<<6|(h=r.indexOf(a.charAt(f++))),x[b++]=c,u!==64&&(x[b++]=d),h!==64&&(x[b++]=p);return x}},{"./support":30,"./utils":32}],2:[function(i,n,o){var s=i("./external"),l=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),a=i("./stream/DataLengthProbe");function c(d,p,v,u,h){this.compressedSize=d,this.uncompressedSize=p,this.crc32=v,this.compression=u,this.compressedContent=h}c.prototype={getContentWorker:function(){var d=new l(s.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),p=this;return d.on("end",function(){if(this.streamInfo.data_length!==p.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(s.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,p,v){return d.pipe(new r).pipe(new a("uncompressedSize")).pipe(p.compressWorker(v)).pipe(new a("compressedSize")).withStreamInfo("compression",p)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,n,o){var s=i("./stream/GenericWorker");o.STORE={magic:"\0\0",compressWorker:function(){return new s("STORE compression")},uncompressWorker:function(){return new s("STORE decompression")}},o.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,n,o){var s=i("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var d=0;d<8;d++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();n.exports=function(r,a){return r!==void 0&&r.length?s.getTypeOf(r)!=="string"?(function(c,d,p,v){var u=l,h=v+p;c^=-1;for(var f=v;f<h;f++)c=c>>>8^u[255&(c^d[f])];return-1^c})(0|a,r,r.length,0):(function(c,d,p,v){var u=l,h=v+p;c^=-1;for(var f=v;f<h;f++)c=c>>>8^u[255&(c^d.charCodeAt(f))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(i,n,o){o.base64=!1,o.binary=!1,o.dir=!1,o.createFolders=!0,o.date=null,o.compression=null,o.compressionOptions=null,o.comment=null,o.unixPermissions=null,o.dosPermissions=null},{}],6:[function(i,n,o){var s=null;s=typeof Promise<"u"?Promise:i("lie"),n.exports={Promise:s}},{lie:37}],7:[function(i,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=i("pako"),r=i("./utils"),a=i("./stream/GenericWorker"),c=s?"uint8array":"array";function d(p,v){a.call(this,"FlateWorker/"+p),this._pako=null,this._pakoAction=p,this._pakoOptions=v,this.meta={}}o.magic="\b\0",r.inherits(d,a),d.prototype.processChunk=function(p){this.meta=p.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,p.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var p=this;this._pako.onData=function(v){p.push({data:v,meta:p.meta})}},o.compressWorker=function(p){return new d("Deflate",p)},o.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,n,o){function s(u,h){var f,b="";for(f=0;f<h;f++)b+=String.fromCharCode(255&u),u>>>=8;return b}function l(u,h,f,b,k,x){var _,A,M=u.file,E=u.compression,w=x!==c.utf8encode,P=r.transformTo("string",x(M.name)),R=r.transformTo("string",c.utf8encode(M.name)),z=M.comment,G=r.transformTo("string",x(z)),S=r.transformTo("string",c.utf8encode(z)),L=R.length!==M.name.length,y=S.length!==z.length,B="",F="",T="",D=M.dir,N=M.date,X={crc32:0,compressedSize:0,uncompressedSize:0};h&&!f||(X.crc32=u.crc32,X.compressedSize=u.compressedSize,X.uncompressedSize=u.uncompressedSize);var Z=0;h&&(Z|=8),w||!L&&!y||(Z|=2048);var U=0,ie=0;D&&(U|=16),k==="UNIX"?(ie=798,U|=(function(le,ve){var Te=le;return le||(Te=ve?16893:33204),(65535&Te)<<16})(M.unixPermissions,D)):(ie=20,U|=(function(le){return 63&(le||0)})(M.dosPermissions)),_=N.getUTCHours(),_<<=6,_|=N.getUTCMinutes(),_<<=5,_|=N.getUTCSeconds()/2,A=N.getUTCFullYear()-1980,A<<=4,A|=N.getUTCMonth()+1,A<<=5,A|=N.getUTCDate(),L&&(F=s(1,1)+s(d(P),4)+R,B+="up"+s(F.length,2)+F),y&&(T=s(1,1)+s(d(G),4)+S,B+="uc"+s(T.length,2)+T);var se="";return se+=`
\0`,se+=s(Z,2),se+=E.magic,se+=s(_,2),se+=s(A,2),se+=s(X.crc32,4),se+=s(X.compressedSize,4),se+=s(X.uncompressedSize,4),se+=s(P.length,2),se+=s(B.length,2),{fileRecord:p.LOCAL_FILE_HEADER+se+P+B,dirRecord:p.CENTRAL_FILE_HEADER+s(ie,2)+se+s(G.length,2)+"\0\0\0\0"+s(U,4)+s(b,4)+P+B+G}}var r=i("../utils"),a=i("../stream/GenericWorker"),c=i("../utf8"),d=i("../crc32"),p=i("../signature");function v(u,h,f,b){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=h,this.zipPlatform=f,this.encodeFileName=b,this.streamFiles=u,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(v,a),v.prototype.push=function(u){var h=u.meta.percent||0,f=this.entriesCount,b=this._sources.length;this.accumulate?this.contentBuffer.push(u):(this.bytesWritten+=u.data.length,a.prototype.push.call(this,{data:u.data,meta:{currentFile:this.currentFile,percent:f?(h+100*(f-b-1))/f:100}}))},v.prototype.openedSource=function(u){this.currentSourceOffset=this.bytesWritten,this.currentFile=u.file.name;var h=this.streamFiles&&!u.file.dir;if(h){var f=l(u,h,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:f.fileRecord,meta:{percent:0}})}else this.accumulate=!0},v.prototype.closedSource=function(u){this.accumulate=!1;var h=this.streamFiles&&!u.file.dir,f=l(u,h,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(f.dirRecord),h)this.push({data:(function(b){return p.DATA_DESCRIPTOR+s(b.crc32,4)+s(b.compressedSize,4)+s(b.uncompressedSize,4)})(u),meta:{percent:100}});else for(this.push({data:f.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},v.prototype.flush=function(){for(var u=this.bytesWritten,h=0;h<this.dirRecords.length;h++)this.push({data:this.dirRecords[h],meta:{percent:100}});var f=this.bytesWritten-u,b=(function(k,x,_,A,M){var E=r.transformTo("string",M(A));return p.CENTRAL_DIRECTORY_END+"\0\0\0\0"+s(k,2)+s(k,2)+s(x,4)+s(_,4)+s(E.length,2)+E})(this.dirRecords.length,f,u,this.zipComment,this.encodeFileName);this.push({data:b,meta:{percent:100}})},v.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},v.prototype.registerPrevious=function(u){this._sources.push(u);var h=this;return u.on("data",function(f){h.processChunk(f)}),u.on("end",function(){h.closedSource(h.previous.streamInfo),h._sources.length?h.prepareNextSource():h.end()}),u.on("error",function(f){h.error(f)}),this},v.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},v.prototype.error=function(u){var h=this._sources;if(!a.prototype.error.call(this,u))return!1;for(var f=0;f<h.length;f++)try{h[f].error(u)}catch{}return!0},v.prototype.lock=function(){a.prototype.lock.call(this);for(var u=this._sources,h=0;h<u.length;h++)u[h].lock()},n.exports=v},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,n,o){var s=i("../compressions"),l=i("./ZipFileWorker");o.generateWorker=function(r,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),p=0;try{r.forEach(function(v,u){p++;var h=(function(x,_){var A=x||_,M=s[A];if(!M)throw new Error(A+" is not a valid compression method !");return M})(u.options.compression,a.compression),f=u.options.compressionOptions||a.compressionOptions||{},b=u.dir,k=u.date;u._compressWorker(h,f).withStreamInfo("file",{name:v,dir:b,date:k,comment:u.comment||"",unixPermissions:u.unixPermissions,dosPermissions:u.dosPermissions}).pipe(d)}),d.entriesCount=p}catch(v){d.error(v)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,n,o){function s(){if(!(this instanceof s))return new s;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new s;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(s.prototype=i("./object")).loadAsync=i("./load"),s.support=i("./support"),s.defaults=i("./defaults"),s.version="3.10.1",s.loadAsync=function(l,r){return new s().loadAsync(l,r)},s.external=i("./external"),n.exports=s},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,n,o){var s=i("./utils"),l=i("./external"),r=i("./utf8"),a=i("./zipEntries"),c=i("./stream/Crc32Probe"),d=i("./nodejsUtils");function p(v){return new l.Promise(function(u,h){var f=v.decompressed.getContentWorker().pipe(new c);f.on("error",function(b){h(b)}).on("end",function(){f.streamInfo.crc32!==v.decompressed.crc32?h(new Error("Corrupted zip : CRC32 mismatch")):u()}).resume()})}n.exports=function(v,u){var h=this;return u=s.extend(u||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),d.isNode&&d.isStream(v)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):s.prepareContent("the loaded zip file",v,!0,u.optimizedBinaryString,u.base64).then(function(f){var b=new a(u);return b.load(f),b}).then(function(f){var b=[l.Promise.resolve(f)],k=f.files;if(u.checkCRC32)for(var x=0;x<k.length;x++)b.push(p(k[x]));return l.Promise.all(b)}).then(function(f){for(var b=f.shift(),k=b.files,x=0;x<k.length;x++){var _=k[x],A=_.fileNameStr,M=s.resolve(_.fileNameStr);h.file(M,_.decompressed,{binary:!0,optimizedBinaryString:!0,date:_.date,dir:_.dir,comment:_.fileCommentStr.length?_.fileCommentStr:null,unixPermissions:_.unixPermissions,dosPermissions:_.dosPermissions,createFolders:u.createFolders}),_.dir||(h.file(M).unsafeOriginalName=A)}return b.zipComment.length&&(h.comment=b.zipComment),h})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,n,o){var s=i("../utils"),l=i("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}s.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,n,o){var s=i("readable-stream").Readable;function l(r,a,c){s.call(this,a),this._helper=r;var d=this;r.on("data",function(p,v){d.push(p)||d._helper.pause(),c&&c(v)}).on("error",function(p){d.emit("error",p)}).on("end",function(){d.push(null)})}i("../utils").inherits(l,s),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(i,n,o){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(s,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(s,l);if(typeof s=="number")throw new Error('The "data" argument must not be a number');return new Buffer(s,l)},allocBuffer:function(s){if(Buffer.alloc)return Buffer.alloc(s);var l=new Buffer(s);return l.fill(0),l},isBuffer:function(s){return Buffer.isBuffer(s)},isStream:function(s){return s&&typeof s.on=="function"&&typeof s.pause=="function"&&typeof s.resume=="function"}}},{}],15:[function(i,n,o){function s(M,E,w){var P,R=r.getTypeOf(E),z=r.extend(w||{},d);z.date=z.date||new Date,z.compression!==null&&(z.compression=z.compression.toUpperCase()),typeof z.unixPermissions=="string"&&(z.unixPermissions=parseInt(z.unixPermissions,8)),z.unixPermissions&&16384&z.unixPermissions&&(z.dir=!0),z.dosPermissions&&16&z.dosPermissions&&(z.dir=!0),z.dir&&(M=k(M)),z.createFolders&&(P=b(M))&&x.call(this,P,!0);var G=R==="string"&&z.binary===!1&&z.base64===!1;w&&w.binary!==void 0||(z.binary=!G),(E instanceof p&&E.uncompressedSize===0||z.dir||!E||E.length===0)&&(z.base64=!1,z.binary=!0,E="",z.compression="STORE",R="string");var S=null;S=E instanceof p||E instanceof a?E:h.isNode&&h.isStream(E)?new f(M,E):r.prepareContent(M,E,z.binary,z.optimizedBinaryString,z.base64);var L=new v(M,S,z);this.files[M]=L}var l=i("./utf8"),r=i("./utils"),a=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),d=i("./defaults"),p=i("./compressedObject"),v=i("./zipObject"),u=i("./generate"),h=i("./nodejsUtils"),f=i("./nodejs/NodejsStreamInputAdapter"),b=function(M){M.slice(-1)==="/"&&(M=M.substring(0,M.length-1));var E=M.lastIndexOf("/");return 0<E?M.substring(0,E):""},k=function(M){return M.slice(-1)!=="/"&&(M+="/"),M},x=function(M,E){return E=E!==void 0?E:d.createFolders,M=k(M),this.files[M]||s.call(this,M,null,{dir:!0,createFolders:E}),this.files[M]};function _(M){return Object.prototype.toString.call(M)==="[object RegExp]"}var A={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(M){var E,w,P;for(E in this.files)P=this.files[E],(w=E.slice(this.root.length,E.length))&&E.slice(0,this.root.length)===this.root&&M(w,P)},filter:function(M){var E=[];return this.forEach(function(w,P){M(w,P)&&E.push(P)}),E},file:function(M,E,w){if(arguments.length!==1)return M=this.root+M,s.call(this,M,E,w),this;if(_(M)){var P=M;return this.filter(function(z,G){return!G.dir&&P.test(z)})}var R=this.files[this.root+M];return R&&!R.dir?R:null},folder:function(M){if(!M)return this;if(_(M))return this.filter(function(R,z){return z.dir&&M.test(R)});var E=this.root+M,w=x.call(this,E),P=this.clone();return P.root=w.name,P},remove:function(M){M=this.root+M;var E=this.files[M];if(E||(M.slice(-1)!=="/"&&(M+="/"),E=this.files[M]),E&&!E.dir)delete this.files[M];else for(var w=this.filter(function(R,z){return z.name.slice(0,M.length)===M}),P=0;P<w.length;P++)delete this.files[w[P].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(M){var E,w={};try{if((w=r.extend(M||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=w.type.toLowerCase(),w.compression=w.compression.toUpperCase(),w.type==="binarystring"&&(w.type="string"),!w.type)throw new Error("No output type specified.");r.checkSupport(w.type),w.platform!=="darwin"&&w.platform!=="freebsd"&&w.platform!=="linux"&&w.platform!=="sunos"||(w.platform="UNIX"),w.platform==="win32"&&(w.platform="DOS");var P=w.comment||this.comment||"";E=u.generateWorker(this,w,P)}catch(R){(E=new a("error")).error(R)}return new c(E,w.type||"string",w.mimeType)},generateAsync:function(M,E){return this.generateInternalStream(M).accumulate(E)},generateNodeStream:function(M,E){return(M=M||{}).type||(M.type="nodebuffer"),this.generateInternalStream(M).toNodejsStream(E)}};n.exports=A},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,n,o){n.exports=i("stream")},{stream:void 0}],17:[function(i,n,o){var s=i("./DataReader");function l(r){s.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}i("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),p=r.charCodeAt(3),v=this.length-4;0<=v;--v)if(this.data[v]===a&&this.data[v+1]===c&&this.data[v+2]===d&&this.data[v+3]===p)return v-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),p=r.charCodeAt(3),v=this.readData(4);return a===v[0]&&c===v[1]&&d===v[2]&&p===v[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(i,n,o){var s=i("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return s.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=l},{"../utils":32}],19:[function(i,n,o){var s=i("./Uint8ArrayReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,n,o){var s=i("./DataReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(i,n,o){var s=i("./ArrayReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(i,n,o){var s=i("../utils"),l=i("../support"),r=i("./ArrayReader"),a=i("./StringReader"),c=i("./NodeBufferReader"),d=i("./Uint8ArrayReader");n.exports=function(p){var v=s.getTypeOf(p);return s.checkSupport(v),v!=="string"||l.uint8array?v==="nodebuffer"?new c(p):l.uint8array?new d(s.transformTo("uint8array",p)):new r(s.transformTo("array",p)):new a(p)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,n,o){o.LOCAL_FILE_HEADER="PK",o.CENTRAL_FILE_HEADER="PK",o.CENTRAL_DIRECTORY_END="PK",o.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",o.ZIP64_CENTRAL_DIRECTORY_END="PK",o.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,n,o){var s=i("./GenericWorker"),l=i("../utils");function r(a){s.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,s),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,n,o){var s=i("./GenericWorker"),l=i("../crc32");function r(){s.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,s),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,n,o){var s=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}s.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,n,o){var s=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=s.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}s.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,s.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(s.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,n,o){function s(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}s.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=s},{}],29:[function(i,n,o){var s=i("../utils"),l=i("./ConvertWorker"),r=i("./GenericWorker"),a=i("../base64"),c=i("../support"),d=i("../external"),p=null;if(c.nodestream)try{p=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function v(h,f){return new d.Promise(function(b,k){var x=[],_=h._internalType,A=h._outputType,M=h._mimeType;h.on("data",function(E,w){x.push(E),f&&f(w)}).on("error",function(E){x=[],k(E)}).on("end",function(){try{var E=(function(w,P,R){switch(w){case"blob":return s.newBlob(s.transformTo("arraybuffer",P),R);case"base64":return a.encode(P);default:return s.transformTo(w,P)}})(A,(function(w,P){var R,z=0,G=null,S=0;for(R=0;R<P.length;R++)S+=P[R].length;switch(w){case"string":return P.join("");case"array":return Array.prototype.concat.apply([],P);case"uint8array":for(G=new Uint8Array(S),R=0;R<P.length;R++)G.set(P[R],z),z+=P[R].length;return G;case"nodebuffer":return Buffer.concat(P);default:throw new Error("concat : unsupported type '"+w+"'")}})(_,x),M);b(E)}catch(w){k(w)}x=[]}).resume()})}function u(h,f,b){var k=f;switch(f){case"blob":case"arraybuffer":k="uint8array";break;case"base64":k="string"}try{this._internalType=k,this._outputType=f,this._mimeType=b,s.checkSupport(k),this._worker=h.pipe(new l(k)),h.lock()}catch(x){this._worker=new r("error"),this._worker.error(x)}}u.prototype={accumulate:function(h){return v(this,h)},on:function(h,f){var b=this;return h==="data"?this._worker.on(h,function(k){f.call(b,k.data,k.meta)}):this._worker.on(h,function(){s.delay(f,arguments,b)}),this},resume:function(){return s.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(h){if(s.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new p(this,{objectMode:this._outputType!=="nodebuffer"},h)}},n.exports=u},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,n,o){if(o.base64=!0,o.array=!0,o.string=!0,o.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",o.nodebuffer=typeof Buffer<"u",o.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")o.blob=!1;else{var s=new ArrayBuffer(0);try{o.blob=new Blob([s],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(s),o.blob=l.getBlob("application/zip").size===0}catch{o.blob=!1}}}try{o.nodestream=!!i("readable-stream").Readable}catch{o.nodestream=!1}},{"readable-stream":16}],31:[function(i,n,o){for(var s=i("./utils"),l=i("./support"),r=i("./nodejsUtils"),a=i("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function p(){a.call(this,"utf-8 decode"),this.leftOver=null}function v(){a.call(this,"utf-8 encode")}o.utf8encode=function(u){return l.nodebuffer?r.newBufferFrom(u,"utf-8"):(function(h){var f,b,k,x,_,A=h.length,M=0;for(x=0;x<A;x++)(64512&(b=h.charCodeAt(x)))==55296&&x+1<A&&(64512&(k=h.charCodeAt(x+1)))==56320&&(b=65536+(b-55296<<10)+(k-56320),x++),M+=b<128?1:b<2048?2:b<65536?3:4;for(f=l.uint8array?new Uint8Array(M):new Array(M),x=_=0;_<M;x++)(64512&(b=h.charCodeAt(x)))==55296&&x+1<A&&(64512&(k=h.charCodeAt(x+1)))==56320&&(b=65536+(b-55296<<10)+(k-56320),x++),b<128?f[_++]=b:(b<2048?f[_++]=192|b>>>6:(b<65536?f[_++]=224|b>>>12:(f[_++]=240|b>>>18,f[_++]=128|b>>>12&63),f[_++]=128|b>>>6&63),f[_++]=128|63&b);return f})(u)},o.utf8decode=function(u){return l.nodebuffer?s.transformTo("nodebuffer",u).toString("utf-8"):(function(h){var f,b,k,x,_=h.length,A=new Array(2*_);for(f=b=0;f<_;)if((k=h[f++])<128)A[b++]=k;else if(4<(x=c[k]))A[b++]=65533,f+=x-1;else{for(k&=x===2?31:x===3?15:7;1<x&&f<_;)k=k<<6|63&h[f++],x--;1<x?A[b++]=65533:k<65536?A[b++]=k:(k-=65536,A[b++]=55296|k>>10&1023,A[b++]=56320|1023&k)}return A.length!==b&&(A.subarray?A=A.subarray(0,b):A.length=b),s.applyFromCharCode(A)})(u=s.transformTo(l.uint8array?"uint8array":"array",u))},s.inherits(p,a),p.prototype.processChunk=function(u){var h=s.transformTo(l.uint8array?"uint8array":"array",u.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var f=h;(h=new Uint8Array(f.length+this.leftOver.length)).set(this.leftOver,0),h.set(f,this.leftOver.length)}else h=this.leftOver.concat(h);this.leftOver=null}var b=(function(x,_){var A;for((_=_||x.length)>x.length&&(_=x.length),A=_-1;0<=A&&(192&x[A])==128;)A--;return A<0||A===0?_:A+c[x[A]]>_?A:_})(h),k=h;b!==h.length&&(l.uint8array?(k=h.subarray(0,b),this.leftOver=h.subarray(b,h.length)):(k=h.slice(0,b),this.leftOver=h.slice(b,h.length))),this.push({data:o.utf8decode(k),meta:u.meta})},p.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:o.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},o.Utf8DecodeWorker=p,s.inherits(v,a),v.prototype.processChunk=function(u){this.push({data:o.utf8encode(u.data),meta:u.meta})},o.Utf8EncodeWorker=v},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,n,o){var s=i("./support"),l=i("./base64"),r=i("./nodejsUtils"),a=i("./external");function c(f){return f}function d(f,b){for(var k=0;k<f.length;++k)b[k]=255&f.charCodeAt(k);return b}i("setimmediate"),o.newBlob=function(f,b){o.checkSupport("blob");try{return new Blob([f],{type:b})}catch{try{var k=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return k.append(f),k.getBlob(b)}catch{throw new Error("Bug : can't construct the Blob.")}}};var p={stringifyByChunk:function(f,b,k){var x=[],_=0,A=f.length;if(A<=k)return String.fromCharCode.apply(null,f);for(;_<A;)b==="array"||b==="nodebuffer"?x.push(String.fromCharCode.apply(null,f.slice(_,Math.min(_+k,A)))):x.push(String.fromCharCode.apply(null,f.subarray(_,Math.min(_+k,A)))),_+=k;return x.join("")},stringifyByChar:function(f){for(var b="",k=0;k<f.length;k++)b+=String.fromCharCode(f[k]);return b},applyCanBeUsed:{uint8array:(function(){try{return s.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return s.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function v(f){var b=65536,k=o.getTypeOf(f),x=!0;if(k==="uint8array"?x=p.applyCanBeUsed.uint8array:k==="nodebuffer"&&(x=p.applyCanBeUsed.nodebuffer),x)for(;1<b;)try{return p.stringifyByChunk(f,k,b)}catch{b=Math.floor(b/2)}return p.stringifyByChar(f)}function u(f,b){for(var k=0;k<f.length;k++)b[k]=f[k];return b}o.applyFromCharCode=v;var h={};h.string={string:c,array:function(f){return d(f,new Array(f.length))},arraybuffer:function(f){return h.string.uint8array(f).buffer},uint8array:function(f){return d(f,new Uint8Array(f.length))},nodebuffer:function(f){return d(f,r.allocBuffer(f.length))}},h.array={string:v,array:c,arraybuffer:function(f){return new Uint8Array(f).buffer},uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return r.newBufferFrom(f)}},h.arraybuffer={string:function(f){return v(new Uint8Array(f))},array:function(f){return u(new Uint8Array(f),new Array(f.byteLength))},arraybuffer:c,uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return r.newBufferFrom(new Uint8Array(f))}},h.uint8array={string:v,array:function(f){return u(f,new Array(f.length))},arraybuffer:function(f){return f.buffer},uint8array:c,nodebuffer:function(f){return r.newBufferFrom(f)}},h.nodebuffer={string:v,array:function(f){return u(f,new Array(f.length))},arraybuffer:function(f){return h.nodebuffer.uint8array(f).buffer},uint8array:function(f){return u(f,new Uint8Array(f.length))},nodebuffer:c},o.transformTo=function(f,b){if(b=b||"",!f)return b;o.checkSupport(f);var k=o.getTypeOf(b);return h[k][f](b)},o.resolve=function(f){for(var b=f.split("/"),k=[],x=0;x<b.length;x++){var _=b[x];_==="."||_===""&&x!==0&&x!==b.length-1||(_===".."?k.pop():k.push(_))}return k.join("/")},o.getTypeOf=function(f){return typeof f=="string"?"string":Object.prototype.toString.call(f)==="[object Array]"?"array":s.nodebuffer&&r.isBuffer(f)?"nodebuffer":s.uint8array&&f instanceof Uint8Array?"uint8array":s.arraybuffer&&f instanceof ArrayBuffer?"arraybuffer":void 0},o.checkSupport=function(f){if(!s[f.toLowerCase()])throw new Error(f+" is not supported by this platform")},o.MAX_VALUE_16BITS=65535,o.MAX_VALUE_32BITS=-1,o.pretty=function(f){var b,k,x="";for(k=0;k<(f||"").length;k++)x+="\\x"+((b=f.charCodeAt(k))<16?"0":"")+b.toString(16).toUpperCase();return x},o.delay=function(f,b,k){setImmediate(function(){f.apply(k||null,b||[])})},o.inherits=function(f,b){function k(){}k.prototype=b.prototype,f.prototype=new k},o.extend=function(){var f,b,k={};for(f=0;f<arguments.length;f++)for(b in arguments[f])Object.prototype.hasOwnProperty.call(arguments[f],b)&&k[b]===void 0&&(k[b]=arguments[f][b]);return k},o.prepareContent=function(f,b,k,x,_){return a.Promise.resolve(b).then(function(A){return s.blob&&(A instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(A))!==-1)&&typeof FileReader<"u"?new a.Promise(function(M,E){var w=new FileReader;w.onload=function(P){M(P.target.result)},w.onerror=function(P){E(P.target.error)},w.readAsArrayBuffer(A)}):A}).then(function(A){var M=o.getTypeOf(A);return M?(M==="arraybuffer"?A=o.transformTo("uint8array",A):M==="string"&&(_?A=l.decode(A):k&&x!==!0&&(A=(function(E){return d(E,s.uint8array?new Uint8Array(E.length):new Array(E.length))})(A))),A):a.Promise.reject(new Error("Can't read the data of '"+f+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,n,o){var s=i("./reader/readerFor"),l=i("./utils"),r=i("./signature"),a=i("./zipEntry"),c=i("./support");function d(p){this.files=[],this.loadOptions=p}d.prototype={checkSignature:function(p){if(!this.reader.readAndCheckSignature(p)){this.reader.index-=4;var v=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(v)+", expected "+l.pretty(p)+")")}},isSignature:function(p,v){var u=this.reader.index;this.reader.setIndex(p);var h=this.reader.readString(4)===v;return this.reader.setIndex(u),h},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var p=this.reader.readData(this.zipCommentLength),v=c.uint8array?"uint8array":"array",u=l.transformTo(v,p);this.zipComment=this.loadOptions.decodeFileName(u)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var p,v,u,h=this.zip64EndOfCentralSize-44;0<h;)p=this.reader.readInt(2),v=this.reader.readInt(4),u=this.reader.readData(v),this.zip64ExtensibleData[p]={id:p,length:v,value:u}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var p,v;for(p=0;p<this.files.length;p++)v=this.files[p],this.reader.setIndex(v.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),v.readLocalPart(this.reader),v.handleUTF8(),v.processAttributes()},readCentralDir:function(){var p;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(p=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(p);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var p=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(p<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(p);var v=p;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(p=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(p),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var u=this.centralDirOffset+this.centralDirSize;this.zip64&&(u+=20,u+=12+this.zip64EndOfCentralSize);var h=v-u;if(0<h)this.isSignature(v,r.CENTRAL_FILE_HEADER)||(this.reader.zero=h);else if(h<0)throw new Error("Corrupted zip: missing "+Math.abs(h)+" bytes.")},prepareReader:function(p){this.reader=s(p)},load:function(p){this.prepareReader(p),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,n,o){var s=i("./reader/readerFor"),l=i("./utils"),r=i("./compressedObject"),a=i("./crc32"),c=i("./utf8"),d=i("./compressions"),p=i("./support");function v(u,h){this.options=u,this.loadOptions=h}v.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(u){var h,f;if(u.skip(22),this.fileNameLength=u.readInt(2),f=u.readInt(2),this.fileName=u.readData(this.fileNameLength),u.skip(f),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((h=(function(b){for(var k in d)if(Object.prototype.hasOwnProperty.call(d,k)&&d[k].magic===b)return d[k];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,h,u.readData(this.compressedSize))},readCentralPart:function(u){this.versionMadeBy=u.readInt(2),u.skip(2),this.bitFlag=u.readInt(2),this.compressionMethod=u.readString(2),this.date=u.readDate(),this.crc32=u.readInt(4),this.compressedSize=u.readInt(4),this.uncompressedSize=u.readInt(4);var h=u.readInt(2);if(this.extraFieldsLength=u.readInt(2),this.fileCommentLength=u.readInt(2),this.diskNumberStart=u.readInt(2),this.internalFileAttributes=u.readInt(2),this.externalFileAttributes=u.readInt(4),this.localHeaderOffset=u.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");u.skip(h),this.readExtraFields(u),this.parseZIP64ExtraField(u),this.fileComment=u.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var u=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),u==0&&(this.dosPermissions=63&this.externalFileAttributes),u==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var u=s(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=u.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=u.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=u.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=u.readInt(4))}},readExtraFields:function(u){var h,f,b,k=u.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});u.index+4<k;)h=u.readInt(2),f=u.readInt(2),b=u.readData(f),this.extraFields[h]={id:h,length:f,value:b};u.setIndex(k)},handleUTF8:function(){var u=p.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var h=this.findExtraFieldUnicodePath();if(h!==null)this.fileNameStr=h;else{var f=l.transformTo(u,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(f)}var b=this.findExtraFieldUnicodeComment();if(b!==null)this.fileCommentStr=b;else{var k=l.transformTo(u,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(k)}}},findExtraFieldUnicodePath:function(){var u=this.extraFields[28789];if(u){var h=s(u.value);return h.readInt(1)!==1||a(this.fileName)!==h.readInt(4)?null:c.utf8decode(h.readData(u.length-5))}return null},findExtraFieldUnicodeComment:function(){var u=this.extraFields[25461];if(u){var h=s(u.value);return h.readInt(1)!==1||a(this.fileComment)!==h.readInt(4)?null:c.utf8decode(h.readData(u.length-5))}return null}},n.exports=v},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,n,o){function s(h,f,b){this.name=h,this.dir=b.dir,this.date=b.date,this.comment=b.comment,this.unixPermissions=b.unixPermissions,this.dosPermissions=b.dosPermissions,this._data=f,this._dataBinary=b.binary,this.options={compression:b.compression,compressionOptions:b.compressionOptions}}var l=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),a=i("./utf8"),c=i("./compressedObject"),d=i("./stream/GenericWorker");s.prototype={internalStream:function(h){var f=null,b="string";try{if(!h)throw new Error("No output type specified.");var k=(b=h.toLowerCase())==="string"||b==="text";b!=="binarystring"&&b!=="text"||(b="string"),f=this._decompressWorker();var x=!this._dataBinary;x&&!k&&(f=f.pipe(new a.Utf8EncodeWorker)),!x&&k&&(f=f.pipe(new a.Utf8DecodeWorker))}catch(_){(f=new d("error")).error(_)}return new l(f,b,"")},async:function(h,f){return this.internalStream(h).accumulate(f)},nodeStream:function(h,f){return this.internalStream(h||"nodebuffer").toNodejsStream(f)},_compressWorker:function(h,f){if(this._data instanceof c&&this._data.compression.magic===h.magic)return this._data.getCompressedWorker();var b=this._decompressWorker();return this._dataBinary||(b=b.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(b,h,f)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new r(this._data)}};for(var p=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],v=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},u=0;u<p.length;u++)s.prototype[p[u]]=v;n.exports=s},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,n,o){(function(s){var l,r,a=s.MutationObserver||s.WebKitMutationObserver;if(a){var c=0,d=new a(h),p=s.document.createTextNode("");d.observe(p,{characterData:!0}),l=function(){p.data=c=++c%2}}else if(s.setImmediate||s.MessageChannel===void 0)l="document"in s&&"onreadystatechange"in s.document.createElement("script")?function(){var f=s.document.createElement("script");f.onreadystatechange=function(){h(),f.onreadystatechange=null,f.parentNode.removeChild(f),f=null},s.document.documentElement.appendChild(f)}:function(){setTimeout(h,0)};else{var v=new s.MessageChannel;v.port1.onmessage=h,l=function(){v.port2.postMessage(0)}}var u=[];function h(){var f,b;r=!0;for(var k=u.length;k;){for(b=u,u=[],f=-1;++f<k;)b[f]();k=u.length}r=!1}n.exports=function(f){u.push(f)!==1||r||l()}}).call(this,typeof Qn<"u"?Qn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,n,o){var s=i("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function p(k){if(typeof k!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,k!==l&&f(this,k)}function v(k,x,_){this.promise=k,typeof x=="function"&&(this.onFulfilled=x,this.callFulfilled=this.otherCallFulfilled),typeof _=="function"&&(this.onRejected=_,this.callRejected=this.otherCallRejected)}function u(k,x,_){s(function(){var A;try{A=x(_)}catch(M){return r.reject(k,M)}A===k?r.reject(k,new TypeError("Cannot resolve promise with itself")):r.resolve(k,A)})}function h(k){var x=k&&k.then;if(k&&(typeof k=="object"||typeof k=="function")&&typeof x=="function")return function(){x.apply(k,arguments)}}function f(k,x){var _=!1;function A(w){_||(_=!0,r.reject(k,w))}function M(w){_||(_=!0,r.resolve(k,w))}var E=b(function(){x(M,A)});E.status==="error"&&A(E.value)}function b(k,x){var _={};try{_.value=k(x),_.status="success"}catch(A){_.status="error",_.value=A}return _}(n.exports=p).prototype.finally=function(k){if(typeof k!="function")return this;var x=this.constructor;return this.then(function(_){return x.resolve(k()).then(function(){return _})},function(_){return x.resolve(k()).then(function(){throw _})})},p.prototype.catch=function(k){return this.then(null,k)},p.prototype.then=function(k,x){if(typeof k!="function"&&this.state===c||typeof x!="function"&&this.state===a)return this;var _=new this.constructor(l);return this.state!==d?u(_,this.state===c?k:x,this.outcome):this.queue.push(new v(_,k,x)),_},v.prototype.callFulfilled=function(k){r.resolve(this.promise,k)},v.prototype.otherCallFulfilled=function(k){u(this.promise,this.onFulfilled,k)},v.prototype.callRejected=function(k){r.reject(this.promise,k)},v.prototype.otherCallRejected=function(k){u(this.promise,this.onRejected,k)},r.resolve=function(k,x){var _=b(h,x);if(_.status==="error")return r.reject(k,_.value);var A=_.value;if(A)f(k,A);else{k.state=c,k.outcome=x;for(var M=-1,E=k.queue.length;++M<E;)k.queue[M].callFulfilled(x)}return k},r.reject=function(k,x){k.state=a,k.outcome=x;for(var _=-1,A=k.queue.length;++_<A;)k.queue[_].callRejected(x);return k},p.resolve=function(k){return k instanceof this?k:r.resolve(new this(l),k)},p.reject=function(k){var x=new this(l);return r.reject(x,k)},p.all=function(k){var x=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var _=k.length,A=!1;if(!_)return this.resolve([]);for(var M=new Array(_),E=0,w=-1,P=new this(l);++w<_;)R(k[w],w);return P;function R(z,G){x.resolve(z).then(function(S){M[G]=S,++E!==_||A||(A=!0,r.resolve(P,M))},function(S){A||(A=!0,r.reject(P,S))})}},p.race=function(k){var x=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var _=k.length,A=!1;if(!_)return this.resolve([]);for(var M=-1,E=new this(l);++M<_;)w=k[M],x.resolve(w).then(function(P){A||(A=!0,r.resolve(E,P))},function(P){A||(A=!0,r.reject(E,P))});var w;return E}},{immediate:36}],38:[function(i,n,o){var s={};(0,i("./lib/utils/common").assign)(s,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),n.exports=s},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,n,o){var s=i("./zlib/deflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/messages"),c=i("./zlib/zstream"),d=Object.prototype.toString,p=0,v=-1,u=0,h=8;function f(k){if(!(this instanceof f))return new f(k);this.options=l.assign({level:v,method:h,chunkSize:16384,windowBits:15,memLevel:8,strategy:u,to:""},k||{});var x=this.options;x.raw&&0<x.windowBits?x.windowBits=-x.windowBits:x.gzip&&0<x.windowBits&&x.windowBits<16&&(x.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var _=s.deflateInit2(this.strm,x.level,x.method,x.windowBits,x.memLevel,x.strategy);if(_!==p)throw new Error(a[_]);if(x.header&&s.deflateSetHeader(this.strm,x.header),x.dictionary){var A;if(A=typeof x.dictionary=="string"?r.string2buf(x.dictionary):d.call(x.dictionary)==="[object ArrayBuffer]"?new Uint8Array(x.dictionary):x.dictionary,(_=s.deflateSetDictionary(this.strm,A))!==p)throw new Error(a[_]);this._dict_set=!0}}function b(k,x){var _=new f(x);if(_.push(k,!0),_.err)throw _.msg||a[_.err];return _.result}f.prototype.push=function(k,x){var _,A,M=this.strm,E=this.options.chunkSize;if(this.ended)return!1;A=x===~~x?x:x===!0?4:0,typeof k=="string"?M.input=r.string2buf(k):d.call(k)==="[object ArrayBuffer]"?M.input=new Uint8Array(k):M.input=k,M.next_in=0,M.avail_in=M.input.length;do{if(M.avail_out===0&&(M.output=new l.Buf8(E),M.next_out=0,M.avail_out=E),(_=s.deflate(M,A))!==1&&_!==p)return this.onEnd(_),!(this.ended=!0);M.avail_out!==0&&(M.avail_in!==0||A!==4&&A!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(M.output,M.next_out))):this.onData(l.shrinkBuf(M.output,M.next_out)))}while((0<M.avail_in||M.avail_out===0)&&_!==1);return A===4?(_=s.deflateEnd(this.strm),this.onEnd(_),this.ended=!0,_===p):A!==2||(this.onEnd(p),!(M.avail_out=0))},f.prototype.onData=function(k){this.chunks.push(k)},f.prototype.onEnd=function(k){k===p&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=k,this.msg=this.strm.msg},o.Deflate=f,o.deflate=b,o.deflateRaw=function(k,x){return(x=x||{}).raw=!0,b(k,x)},o.gzip=function(k,x){return(x=x||{}).gzip=!0,b(k,x)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,n,o){var s=i("./zlib/inflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/constants"),c=i("./zlib/messages"),d=i("./zlib/zstream"),p=i("./zlib/gzheader"),v=Object.prototype.toString;function u(f){if(!(this instanceof u))return new u(f);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},f||{});var b=this.options;b.raw&&0<=b.windowBits&&b.windowBits<16&&(b.windowBits=-b.windowBits,b.windowBits===0&&(b.windowBits=-15)),!(0<=b.windowBits&&b.windowBits<16)||f&&f.windowBits||(b.windowBits+=32),15<b.windowBits&&b.windowBits<48&&(15&b.windowBits)==0&&(b.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var k=s.inflateInit2(this.strm,b.windowBits);if(k!==a.Z_OK)throw new Error(c[k]);this.header=new p,s.inflateGetHeader(this.strm,this.header)}function h(f,b){var k=new u(b);if(k.push(f,!0),k.err)throw k.msg||c[k.err];return k.result}u.prototype.push=function(f,b){var k,x,_,A,M,E,w=this.strm,P=this.options.chunkSize,R=this.options.dictionary,z=!1;if(this.ended)return!1;x=b===~~b?b:b===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof f=="string"?w.input=r.binstring2buf(f):v.call(f)==="[object ArrayBuffer]"?w.input=new Uint8Array(f):w.input=f,w.next_in=0,w.avail_in=w.input.length;do{if(w.avail_out===0&&(w.output=new l.Buf8(P),w.next_out=0,w.avail_out=P),(k=s.inflate(w,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&R&&(E=typeof R=="string"?r.string2buf(R):v.call(R)==="[object ArrayBuffer]"?new Uint8Array(R):R,k=s.inflateSetDictionary(this.strm,E)),k===a.Z_BUF_ERROR&&z===!0&&(k=a.Z_OK,z=!1),k!==a.Z_STREAM_END&&k!==a.Z_OK)return this.onEnd(k),!(this.ended=!0);w.next_out&&(w.avail_out!==0&&k!==a.Z_STREAM_END&&(w.avail_in!==0||x!==a.Z_FINISH&&x!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(_=r.utf8border(w.output,w.next_out),A=w.next_out-_,M=r.buf2string(w.output,_),w.next_out=A,w.avail_out=P-A,A&&l.arraySet(w.output,w.output,_,A,0),this.onData(M)):this.onData(l.shrinkBuf(w.output,w.next_out)))),w.avail_in===0&&w.avail_out===0&&(z=!0)}while((0<w.avail_in||w.avail_out===0)&&k!==a.Z_STREAM_END);return k===a.Z_STREAM_END&&(x=a.Z_FINISH),x===a.Z_FINISH?(k=s.inflateEnd(this.strm),this.onEnd(k),this.ended=!0,k===a.Z_OK):x!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(w.avail_out=0))},u.prototype.onData=function(f){this.chunks.push(f)},u.prototype.onEnd=function(f){f===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=f,this.msg=this.strm.msg},o.Inflate=u,o.inflate=h,o.inflateRaw=function(f,b){return(b=b||{}).raw=!0,h(f,b)},o.ungzip=h},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";o.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var p in d)d.hasOwnProperty(p)&&(a[p]=d[p])}}return a},o.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,p,v){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+p),v);else for(var u=0;u<p;u++)a[v+u]=c[d+u]},flattenChunks:function(a){var c,d,p,v,u,h;for(c=p=0,d=a.length;c<d;c++)p+=a[c].length;for(h=new Uint8Array(p),c=v=0,d=a.length;c<d;c++)u=a[c],h.set(u,v),v+=u.length;return h}},r={arraySet:function(a,c,d,p,v){for(var u=0;u<p;u++)a[v+u]=c[d+u]},flattenChunks:function(a){return[].concat.apply([],a)}};o.setTyped=function(a){a?(o.Buf8=Uint8Array,o.Buf16=Uint16Array,o.Buf32=Int32Array,o.assign(o,l)):(o.Buf8=Array,o.Buf16=Array,o.Buf32=Array,o.assign(o,r))},o.setTyped(s)},{}],42:[function(i,n,o){var s=i("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new s.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(p,v){if(v<65537&&(p.subarray&&r||!p.subarray&&l))return String.fromCharCode.apply(null,s.shrinkBuf(p,v));for(var u="",h=0;h<v;h++)u+=String.fromCharCode(p[h]);return u}a[254]=a[254]=1,o.string2buf=function(p){var v,u,h,f,b,k=p.length,x=0;for(f=0;f<k;f++)(64512&(u=p.charCodeAt(f)))==55296&&f+1<k&&(64512&(h=p.charCodeAt(f+1)))==56320&&(u=65536+(u-55296<<10)+(h-56320),f++),x+=u<128?1:u<2048?2:u<65536?3:4;for(v=new s.Buf8(x),f=b=0;b<x;f++)(64512&(u=p.charCodeAt(f)))==55296&&f+1<k&&(64512&(h=p.charCodeAt(f+1)))==56320&&(u=65536+(u-55296<<10)+(h-56320),f++),u<128?v[b++]=u:(u<2048?v[b++]=192|u>>>6:(u<65536?v[b++]=224|u>>>12:(v[b++]=240|u>>>18,v[b++]=128|u>>>12&63),v[b++]=128|u>>>6&63),v[b++]=128|63&u);return v},o.buf2binstring=function(p){return d(p,p.length)},o.binstring2buf=function(p){for(var v=new s.Buf8(p.length),u=0,h=v.length;u<h;u++)v[u]=p.charCodeAt(u);return v},o.buf2string=function(p,v){var u,h,f,b,k=v||p.length,x=new Array(2*k);for(u=h=0;u<k;)if((f=p[u++])<128)x[h++]=f;else if(4<(b=a[f]))x[h++]=65533,u+=b-1;else{for(f&=b===2?31:b===3?15:7;1<b&&u<k;)f=f<<6|63&p[u++],b--;1<b?x[h++]=65533:f<65536?x[h++]=f:(f-=65536,x[h++]=55296|f>>10&1023,x[h++]=56320|1023&f)}return d(x,h)},o.utf8border=function(p,v){var u;for((v=v||p.length)>p.length&&(v=p.length),u=v-1;0<=u&&(192&p[u])==128;)u--;return u<0||u===0?v:u+a[p[u]]>v?u:v}},{"./common":41}],43:[function(i,n,o){n.exports=function(s,l,r,a){for(var c=65535&s|0,d=s>>>16&65535|0,p=0;r!==0;){for(r-=p=2e3<r?2e3:r;d=d+(c=c+l[a++]|0)|0,--p;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(i,n,o){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,n,o){var s=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();n.exports=function(l,r,a,c){var d=s,p=c+a;l^=-1;for(var v=c;v<p;v++)l=l>>>8^d[255&(l^r[v])];return-1^l}},{}],46:[function(i,n,o){var s,l=i("../utils/common"),r=i("./trees"),a=i("./adler32"),c=i("./crc32"),d=i("./messages"),p=0,v=4,u=0,h=-2,f=-1,b=4,k=2,x=8,_=9,A=286,M=30,E=19,w=2*A+1,P=15,R=3,z=258,G=z+R+1,S=42,L=113,y=1,B=2,F=3,T=4;function D(g,q){return g.msg=d[q],q}function N(g){return(g<<1)-(4<g?9:0)}function X(g){for(var q=g.length;0<=--q;)g[q]=0}function Z(g){var q=g.state,H=q.pending;H>g.avail_out&&(H=g.avail_out),H!==0&&(l.arraySet(g.output,q.pending_buf,q.pending_out,H,g.next_out),g.next_out+=H,q.pending_out+=H,g.total_out+=H,g.avail_out-=H,q.pending-=H,q.pending===0&&(q.pending_out=0))}function U(g,q){r._tr_flush_block(g,0<=g.block_start?g.block_start:-1,g.strstart-g.block_start,q),g.block_start=g.strstart,Z(g.strm)}function ie(g,q){g.pending_buf[g.pending++]=q}function se(g,q){g.pending_buf[g.pending++]=q>>>8&255,g.pending_buf[g.pending++]=255&q}function le(g,q){var H,$,I=g.max_chain_length,C=g.strstart,W=g.prev_length,K=g.nice_match,V=g.strstart>g.w_size-G?g.strstart-(g.w_size-G):0,Q=g.window,oe=g.w_mask,ne=g.prev,ue=g.strstart+z,Se=Q[C+W-1],ke=Q[C+W];g.prev_length>=g.good_match&&(I>>=2),K>g.lookahead&&(K=g.lookahead);do if(Q[(H=q)+W]===ke&&Q[H+W-1]===Se&&Q[H]===Q[C]&&Q[++H]===Q[C+1]){C+=2,H++;do;while(Q[++C]===Q[++H]&&Q[++C]===Q[++H]&&Q[++C]===Q[++H]&&Q[++C]===Q[++H]&&Q[++C]===Q[++H]&&Q[++C]===Q[++H]&&Q[++C]===Q[++H]&&Q[++C]===Q[++H]&&C<ue);if($=z-(ue-C),C=ue-z,W<$){if(g.match_start=q,K<=(W=$))break;Se=Q[C+W-1],ke=Q[C+W]}}while((q=ne[q&oe])>V&&--I!=0);return W<=g.lookahead?W:g.lookahead}function ve(g){var q,H,$,I,C,W,K,V,Q,oe,ne=g.w_size;do{if(I=g.window_size-g.lookahead-g.strstart,g.strstart>=ne+(ne-G)){for(l.arraySet(g.window,g.window,ne,ne,0),g.match_start-=ne,g.strstart-=ne,g.block_start-=ne,q=H=g.hash_size;$=g.head[--q],g.head[q]=ne<=$?$-ne:0,--H;);for(q=H=ne;$=g.prev[--q],g.prev[q]=ne<=$?$-ne:0,--H;);I+=ne}if(g.strm.avail_in===0)break;if(W=g.strm,K=g.window,V=g.strstart+g.lookahead,Q=I,oe=void 0,oe=W.avail_in,Q<oe&&(oe=Q),H=oe===0?0:(W.avail_in-=oe,l.arraySet(K,W.input,W.next_in,oe,V),W.state.wrap===1?W.adler=a(W.adler,K,oe,V):W.state.wrap===2&&(W.adler=c(W.adler,K,oe,V)),W.next_in+=oe,W.total_in+=oe,oe),g.lookahead+=H,g.lookahead+g.insert>=R)for(C=g.strstart-g.insert,g.ins_h=g.window[C],g.ins_h=(g.ins_h<<g.hash_shift^g.window[C+1])&g.hash_mask;g.insert&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[C+R-1])&g.hash_mask,g.prev[C&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=C,C++,g.insert--,!(g.lookahead+g.insert<R)););}while(g.lookahead<G&&g.strm.avail_in!==0)}function Te(g,q){for(var H,$;;){if(g.lookahead<G){if(ve(g),g.lookahead<G&&q===p)return y;if(g.lookahead===0)break}if(H=0,g.lookahead>=R&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+R-1])&g.hash_mask,H=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),H!==0&&g.strstart-H<=g.w_size-G&&(g.match_length=le(g,H)),g.match_length>=R)if($=r._tr_tally(g,g.strstart-g.match_start,g.match_length-R),g.lookahead-=g.match_length,g.match_length<=g.max_lazy_match&&g.lookahead>=R){for(g.match_length--;g.strstart++,g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+R-1])&g.hash_mask,H=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart,--g.match_length!=0;);g.strstart++}else g.strstart+=g.match_length,g.match_length=0,g.ins_h=g.window[g.strstart],g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+1])&g.hash_mask;else $=r._tr_tally(g,0,g.window[g.strstart]),g.lookahead--,g.strstart++;if($&&(U(g,!1),g.strm.avail_out===0))return y}return g.insert=g.strstart<R-1?g.strstart:R-1,q===v?(U(g,!0),g.strm.avail_out===0?F:T):g.last_lit&&(U(g,!1),g.strm.avail_out===0)?y:B}function ye(g,q){for(var H,$,I;;){if(g.lookahead<G){if(ve(g),g.lookahead<G&&q===p)return y;if(g.lookahead===0)break}if(H=0,g.lookahead>=R&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+R-1])&g.hash_mask,H=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),g.prev_length=g.match_length,g.prev_match=g.match_start,g.match_length=R-1,H!==0&&g.prev_length<g.max_lazy_match&&g.strstart-H<=g.w_size-G&&(g.match_length=le(g,H),g.match_length<=5&&(g.strategy===1||g.match_length===R&&4096<g.strstart-g.match_start)&&(g.match_length=R-1)),g.prev_length>=R&&g.match_length<=g.prev_length){for(I=g.strstart+g.lookahead-R,$=r._tr_tally(g,g.strstart-1-g.prev_match,g.prev_length-R),g.lookahead-=g.prev_length-1,g.prev_length-=2;++g.strstart<=I&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+R-1])&g.hash_mask,H=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),--g.prev_length!=0;);if(g.match_available=0,g.match_length=R-1,g.strstart++,$&&(U(g,!1),g.strm.avail_out===0))return y}else if(g.match_available){if(($=r._tr_tally(g,0,g.window[g.strstart-1]))&&U(g,!1),g.strstart++,g.lookahead--,g.strm.avail_out===0)return y}else g.match_available=1,g.strstart++,g.lookahead--}return g.match_available&&($=r._tr_tally(g,0,g.window[g.strstart-1]),g.match_available=0),g.insert=g.strstart<R-1?g.strstart:R-1,q===v?(U(g,!0),g.strm.avail_out===0?F:T):g.last_lit&&(U(g,!1),g.strm.avail_out===0)?y:B}function ae(g,q,H,$,I){this.good_length=g,this.max_lazy=q,this.nice_length=H,this.max_chain=$,this.func=I}function Y(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=x,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*w),this.dyn_dtree=new l.Buf16(2*(2*M+1)),this.bl_tree=new l.Buf16(2*(2*E+1)),X(this.dyn_ltree),X(this.dyn_dtree),X(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(P+1),this.heap=new l.Buf16(2*A+1),X(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*A+1),X(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ce(g){var q;return g&&g.state?(g.total_in=g.total_out=0,g.data_type=k,(q=g.state).pending=0,q.pending_out=0,q.wrap<0&&(q.wrap=-q.wrap),q.status=q.wrap?S:L,g.adler=q.wrap===2?0:1,q.last_flush=p,r._tr_init(q),u):D(g,h)}function O(g){var q=ce(g);return q===u&&(function(H){H.window_size=2*H.w_size,X(H.head),H.max_lazy_match=s[H.level].max_lazy,H.good_match=s[H.level].good_length,H.nice_match=s[H.level].nice_length,H.max_chain_length=s[H.level].max_chain,H.strstart=0,H.block_start=0,H.lookahead=0,H.insert=0,H.match_length=H.prev_length=R-1,H.match_available=0,H.ins_h=0})(g.state),q}function j(g,q,H,$,I,C){if(!g)return h;var W=1;if(q===f&&(q=6),$<0?(W=0,$=-$):15<$&&(W=2,$-=16),I<1||_<I||H!==x||$<8||15<$||q<0||9<q||C<0||b<C)return D(g,h);$===8&&($=9);var K=new Y;return(g.state=K).strm=g,K.wrap=W,K.gzhead=null,K.w_bits=$,K.w_size=1<<K.w_bits,K.w_mask=K.w_size-1,K.hash_bits=I+7,K.hash_size=1<<K.hash_bits,K.hash_mask=K.hash_size-1,K.hash_shift=~~((K.hash_bits+R-1)/R),K.window=new l.Buf8(2*K.w_size),K.head=new l.Buf16(K.hash_size),K.prev=new l.Buf16(K.w_size),K.lit_bufsize=1<<I+6,K.pending_buf_size=4*K.lit_bufsize,K.pending_buf=new l.Buf8(K.pending_buf_size),K.d_buf=1*K.lit_bufsize,K.l_buf=3*K.lit_bufsize,K.level=q,K.strategy=C,K.method=H,O(g)}s=[new ae(0,0,0,0,function(g,q){var H=65535;for(H>g.pending_buf_size-5&&(H=g.pending_buf_size-5);;){if(g.lookahead<=1){if(ve(g),g.lookahead===0&&q===p)return y;if(g.lookahead===0)break}g.strstart+=g.lookahead,g.lookahead=0;var $=g.block_start+H;if((g.strstart===0||g.strstart>=$)&&(g.lookahead=g.strstart-$,g.strstart=$,U(g,!1),g.strm.avail_out===0)||g.strstart-g.block_start>=g.w_size-G&&(U(g,!1),g.strm.avail_out===0))return y}return g.insert=0,q===v?(U(g,!0),g.strm.avail_out===0?F:T):(g.strstart>g.block_start&&(U(g,!1),g.strm.avail_out),y)}),new ae(4,4,8,4,Te),new ae(4,5,16,8,Te),new ae(4,6,32,32,Te),new ae(4,4,16,16,ye),new ae(8,16,32,32,ye),new ae(8,16,128,128,ye),new ae(8,32,128,256,ye),new ae(32,128,258,1024,ye),new ae(32,258,258,4096,ye)],o.deflateInit=function(g,q){return j(g,q,x,15,8,0)},o.deflateInit2=j,o.deflateReset=O,o.deflateResetKeep=ce,o.deflateSetHeader=function(g,q){return g&&g.state?g.state.wrap!==2?h:(g.state.gzhead=q,u):h},o.deflate=function(g,q){var H,$,I,C;if(!g||!g.state||5<q||q<0)return g?D(g,h):h;if($=g.state,!g.output||!g.input&&g.avail_in!==0||$.status===666&&q!==v)return D(g,g.avail_out===0?-5:h);if($.strm=g,H=$.last_flush,$.last_flush=q,$.status===S)if($.wrap===2)g.adler=0,ie($,31),ie($,139),ie($,8),$.gzhead?(ie($,($.gzhead.text?1:0)+($.gzhead.hcrc?2:0)+($.gzhead.extra?4:0)+($.gzhead.name?8:0)+($.gzhead.comment?16:0)),ie($,255&$.gzhead.time),ie($,$.gzhead.time>>8&255),ie($,$.gzhead.time>>16&255),ie($,$.gzhead.time>>24&255),ie($,$.level===9?2:2<=$.strategy||$.level<2?4:0),ie($,255&$.gzhead.os),$.gzhead.extra&&$.gzhead.extra.length&&(ie($,255&$.gzhead.extra.length),ie($,$.gzhead.extra.length>>8&255)),$.gzhead.hcrc&&(g.adler=c(g.adler,$.pending_buf,$.pending,0)),$.gzindex=0,$.status=69):(ie($,0),ie($,0),ie($,0),ie($,0),ie($,0),ie($,$.level===9?2:2<=$.strategy||$.level<2?4:0),ie($,3),$.status=L);else{var W=x+($.w_bits-8<<4)<<8;W|=(2<=$.strategy||$.level<2?0:$.level<6?1:$.level===6?2:3)<<6,$.strstart!==0&&(W|=32),W+=31-W%31,$.status=L,se($,W),$.strstart!==0&&(se($,g.adler>>>16),se($,65535&g.adler)),g.adler=1}if($.status===69)if($.gzhead.extra){for(I=$.pending;$.gzindex<(65535&$.gzhead.extra.length)&&($.pending!==$.pending_buf_size||($.gzhead.hcrc&&$.pending>I&&(g.adler=c(g.adler,$.pending_buf,$.pending-I,I)),Z(g),I=$.pending,$.pending!==$.pending_buf_size));)ie($,255&$.gzhead.extra[$.gzindex]),$.gzindex++;$.gzhead.hcrc&&$.pending>I&&(g.adler=c(g.adler,$.pending_buf,$.pending-I,I)),$.gzindex===$.gzhead.extra.length&&($.gzindex=0,$.status=73)}else $.status=73;if($.status===73)if($.gzhead.name){I=$.pending;do{if($.pending===$.pending_buf_size&&($.gzhead.hcrc&&$.pending>I&&(g.adler=c(g.adler,$.pending_buf,$.pending-I,I)),Z(g),I=$.pending,$.pending===$.pending_buf_size)){C=1;break}C=$.gzindex<$.gzhead.name.length?255&$.gzhead.name.charCodeAt($.gzindex++):0,ie($,C)}while(C!==0);$.gzhead.hcrc&&$.pending>I&&(g.adler=c(g.adler,$.pending_buf,$.pending-I,I)),C===0&&($.gzindex=0,$.status=91)}else $.status=91;if($.status===91)if($.gzhead.comment){I=$.pending;do{if($.pending===$.pending_buf_size&&($.gzhead.hcrc&&$.pending>I&&(g.adler=c(g.adler,$.pending_buf,$.pending-I,I)),Z(g),I=$.pending,$.pending===$.pending_buf_size)){C=1;break}C=$.gzindex<$.gzhead.comment.length?255&$.gzhead.comment.charCodeAt($.gzindex++):0,ie($,C)}while(C!==0);$.gzhead.hcrc&&$.pending>I&&(g.adler=c(g.adler,$.pending_buf,$.pending-I,I)),C===0&&($.status=103)}else $.status=103;if($.status===103&&($.gzhead.hcrc?($.pending+2>$.pending_buf_size&&Z(g),$.pending+2<=$.pending_buf_size&&(ie($,255&g.adler),ie($,g.adler>>8&255),g.adler=0,$.status=L)):$.status=L),$.pending!==0){if(Z(g),g.avail_out===0)return $.last_flush=-1,u}else if(g.avail_in===0&&N(q)<=N(H)&&q!==v)return D(g,-5);if($.status===666&&g.avail_in!==0)return D(g,-5);if(g.avail_in!==0||$.lookahead!==0||q!==p&&$.status!==666){var K=$.strategy===2?(function(V,Q){for(var oe;;){if(V.lookahead===0&&(ve(V),V.lookahead===0)){if(Q===p)return y;break}if(V.match_length=0,oe=r._tr_tally(V,0,V.window[V.strstart]),V.lookahead--,V.strstart++,oe&&(U(V,!1),V.strm.avail_out===0))return y}return V.insert=0,Q===v?(U(V,!0),V.strm.avail_out===0?F:T):V.last_lit&&(U(V,!1),V.strm.avail_out===0)?y:B})($,q):$.strategy===3?(function(V,Q){for(var oe,ne,ue,Se,ke=V.window;;){if(V.lookahead<=z){if(ve(V),V.lookahead<=z&&Q===p)return y;if(V.lookahead===0)break}if(V.match_length=0,V.lookahead>=R&&0<V.strstart&&(ne=ke[ue=V.strstart-1])===ke[++ue]&&ne===ke[++ue]&&ne===ke[++ue]){Se=V.strstart+z;do;while(ne===ke[++ue]&&ne===ke[++ue]&&ne===ke[++ue]&&ne===ke[++ue]&&ne===ke[++ue]&&ne===ke[++ue]&&ne===ke[++ue]&&ne===ke[++ue]&&ue<Se);V.match_length=z-(Se-ue),V.match_length>V.lookahead&&(V.match_length=V.lookahead)}if(V.match_length>=R?(oe=r._tr_tally(V,1,V.match_length-R),V.lookahead-=V.match_length,V.strstart+=V.match_length,V.match_length=0):(oe=r._tr_tally(V,0,V.window[V.strstart]),V.lookahead--,V.strstart++),oe&&(U(V,!1),V.strm.avail_out===0))return y}return V.insert=0,Q===v?(U(V,!0),V.strm.avail_out===0?F:T):V.last_lit&&(U(V,!1),V.strm.avail_out===0)?y:B})($,q):s[$.level].func($,q);if(K!==F&&K!==T||($.status=666),K===y||K===F)return g.avail_out===0&&($.last_flush=-1),u;if(K===B&&(q===1?r._tr_align($):q!==5&&(r._tr_stored_block($,0,0,!1),q===3&&(X($.head),$.lookahead===0&&($.strstart=0,$.block_start=0,$.insert=0))),Z(g),g.avail_out===0))return $.last_flush=-1,u}return q!==v?u:$.wrap<=0?1:($.wrap===2?(ie($,255&g.adler),ie($,g.adler>>8&255),ie($,g.adler>>16&255),ie($,g.adler>>24&255),ie($,255&g.total_in),ie($,g.total_in>>8&255),ie($,g.total_in>>16&255),ie($,g.total_in>>24&255)):(se($,g.adler>>>16),se($,65535&g.adler)),Z(g),0<$.wrap&&($.wrap=-$.wrap),$.pending!==0?u:1)},o.deflateEnd=function(g){var q;return g&&g.state?(q=g.state.status)!==S&&q!==69&&q!==73&&q!==91&&q!==103&&q!==L&&q!==666?D(g,h):(g.state=null,q===L?D(g,-3):u):h},o.deflateSetDictionary=function(g,q){var H,$,I,C,W,K,V,Q,oe=q.length;if(!g||!g.state||(C=(H=g.state).wrap)===2||C===1&&H.status!==S||H.lookahead)return h;for(C===1&&(g.adler=a(g.adler,q,oe,0)),H.wrap=0,oe>=H.w_size&&(C===0&&(X(H.head),H.strstart=0,H.block_start=0,H.insert=0),Q=new l.Buf8(H.w_size),l.arraySet(Q,q,oe-H.w_size,H.w_size,0),q=Q,oe=H.w_size),W=g.avail_in,K=g.next_in,V=g.input,g.avail_in=oe,g.next_in=0,g.input=q,ve(H);H.lookahead>=R;){for($=H.strstart,I=H.lookahead-(R-1);H.ins_h=(H.ins_h<<H.hash_shift^H.window[$+R-1])&H.hash_mask,H.prev[$&H.w_mask]=H.head[H.ins_h],H.head[H.ins_h]=$,$++,--I;);H.strstart=$,H.lookahead=R-1,ve(H)}return H.strstart+=H.lookahead,H.block_start=H.strstart,H.insert=H.lookahead,H.lookahead=0,H.match_length=H.prev_length=R-1,H.match_available=0,g.next_in=K,g.input=V,g.avail_in=W,H.wrap=C,u},o.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,n,o){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,n,o){n.exports=function(s,l){var r,a,c,d,p,v,u,h,f,b,k,x,_,A,M,E,w,P,R,z,G,S,L,y,B;r=s.state,a=s.next_in,y=s.input,c=a+(s.avail_in-5),d=s.next_out,B=s.output,p=d-(l-s.avail_out),v=d+(s.avail_out-257),u=r.dmax,h=r.wsize,f=r.whave,b=r.wnext,k=r.window,x=r.hold,_=r.bits,A=r.lencode,M=r.distcode,E=(1<<r.lenbits)-1,w=(1<<r.distbits)-1;e:do{_<15&&(x+=y[a++]<<_,_+=8,x+=y[a++]<<_,_+=8),P=A[x&E];t:for(;;){if(x>>>=R=P>>>24,_-=R,(R=P>>>16&255)===0)B[d++]=65535&P;else{if(!(16&R)){if((64&R)==0){P=A[(65535&P)+(x&(1<<R)-1)];continue t}if(32&R){r.mode=12;break e}s.msg="invalid literal/length code",r.mode=30;break e}z=65535&P,(R&=15)&&(_<R&&(x+=y[a++]<<_,_+=8),z+=x&(1<<R)-1,x>>>=R,_-=R),_<15&&(x+=y[a++]<<_,_+=8,x+=y[a++]<<_,_+=8),P=M[x&w];i:for(;;){if(x>>>=R=P>>>24,_-=R,!(16&(R=P>>>16&255))){if((64&R)==0){P=M[(65535&P)+(x&(1<<R)-1)];continue i}s.msg="invalid distance code",r.mode=30;break e}if(G=65535&P,_<(R&=15)&&(x+=y[a++]<<_,(_+=8)<R&&(x+=y[a++]<<_,_+=8)),u<(G+=x&(1<<R)-1)){s.msg="invalid distance too far back",r.mode=30;break e}if(x>>>=R,_-=R,(R=d-p)<G){if(f<(R=G-R)&&r.sane){s.msg="invalid distance too far back",r.mode=30;break e}if(L=k,(S=0)===b){if(S+=h-R,R<z){for(z-=R;B[d++]=k[S++],--R;);S=d-G,L=B}}else if(b<R){if(S+=h+b-R,(R-=b)<z){for(z-=R;B[d++]=k[S++],--R;);if(S=0,b<z){for(z-=R=b;B[d++]=k[S++],--R;);S=d-G,L=B}}}else if(S+=b-R,R<z){for(z-=R;B[d++]=k[S++],--R;);S=d-G,L=B}for(;2<z;)B[d++]=L[S++],B[d++]=L[S++],B[d++]=L[S++],z-=3;z&&(B[d++]=L[S++],1<z&&(B[d++]=L[S++]))}else{for(S=d-G;B[d++]=B[S++],B[d++]=B[S++],B[d++]=B[S++],2<(z-=3););z&&(B[d++]=B[S++],1<z&&(B[d++]=B[S++]))}break}}break}}while(a<c&&d<v);a-=z=_>>3,x&=(1<<(_-=z<<3))-1,s.next_in=a,s.next_out=d,s.avail_in=a<c?c-a+5:5-(a-c),s.avail_out=d<v?v-d+257:257-(d-v),r.hold=x,r.bits=_}},{}],49:[function(i,n,o){var s=i("../utils/common"),l=i("./adler32"),r=i("./crc32"),a=i("./inffast"),c=i("./inftrees"),d=1,p=2,v=0,u=-2,h=1,f=852,b=592;function k(S){return(S>>>24&255)+(S>>>8&65280)+((65280&S)<<8)+((255&S)<<24)}function x(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new s.Buf16(320),this.work=new s.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function _(S){var L;return S&&S.state?(L=S.state,S.total_in=S.total_out=L.total=0,S.msg="",L.wrap&&(S.adler=1&L.wrap),L.mode=h,L.last=0,L.havedict=0,L.dmax=32768,L.head=null,L.hold=0,L.bits=0,L.lencode=L.lendyn=new s.Buf32(f),L.distcode=L.distdyn=new s.Buf32(b),L.sane=1,L.back=-1,v):u}function A(S){var L;return S&&S.state?((L=S.state).wsize=0,L.whave=0,L.wnext=0,_(S)):u}function M(S,L){var y,B;return S&&S.state?(B=S.state,L<0?(y=0,L=-L):(y=1+(L>>4),L<48&&(L&=15)),L&&(L<8||15<L)?u:(B.window!==null&&B.wbits!==L&&(B.window=null),B.wrap=y,B.wbits=L,A(S))):u}function E(S,L){var y,B;return S?(B=new x,(S.state=B).window=null,(y=M(S,L))!==v&&(S.state=null),y):u}var w,P,R=!0;function z(S){if(R){var L;for(w=new s.Buf32(512),P=new s.Buf32(32),L=0;L<144;)S.lens[L++]=8;for(;L<256;)S.lens[L++]=9;for(;L<280;)S.lens[L++]=7;for(;L<288;)S.lens[L++]=8;for(c(d,S.lens,0,288,w,0,S.work,{bits:9}),L=0;L<32;)S.lens[L++]=5;c(p,S.lens,0,32,P,0,S.work,{bits:5}),R=!1}S.lencode=w,S.lenbits=9,S.distcode=P,S.distbits=5}function G(S,L,y,B){var F,T=S.state;return T.window===null&&(T.wsize=1<<T.wbits,T.wnext=0,T.whave=0,T.window=new s.Buf8(T.wsize)),B>=T.wsize?(s.arraySet(T.window,L,y-T.wsize,T.wsize,0),T.wnext=0,T.whave=T.wsize):(B<(F=T.wsize-T.wnext)&&(F=B),s.arraySet(T.window,L,y-B,F,T.wnext),(B-=F)?(s.arraySet(T.window,L,y-B,B,0),T.wnext=B,T.whave=T.wsize):(T.wnext+=F,T.wnext===T.wsize&&(T.wnext=0),T.whave<T.wsize&&(T.whave+=F))),0}o.inflateReset=A,o.inflateReset2=M,o.inflateResetKeep=_,o.inflateInit=function(S){return E(S,15)},o.inflateInit2=E,o.inflate=function(S,L){var y,B,F,T,D,N,X,Z,U,ie,se,le,ve,Te,ye,ae,Y,ce,O,j,g,q,H,$,I=0,C=new s.Buf8(4),W=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!S||!S.state||!S.output||!S.input&&S.avail_in!==0)return u;(y=S.state).mode===12&&(y.mode=13),D=S.next_out,F=S.output,X=S.avail_out,T=S.next_in,B=S.input,N=S.avail_in,Z=y.hold,U=y.bits,ie=N,se=X,q=v;e:for(;;)switch(y.mode){case h:if(y.wrap===0){y.mode=13;break}for(;U<16;){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}if(2&y.wrap&&Z===35615){C[y.check=0]=255&Z,C[1]=Z>>>8&255,y.check=r(y.check,C,2,0),U=Z=0,y.mode=2;break}if(y.flags=0,y.head&&(y.head.done=!1),!(1&y.wrap)||(((255&Z)<<8)+(Z>>8))%31){S.msg="incorrect header check",y.mode=30;break}if((15&Z)!=8){S.msg="unknown compression method",y.mode=30;break}if(U-=4,g=8+(15&(Z>>>=4)),y.wbits===0)y.wbits=g;else if(g>y.wbits){S.msg="invalid window size",y.mode=30;break}y.dmax=1<<g,S.adler=y.check=1,y.mode=512&Z?10:12,U=Z=0;break;case 2:for(;U<16;){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}if(y.flags=Z,(255&y.flags)!=8){S.msg="unknown compression method",y.mode=30;break}if(57344&y.flags){S.msg="unknown header flags set",y.mode=30;break}y.head&&(y.head.text=Z>>8&1),512&y.flags&&(C[0]=255&Z,C[1]=Z>>>8&255,y.check=r(y.check,C,2,0)),U=Z=0,y.mode=3;case 3:for(;U<32;){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}y.head&&(y.head.time=Z),512&y.flags&&(C[0]=255&Z,C[1]=Z>>>8&255,C[2]=Z>>>16&255,C[3]=Z>>>24&255,y.check=r(y.check,C,4,0)),U=Z=0,y.mode=4;case 4:for(;U<16;){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}y.head&&(y.head.xflags=255&Z,y.head.os=Z>>8),512&y.flags&&(C[0]=255&Z,C[1]=Z>>>8&255,y.check=r(y.check,C,2,0)),U=Z=0,y.mode=5;case 5:if(1024&y.flags){for(;U<16;){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}y.length=Z,y.head&&(y.head.extra_len=Z),512&y.flags&&(C[0]=255&Z,C[1]=Z>>>8&255,y.check=r(y.check,C,2,0)),U=Z=0}else y.head&&(y.head.extra=null);y.mode=6;case 6:if(1024&y.flags&&(N<(le=y.length)&&(le=N),le&&(y.head&&(g=y.head.extra_len-y.length,y.head.extra||(y.head.extra=new Array(y.head.extra_len)),s.arraySet(y.head.extra,B,T,le,g)),512&y.flags&&(y.check=r(y.check,B,le,T)),N-=le,T+=le,y.length-=le),y.length))break e;y.length=0,y.mode=7;case 7:if(2048&y.flags){if(N===0)break e;for(le=0;g=B[T+le++],y.head&&g&&y.length<65536&&(y.head.name+=String.fromCharCode(g)),g&&le<N;);if(512&y.flags&&(y.check=r(y.check,B,le,T)),N-=le,T+=le,g)break e}else y.head&&(y.head.name=null);y.length=0,y.mode=8;case 8:if(4096&y.flags){if(N===0)break e;for(le=0;g=B[T+le++],y.head&&g&&y.length<65536&&(y.head.comment+=String.fromCharCode(g)),g&&le<N;);if(512&y.flags&&(y.check=r(y.check,B,le,T)),N-=le,T+=le,g)break e}else y.head&&(y.head.comment=null);y.mode=9;case 9:if(512&y.flags){for(;U<16;){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}if(Z!==(65535&y.check)){S.msg="header crc mismatch",y.mode=30;break}U=Z=0}y.head&&(y.head.hcrc=y.flags>>9&1,y.head.done=!0),S.adler=y.check=0,y.mode=12;break;case 10:for(;U<32;){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}S.adler=y.check=k(Z),U=Z=0,y.mode=11;case 11:if(y.havedict===0)return S.next_out=D,S.avail_out=X,S.next_in=T,S.avail_in=N,y.hold=Z,y.bits=U,2;S.adler=y.check=1,y.mode=12;case 12:if(L===5||L===6)break e;case 13:if(y.last){Z>>>=7&U,U-=7&U,y.mode=27;break}for(;U<3;){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}switch(y.last=1&Z,U-=1,3&(Z>>>=1)){case 0:y.mode=14;break;case 1:if(z(y),y.mode=20,L!==6)break;Z>>>=2,U-=2;break e;case 2:y.mode=17;break;case 3:S.msg="invalid block type",y.mode=30}Z>>>=2,U-=2;break;case 14:for(Z>>>=7&U,U-=7&U;U<32;){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}if((65535&Z)!=(Z>>>16^65535)){S.msg="invalid stored block lengths",y.mode=30;break}if(y.length=65535&Z,U=Z=0,y.mode=15,L===6)break e;case 15:y.mode=16;case 16:if(le=y.length){if(N<le&&(le=N),X<le&&(le=X),le===0)break e;s.arraySet(F,B,T,le,D),N-=le,T+=le,X-=le,D+=le,y.length-=le;break}y.mode=12;break;case 17:for(;U<14;){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}if(y.nlen=257+(31&Z),Z>>>=5,U-=5,y.ndist=1+(31&Z),Z>>>=5,U-=5,y.ncode=4+(15&Z),Z>>>=4,U-=4,286<y.nlen||30<y.ndist){S.msg="too many length or distance symbols",y.mode=30;break}y.have=0,y.mode=18;case 18:for(;y.have<y.ncode;){for(;U<3;){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}y.lens[W[y.have++]]=7&Z,Z>>>=3,U-=3}for(;y.have<19;)y.lens[W[y.have++]]=0;if(y.lencode=y.lendyn,y.lenbits=7,H={bits:y.lenbits},q=c(0,y.lens,0,19,y.lencode,0,y.work,H),y.lenbits=H.bits,q){S.msg="invalid code lengths set",y.mode=30;break}y.have=0,y.mode=19;case 19:for(;y.have<y.nlen+y.ndist;){for(;ae=(I=y.lencode[Z&(1<<y.lenbits)-1])>>>16&255,Y=65535&I,!((ye=I>>>24)<=U);){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}if(Y<16)Z>>>=ye,U-=ye,y.lens[y.have++]=Y;else{if(Y===16){for($=ye+2;U<$;){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}if(Z>>>=ye,U-=ye,y.have===0){S.msg="invalid bit length repeat",y.mode=30;break}g=y.lens[y.have-1],le=3+(3&Z),Z>>>=2,U-=2}else if(Y===17){for($=ye+3;U<$;){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}U-=ye,g=0,le=3+(7&(Z>>>=ye)),Z>>>=3,U-=3}else{for($=ye+7;U<$;){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}U-=ye,g=0,le=11+(127&(Z>>>=ye)),Z>>>=7,U-=7}if(y.have+le>y.nlen+y.ndist){S.msg="invalid bit length repeat",y.mode=30;break}for(;le--;)y.lens[y.have++]=g}}if(y.mode===30)break;if(y.lens[256]===0){S.msg="invalid code -- missing end-of-block",y.mode=30;break}if(y.lenbits=9,H={bits:y.lenbits},q=c(d,y.lens,0,y.nlen,y.lencode,0,y.work,H),y.lenbits=H.bits,q){S.msg="invalid literal/lengths set",y.mode=30;break}if(y.distbits=6,y.distcode=y.distdyn,H={bits:y.distbits},q=c(p,y.lens,y.nlen,y.ndist,y.distcode,0,y.work,H),y.distbits=H.bits,q){S.msg="invalid distances set",y.mode=30;break}if(y.mode=20,L===6)break e;case 20:y.mode=21;case 21:if(6<=N&&258<=X){S.next_out=D,S.avail_out=X,S.next_in=T,S.avail_in=N,y.hold=Z,y.bits=U,a(S,se),D=S.next_out,F=S.output,X=S.avail_out,T=S.next_in,B=S.input,N=S.avail_in,Z=y.hold,U=y.bits,y.mode===12&&(y.back=-1);break}for(y.back=0;ae=(I=y.lencode[Z&(1<<y.lenbits)-1])>>>16&255,Y=65535&I,!((ye=I>>>24)<=U);){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}if(ae&&(240&ae)==0){for(ce=ye,O=ae,j=Y;ae=(I=y.lencode[j+((Z&(1<<ce+O)-1)>>ce)])>>>16&255,Y=65535&I,!(ce+(ye=I>>>24)<=U);){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}Z>>>=ce,U-=ce,y.back+=ce}if(Z>>>=ye,U-=ye,y.back+=ye,y.length=Y,ae===0){y.mode=26;break}if(32&ae){y.back=-1,y.mode=12;break}if(64&ae){S.msg="invalid literal/length code",y.mode=30;break}y.extra=15&ae,y.mode=22;case 22:if(y.extra){for($=y.extra;U<$;){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}y.length+=Z&(1<<y.extra)-1,Z>>>=y.extra,U-=y.extra,y.back+=y.extra}y.was=y.length,y.mode=23;case 23:for(;ae=(I=y.distcode[Z&(1<<y.distbits)-1])>>>16&255,Y=65535&I,!((ye=I>>>24)<=U);){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}if((240&ae)==0){for(ce=ye,O=ae,j=Y;ae=(I=y.distcode[j+((Z&(1<<ce+O)-1)>>ce)])>>>16&255,Y=65535&I,!(ce+(ye=I>>>24)<=U);){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}Z>>>=ce,U-=ce,y.back+=ce}if(Z>>>=ye,U-=ye,y.back+=ye,64&ae){S.msg="invalid distance code",y.mode=30;break}y.offset=Y,y.extra=15&ae,y.mode=24;case 24:if(y.extra){for($=y.extra;U<$;){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}y.offset+=Z&(1<<y.extra)-1,Z>>>=y.extra,U-=y.extra,y.back+=y.extra}if(y.offset>y.dmax){S.msg="invalid distance too far back",y.mode=30;break}y.mode=25;case 25:if(X===0)break e;if(le=se-X,y.offset>le){if((le=y.offset-le)>y.whave&&y.sane){S.msg="invalid distance too far back",y.mode=30;break}ve=le>y.wnext?(le-=y.wnext,y.wsize-le):y.wnext-le,le>y.length&&(le=y.length),Te=y.window}else Te=F,ve=D-y.offset,le=y.length;for(X<le&&(le=X),X-=le,y.length-=le;F[D++]=Te[ve++],--le;);y.length===0&&(y.mode=21);break;case 26:if(X===0)break e;F[D++]=y.length,X--,y.mode=21;break;case 27:if(y.wrap){for(;U<32;){if(N===0)break e;N--,Z|=B[T++]<<U,U+=8}if(se-=X,S.total_out+=se,y.total+=se,se&&(S.adler=y.check=y.flags?r(y.check,F,se,D-se):l(y.check,F,se,D-se)),se=X,(y.flags?Z:k(Z))!==y.check){S.msg="incorrect data check",y.mode=30;break}U=Z=0}y.mode=28;case 28:if(y.wrap&&y.flags){for(;U<32;){if(N===0)break e;N--,Z+=B[T++]<<U,U+=8}if(Z!==(4294967295&y.total)){S.msg="incorrect length check",y.mode=30;break}U=Z=0}y.mode=29;case 29:q=1;break e;case 30:q=-3;break e;case 31:return-4;case 32:default:return u}return S.next_out=D,S.avail_out=X,S.next_in=T,S.avail_in=N,y.hold=Z,y.bits=U,(y.wsize||se!==S.avail_out&&y.mode<30&&(y.mode<27||L!==4))&&G(S,S.output,S.next_out,se-S.avail_out)?(y.mode=31,-4):(ie-=S.avail_in,se-=S.avail_out,S.total_in+=ie,S.total_out+=se,y.total+=se,y.wrap&&se&&(S.adler=y.check=y.flags?r(y.check,F,se,S.next_out-se):l(y.check,F,se,S.next_out-se)),S.data_type=y.bits+(y.last?64:0)+(y.mode===12?128:0)+(y.mode===20||y.mode===15?256:0),(ie==0&&se===0||L===4)&&q===v&&(q=-5),q)},o.inflateEnd=function(S){if(!S||!S.state)return u;var L=S.state;return L.window&&(L.window=null),S.state=null,v},o.inflateGetHeader=function(S,L){var y;return S&&S.state?(2&(y=S.state).wrap)==0?u:((y.head=L).done=!1,v):u},o.inflateSetDictionary=function(S,L){var y,B=L.length;return S&&S.state?(y=S.state).wrap!==0&&y.mode!==11?u:y.mode===11&&l(1,L,B,0)!==y.check?-3:G(S,L,B,B)?(y.mode=31,-4):(y.havedict=1,v):u},o.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,n,o){var s=i("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(d,p,v,u,h,f,b,k){var x,_,A,M,E,w,P,R,z,G=k.bits,S=0,L=0,y=0,B=0,F=0,T=0,D=0,N=0,X=0,Z=0,U=null,ie=0,se=new s.Buf16(16),le=new s.Buf16(16),ve=null,Te=0;for(S=0;S<=15;S++)se[S]=0;for(L=0;L<u;L++)se[p[v+L]]++;for(F=G,B=15;1<=B&&se[B]===0;B--);if(B<F&&(F=B),B===0)return h[f++]=20971520,h[f++]=20971520,k.bits=1,0;for(y=1;y<B&&se[y]===0;y++);for(F<y&&(F=y),S=N=1;S<=15;S++)if(N<<=1,(N-=se[S])<0)return-1;if(0<N&&(d===0||B!==1))return-1;for(le[1]=0,S=1;S<15;S++)le[S+1]=le[S]+se[S];for(L=0;L<u;L++)p[v+L]!==0&&(b[le[p[v+L]]++]=L);if(w=d===0?(U=ve=b,19):d===1?(U=l,ie-=257,ve=r,Te-=257,256):(U=a,ve=c,-1),S=y,E=f,D=L=Z=0,A=-1,M=(X=1<<(T=F))-1,d===1&&852<X||d===2&&592<X)return 1;for(;;){for(P=S-D,z=b[L]<w?(R=0,b[L]):b[L]>w?(R=ve[Te+b[L]],U[ie+b[L]]):(R=96,0),x=1<<S-D,y=_=1<<T;h[E+(Z>>D)+(_-=x)]=P<<24|R<<16|z|0,_!==0;);for(x=1<<S-1;Z&x;)x>>=1;if(x!==0?(Z&=x-1,Z+=x):Z=0,L++,--se[S]==0){if(S===B)break;S=p[v+b[L]]}if(F<S&&(Z&M)!==A){for(D===0&&(D=F),E+=y,N=1<<(T=S-D);T+D<B&&!((N-=se[T+D])<=0);)T++,N<<=1;if(X+=1<<T,d===1&&852<X||d===2&&592<X)return 1;h[A=Z&M]=F<<24|T<<16|E-f|0}}return Z!==0&&(h[E+Z]=S-D<<24|64<<16|0),k.bits=F,0}},{"../utils/common":41}],51:[function(i,n,o){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,n,o){var s=i("../utils/common"),l=0,r=1;function a(I){for(var C=I.length;0<=--C;)I[C]=0}var c=0,d=29,p=256,v=p+1+d,u=30,h=19,f=2*v+1,b=15,k=16,x=7,_=256,A=16,M=17,E=18,w=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],P=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],R=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],z=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],G=new Array(2*(v+2));a(G);var S=new Array(2*u);a(S);var L=new Array(512);a(L);var y=new Array(256);a(y);var B=new Array(d);a(B);var F,T,D,N=new Array(u);function X(I,C,W,K,V){this.static_tree=I,this.extra_bits=C,this.extra_base=W,this.elems=K,this.max_length=V,this.has_stree=I&&I.length}function Z(I,C){this.dyn_tree=I,this.max_code=0,this.stat_desc=C}function U(I){return I<256?L[I]:L[256+(I>>>7)]}function ie(I,C){I.pending_buf[I.pending++]=255&C,I.pending_buf[I.pending++]=C>>>8&255}function se(I,C,W){I.bi_valid>k-W?(I.bi_buf|=C<<I.bi_valid&65535,ie(I,I.bi_buf),I.bi_buf=C>>k-I.bi_valid,I.bi_valid+=W-k):(I.bi_buf|=C<<I.bi_valid&65535,I.bi_valid+=W)}function le(I,C,W){se(I,W[2*C],W[2*C+1])}function ve(I,C){for(var W=0;W|=1&I,I>>>=1,W<<=1,0<--C;);return W>>>1}function Te(I,C,W){var K,V,Q=new Array(b+1),oe=0;for(K=1;K<=b;K++)Q[K]=oe=oe+W[K-1]<<1;for(V=0;V<=C;V++){var ne=I[2*V+1];ne!==0&&(I[2*V]=ve(Q[ne]++,ne))}}function ye(I){var C;for(C=0;C<v;C++)I.dyn_ltree[2*C]=0;for(C=0;C<u;C++)I.dyn_dtree[2*C]=0;for(C=0;C<h;C++)I.bl_tree[2*C]=0;I.dyn_ltree[2*_]=1,I.opt_len=I.static_len=0,I.last_lit=I.matches=0}function ae(I){8<I.bi_valid?ie(I,I.bi_buf):0<I.bi_valid&&(I.pending_buf[I.pending++]=I.bi_buf),I.bi_buf=0,I.bi_valid=0}function Y(I,C,W,K){var V=2*C,Q=2*W;return I[V]<I[Q]||I[V]===I[Q]&&K[C]<=K[W]}function ce(I,C,W){for(var K=I.heap[W],V=W<<1;V<=I.heap_len&&(V<I.heap_len&&Y(C,I.heap[V+1],I.heap[V],I.depth)&&V++,!Y(C,K,I.heap[V],I.depth));)I.heap[W]=I.heap[V],W=V,V<<=1;I.heap[W]=K}function O(I,C,W){var K,V,Q,oe,ne=0;if(I.last_lit!==0)for(;K=I.pending_buf[I.d_buf+2*ne]<<8|I.pending_buf[I.d_buf+2*ne+1],V=I.pending_buf[I.l_buf+ne],ne++,K===0?le(I,V,C):(le(I,(Q=y[V])+p+1,C),(oe=w[Q])!==0&&se(I,V-=B[Q],oe),le(I,Q=U(--K),W),(oe=P[Q])!==0&&se(I,K-=N[Q],oe)),ne<I.last_lit;);le(I,_,C)}function j(I,C){var W,K,V,Q=C.dyn_tree,oe=C.stat_desc.static_tree,ne=C.stat_desc.has_stree,ue=C.stat_desc.elems,Se=-1;for(I.heap_len=0,I.heap_max=f,W=0;W<ue;W++)Q[2*W]!==0?(I.heap[++I.heap_len]=Se=W,I.depth[W]=0):Q[2*W+1]=0;for(;I.heap_len<2;)Q[2*(V=I.heap[++I.heap_len]=Se<2?++Se:0)]=1,I.depth[V]=0,I.opt_len--,ne&&(I.static_len-=oe[2*V+1]);for(C.max_code=Se,W=I.heap_len>>1;1<=W;W--)ce(I,Q,W);for(V=ue;W=I.heap[1],I.heap[1]=I.heap[I.heap_len--],ce(I,Q,1),K=I.heap[1],I.heap[--I.heap_max]=W,I.heap[--I.heap_max]=K,Q[2*V]=Q[2*W]+Q[2*K],I.depth[V]=(I.depth[W]>=I.depth[K]?I.depth[W]:I.depth[K])+1,Q[2*W+1]=Q[2*K+1]=V,I.heap[1]=V++,ce(I,Q,1),2<=I.heap_len;);I.heap[--I.heap_max]=I.heap[1],(function(ke,Me){var Ve,Ge,Je,De,Zt,st,Xe=Me.dyn_tree,Ft=Me.max_code,Ni=Me.stat_desc.static_tree,Fo=Me.stat_desc.has_stree,Ho=Me.stat_desc.extra_bits,Un=Me.stat_desc.extra_base,ki=Me.stat_desc.max_length,zi=0;for(De=0;De<=b;De++)ke.bl_count[De]=0;for(Xe[2*ke.heap[ke.heap_max]+1]=0,Ve=ke.heap_max+1;Ve<f;Ve++)ki<(De=Xe[2*Xe[2*(Ge=ke.heap[Ve])+1]+1]+1)&&(De=ki,zi++),Xe[2*Ge+1]=De,Ft<Ge||(ke.bl_count[De]++,Zt=0,Un<=Ge&&(Zt=Ho[Ge-Un]),st=Xe[2*Ge],ke.opt_len+=st*(De+Zt),Fo&&(ke.static_len+=st*(Ni[2*Ge+1]+Zt)));if(zi!==0){do{for(De=ki-1;ke.bl_count[De]===0;)De--;ke.bl_count[De]--,ke.bl_count[De+1]+=2,ke.bl_count[ki]--,zi-=2}while(0<zi);for(De=ki;De!==0;De--)for(Ge=ke.bl_count[De];Ge!==0;)Ft<(Je=ke.heap[--Ve])||(Xe[2*Je+1]!==De&&(ke.opt_len+=(De-Xe[2*Je+1])*Xe[2*Je],Xe[2*Je+1]=De),Ge--)}})(I,C),Te(Q,Se,I.bl_count)}function g(I,C,W){var K,V,Q=-1,oe=C[1],ne=0,ue=7,Se=4;for(oe===0&&(ue=138,Se=3),C[2*(W+1)+1]=65535,K=0;K<=W;K++)V=oe,oe=C[2*(K+1)+1],++ne<ue&&V===oe||(ne<Se?I.bl_tree[2*V]+=ne:V!==0?(V!==Q&&I.bl_tree[2*V]++,I.bl_tree[2*A]++):ne<=10?I.bl_tree[2*M]++:I.bl_tree[2*E]++,Q=V,Se=(ne=0)===oe?(ue=138,3):V===oe?(ue=6,3):(ue=7,4))}function q(I,C,W){var K,V,Q=-1,oe=C[1],ne=0,ue=7,Se=4;for(oe===0&&(ue=138,Se=3),K=0;K<=W;K++)if(V=oe,oe=C[2*(K+1)+1],!(++ne<ue&&V===oe)){if(ne<Se)for(;le(I,V,I.bl_tree),--ne!=0;);else V!==0?(V!==Q&&(le(I,V,I.bl_tree),ne--),le(I,A,I.bl_tree),se(I,ne-3,2)):ne<=10?(le(I,M,I.bl_tree),se(I,ne-3,3)):(le(I,E,I.bl_tree),se(I,ne-11,7));Q=V,Se=(ne=0)===oe?(ue=138,3):V===oe?(ue=6,3):(ue=7,4)}}a(N);var H=!1;function $(I,C,W,K){se(I,(c<<1)+(K?1:0),3),(function(V,Q,oe,ne){ae(V),ie(V,oe),ie(V,~oe),s.arraySet(V.pending_buf,V.window,Q,oe,V.pending),V.pending+=oe})(I,C,W)}o._tr_init=function(I){H||((function(){var C,W,K,V,Q,oe=new Array(b+1);for(V=K=0;V<d-1;V++)for(B[V]=K,C=0;C<1<<w[V];C++)y[K++]=V;for(y[K-1]=V,V=Q=0;V<16;V++)for(N[V]=Q,C=0;C<1<<P[V];C++)L[Q++]=V;for(Q>>=7;V<u;V++)for(N[V]=Q<<7,C=0;C<1<<P[V]-7;C++)L[256+Q++]=V;for(W=0;W<=b;W++)oe[W]=0;for(C=0;C<=143;)G[2*C+1]=8,C++,oe[8]++;for(;C<=255;)G[2*C+1]=9,C++,oe[9]++;for(;C<=279;)G[2*C+1]=7,C++,oe[7]++;for(;C<=287;)G[2*C+1]=8,C++,oe[8]++;for(Te(G,v+1,oe),C=0;C<u;C++)S[2*C+1]=5,S[2*C]=ve(C,5);F=new X(G,w,p+1,v,b),T=new X(S,P,0,u,b),D=new X(new Array(0),R,0,h,x)})(),H=!0),I.l_desc=new Z(I.dyn_ltree,F),I.d_desc=new Z(I.dyn_dtree,T),I.bl_desc=new Z(I.bl_tree,D),I.bi_buf=0,I.bi_valid=0,ye(I)},o._tr_stored_block=$,o._tr_flush_block=function(I,C,W,K){var V,Q,oe=0;0<I.level?(I.strm.data_type===2&&(I.strm.data_type=(function(ne){var ue,Se=4093624447;for(ue=0;ue<=31;ue++,Se>>>=1)if(1&Se&&ne.dyn_ltree[2*ue]!==0)return l;if(ne.dyn_ltree[18]!==0||ne.dyn_ltree[20]!==0||ne.dyn_ltree[26]!==0)return r;for(ue=32;ue<p;ue++)if(ne.dyn_ltree[2*ue]!==0)return r;return l})(I)),j(I,I.l_desc),j(I,I.d_desc),oe=(function(ne){var ue;for(g(ne,ne.dyn_ltree,ne.l_desc.max_code),g(ne,ne.dyn_dtree,ne.d_desc.max_code),j(ne,ne.bl_desc),ue=h-1;3<=ue&&ne.bl_tree[2*z[ue]+1]===0;ue--);return ne.opt_len+=3*(ue+1)+5+5+4,ue})(I),V=I.opt_len+3+7>>>3,(Q=I.static_len+3+7>>>3)<=V&&(V=Q)):V=Q=W+5,W+4<=V&&C!==-1?$(I,C,W,K):I.strategy===4||Q===V?(se(I,2+(K?1:0),3),O(I,G,S)):(se(I,4+(K?1:0),3),(function(ne,ue,Se,ke){var Me;for(se(ne,ue-257,5),se(ne,Se-1,5),se(ne,ke-4,4),Me=0;Me<ke;Me++)se(ne,ne.bl_tree[2*z[Me]+1],3);q(ne,ne.dyn_ltree,ue-1),q(ne,ne.dyn_dtree,Se-1)})(I,I.l_desc.max_code+1,I.d_desc.max_code+1,oe+1),O(I,I.dyn_ltree,I.dyn_dtree)),ye(I),K&&ae(I)},o._tr_tally=function(I,C,W){return I.pending_buf[I.d_buf+2*I.last_lit]=C>>>8&255,I.pending_buf[I.d_buf+2*I.last_lit+1]=255&C,I.pending_buf[I.l_buf+I.last_lit]=255&W,I.last_lit++,C===0?I.dyn_ltree[2*W]++:(I.matches++,C--,I.dyn_ltree[2*(y[W]+p+1)]++,I.dyn_dtree[2*U(C)]++),I.last_lit===I.lit_bufsize-1},o._tr_align=function(I){se(I,2,3),le(I,_,G),(function(C){C.bi_valid===16?(ie(C,C.bi_buf),C.bi_buf=0,C.bi_valid=0):8<=C.bi_valid&&(C.pending_buf[C.pending++]=255&C.bi_buf,C.bi_buf>>=8,C.bi_valid-=8)})(I)}},{"../utils/common":41}],53:[function(i,n,o){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,n,o){(function(s){(function(l,r){if(!l.setImmediate){var a,c,d,p,v=1,u={},h=!1,f=l.document,b=Object.getPrototypeOf&&Object.getPrototypeOf(l);b=b&&b.setTimeout?b:l,a={}.toString.call(l.process)==="[object process]"?function(A){process.nextTick(function(){x(A)})}:(function(){if(l.postMessage&&!l.importScripts){var A=!0,M=l.onmessage;return l.onmessage=function(){A=!1},l.postMessage("","*"),l.onmessage=M,A}})()?(p="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",_,!1):l.attachEvent("onmessage",_),function(A){l.postMessage(p+A,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(A){x(A.data)},function(A){d.port2.postMessage(A)}):f&&"onreadystatechange"in f.createElement("script")?(c=f.documentElement,function(A){var M=f.createElement("script");M.onreadystatechange=function(){x(A),M.onreadystatechange=null,c.removeChild(M),M=null},c.appendChild(M)}):function(A){setTimeout(x,0,A)},b.setImmediate=function(A){typeof A!="function"&&(A=new Function(""+A));for(var M=new Array(arguments.length-1),E=0;E<M.length;E++)M[E]=arguments[E+1];var w={callback:A,args:M};return u[v]=w,a(v),v++},b.clearImmediate=k}function k(A){delete u[A]}function x(A){if(h)setTimeout(x,0,A);else{var M=u[A];if(M){h=!0;try{(function(E){var w=E.callback,P=E.args;switch(P.length){case 0:w();break;case 1:w(P[0]);break;case 2:w(P[0],P[1]);break;case 3:w(P[0],P[1],P[2]);break;default:w.apply(r,P)}})(M)}finally{k(A),h=!1}}}}function _(A){A.source===l&&typeof A.data=="string"&&A.data.indexOf(p)===0&&x(+A.data.slice(p.length))}})(typeof self>"u"?s===void 0?this:s:self)}).call(this,typeof Qn<"u"?Qn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(ns)),ns.exports}var by=vy();const yy=gy(by),ky=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,wy=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function xy(e){const t=await yy.loadAsync(e),i={},n=[];let o="",s="";const l=[];t.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(o=await r.file.async("string"),s=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||wy.test(c)||c.includes("snippets/")){const d=await a.file.async("string");i[c]=d;const p=c.split("/");p.length>1&&(i[p.slice(1).join("/")]=d)}else if(ky.test(c)){const d=await a.file.async("uint8array"),p=c.split("/").pop()||c,v=typeof Blob<"u"?new Blob([d]):void 0;n.push({zipPath:c,fileName:p,data:d,blob:v})}}return{entryMarkdown:o,entryMarkdownPath:s,virtualFiles:i,assets:n}}function Sy(e,t){if(Object.keys(t).length===0)return e;function i(o){const s=o.trim().replace(/^['"]|['"]$/g,""),l=s.split("/").pop()||s;if(t[s])return t[s];const r=s.replace(/^\.?\//,"");return t[r]?t[r]:t[l]?t[l]:null}function n(o){let s=o;return s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=i(a);return c?`![${r}](${c})`:l}),s=s.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=i(r);return a?`src="${a}"`:l}),s}for(const o of e.slides)if(o.rawMarkdown=n(o.rawMarkdown),o.pageAttrs["custom-slidev-background"]){const s=o.pageAttrs["custom-slidev-background"],l=i(s);l&&(o.pageAttrs["custom-slidev-background"]=l)}if(e.flattenedMarkdown=n(e.flattenedMarkdown),e.docRootAttrs["custom-slidev-background"]){const o=e.docRootAttrs["custom-slidev-background"],s=i(o);s&&(e.docRootAttrs["custom-slidev-background"]=s)}return e}function Da(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function _y(e,t){const i=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const n=i[1].trim(),o=n.indexOf("#"),s=o!==-1?n.slice(0,o):n,l=o!==-1?n.slice(o+1):"",r=s.replace(/^@\//,"").replace(/^\.\//,""),a=(t==null?void 0:t.virtualFiles)||{};let c=a[s]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const u=r.split("/").pop();for(const[h,f]of Object.entries(a))if(h.endsWith(`/${r}`)||u&&h.endsWith(`/${u}`)){c=f;break}}if(!c){const u=[];if(t!=null&&t.baseDir)try{const h=require("path");u.push(h.resolve(t.baseDir,r)),u.push(h.resolve(t.baseDir,s))}catch{}try{const h=require("path");u.push(h.resolve(process.cwd(),r))}catch{}for(const h of u){const f=Da(h);if(f!==null){c=f;break}}}if(!c){const u=xa||{};if(c=u[s]||u[r]||u[`snippets/${r}`],!c){const h=r.split("/").pop();for(const[f,b]of Object.entries(u))if(f.endsWith(`/${r}`)||h&&f.endsWith(`/${h}`)){c=b;break}}}if(!c)return null;let d=c;if(l){const u=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),h=c.match(u);if(h){const f=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(f?f[1]:"")+h[1].trimEnd()}}const p=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${p?p[1]:""}
${d}
\`\`\``}function Cy(e){let t=!1,i=!1;for(let n=0;n<e.length;n++){const o=e[n];if(o==="'"&&!i)t=!t;else if(o==='"'&&!t)i=!i;else if(o==="#"&&!t&&!i)return e.slice(0,n).trim()}return e.trim()}function oo(e){const t={},i=e.split(/\r?\n/);let n=0;for(;n<i.length;){const o=i[n],s=o.trim();if(!s||s.startsWith("#")){n++;continue}const l=o.indexOf(":");if(l>0){const r=o.slice(0,l).trim();let a=o.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let d=-1;for(;n<i.length;){const p=i[n];if(!p.trim()){c.push(""),n++;continue}const u=p.match(/^(\s+)/),h=u?u[1].length:0;if(d===-1&&(d=h),h<d)break;c.push(p.slice(d)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=Cy(a),!a){let c=n+1;const d=[];let p=-1;for(;c<i.length;){const v=i[c],u=v.trim();if(!u||u.startsWith("#")){p!==-1&&d.push(""),c++;continue}const h=v.match(/^(\s+)/),f=h?h[1].length:0;if(p===-1)if(f>0)p=f;else break;if(f<p)break;d.push(v.slice(p)),c++}if(d.length>0){t[r]=oo(d.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),t[r]=a}n++}return t}const $y=/^\s*```ya?ml([\s\S]*?)```/;function Kr(e){let t={},i=e.trim();const n=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const s=oo(n[1]);if(Object.keys(s).length>0||!n[1].trim())return t=s,i=i.slice(n[0].length).trim(),{frontmatter:t,content:i}}if(i.startsWith("---")){const s=i.match(/^---[^\n\r]*(?:\r?\n|$)/);s&&(i=i.slice(s[0].length).trim())}const o=i.match($y);if(o)t=oo(o[1]),i=i.slice(o[0].length).trim();else{const s=i.split(/\r?\n/),l=[];let r=0;for(let a=0;a<s.length;a++){const c=s[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(t=oo(l.join(`
`)),i=s.slice(r).join(`
`).trim())}return{frontmatter:t,content:i}}function Iy(e){const t=e.split(/\r?\n/),i=[];let n=0,o=!1;function s(l){if(n>=l)return;const r=t.slice(n,l).join(`
`).trim();r&&i.push(r),n=l+1}for(let l=0;l<t.length;l++){const a=t[l].trimEnd();if(o){a.includes("-->")&&(o=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(o=!0);continue}if(a.startsWith("---")){s(l);const c=t[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<t.length&&t[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let p=l+1;for(;p<t.length&&!t[p].trimStart().startsWith(d);p++);p<t.length&&(l=p)}}return n<t.length&&s(t.length),i}function so(e,t={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:n=!0,cleanShikiLines:o=!0,cleanSlots:s=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=t;let d=e;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const p=Iy(d),v={};let u="",h="",f=0;if(p.length>0){const z=p[0],G=Kr(z),S=Object.keys(G.frontmatter).length>0,L=G.content.length>0;S&&!L&&p.length>1?(f=1,b(G.frontmatter)):S&&b(G.frontmatter)}function b(z){u=z.title||"",z.theme&&(v[$n]=String(z.theme)),z.aspectRatio&&(v[In]=String(z.aspectRatio)),z.highlighter&&(v[il]=String(z.highlighter)),z.transition&&(v[En]=String(z.transition)),z.colorSchema&&(v[nl]=String(z.colorSchema)),z.layout&&(v[fe]=String(z.layout)),z.background&&(v[je]=String(z.background)),z.image&&(v[Dt]=String(z.image)),z.class&&(v[Vi]=String(z.class));for(const[G,S]of Object.entries(z))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(G)||(v[`custom-slidev-${G}`]=typeof S=="object"?JSON.stringify(S):String(S))}const k=[];let x=0,_=0,A=0,M=0;const E=new Set,w={};let P=1;for(let z=f;z<p.length;z++){const G=p[z],{frontmatter:S,content:L}=Kr(G),y=G.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),B=S.src||(y?y[1]:void 0);if(B){const ae=String(B).trim().replace(/^['"]|['"]$/g,"");let Y=c[ae]||c[ae.replace(/^\.\//,"")]||c[`pages/${ae.replace(/^.*pages\//,"")}`];if(!Y){const O=ae.replace(/^\.\//,""),j=[];if(t.baseDir)try{const g=require("path");j.push(g.resolve(t.baseDir,O)),j.push(g.resolve(t.baseDir,ae))}catch{}try{const g=require("path");j.push(g.resolve(process.cwd(),O)),j.push(g.resolve(process.cwd(),ae))}catch{}for(const g of j){const q=Da(g);if(q!==null){Y=q;break}}}const ce={};S.layout&&(ce[fe]=String(S.layout)),S.transition&&(ce[tt]=String(S.transition)),S.background&&(ce[je]=String(S.background)),S.image&&(ce[Dt]=String(S.image)),S.class&&(ce[Vi]=String(S.class));for(const[O,j]of Object.entries(S))["src","layout","transition","background","image","class"].includes(O)||(ce[`custom-slidev-${O}`]=typeof j=="object"?JSON.stringify(j):String(j));if(Y){const O=so(Y,{...t,virtualFiles:c});for(const j of O.slides){j.pageIndex=P++,j.pageAttrs={...ce,...j.pageAttrs},k.push(j);const g=j.pageAttrs[fe]||"default";w[g]=(w[g]||0)+1}continue}else{k.push({pageIndex:P++,pageAttrs:{...ce,"custom-slidev-src":ae},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${ae}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const O=ce[fe]||"default";w[O]=(w[O]||0)+1;continue}}const F={};S.layout&&(F[fe]=String(S.layout)),S.transition&&(F[tt]=String(S.transition)),S.background&&(F[je]=String(S.background)),S.image&&(F[Dt]=String(S.image)),S.class&&(F[Vi]=String(S.class)),S.mask&&(F[Ki]=String(S.mask)),(S.maskRatio||S["mask-ratio"])&&(F[qi]=String(S.maskRatio||S["mask-ratio"])),(S.maskStyle||S["mask-style"])&&(F[Gi]=String(S.maskStyle||S["mask-style"])),(S.maskInitial||S["mask-initial"])&&(F[Zi]=String(S.maskInitial||S["mask-initial"]));for(const[ae,Y]of Object.entries(S))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(ae)||(F[`custom-slidev-${ae}`]=typeof Y=="object"?JSON.stringify(Y):String(Y));let T=L;const D=[];let N=T.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,ae=>{const Y=`__CODE_TOKEN_NOTE_${D.length}__`;return D.push(ae),Y});N=N.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,ae=>{const Y=`__CODE_TOKEN_NOTE_${D.length}__`;return D.push(ae),Y});let X="";const Z=Array.from(N.matchAll(/<!--([\s\S]*?)-->/g));if(Z.length>0){const ae=Z[Z.length-1],Y=N.slice(ae.index+ae[0].length).trim();if(!Y||!Y.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const O=ae[1].trim();O.startsWith("TODO:")||(X=O,x++),i&&(N=N.slice(0,ae.index).trimEnd()+N.slice(ae.index+ae[0].length))}}i&&(N=N.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let ae=0;ae<D.length;ae++)N=N.replace(`__CODE_TOKEN_NOTE_${ae}__`,D[ae]);if(T=N,X){for(let ce=0;ce<D.length;ce++)X=X.replace(`__CODE_TOKEN_NOTE_${ce}__`,D[ce]);const Y=`> [!NOTE] 💡 演讲备注
${X.split(/\r?\n/).map(ce=>`> ${ce}`).join(`
`)}
{: custom-slidev-note="true"}`;T=T?`${T}

${Y}`:Y}let U=!1;if(/<style\b/i.test(T)){U=!0;const ae=T.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(ae){for(const Y of ae){const ce=Y.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();h=h?`${h}

${ce}`:ce}l&&(T=T.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const ie=T.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);ie&&(_+=ie.length);const se=T.match(/```\w+\s+\{[^}]+\}/g);se&&(A+=se.length);const le=T.match(/::\w+::|<template\s+#[^>]+>/g);if(le&&(M+=le.length),T=T.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,ae=>_y(ae,{...t,virtualFiles:c})||ae),n&&(T=T.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),o&&(T=T.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),T=T.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),s&&(T=T.replace(/^::\w+::\s*$/gm,"")),r&&(T=Cf(T)),a){let ae=T.trim(),Y="";const ce=ae.lastIndexOf("> [!NOTE] 💡 演讲备注");if(ce!==-1&&(Y=ae.slice(ce),ae=ae.slice(0,ce).trim()),(S.layout==="image-left"||S.layout==="image-right")&&S.image){const O=String(S.image).trim(),j=S.layout==="image-left"?"image-left":"image-right",g=`![配图](${O})
{: custom-slidev-layout="${j}" }`;S.layout==="image-left"?ae=`{{{col

${g}

${ae}

}}}`:ae=`{{{col

${ae}

${g}

}}}`}if(S.background){const j=`![背景图](${String(S.background).trim()})
{: custom-slidev-role="background" }`;ae=ae?`${j}

${ae}`:j}T=Y?`${ae}

${Y}`:ae}const ve=Ey(T);F[je]&&ve.push(F[je]),F[Dt]&&ve.push(F[Dt]);for(const ae of ve)E.add(ae);const Te=/<[A-Z][a-zA-Z0-9]+/.test(T),ye=F[fe]||(P===1?v[fe]||"cover":"default");w[ye]=(w[ye]||0)+1,k.push({pageIndex:P++,pageAttrs:F,notes:X,rawMarkdown:T,hasVueComponent:Te,hasStyleTag:U,assetReferences:ve})}if(!u&&k.length>0){const z=k[0].rawMarkdown.match(/^#\s+(.+)$/m);z&&(u=z[1].trim())}h&&(v["custom-slidev-custom-css"]=h);let R=k.map(z=>`---

${z.rawMarkdown}`).join(`

`);return R.trimStart().startsWith("---")||(R=`---

${R.trimStart()}`),{docTitle:u||"Slidev 演示文稿",docRootAttrs:v,slides:k,totalSlides:k.length,stats:{totalNotes:x,totalVClicks:_,totalShikiHighlights:A,totalSlots:M,discoveredAssets:Array.from(E),layoutDistribution:w},flattenedMarkdown:R,customCss:h}}function Ey(e){const t=[],i=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=i.exec(e))!==null;){const s=n[1].split(/\s+/)[0].trim();s&&t.push(s)}const o=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=o.exec(e))!==null;){const s=n[1].trim();s&&t.push(s)}return t}function La(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),i=String(e.markdown||"").trim(),n=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||i==="---"||i==="***"||n==="---"||n==="***"}function Ty(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function Ay(e,t,i=Ne){const n=e.filter(La);let o=0;if(n.length>=t.length)for(let s=0;s<t.length;s++){const l=t[s],r=n[s];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),o++)}else for(let s=1;s<t.length;s++){const l=t[s],r=n[s-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),o++)}return o}async function By(e,t=Ne){let i=!1,n=0;for(const o of e){if(La(o)){i=!1;continue}const s=(o.markdown||o.content||"").trim();if(s==="::right::"||s.startsWith("::right::")){i=!0;continue}i&&o.id&&(await t(o.id,{[Ce]:"right"}).catch(()=>{}),n++)}return n}async function My(e,t,i=Xr){const n={};if(!t||t.length===0)return n;const o=[];for(const s of t){const l=new File([s.data],s.fileName,{type:"application/octet-stream"});o.push(l)}try{const s=await i("/data/assets",o);if(s!=null&&s.succMap)for(const[l,r]of Object.entries(s.succMap))n[l]=String(r)}catch(s){console.warn("上传本地静态资产失败，保留原路径:",s)}return Object.keys(n).length>0&&Sy(e,n),n}async function Dy(e){var A;const{presentation:t,notebookId:i,docTitle:n,extractedAssets:o=[],uploadAssets:s=!0,autoPreview:l=!0,plugin:r,api:a={}}=e,c=a.uploadFn||Xr,d=a.createDocFn||Dc,p=a.setAttrsFn||Ne,v=a.getChildBlocksFn||uo,u=a.openTabFn||pe.openTab,h=a.showMessageFn||pe.showMessage;s&&o.length>0&&await My(t,o,c);const f=Ty(n),b=`/${f}`,k=await d(i,b,t.flattenedMarkdown);if(!k)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const x=((A=t.slides[0])==null?void 0:A.pageAttrs)||{};await p(k,{...x,...t.docRootAttrs});const _=await v(k).catch(()=>[]);return Array.isArray(_)&&_.length>0&&(await Ay(_,t.slides,p),await By(_,p)),h(`🎉 成功导入 Slidev 演示文档《${f}》！`),l&&r&&(r.currentDocId=k,await u({app:r.app,doc:{id:k}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),k}function Ly(e){const t=he("file"),i=he(!1),n=he(!1),o=he(""),s=he(null),l=he(null),r=he(""),a=he(0),c=he(""),d=he([]),p=he(null),v=he(""),u=he([]),h=he(""),f=he(!0),b=he(!0),k=he(!0),x=he(!0),_=xe(()=>{const F=a.value;if(F===0)return"0 B";const T=1024,D=["B","KB","MB","GB"],N=Math.floor(Math.log(F)/Math.log(T));return`${(F/T**N).toFixed(1)} ${D[N]}`}),A=xe(()=>{var F;return((F=p.value)==null?void 0:F.docRootAttrs["custom-slidev-theme"])||"default"}),M=xe(()=>{var F;return d.value.length>0?d.value.length:((F=p.value)==null?void 0:F.stats.discoveredAssets.length)||0}),E=xe(()=>{var T;const F=((T=p.value)==null?void 0:T.stats.layoutDistribution)||{};return Object.entries(F).map(([D,N])=>({name:D,count:N}))});async function w(F=Mc){try{const T=await F();T!=null&&T.notebooks&&Array.isArray(T.notebooks)&&(u.value=T.notebooks.filter(D=>!D.closed),u.value.length>0&&!h.value&&(h.value=u.value[0].id))}catch(T){console.warn("获取笔记本列表失败:",T)}}function P(){var F;(F=s.value)==null||F.click()}function R(){l.value=null,r.value="",a.value=0,p.value=null,d.value=[],o.value=""}async function z(F){o.value="",l.value=F,r.value=F.name,a.value=F.size;try{if(F.name.toLowerCase().endsWith(".zip")){const D=await F.arrayBuffer(),N=await xy(D);if(!N.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}d.value=N.assets;const X=so(N.entryMarkdown,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1,virtualFiles:N.virtualFiles});p.value=X,v.value=X.docTitle||F.name.replace(/\.zip$/i,"")}else{const D=await F.text();d.value=[];const N=F.path||"",X=N?N.replace(/[\\/][^\\/]+$/,""):"",Z=so(D,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1,baseDir:X||void 0});p.value=Z,v.value=Z.docTitle||F.name.replace(/\.md$/i,"")}}catch(T){console.error("解析文件失败:",T),o.value=`解析文件失败: ${T.message||String(T)}`}}function G(){if(o.value="",!c.value.trim()){p.value=null;return}try{const F=so(c.value,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1});p.value=F,v.value=F.docTitle||"Slidev 演示文稿"}catch(F){o.value=`解析 Markdown 源码失败: ${F.message||String(F)}`}}async function S(){l.value?await z(l.value):c.value&&G()}async function L(F){const T=F.target;T.files&&T.files[0]&&await z(T.files[0])}async function y(F){var T;i.value=!1,(T=F.dataTransfer)!=null&&T.files&&F.dataTransfer.files[0]&&await z(F.dataTransfer.files[0])}async function B(F=e){if(p.value){if(!h.value&&u.value.length>0&&(h.value=u.value[0].id),!h.value){o.value="请先选择目标笔记本";return}n.value=!0,o.value="";try{return await Dy({presentation:p.value,notebookId:h.value,docTitle:v.value,extractedAssets:d.value,uploadAssets:k.value,autoPreview:x.value,plugin:F})}catch(T){console.error("导入 Slidev 演示失败:",T),o.value=`导入执行失败: ${T.message||String(T)}`}finally{n.value=!1}}}return{inputMode:t,isDragging:i,isImporting:n,errorMessage:o,fileInputRef:s,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:d,parsedPresentation:p,customDocTitle:v,notebooks:u,selectedNotebookId:h,optCleanHtml:f,optStripNotes:b,optUploadAssets:k,optAutoPreview:x,formattedFileSize:_,currentTheme:A,extractedAssetsCount:M,layoutChips:E,fetchNotebooks:w,triggerFileInput:P,clearFile:R,processFile:z,onFileSelected:L,onFileDrop:y,onTextChange:G,reprocessCurrentInput:S,handleConfirmImport:B}}const Oy={class:"spm-import-dialog"},Py={class:"spm-tabs-header"},Ry={class:"spm-dialog-body"},Ny={key:0,class:"spm-file-section"},zy={key:0,class:"spm-dropzone-prompt"},Fy={class:"spm-dropzone-icon"},Hy={key:1,class:"spm-dropzone-active"},jy={class:"spm-file-badge"},Wy={class:"spm-file-size"},Uy={key:1,class:"spm-text-section"},Vy={key:2,class:"spm-error-banner"},Ky={key:3,class:"spm-preview-card"},qy={class:"spm-preview-card__header"},Gy={style:{display:"inline-flex","align-items":"center",gap:"4px"}},Zy={class:"spm-config-grid"},Yy={class:"spm-form-item"},Jy={class:"spm-form-item"},Xy=["value"],Qy={class:"spm-stats-grid"},e0={class:"spm-stat-box"},t0={class:"spm-stat-value"},i0={class:"spm-stat-box"},n0={class:"spm-stat-value"},o0={class:"spm-stat-box"},s0={class:"spm-stat-value"},r0={class:"spm-stat-box"},l0={class:"spm-stat-value"},a0={key:0,class:"spm-chips-row"},c0={class:"spm-options-group"},d0={class:"spm-checkbox-label"},u0={class:"spm-checkbox-label"},f0={class:"spm-checkbox-label"},p0={class:"spm-checkbox-label"},h0={class:"spm-dialog-footer"},m0=["disabled"],g0=["disabled"],v0={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},b0={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},y0=xt({__name:"SlidevImportDialog",emits:["close","success"],setup(e,{emit:t}){const i=t,n=ti("plugin"),{inputMode:o,isDragging:s,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:d,extractedAssetsCount:p,parsedPresentation:v,customDocTitle:u,notebooks:h,selectedNotebookId:f,optCleanHtml:b,optStripNotes:k,optUploadAssets:x,optAutoPreview:_,formattedFileSize:A,currentTheme:M,layoutChips:E,fetchNotebooks:w,triggerFileInput:P,clearFile:R,onFileSelected:z,onFileDrop:G,onTextChange:S,reprocessCurrentInput:L,handleConfirmImport:y}=Ly(n);Hn(async()=>{await w()});async function B(){const T=await y();T&&(i("success",{docId:T}),i("close"))}function F(){i("close")}return(T,D)=>(ee(),te("div",{class:"spm-modal-overlay",onClick:Lt(F,["self"])},[m("div",Oy,[m("div",{class:"spm-dialog-header"},[D[18]||(D[18]=m("div",{class:"spm-dialog-title"},[m("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[m("use",{"xlink:href":"#iconSlidev"})]),m("span",null,"导入 Slidev 演示文档")],-1)),m("button",{class:"spm-close-btn",title:"关闭",onClick:F},"✕")]),m("div",Py,[m("button",{class:_e(["spm-tab-btn",{active:ge(o)==="file"}]),onClick:D[0]||(D[0]=N=>o.value="file")},[re(de,{name:"package"}),D[19]||(D[19]=m("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),m("button",{class:_e(["spm-tab-btn",{active:ge(o)==="text"}]),onClick:D[1]||(D[1]=N=>o.value="text")},[re(de,{name:"notes"}),D[20]||(D[20]=m("span",null,"粘贴 Markdown 源码",-1))],2)]),m("div",Ry,[ge(o)==="file"?(ee(),te("div",Ny,[m("div",{class:_e(["spm-dropzone",{dragover:ge(s),"has-file":!!ge(c)}]),onDragover:D[4]||(D[4]=Lt(N=>s.value=!0,["prevent"])),onDragleave:D[5]||(D[5]=Lt(N=>s.value=!1,["prevent"])),onDrop:D[6]||(D[6]=Lt((...N)=>ge(G)&&ge(G)(...N),["prevent"])),onClick:D[7]||(D[7]=(...N)=>ge(P)&&ge(P)(...N))},[m("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:D[2]||(D[2]=(...N)=>ge(z)&&ge(z)(...N))},null,544),ge(c)?(ee(),te("div",Hy,[m("span",jy,[re(de,{name:"notes"}),$t(" "+we(ge(c)),1)]),m("span",Wy,"("+we(ge(A))+")",1),m("button",{class:"spm-btn-text",onClick:D[3]||(D[3]=Lt((...N)=>ge(R)&&ge(R)(...N),["stop"]))},"更换文件")])):(ee(),te("div",zy,[m("span",Fy,[re(de,{name:"folder",style:{"font-size":"32px"}})]),D[21]||(D[21]=m("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),D[22]||(D[22]=m("p",{class:"spm-dropzone-hint"},[$t(" 支持 Slidev 完整工程 "),m("strong",null,".zip"),$t("（自动解包 public/ 静态素材）或单文件 "),m("strong",null,".md")],-1))]))],34)])):(ee(),te("div",Uy,[Tt(m("textarea",{"onUpdate:modelValue":D[8]||(D[8]=N=>Ye(d)?d.value=N:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:D[9]||(D[9]=(...N)=>ge(S)&&ge(S)(...N))},null,544),[[_o,ge(d)]])])),ge(r)?(ee(),te("div",Vy," ⚠️ "+we(ge(r)),1)):Oe("",!0),ge(v)?(ee(),te("div",Ky,[m("div",qy,[m("span",Gy,[re(de,{name:"sparkles"}),D[23]||(D[23]=$t(" 演示解析摘要",-1))]),D[24]||(D[24]=m("span",{class:"spm-badge-success"},"预检就绪",-1))]),m("div",Zy,[m("div",Yy,[D[25]||(D[25]=m("label",{class:"spm-form-label"},"笔记文档标题",-1)),Tt(m("input",{"onUpdate:modelValue":D[10]||(D[10]=N=>Ye(u)?u.value=N:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[_o,ge(u)]])]),m("div",Jy,[D[26]||(D[26]=m("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Tt(m("select",{"onUpdate:modelValue":D[11]||(D[11]=N=>Ye(f)?f.value=N:null),class:"spm-select"},[(ee(!0),te(Ue,null,kt(ge(h),N=>(ee(),te("option",{key:N.id,value:N.id},we(N.name),9,Xy))),128))],512),[[sf,ge(f)]])])]),m("div",Qy,[m("div",e0,[m("span",t0,we(ge(v).totalSlides),1),D[27]||(D[27]=m("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),m("div",i0,[m("span",n0,we(ge(M)),1),D[28]||(D[28]=m("span",{class:"spm-stat-label"},"演示主题",-1))]),m("div",o0,[m("span",s0,we(ge(v).stats.totalNotes),1),D[29]||(D[29]=m("span",{class:"spm-stat-label"},"演讲者提词",-1))]),m("div",r0,[m("span",l0,we(ge(p)),1),D[30]||(D[30]=m("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),ge(E).length>0?(ee(),te("div",a0,[D[31]||(D[31]=m("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(ee(!0),te(Ue,null,kt(ge(E),N=>(ee(),te("span",{key:N.name,class:"spm-chip-badge"},we(N.name)+": "+we(N.count),1))),128))])):Oe("",!0),m("div",c0,[m("label",d0,[Tt(m("input",{"onUpdate:modelValue":D[12]||(D[12]=N=>Ye(b)?b.value=N:null),type:"checkbox",onChange:D[13]||(D[13]=(...N)=>ge(L)&&ge(L)(...N))},null,544),[[Jn,ge(b)]]),D[32]||(D[32]=m("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),m("label",u0,[Tt(m("input",{"onUpdate:modelValue":D[14]||(D[14]=N=>Ye(k)?k.value=N:null),type:"checkbox",onChange:D[15]||(D[15]=(...N)=>ge(L)&&ge(L)(...N))},null,544),[[Jn,ge(k)]]),D[33]||(D[33]=m("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),m("label",f0,[Tt(m("input",{"onUpdate:modelValue":D[16]||(D[16]=N=>Ye(x)?x.value=N:null),type:"checkbox"},null,512),[[Jn,ge(x)]]),D[34]||(D[34]=m("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),m("label",p0,[Tt(m("input",{"onUpdate:modelValue":D[17]||(D[17]=N=>Ye(_)?_.value=N:null),type:"checkbox"},null,512),[[Jn,ge(_)]]),D[35]||(D[35]=m("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Oe("",!0)]),m("div",h0,[m("button",{class:"spm-btn-secondary",disabled:ge(l),onClick:F}," 取消 ",8,m0),m("button",{class:"spm-btn-primary",disabled:!ge(v)||ge(l),onClick:B},[ge(l)?(ee(),te("span",v0,[re(de,{name:"refresh"}),D[36]||(D[36]=$t(" 正在导入生成中...",-1))])):(ee(),te("span",b0,[re(de,{name:"rocket"}),D[37]||(D[37]=$t(" 确认导入思源笔记",-1))]))],8,g0)])])]))}}),k0=Mt(y0,[["__scopeId","data-v-2eff6f1e"]]);function er(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function w0(e,t){var r;if(!e||e.length===0)return null;const i=t.activeBlockId||"",n=t.currentTopBlockId||i,o=t.currentPageDividerId||"",s=t.activeBlockType||"";if(er(s)&&i){let a=e.find(c=>c.startBlockId===i);if(a||(a=e.find(c=>{var d,p;return((p=(d=c.blocks)==null?void 0:d[0])==null?void 0:p.id)===i}),a)||(a=e.find(c=>{var d;return(d=c.allBlockIds)==null?void 0:d.includes(i)}),a))return a}if(o){let a=e.find(c=>c.startBlockId===o);if(a||(a=e.find(c=>{var d,p;return((p=(d=c.blocks)==null?void 0:d[0])==null?void 0:p.id)===o}),a))return a}if(i){let a=e.find(d=>d.startBlockId===i);if(a||(a=e.find(d=>{var p,v;return((p=d.blocks)==null?void 0:p.some(u=>u.id===i))||((v=d.allBlockIds)==null?void 0:v.includes(i))}),a)||n&&n!==i&&(a=e.find(d=>{var p,v;return((p=d.blocks)==null?void 0:p.some(u=>u.id===n))||((v=d.allBlockIds)==null?void 0:v.includes(n))}),a)||(a=e.find(d=>{var p;return(p=d.noteBlocks)==null?void 0:p.some(v=>v.id===i||v.id===n)}),a))return a;const c=(r=t.activeBlockAttrs)==null?void 0:r[Ce];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=e.find(d=>{var p,v;return((p=d.frontmatter)==null?void 0:p.layout)==="three-cols-header"||((v=d.blocks)==null?void 0:v.some(u=>u.slot==="col-1"||u.slot==="col-2"||u.slot==="col-3"))}),a))return a}return e[0]||null}function x0(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!i)return!1;const n=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===e}function S0(e){let t=null;function i(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const d=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(d,1200):t=setTimeout(d,1200)}async function n(c){var u;const d=e.activeBlockId.value||e.currentDocId.value;if(!d)return;for(const[h,f]of Object.entries(c))e.activeBlockAttrs.value[h]=f;Be.setBlockAttrOverride(d,c),et(d,c);const p=(u=e.parentContainerId)==null?void 0:u.value,v=!!(p&&x0(d,p));if(Ze in c&&v&&p){const h=c[Ze];e.parentContainerClicks&&(e.parentContainerClicks.value=h),Be.setBlockAttrOverride(p,{[Ze]:h}),et(p,{[Ze]:h}),Ne(p,{[Ze]:h}).catch(()=>{})}if(fe in c){const h=c[fe];e.currentPageDividerLayout.value=h,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=h)}if(yt in c){const h=c[yt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=h)}i("保存中...");try{await Ne(d,c),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}async function o(c,d){await n({[c]:d})}function s(){const c=e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak";return e.currentPageDividerId.value||(c?e.activeBlockId.value:"")||e.currentDocId.value}async function l(c,d){const p=s();if(p){p===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=d),Be.setBlockAttrOverride(p,{[c]:d}),et(p,{[c]:d}),c===fe&&(e.currentPageDividerLayout.value=d,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=d)),c===yt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=d),i("保存中...");try{await Ne(p,{[c]:d}),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}}async function r(c,d){const p=s();if(!p)return;const v={[fe]:c,[yt]:d};p===e.activeBlockId.value&&(e.activeBlockAttrs.value[fe]=c,e.activeBlockAttrs.value[yt]=d),e.currentPageDividerLayout.value=c,Be.setBlockAttrOverride(p,v),et(p,v),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=d),i("应用排版中...");try{await Ne(p,v),i("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("应用失败")}}async function a(c,d){var v;const p=e.currentDocId.value||e.activeBlockId.value;if(p){e.activeBlockAttrs.value[c]=d,Be.setBlockAttrOverride(p,{[c]:d}),et(p,{[c]:d}),(v=e.latestDoc.value)!=null&&v.config&&(c===$n&&(e.latestDoc.value.config.theme=d),c===In&&(e.latestDoc.value.config.aspectRatio=d),c===En&&(e.latestDoc.value.config.defaultTransition=d)),i("更新中...");try{await Ne(p,{[c]:d}),i("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(p)}catch{i("更新失败")}}}return{triggerSaveNotice:i,saveAttrs:n,saveAttr:o,getPageTargetBlockId:s,savePageAttr:l,applyPageLayoutAndRatio:r,saveDocAttr:a}}function qr(e,t){const i=(e.blocks||[]).filter(l=>{const r=(l.content||l.rawMarkdown||"").trim();return r&&r!=="---"});if(i.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],o=[];for(const l of i){const r=(l.content||l.rawMarkdown||"").trim();r&&(l.type==="h"||r.startsWith("#")?n.push(r.replace(/^#+\s*/,"")):o.push(r.slice(0,50)))}const s=[];return n.length>0&&s.push(`【核心重点】：${n.join("、")}`),o.length>0&&(s.push("【口播要点】："),o.slice(0,3).forEach((l,r)=>{s.push(`${r+1}. 讲解 ${l}`)})),s.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),s.join(`
`)}async function Oa(e,t){const i=e.blocks&&e.blocks.length>0?e.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(t&&i){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const o=await t(n);if(o&&o.trim())return{notes:o.trim(),isAiGenerated:!0}}catch(o){return{notes:qr(e),isAiGenerated:!1,error:(o==null?void 0:o.message)||"AI 调用异常"}}}return{notes:qr(e),isAiGenerated:!1}}async function _0(e,t){return(await Oa(e,t)).notes}function C0(e,t){const i=he(!1),{triggerSaveNotice:n}=t;async function o(p){var A,M,E,w,P,R,z,G;const h=`> [!NOTE] 💡 演讲备注
${(p||"在此输入本页讲稿提词...").split(/\r?\n/).map(S=>`> ${S}`).join(`
`)}
{: custom-slidev-note="true"}`,f=((A=e.latestDoc.value)==null?void 0:A.slides)||[],b=e.targetSlide.value,k=b?f.findIndex(S=>S===b):-1;let x=null;if(k!==-1&&k<f.length-1){const S=f[k+1];x=await Ti("markdown",h,S.startBlockId)}else{const S=((M=b==null?void 0:b.noteBlocks)==null?void 0:M.slice(-1)[0])||((E=b==null?void 0:b.blocks)==null?void 0:E.slice(-1)[0]),L=(S==null?void 0:S.id)||(b==null?void 0:b.startBlockId);L?x=await Ti("markdown",h,void 0,L):x=await rs("markdown",h,e.currentDocId.value)}const _=((R=(P=(w=x==null?void 0:x[0])==null?void 0:w.doOperations)==null?void 0:P[0])==null?void 0:R.id)||((z=x==null?void 0:x[0])==null?void 0:z.id);return _&&(await Ne(_,{[nt]:"true"}),Be.setBlockAttrOverride(_,{[nt]:"true"}),Oi(_,(G=e.plugin)==null?void 0:G.app)),e.plugin&&await e.plugin.compileCurrentDocument(),_}async function s(){const p=e.activeBlockId.value;if(p)if(e.isNoteBlock.value){n("取消中...");try{await Ne(p,{[nt]:"","slidev-note":""}),Be.setBlockAttrOverride(p,{[nt]:"","slidev-note":""}),et(p,{[nt]:"","slidev-note":""}),delete e.activeBlockAttrs.value[nt],delete e.activeBlockAttrs.value["slidev-note"],n("已取消备注"),pe.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(v){console.error("[SiYuanSlidev] 取消讲稿备注失败:",v),n("取消失败"),pe.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let v=e.rawSnippet.value;try{const b=await Lc(p);b!=null&&b.kramdown&&(v=b.kramdown)}catch{}const f=`> [!NOTE] 💡 演讲备注
${(ba(v)||v.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(b=>`> ${b}`).join(`
`)}
{: custom-slidev-note="true"}`;await rr("markdown",f,p),await Ne(p,{[nt]:"true"}),Be.setBlockAttrOverride(p,{[nt]:"true"}),et(p,{[nt]:"true"}),e.activeBlockAttrs.value[nt]="true",e.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),pe.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(v){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",v),n("设置失败"),pe.showMessage("转为讲稿备注提示块失败")}}}async function l(){try{await o(),pe.showMessage("已在正文末尾插入讲稿备注提示块")}catch(p){pe.showMessage("插入讲稿备注块失败"),console.error(p)}}function r(){var u;const p=e.currentSlideNoteBlockId.value;if(!p){pe.showMessage("未找到本页关联的讲稿备注块");return}Oi(p,(u=e.plugin)==null?void 0:u.app)?pe.showMessage("已在编辑区定位讲稿备注块"):pe.showMessage("定位讲稿备注块失败")}async function a(){var u;if(!e.currentDocId.value)return;const p=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};pe.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const v=await Oa(p,el);if(v.notes){const h=e.currentSlideNoteBlockId.value;if(h){const f=`> [!NOTE] 💡 演讲备注
${v.notes.split(/\r?\n/).map(b=>`> ${b}`).join(`
`)}
{: custom-slidev-note="true"}`;await rr("markdown",f,h),await Ne(h,{[nt]:"true"}),Be.setBlockAttrOverride(h,{[nt]:"true"}),Oi(h,(u=e.plugin)==null?void 0:u.app)}else await o(v.notes);v.isAiGenerated?pe.showMessage("思源 AI 演讲提词卡生成成功！"):pe.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}async function c(){var h;if(i.value)return;const p=((h=e.latestDoc.value)==null?void 0:h.slides)||[];if(p.length===0){pe.showMessage("当前文档无幻灯片页面");return}const v=p.map((f,b)=>({slide:f,idx:b})).filter(({slide:f})=>{var x;const b=Array.isArray(f.noteBlocks)&&f.noteBlocks.length>0,k=!!((x=f.notes)!=null&&x.trim());return!b&&!k});if(v.length===0){pe.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const u=v.length;pe.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${u} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var b,k,x,_,A,M;if(i.value)return;i.value=!0,pe.showMessage("正在批量追加讲稿块...");let f=0;try{const P=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(R=>`> ${R}`).join(`
`)}
{: custom-slidev-note="true"}`;for(const{slide:R,idx:z}of v)try{let G=null;if(z<p.length-1){const L=p[z+1];G=await Ti("markdown",P,L.startBlockId)}else{const L=((b=R==null?void 0:R.noteBlocks)==null?void 0:b.slice(-1)[0])||((k=R==null?void 0:R.blocks)==null?void 0:k.slice(-1)[0]),y=(L==null?void 0:L.id)||(R==null?void 0:R.startBlockId);y?G=await Ti("markdown",P,void 0,y):G=await rs("markdown",P,e.currentDocId.value)}const S=((A=(_=(x=G==null?void 0:G[0])==null?void 0:x.doOperations)==null?void 0:_[0])==null?void 0:A.id)||((M=G==null?void 0:G[0])==null?void 0:M.id);S&&(await Ne(S,{[nt]:"true"}),Be.setBlockAttrOverride(S,{[nt]:"true"})),f++}catch(G){console.error(`[SiYuanSlidev] 为第 ${z+1} 页追加讲稿块失败:`,G)}e.plugin&&await e.plugin.compileCurrentDocument(),pe.showMessage(`已成功为 ${f} 页追加讲稿备注块`)}catch(E){console.error("[SiYuanSlidev] 批量追加讲稿块失败:",E),pe.showMessage("批量追加讲稿块时出现异常")}finally{i.value=!1}})}async function d(){var f;if(i.value)return;const p=((f=e.latestDoc.value)==null?void 0:f.slides)||[];if(p.length===0){pe.showMessage("当前文档无幻灯片页面");return}const v=[];for(const b of p)if(b.noteBlocks&&b.noteBlocks.length>0)for(const k of b.noteBlocks)k.id&&v.push({id:k.id,pageIndex:b.pageIndex});if(v.length===0){pe.showMessage("当前文档中没有讲稿备注块，无需删除");return}const u=new Set(v.map(b=>b.pageIndex)).size,h=v.length;pe.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${h} 个讲稿备注块（涉及 ${u} 页），删除后无法撤销。是否确认继续？`,async()=>{if(i.value)return;i.value=!0,pe.showMessage("正在批量删除讲稿块...");let b=0;try{for(const k of v)try{await Qr(k.id),Be.clearBlockAttrOverride(k.id),b++}catch(x){console.error(`[SiYuanSlidev] 删除讲稿块 ${k.id} 失败:`,x)}e.activeBlockId.value&&v.some(k=>k.id===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[nt],delete e.activeBlockAttrs.value["slidev-note"]),e.plugin&&await e.plugin.compileCurrentDocument(),pe.showMessage(`已成功删除全部 ${b} 个讲稿备注块`)}catch(k){console.error("[SiYuanSlidev] 批量删除讲稿块失败:",k),pe.showMessage("批量删除讲稿块时出现异常")}finally{i.value=!1}})}return{isBatchProcessing:i,createNoteBlockOnCurrentSlide:o,onToggleNoteBlock:s,onAddNoteBlock:l,onLocateNoteBlock:r,onGenerateNotesWithAI:a,onBatchAppendNotes:c,onBatchDeleteNotes:d}}function $0(e,t){const{saveAttr:i,saveAttrs:n,savePageAttr:o}=t;async function s(){(e.videoAutoplay.value?"false":"true")==="true"?(await n({[Ei]:"true",[Wi]:"true"}),e.activeBlockAttrs.value[Ei]="true",e.activeBlockAttrs.value[Wi]="true"):(await i(Ei,"false"),e.activeBlockAttrs.value[Ei]="false")}async function l(){const w=e.videoLoop.value?"false":"true";await i(fo,w)}async function r(){const w=e.videoMuted.value?"false":"true";await i(Wi,w)}async function a(){const w=e.videoControls.value?"false":"true";await i(po,w)}async function c(w){var S;const P=e.activeBlockId.value;if(!P)return;const R=e.rawSnippet.value||"",z=bi(R)||"",G=e.currentPageDividerId.value||e.currentDocId.value;if(w)if(w==="background"){const L={[qe]:"background",[fe]:""};G&&z&&(e.pageBackground.value=z,await Ne(G,{[je]:z}).catch(()=>{}),Be.setBlockAttrOverride(G,{[je]:z}),et(G,{[je]:z}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=z)),await n(L)}else(w===ho||w===mo)&&await n({[fe]:w,[qe]:""});else{const L={[qe]:"",[fe]:""};if(e.activeBlockAttrs.value[je]==="true"&&(L[je]=""),G&&z&&e.pageBackground.value===z&&(e.pageBackground.value="",await Ne(G,{[je]:""}).catch(()=>{}),Be.setBlockAttrOverride(G,{[je]:""}),et(G,{[je]:""}),(S=e.targetSlide.value)!=null&&S.frontmatter&&delete e.targetSlide.value.frontmatter.background),await n(L),typeof document<"u"){const y=document.querySelector(`.protyle-wysiwyg [data-node-id="${P}"]`),B=y==null?void 0:y.closest('[data-type="NodeListItem"]'),F=B==null?void 0:B.getAttribute("data-node-id");if(F&&F!==P){const T={[fe]:"",[qe]:""};et(F,T),Be.setBlockAttrOverride(F,T),await Ne(F,T).catch(()=>{})}}}}function d(){e.elemClick.value?i(Ze,""):i(Ze,"+1")}function p(w){i(Ze,w)}function v(w){i(Kt,w)}function u(w){(e.activeBlockAttrs.value[Ce]||"")===w?i(Ce,""):i(Ce,w)}function h(w){e.elemShikiLines.value=w,i(Pi,w)}function f(w){e.elemMaxHeight.value=w,i(Tn,w)}async function b(){const w=e.currentSlideLayout.value==="three-cols-header";await i(Ce,w?"col-1":"left"),pe.showMessage(w?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function k(){const w=e.activeBlockId.value;if(!w)return;const P={[Ze]:"",[Kt]:"",[Ce]:"",[Pi]:"",[Tn]:"",[nt]:"","slidev-note":"",[fe]:"",[yt]:"",[qe]:"",[tt]:"",[je]:"",[Dt]:"",[Ei]:"",[fo]:"",[Wi]:"",[po]:""};if(et(w,P),await Ne(w,P),Be.clearBlockAttrOverride(w),typeof document<"u"){const R=document.querySelector(`.protyle-wysiwyg [data-node-id="${w}"]`),z=R==null?void 0:R.closest('[data-type="NodeListItem"]'),G=z==null?void 0:z.getAttribute("data-node-id");G&&G!==w&&(et(G,P),await Ne(G,P).catch(()=>{}),Be.clearBlockAttrOverride(G))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground.value="",e.pageImage.value="",pe.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()}async function x(){if(e.activeBlockId.value)try{await Ti("markdown","---",e.activeBlockId.value,void 0),pe.showMessage("已在上方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{pe.showMessage("插入分页符失败")}}async function _(){const w=e.activeBlockId.value||e.currentDocId.value;if(w)try{await Ti("markdown","---",void 0,w),pe.showMessage("已在下方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{pe.showMessage("插入分页符失败")}}async function A(){if(e.activeBlockId.value)try{await Qr(e.activeBlockId.value),pe.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{pe.showMessage("删除失败")}}async function M(){var w,P;try{let R=null;if(typeof document<"u"){const G=e.activeBlockId.value;if(G){const S=document.querySelector(`.protyle-wysiwyg [data-node-id="${G}"]`);S&&(R=S.getAttribute("data-type")==="NodeSuperBlock"?S:S.closest('[data-type="NodeSuperBlock"]'))}if(!R){const S=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(S){const L=document.querySelector(`.protyle-wysiwyg [data-node-id="${S}"]`);if(L){let y=L.nextElementSibling;for(;y&&!(y.getAttribute("data-type")==="NodeThematicBreak"||(w=y.classList)!=null&&w.contains("protyle-wysiwyg__block--hr"));){const B=y.getAttribute("data-type")==="NodeSuperBlock"?y:y.querySelector('[data-type="NodeSuperBlock"]');if(B){R=B;break}y=y.nextElementSibling}}}else{const L=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),y=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const B of y)if(!L||B.compareDocumentPosition(L)&Node.DOCUMENT_POSITION_FOLLOWING){R=B;break}}}}const z=[];if(R){const G=Array.from(R.querySelectorAll(":scope > [data-node-id]"));for(const S of G){const L=S.getAttribute("data-node-id");L&&(z.push(L),S.removeAttribute("style"))}}else if((P=e.targetSlide.value)!=null&&P.blocks){for(const G of e.targetSlide.value.blocks)if(G.children&&G.children.length>=2){for(const S of G.children)S.id&&z.push(S.id);break}}if(z.length>0)for(const G of z)await Ne(G,{style:""}).catch(()=>{});await o(yt,""),pe.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(R){console.error("[layout-actions] resetSuperBlockWidth error:",R),pe.showMessage("重置超级块比例失败")}}async function E(){var w,P,R;try{let z=null;if(typeof document<"u"){const S=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),L=e.activeBlockId.value;let y=[];if(S){const T=document.querySelector(`.protyle-wysiwyg [data-node-id="${S}"]`);if(T){let D=T.nextElementSibling;for(;D&&!(D.getAttribute("data-type")==="NodeThematicBreak"||(w=D.classList)!=null&&w.contains("protyle-wysiwyg__block--hr"));)y.push(D),D=D.nextElementSibling}}else{const T=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),D=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const N of D)if(!T||N.compareDocumentPosition(T)&Node.DOCUMENT_POSITION_FOLLOWING)y.push(N);else break}const B=[];let F;for(const T of y){const D=T.getAttribute("data-type");D==="NodeHeading"&&(F=T.getAttribute("data-node-id")||void 0);const N=[];D==="NodeSuperBlock"?N.push(T):N.push(...Array.from(T.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const X of N){if((X.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const U=X.getAttribute("data-node-id")||"";let ie=[];const se=Array.from(X.querySelectorAll('[data-type="NodeListItem"]'));if(se.length===4&&(ie=se.map(le=>le.getAttribute("data-node-id")).filter(Boolean)),ie.length!==4){const le=Array.from(X.querySelectorAll(":scope > [data-node-id]"));le.length===4&&(ie=le.map(ve=>ve.getAttribute("data-node-id")).filter(Boolean))}ie.length===4&&B.push({sbId:U,itemIds:ie,headerId:F})}}B.length>0&&(L&&(z=B.find(T=>{if(T.sbId===L||T.itemIds.includes(L))return!0;const D=document.querySelector(`.protyle-wysiwyg [data-node-id="${T.sbId}"]`),N=document.querySelector(`.protyle-wysiwyg [data-node-id="${L}"]`);return!!(D&&N&&D.contains(N))})||null),z||(z=B[0]))}if(!z&&((P=e.targetSlide.value)!=null&&P.blocks)){const S=e.targetSlide.value,L=[];for(const B of S.blocks)B.rawNode?L.push(B.rawNode):L.push({id:B.id,type:B.type,content:B.content,markdown:B.rawMarkdown,children:B.children,ial:B.attributes||B.ial||{}});const y=wf(L,e.activeBlockId.value);y&&y.items.length===4&&(z={sbId:y.superBlockNode.id,itemIds:y.items.map(B=>B.id),headerId:(R=y.headerNode)==null?void 0:R.id})}if(!z||z.itemIds.length!==4)return pe.showMessage("当前页面未找到包含 4 个组件的超级块（需包含 4 个列表项或 4 个子块）",4e3,"info"),!1;const G=e.currentPageDividerId.value||e.currentDocId.value;G&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Be.setBlockAttrOverride(G,{[fe]:"clover"}),et(G,{[fe]:"clover"}),await Ne(G,{[fe]:"clover"}).catch(()=>{})),z.headerId&&(Be.setBlockAttrOverride(z.headerId,{[Ce]:"header"}),et(z.headerId,{[Ce]:"header"}),await Ne(z.headerId,{[Ce]:"header"}).catch(()=>{}));for(let S=0;S<4;S++){const L=z.itemIds[S],y=`col-${S+1}`;Be.setBlockAttrOverride(L,{[Ce]:y}),et(L,{[Ce]:y}),await Ne(L,{[Ce]:y}).catch(()=>{})}return pe.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(z){return console.error("[layout-actions] applyCloverLayout error:",z),pe.showMessage("配置四叶草布局失败",4e3,"error"),!1}}return{onToggleVideoAutoplay:s,onToggleVideoLoop:l,onToggleVideoMuted:r,onToggleVideoControls:a,onImageRoleChange:c,toggleElemClick:d,onElemClickStepChange:p,onElemMotionChange:v,onElemSlotChange:u,onElemShikiLinesChange:h,onElemMaxHeightChange:f,onSetTwoColsContrast:b,onClearBlockAttrs:k,onInsertDividerBefore:x,onInsertDividerAfter:_,onDeleteCurrentBlock:A,resetSuperBlockWidth:M,applyCloverLayout:E}}function I0(e){const{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:o,applyPageLayoutAndRatio:s,saveDocAttr:l}=S0(e),r=C0(e,{triggerSaveNotice:t}),a=$0(e,{saveAttr:n,saveAttrs:i,savePageAttr:o});function c(){if(!e.latestDoc.value){pe.showMessage("请先在主编辑区打开幻灯片文档");return}const p=Ta(e.latestDoc.value);Aa("presentation.html",p)&&pe.showMessage("已开始下载单文件离线 HTML 演示包")}function d(){if(!e.latestDoc.value){pe.showMessage("请先在主编辑区打开幻灯片文档");return}Ba(e.latestDoc.value)&&pe.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:o,applyPageLayoutAndRatio:s,saveDocAttr:l,onToggleVideoAutoplay:a.onToggleVideoAutoplay,onToggleVideoLoop:a.onToggleVideoLoop,onToggleVideoMuted:a.onToggleVideoMuted,onToggleVideoControls:a.onToggleVideoControls,onImageRoleChange:a.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,toggleElemClick:a.toggleElemClick,onElemClickStepChange:a.onElemClickStepChange,onElemMotionChange:a.onElemMotionChange,onElemSlotChange:a.onElemSlotChange,onElemShikiLinesChange:a.onElemShikiLinesChange,onElemMaxHeightChange:a.onElemMaxHeightChange,onSetTwoColsContrast:a.onSetTwoColsContrast,onClearBlockAttrs:a.onClearBlockAttrs,onInsertDividerBefore:a.onInsertDividerBefore,onInsertDividerAfter:a.onInsertDividerAfter,onDeleteCurrentBlock:a.onDeleteCurrentBlock,resetSuperBlockWidth:a.resetSuperBlockWidth,applyCloverLayout:a.applyCloverLayout,onExportHtml:c,onExportPdf:d}}function E0(e){const t=xe(()=>er(e.activeBlockType.value));function i(n){const{attrKey:o,fallback:s,mode:l="defined"}=n,r=a=>l==="truthy"?a:a!==void 0;return xe(()=>{if(t.value){const c=e.activeBlockAttrs.value[o];if(r(c))return c}const a=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(a){const c=Be.getBlockAttrOverride(a);if(r(c==null?void 0:c[o]))return c[o]}return s()})}return{isDivider:t,resolvePageAttr:i}}const T0={class:"spm-slidev-inspector"},A0={class:"spm-inspector-topbar"},B0={class:"spm-inspector-title"},M0={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},D0={class:"spm-inspector-topbar-actions"},L0={class:"spm-target-banner"},O0={class:"spm-target-info"},P0=["aria-label"],R0={key:0,class:"spm-save-status"},N0=["title"],z0={class:"spm-inspector-body"},F0=xt({__name:"SlidevInspectorDockView",setup(e,{expose:t}){const i=ti("plugin"),n=he(!1);function o(J){n.value=!1,c.value=J.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(J.docId)}const s=he(""),l=he(""),r=he({}),a=he(""),c=he(""),d=he(""),p=he(""),v=he(""),u=he(""),h=he(""),f=he(""),b=he(null),k=he(""),x=he("");function _(){var me;const J=s.value||c.value;J&&typeof navigator<"u"&&(me=navigator==null?void 0:navigator.clipboard)!=null&&me.writeText&&navigator.clipboard.writeText(J).then(()=>{x.value="已复制！",setTimeout(()=>{x.value=""},1500)}).catch(()=>{})}const A=xe(()=>er(l.value)),M=xe(()=>l.value==="NodeCodeBlock"),E=he(!1),w=xe(()=>{if(E.value||Ve.value)return!0;const J=a.value||"";return!!bi(J)}),P=xe(()=>{const J=l.value||"";if(J==="NodeVideo"||J==="video")return!0;const me=a.value||"";return!!(/<video\b/i.test(me)||/\.mp4\b/i.test(me))}),R=xe(()=>!s.value||s.value===c.value||l.value==="doc"||l.value==="NodeDocument"),z=xe(()=>{const J=s.value||c.value||"";return J.length>8?J.slice(-8):J||"无"}),G=xe(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),S=xe(()=>{if(A.value)return"分页符 (---)";if(R.value)return"全局文档";if(P.value)return"视频块";let J="内容块";switch(l.value){case"NodeHeading":J="标题块";break;case"NodeParagraph":J="段落块";break;case"NodeCodeBlock":J="代码块";break;case"NodeVideo":J="视频块";break;case"NodeList":case"NodeListItem":J="列表项";break;case"NodeBlockquote":J="引述块";break;case"NodeTable":J="表格块";break;case"NodeSuperBlock":case"s":case"sb":J="超级块";break;default:J="内容块";break}return u.value?h.value?`${h.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${J}`:`分栏容器 › ${J}`:J}),L=xe(()=>A.value?"tag-divider":R.value?"tag-doc":"tag-block"),y=xe(()=>r.value[fe]||"default"),B=xe(()=>r.value[tt]||"slide-left"),F=he(""),T=he(""),D=xe(()=>r.value[vn]||"inherit"),N=xe(()=>{var J;return w0((J=b.value)==null?void 0:J.slides,{activeBlockId:s.value,activeBlockType:l.value,currentTopBlockId:d.value,currentPageDividerId:p.value,activeBlockAttrs:r.value})}),X=xe(()=>{var J;return((J=N.value)==null?void 0:J.notes)||""}),Z=xe(()=>{var J,me,Ie;return((Ie=(me=(J=N.value)==null?void 0:J.noteBlocks)==null?void 0:me[0])==null?void 0:Ie.id)||""}),U=xe(()=>{var ze,Fe,Le,ut,Vn,di;if(A.value){const Qe=r.value[fe]||r.value["custom-slidev-layout"];if(Qe)return Qe}const J=r.value[Ce]||r.value["custom-slidev-slot"];if(J&&(["col-1","col-2","col-3"].includes(J)||/^col-\d+$/.test(J)))return"cols-header";if(v.value)return v.value;const me=p.value||(A.value?s.value:"");if(me){const Qe=Be.getBlockAttrOverride(me);if(Qe!=null&&Qe[fe])return Qe[fe]}if(me&&((ze=b.value)!=null&&ze.slides)){const Qe=b.value.slides.find(Fi=>Fi.startBlockId===me);if((Fe=Qe==null?void 0:Qe.frontmatter)!=null&&Fe.layout)return Qe.frontmatter.layout}if((ut=(Le=N.value)==null?void 0:Le.frontmatter)!=null&&ut.layout)return N.value.frontmatter.layout;if((di=(Vn=N.value)==null?void 0:Vn.blocks)!=null&&di.some(Qe=>Qe.slot&&(["col-1","col-2","col-3"].includes(Qe.slot)||/^col-\d+$/.test(Qe.slot))))return"cols-header";const Ie=Be.getBlockAttrOverride(c.value);return Ie!=null&&Ie[fe]?Ie[fe]:"default"}),ie=E0({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,currentPageDividerId:p}),se=ie.resolvePageAttr({attrKey:yt,mode:"truthy",fallback:()=>{var J,me;return((me=(J=N.value)==null?void 0:J.frontmatter)==null?void 0:me.layoutRatio)||""}}),le=ie.resolvePageAttr({attrKey:Ki,fallback:()=>{var J,me;return((me=(J=N.value)==null?void 0:J.frontmatter)==null?void 0:me.mask)||""}}),ve=ie.resolvePageAttr({attrKey:qi,fallback:()=>{var J,me;return((me=(J=N.value)==null?void 0:J.frontmatter)==null?void 0:me.maskRatio)||""}}),Te=ie.resolvePageAttr({attrKey:Gi,fallback:()=>{var J,me;return((me=(J=N.value)==null?void 0:J.frontmatter)==null?void 0:me.maskStyle)||"solid"}}),ye=ie.resolvePageAttr({attrKey:Zi,fallback:()=>{var J,me;return((me=(J=N.value)==null?void 0:J.frontmatter)==null?void 0:me.maskInitial)||"hidden"}});function ae(J){if(!J||(J.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Ie=Array.from(J.querySelectorAll(":scope > [data-node-id]"));if(Ie.length<2)return null;const ze=Ie.length,Fe=Ie.map(di=>{const Qe=di.getAttribute("style")||"",Fi=Qe.match(/calc\(\s*([\d.]+)%/);if(Fi)return parseFloat(Fi[1]);const dn=Qe.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return dn?parseFloat(dn[1]):null});let Le="",ut=!1;if(Fe.some(di=>di!==null)){ut=!0;const di=Fe.reduce((Ae,ft)=>Ae+(ft||0),0),Qe=Fe.filter(Ae=>Ae===null).length,Fi=Qe>0?Math.max(0,100-di)/Qe:100/Ie.length,dn=Fe.map(Ae=>Ae!==null?Ae:Fi),_c=dn.reduce((Ae,ft)=>Ae+ft,0)||1,un=dn.map(Ae=>Ae/_c*100);if(un.length===2){const[Ae]=un;if(Ae>=48&&Ae<=52)Le="1:1";else if(Ae>=31&&Ae<=35)Le="1:2";else if(Ae>=65&&Ae<=69)Le="2:1";else if(Ae>=28&&Ae<=32)Le="3:7";else if(Ae>=68&&Ae<=72)Le="7:3";else if(Ae>=38&&Ae<=42)Le="4:6";else if(Ae>=58&&Ae<=62)Le="6:4";else{const ft=Math.round(Ae);Le=`${ft}:${100-ft}`}}else if(un.length===3){const[Ae,ft,ui]=un;if(Ae>=31&&Ae<=35&&ft>=31&&ft<=35&&ui>=31&&ui<=35)Le="1:1:1";else if(Ae>=23&&Ae<=27&&ft>=48&&ft<=52&&ui>=23&&ui<=27)Le="1:2:1";else if(Ae>=48&&Ae<=52&&ft>=23&&ft<=27&&ui>=23&&ui<=27)Le="2:1:1";else if(Ae>=23&&Ae<=27&&ft>=23&&ft<=27&&ui>=48&&ui<=52)Le="1:1:2";else{const or=Math.round(Ae),sr=Math.round(ft);Le=`${or}:${sr}:${100-or-sr}`}}else Le=un.map(Ae=>Math.round(Ae)).join(":")}else ut=!1,Le=Array.from({length:ze},()=>1).join(":");const Vn=ze>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:ze,ratio:Le,isCustomWidth:ut,recommendedLayout:Vn}}function Y(J){if(!(J!=null&&J.blocks))return null;for(const me of J.blocks){const Ie=me.rawNode;if(Ie&&ot(Ie)&&Gt(Ie)){const Fe=cn(Ie).length,Le=Gs(Ie);return{hasSuperBlock:!0,colCount:Fe,ratio:Le||Array.from({length:Fe},()=>1).join(":"),isCustomWidth:!!Le,recommendedLayout:Fe>=2?"cols-header":"two-cols"}}}return null}const ce=xe(()=>{var J;if(typeof document<"u"){const me=s.value;if(me){const ze=document.querySelector(`.protyle-wysiwyg [data-node-id="${me}"]`);if(ze){const Fe=ze.getAttribute("data-type")==="NodeSuperBlock"?ze:ze.closest('[data-type="NodeSuperBlock"]');if(Fe){const Le=ae(Fe);if(Le)return Le}}}const Ie=p.value||(A.value?s.value:"");if(Ie){const ze=document.querySelector(`.protyle-wysiwyg [data-node-id="${Ie}"]`);if(ze){let Fe=ze.nextElementSibling;for(;Fe&&!(Fe.getAttribute("data-type")==="NodeThematicBreak"||(J=Fe.classList)!=null&&J.contains("protyle-wysiwyg__block--hr"));){const Le=Fe.getAttribute("data-type")==="NodeSuperBlock"?Fe:Fe.querySelector('[data-type="NodeSuperBlock"]');if(Le){const ut=ae(Le);if(ut)return ut}Fe=Fe.nextElementSibling}}}else{const ze=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Fe=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Le of Fe)if(!ze||Le.compareDocumentPosition(ze)&Node.DOCUMENT_POSITION_FOLLOWING){const ut=ae(Le);if(ut)return ut}}}return Y(N.value)}),O=xe(()=>{var J;return((J=ce.value)==null?void 0:J.ratio)||""}),j=xe(()=>{const J=l.value||"";if(J==="NodeSuperBlock"||J==="s"||J==="sb")return!0;if(typeof document<"u"&&s.value){const me=document.querySelector(`.protyle-wysiwyg [data-node-id="${s.value}"]`);if(me!=null&&me.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),g=xe(()=>{var J;return((J=N.value)==null?void 0:J.pageIndex)||1}),q=xe(()=>!!(r.value[nt]||r.value["slidev-note"]));function H(){if(!u.value)return!1;if(s.value===u.value||typeof document>"u")return!0;const J=document.querySelector(`.protyle-wysiwyg [data-node-id="${u.value}"]`)||document.querySelector(`[data-node-id="${u.value}"]`);if(!J)return!1;const me=J.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(me==null?void 0:me.getAttribute("data-node-id"))===s.value}const $=xe(()=>{var me;if(r.value[Ze]!==void 0)return r.value[Ze]||"";if(u.value&&H())return f.value||"";if(u.value)return"";const J=s.value;if(J&&((me=N.value)!=null&&me.blocks)){const Ie=N.value.blocks.find(ze=>ze.id===J);if(Ie!=null&&Ie.clicks)return Ie.clicks}return""}),I=xe(()=>{var me;if(r.value[Kt])return r.value[Kt];const J=s.value;if(J&&((me=N.value)!=null&&me.blocks)){const Ie=N.value.blocks.find(ze=>ze.id===J);if(Ie!=null&&Ie.motion)return typeof Ie.motion=="string"?Ie.motion:JSON.stringify(Ie.motion)}return""}),C=xe(()=>{var me;if(r.value[Ce])return r.value[Ce];const J=s.value;if(J&&((me=N.value)!=null&&me.blocks)){const Ie=N.value.blocks.find(ze=>ze.id===J);if(Ie!=null&&Ie.slot)return Ie.slot}return""}),W=he(""),K=he(""),V=xe(()=>r.value[Ei]==="true"),Q=xe(()=>r.value[fo]==="true"),oe=xe(()=>r.value[Wi]==="true"),ne=xe(()=>r.value[po]!=="false"),ue=xe(()=>{var J,me;return((me=(J=b.value)==null?void 0:J.config)==null?void 0:me.theme)||r.value[$n]||"default"}),Se=xe(()=>{var J,me;return((me=(J=b.value)==null?void 0:J.config)==null?void 0:me.aspectRatio)||r.value[In]||"16/9"}),ke=xe(()=>{var J,me;return((me=(J=b.value)==null?void 0:J.config)==null?void 0:me.defaultTransition)||r.value[En]||"slide-left"}),Me=xe(()=>{var J,me;return((me=(J=b.value)==null?void 0:J.config)==null?void 0:me.spacing)||r.value[as]||"normal"}),Ve=xe(()=>{var Fe,Le;if((r.value[qe]||r.value["slidev-role"])===ol||r.value[je]==="true")return"background";const me=r.value[fe]||r.value["slidev-layout"];if(me==="image-left"||me==="image-right")return me;const Ie=a.value||"",ze=bi(Ie);if(ze&&((Le=(Fe=N.value)==null?void 0:Fe.frontmatter)!=null&&Le.background)){const ut=N.value.frontmatter.background;if(ut===ze||ut.endsWith(ze)||ze.endsWith(ut))return"background"}return""}),Ge=xe(()=>!!(r.value[Ze]||r.value[Kt]||r.value[Ce]||r.value[Pi]||r.value[nt]||r.value["slidev-note"]||r.value[qe]||r.value[fe]||r.value[Ei]||r.value[fo]||r.value[Wi]||r.value[po])),{saveAttr:Je,savePageAttr:De,applyPageLayoutAndRatio:Zt,applyCloverLayout:st,resetSuperBlockWidth:Xe,saveDocAttr:Ft,onToggleVideoAutoplay:Ni,onToggleVideoLoop:Fo,onToggleVideoMuted:Ho,onToggleVideoControls:Un,onImageRoleChange:ki,onToggleNoteBlock:zi,onAddNoteBlock:ja,onLocateNoteBlock:Wa,onGenerateNotesWithAI:Ua,isBatchProcessing:Va,onBatchAppendNotes:Ka,onBatchDeleteNotes:qa,toggleElemClick:Ga,onElemClickStepChange:Za,onElemMotionChange:Ya,onElemSlotChange:Ja,onElemShikiLinesChange:Xa,onElemMaxHeightChange:Qa,onSetTwoColsContrast:ec,onClearBlockAttrs:tc,onInsertDividerBefore:ic,onInsertDividerAfter:tr,onDeleteCurrentBlock:nc,onExportHtml:oc,onExportPdf:sc}=I0({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:p,currentPageDividerLayout:v,parentContainerId:u,parentContainerClicks:f,latestDoc:b,targetSlide:N,currentSlideNoteBlockId:Z,currentSlideLayout:U,isNoteBlock:q,elemClick:$,videoAutoplay:V,videoLoop:Q,videoMuted:oe,videoControls:ne,pageBackground:F,pageImage:T,elemShikiLines:W,elemMaxHeight:K,saveStatus:k,plugin:i});async function rc(J){if(J==="clover"){if(!await st())return}else Je(fe,J)}function lc(J){De(yt,J)}function ac(J){De(Ki,J)}function cc(J){De(qi,J)}function dc(J){De(Gi,J)}function uc(J){De(Zi,J)}function ir(J){if(!J)return;const me=J.recommendedLayout||(J.colCount&&J.colCount>=2?"cols-header":"two-cols"),Ie=J.ratio||(J.colCount?Array(J.colCount).fill(1).join(":"):"1:1");Zt(me,Ie)}function fc(J){De(yt,J)}async function pc(){await Xe()}function hc(J){Je(tt,J)}function mc(J){F.value=J,Je(je,J)}function gc(J){T.value=J,Je(Dt,J)}function vc(J){Je(vn,J==="inherit"?"":J)}function bc(J){Ft($n,J)}function yc(J){Ft(In,J)}function kc(J){Ft(En,J)}function wc(J){Ft(as,J)}function nr(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function xc(){i!=null&&i.openPresenterTab&&i.openPresenterTab()}function Sc(){i!=null&&i.executeCommand&&i.executeCommand("slidevAiSplit")}return t({setActiveBlock(J){s.value=J.id,l.value=J.type,r.value={...J.attrs},a.value=J.content||J.markdown||"",d.value=J.topBlockId||J.id,p.value=J.pageDividerId||"",v.value=J.pageDividerLayout||"",u.value=J.parentContainerId||"",h.value=J.parentContainerSlot||"",f.value=J.parentContainerClicks||"",J.rootId?c.value=J.rootId:(J.type==="doc"||J.type==="NodeDocument")&&J.id&&(c.value=J.id),F.value=J.attrs[je]||"",T.value=J.attrs[Dt]||"",W.value=J.attrs[Pi]||"",K.value=J.attrs[Tn]||"",E.value=!!J.isImage},updateDocument(J){b.value=J,c.value=J.docId},openImportDialog(){n.value=!0},setCurrentDocId(J){c.value=J}}),(J,me)=>(ee(),te("div",T0,[m("div",A0,[m("div",B0,[(ee(),te("svg",M0,[...me[2]||(me[2]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),me[3]||(me[3]=m("span",null,"演示配置",-1))]),m("div",D0,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:me[0]||(me[0]=Ie=>n.value=!0)},[re(de,{name:"import"}),me[4]||(me[4]=m("span",null,"导入",-1))]),m("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:nr},[re(de,{name:"split-preview"}),me[5]||(me[5]=m("span",null,"分屏预览",-1))])])]),m("div",L0,[m("div",O0,[m("span",{class:_e(["spm-target-tag",L.value])},we(S.value),3),m("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":x.value||"点击复制 ID: "+(s.value||c.value),onClick:_},[re(de,{name:"copy"}),m("span",null,"#"+we(z.value),1)],8,P0)]),k.value?(ee(),te("span",R0,"● "+we(k.value),1)):Oe("",!0)]),G.value?(ee(),te("div",{key:0,class:"spm-context-quote",title:a.value},we(G.value),9,N0)):Oe("",!0),m("div",z0,[A.value?(ee(),Ot(qv,{key:0,"page-layout":y.value,"page-layout-ratio":ge(se),"page-mask":ge(le),"page-mask-ratio":ge(ve),"page-mask-style":ge(Te),"page-mask-initial":ge(ye),"detected-sb-ratio":O.value,"detected-sb-info":ce.value,"page-transition":B.value,"page-background":F.value,"page-spacing":D.value,"page-image":T.value,"page-notes":X.value,"page-index":g.value,"onUpdate:pageLayout":rc,"onUpdate:pageLayoutRatio":lc,"onUpdate:pageMask":ac,"onUpdate:pageMaskRatio":cc,"onUpdate:pageMaskStyle":dc,"onUpdate:pageMaskInitial":uc,onApplySuperBlockLayout:ir,onResetSuperblockRatio:pc,"onUpdate:pageTransition":hc,"onUpdate:pageBackground":mc,"onUpdate:pageSpacing":vc,"onUpdate:pageImage":gc,onAddNoteBlock:ge(ja),onLocateNoteBlock:ge(Wa),onGenerateNotes:ge(Ua),onBatchAppendNotes:ge(Ka),onBatchDeleteNotes:ge(qa),"is-batch-processing":ge(Va),onInsertDividerAfter:ge(tr),onDeleteDivider:ge(nc)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):s.value&&!R.value?(ee(),Ot(B1,{key:1,"elem-click":$.value,"elem-motion":I.value,"elem-slot":C.value,"elem-shiki-lines":W.value,"elem-max-height":K.value,"is-code-block":M.value,"is-image":w.value,"is-video":P.value,"is-super-block":j.value,"detected-sb-info":ce.value,"video-autoplay":V.value,"video-loop":Q.value,"video-muted":oe.value,"video-controls":ne.value,"has-block-attrs":Ge.value,"is-note":q.value,"image-role":Ve.value,"current-slide-layout":U.value,"parent-elem-click":f.value,"parent-container-slot":h.value,"parent-container-id":u.value,onToggleNote:ge(zi),onToggleElemClick:ge(Ga),onToggleVideoAutoplay:ge(Ni),onToggleVideoLoop:ge(Fo),onToggleVideoMuted:ge(Ho),onToggleVideoControls:ge(Un),"onUpdate:imageRole":ge(ki),"onUpdate:elemClick":ge(Za),"onUpdate:elemMotion":ge(Ya),"onUpdate:elemSlot":ge(Ja),"onUpdate:elemShikiLines":ge(Xa),"onUpdate:elemMaxHeight":ge(Qa),onApplySuperBlockLayout:ir,onApplySuperBlockRatio:fc,onInsertDividerBefore:ge(ic),onInsertDividerAfter:ge(tr),onSetTwoColsContrast:ge(ec),onClearBlockAttrs:ge(tc)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(ee(),Ot(my,{key:2,"doc-theme":ue.value,"doc-aspect-ratio":Se.value,"doc-default-transition":ke.value,"doc-spacing":Me.value,"onUpdate:docTheme":bc,"onUpdate:docAspectRatio":yc,"onUpdate:docDefaultTransition":kc,"onUpdate:docSpacing":wc,onOpenBottomPreview:nr,onOpenPresenter:xc,onAiAutoSplit:Sc,onExportHtml:ge(oc),onExportPdf:ge(sc)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf"]))]),n.value?(ee(),Ot(k0,{key:1,onClose:me[1]||(me[1]=Ie=>n.value=!1),onSuccess:o})):Oe("",!0)]))}}),H0=2e3,j0=600;function W0(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function os(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(Gr(e))return!0;const t=e.firstElementChild;return!!(t&&Gr(t))}function Gr(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function U0(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class V0{constructor(){be(this,"consumers",new Map);be(this,"seq",0);be(this,"verifyTimer",null)}register(t,i,n){if(!i)return()=>{};const o=++this.seq,s=U0(),l={kind:t,element:i,visible:!1,measureOnDemand:!s,observer:null,onVisible:n};return s?(l.observer=new s(r=>{var d;const a=r[r.length-1];if(!a)return;const c=a.isIntersecting&&!l.visible;l.visible=a.isIntersecting,c&&((d=l.onVisible)==null||d.call(l))}),l.observer.observe(i)):l.visible=os(i),this.consumers.set(o,l),()=>{var r;(r=l.observer)==null||r.disconnect(),this.consumers.delete(o),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const i of this.consumers.values())(t=i.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?os(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!W0(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const i of this.consumers.values())if(!i.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var i;this.verifyTimer=null;for(const n of this.consumers.values())if(!n.visible&&os(n.element)){n.visible=!0,(i=n.onVisible)==null||i.call(n);return}},H0))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const ro=new V0,Wn=new Xs;function Pa(e,t,i){const n=()=>{var s;try{(s=i==null?void 0:i.flushDirtyCompile)==null||s.call(i)}catch{}},o=ro.register(e,t,n);return n(),o}let gi=null,At=null,lo=null;function K0(){return At}function q0(e,t){gi&&Ra(),gi=Ks(Eg),gi.provide("plugin",t),gi.provide("sandboxBridge",Wn);const i=gi.mount(e);return At=i,lo=Pa("preview",e,t),i}function Ra(e){lo&&(lo(),lo=null),gi&&(gi.unmount(),gi=null,At=null)}function G0(){return At!==null}let Bi=null;function Z0(e,t){return Bi&&Na(),Bi=Ks(Bg),Bi.provide("plugin",t),Bi.mount(e)}function Na(e){Bi&&(Bi.unmount(),Bi=null)}let vi=null,_t=null,ao=null;function Y0(e,t){vi&&za(),vi=Ks(F0),vi.provide("plugin",t),vi.provide("sandboxBridge",Wn);const i=vi.mount(e);return _t=i,ao=Pa("dock",e,t),i}function za(e){ao&&(ao(),ao=null),vi&&(vi.unmount(),vi=null,_t=null)}function J0(e,t){_t!=null&&_t.updateDocument&&_t.updateDocument(e),At!=null&&At.updateDocument?At.updateDocument(e,t):Wn.updateSlides(e.slides,e.config,e.fullMarkdown)}function Cs(e){At!=null&&At.navigateToBlock?At.navigateToBlock(e):Wn.highlightElement(e)}function co(e){_t!=null&&_t.setActiveBlock&&_t.setActiveBlock(e)}function X0(){return _t!=null&&_t.openImportDialog?(_t.openImportDialog(),!0):!1}function Q0(e,t){const i=[];let o=0;for(let s=0;s<e.length;s++){const l=e[s];if(Co(l)){o=0;continue}const r=l.markdown||l.content||"";if(!(s===0)){if(l.type==="h"&&(l.subType==="h1"||r.startsWith("# "))){i.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),o=0;continue}if(l.type==="h"&&(l.subType==="h2"||r.startsWith("## "))){i.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),o=0;continue}}if(o++,o>=6&&s<e.length-1){const c=e[s+1];Co(c)||(i.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),o=0)}}return i}const ek=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Ii,value:"true"},{key:fe,value:"cover"},{key:tt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Ii,value:"true"},{key:fe,value:"two-cols"},{key:tt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Ii,value:"true"},{key:fe,value:"fact"},{key:tt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Ii,value:"true"},{key:fe,value:"intro"},{key:tt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Ii,value:"true"},{key:fe,value:"quote"},{key:tt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Ze,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Ze,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Ce,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Pi,value:"1-3"}]}];class ss{getPresetTemplates(){return ek}buildScanSlidevBlocksSql(t="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${tt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,i,n,o){const s=`SELECT block_id FROM attributes WHERE name = '${tt}' AND value = '${t}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{[tt]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,i,n,o){const s=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${t}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{"custom-slidev-layout":i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${t.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function tk(e){e.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),e.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{X0()||pe.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await Ne(e.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),pe.showMessage("已为当前文档初始化 Slidev 演示属性"),e.compileCurrentDocument(e.currentDocId))}}),e.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const s=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}if(!e.currentDocId){pe.showMessage("请先打开一篇思源笔记文档");return}const t=await uo(e.currentDocId).catch(()=>[]);if(!t||t.length===0){pe.showMessage("当前文档无内容，无需断页");return}const i=t.map(s=>({id:s.id,type:s.type,subType:s.subType,content:s.content||"",markdown:s.markdown||""})),n=Q0(i);if(n.length===0){pe.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}pe.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const s of n)try{await Ti("markdown","---",void 0,s.blockId),await Ne(s.blockId,{"custom-slidev-layout":s.recommendedLayout}),o++}catch(l){console.warn("Failed to insert divider:",l)}pe.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,d,p;if(!e.currentDocId){const v=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(v==null?void 0:v.getAttribute("data-doc-id"))||""}if(!e.currentDocId){pe.showMessage("请先打开一篇思源笔记文档");return}pe.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await uo(e.currentDocId).catch(()=>[]),i={startBlockId:e.currentDocId,blocks:t.map(v=>({id:v.id,type:v.type,content:v.content||"",rawMarkdown:v.markdown||""})),rawMarkdown:""},s=`> [!NOTE] 💡 演讲备注
${(await _0(i,el)).split(/\r?\n/).map(v=>`> ${v}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await rs("markdown",s,e.currentDocId).catch(()=>null),r=((d=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:d.id)||((p=l==null?void 0:l[0])==null?void 0:p.id);r&&(await Ne(r,{"custom-slidev-note":"true"}),Be.setBlockAttrOverride(r,{"custom-slidev-note":"true"}),Oi(r,e.app)),pe.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new ss,i=t.buildTransitionStatsSql(),n=await tn(i).catch(()=>[]),o=t.formatTransitionSummary(n||[]);pe.showMessage(o)}}),e.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new ss().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),pe.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):pe.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),e.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new ss().batchUpdateTransitions("fade","slide-left",n=>tn(n).catch(()=>[]),(n,o)=>Ne(n,o));pe.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),e.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),e.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){pe.showMessage("请先打开并放映一篇思源笔记文档");return}e.cliBridge.downloadSlidesMd(e.latestCompiledDoc,`slides-${e.currentDocId||"demo"}.md`)&&pe.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),e.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{pe.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await e.cliBridge.probeServer(1500)?pe.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):pe.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),e.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){pe.showMessage("请先打开并放映一篇思源笔记文档");return}const t=await e.cliBridge.syncToWorkspaceFile(e.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",ls);t.success?pe.showMessage(`已成功同步最新 slides.md 至工作空间：${t.path}`):pe.showMessage(`同步失败：${t.error}`)}})}function Fa(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function Ha(e,t){var i,n,o;if(!t)return"";if(typeof document<"u"){const s=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),l=((s==null?void 0:s.innerText)||(s==null?void 0:s.textContent)||"").trim();if(l)return l}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const s=(i=e.latestCompiledDoc.slides)==null?void 0:i[0],l=(n=s==null?void 0:s.blocks)==null?void 0:n.find(r=>r.type==="h"||r.type==="NodeHeading");if(l!=null&&l.content)return l.content.trim()}try{const s=await tn(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(s)&&s.length>0&&((o=s[0])!=null&&o.content))return String(s[0].content).trim()}catch{}return""}async function ik(e,t,i){var c,d,p;const n=K0(),o=!!((c=n==null?void 0:n.isPinned)!=null&&c.value),s=String(((d=n==null?void 0:n.pinnedDocId)==null?void 0:d.value)||"");if(o&&s&&i&&i!==s)return;const l=i||(o&&s?s:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&l&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(l):await Ha(e,l));const a=Fa(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(a),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",a);return}if(typeof document<"u"){const v=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const u of v){const h=u.querySelector(".item__text"),f=((p=h==null?void 0:h.textContent)==null?void 0:p.trim())||"";if(f.includes("Slidev 演示预览")||f.startsWith("即现")){h&&(h.textContent=a),u.setAttribute("title",a);break}}}}class nk{constructor(t=400){be(this,"entries",new Map);this.ttlMs=t}get(t,i=Date.now()){if(!t)return;const n=this.entries.get(t);if(n){if(i-n.at>this.ttlMs){this.entries.delete(t);return}return n.attrs}}set(t,i,n=Date.now()){!t||!i||this.entries.set(t,{attrs:i,at:n})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function ok(e){const t=new Map;if(!(e!=null&&e.slides))return t;const i=n=>{for(const o of n||[])o!=null&&o.id&&o.ial&&t.set(o.id,o.ial)};for(const n of e.slides)i(n.blocks),i(n.noteBlocks);return t}class sk{constructor(t=150){be(this,"lastBlockId","");be(this,"lastAt",0);this.windowMs=t}shouldSkip(t,i=Date.now()){return t&&t===this.lastBlockId&&i-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=i,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class rk{constructor(){be(this,"attrCache",new nk);be(this,"compiledIalIndex",{doc:null,map:new Map})}async resolveBlockAttrs(t,i){if(!t)return{};const n=Be.getBlockAttrOverride(t),o=this.getCompiledIal(i,t);if(n||o)return{...o||{},...n||{}};const s=this.attrCache.get(t);if(s)return s;const l=await $s(t).catch(()=>({}))||{};return this.attrCache.set(t,l),l}getCompiledIal(t,i){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:ok(t)}),this.compiledIalIndex.map.get(i)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=t==null?void 0:t.getAttribute("data-node-id");if(i)return i;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=document.querySelector("[data-doc-id]"),l=s==null?void 0:s.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(t,i=""){const n=t.closest(".protyle-title"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=t.closest(".protyle"),l=s==null?void 0:s.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=t.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||i}async switchToDocGlobalInspector(t,i){var s;if(!t)return;let n=i||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((s=l==null?void 0:l.innerText)==null?void 0:s.trim())||""}const o=await this.resolveBlockAttrs(t,null);co({id:t,rootId:t,type:"doc",content:n,attrs:o,isDivider:!1,isCode:!1}),Cs(t)}handleBlockClickedFromSlide(t,i,n,o){var a;if(!t)return!1;const s=Oi(t,i),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`),r=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,t,r,n,o);else{let c="",d="";if(o!=null&&o.slides){const p=o.slides.find(v=>{var u,h,f;return v.startBlockId===t||((u=v.blocks)==null?void 0:u.some(b=>b.id===t))||((h=v.allBlockIds)==null?void 0:h.includes(t))||((f=v.noteBlocks)==null?void 0:f.some(b=>b.id===t))});p!=null&&p.startBlockId&&(c=p.startBlockId),(a=p==null?void 0:p.frontmatter)!=null&&a.layout&&(d=p.frontmatter.layout)}this.resolveBlockAttrs(t,o).then(async p=>{if(c&&!d){const v=Be.getBlockAttrOverride(c);if(v!=null&&v[fe]||v!=null&&v["custom-slidev-layout"])d=v[fe]||v["custom-slidev-layout"]||"";else{const u=await this.resolveBlockAttrs(c,o);d=u[fe]||u["custom-slidev-layout"]||"",u&&Object.keys(u).length>0&&Be.setBlockAttrOverride(c,u)}}co({id:t,rootId:n,type:r||"NodeParagraph",attrs:p||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return s}async syncInspectorBlock(t,i,n,o,s){var B,F,T,D,N,X,Z,U;let l=t,r=i,a=n;const c=t.closest('[data-type="NodeCallout"]');if(c&&c!==t){const ie=c.getAttribute("data-node-id");if(ie){const se=await this.resolveBlockAttrs(ie,s),le=Be.getBlockAttrOverride(ie)||{},ve={...se,...le};(ve[nt]||ve["slidev-note"])&&(l=c,r=ie,a="NodeCallout")}}const d=l.closest(".protyle-wysiwyg > [data-node-id]")||l,p=(d==null?void 0:d.getAttribute("data-node-id"))||r,v=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(d==null?void 0:d.getAttribute("data-type"))==="NodeThematicBreak"||(d==null?void 0:d.getAttribute("data-type"))==="tb"||!!((B=d==null?void 0:d.classList)!=null&&B.contains("hr")),u=a==="NodeCodeBlock",h=((F=l.innerText)==null?void 0:F.trim())||"",f=await this.resolveBlockAttrs(r,s),b=Be.getBlockAttrOverride(r)||{},k={...f,...b};let x="",_="";if(v)x=r,_=k[fe]||k["custom-slidev-layout"]||"";else{let ie=d.previousElementSibling;for(;ie;){const se=ie.getAttribute("data-type");if(se==="NodeThematicBreak"||se==="tb"||(T=ie.classList)!=null&&T.contains("hr")){x=ie.getAttribute("data-node-id")||"";break}ie=ie.previousElementSibling}}if(s!=null&&s.slides){const ie=[r,p];let se=l.parentElement;for(;se&&!se.classList.contains("protyle-wysiwyg");){const ve=se.getAttribute("data-node-id");ve&&!ie.includes(ve)&&ie.push(ve),se=se.parentElement}const le=s.slides.find(ve=>{var Te,ye,ae;return ie.includes(ve.startBlockId)||((Te=ve.blocks)==null?void 0:Te.some(Y=>ie.includes(Y.id)))||((ye=ve.allBlockIds)==null?void 0:ye.some(Y=>ie.includes(Y)))||((ae=ve.noteBlocks)==null?void 0:ae.some(Y=>ie.includes(Y.id)))});le&&(!x&&le.startBlockId&&(x=le.startBlockId),!_&&((D=le.frontmatter)!=null&&D.layout)&&(_=le.frontmatter.layout))}if(x){const ie=Be.getBlockAttrOverride(x);if(ie&&(fe in ie||"custom-slidev-layout"in ie)&&(_=ie[fe]||ie["custom-slidev-layout"]||""),!_&&(s!=null&&s.slides)){const se=s.slides.find(le=>le.startBlockId===x);(N=se==null?void 0:se.frontmatter)!=null&&N.layout&&(_=se.frontmatter.layout)}if(!_){const se=await this.resolveBlockAttrs(x,s);_=se[fe]||se["custom-slidev-layout"]||"",se&&Object.keys(se).length>0&&Be.setBlockAttrOverride(x,se)}et(x,{[fe]:_||""})}else if(o){const ie=Be.getBlockAttrOverride(o);ie&&(fe in ie||"custom-slidev-layout"in ie)?_=ie[fe]||ie["custom-slidev-layout"]||"":!_&&((U=(Z=(X=s==null?void 0:s.slides)==null?void 0:X[0])==null?void 0:Z.frontmatter)!=null&&U.layout)&&(_=s.slides[0].frontmatter.layout)}const A=l.getAttribute(fe)||l.getAttribute("custom-slidev-layout"),M=k[fe]||k["custom-slidev-layout"]||"";A&&A!==M&&et(r,{[fe]:M});const E=l.getAttribute(qe)||l.getAttribute("custom-slidev-role"),w=k[qe]||k["custom-slidev-role"]||"";E&&E!==w&&et(r,{[qe]:w});let P="",R="",z="";const G=l.closest('[data-type="NodeListItem"]');if(G&&G!==l){const ie=G.getAttribute("data-node-id");if(ie){P=ie;const se=await this.resolveBlockAttrs(ie,s),le=Be.getBlockAttrOverride(ie)||{},ve={...se,...le};R=ve[Ce]||"",z=ve[Ze]||"";const Te=ve[fe]||ve["custom-slidev-layout"]||"",ye=G.getAttribute(fe)||G.getAttribute("custom-slidev-layout");ye&&ye!==Te&&et(ie,{[fe]:Te});const ae=ve[qe]||ve["custom-slidev-role"]||"",Y=G.getAttribute(qe)||G.getAttribute("custom-slidev-role");Y&&Y!==ae&&et(ie,{[qe]:ae})}}const S=!!l.querySelector("img, span[data-type='img']"),L=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),y=S&&L.length<=50;co({id:r,rootId:o,type:a,content:h,attrs:k,isDivider:v,isCode:u,isImage:y,topBlockId:p,pageDividerId:x,pageDividerLayout:_,parentContainerId:P,parentContainerSlot:R,parentContainerClicks:z})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const i of t.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const n of i.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const o=n.data.old||{},s=n.data.new||{},l={};for(const r of Object.keys(o))r in s||(l[r]="");for(const[r,a]of Object.entries(s))l[r]=String(a??"");et(n.id,l),Be.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidevAttrs(t){var o,s,l;if(typeof document>"u"||!t)return;const i=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const a=i.get(r.startBlockId)||{};(o=r.frontmatter)!=null&&o.layout&&(a[fe]=r.frontmatter.layout),i.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=i.get(a.id)||{};(s=a.ial)!=null&&s[fe]&&(c[fe]=a.ial[fe]),(l=a.ial)!=null&&l[qe]&&(c[qe]=a.ial[qe]),Object.keys(c).length>0&&i.set(a.id,c)}}}const n=Be.getAllAttrOverrides();for(const[r,a]of n.entries()){const c=i.get(r)||{};a[fe]!==void 0&&(c[fe]=a[fe]),a[qe]!==void 0&&(c[qe]=a[qe]),i.set(r,c)}uh(i)}}const Ci=new rk;class lk{constructor(){be(this,"inFlightDocId",null);be(this,"pendingDocId",null);be(this,"generation",0)}get isRunning(){return this.inFlightDocId!==null}get runningDocId(){return this.inFlightDocId}get pending(){return this.pendingDocId}tryBegin(t){return this.inFlightDocId!==null?(this.pendingDocId=t,null):(this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finish(){this.inFlightDocId=null;const t=this.pendingDocId;return this.pendingDocId=null,t}reset(){this.inFlightDocId=null,this.pendingDocId=null,this.generation=0}}const ak=150,ck=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,dk="slidev-dock",Zr="slidev-preview-tab",Yr="slidev-presenter-tab",Jr=hf;class uk extends pe.Plugin{constructor(){super(...arguments);be(this,"isMobile",!1);be(this,"currentDocId","");be(this,"previewTab",null);be(this,"latestCompiledDoc",null);be(this,"cliBridge",new Zs);be(this,"debounceTimer",null);be(this,"activeCursorBlockId","");be(this,"compileScheduler",new lk);be(this,"dirtyDocId",null);be(this,"inspectorSyncThrottle",new sk);be(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));be(this,"onWsMainBound",this.onWsMain.bind(this));be(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));be(this,"onEditorClickBound",this.onEditorClick.bind(this));be(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));be(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));be(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const i=pe.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(ck),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),tk(this);const n=this;if(this.addTab({type:Zr,init(o){const s=this||o;n.previewTab=(s==null?void 0:s.tab)||null,q0(s.element,n),n.updatePreviewTabHeader()},destroy(){n.previewTab===(this==null?void 0:this.tab)&&(n.previewTab=null),Ra(this.element)}}),this.addTab({type:Yr,init(o){Z0((this||o).element,n)},destroy(){Na(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:dk,init(){Y0(this.element,n)},destroy(){za(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(o,s)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${o}`,{detail:s}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const o=()=>{const s=this.getActiveDocumentId();s&&(s!==this.currentDocId&&(this.currentDocId=s,this.updatePreviewTabHeader("",s)),this.latestCompiledDoc||this.markCompileDirty(s))};setTimeout(o,300),setTimeout(o,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(Jr),n=mf(i);return Ai(n),n}catch{return Ai(rn),rn}}async saveGlobalSettings(i){const n=zo(),o=Ai({...n,...i||{}});try{await this.saveData(Jr,o)}catch(l){console.error("保存 Slidev 全局配置失败",l)}const s=this.currentDocId||this.getActiveDocumentId();return s&&this.markCompileDirty(s),o}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,ro.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),Wn.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const i=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",n=this.buildPreviewTabTitle(i);await pe.openTab({app:this.app,custom:{id:this.name+Zr,title:n,icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(i,this.currentDocId)}async openPresenterTab(){G0()||await this.openBottomPreviewTab(),await pe.openTab({app:this.app,custom:{id:this.name+Yr,title:"演讲者控制台",icon:"iconSlidev",data:{}},position:"right"})}async onSwitchProtyle(i){var l,r,a,c,d;const n=(l=i.detail)==null?void 0:l.protyle,o=(r=n==null?void 0:n.block)==null?void 0:r.rootID,s=((d=(c=(a=n==null?void 0:n.title)==null?void 0:a.editElement)==null?void 0:c.textContent)==null?void 0:d.trim())||"";if(o&&o!==this.currentDocId){this.currentDocId=o,this.activeCursorBlockId=o;const p=await $s(o).catch(()=>({}));co({id:o,rootId:o,type:"doc",attrs:p}),this.markCompileDirty(o),this.updatePreviewTabHeader(s,o)}}onClickEditorContent(i){var s,l;const n=i==null?void 0:i.detail;if(!n)return;const o=(l=(s=n.protyle)==null?void 0:s.block)==null?void 0:l.rootID;o&&(!this.currentDocId||this.currentDocId!==o)&&(this.currentDocId=o),n.event&&this.onEditorClick(n.event)}buildPreviewTabTitle(i){return Fa(i)}async fetchDocumentTitle(i){return Ha(this,i)}async updatePreviewTabHeader(i,n){return ik(this,i,n)}getActiveDocumentId(){return Ci.getActiveDocumentId()}resolveDocIdFromElement(i){return Ci.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,n){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await Ci.switchToDocGlobalInspector(i,n))}onWsMain(i){const n=i.detail;n&&n.cmd==="transactions"&&(Ci.patchThematicBreakTransactions(n),this.markCompileDirty())}markCompileDirty(i){const n=i||this.currentDocId||this.getActiveDocumentId();n&&(this.currentDocId||(this.currentDocId=n),this.dirtyDocId=n,this.scheduleDirtyCompile())}scheduleDirtyCompile(i=ak){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const n=ro.getVisibility();if(n==="none")return;const o=n==="visible"?i:Math.max(i,j0);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const s=this.dirtyDocId;this.dirtyDocId=null,s&&this.compileCurrentDocument(s,{reason:"auto"})},o)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(i,n){return i?(this.activeCursorBlockId=i,Ci.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(i){const n=(i==null?void 0:i.detail)||i;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(i){const n=i.target;if(!n)return;const o=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(o||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const p=o||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),v=p==null?void 0:p.querySelector(".protyle-title__input"),u=((v==null?void 0:v.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const a=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Cs(a)),this.syncInspectorBlock(r,a,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const n=i.anchorNode;if(!n)return;const o=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!o)return;const s=o.closest(".protyle-title");if(!!(s||o.closest(".protyle-content")&&!o.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(o);if(d&&this.activeCursorBlockId!==d){const p=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),v=p==null?void 0:p.querySelector(".protyle-title__input"),u=((v==null?void 0:v.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!o.closest(".protyle-wysiwyg"))return;const r=o.closest("[data-node-id]"),a=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";r&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(o)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Cs(a)),this.syncInspectorBlock(r,a,c))}async syncInspectorBlock(i,n,o){this.inspectorSyncThrottle.shouldSkip(n)||await Ci.syncInspectorBlock(i,n,o,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i,n){const o=(n==null?void 0:n.reason)??"explicit";let s=i||this.currentDocId;if(!s){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,s=r;else return}if(o==="auto"&&ro.getVisibility()==="none"){this.dirtyDocId=s;return}const l=this.compileScheduler.tryBegin(s);if(l!==null){this.dirtyDocId===s&&(this.dirtyDocId=null);try{const r=await Be.compile(s),a=!!this.currentDocId&&s!==this.currentDocId;!this.compileScheduler.isStale(l)&&!a&&(this.currentDocId||(this.currentDocId=s),this.latestCompiledDoc=r,J0(r,s),this.updatePreviewTabHeader("",s),this.purgeStaleDomSlidevAttrs(r))}catch(r){console.error("[SiYuanSlidev] Failed to compile document:",r)}finally{const r=this.compileScheduler.finish();r&&this.markCompileDirty(r)}}}purgeStaleDomSlidevAttrs(i){Ci.purgeStaleDomSlidevAttrs(i)}}module.exports=uk;
