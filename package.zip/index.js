"use strict";var va=Object.create;var ys=Object.defineProperty;var ba=Object.getOwnPropertyDescriptor;var ya=Object.getOwnPropertyNames;var wa=Object.getPrototypeOf,ka=Object.prototype.hasOwnProperty;var xa=(t,i,e)=>i in t?ys(t,i,{enumerable:!0,configurable:!0,writable:!0,value:e}):t[i]=e;var _a=(t,i,e,s)=>{if(i&&typeof i=="object"||typeof i=="function")for(let n of ya(i))!ka.call(t,n)&&n!==e&&ys(t,n,{get:()=>i[n],enumerable:!(s=ba(i,n))||s.enumerable});return t};var Mn=(t,i,e)=>(e=t!=null?va(wa(t)):{},_a(i||!t||!t.__esModule?ys(e,"default",{value:t,enumerable:!0}):e,t));var wt=(t,i,e)=>xa(t,typeof i!="symbol"?i+"":i,e);const vt=require("siyuan");async function he(t,i){const e=await vt.fetchSyncPost(t,i);return e.code===0?e.data:null}async function Sa(){return he("/api/notebook/lsNotebooks","")}async function Ca(t,i,e){return he("/api/filetree/createDocWithMd",{notebook:t,path:i,markdown:e})}async function $a(t,i){const e=new FormData;e.append("assetsDirPath",t);for(const n of i)e.append("file[]",n);return he("/api/asset/upload",e)}async function nn(t,i,e,s,n){return he("/api/block/insertBlock",{dataType:t,data:i,nextID:e,previousID:s,parentID:n})}async function $r(t,i,e){return he("/api/block/appendBlock",{dataType:t,data:i,parentID:e})}async function Ro(t,i,e){return he("/api/block/updateBlock",{dataType:t,data:i,id:e})}async function Ia(t){return he("/api/block/deleteBlock",{id:t})}async function Aa(t){return he("/api/block/getBlockKramdown",{id:t})}async function qn(t){return he("/api/block/getChildBlocks",{id:t})}async function Lt(t,i){return he("/api/attr/setBlockAttrs",{id:t,attrs:i})}async function Ge(t){return he("/api/attr/getBlockAttrs",{id:t})}async function vn(t){return he("/api/query/sql",{stmt:t})}async function Os(t,i,e){const s=new FormData;return s.append("path",t),s.append("isDir",i.toString()),s.append("modTime",Math.floor(Date.now()/1e3).toString()),s.append("file",e),he("/api/file/putFile",s)}async function Ir(t){const i="/api/ai/chatGPT";try{const e=await he(i,{msg:t});return typeof e=="string"&&e.trim().length>0?e.trim():e&&typeof e.content=="string"&&e.content.trim().length>0?e.content.trim():null}catch{return null}}async function Ta(){return he("/api/storage/getInlineStyles","")}const rn="custom-slidev-theme",ln="custom-slidev-aspect-ratio",Ar="custom-slidev-highlighter",an="custom-slidev-default-transition",Tr="custom-slidev-color-schema",Ps="custom-slidev-spacing",_i="custom-slidev-slide",ft="custom-slidev-layout",Zt="custom-slidev-transition",Ft="custom-slidev-background",Ae="custom-slidev-image",zi="custom-slidev-notes",Ni="custom-slidev-class",cn="custom-slidev-spacing",Se="custom-slidev-click",je="custom-slidev-motion",Ci="custom-slidev-shiki-lines",At="custom-slidev-slot",Qt="custom-slidev-note",Ut="custom-slidev-role",dn="custom-slidev-max-height",vi="custom-slidev-autoplay",Bn="custom-slidev-loop",Oi="custom-slidev-muted",Dn="custom-slidev-controls",Er="background",Rs="image-left",zs="image-right",bi={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal"};function Ea(t){var i,e,s,n,r,l;return t?{theme:((i=t[rn])==null?void 0:i.trim())||bi.theme,aspectRatio:((e=t[ln])==null?void 0:e.trim())||bi.aspectRatio,highlighter:((s=t[Ar])==null?void 0:s.trim())||bi.highlighter,defaultTransition:((n=t[an])==null?void 0:n.trim())||bi.defaultTransition,colorSchema:((r=t[Tr])==null?void 0:r.trim())||bi.colorSchema,spacing:((l=t[Ps])==null?void 0:l.trim())||bi.spacing}:{...bi}}function Gn(t){var e,s,n,r,l;const i=(e=t.ial)==null?void 0:e[_i];return!!(i&&(i==="true"||i==="page"||i==="cover"||i==="end")||t.type==="tb"||t.type==="thematic-break"||t.type==="NodeThematicBreak"||((s=t.markdown)==null?void 0:s.trim())==="---"||((n=t.markdown)==null?void 0:n.trim())==="***"||t.type==="b"&&(((r=t.markdown)==null?void 0:r.trim())==="---"||((l=t.content)==null?void 0:l.trim())==="---"))}function zo(t){const i={};let e="";if(!t)return{frontmatter:i,notes:e};t[ft]&&(i.layout=t[ft].trim()),t[Zt]&&(i.transition=t[Zt].trim()),t[Ft]&&(i.background=t[Ft].trim()),t[Ae]&&(i.image=t[Ae].trim()),t[Ni]&&(i.class=t[Ni].trim()),t[cn]&&(i.spacing=t[cn].trim()),t[zi]&&(e=t[zi].trim());for(const[s,n]of Object.entries(t))if(s.startsWith("custom-slidev-")&&![ft,Zt,Ft,Ae,Ni,cn,zi,_i].includes(s)){const r=s.replace(/^custom-slidev-/,"");try{i[r]=JSON.parse(n)}catch{i[r]=n}}return{frontmatter:i,notes:e}}function Ma(t){const i={};if(!t)return i;const e=t[Qt]??t["slidev-note"];e!=null&&e!==""&&e!=="false"&&e!=="0"&&(i.isNote=!0);const s=t[Ut]??t["slidev-role"],n=t[Ft]??t["slidev-background"];(s===Er||n==="true"||n==="1")&&(i.isBackground=!0);const r=t[ft]??t["slidev-layout"];r===Rs||r===zs?i.imageLayout=r:(s===Rs||s===zs)&&(i.imageLayout=s);const l=t[Se]??t["custom-slidev-clicks"]??t["slidev-click"]??t["slidev-clicks"];if(l!=null&&(i.clicks=l.trim()),t[je])try{const o=JSON.parse(t[je]);typeof o=="object"&&o!==null?i.motion={preset:o.preset||o.type||"fade-in",...o}:i.motion={preset:String(o).trim()}}catch{i.motion={preset:t[je].trim()}}return t[Ci]&&(i.shikiLines=t[Ci].trim()),t[dn]&&(i.maxHeight=t[dn].trim()),t[At]&&(i.slot=t[At].trim()),t.style&&t.style.trim()&&(i.style=t.style.trim()),i}function Ba(t,i){const e=[];let n=0;for(let r=0;r<t.length;r++){const l=t[r];if(Gn(l)){n=0;continue}const o=l.markdown||l.content||"";if(!(r===0)){if(l.type==="h"&&(l.subType==="h1"||o.startsWith("# "))){e.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),n=0;continue}if(l.type==="h"&&(l.subType==="h2"||o.startsWith("## "))){e.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),n=0;continue}}if(n++,n>=6&&r<t.length-1){const c=t[r+1];Gn(c)||(e.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),n=0)}}return e}function No(t,i){const e=(t.blocks||[]).filter(l=>{const o=(l.content||l.rawMarkdown||"").trim();return o&&o!=="---"});if(e.length===0)return"本页暂无内容，建议过渡承接上下文。";const s=[],n=[];for(const l of e){const o=(l.content||l.rawMarkdown||"").trim();o&&(l.type==="h"||o.startsWith("#")?s.push(o.replace(/^#+\s*/,"")):n.push(o.slice(0,50)))}const r=[];return s.length>0&&r.push(`【核心重点】：${s.join("、")}`),n.length>0&&(r.push("【口播要点】："),n.slice(0,3).forEach((l,o)=>{r.push(`${o+1}. 讲解 ${l}`)})),r.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),r.join(`
`)}async function Mr(t,i){const e=t.blocks&&t.blocks.length>0?t.blocks.map(s=>(s.content||s.rawMarkdown||"").trim()).filter(s=>s&&s!=="---").join(`
`):(t.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(i&&e){const s=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${e}`;try{const n=await i(s);if(n&&n.trim())return{notes:n.trim(),isAiGenerated:!0}}catch(n){return{notes:No(t),isAiGenerated:!1,error:(n==null?void 0:n.message)||"AI 调用异常"}}}return{notes:No(t),isAiGenerated:!1}}async function Da(t,i){return(await Mr(t,i)).notes}const Br=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function La(t){const i=[];if(!t)return i;const e=new RegExp(Br.source,"g");let s;for(;(s=e.exec(t))!==null;){const n=s[2]??s[3]??s[4];i.push({fullMatch:s[0],blockId:s[1],anchorText:n?n.trim():void 0})}return i}function Oa(t,i){if(!t)return"";const e=new RegExp(Br.source,"g");return t.replace(e,(s,n,r,l,o)=>{const a=(r??l??o??"").trim();if(i&&i[n]){const d=i[n].trim();return`<div class="slidev-block-ref" data-ref-id="${n}">${d}</div>`}const c=a||`Ref(${n.slice(0,8)})`;return`<a href="siyuan://blocks/${n}" data-ref-id="${n}" class="slidev-ref-tag">🔗 ${c}</a>`})}function Pa(t){return t.markdown&&t.markdown.trim()?t.markdown.trim():t.content&&t.content.trim()?t.content.trim():""}function Ra(t){const i={};if(!t)return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),s=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let n;for(;(n=s.exec(e))!==null;){const r=n[1],l=n[2]??n[3]??n[4]??"";i[r]=l}return i}function za(t){if(!t)return!1;const i=t.trim();return i.startsWith("assets/")||i.startsWith("./assets/")||i.startsWith("/assets/")}function Na(t){const i=t.trim();return i.startsWith("./assets/")?i.slice(2):i.startsWith("/assets/")?i.slice(1):i}function _e(t,i){if(!za(t))return t;const e=Na(t);return i!=null&&i.base64Map&&i.base64Map[e]?i.base64Map[e]:i!=null&&i.baseUrl?`${i.baseUrl.replace(/\/+$/,"")}/${e}`:`/${e}`}function Fa(t,i){if(!t)return"";let e=t;return e=e.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(s,n,r)=>{const l=_e(r,i);return`![${n}](${l})`}),e=e.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(s,n,r,l)=>{const o=_e(r,i);return`${n}${o}${l}`}),e=e.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(s,n,r,l)=>{const o=_e(r,i);return`${n}${o}${l}`}),e}function fi(t,i){const e=(t||i||"").trim();if(!e)return null;const s=e.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(s)return s[1].trim();const n=e.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(n)return n[1].trim();const r=e.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(r)?r:null}function ae(t){if(!t)return!1;const i=(t.type||"").toLowerCase();return i==="s"||i==="sb"||i==="nodesuperblock"}function Bi(t){if(!ae(t))return!1;const i=(t.subType||"").toLowerCase();if(i==="col"||i==="h"||i==="horizontal")return!0;if(i==="row"||i==="v"||i==="vertical")return!1;if(t.ial){const s=(t.ial["data-sb-layout"]||t.ial.layout||"").toLowerCase();if(s==="col"||s==="h")return!0;if(s==="row"||s==="v")return!1}if(t.children&&t.children.length>0){for(const s of t.children)if(s.type==="NodeSuperBlockLayoutMarker"||s.type==="layout-marker"){const n=(s.content||s.markdown||"").trim().toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}}const e=(t.markdown||t.content||"").trim();return/^\{\{\{col\b/i.test(e)?!0:!/^\{\{\{row\b/i.test(e)}function Ki(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="i"||i==="nodelistitem"||i==="l"||i==="nodelist")return!0;const e=(t.markdown||t.rawMarkdown||t.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(e)}function Ns(t){return!t||Ki(t)||ae(t)||!fi(t.markdown,t.content)?!1:(t.markdown||t.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function pi(t){if(!t||!ae(t)||!Bi(t))return null;const i=(t.children||[]).filter(n=>{const r=n.type||"";if(r==="NodeSuperBlockOpenMarker"||r==="NodeSuperBlockLayoutMarker"||r==="NodeSuperBlockCloseMarker"||r==="open-marker"||r==="layout-marker"||r==="close-marker")return!1;const l=(n.markdown||n.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(l)||l==="}}}")});if(i.length<2)return null;const e=Ns(i[0]),s=Ns(i[i.length-1]);if(e&&!s){const n=fi(i[0].markdown,i[0].content);if(n)return{imageNode:i[0],imageUrl:n,layout:Rs,contentNodes:i.slice(1)}}if(!e&&s){const n=fi(i[i.length-1].markdown,i[i.length-1].content);if(n)return{imageNode:i[i.length-1],imageUrl:n,layout:zs,contentNodes:i.slice(0,i.length-1)}}return null}function ja(t,i){const e=[];function s(n){for(const r of n){const l=pi(r);if(l){const{imageNode:o,layout:a}=l;o.ial||(o.ial={});const c=o.ial[ft];if(c!==a){const d={blockId:o.id,layout:a,previousLayout:c};o.ial[ft]=a,e.push(d),i&&i(d)}}r.children&&r.children.length>0&&s(r.children)}}return s(t),e}function eo(t){return(t.children||[]).filter(i=>{const e=i.type||"";if(e==="NodeSuperBlockOpenMarker"||e==="NodeSuperBlockLayoutMarker"||e==="NodeSuperBlockCloseMarker"||e==="open-marker"||e==="layout-marker"||e==="close-marker")return!1;const s=(i.markdown||i.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(s)||s==="}}}")})}function Ha(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="h"||i==="nodeheading"||/^h[1-6]$/i.test(t.subType||""))return!0;const e=(t.markdown||t.content||"").trim();return!!/^#{1,6}\s+/.test(e)}function Fs(t){if(!t)return"";const i=t.split(/\r?\n/);if(i.length===0)return"";const e=i[0],s=e.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!s)return t;const n=s[1].length,r=s[2].trim(),l=e.length-s[2].length;if(i.length===1)return r;const o=[r];for(let a=1;a<i.length;a++){const c=i[a];if(!c.trim()){o.push("");continue}const d=c.match(/^(\s*)/),p=d?d[1].length:0;p>=l?o.push(c.slice(l)):p>n?o.push(c.slice(p)):o.push(c)}return o.join(`
`)}function Si(t){if(!t)return[];if(ae(t)&&Bi(t)&&!pi(t)){const s=eo(t),n=[];for(const r of s)n.push(...Si(r));return n}const i=(t.type||"").toLowerCase();if(i==="l"||i==="nodelist"||i==="list"){if(t.children&&t.children.length>0){const l=t.children.filter(Ki);if(l.length>0)return l}const n=(t.markdown||t.content||"").trim().split(/\r?\n/),r=[];for(let l=0;l<n.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(n[l])&&r.push(l);if(r.length>=2){const l=[];for(let o=0;o<r.length;o++){const a=r[o],c=o+1<r.length?r[o+1]:n.length,d=n.slice(a,c).join(`
`);l.push({id:`${t.id}-item-${o+1}`,type:"i",markdown:d,content:d,ial:{...t.ial||{}}})}return l}}return Ki(t)?[t]:[]}function Dr(t){var s;if(!t||!ae(t)||!Bi(t)||pi(t))return null;const i=eo(t);if(i.length===0)return null;if(i.length===1&&ae(i[0])&&Bi(i[0])){const n=Dr(i[0]);return n?{items:n.items,nestedSuperBlocks:[i[0],...n.nestedSuperBlocks]}:null}const e=[];for(const n of i)if(ae(n)){e.push(n);const r=((s=n.children)==null?void 0:s.filter(ae))||[];e.push(...r)}if(i.length===3){const n=Si(i[0]),r=Si(i[1]),l=Si(i[2]);if(n.length===1&&r.length===1&&l.length===1)return{items:[n[0],r[0],l[0]],nestedSuperBlocks:e}}if(i.length===2){const n=Si(i[0]),r=Si(i[1]);if(n.length===2&&r.length===1)return{items:[n[0],n[1],r[0]],nestedSuperBlocks:e};if(n.length===1&&r.length===2)return{items:[n[0],r[0],r[1]],nestedSuperBlocks:e};if(n.length===1&&r.length===1)return{items:[n[0],r[0]],nestedSuperBlocks:e}}return null}function Ua(t){if(!t||!ae(t)||!Bi(t)||pi(t))return null;const i=Dr(t);if(!i)return null;const{items:e,nestedSuperBlocks:s}=i;return e.length!==2&&e.length!==3?null:e.length===2?{superBlockNode:t,nestedSuperBlocks:s,count:2,layout:"two-cols-header",items:e,slots:["left","right"]}:{superBlockNode:t,nestedSuperBlocks:s,count:3,layout:"three-cols-header",items:e,slots:["col-1","col-2","col-3"]}}function Wa(t){if(!t||!ae(t)||!Bi(t)||pi(t))return null;const i=eo(t);if(i.length===0)return null;const e=[];for(const s of i){const n=Si(s);if(n.length===0)return null;e.push(...n)}return e}function Va(t){if(!t||!ae(t)||!Bi(t)||pi(t))return null;const i=Wa(t);return!i||i.length===0||i.length===2||i.length===3?null:{superBlockNode:t,items:i}}function Ka(t,i,e){var d,p,g,u,k;const s=[],n=[],r=(e==null?void 0:e.tracked)||[],l=[];let o={pageTargetId:t,blocks:[]};l.push(o);for(let h=0;h<i.length;h++){const b=i[h];if(Gn(b)){if(l.length===1&&o.blocks.length===0){o.pageTargetId=b.id,o.blocks.push(b);continue}o={pageTargetId:b.id,blocks:[b]},l.push(o)}else o.blocks.push(b)}function a(h){const b=[];for(const v of h)ae(v)&&b.push(v),v.children&&v.children.length>0&&b.push(...a(v.children));return b}function c(h,b,v){const y={blockId:h,attrs:b,previousAttrs:v};s.push(y),e!=null&&e.onTagChange&&e.onTagChange(y)}for(const h of l){const b=h.pageTargetId,v=i.find(_=>_.id===b),y=r.find(_=>_.pageTargetId===b);if(h.blocks.some(_=>{var S,D;return!!(pi(_)||Ns(_)&&(((S=_.ial)==null?void 0:S[ft])==="image-left"||((D=_.ial)==null?void 0:D[ft])==="image-right"))})){if(y){const _=y.headerId;if(_){c(_,{[At]:""});const S=i.find(D=>D.id===_);S!=null&&S.ial&&(S.ial[At]="")}for(const S of y.itemIds){c(S,{[At]:""});const D=i.find(M=>M.id===S);D!=null&&D.ial&&(D.ial[At]="")}}continue}let A=null,x=-1;for(let _=0;_<h.blocks.length;_++){const S=h.blocks[_],D=ae(S)?[S,...a(S.children||[])]:S.children?a(S.children):[];for(const M of D){const P=Ua(M);if(P){A=P,x=_;break}}if(A)break}if(A){const{superBlockNode:_,layout:S,items:D,slots:M}=A,J=h.blocks.slice(0,x).find(F=>Ha(F)),T=J==null?void 0:J.id,L=((d=v==null?void 0:v.ial)==null?void 0:d[ft])||"";if(L!==S&&(c(b,{[ft]:S},{[ft]:L}),v&&(v.ial||(v.ial={}),v.ial[ft]=S)),J){const F=((p=J.ial)==null?void 0:p[At])||"";F!=="header"&&(c(J.id,{[At]:"header"},{[At]:F}),J.ial||(J.ial={}),J.ial[At]="header")}if(y!=null&&y.headerId&&y.headerId!==T){c(y.headerId,{[At]:""});const F=i.find(Q=>Q.id===y.headerId);F&&(F.ial||(F.ial={}),F.ial[At]="")}const w=[];for(let F=0;F<D.length;F++){const Q=D[F],V=M[F];w.push(Q.id);const it=((g=Q.ial)==null?void 0:g[At])||"";if(it!==V&&(c(Q.id,{[At]:V},{[At]:it}),Q.ial||(Q.ial={}),Q.ial[At]=V),Q.children&&Q.children.length>0)for(const U of Q.children)U.ial||(U.ial={}),U.ial[At]!==V&&(U.ial[At]=V)}if(y!=null&&y.itemIds){for(const F of y.itemIds)if(!w.includes(F)){c(F,{[At]:""});const Q=i.find(V=>V.id===F);Q&&(Q.ial||(Q.ial={}),Q.ial[At]="")}}n.push({superBlockId:_.id,nestedSuperBlockIds:(u=A.nestedSuperBlocks)==null?void 0:u.map(F=>F.id),pageTargetId:b,headerId:T,itemIds:w,layout:S})}else{let _=!1;const S=[];for(const P of h.blocks){const J=ae(P)?[P,...a(P.children||[])]:P.children?a(P.children):[];for(const T of J){const L=Va(T);if(L){_=!0;for(const w of L.items)S.push(w.id)}}}const D=((k=v==null?void 0:v.ial)==null?void 0:k[ft])||"";if(y||_&&(D==="two-cols-header"||D==="three-cols-header")){c(b,{[ft]:""},{[ft]:D}),v&&(v.ial||(v.ial={}),v.ial[ft]="");const P=y==null?void 0:y.headerId;if(P){c(P,{[At]:""});const T=i.find(L=>L.id===P);T&&(T.ial||(T.ial={}),T.ial[At]="")}const J=new Set([...(y==null?void 0:y.itemIds)||[],...S]);for(const T of J){c(T,{[At]:""});const L=i.find(w=>w.id===T);L&&(L.ial||(L.ial={}),L.ial[At]="")}}}}return{changes:s,newTracked:n}}function yi(t,i,e){let s="",n=0;const r=/<div\b([^>]*)>/gi;for(;n<t.length;){r.lastIndex=n;let l,o=!1,a=-1,c=0;for(;(l=r.exec(t))!==null;){const v=l[1].match(/\bclass=["']([^"']*)["']/i);if(v){const y=v[1];if(typeof i=="string"?y.split(/\s+/).includes(i):i.test(y)){o=!0,a=l.index,c=l[0].length;break}}}if(!o){s+=t.slice(n);break}s+=t.slice(n,a);const d=a+c;let p=1,g=-1,u=-1;const k=/<\/?div\b[^>]*>/gi;k.lastIndex=d;let h;for(;(h=k.exec(t))!==null;)if(h[0].startsWith("</")){if(p--,p===0){g=h.index,u=h.index+h[0].length;break}}else p++;if(g!==-1&&u!==-1){const b=t.slice(d,g);s+=e(b),n=u}else s+=t.slice(a,d),n=d}return s}function qa(t){const i=[];let e="",s=0;const n=/<div\b([^>]*)>/gi;for(;s<t.length;){n.lastIndex=s;let r,l=!1,o=-1,a=0;for(;(r=n.exec(t))!==null;){const h=r[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(h)){l=!0,o=r.index,a=r[0].length;break}}if(!l){e+=t.slice(s);break}e+=t.slice(s,o);const c=o+a;let d=1,p=-1,g=-1;const u=/<\/?div\b[^>]*>/gi;u.lastIndex=c;let k;for(;(k=u.exec(t))!==null;)if(k[0].startsWith("</")){if(d--,d===0){p=k.index,g=k.index+k[0].length;break}}else d++;if(p!==-1&&g!==-1){const h=t.slice(o,g),b=`__VUE_DIV_TOKEN_${i.length}__`;i.push(h),e+=b,s=g}else e+=t.slice(o,c),s=c}return{text:e,tokens:i}}function Ga(t){const i=[];let e=t.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,o=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(o),a});e=e.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,o=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(o),a});const s=[];e=e.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,o=>{const a=`__SCRIPT_TOKEN_${s.length}__`;return s.push(o),a});const{text:n,tokens:r}=qa(e);e=n;const l=[];e=e.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),e=e.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),e=e.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),e=e.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),e=e.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),e=e.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),e=e.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),e=e.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(o,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),e=e.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(o,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),e=e.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(o,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),e=e.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(o,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=yi(e,"diff-grid",o=>{const a=Array.from(o.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),p=c[3].trim();return`**${d}:**
\`\`\`yaml
${p}
\`\`\``}).join(`

`)+`
`:o}),e=yi(e,"before-after",o=>{const a=o.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=o.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:o}),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(o,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),e=yi(e,"timeline",o=>{const a=Array.from(o.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let p="-";return d.includes("warn")?p="- ⚠️":d.includes("bad")?p="- ❌":d.includes("ok")&&(p="- ✅"),`${p} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:o}),e=yi(e,"pipeline",o=>{const a=Array.from(o.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const g=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${g}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:o}),e=yi(e,"check-grid",o=>{const a=Array.from(o.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:o}),e=yi(e,"manifesto",o=>{const a=Array.from(o.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:o}),e=yi(e,"split-note",o=>{const a=Array.from(o.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:o}),e=e.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(o,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),e=e.replace(/<pre>([\s\S]*?)<\/pre>/gi,(o,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=e.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),e=e.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),e=e.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),e=e.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),e=e.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),e=e.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),e=e.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),e=e.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),e=e.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(o,a,c)=>/@|v-|:|class=/i.test(a)?o:`
${c.trim()}

`),e=e.replace(/<br\s*\/?>/gi,`
`),e=e.replace(/<hr\s*\/?>/gi,`
---
`),e=e.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),e=e.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),e=e.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),e=e.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(o,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((p,g)=>Math.max(p,g.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),e=e.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),e=e.replace(/\*{4}/g,"** **"),e=e.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),e=e.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),e=e.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(o,a,c,d,p)=>{const g=p.trim();return g.includes("<")||g.includes(`
`)?o:`[${g}](${c})`}),e=e.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(o,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),e=e.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(o,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),e=e.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(o,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),e=e.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),e=e.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),e=e.replace(/<\/?span\b[^>]*>/gi,"");for(let o=0;o<l.length;o++)e=e.replace(`__VUE_COMP_TOKEN_${o}__`,l[o]);for(let o=0;o<r.length;o++)e=e.replace(`__VUE_DIV_TOKEN_${o}__`,r[o]);for(let o=0;o<s.length;o++)e=e.replace(`__SCRIPT_TOKEN_${o}__`,s[o]);for(let o=0;o<i.length;o++)e=e.replace(`__CODE_TOKEN_${o}__`,i[o]);return e=e.replace(/\n{3,}/g,`

`).trim(),e}function Lr(t){if(!t||typeof t!="string")return"";const i=[];let e=t.replace(/`([^`]+)`/g,s=>(i.push(s),`%%INLINE_CODE_${i.length-1}%%`));return e=e.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),e=e.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),e=e.replace(/\{:[^}]*\}/g,""),e=e.replace(/%%INLINE_CODE_(\d+)%%/g,(s,n)=>i[parseInt(n,10)]||""),e}function Za(t){const i=Object.entries(t).filter(([s,n])=>n!=null&&n!=="");return i.length===0?"":`---
${i.map(([s,n])=>typeof n=="string"?n.includes(":")||n.includes(`
`)||n.includes("#")?`${s}: "${n.replace(/"/g,'\\"')}"`:`${s}: ${n}`:`${s}: ${JSON.stringify(n)}`).join(`
`)}
---`}function Ya(t,i){if(!i||!t.startsWith("```"))return t;const e=t.indexOf(`
`);if(e===-1)return t;const s=t.slice(0,e).trim(),n=t.slice(e);return s.includes("{")?t:`${s} {${i}}${n}`}function Ja(t,i){if(i==null)return t;const e=i.trim();return e===""||e==="+1"?`<v-click>

${t}

</v-click>`:e==="hide"?`<v-click hide>

${t}

</v-click>`:`<v-click at="${e}">

${t}

</v-click>`}function Xa(t){if(!t||!t.preset)return null;const i=t.preset.toLowerCase().trim();if(!i||i==="none")return null;let e={opacity:0},s={opacity:1};switch(i){case"slide-up":e={y:40,opacity:0},s={y:0,opacity:1};break;case"slide-down":e={y:-40,opacity:0},s={y:0,opacity:1};break;case"slide-left":e={x:40,opacity:0},s={x:0,opacity:1};break;case"slide-right":e={x:-40,opacity:0},s={x:0,opacity:1};break;case"zoom-in":case"pop":e={scale:.8,opacity:0},s={scale:1,opacity:1};break;case"bounce":e={y:40,opacity:0},s={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:e={opacity:0},s={opacity:1};break}t.initial&&typeof t.initial=="object"&&(e={...e,...t.initial}),t.enter&&typeof t.enter=="object"&&(s={...s,...t.enter});const n={...s.transition||{}};return typeof t.duration=="number"&&t.duration>0&&(n.duration=t.duration),typeof t.delay=="number"&&t.delay>0&&(n.delay=t.delay),Object.keys(n).length>0&&(s.transition=n),{initial:e,enter:s}}function Fo(t,i,e,s){const n=i!=null&&i.trim()!=="",r=Xa(e),l=s==null?void 0:s.trim(),o=l!==void 0&&l!=="",a=o?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!n&&!r)return o?`<div${a}>

${t}

</div>`:t;if(n&&!r){if(o){const k=i.trim();let h="v-click";return k==="hide"?h="v-click.hide":k!==""&&k!=="+1"&&(h=`v-click="${k}"`),`<div ${h}${a}>

${t}

</div>`}return Ja(t,i)}const c=JSON.stringify(r.initial).replace(/"/g,"'"),d=JSON.stringify(r.enter).replace(/"/g,"'"),p=`v-motion :initial="${c}" :enter="${d}"`;if(!n)return`<div ${p}${a}>

${t}

</div>`;const g=i.trim();let u="v-click";return g==="hide"?u="v-click.hide":g!==""&&g!=="+1"&&(u=`v-click="${g}"`),`<div ${u} ${p}${a}>

${t}

</div>`}function Or(t){if(!t)return"";let i=t.trim();i=i.replace(/\{:[^}]*\}/g,"").trim(),i=i.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),i=i.replace(/\r?\n?:::\s*$/g,"");let n=i.split(/\r?\n/).map(r=>r.trim().replace(/^>\s*/,"")).join(`
`).trim();return n=n.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),n=n.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),n=n.replace(/^[-*+]\s+/,""),n=n.replace(/^\d+\.\s+/,""),n.trim()}function Qa(t){var s;if(t.subType&&/^h([1-6])$/i.test(t.subType))return parseInt(t.subType.slice(1),10);const e=(t.markdown||t.content||"").trim().match(/^(#{1,6})\s+/);return e?e[1].length:t.type==="h"?(s=t.ial)!=null&&s.subType&&/^h([1-6])$/i.test(t.ial.subType)?parseInt(t.ial.subType.slice(1),10):1:null}function Pr(t){if(!t||t.length===0)return{col1:[],col2:[],col3:[]};if(t.length===1&&t[0].children&&t[0].children.length>=2){const l=t[0].children;if(l.length>=3){const o=Math.ceil(l.length/3),a=Math.ceil((l.length-o)/2);return{col1:l.slice(0,o),col2:l.slice(o,o+a),col3:l.slice(o+a)}}else return{col1:[l[0]],col2:[l[1]],col3:[]}}const i=l=>{const o=l.slot||"";return o==="col-1"||o==="left"?1:o==="col-2"||o==="center"?2:o==="col-3"||o==="right"?3:null},e=t.map(i);if(e.some(l=>l!==null)){const l=e.includes(2),o=e.includes(3);if(l||o){const d=[],p=[],g=[];let u=1;for(const k of t){const h=i(k);h!==null&&(u=h),u===1?d.push(k):u===2?p.push(k):g.push(k)}return{col1:d,col2:p,col3:g}}const a=t.filter(d=>i(d)===1),c=t.filter(d=>i(d)===null);if(c.length>=2){const d=Math.ceil(c.length/2);return{col1:a,col2:c.slice(0,d),col3:c.slice(d)}}else return c.length===1?{col1:a,col2:c,col3:[]}:{col1:a,col2:[],col3:[]}}const n=l=>{if(l.type==="h"||l.subType&&/^h[1-6]$/i.test(l.subType))return!0;const o=(l.rawMarkdown||l.content||"").trim();return/^#{1,6}\s+/.test(o)},r=t.map((l,o)=>n(l)?o:-1).filter(l=>l!==-1);if(r.length>=3)return{col1:t.slice(0,r[1]),col2:t.slice(r[1],r[2]),col3:t.slice(r[2])};if(t.length>=3){const l=Math.ceil(t.length/3),o=Math.ceil((t.length-l)/2);return{col1:t.slice(0,l),col2:t.slice(l,l+o),col3:t.slice(l+o)}}if(t.length===2)return{col1:[t[0]],col2:[t[1]],col3:[]};if(t.length===1){const l=t[0],o=(l.rawMarkdown||l.content||"").trim(),a=o.split(/\r?\n/),c=[];for(let g=0;g<a.length;g++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(a[g])&&c.push(g);if(c.length>=3){const g=Math.ceil(c.length/3),u=Math.ceil((c.length-g)/2),k=a.slice(c[0],c[g]).join(`
`),h=a.slice(c[g],c[g+u]).join(`
`),b=a.slice(c[g+u]).join(`
`);return{col1:[{...l,rawMarkdown:k,content:k}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:h,content:h}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:b,content:b}]}}const d=o.match(/<li[\s\S]*?<\/li>/gi);if(d&&d.length>=3){const g=Math.ceil(d.length/3),u=Math.ceil((d.length-g)/2),k=`<ul>
${d.slice(0,g).join(`
`)}
</ul>`,h=`<ul>
${d.slice(g,g+u).join(`
`)}
</ul>`,b=`<ul>
${d.slice(g+u).join(`
`)}
</ul>`;return{col1:[{...l,rawMarkdown:k,content:k}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:h,content:h}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:b,content:b}]}}const p=o.split(/\r?\n\s*\r?\n/).filter(g=>g.trim()!=="");if(p.length>=3){const g=Math.ceil(p.length/3),u=Math.ceil((p.length-g)/2);return{col1:[{...l,rawMarkdown:p.slice(0,g).join(`

`),content:p.slice(0,g).join(`

`)}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:p.slice(g,g+u).join(`

`),content:p.slice(g,g+u).join(`

`)}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:p.slice(g+u).join(`

`),content:p.slice(g+u).join(`

`)}]}}}return{col1:t,col2:[],col3:[]}}function jo(t,i,e,s){var d;const n=Ea(i),r=[],l=zo(i);let o={pageIndex:1,startBlockId:t,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[t]};o.frontmatter.background&&(o.frontmatter.background=_e(o.frontmatter.background,s)),o.frontmatter.image&&(o.frontmatter.image=_e(o.frontmatter.image,s)),r.push(o);let a=[];for(const p of e){if(Gn(p)){a=[];const u=zo(p.ial);if(r.length===1&&o.blocks.length===0){o.startBlockId=p.id,o.allBlockIds||(o.allBlockIds=[]),o.allBlockIds.includes(p.id)||o.allBlockIds.push(p.id),u.frontmatter.layout&&(o.frontmatter.layout=u.frontmatter.layout),Object.assign(o.frontmatter,u.frontmatter),!u.frontmatter.image&&l.frontmatter.image&&(o.frontmatter.image=l.frontmatter.image),!u.frontmatter.background&&l.frontmatter.background&&(o.frontmatter.background=l.frontmatter.background),o.frontmatter.background&&(o.frontmatter.background=_e(o.frontmatter.background,s)),o.frontmatter.image&&(o.frontmatter.image=_e(o.frontmatter.image,s));continue}o={pageIndex:r.length+1,startBlockId:p.id,frontmatter:{layout:u.frontmatter.layout||"default",...u.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[p.id]},o.frontmatter.background&&(o.frontmatter.background=_e(o.frontmatter.background,s)),o.frontmatter.image&&(o.frontmatter.image=_e(o.frontmatter.image,s)),r.push(o);continue}const g=u=>{if(o.allBlockIds||(o.allBlockIds=[]),u.id&&!o.allBlockIds.includes(u.id)&&o.allBlockIds.push(u.id),u.children&&u.children.length>0){const L=w=>{for(const F of w)F.id&&!o.allBlockIds.includes(F.id)&&o.allBlockIds.push(F.id),F.children&&F.children.length>0&&L(F.children)};L(u.children)}let k=Pa(u),h=u.ial?{...u.ial}:{};const b=k.match(/\{:\s*([^}]+)\s*\}\s*$/);b&&(h={...Ra(b[0]),...h},k=k.slice(0,b.index).trim()),u.type!=="c"&&!k.startsWith("```")&&(k=Lr(k));let v=k.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(v)||v==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(v)&&/\r?\n\}\}\}$/.test(v)&&(k=v.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),v=k.trim());const y=Ma(h);if(k=Fa(k,s),k=Oa(k,s==null?void 0:s.refContentMap),u.children&&u.children.length>0){const L=w=>{for(const F of w){if(F.ial)for(const[Q,V]of Object.entries(F.ial))Q.startsWith("custom-slidev-")&&!h[Q]&&(h[Q]=V);F.children&&F.children.length>0&&L(F.children)}};L(u.children)}const $=u.type==="video"||u.type==="NodeVideo"||/<video\b/i.test(k);if($){const L=h["custom-slidev-autoplay"]==="true",w=h["custom-slidev-loop"]==="true",F=h["custom-slidev-muted"]==="true"||L,Q=h["custom-slidev-controls"]==="false";k=k.replace(/<video\b([^>]*)>/gi,(V,it)=>{let U=it;return Q?U=U.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(U)||(U+=" controls"),L&&!/autoplay/i.test(U)?U+=" autoplay playsinline":!L&&h["custom-slidev-autoplay"]==="false"&&(U=U.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),w&&!/loop/i.test(U)?U+=" loop":!w&&h["custom-slidev-loop"]==="false"&&(U=U.replace(/\bloop\b/gi,"").trim()),F&&!/muted/i.test(U)?U+=" muted":!F&&h["custom-slidev-muted"]==="false"&&(U=U.replace(/\bmuted\b/gi,"").trim()),`<video ${U.trim()}>`})}if(y.isBackground){const L=fi(k,u.content);if(L){o.frontmatter.background=_e(L,s);return}}const A=pi(u);if(A){o.frontmatter.layout=A.layout,o.frontmatter.image=_e(A.imageUrl,s);for(const L of A.contentNodes)g(L);return}if(y.imageLayout==="image-left"||y.imageLayout==="image-right"){const L=fi(k,u.content);if(L){o.frontmatter.layout=y.imageLayout,o.frontmatter.image=_e(L,s);return}}if(ae(u)&&u.children&&u.children.length>0){for(const L of u.children)g(L);return}if((u.type==="l"||u.type==="NodeList"||u.type==="list")&&u.children&&u.children.length>0&&(u.children.some(L=>{var w;return(w=L.ial)==null?void 0:w[At]})||y.slot)){for(const L of u.children)y.slot&&(!L.ial||!L.ial[At])&&(L.ial||(L.ial={}),L.ial[At]=y.slot),g(L);return}if(y.isNote){const L=Or(k);L&&(o.notes?o.notes+=`

`+L:o.notes=L),o.noteBlocks||(o.noteBlocks=[]),o.noteBlocks.push({id:u.id,type:u.type,content:L||u.content||"",rawMarkdown:k,isNote:!0,attributes:u.ial});return}y.shikiLines&&(k=Ya(k,y.shikiLines)),v=k.trim();const x=(u.content||"").trim();if(v==="::right::"||x==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(v)||v.startsWith("::right::")){o.blocks.push({id:u.id,type:u.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:u.ial});return}const S=Qa(u);let D=y.slot,M=y.clicks,P=y.motion,J={...u.ial||{}};if(S!==null){for(;a.length>0&&a[a.length-1].level>=S;)a.pop();const L=a.length>0?a[a.length-1]:void 0;!D&&(L!=null&&L.slot)&&(D=L.slot),!M&&(L!=null&&L.clicks)&&(M=L.clicks),!P&&(L!=null&&L.motion)&&(P=L.motion);const w={...(L==null?void 0:L.customAttrs)||{}};if(u.ial)for(const[F,Q]of Object.entries(u.ial))F.startsWith("custom-slidev-")&&!F.startsWith("custom-slidev-slide")&&(w[F]=Q);a.push({level:S,slot:D,clicks:M,motion:P,customAttrs:w})}else{const L=a.length>0?a[a.length-1]:void 0;L&&(!D&&L.slot&&L.slot!=="header"&&(D=L.slot),!M&&L.clicks&&(M=L.clicks),!P&&L.motion&&(P=L.motion),L.customAttrs&&(J={...L.customAttrs,...J}))}!D&&o.blocks.some(L=>L.slot==="slot-divider-right")&&(D="right"),D&&(J[At]=D),M&&!J[Se]&&(J[Se]=M),P&&!J[je]&&(J[je]=JSON.stringify(P)),($||h["custom-slidev-autoplay"]||h["custom-slidev-muted"])&&(h["custom-slidev-autoplay"]&&(J["custom-slidev-autoplay"]=h["custom-slidev-autoplay"],h["custom-slidev-autoplay"]==="true"&&!h["custom-slidev-muted"]&&(J["custom-slidev-muted"]="true")),h["custom-slidev-loop"]&&(J["custom-slidev-loop"]=h["custom-slidev-loop"]),h["custom-slidev-muted"]&&(J["custom-slidev-muted"]=h["custom-slidev-muted"]),h["custom-slidev-controls"]&&(J["custom-slidev-controls"]=h["custom-slidev-controls"]));const T={id:u.id,type:u.type,content:u.content||"",rawMarkdown:k,clicks:M,motion:P,shikiLines:y.shikiLines,slot:D,attributes:J};o.blocks.push(T)};g(p)}for(let p=0;p<r.length;p++){const g=r[p],u=[],k={...g.frontmatter};p===0&&(k.theme=n.theme,k.aspectRatio=n.aspectRatio,k.highlighter=n.highlighter,k.transition=g.frontmatter.transition||n.defaultTransition);const h=Za(k);h&&u.push(h);const b=g.blocks.filter(x=>x.slot!=="slot-divider-right"),v=x=>x.filter(_=>!!(_.rawMarkdown||_.content||"").trim()).map(_=>{var S;return Fo(_.rawMarkdown,_.clicks,_.motion,(S=_.attributes)==null?void 0:S.style)}).join(`

`),y=x=>{const _=x.filter(P=>!!(P.rawMarkdown||P.content||"").trim());if(_.length===0)return;const S=_[0],D=(S.rawMarkdown||S.content||"").trim();(Ki(S)||/^(?:[-*+]|\d+\.)\s+/.test(D))&&(S.rawMarkdown=Fs(S.rawMarkdown||S.content||""),S.content=S.rawMarkdown)},$=x=>x.length===0?"":(y(x),v(x)),A=g.frontmatter.layout||"default";if(A==="two-cols-header"){let x=[];const _=b.filter(L=>L.slot==="header");if(_.length>0)x=_;else if(b.length>0){const L=b.find(w=>w.type==="h"&&(!w.slot||w.slot==="default"));L&&(x=[L])}const S=b.filter(L=>!x.includes(L)),D=S.filter(L=>L.slot==="right"||L.slot==="col-2"),M=S.filter(L=>!D.includes(L));y(M),y(D);const P=v(x),J=$(M),T=$(D);P&&u.push(P),J&&u.push(`::left::

${J}`),T&&u.push(`::right::

${T}`)}else if(A==="three-cols-header"){let x=[];const _=b.filter(Q=>Q.slot==="header");if(_.length>0)x=_;else if(b.length>0){const Q=b.find(V=>V.type==="h"&&(!V.slot||V.slot==="default"));Q&&(x=[Q])}const S=b.filter(Q=>!x.includes(Q)),D=Pr(S),M=D.col1,P=D.col2,J=D.col3;for(const Q of M)Q.slot||(Q.slot="col-1");for(const Q of P)Q.slot||(Q.slot="col-2");for(const Q of J)Q.slot||(Q.slot="col-3");if(y(M),y(P),y(J),S.length===1&&(P.length>0||J.length>0)){const Q=g.blocks.findIndex(V=>V.id===S[0].id);Q!==-1&&g.blocks.splice(Q,1,...M,...P,...J)}const T=v(x),L=$(M),w=$(P),F=$(J);T&&u.push(T),L&&u.push(`::col-1::

${L}`),w&&u.push(`::col-2::

${w}`),F&&u.push(`::col-3::

${F}`)}else if(A==="two-cols"){const x=b.filter(M=>M.slot==="left"),_=b.filter(M=>M.slot==="right");y(x),y(_);const S=v(x.length>0?x:b.filter(M=>M.slot!=="right")),D=v(_);u.push(S),D&&u.push(`::right::

${D}`)}else for(const x of b)u.push(Fo(x.rawMarkdown,x.clicks,x.motion,(d=x.attributes)==null?void 0:d.style));g.notes&&u.push(`<!--
${g.notes}
-->`),g.rawMarkdown=u.join(`

`).trim()}const c=r.map(p=>p.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:t,config:n,slides:r,fullMarkdown:c}}const js=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function tc(t){var n,r,l,o,a,c,d,p,g,u,k,h;if(!t||typeof t!="object")return"";const i=[],e=[];if(Array.isArray(t.styles))for(const b of t.styles){if(!b||!b.id)continue;const v=`--b3-inline-style-${b.id}`;(n=b.light)!=null&&n.color&&i.push(`  ${v}-color: ${b.light.color};`),(r=b.light)!=null&&r.backgroundColor&&i.push(`  ${v}-background-color: ${b.light.backgroundColor};`),(l=b.dark)!=null&&l.color&&e.push(`  ${v}-color: ${b.dark.color};`),(o=b.dark)!=null&&o.backgroundColor&&e.push(`  ${v}-background-color: ${b.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.colors))for(const b of t.builtin.colors){if(!b||typeof b.index!="number")continue;const v=b.index;(a=b.light)!=null&&a.color&&i.push(`  --b3-font-color${v}: ${b.light.color};`),(c=b.light)!=null&&c.backgroundColor&&i.push(`  --b3-font-background${v}: ${b.light.backgroundColor};`),(d=b.dark)!=null&&d.color&&e.push(`  --b3-font-color${v}: ${b.dark.color};`),(p=b.dark)!=null&&p.backgroundColor&&e.push(`  --b3-font-background${v}: ${b.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.styles))for(const b of t.builtin.styles){if(!b||!b.id)continue;const v=b.id;(g=b.light)!=null&&g.color&&i.push(`  --b3-card-${v}-color: ${b.light.color};`),(u=b.light)!=null&&u.backgroundColor&&i.push(`  --b3-card-${v}-background: ${b.light.backgroundColor};`),(k=b.dark)!=null&&k.color&&e.push(`  --b3-card-${v}-color: ${b.dark.color};`),(h=b.dark)!=null&&h.backgroundColor&&e.push(`  --b3-card-${v}-background: ${b.dark.backgroundColor};`)}if(i.length===0&&e.length===0)return"";const s=[];return i.length>0&&s.push(`:root, html:not(.dark), [data-theme="light"] {
${i.join(`
`)}
}`),e.length>0&&s.push(`html.dark, [data-theme="dark"], .dark {
${e.join(`
`)}
}`),s.join(`

`)}function un(t){const i=tc(t);return i?`${js}

/* Custom Workspace Inline Styles */
${i}`:js}function ws(t){const i={};if(!t||typeof t!="string")return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),s=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let n;for(;(n=s.exec(e))!==null;){const r=n[1],l=n[2]??n[3]??n[4]??"";i[r]=l}return i}const ec={getBlockAttrs:Ge,getChildBlocks:qn,setBlockAttrs:Lt,sql:vn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:Ta};class ic{constructor(i){wt(this,"deps");wt(this,"attrOverrides",new Map);wt(this,"trackedListSuperBlocks",new Map);this.deps={...ec,...i||{}}}setBlockAttrOverride(i,e){if(!i||!e)return;const n={...this.attrOverrides.get(i)||{}};for(const[r,l]of Object.entries(e))l===""||l===null||l===void 0?delete n[r]:n[r]=String(l);Object.keys(n).length===0?this.attrOverrides.delete(i):this.attrOverrides.set(i,n)}getBlockAttrOverride(i){return this.attrOverrides.get(i)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(i){return this.trackedListSuperBlocks.get(i)||[]}clearBlockAttrOverride(i,e){if(!i)return;if(!e){this.attrOverrides.delete(i);return}const s=this.attrOverrides.get(i);s&&(delete s[e],Object.keys(s).length===0&&this.attrOverrides.delete(i))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(i){try{const e=await this.deps.getBlockAttrs(i).catch(()=>({}))||{},s=this.attrOverrides.get(i);s&&Object.assign(e,s);let n=await this.deps.getChildBlocks(i).catch(()=>[]);const r=`SELECT id, ial FROM blocks WHERE root_id = '${i}' LIMIT 99999`,l=await this.deps.sql(r).catch(()=>[])||[],o=new Map;if(Array.isArray(l))for(const $ of l)$.id&&$.ial&&o.set($.id,ws($.ial));const a=`SELECT block_id, name, value FROM attributes WHERE root_id = '${i}' AND type = 'b' LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[];if(Array.isArray(c)){for(const $ of c)if($.block_id&&$.name){let A=o.get($.block_id);A||(A={},o.set($.block_id,A)),A[$.name]=$.value||""}}if(!n||n.length===0){const $=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE root_id = '${i}' AND id != '${i}' ORDER BY created ASC LIMIT 99999`;n=await this.deps.sql($).catch(()=>[])||[]}const d=(n||[]).map($=>{const A=o.get($.id)||($.ial?ws($.ial):{}),x=this.attrOverrides.get($.id);return x&&Object.assign(A,x),{id:$.id,parent_id:$.parent_id,root_id:$.root_id||i,type:$.type,subType:$.subType,content:$.content||"",markdown:$.markdown||"",ial:A,children:$.children}}),p=async($,A=0)=>{if(!(!$||$.length===0||A>8))for(const x of $){if((ae(x)||x.type==="l"||x.type==="NodeList"||x.type==="i"||x.type==="NodeListItem"||x.type==="b"||x.type==="NodeBlockquote")&&(!x.children||x.children.length===0)){let S=await this.deps.getChildBlocks(x.id).catch(()=>[]);if(!S||S.length===0){const D=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE parent_id = '${x.id}' ORDER BY sort ASC, created ASC`;S=await this.deps.sql(D).catch(()=>[])||[]}Array.isArray(S)&&S.length>0&&(x.children=S.map(D=>{const M=o.get(D.id)||(D.ial?ws(D.ial):{}),P=this.attrOverrides.get(D.id);return P&&Object.assign(M,P),{id:D.id,parent_id:D.parent_id||x.id,root_id:D.root_id||i,type:D.type,subType:D.subType,content:D.content||"",markdown:D.markdown||"",ial:M}}))}x.children&&x.children.length>0&&await p(x.children,A+1)}};await p(d);const g=$=>{var A,x;for(const _ of $)if(_.children&&_.children.length>0){g(_.children);for(const S of _.children)if(S.ial)for(const[D,M]of Object.entries(S.ial))D.startsWith("custom-slidev-")&&!((A=_.ial)!=null&&A[D])&&(_.ial||(_.ial={}),_.ial[D]=M);if(_.ial){for(const[S,D]of Object.entries(_.ial))if(S.startsWith("custom-slidev-"))for(const M of _.children)(M.type==="video"||M.type==="NodeVideo"||/<video\b/i.test(M.markdown||M.content||""))&&!((x=M.ial)!=null&&x[S])&&(M.ial||(M.ial={}),M.ial[S]=D)}}};g(d),ja(d,$=>{this.setBlockAttrOverride($.blockId,{[ft]:$.layout}),(this.deps.setBlockAttrs||Lt)($.blockId,{[ft]:$.layout}).catch(x=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",x)})});const u=this.trackedListSuperBlocks.get(i)||[],k=Ka(i,d,{tracked:u,onTagChange:$=>{this.setBlockAttrOverride($.blockId,$.attrs),$.blockId===i&&Object.assign(e,$.attrs);const A=_=>{for(const S of _)S.id===$.blockId&&(S.ial||(S.ial={}),Object.assign(S.ial,$.attrs)),S.children&&S.children.length>0&&A(S.children)};A(d),(this.deps.setBlockAttrs||Lt)($.blockId,$.attrs).catch(_=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",_)})}});this.trackedListSuperBlocks.set(i,k.newTracked);const h=new Set;for(const $ of d){const A=$.markdown||$.content||"";if(A.includes("((")){const x=La(A);for(const _ of x)h.add(_.blockId)}}const b={};if(h.size>0){const $=Array.from(h).map(x=>`'${x}'`).join(","),A=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${$})`).catch(()=>[])||[];if(Array.isArray(A))for(const x of A)x.id&&(b[x.id]=x.markdown||x.content||"")}const v=this.deps.getBaseUrl?this.deps.getBaseUrl():"",y=jo(i,e,d,{baseUrl:v,refContentMap:b});try{const $=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;y.customThemeCss=un($)}catch{y.customThemeCss=un(null)}return y}catch(e){console.error("[DocumentCompilerService] Failed to compile document:",e);const s=jo(i,{},[],{});return s.customThemeCss=un(null),s}}}const Nt=new ic;class io{constructor(i){wt(this,"devServerUrl","http://localhost:3030");wt(this,"isConnected",!1);wt(this,"lastSyncTime",null);i&&(this.devServerUrl=i)}getUrl(){return this.devServerUrl}setUrl(i){this.devServerUrl=i.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(i=1500){try{const e=new AbortController,s=setTimeout(()=>e.abort(),i),n=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:e.signal}).catch(()=>null);return clearTimeout(s),this.isConnected=!!n,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(i){const e=i.config,s=["---",`theme: ${e.theme||"default"}`,`aspectRatio: "${e.aspectRatio||"16/9"}"`,`highlighter: ${e.highlighter||"shiki"}`,`transition: ${e.defaultTransition||"slide-left"}`];e.colorSchema&&e.colorSchema!=="auto"&&s.push(`colorSchema: ${e.colorSchema}`),s.push("drawings:","  persist: false","---","");const n=s.join(`
`),r=i.slides.map((l,o)=>{const a=l.frontmatter||{},c=[],d=o===0;a.layout&&a.layout!=="default"&&c.push(`layout: ${a.layout}`),a.transition&&c.push(`transition: ${a.transition}`),a.background&&c.push(`background: ${a.background}`),a.class&&c.push(`class: "${a.class}"`);let p="";c.length>0?p=d?"":`---
${c.join(`
`)}
---

`:d||(p=`---

`);let g="";if(a.layout==="two-cols"){const k=l.blocks.filter(y=>y.slot!=="right"),h=l.blocks.filter(y=>y.slot==="right"),b=k.map(y=>y.rawMarkdown||y.content||"").join(`

`),v=h.map(y=>y.rawMarkdown||y.content||"").join(`

`);g=`${b}

::right::

${v}`}else g=l.blocks.map(k=>k.rawMarkdown||k.content||"").join(`

`);let u="";return l.notes&&l.notes.trim()&&(u=`

<!--
${l.notes.trim()}
-->`),`${p}${g}${u}`}).join(`

`);return`${n}${r}
`}async syncToWorkspaceFile(i,e="/data/storage/petal/siyuan-slidev/slides.md",s){const n=this.buildStandardSlidevMarkdown(i);if(this.lastSyncTime=Date.now(),s)try{const r=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8");return await s(e,!1,r),{success:!0,path:e}}catch(r){return{success:!1,path:e,error:String(r)}}return{success:!0,path:e}}downloadSlidesMd(i,e="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const s=this.buildStandardSlidevMarkdown(i),n=new Blob([s],{type:"text/markdown;charset=utf-8"}),r=URL.createObjectURL(n),l=document.createElement("a");return l.href=r,l.download=e,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(r),!0}}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function no(t){const i=Object.create(null);for(const e of t.split(","))i[e]=1;return e=>e in i}const jt={},Fi=[],We=()=>{},Rr=()=>!1,ss=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&(t.charCodeAt(2)>122||t.charCodeAt(2)<97),os=t=>t.startsWith("onUpdate:"),se=Object.assign,so=(t,i)=>{const e=t.indexOf(i);e>-1&&t.splice(e,1)},nc=Object.prototype.hasOwnProperty,Dt=(t,i)=>nc.call(t,i),Ct=Array.isArray,ji=t=>Cn(t)==="[object Map]",Ji=t=>Cn(t)==="[object Set]",Ho=t=>Cn(t)==="[object Date]",It=t=>typeof t=="function",Yt=t=>typeof t=="string",Be=t=>typeof t=="symbol",zt=t=>t!==null&&typeof t=="object",zr=t=>(zt(t)||It(t))&&It(t.then)&&It(t.catch),Nr=Object.prototype.toString,Cn=t=>Nr.call(t),sc=t=>Cn(t).slice(8,-1),Fr=t=>Cn(t)==="[object Object]",oo=t=>Yt(t)&&t!=="NaN"&&t[0]!=="-"&&""+parseInt(t,10)===t,fn=no(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),rs=t=>{const i=Object.create(null);return(e=>i[e]||(i[e]=t(e)))},oc=/-\w/g,pe=rs(t=>t.replace(oc,i=>i.slice(1).toUpperCase())),rc=/\B([A-Z])/g,hi=rs(t=>t.replace(rc,"-$1").toLowerCase()),ls=rs(t=>t.charAt(0).toUpperCase()+t.slice(1)),ks=rs(t=>t?`on${ls(t)}`:""),He=(t,i)=>!Object.is(t,i),Hn=(t,...i)=>{for(let e=0;e<t.length;e++)t[e](...i)},jr=(t,i,e,s=!1)=>{Object.defineProperty(t,i,{configurable:!0,enumerable:!1,writable:s,value:e})},as=t=>{const i=parseFloat(t);return isNaN(i)?t:i};let Uo;const cs=()=>Uo||(Uo=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function ro(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++){const s=t[e],n=Yt(s)?dc(s):ro(s);if(n)for(const r in n)i[r]=n[r]}return i}else if(Yt(t)||zt(t))return t}const lc=/;(?![^(]*\))/g,ac=/:([^]+)/,cc=/\/\*[^]*?\*\//g;function dc(t){const i={};return t.replace(cc,"").split(lc).forEach(e=>{if(e){const s=e.split(ac);s.length>1&&(i[s[0].trim()]=s[1].trim())}}),i}function $t(t){let i="";if(Yt(t))i=t;else if(Ct(t))for(let e=0;e<t.length;e++){const s=$t(t[e]);s&&(i+=s+" ")}else if(zt(t))for(const e in t)t[e]&&(i+=e+" ");return i.trim()}const uc="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",fc=no(uc);function Hr(t){return!!t||t===""}function pc(t,i){if(t.length!==i.length)return!1;let e=!0;for(let s=0;e&&s<t.length;s++)e=Xi(t[s],i[s]);return e}function Xi(t,i){if(t===i)return!0;let e=Ho(t),s=Ho(i);if(e||s)return e&&s?t.getTime()===i.getTime():!1;if(e=Be(t),s=Be(i),e||s)return t===i;if(e=Ct(t),s=Ct(i),e||s)return e&&s?pc(t,i):!1;if(e=zt(t),s=zt(i),e||s){if(!e||!s)return!1;const n=Object.keys(t).length,r=Object.keys(i).length;if(n!==r)return!1;for(const l in t){const o=t.hasOwnProperty(l),a=i.hasOwnProperty(l);if(o&&!a||!o&&a||!Xi(t[l],i[l]))return!1}}return String(t)===String(i)}function lo(t,i){return t.findIndex(e=>Xi(e,i))}const Ur=t=>!!(t&&t.__v_isRef===!0),_t=t=>Yt(t)?t:t==null?"":Ct(t)||zt(t)&&(t.toString===Nr||!It(t.toString))?Ur(t)?_t(t.value):JSON.stringify(t,Wr,2):String(t),Wr=(t,i)=>Ur(i)?Wr(t,i.value):ji(i)?{[`Map(${i.size})`]:[...i.entries()].reduce((e,[s,n],r)=>(e[xs(s,r)+" =>"]=n,e),{})}:Ji(i)?{[`Set(${i.size})`]:[...i.values()].map(e=>xs(e))}:Be(i)?xs(i):zt(i)&&!Ct(i)&&!Fr(i)?String(i):i,xs=(t,i="")=>{var e;return Be(t)?`Symbol(${(e=t.description)!=null?e:i})`:t};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let te;class hc{constructor(i=!1){this.detached=i,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!i&&te&&(te.active?(this.parent=te,this.index=(te.scopes||(te.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let i,e;if(this.scopes){const s=this.scopes.slice();for(i=0,e=s.length;i<e;i++)s[i].pause()}for(i=0,e=this.effects.length;i<e;i++)this.effects[i].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let i,e;if(this.scopes){const n=this.scopes.slice();for(i=0,e=n.length;i<e;i++)n[i].resume()}const s=this.effects.slice();for(i=0,e=s.length;i<e;i++)s[i].resume()}}run(i){if(this._active){const e=te;try{return te=this,i()}finally{te=e}}}on(){++this._on===1&&(this.prevScope=te,te=this)}off(){if(this._on>0&&--this._on===0){if(te===this)te=this.prevScope;else{let i=te;for(;i;){if(i.prevScope===this){i.prevScope=this.prevScope;break}i=i.prevScope}}this.prevScope=void 0}}stop(i){if(this._active){this._active=!1;let e,s;for(e=0,s=this.effects.length;e<s;e++)this.effects[e].stop();for(this.effects.length=0,e=0,s=this.cleanups.length;e<s;e++)this.cleanups[e]();if(this.cleanups.length=0,this.scopes){const n=this.scopes.slice();for(e=0,s=n.length;e<s;e++)n[e].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!i){const n=this.parent.scopes.pop();n&&n!==this&&(this.parent.scopes[this.index]=n,n.index=this.index)}this.parent=void 0}}}function mc(){return te}let Ht;const _s=new WeakSet;class Vr{constructor(i){this.fn=i,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,te&&(te.active?te.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,_s.has(this)&&(_s.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||qr(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Wo(this),Gr(this);const i=Ht,e=Me;Ht=this,Me=!0;try{return this.fn()}finally{Zr(this),Ht=i,Me=e,this.flags&=-3}}stop(){if(this.flags&1){for(let i=this.deps;i;i=i.nextDep)uo(i);this.deps=this.depsTail=void 0,Wo(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?_s.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){Hs(this)&&this.run()}get dirty(){return Hs(this)}}let Kr=0,pn,hn;function qr(t,i=!1){if(t.flags|=8,i){t.next=hn,hn=t;return}t.next=pn,pn=t}function ao(){Kr++}function co(){if(--Kr>0)return;if(hn){let i=hn;for(hn=void 0;i;){const e=i.next;i.next=void 0,i.flags&=-9,i=e}}let t;for(;pn;){let i=pn;for(pn=void 0;i;){const e=i.next;if(i.next=void 0,i.flags&=-9,i.flags&1)try{i.trigger()}catch(s){t||(t=s)}i=e}}if(t)throw t}function Gr(t){for(let i=t.deps;i;i=i.nextDep)i.version=-1,i.prevActiveLink=i.dep.activeLink,i.dep.activeLink=i}function Zr(t){let i,e=t.depsTail,s=e;for(;s;){const n=s.prevDep;s.version===-1?(s===e&&(e=n),uo(s),gc(s)):i=s,s.dep.activeLink=s.prevActiveLink,s.prevActiveLink=void 0,s=n}t.deps=i,t.depsTail=e}function Hs(t){for(let i=t.deps;i;i=i.nextDep)if(i.dep.version!==i.version||i.dep.computed&&(Yr(i.dep.computed)||i.dep.version!==i.version))return!0;return!!t._dirty}function Yr(t){if(t.flags&4&&!(t.flags&16)||(t.flags&=-17,t.globalVersion===bn)||(t.globalVersion=bn,!t.isSSR&&t.flags&128&&(!t.deps&&!t._dirty||!Hs(t))))return;t.flags|=2;const i=t.dep,e=Ht,s=Me;Ht=t,Me=!0;try{Gr(t);const n=t.fn(t._value);(i.version===0||He(n,t._value))&&(t.flags|=128,t._value=n,i.version++)}catch(n){throw i.version++,n}finally{Ht=e,Me=s,Zr(t),t.flags&=-3}}function uo(t,i=!1){const{dep:e,prevSub:s,nextSub:n}=t;if(s&&(s.nextSub=n,t.prevSub=void 0),n&&(n.prevSub=s,t.nextSub=void 0),e.subs===t&&(e.subs=s,!s&&e.computed)){e.computed.flags&=-5;for(let r=e.computed.deps;r;r=r.nextDep)uo(r,!0)}!i&&!--e.sc&&e.map&&e.map.delete(e.key)}function gc(t){const{prevDep:i,nextDep:e}=t;i&&(i.nextDep=e,t.prevDep=void 0),e&&(e.prevDep=i,t.nextDep=void 0)}let Me=!0;const Jr=[];function ii(){Jr.push(Me),Me=!1}function ni(){const t=Jr.pop();Me=t===void 0?!0:t}function Wo(t){const{cleanup:i}=t;if(t.cleanup=void 0,i){const e=Ht;Ht=void 0;try{i()}finally{Ht=e}}}let bn=0;class vc{constructor(i,e){this.sub=i,this.dep=e,this.version=e.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class fo{constructor(i){this.computed=i,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(i){if(!Ht||!Me||Ht===this.computed)return;let e=this.activeLink;if(e===void 0||e.sub!==Ht)e=this.activeLink=new vc(Ht,this),Ht.deps?(e.prevDep=Ht.depsTail,Ht.depsTail.nextDep=e,Ht.depsTail=e):Ht.deps=Ht.depsTail=e,Xr(e);else if(e.version===-1&&(e.version=this.version,e.nextDep)){const s=e.nextDep;s.prevDep=e.prevDep,e.prevDep&&(e.prevDep.nextDep=s),e.prevDep=Ht.depsTail,e.nextDep=void 0,Ht.depsTail.nextDep=e,Ht.depsTail=e,Ht.deps===e&&(Ht.deps=s)}return e}trigger(i){this.version++,bn++,this.notify(i)}notify(i){ao();try{for(let e=this.subs;e;e=e.prevSub)e.sub.notify()&&e.sub.dep.notify()}finally{co()}}}function Xr(t){if(t.dep.sc++,t.sub.flags&4){const i=t.dep.computed;if(i&&!t.dep.subs){i.flags|=20;for(let s=i.deps;s;s=s.nextDep)Xr(s)}const e=t.dep.subs;e!==t&&(t.prevSub=e,e&&(e.nextSub=t)),t.dep.subs=t}}const Us=new WeakMap,Ai=Symbol(""),Ws=Symbol(""),yn=Symbol("");function re(t,i,e){if(Me&&Ht){let s=Us.get(t);s||Us.set(t,s=new Map);let n=s.get(e);n||(s.set(e,n=new fo),n.map=s,n.key=e),n.track()}}function Je(t,i,e,s,n,r){const l=Us.get(t);if(!l){bn++;return}const o=a=>{a&&a.trigger()};if(ao(),i==="clear")l.forEach(o);else{const a=Ct(t),c=a&&oo(e);if(a&&e==="length"){const d=Number(s);l.forEach((p,g)=>{(g==="length"||g===yn||!Be(g)&&g>=d)&&o(p)})}else switch((e!==void 0||l.has(void 0))&&o(l.get(e)),c&&o(l.get(yn)),i){case"add":a?c&&o(l.get("length")):(o(l.get(Ai)),ji(t)&&o(l.get(Ws)));break;case"delete":a||(o(l.get(Ai)),ji(t)&&o(l.get(Ws)));break;case"set":ji(t)&&o(l.get(Ai));break}}co()}function Pi(t){const i=Bt(t);return i===t?i:(re(i,"iterate",yn),Ce(t)?i:i.map(De))}function ds(t){return re(t=Bt(t),"iterate",yn),t}function Ne(t,i){return si(t)?qi(Ti(t)?De(i):i):De(i)}const bc={__proto__:null,[Symbol.iterator](){return Ss(this,Symbol.iterator,t=>Ne(this,t))},concat(...t){return Pi(this).concat(...t.map(i=>Ct(i)?Pi(i):i))},entries(){return Ss(this,"entries",t=>(t[1]=Ne(this,t[1]),t))},every(t,i){return qe(this,"every",t,i,void 0,arguments)},filter(t,i){return qe(this,"filter",t,i,e=>e.map(s=>Ne(this,s)),arguments)},find(t,i){return qe(this,"find",t,i,e=>Ne(this,e),arguments)},findIndex(t,i){return qe(this,"findIndex",t,i,void 0,arguments)},findLast(t,i){return qe(this,"findLast",t,i,e=>Ne(this,e),arguments)},findLastIndex(t,i){return qe(this,"findLastIndex",t,i,void 0,arguments)},forEach(t,i){return qe(this,"forEach",t,i,void 0,arguments)},includes(...t){return Cs(this,"includes",t)},indexOf(...t){return Cs(this,"indexOf",t)},join(t){return Pi(this).join(t)},lastIndexOf(...t){return Cs(this,"lastIndexOf",t)},map(t,i){return qe(this,"map",t,i,void 0,arguments)},pop(){return Qi(this,"pop")},push(...t){return Qi(this,"push",t)},reduce(t,...i){return Vo(this,"reduce",t,i)},reduceRight(t,...i){return Vo(this,"reduceRight",t,i)},shift(){return Qi(this,"shift")},some(t,i){return qe(this,"some",t,i,void 0,arguments)},splice(...t){return Qi(this,"splice",t)},toReversed(){return Pi(this).toReversed()},toSorted(t){return Pi(this).toSorted(t)},toSpliced(...t){return Pi(this).toSpliced(...t)},unshift(...t){return Qi(this,"unshift",t)},values(){return Ss(this,"values",t=>Ne(this,t))}};function Ss(t,i,e){const s=ds(t),n=s[i]();return s!==t&&!Ce(t)&&(n._next=n.next,n.next=()=>{const r=n._next();return r.done||(r.value=e(r.value)),r}),n}const yc=Array.prototype;function qe(t,i,e,s,n,r){const l=ds(t),o=l!==t&&!Ce(t),a=l[i];if(a!==yc[i]){const p=a.apply(t,r);return o?De(p):p}let c=e;l!==t&&(o?c=function(p,g){return e.call(this,Ne(t,p),g,t)}:e.length>2&&(c=function(p,g){return e.call(this,p,g,t)}));const d=a.call(l,c,s);return o&&n?n(d):d}function Vo(t,i,e,s){const n=ds(t),r=n!==t&&!Ce(t);let l=e,o=!1;n!==t&&(r?(o=s.length===0,l=function(c,d,p){return o&&(o=!1,c=Ne(t,c)),e.call(this,c,Ne(t,d),p,t)}):e.length>3&&(l=function(c,d,p){return e.call(this,c,d,p,t)}));const a=n[i](l,...s);return o?Ne(t,a):a}function Cs(t,i,e){const s=Bt(t);re(s,"iterate",yn);const n=s[i](...e);return(n===-1||n===!1)&&mo(e[0])?(e[0]=Bt(e[0]),s[i](...e)):n}function Qi(t,i,e=[]){ii(),ao();const s=Bt(t)[i].apply(t,e);return co(),ni(),s}const wc=no("__proto__,__v_isRef,__isVue"),Qr=new Set(Object.getOwnPropertyNames(Symbol).filter(t=>t!=="arguments"&&t!=="caller").map(t=>Symbol[t]).filter(Be));function kc(t){Be(t)||(t=String(t));const i=Bt(this);return re(i,"has",t),i.hasOwnProperty(t)}class tl{constructor(i=!1,e=!1){this._isReadonly=i,this._isShallow=e}get(i,e,s){if(e==="__v_skip")return i.__v_skip;const n=this._isReadonly,r=this._isShallow;if(e==="__v_isReactive")return!n;if(e==="__v_isReadonly")return n;if(e==="__v_isShallow")return r;if(e==="__v_raw")return s===(n?r?Mc:sl:r?nl:il).get(i)||Object.getPrototypeOf(i)===Object.getPrototypeOf(s)?i:void 0;const l=Ct(i);if(!n){let a;if(l&&(a=bc[e]))return a;if(e==="hasOwnProperty")return kc}const o=Reflect.get(i,e,ce(i)?i:s);if((Be(e)?Qr.has(e):wc(e))||(n||re(i,"get",e),r))return o;if(ce(o)){const a=l&&oo(e)?o:o.value;return n&&zt(a)?Ks(a):a}return zt(o)?n?Ks(o):us(o):o}}class el extends tl{constructor(i=!1){super(!1,i)}set(i,e,s,n){let r=i[e];const l=Ct(i)&&oo(e);if(!this._isShallow){const c=si(r);if(!Ce(s)&&!si(s)&&(r=Bt(r),s=Bt(s)),!l&&ce(r)&&!ce(s))return c||(r.value=s),!0}const o=l?Number(e)<i.length:Dt(i,e),a=Reflect.set(i,e,s,ce(i)?i:n);return i===Bt(n)&&a&&(o?He(s,r)&&Je(i,"set",e,s):Je(i,"add",e,s)),a}deleteProperty(i,e){const s=Dt(i,e);i[e];const n=Reflect.deleteProperty(i,e);return n&&s&&Je(i,"delete",e,void 0),n}has(i,e){const s=Reflect.has(i,e);return(!Be(e)||!Qr.has(e))&&re(i,"has",e),s}ownKeys(i){return re(i,"iterate",Ct(i)?"length":Ai),Reflect.ownKeys(i)}}class xc extends tl{constructor(i=!1){super(!0,i)}set(i,e){return!0}deleteProperty(i,e){return!0}}const _c=new el,Sc=new xc,Cc=new el(!0);const Vs=t=>t,Ln=t=>Reflect.getPrototypeOf(t);function $c(t,i,e){return function(...s){const n=this.__v_raw,r=Bt(n),l=ji(r),o=t==="entries"||t===Symbol.iterator&&l,a=t==="keys"&&l,c=n[t](...s),d=e?Vs:i?qi:De;return!i&&re(r,"iterate",a?Ws:Ai),se(Object.create(c),{next(){const{value:p,done:g}=c.next();return g?{value:p,done:g}:{value:o?[d(p[0]),d(p[1])]:d(p),done:g}}})}}function On(t){return function(...i){return t==="delete"?!1:t==="clear"?void 0:this}}function Ic(t,i){const e={get(n){const r=this.__v_raw,l=Bt(r),o=Bt(n);t||(He(n,o)&&re(l,"get",n),re(l,"get",o));const{has:a}=Ln(l),c=i?Vs:t?qi:De;if(a.call(l,n))return c(r.get(n));if(a.call(l,o))return c(r.get(o));r!==l&&r.get(n)},get size(){const n=this.__v_raw;return!t&&re(Bt(n),"iterate",Ai),n.size},has(n){const r=this.__v_raw,l=Bt(r),o=Bt(n);return t||(He(n,o)&&re(l,"has",n),re(l,"has",o)),n===o?r.has(n):r.has(n)||r.has(o)},forEach(n,r){const l=this,o=l.__v_raw,a=Bt(o),c=i?Vs:t?qi:De;return!t&&re(a,"iterate",Ai),o.forEach((d,p)=>n.call(r,c(d),c(p),l))}};return se(e,t?{add:On("add"),set:On("set"),delete:On("delete"),clear:On("clear")}:{add(n){const r=Bt(this),l=Ln(r),o=Bt(n),a=!i&&!Ce(n)&&!si(n)?o:n;return l.has.call(r,a)||He(n,a)&&l.has.call(r,n)||He(o,a)&&l.has.call(r,o)||(r.add(a),Je(r,"add",a,a)),this},set(n,r){!i&&!Ce(r)&&!si(r)&&(r=Bt(r));const l=Bt(this),{has:o,get:a}=Ln(l);let c=o.call(l,n);c||(n=Bt(n),c=o.call(l,n));const d=a.call(l,n);return l.set(n,r),c?He(r,d)&&Je(l,"set",n,r):Je(l,"add",n,r),this},delete(n){const r=Bt(this),{has:l,get:o}=Ln(r);let a=l.call(r,n);a||(n=Bt(n),a=l.call(r,n)),o&&o.call(r,n);const c=r.delete(n);return a&&Je(r,"delete",n,void 0),c},clear(){const n=Bt(this),r=n.size!==0,l=n.clear();return r&&Je(n,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(n=>{e[n]=$c(n,t,i)}),e}function po(t,i){const e=Ic(t,i);return(s,n,r)=>n==="__v_isReactive"?!t:n==="__v_isReadonly"?t:n==="__v_raw"?s:Reflect.get(Dt(e,n)&&n in s?e:s,n,r)}const Ac={get:po(!1,!1)},Tc={get:po(!1,!0)},Ec={get:po(!0,!1)};const il=new WeakMap,nl=new WeakMap,sl=new WeakMap,Mc=new WeakMap;function Bc(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function us(t){return si(t)?t:ho(t,!1,_c,Ac,il)}function Dc(t){return ho(t,!1,Cc,Tc,nl)}function Ks(t){return ho(t,!0,Sc,Ec,sl)}function ho(t,i,e,s,n){if(!zt(t)||t.__v_raw&&!(i&&t.__v_isReactive)||t.__v_skip||!Object.isExtensible(t))return t;const r=n.get(t);if(r)return r;const l=Bc(sc(t));if(l===0)return t;const o=new Proxy(t,l===2?s:e);return n.set(t,o),o}function Ti(t){return si(t)?Ti(t.__v_raw):!!(t&&t.__v_isReactive)}function si(t){return!!(t&&t.__v_isReadonly)}function Ce(t){return!!(t&&t.__v_isShallow)}function mo(t){return t?!!t.__v_raw:!1}function Bt(t){const i=t&&t.__v_raw;return i?Bt(i):t}function Lc(t){return!Dt(t,"__v_skip")&&Object.isExtensible(t)&&jr(t,"__v_skip",!0),t}const De=t=>zt(t)?us(t):t,qi=t=>zt(t)?Ks(t):t;function ce(t){return t?t.__v_isRef===!0:!1}function ht(t){return Oc(t,!1)}function Oc(t,i){return ce(t)?t:new Pc(t,i)}class Pc{constructor(i,e){this.dep=new fo,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=e?i:Bt(i),this._value=e?i:De(i),this.__v_isShallow=e}get value(){return this.dep.track(),this._value}set value(i){const e=this._rawValue,s=this.__v_isShallow||Ce(i)||si(i);i=s?i:Bt(i),He(i,e)&&(this._rawValue=i,this._value=s?i:De(i),this.dep.trigger())}}function $i(t){return ce(t)?t.value:t}const Rc={get:(t,i,e)=>i==="__v_raw"?t:$i(Reflect.get(t,i,e)),set:(t,i,e,s)=>{const n=t[i];return ce(n)&&!ce(e)?(n.value=e,!0):Reflect.set(t,i,e,s)}};function ol(t){return Ti(t)?t:new Proxy(t,Rc)}class zc{constructor(i,e,s){this.fn=i,this.setter=e,this._value=void 0,this.dep=new fo(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=bn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!e,this.isSSR=s}notify(){if(this.flags|=16,!(this.flags&8)&&Ht!==this)return qr(this,!0),!0}get value(){const i=this.dep.track();return Yr(this),i&&(i.version=this.dep.version),this._value}set value(i){this.setter&&this.setter(i)}}function Nc(t,i,e=!1){let s,n;return It(t)?s=t:(s=t.get,n=t.set),new zc(s,n,e)}const Pn={},Zn=new WeakMap;let xi;function Fc(t,i=!1,e=xi){if(e){let s=Zn.get(e);s||Zn.set(e,s=[]),s.push(t)}}function jc(t,i,e=jt){const{immediate:s,deep:n,once:r,scheduler:l,augmentJob:o,call:a}=e,c=A=>n?A:Ce(A)||n===!1||n===0?Xe(A,1):Xe(A);let d,p,g,u,k=!1,h=!1;if(ce(t)?(p=()=>t.value,k=Ce(t)):Ti(t)?(p=()=>c(t),k=!0):Ct(t)?(h=!0,k=t.some(A=>Ti(A)||Ce(A)),p=()=>t.map(A=>{if(ce(A))return A.value;if(Ti(A))return c(A);if(It(A))return a?a(A,2):A()})):It(t)?i?p=a?()=>a(t,2):t:p=()=>{if(g){ii();try{g()}finally{ni()}}const A=xi;xi=d;try{return a?a(t,3,[u]):t(u)}finally{xi=A}}:p=We,i&&n){const A=p,x=n===!0?1/0:n;p=()=>Xe(A(),x)}const b=mc(),v=()=>{d.stop(),b&&b.active&&so(b.effects,d)};if(r&&i){const A=i;i=(...x)=>{const _=A(...x);return v(),_}}let y=h?new Array(t.length).fill(Pn):Pn;const $=A=>{if(!(!(d.flags&1)||!d.dirty&&!A))if(i){const x=d.run();if(A||n||k||(h?x.some((_,S)=>He(_,y[S])):He(x,y))){g&&g();const _=xi;xi=d;try{const S=[x,y===Pn?void 0:h&&y[0]===Pn?[]:y,u];y=x,a?a(i,3,S):i(...S)}finally{xi=_}}}else d.run()};return o&&o($),d=new Vr(p),d.scheduler=l?()=>l($,!1):$,u=A=>Fc(A,!1,d),g=d.onStop=()=>{const A=Zn.get(d);if(A){if(a)a(A,4);else for(const x of A)x();Zn.delete(d)}},i?s?$(!0):y=d.run():l?l($.bind(null,!0),!0):d.run(),v.pause=d.pause.bind(d),v.resume=d.resume.bind(d),v.stop=v,v}function Xe(t,i=1/0,e){if(i<=0||!zt(t)||t.__v_skip||(e=e||new Map,(e.get(t)||0)>=i))return t;if(e.set(t,i),i--,ce(t))Xe(t.value,i,e);else if(Ct(t))for(let s=0;s<t.length;s++)Xe(t[s],i,e);else if(Ji(t)||ji(t))t.forEach(s=>{Xe(s,i,e)});else if(Fr(t)){for(const s in t)Xe(t[s],i,e);for(const s of Object.getOwnPropertySymbols(t))Object.prototype.propertyIsEnumerable.call(t,s)&&Xe(t[s],i,e)}return t}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function $n(t,i,e,s){try{return s?t(...s):t()}catch(n){fs(n,i,e)}}function Le(t,i,e,s){if(It(t)){const n=$n(t,i,e,s);return n&&zr(n)&&n.catch(r=>{fs(r,i,e)}),n}if(Ct(t)){const n=[];for(let r=0;r<t.length;r++)n.push(Le(t[r],i,e,s));return n}}function fs(t,i,e,s=!0){const n=i?i.vnode:null,{errorHandler:r,throwUnhandledErrorInProduction:l}=i&&i.appContext.config||jt;if(i){let o=i.parent;const a=i.proxy,c=`https://vuejs.org/error-reference/#runtime-${e}`;for(;o;){const d=o.ec;if(d){for(let p=0;p<d.length;p++)if(d[p](t,a,c)===!1)return}o=o.parent}if(r){ii(),$n(r,null,10,[t,a,c]),ni();return}}Hc(t,e,n,s,l)}function Hc(t,i,e,s=!0,n=!1){if(n)throw t;console.error(t)}const fe=[];let ze=-1;const Hi=[];let ai=null,Ri=0;const rl=Promise.resolve();let Yn=null;function ll(t){const i=Yn||rl;return t?i.then(this?t.bind(this):t):i}function Uc(t){let i=ze+1,e=fe.length;for(;i<e;){const s=i+e>>>1,n=fe[s],r=wn(n);r<t||r===t&&n.flags&2?i=s+1:e=s}return i}function go(t){if(!(t.flags&1)){const i=wn(t),e=fe[fe.length-1];!e||!(t.flags&2)&&i>=wn(e)?fe.push(t):fe.splice(Uc(i),0,t),t.flags|=1,al()}}function al(){Yn||(Yn=rl.then(dl))}function Wc(t){Ct(t)?Hi.push(...t):ai&&t.id===-1?ai.splice(Ri+1,0,t):t.flags&1||(Hi.push(t),t.flags|=1),al()}function Ko(t,i,e=ze+1){for(;e<fe.length;e++){const s=fe[e];if(s&&s.flags&2){if(t&&s.id!==t.uid)continue;fe.splice(e,1),e--,s.flags&4&&(s.flags&=-2),s(),s.flags&4||(s.flags&=-2)}}}function cl(t){if(Hi.length){const i=[...new Set(Hi)].sort((e,s)=>wn(e)-wn(s));if(Hi.length=0,ai){ai.push(...i);return}for(ai=i,Ri=0;Ri<ai.length;Ri++){const e=ai[Ri];e.flags&4&&(e.flags&=-2),e.flags&8||e(),e.flags&=-2}ai=null,Ri=0}}const wn=t=>t.id==null?t.flags&2?-1:1/0:t.id;function dl(t){try{for(ze=0;ze<fe.length;ze++){const i=fe[ze];i&&!(i.flags&8)&&(i.flags&4&&(i.flags&=-2),$n(i,i.i,i.i?15:14),i.flags&4||(i.flags&=-2))}}finally{for(;ze<fe.length;ze++){const i=fe[ze];i&&(i.flags&=-2)}ze=-1,fe.length=0,cl(),Yn=null,(fe.length||Hi.length)&&dl()}}let ne=null,ul=null;function Jn(t){const i=ne;return ne=t,ul=t&&t.type.__scopeId||null,i}function fl(t,i=ne,e){if(!i||t._n)return t;const s=(...n)=>{s._d&&sr(-1);const r=Jn(i),l=ti.length;let o;try{o=t(...n)}finally{for(let a=ti.length;a>l;a--)xo();Jn(r),s._d&&sr(1)}return o};return s._n=!0,s._c=!0,s._d=!0,s}function Ie(t,i){if(ne===null)return t;const e=gs(ne),s=t.dirs||(t.dirs=[]);for(let n=0;n<i.length;n++){let[r,l,o,a=jt]=i[n];r&&(It(r)&&(r={mounted:r,updated:r}),r.deep&&Xe(l),s.push({dir:r,instance:e,value:l,oldValue:void 0,arg:o,modifiers:a}))}return t}function wi(t,i,e,s){const n=t.dirs,r=i&&i.dirs;for(let l=0;l<n.length;l++){const o=n[l];r&&(o.oldValue=r[l].value);let a=o.dir[s];a&&(ii(),Le(a,e,8,[t.el,o,t,i]),ni())}}function Vc(t,i){if(le){let e=le.provides;const s=le.parent&&le.parent.provides;s===e&&(e=le.provides=Object.create(s)),e[t]=i}}function Qe(t,i,e=!1){const s=Ud();if(s||Wi){let n=Wi?Wi._context.provides:s?s.parent==null||s.ce?s.vnode.appContext&&s.vnode.appContext.provides:s.parent.provides:void 0;if(n&&t in n)return n[t];if(arguments.length>1)return e&&It(i)?i.call(s&&s.proxy):i}}const Kc=Symbol.for("v-scx"),qc=()=>Qe(Kc);function Ei(t,i,e){return pl(t,i,e)}function pl(t,i,e=jt){const{immediate:s,deep:n,flush:r,once:l}=e,o=se({},e),a=i&&s||!i&&r!=="post";let c;if(xn){if(r==="sync"){const u=qc();c=u.__watcherHandles||(u.__watcherHandles=[])}else if(!a){const u=()=>{};return u.stop=We,u.resume=We,u.pause=We,u}}const d=le;o.call=(u,k,h)=>Le(u,d,k,h);let p=!1;r==="post"?o.scheduler=u=>{me(u,d&&d.suspense)}:r!=="sync"&&(p=!0,o.scheduler=(u,k)=>{k?u():go(u)}),o.augmentJob=u=>{i&&(u.flags|=4),p&&(u.flags|=2,d&&(u.id=d.uid,u.i=d))};const g=jc(t,i,o);return xn&&(c?c.push(g):a&&g()),g}function Gc(t,i,e){const s=this.proxy,n=Yt(t)?t.includes(".")?hl(s,t):()=>s[t]:t.bind(s,s);let r;It(i)?r=i:(r=i.handler,e=i);const l=An(this),o=pl(n,r.bind(s),e);return l(),o}function hl(t,i){const e=i.split(".");return()=>{let s=t;for(let n=0;n<e.length&&s;n++)s=s[e[n]];return s}}const Zc=Symbol("_vte"),Yc=t=>t.__isTeleport,$s=Symbol("_leaveCb");function vo(t,i){t.shapeFlag&6&&t.component?(t.transition=i,vo(t.component.subTree,i)):t.shapeFlag&128?(t.ssContent.transition=i.clone(t.ssContent),t.ssFallback.transition=i.clone(t.ssFallback)):t.transition=i}function be(t,i){return It(t)?se({name:t.name},i,{setup:t}):t}function ml(t){t.ids=[t.ids[0]+t.ids[2]+++"-",0,0]}function qo(t,i){let e;return!!((e=Object.getOwnPropertyDescriptor(t,i))&&!e.configurable)}const Xn=new WeakMap;function mn(t,i,e,s,n=!1){if(Ct(t)){t.forEach((h,b)=>mn(h,i&&(Ct(i)?i[b]:i),e,s,n));return}if(Ui(s)&&!n){s.shapeFlag&512&&s.type.__asyncResolved&&s.component.subTree.component&&mn(t,i,e,s.component.subTree);return}const r=s.shapeFlag&4?gs(s.component):s.el,l=n?null:r,{i:o,r:a}=t,c=i&&i.r,d=o.refs===jt?o.refs={}:o.refs,p=o.setupState,g=Bt(p),u=p===jt?Rr:h=>qo(d,h)?!1:Dt(g,h),k=(h,b)=>!(b&&qo(d,b));if(c!=null&&c!==a){if(Go(i),Yt(c))d[c]=null,u(c)&&(p[c]=null);else if(ce(c)){const h=i;k(c,h.k)&&(c.value=null),h.k&&(d[h.k]=null)}}if(It(a))$n(a,o,12,[l,d]);else{const h=Yt(a),b=ce(a);if(h||b){const v=()=>{if(t.f){const y=h?u(a)?p[a]:d[a]:k()||!t.k?a.value:d[t.k];if(n)Ct(y)&&so(y,r);else if(Ct(y))y.includes(r)||y.push(r);else if(h)d[a]=[r],u(a)&&(p[a]=d[a]);else{const $=[r];k(a,t.k)&&(a.value=$),t.k&&(d[t.k]=$)}}else h?(d[a]=l,u(a)&&(p[a]=l)):b&&(k(a,t.k)&&(a.value=l),t.k&&(d[t.k]=l))};if(l){const y=()=>{v(),Xn.delete(t)};y.id=-1,Xn.set(t,y),me(y,e)}else Go(t),v()}}}function Go(t){const i=Xn.get(t);i&&(i.flags|=8,Xn.delete(t))}cs().requestIdleCallback;cs().cancelIdleCallback;const Ui=t=>!!t.type.__asyncLoader,gl=t=>t.type.__isKeepAlive;function Jc(t,i){vl(t,"a",i)}function Xc(t,i){vl(t,"da",i)}function vl(t,i,e=le){const s=t.__wdc||(t.__wdc=()=>{let n=e;for(;n;){if(n.isDeactivated)return;n=n.parent}return t()});if(ps(i,s,e),e){let n=e.parent;for(;n&&n.parent;)gl(n.parent.vnode)&&Qc(s,i,e,n),n=n.parent}}function Qc(t,i,e,s){const n=ps(i,t,s,!0);yo(()=>{so(s[i],n)},e)}function ps(t,i,e=le,s=!1){if(e){const n=e[t]||(e[t]=[]),r=i.__weh||(i.__weh=(...l)=>{ii();const o=An(e),a=Le(i,e,t,l);return o(),ni(),a});return s?n.unshift(r):n.push(r),r}}const ri=t=>(i,e=le)=>{(!xn||t==="sp")&&ps(t,(...s)=>i(...s),e)},td=ri("bm"),In=ri("m"),ed=ri("bu"),id=ri("u"),bo=ri("bum"),yo=ri("um"),nd=ri("sp"),sd=ri("rtg"),od=ri("rtc");function rd(t,i=le){ps("ec",t,i)}const ld="components";function ad(t,i){return dd(ld,t,!0,i)||t}const cd=Symbol.for("v-ndc");function dd(t,i,e=!0,s=!1){const n=ne||le;if(n){const r=n.type;{const o=Gd(r,!1);if(o&&(o===i||o===pe(i)||o===ls(pe(i))))return r}const l=Zo(n[t]||r[t],i)||Zo(n.appContext[t],i);return!l&&s?r:l}}function Zo(t,i){return t&&(t[i]||t[pe(i)]||t[ls(pe(i))])}function ye(t,i,e,s){let n;const r=e,l=Ct(t);if(l||Yt(t)){const o=l&&Ti(t);let a=!1,c=!1;o&&(a=!Ce(t),c=si(t),t=ds(t)),n=new Array(t.length);for(let d=0,p=t.length;d<p;d++)n[d]=i(a?c?qi(De(t[d])):De(t[d]):t[d],d,void 0,r)}else if(typeof t=="number"){n=new Array(t);for(let o=0;o<t;o++)n[o]=i(o+1,o,void 0,r)}else if(zt(t))if(t[Symbol.iterator])n=Array.from(t,(o,a)=>i(o,a,void 0,r));else{const o=Object.keys(t);n=new Array(o.length);for(let a=0,c=o.length;a<c;a++){const d=o[a];n[a]=i(t[d],d,a,r)}}else n=[];return n}function Rn(t,i,e={},s,n,r){if(ne.ce||ne.parent&&Ui(ne.parent)&&ne.parent.ce){const c=e,d=Object.keys(c).length>0;return i!=="default"&&(c.name=i),et(),Ee(Kt,null,[pt("slot",c,s&&s())],d?-2:64)}let l=t[i];l&&l._c&&(l._d=!1);const o=ti.length;et();let a;try{const c=l&&bl(l(e)),d=e.key||r||c&&c.key;a=Ee(Kt,{key:(d&&!Be(d)?d:`_${i}`)+(!c&&s?"_fb":"")},c||(s?s():[]),c&&t._===1?64:-2)}catch(c){for(let d=ti.length;d>o;d--)xo();throw c}finally{l&&l._c&&(l._d=!0)}return a}function bl(t){return t.some(i=>_o(i)?!(i.type===oi||i.type===Kt&&!bl(i.children)):!0)?t:null}const qs=t=>t?zl(t)?gs(t):qs(t.parent):null,gn=se(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>qs(t.parent),$root:t=>qs(t.root),$host:t=>t.ce,$emit:t=>t.emit,$options:t=>wl(t),$forceUpdate:t=>t.f||(t.f=()=>{go(t.update)}),$nextTick:t=>t.n||(t.n=ll.bind(t.proxy)),$watch:t=>Gc.bind(t)}),Is=(t,i)=>t!==jt&&!t.__isScriptSetup&&Dt(t,i),ud={get({_:t},i){if(i==="__v_skip")return!0;const{ctx:e,setupState:s,data:n,props:r,accessCache:l,type:o,appContext:a}=t;if(i[0]!=="$"){const g=l[i];if(g!==void 0)switch(g){case 1:return s[i];case 2:return n[i];case 4:return e[i];case 3:return r[i]}else{if(Is(s,i))return l[i]=1,s[i];if(n!==jt&&Dt(n,i))return l[i]=2,n[i];if(Dt(r,i))return l[i]=3,r[i];if(e!==jt&&Dt(e,i))return l[i]=4,e[i];Gs&&(l[i]=0)}}const c=gn[i];let d,p;if(c)return i==="$attrs"&&re(t.attrs,"get",""),c(t);if((d=o.__cssModules)&&(d=d[i]))return d;if(e!==jt&&Dt(e,i))return l[i]=4,e[i];if(p=a.config.globalProperties,Dt(p,i))return p[i]},set({_:t},i,e){const{data:s,setupState:n,ctx:r}=t;return Is(n,i)?(n[i]=e,!0):s!==jt&&Dt(s,i)?(s[i]=e,!0):Dt(t.props,i)||i[0]==="$"&&i.slice(1)in t?!1:(r[i]=e,!0)},has({_:{data:t,setupState:i,accessCache:e,ctx:s,appContext:n,props:r,type:l}},o){let a;return!!(e[o]||t!==jt&&o[0]!=="$"&&Dt(t,o)||Is(i,o)||Dt(r,o)||Dt(s,o)||Dt(gn,o)||Dt(n.config.globalProperties,o)||(a=l.__cssModules)&&a[o])},defineProperty(t,i,e){return e.get!=null?t._.accessCache[i]=0:Dt(e,"value")&&this.set(t,i,e.value,null),Reflect.defineProperty(t,i,e)}};function Yo(t){return Ct(t)?t.reduce((i,e)=>(i[e]=null,i),{}):t}let Gs=!0;function fd(t){const i=wl(t),e=t.proxy,s=t.ctx;Gs=!1,i.beforeCreate&&Jo(i.beforeCreate,t,"bc");const{data:n,computed:r,methods:l,watch:o,provide:a,inject:c,created:d,beforeMount:p,mounted:g,beforeUpdate:u,updated:k,activated:h,deactivated:b,beforeDestroy:v,beforeUnmount:y,destroyed:$,unmounted:A,render:x,renderTracked:_,renderTriggered:S,errorCaptured:D,serverPrefetch:M,expose:P,inheritAttrs:J,components:T,directives:L,filters:w}=i;if(c&&pd(c,s,null),l)for(const V in l){const it=l[V];It(it)&&(s[V]=it.bind(e))}if(n){const V=n.call(e,e);zt(V)&&(t.data=us(V))}if(Gs=!0,r)for(const V in r){const it=r[V],U=It(it)?it.bind(e,e):It(it.get)?it.get.bind(e,e):We,Y=!It(it)&&It(it.set)?it.set.bind(e):We,W=St({get:U,set:Y});Object.defineProperty(s,V,{enumerable:!0,configurable:!0,get:()=>W.value,set:z=>W.value=z})}if(o)for(const V in o)yl(o[V],s,e,V);if(a){const V=It(a)?a.call(e):a;Reflect.ownKeys(V).forEach(it=>{Vc(it,V[it])})}d&&Jo(d,t,"c");function Q(V,it){Ct(it)?it.forEach(U=>V(U.bind(e))):it&&V(it.bind(e))}if(Q(td,p),Q(In,g),Q(ed,u),Q(id,k),Q(Jc,h),Q(Xc,b),Q(rd,D),Q(od,_),Q(sd,S),Q(bo,y),Q(yo,A),Q(nd,M),Ct(P))if(P.length){const V=t.exposed||(t.exposed={});P.forEach(it=>{Object.defineProperty(V,it,{get:()=>e[it],set:U=>e[it]=U,enumerable:!0})})}else t.exposed||(t.exposed={});x&&t.render===We&&(t.render=x),J!=null&&(t.inheritAttrs=J),T&&(t.components=T),L&&(t.directives=L),M&&ml(t)}function pd(t,i,e=We){Ct(t)&&(t=Zs(t));for(const s in t){const n=t[s];let r;zt(n)?"default"in n?r=Qe(n.from||s,n.default,!0):r=Qe(n.from||s):r=Qe(n),ce(r)?Object.defineProperty(i,s,{enumerable:!0,configurable:!0,get:()=>r.value,set:l=>r.value=l}):i[s]=r}}function Jo(t,i,e){Le(Ct(t)?t.map(s=>s.bind(i.proxy)):t.bind(i.proxy),i,e)}function yl(t,i,e,s){let n=s.includes(".")?hl(e,s):()=>e[s];if(Yt(t)){const r=i[t];It(r)&&Ei(n,r)}else if(It(t))Ei(n,t.bind(e));else if(zt(t))if(Ct(t))t.forEach(r=>yl(r,i,e,s));else{const r=It(t.handler)?t.handler.bind(e):i[t.handler];It(r)&&Ei(n,r,t)}}function wl(t){const i=t.type,{mixins:e,extends:s}=i,{mixins:n,optionsCache:r,config:{optionMergeStrategies:l}}=t.appContext,o=r.get(i);let a;return o?a=o:!n.length&&!e&&!s?a=i:(a={},n.length&&n.forEach(c=>Qn(a,c,l,!0)),Qn(a,i,l)),zt(i)&&r.set(i,a),a}function Qn(t,i,e,s=!1){const{mixins:n,extends:r}=i;r&&Qn(t,r,e,!0),n&&n.forEach(l=>Qn(t,l,e,!0));for(const l in i)if(!(s&&l==="expose")){const o=hd[l]||e&&e[l];t[l]=o?o(t[l],i[l]):i[l]}return t}const hd={data:Xo,props:Qo,emits:Qo,methods:sn,computed:sn,beforeCreate:ue,created:ue,beforeMount:ue,mounted:ue,beforeUpdate:ue,updated:ue,beforeDestroy:ue,beforeUnmount:ue,destroyed:ue,unmounted:ue,activated:ue,deactivated:ue,errorCaptured:ue,serverPrefetch:ue,components:sn,directives:sn,watch:gd,provide:Xo,inject:md};function Xo(t,i){return i?t?function(){return se(It(t)?t.call(this,this):t,It(i)?i.call(this,this):i)}:i:t}function md(t,i){return sn(Zs(t),Zs(i))}function Zs(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++)i[t[e]]=t[e];return i}return t}function ue(t,i){return t?[...new Set([].concat(t,i))]:i}function sn(t,i){return t?se(Object.create(null),t,i):i}function Qo(t,i){return t?Ct(t)&&Ct(i)?[...new Set([...t,...i])]:se(Object.create(null),Yo(t),Yo(i??{})):i}function gd(t,i){if(!t)return i;if(!i)return t;const e=se(Object.create(null),t);for(const s in i)e[s]=ue(t[s],i[s]);return e}function kl(){return{app:null,config:{isNativeTag:Rr,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let vd=0;function bd(t,i){return function(s,n=null){It(s)||(s=se({},s)),n!=null&&!zt(n)&&(n=null);const r=kl(),l=new WeakSet,o=[];let a=!1;const c=r.app={_uid:vd++,_component:s,_props:n,_container:null,_context:r,_instance:null,version:Yd,get config(){return r.config},set config(d){},use(d,...p){return l.has(d)||(d&&It(d.install)?(l.add(d),d.install(c,...p)):It(d)&&(l.add(d),d(c,...p))),c},mixin(d){return r.mixins.includes(d)||r.mixins.push(d),c},component(d,p){return p?(r.components[d]=p,c):r.components[d]},directive(d,p){return p?(r.directives[d]=p,c):r.directives[d]},mount(d,p,g){if(!a){const u=c._ceVNode||pt(s,n);return u.appContext=r,g===!0?g="svg":g===!1&&(g=void 0),t(u,d,g),a=!0,c._container=d,d.__vue_app__=c,gs(u.component)}},onUnmount(d){o.push(d)},unmount(){a&&(Le(o,c._instance,16),t(null,c._container),delete c._container.__vue_app__)},provide(d,p){return r.provides[d]=p,c},runWithContext(d){const p=Wi;Wi=c;try{return d()}finally{Wi=p}}};return c}}let Wi=null;const yd=(t,i)=>i==="modelValue"||i==="model-value"?t.modelModifiers:t[`${i}Modifiers`]||t[`${pe(i)}Modifiers`]||t[`${hi(i)}Modifiers`];function wd(t,i,...e){if(t.isUnmounted)return;const s=t.vnode.props||jt;let n=e;const r=i.startsWith("update:"),l=r&&yd(s,i.slice(7));l&&(l.trim&&(n=e.map(d=>Yt(d)?d.trim():d)),l.number&&(n=e.map(as)));let o,a=s[o=ks(i)]||s[o=ks(pe(i))];!a&&r&&(a=s[o=ks(hi(i))]),a&&Le(a,t,6,n);const c=s[o+"Once"];if(c){if(!t.emitted)t.emitted={};else if(t.emitted[o])return;t.emitted[o]=!0,Le(c,t,6,n)}}const kd=new WeakMap;function xl(t,i,e=!1){const s=e?kd:i.emitsCache,n=s.get(t);if(n!==void 0)return n;const r=t.emits;let l={},o=!1;if(!It(t)){const a=c=>{const d=xl(c,i,!0);d&&(o=!0,se(l,d))};!e&&i.mixins.length&&i.mixins.forEach(a),t.extends&&a(t.extends),t.mixins&&t.mixins.forEach(a)}return!r&&!o?(zt(t)&&s.set(t,null),null):(Ct(r)?r.forEach(a=>l[a]=null):se(l,r),zt(t)&&s.set(t,l),l)}function hs(t,i){return!t||!ss(i)?!1:(i=i.slice(2),i=i==="Once"?i:i.replace(/Once$/,""),Dt(t,i[0].toLowerCase()+i.slice(1))||Dt(t,hi(i))||Dt(t,i))}function tr(t){const{type:i,vnode:e,proxy:s,withProxy:n,propsOptions:[r],slots:l,attrs:o,emit:a,render:c,renderCache:d,props:p,data:g,setupState:u,ctx:k,inheritAttrs:h}=t,b=Jn(t);let v,y;try{if(e.shapeFlag&4){const A=n||s,x=A;v=Fe(c.call(x,A,d,p,u,g,k)),y=o}else{const A=i;v=Fe(A.length>1?A(p,{attrs:o,slots:l,emit:a}):A(p,null)),y=i.props?o:xd(o)}}catch(A){ti.length=0,fs(A,t,1),v=pt(oi)}let $=v;if(y&&h!==!1){const A=Object.keys(y),{shapeFlag:x}=$;A.length&&x&7&&(r&&A.some(os)&&(y=_d(y,r)),$=Gi($,y,!1,!0))}return e.dirs&&($=Gi($,null,!1,!0),$.dirs=$.dirs?$.dirs.concat(e.dirs):e.dirs),e.transition&&vo($,e.transition),v=$,Jn(b),v}const xd=t=>{let i;for(const e in t)(e==="class"||e==="style"||ss(e))&&((i||(i={}))[e]=t[e]);return i},_d=(t,i)=>{const e={};for(const s in t)(!os(s)||!(s.slice(9)in i))&&(e[s]=t[s]);return e};function Sd(t,i,e){const{props:s,children:n,component:r}=t,{props:l,children:o,patchFlag:a}=i,c=r.emitsOptions;if(i.dirs||i.transition)return!0;if(e&&a>=0){if(a&1024)return!0;if(a&16)return s?er(s,l,c):!!l;if(a&8){const d=i.dynamicProps;for(let p=0;p<d.length;p++){const g=d[p];if(_l(l,s,g)&&!hs(c,g))return!0}}}else return(n||o)&&(!o||!o.$stable)?!0:s===l?!1:s?l?er(s,l,c):!0:!!l;return!1}function er(t,i,e){const s=Object.keys(i);if(s.length!==Object.keys(t).length)return!0;for(let n=0;n<s.length;n++){const r=s[n];if(_l(i,t,r)&&!hs(e,r))return!0}return!1}function _l(t,i,e){const s=t[e],n=i[e];return e==="style"&&zt(s)&&zt(n)?!Xi(s,n):s!==n}function Cd({vnode:t,parent:i,suspense:e},s){for(;i;){const n=i.subTree;if(n.suspense&&n.suspense.activeBranch===t&&(n.suspense.vnode.el=n.el=s,t=n),n===t)(t=i.vnode).el=s,i=i.parent;else break}e&&e.activeBranch===t&&(e.vnode.el=s)}const Sl={},Cl=()=>Object.create(Sl),$l=t=>Object.getPrototypeOf(t)===Sl;function $d(t,i,e,s=!1){const n={},r=Cl();t.propsDefaults=Object.create(null),Il(t,i,n,r);for(const l in t.propsOptions[0])l in n||(n[l]=void 0);e?t.props=s?n:Dc(n):t.type.props?t.props=n:t.props=r,t.attrs=r}function Id(t,i,e,s){const{props:n,attrs:r,vnode:{patchFlag:l}}=t,o=Bt(n),[a]=t.propsOptions;let c=!1;if((s||l>0)&&!(l&16)){if(l&8){const d=t.vnode.dynamicProps;for(let p=0;p<d.length;p++){let g=d[p];if(hs(t.emitsOptions,g))continue;const u=i[g];if(a)if(Dt(r,g))u!==r[g]&&(r[g]=u,c=!0);else{const k=pe(g);n[k]=Ys(a,o,k,u,t,!1)}else u!==r[g]&&(r[g]=u,c=!0)}}}else{Il(t,i,n,r)&&(c=!0);let d;for(const p in o)(!i||!Dt(i,p)&&((d=hi(p))===p||!Dt(i,d)))&&(a?e&&(e[p]!==void 0||e[d]!==void 0)&&(n[p]=Ys(a,o,p,void 0,t,!0)):delete n[p]);if(r!==o)for(const p in r)(!i||!Dt(i,p))&&(delete r[p],c=!0)}c&&Je(t.attrs,"set","")}function Il(t,i,e,s){const[n,r]=t.propsOptions;let l=!1,o;if(i)for(let a in i){if(fn(a))continue;const c=i[a];let d;n&&Dt(n,d=pe(a))?!r||!r.includes(d)?e[d]=c:(o||(o={}))[d]=c:hs(t.emitsOptions,a)||(!(a in s)||c!==s[a])&&(s[a]=c,l=!0)}if(r){const a=Bt(e),c=o||jt;for(let d=0;d<r.length;d++){const p=r[d];e[p]=Ys(n,a,p,c[p],t,!Dt(c,p))}}return l}function Ys(t,i,e,s,n,r){const l=t[e];if(l!=null){const o=Dt(l,"default");if(o&&s===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&It(a)){const{propsDefaults:c}=n;if(e in c)s=c[e];else{const d=An(n);s=c[e]=a.call(null,i),d()}}else s=a;n.ce&&n.ce._setProp(e,s)}l[0]&&(r&&!o?s=!1:l[1]&&(s===""||s===hi(e))&&(s=!0))}return s}const Ad=new WeakMap;function Al(t,i,e=!1){const s=e?Ad:i.propsCache,n=s.get(t);if(n)return n;const r=t.props,l={},o=[];let a=!1;if(!It(t)){const d=p=>{a=!0;const[g,u]=Al(p,i,!0);se(l,g),u&&o.push(...u)};!e&&i.mixins.length&&i.mixins.forEach(d),t.extends&&d(t.extends),t.mixins&&t.mixins.forEach(d)}if(!r&&!a)return zt(t)&&s.set(t,Fi),Fi;if(Ct(r))for(let d=0;d<r.length;d++){const p=pe(r[d]);ir(p)&&(l[p]=jt)}else if(r)for(const d in r){const p=pe(d);if(ir(p)){const g=r[d],u=l[p]=Ct(g)||It(g)?{type:g}:se({},g),k=u.type;let h=!1,b=!0;if(Ct(k))for(let v=0;v<k.length;++v){const y=k[v],$=It(y)&&y.name;if($==="Boolean"){h=!0;break}else $==="String"&&(b=!1)}else h=It(k)&&k.name==="Boolean";u[0]=h,u[1]=b,(h||Dt(u,"default"))&&o.push(p)}}const c=[l,o];return zt(t)&&s.set(t,c),c}function ir(t){return t[0]!=="$"&&!fn(t)}const wo=t=>t==="_"||t==="_ctx"||t==="$stable",ko=t=>Ct(t)?t.map(Fe):[Fe(t)],Td=(t,i,e)=>{if(i._n)return i;const s=fl((...n)=>ko(i(...n)),e);return s._c=!1,s},Tl=(t,i,e)=>{const s=t._ctx;for(const n in t){if(wo(n))continue;const r=t[n];if(It(r))i[n]=Td(n,r,s);else if(r!=null){const l=ko(r);i[n]=()=>l}}},El=(t,i)=>{const e=ko(i);t.slots.default=()=>e},Ml=(t,i,e)=>{for(const s in i)(e||!wo(s))&&(t[s]=i[s])},Ed=(t,i,e)=>{const s=t.slots=Cl();if(t.vnode.shapeFlag&32){const n=i._;n?(Ml(s,i,e),e&&jr(s,"_",n,!0)):Tl(i,s)}else i&&El(t,i)},Md=(t,i,e)=>{const{vnode:s,slots:n}=t;let r=!0,l=jt;if(s.shapeFlag&32){const o=i._;o?e&&o===1?r=!1:Ml(n,i,e):(r=!i.$stable,Tl(i,n)),l=i}else i&&(El(t,i),l={default:1});if(r)for(const o in n)!wo(o)&&l[o]==null&&delete n[o]},me=Pd;function Bd(t){return Dd(t)}function Dd(t,i){const e=cs();e.__VUE__=!0;const{insert:s,remove:n,patchProp:r,createElement:l,createText:o,createComment:a,setText:c,setElementText:d,parentNode:p,nextSibling:g,setScopeId:u=We,insertStaticContent:k}=t,h=(E,R,f,N=null,O=null,C=null,I=void 0,B=null,K=!!R.dynamicChildren)=>{if(E===R)return;E&&!tn(E,R)&&(N=gt(E),z(E,O,C,!0),E=null),R.patchFlag===-2&&(K=!1,R.dynamicChildren=null);const{type:j,ref:H,shapeFlag:Z}=R;switch(j){case ms:b(E,R,f,N);break;case oi:v(E,R,f,N);break;case Un:E==null&&y(R,f,N,I);break;case Kt:T(E,R,f,N,O,C,I,B,K);break;default:Z&1?x(E,R,f,N,O,C,I,B,K):Z&6?L(E,R,f,N,O,C,I,B,K):(Z&64||Z&128)&&j.process(E,R,f,N,O,C,I,B,K,rt)}H!=null&&O?mn(H,E&&E.ref,C,R||E,!R):H==null&&E&&E.ref!=null&&mn(E.ref,null,C,E,!0)},b=(E,R,f,N)=>{if(E==null)s(R.el=o(R.children),f,N);else{const O=R.el=E.el;R.children!==E.children&&c(O,R.children)}},v=(E,R,f,N)=>{E==null?s(R.el=a(R.children||""),f,N):R.el=E.el},y=(E,R,f,N)=>{[E.el,E.anchor]=k(E.children,R,f,N,E.el,E.anchor)},$=({el:E,anchor:R},f,N)=>{let O;for(;E&&E!==R;)O=g(E),s(E,f,N),E=O;s(R,f,N)},A=({el:E,anchor:R})=>{let f;for(;E&&E!==R;)f=g(E),n(E),E=f;n(R)},x=(E,R,f,N,O,C,I,B,K)=>{if(R.type==="svg"?I="svg":R.type==="math"&&(I="mathml"),E==null)_(R,f,N,O,C,I,B,K);else{const j=E.el&&E.el._isVueCE?E.el:null;try{j&&j._beginPatch(),M(E,R,O,C,I,B,K)}finally{j&&j._endPatch()}}},_=(E,R,f,N,O,C,I,B)=>{let K,j;const{props:H,shapeFlag:Z,transition:nt,dirs:X}=E;if(K=E.el=l(E.type,C,H&&H.is,H),Z&8?d(K,E.children):Z&16&&D(E.children,K,null,N,O,As(E,C),I,B),X&&wi(E,null,N,"created"),S(K,E,E.scopeId,I,N),H){for(const xt in H)xt!=="value"&&!fn(xt)&&r(K,xt,null,H[xt],C,N);"value"in H&&r(K,"value",null,H.value,C),(j=H.onVnodeBeforeMount)&&Pe(j,N,E)}X&&wi(E,null,N,"beforeMount");const dt=Ld(O,nt);dt&&nt.beforeEnter(K),s(K,R,f),((j=H&&H.onVnodeMounted)||dt||X)&&me(()=>{try{j&&Pe(j,N,E),dt&&nt.enter(K),X&&wi(E,null,N,"mounted")}finally{}},O)},S=(E,R,f,N,O)=>{if(f&&u(E,f),N)for(let C=0;C<N.length;C++)u(E,N[C]);if(O){let C=O.subTree;if(R===C||Ol(C.type)&&(C.ssContent===R||C.ssFallback===R)){const I=O.vnode;S(E,I,I.scopeId,I.slotScopeIds,O.parent)}}},D=(E,R,f,N,O,C,I,B,K=0)=>{for(let j=K;j<E.length;j++){const H=E[j]=B?Ye(E[j]):Fe(E[j]);h(null,H,R,f,N,O,C,I,B)}},M=(E,R,f,N,O,C,I)=>{const B=R.el=E.el;let{patchFlag:K,dynamicChildren:j,dirs:H}=R;K|=E.patchFlag&16;const Z=E.props||jt,nt=R.props||jt;let X;if(f&&ki(f,!1),(X=nt.onVnodeBeforeUpdate)&&Pe(X,f,R,E),H&&wi(R,E,f,"beforeUpdate"),f&&ki(f,!0),j&&(!E.dynamicChildren||E.dynamicChildren.length!==j.length)&&(K=0,I=!1,j=null),(Z.innerHTML&&nt.innerHTML==null||Z.textContent&&nt.textContent==null)&&d(B,""),j?P(E.dynamicChildren,j,B,f,N,As(R,O),C):I||it(E,R,B,null,f,N,As(R,O),C,!1),K>0){if(K&16)J(B,Z,nt,f,O);else if(K&2&&Z.class!==nt.class&&r(B,"class",null,nt.class,O),K&4&&r(B,"style",Z.style,nt.style,O),K&8){const dt=R.dynamicProps;for(let xt=0;xt<dt.length;xt++){const bt=dt[xt],Et=Z[bt],Wt=nt[bt];(Wt!==Et||bt==="value")&&r(B,bt,Et,Wt,O,f)}}K&1&&E.children!==R.children&&d(B,R.children)}else!I&&j==null&&J(B,Z,nt,f,O);((X=nt.onVnodeUpdated)||H)&&me(()=>{X&&Pe(X,f,R,E),H&&wi(R,E,f,"updated")},N)},P=(E,R,f,N,O,C,I)=>{for(let B=0;B<R.length;B++){const K=E[B],j=R[B],H=K.el&&(K.type===Kt||!tn(K,j)||K.shapeFlag&198)?p(K.el):f;h(K,j,H,null,N,O,C,I,!0)}},J=(E,R,f,N,O)=>{if(R!==f){if(R!==jt)for(const C in R)!fn(C)&&!(C in f)&&r(E,C,R[C],null,O,N);for(const C in f){if(fn(C))continue;const I=f[C],B=R[C];I!==B&&C!=="value"&&r(E,C,B,I,O,N)}"value"in f&&r(E,"value",R.value,f.value,O)}},T=(E,R,f,N,O,C,I,B,K)=>{const j=R.el=E?E.el:o(""),H=R.anchor=E?E.anchor:o("");let{patchFlag:Z,dynamicChildren:nt,slotScopeIds:X}=R;X&&(B=B?B.concat(X):X),E==null?(s(j,f,N),s(H,f,N),D(R.children||[],f,H,O,C,I,B,K)):Z>0&&Z&64&&nt&&E.dynamicChildren&&E.dynamicChildren.length===nt.length?(P(E.dynamicChildren,nt,f,O,C,I,B),(R.key!=null||O&&R===O.subTree)&&Bl(E,R,!0)):it(E,R,f,H,O,C,I,B,K)},L=(E,R,f,N,O,C,I,B,K)=>{R.slotScopeIds=B,E==null?R.shapeFlag&512?O.ctx.activate(R,f,N,I,K):w(R,f,N,O,C,I,K):F(E,R,K)},w=(E,R,f,N,O,C,I)=>{const B=E.component=Hd(E,N,O);if(gl(E)&&(B.ctx.renderer=rt),Wd(B,!1,I),B.asyncDep){if(O&&O.registerDep(B,Q,I),!E.el){const K=B.subTree=pt(oi);v(null,K,R,f),E.placeholder=K.el}}else Q(B,E,R,f,O,C,I)},F=(E,R,f)=>{const N=R.component=E.component;if(Sd(E,R,f))if(N.asyncDep&&!N.asyncResolved){V(N,R,f);return}else N.next=R,N.update();else R.el=E.el,N.vnode=R},Q=(E,R,f,N,O,C,I)=>{const B=()=>{if(E.isMounted){let{next:Z,bu:nt,u:X,parent:dt,vnode:xt}=E;{const Xt=Dl(E);if(Xt){Z&&(Z.el=xt.el,V(E,Z,I)),Xt.asyncDep.then(()=>{me(()=>{E.isUnmounted||j()},O)});return}}let bt=Z,Et;ki(E,!1),Z?(Z.el=xt.el,V(E,Z,I)):Z=xt,nt&&Hn(nt),(Et=Z.props&&Z.props.onVnodeBeforeUpdate)&&Pe(Et,dt,Z,xt),ki(E,!0);const Wt=tr(E),qt=E.subTree;E.subTree=Wt,h(qt,Wt,p(qt.el),gt(qt),E,O,C),Z.el=Wt.el,bt===null&&Cd(E,Wt.el),X&&me(X,O),(Et=Z.props&&Z.props.onVnodeUpdated)&&me(()=>Pe(Et,dt,Z,xt),O)}else{let Z;const{el:nt,props:X}=R,{bm:dt,m:xt,parent:bt,root:Et,type:Wt}=E,qt=Ui(R);ki(E,!1),dt&&Hn(dt),!qt&&(Z=X&&X.onVnodeBeforeMount)&&Pe(Z,bt,R),ki(E,!0);{Et.ce&&Et.ce._hasShadowRoot()&&Et.ce._injectChildStyle(Wt,E.parent?E.parent.type:void 0);const Xt=E.subTree=tr(E);h(null,Xt,f,N,E,O,C),R.el=Xt.el}if(xt&&me(xt,O),!qt&&(Z=X&&X.onVnodeMounted)){const Xt=R;me(()=>Pe(Z,bt,Xt),O)}(R.shapeFlag&256||bt&&Ui(bt.vnode)&&bt.vnode.shapeFlag&256)&&E.a&&me(E.a,O),E.isMounted=!0,R=f=N=null}};E.scope.on();const K=E.effect=new Vr(B);E.scope.off();const j=E.update=K.run.bind(K),H=E.job=K.runIfDirty.bind(K);H.i=E,H.id=E.uid,K.scheduler=()=>go(H),ki(E,!0),j()},V=(E,R,f)=>{R.component=E;const N=E.vnode.props;E.vnode=R,E.next=null,Id(E,R.props,N,f),Md(E,R.children,f),ii(),Ko(E),ni()},it=(E,R,f,N,O,C,I,B,K=!1)=>{const j=E&&E.children,H=E?E.shapeFlag:0,Z=R.children,{patchFlag:nt,shapeFlag:X}=R;if(nt>0){if(nt&128){Y(j,Z,f,N,O,C,I,B,K);return}else if(nt&256){U(j,Z,f,N,O,C,I,B,K);return}}X&8?(H&16&&tt(j,O,C),Z!==j&&d(f,Z)):H&16?X&16?Y(j,Z,f,N,O,C,I,B,K):tt(j,O,C,!0):(H&8&&d(f,""),X&16&&D(Z,f,N,O,C,I,B,K))},U=(E,R,f,N,O,C,I,B,K)=>{E=E||Fi,R=R||Fi;const j=E.length,H=R.length,Z=Math.min(j,H);let nt;for(nt=0;nt<Z;nt++){const X=R[nt]=K?Ye(R[nt]):Fe(R[nt]);h(E[nt],X,f,null,O,C,I,B,K)}j>H?tt(E,O,C,!0,!1,Z):D(R,f,N,O,C,I,B,K,Z)},Y=(E,R,f,N,O,C,I,B,K)=>{let j=0;const H=R.length;let Z=E.length-1,nt=H-1;for(;j<=Z&&j<=nt;){const X=E[j],dt=R[j]=K?Ye(R[j]):Fe(R[j]);if(tn(X,dt))h(X,dt,f,null,O,C,I,B,K);else break;j++}for(;j<=Z&&j<=nt;){const X=E[Z],dt=R[nt]=K?Ye(R[nt]):Fe(R[nt]);if(tn(X,dt))h(X,dt,f,null,O,C,I,B,K);else break;Z--,nt--}if(j>Z){if(j<=nt){const X=nt+1,dt=X<H?R[X].el:N;for(;j<=nt;)h(null,R[j]=K?Ye(R[j]):Fe(R[j]),f,dt,O,C,I,B,K),j++}}else if(j>nt)for(;j<=Z;)z(E[j],O,C,!0),j++;else{const X=j,dt=j,xt=new Map;for(j=dt;j<=nt;j++){const Jt=R[j]=K?Ye(R[j]):Fe(R[j]);Jt.key!=null&&xt.set(Jt.key,j)}let bt,Et=0;const Wt=nt-dt+1;let qt=!1,Xt=0;const Mt=new Array(Wt);for(j=0;j<Wt;j++)Mt[j]=0;for(j=X;j<=Z;j++){const Jt=E[j];if(Et>=Wt){z(Jt,O,C,!0);continue}let Gt;if(Jt.key!=null)Gt=xt.get(Jt.key);else for(bt=dt;bt<=nt;bt++)if(Mt[bt-dt]===0&&tn(Jt,R[bt])){Gt=bt;break}Gt===void 0?z(Jt,O,C,!0):(Mt[Gt-dt]=j+1,Gt>=Xt?Xt=Gt:qt=!0,h(Jt,R[Gt],f,null,O,C,I,B,K),Et++)}const Ve=qt?Od(Mt):Fi;for(bt=Ve.length-1,j=Wt-1;j>=0;j--){const Jt=dt+j,Gt=R[Jt],mi=R[Jt+1],Di=Jt+1<H?mi.el||Ll(mi):N;Mt[j]===0?h(null,Gt,f,Di,O,C,I,B,K):qt&&(bt<0||j!==Ve[bt]?W(Gt,f,Di,2):bt--)}}},W=(E,R,f,N,O=null)=>{const{el:C,type:I,transition:B,children:K,shapeFlag:j}=E;if(j&6){W(E.component.subTree,R,f,N);return}if(j&128){E.suspense.move(R,f,N);return}if(j&64){I.move(E,R,f,rt);return}if(I===Kt){s(C,R,f);for(let Z=0;Z<K.length;Z++)W(K[Z],R,f,N);s(E.anchor,R,f);return}if(I===Un){$(E,R,f);return}if(N!==2&&j&1&&B)if(N===0)B.persisted&&!C[$s]?s(C,R,f):(B.beforeEnter(C),s(C,R,f),me(()=>B.enter(C),O));else{const{leave:Z,delayLeave:nt,afterLeave:X}=B,dt=()=>{E.ctx.isUnmounted?n(C):s(C,R,f)},xt=()=>{const bt=C._isLeaving||!!C[$s];C._isLeaving&&C[$s](!0),B.persisted&&!bt?dt():Z(C,()=>{dt(),X&&X()})};nt?nt(C,dt,xt):xt()}else s(C,R,f)},z=(E,R,f,N=!1,O=!1)=>{const{type:C,props:I,ref:B,children:K,dynamicChildren:j,shapeFlag:H,patchFlag:Z,dirs:nt,cacheIndex:X,memo:dt}=E;if(Z===-2&&(O=!1),B!=null&&(ii(),mn(B,null,f,E,!0),ni()),X!=null&&(R.renderCache[X]=void 0),H&256){R.ctx.deactivate(E);return}const xt=H&1&&nt,bt=!Ui(E);let Et;if(bt&&(Et=I&&I.onVnodeBeforeUnmount)&&Pe(Et,R,E),H&6)ot(E.component,f,N);else{if(H&128){E.suspense.unmount(f,N);return}xt&&wi(E,null,R,"beforeUnmount"),H&64?E.type.remove(E,R,f,rt,N):j&&!j.hasOnce&&(C!==Kt||Z>0&&Z&64)?tt(j,R,f,!1,!0):(C===Kt&&Z&384||!O&&H&16)&&tt(K,R,f),N&&ct(E)}const Wt=dt!=null&&X==null;(bt&&(Et=I&&I.onVnodeUnmounted)||xt||Wt)&&me(()=>{Et&&Pe(Et,R,E),xt&&wi(E,null,R,"unmounted"),Wt&&(E.el=null)},f)},ct=E=>{const{type:R,el:f,anchor:N,transition:O}=E;if(R===Kt){lt(f,N);return}if(R===Un){A(E);return}const C=()=>{n(f),O&&!O.persisted&&O.afterLeave&&O.afterLeave()};if(E.shapeFlag&1&&O&&!O.persisted){const{leave:I,delayLeave:B}=O,K=()=>I(f,C);B?B(E.el,C,K):K()}else C()},lt=(E,R)=>{let f;for(;E!==R;)f=g(E),n(E),E=f;n(R)},ot=(E,R,f)=>{const{bum:N,scope:O,job:C,subTree:I,um:B,m:K,a:j}=E;nr(K),nr(j),N&&Hn(N),O.stop(),C&&(C.flags|=8,z(I,E,R,f)),B&&me(B,R),me(()=>{E.isUnmounted=!0},R)},tt=(E,R,f,N=!1,O=!1,C=0)=>{for(let I=C;I<E.length;I++)z(E[I],R,f,N,O)},gt=E=>{if(E.shapeFlag&6)return gt(E.component.subTree);if(E.shapeFlag&128)return E.suspense.next();const R=g(E.anchor||E.el),f=R&&R[Zc];return f?g(f):R};let mt=!1;const G=(E,R,f)=>{let N;E==null?R._vnode&&(z(R._vnode,null,null,!0),N=R._vnode.component):h(R._vnode||null,E,R,null,null,null,f),R._vnode=E,mt||(mt=!0,Ko(N),cl(),mt=!1)},rt={p:h,um:z,m:W,r:ct,mt:w,mc:D,pc:it,pbc:P,n:gt,o:t};return{render:G,hydrate:void 0,createApp:bd(G)}}function As({type:t,props:i},e){return e==="svg"&&t==="foreignObject"||e==="mathml"&&t==="annotation-xml"&&i&&i.encoding&&i.encoding.includes("html")?void 0:e}function ki({effect:t,job:i},e){e?(t.flags|=32,i.flags|=4):(t.flags&=-33,i.flags&=-5)}function Ld(t,i){return(!t||t&&!t.pendingBranch)&&i&&!i.persisted}function Bl(t,i,e=!1){const s=t.children,n=i.children;if(Ct(s)&&Ct(n))for(let r=0;r<s.length;r++){const l=s[r];let o=n[r];o.shapeFlag&1&&!o.dynamicChildren&&((o.patchFlag<=0||o.patchFlag===32)&&(o=n[r]=Ye(n[r]),o.el=l.el),!e&&o.patchFlag!==-2&&Bl(l,o)),o.type===ms&&(o.patchFlag===-1&&(o=n[r]=Ye(o)),o.el=l.el),o.type===oi&&!o.el&&(o.el=l.el)}}function Od(t){const i=t.slice(),e=[0];let s,n,r,l,o;const a=t.length;for(s=0;s<a;s++){const c=t[s];if(c!==0){if(n=e[e.length-1],t[n]<c){i[s]=n,e.push(s);continue}for(r=0,l=e.length-1;r<l;)o=r+l>>1,t[e[o]]<c?r=o+1:l=o;c<t[e[r]]&&(r>0&&(i[s]=e[r-1]),e[r]=s)}}for(r=e.length,l=e[r-1];r-- >0;)e[r]=l,l=i[l];return e}function Dl(t){const i=t.subTree.component;if(i)return i.asyncDep&&!i.asyncResolved?i:Dl(i)}function nr(t){if(t)for(let i=0;i<t.length;i++)t[i].flags|=8}function Ll(t){if(t.placeholder)return t.placeholder;const i=t.component;return i?Ll(i.subTree):null}const Ol=t=>t.__isSuspense;function Pd(t,i){i&&i.pendingBranch?Ct(t)?i.effects.push(...t):i.effects.push(t):Wc(t)}const Kt=Symbol.for("v-fgt"),ms=Symbol.for("v-txt"),oi=Symbol.for("v-cmt"),Un=Symbol.for("v-stc"),ti=[];let we=null;function et(t=!1){ti.push(we=t?null:[])}function xo(){ti.pop(),we=ti[ti.length-1]||null}let kn=1;function sr(t,i=!1){kn+=t,t<0&&we&&i&&(we.hasOnce=!0)}function Pl(t){return t.dynamicChildren=kn>0?we||Fi:null,xo(),kn>0&&we&&we.push(t),t}function st(t,i,e,s,n,r){return Pl(m(t,i,e,s,n,r,!0))}function Ee(t,i,e,s,n){return Pl(pt(t,i,e,s,n,!0))}function _o(t){return t?t.__v_isVNode===!0:!1}function tn(t,i){return t.type===i.type&&t.key===i.key}const Rl=({key:t})=>t??null,Wn=({ref:t,ref_key:i,ref_for:e})=>(typeof t=="number"&&(t=""+t),t!=null?Yt(t)||ce(t)||It(t)?{i:ne,r:t,k:i,f:!!e}:t:null);function m(t,i=null,e=null,s=0,n=null,r=t===Kt?0:1,l=!1,o=!1){const a={__v_isVNode:!0,__v_skip:!0,type:t,props:i,key:i&&Rl(i),ref:i&&Wn(i),scopeId:ul,slotScopeIds:null,children:e,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:r,patchFlag:s,dynamicProps:n,dynamicChildren:null,appContext:null,ctx:ne};return o?(ts(a,e),r&128&&t.normalize(a)):e&&(a.shapeFlag|=Yt(e)?8:16),kn>0&&!l&&we&&(a.patchFlag>0||r&6)&&a.patchFlag!==32&&we.push(a),a}const pt=Rd;function Rd(t,i=null,e=null,s=0,n=null,r=!1){if((!t||t===cd)&&(t=oi),_o(t)){const o=Gi(t,i,!0);return e&&ts(o,e),kn>0&&!r&&we&&(o.shapeFlag&6?we[we.indexOf(t)]=o:we.push(o)),o.patchFlag=-2,o}if(Zd(t)&&(t=t.__vccOpts),i){i=zd(i);let{class:o,style:a}=i;o&&!Yt(o)&&(i.class=$t(o)),zt(a)&&(mo(a)&&!Ct(a)&&(a=se({},a)),i.style=ro(a))}const l=Yt(t)?1:Ol(t)?128:Yc(t)?64:zt(t)?4:It(t)?2:0;return m(t,i,e,s,n,l,r,!0)}function zd(t){return t?mo(t)||$l(t)?se({},t):t:null}function Gi(t,i,e=!1,s=!1){const{props:n,ref:r,patchFlag:l,children:o,transition:a}=t,c=i?Nd(n||{},i):n,d={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&Rl(c),ref:i&&i.ref?e&&r?Ct(r)?r.concat(Wn(i)):[r,Wn(i)]:Wn(i):r,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:o,target:t.target,targetStart:t.targetStart,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:i&&t.type!==Kt?l===-1?16:l|16:l,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:a,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&Gi(t.ssContent),ssFallback:t.ssFallback&&Gi(t.ssFallback),placeholder:t.placeholder,el:t.el,anchor:t.anchor,ctx:t.ctx,ce:t.ce};return a&&s&&vo(d,a.clone(d)),d}function Js(t=" ",i=0){return pt(ms,null,t,i)}function $e(t,i){const e=pt(Un,null,t);return e.staticCount=i,e}function Rt(t="",i=!1){return i?(et(),Ee(oi,null,t)):pt(oi,null,t)}function Fe(t){return t==null||typeof t=="boolean"?pt(oi):Ct(t)?pt(Kt,null,t.slice()):_o(t)?Ye(t):pt(ms,null,String(t))}function Ye(t){return t.el===null&&t.patchFlag!==-1||t.memo?t:Gi(t)}function ts(t,i){let e=0;const{shapeFlag:s}=t;if(i==null)i=null;else if(Ct(i))e=16;else if(typeof i=="object")if(s&65){const n=i.default;n&&(n._c&&(n._d=!1),ts(t,n()),n._c&&(n._d=!0));return}else{e=32;const n=i._;!n&&!$l(i)?i._ctx=ne:n===3&&ne&&(ne.slots._===1?i._=1:(i._=2,t.patchFlag|=1024))}else if(It(i)){if(s&65){ts(t,{default:i});return}i={default:i,_ctx:ne},e=32}else i=String(i),s&64?(e=16,i=[Js(i)]):e=8;t.children=i,t.shapeFlag|=e}function Nd(...t){const i={};for(let e=0;e<t.length;e++){const s=t[e];for(const n in s)if(n==="class")i.class!==s.class&&(i.class=$t([i.class,s.class]));else if(n==="style")i.style=ro([i.style,s.style]);else if(ss(n)){const r=i[n],l=s[n];l&&r!==l&&!(Ct(r)&&r.includes(l))?i[n]=r?[].concat(r,l):l:l==null&&r==null&&!os(n)&&(i[n]=l)}else n!==""&&(i[n]=s[n])}return i}function Pe(t,i,e,s=null){Le(t,i,7,[e,s])}const Fd=kl();let jd=0;function Hd(t,i,e){const s=t.type,n=(i?i.appContext:t.appContext)||Fd,r={uid:jd++,vnode:t,type:s,parent:i,appContext:n,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new hc(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:i?i.provides:Object.create(n.provides),ids:i?i.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Al(s,n),emitsOptions:xl(s,n),emit:null,emitted:null,propsDefaults:jt,inheritAttrs:s.inheritAttrs,ctx:jt,data:jt,props:jt,attrs:jt,slots:jt,refs:jt,setupState:jt,setupContext:null,suspense:e,suspenseId:e?e.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return r.ctx={_:r},r.root=i?i.root:r,r.emit=wd.bind(null,r),t.ce&&t.ce(r),r}let le=null;const Ud=()=>le||ne;let es,Xs;{const t=cs(),i=(e,s)=>{let n;return(n=t[e])||(n=t[e]=[]),n.push(s),r=>{n.length>1?n.forEach(l=>l(r)):n[0](r)}};es=i("__VUE_INSTANCE_SETTERS__",e=>le=e),Xs=i("__VUE_SSR_SETTERS__",e=>xn=e)}const An=t=>{const i=le;return es(t),t.scope.on(),()=>{t.scope.off(),es(i)}},or=()=>{le&&le.scope.off(),es(null)};function zl(t){return t.vnode.shapeFlag&4}let xn=!1;function Wd(t,i=!1,e=!1){i&&Xs(i);const{props:s,children:n}=t.vnode,r=zl(t);$d(t,s,r,i),Ed(t,n,e||i);const l=r?Vd(t,i):void 0;return i&&Xs(!1),l}function Vd(t,i){const e=t.type;t.accessCache=Object.create(null),t.proxy=new Proxy(t.ctx,ud);const{setup:s}=e;if(s){ii();const n=t.setupContext=s.length>1?qd(t):null,r=An(t),l=$n(s,t,0,[t.props,n]),o=zr(l);if(ni(),r(),(o||t.sp)&&!Ui(t)&&ml(t),o){if(l.then(or,or),i)return l.then(a=>{rr(t,a)}).catch(a=>{fs(a,t,0)});t.asyncDep=l}else rr(t,l)}else Nl(t)}function rr(t,i,e){It(i)?t.type.__ssrInlineRender?t.ssrRender=i:t.render=i:zt(i)&&(t.setupState=ol(i)),Nl(t)}function Nl(t,i,e){const s=t.type;t.render||(t.render=s.render||We);{const n=An(t);ii();try{fd(t)}finally{ni(),n()}}}const Kd={get(t,i){return re(t,"get",""),t[i]}};function qd(t){const i=e=>{t.exposed=e||{}};return{attrs:new Proxy(t.attrs,Kd),slots:t.slots,emit:t.emit,expose:i}}function gs(t){return t.exposed?t.exposeProxy||(t.exposeProxy=new Proxy(ol(Lc(t.exposed)),{get(i,e){if(e in i)return i[e];if(e in gn)return gn[e](t)},has(i,e){return e in i||e in gn}})):t.proxy}function Gd(t,i=!0){return It(t)?t.displayName||t.name:t.name||i&&t.__name}function Zd(t){return It(t)&&"__vccOpts"in t}const St=(t,i)=>Nc(t,i,xn),Yd="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Qs;const lr=typeof window<"u"&&window.trustedTypes;if(lr)try{Qs=lr.createPolicy("vue",{createHTML:t=>t})}catch{}const Fl=Qs?t=>Qs.createHTML(t):t=>t,Jd="http://www.w3.org/2000/svg",Xd="http://www.w3.org/1998/Math/MathML",Ze=typeof document<"u"?document:null,ar=Ze&&Ze.createElement("template"),Qd={insert:(t,i,e)=>{i.insertBefore(t,e||null)},remove:t=>{const i=t.parentNode;i&&i.removeChild(t)},createElement:(t,i,e,s)=>{const n=i==="svg"?Ze.createElementNS(Jd,t):i==="mathml"?Ze.createElementNS(Xd,t):e?Ze.createElement(t,{is:e}):Ze.createElement(t);return t==="select"&&s&&s.multiple!=null&&n.setAttribute("multiple",s.multiple),n},createText:t=>Ze.createTextNode(t),createComment:t=>Ze.createComment(t),setText:(t,i)=>{t.nodeValue=i},setElementText:(t,i)=>{t.textContent=i},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>Ze.querySelector(t),setScopeId(t,i){t.setAttribute(i,"")},insertStaticContent(t,i,e,s,n,r){const l=e?e.previousSibling:i.lastChild;if(n&&(n===r||n.nextSibling))for(;i.insertBefore(n.cloneNode(!0),e),!(n===r||!(n=n.nextSibling)););else{ar.innerHTML=Fl(s==="svg"?`<svg>${t}</svg>`:s==="mathml"?`<math>${t}</math>`:t);const o=ar.content;if(s==="svg"||s==="mathml"){const a=o.firstChild;for(;a.firstChild;)o.appendChild(a.firstChild);o.removeChild(a)}i.insertBefore(o,e)}return[l?l.nextSibling:i.firstChild,e?e.previousSibling:i.lastChild]}},tu=Symbol("_vtc");function eu(t,i,e){const s=t[tu];s&&(i=(i?[i,...s]:[...s]).join(" ")),i==null?t.removeAttribute("class"):e?t.setAttribute("class",i):t.className=i}const is=Symbol("_vod"),jl=Symbol("_vsh"),Hl={name:"show",beforeMount(t,{value:i},{transition:e}){t[is]=t.style.display==="none"?"":t.style.display,e&&i?e.beforeEnter(t):en(t,i)},mounted(t,{value:i},{transition:e}){e&&i&&e.enter(t)},updated(t,{value:i,oldValue:e},{transition:s}){!i!=!e&&(s?i?(s.beforeEnter(t),en(t,!0),s.enter(t)):s.leave(t,()=>{en(t,!1)}):en(t,i))},beforeUnmount(t,{value:i}){en(t,i)}};function en(t,i){t.style.display=i?t[is]:"none",t[jl]=!i}const iu=Symbol(""),nu=/(?:^|;)\s*display\s*:/;function su(t,i,e){const s=t.style,n=Yt(e);let r=!1;if(e&&!n){if(i)if(Yt(i))for(const l of i.split(";")){const o=l.slice(0,l.indexOf(":")).trim();e[o]==null&&on(s,o,"")}else for(const l in i)e[l]==null&&on(s,l,"");for(const l in e){l==="display"&&(r=!0);const o=e[l];o!=null?ru(t,l,!Yt(i)&&i?i[l]:void 0,o)||on(s,l,o):on(s,l,"")}}else if(n){if(i!==e){const l=s[iu];l&&(e+=";"+l),s.cssText=e,r=nu.test(e)}}else i&&t.removeAttribute("style");is in t&&(t[is]=r?s.display:"",t[jl]&&(s.display="none"))}const cr=/\s*!important$/;function on(t,i,e){if(Ct(e))e.forEach(s=>on(t,i,s));else if(e==null&&(e=""),i.startsWith("--"))t.setProperty(i,e);else{const s=ou(t,i);cr.test(e)?t.setProperty(hi(s),e.replace(cr,""),"important"):t[s]=e}}const dr=["Webkit","Moz","ms"],Ts={};function ou(t,i){const e=Ts[i];if(e)return e;let s=pe(i);if(s!=="filter"&&s in t)return Ts[i]=s;s=ls(s);for(let n=0;n<dr.length;n++){const r=dr[n]+s;if(r in t)return Ts[i]=r}return i}function ru(t,i,e,s){return t.tagName==="TEXTAREA"&&(i==="width"||i==="height")&&Yt(s)&&e===s}const ur="http://www.w3.org/1999/xlink";function fr(t,i,e,s,n,r=fc(i)){s&&i.startsWith("xlink:")?e==null?t.removeAttributeNS(ur,i.slice(6,i.length)):t.setAttributeNS(ur,i,e):e==null||r&&!Hr(e)?t.removeAttribute(i):t.setAttribute(i,r?"":Be(e)?String(e):e)}function pr(t,i,e,s,n){if(i==="innerHTML"||i==="textContent"){e!=null&&(t[i]=i==="innerHTML"?Fl(e):e);return}const r=t.tagName;if(i==="value"&&r!=="PROGRESS"&&!r.includes("-")){const o=r==="OPTION"?t.getAttribute("value")||"":t.value,a=e==null?t.type==="checkbox"?"on":"":String(e);(o!==a||!("_value"in t))&&(t.value=a),e==null&&t.removeAttribute(i),t._value=e;return}let l=!1;if(e===""||e==null){const o=typeof t[i];o==="boolean"?e=Hr(e):e==null&&o==="string"?(e="",l=!0):o==="number"&&(e=0,l=!0)}try{t[i]=e}catch{}l&&t.removeAttribute(n||i)}function ci(t,i,e,s){t.addEventListener(i,e,s)}function lu(t,i,e,s){t.removeEventListener(i,e,s)}const hr=Symbol("_vei");function au(t,i,e,s,n=null){const r=t[hr]||(t[hr]={}),l=r[i];if(s&&l)l.value=s;else{const[o,a]=uu(i);if(s){const c=r[i]=hu(s,n);ci(t,o,c,a)}else l&&(lu(t,o,l,a),r[i]=void 0)}}const cu=/(Once|Passive|Capture)$/,du=/^on:?(?:Once|Passive|Capture)$/;function uu(t){let i,e;for(;(e=t.match(cu))&&!du.test(t);)i||(i={}),t=t.slice(0,t.length-e[1].length),i[e[1].toLowerCase()]=!0;return[t[2]===":"?t.slice(3):hi(t.slice(2)),i]}let Es=0;const fu=Promise.resolve(),pu=()=>Es||(fu.then(()=>Es=0),Es=Date.now());function hu(t,i){const e=s=>{if(!s._vts)s._vts=Date.now();else if(s._vts<=e.attached)return;const n=e.value;if(Ct(n)){const r=s.stopImmediatePropagation;s.stopImmediatePropagation=()=>{r.call(s),s._stopped=!0};const l=n.slice(),o=[s];for(let a=0;a<l.length&&!s._stopped;a++){const c=l[a];c&&Le(c,i,5,o)}}else Le(n,i,5,[s])};return e.value=t,e.attached=pu(),e}const mr=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&t.charCodeAt(2)>96&&t.charCodeAt(2)<123,mu=(t,i,e,s,n,r)=>{const l=n==="svg";i==="class"?eu(t,s,l):i==="style"?su(t,e,s):ss(i)?os(i)||au(t,i,e,s,r):(i[0]==="."?(i=i.slice(1),!0):i[0]==="^"?(i=i.slice(1),!1):gu(t,i,s,l))?(pr(t,i,s),!t.tagName.includes("-")&&(i==="value"||i==="checked"||i==="selected")&&fr(t,i,s,l,r,i!=="value")):t._isVueCE&&(vu(t,i)||t._def.__asyncLoader&&(/[A-Z]/.test(i)||!Yt(s)))?pr(t,pe(i),s,r,i):(i==="true-value"?t._trueValue=s:i==="false-value"&&(t._falseValue=s),fr(t,i,s,l))};function gu(t,i,e,s){if(s)return!!(i==="innerHTML"||i==="textContent"||i in t&&mr(i)&&It(e));if(i==="spellcheck"||i==="draggable"||i==="translate"||i==="autocorrect"||i==="sandbox"&&t.tagName==="IFRAME"||i==="form"||i==="list"&&t.tagName==="INPUT"||i==="type"&&t.tagName==="TEXTAREA")return!1;if(i==="width"||i==="height"){const n=t.tagName;if(n==="IMG"||n==="VIDEO"||n==="CANVAS"||n==="SOURCE")return!1}return mr(i)&&Yt(e)?!1:i in t}function vu(t,i){const e=t._def.props;if(!e)return!1;const s=pe(i);return Array.isArray(e)?e.some(n=>pe(n)===s):Object.keys(e).some(n=>pe(n)===s)}const Zi=t=>{const i=t.props["onUpdate:modelValue"]||!1;return Ct(i)?e=>Hn(i,e):i};function bu(t){t.target.composing=!0}function gr(t){const i=t.target;i.composing&&(i.composing=!1,i.dispatchEvent(new Event("input")))}const ei=Symbol("_assign");function vr(t,i,e){return i&&(t=t.trim()),e&&(t=as(t)),t}const ns={created(t,{modifiers:{lazy:i,trim:e,number:s}},n){t[ei]=Zi(n);const r=s||n.props&&n.props.type==="number";ci(t,i?"change":"input",l=>{l.target.composing||t[ei](vr(t.value,e,r))}),(e||r)&&ci(t,"change",()=>{t.value=vr(t.value,e,r)}),i||(ci(t,"compositionstart",bu),ci(t,"compositionend",gr),ci(t,"change",gr))},mounted(t,{value:i}){t.value=i??""},beforeUpdate(t,{value:i,oldValue:e,modifiers:{lazy:s,trim:n,number:r}},l){if(t[ei]=Zi(l),t.composing)return;const o=(r||t.type==="number")&&!/^0\d/.test(t.value)?as(t.value):t.value,a=i??"";if(o===a)return;const c=t.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===t&&t.type!=="range"&&(s&&i===e||n&&t.value.trim()===a)||(t.value=a)}},zn={deep:!0,created(t,i,e){t[ei]=Zi(e),ci(t,"change",()=>{const s=t._modelValue,n=_n(t),r=t.checked,l=t[ei];if(Ct(s)){const o=lo(s,n),a=o!==-1;if(r&&!a)l(s.concat(n));else if(!r&&a){const c=[...s];c.splice(o,1),l(c)}}else if(Ji(s)){const o=new Set(s);r?o.add(n):o.delete(n),l(o)}else l(Ul(t,r))})},mounted:br,beforeUpdate(t,i,e){t[ei]=Zi(e),br(t,i,e)}};function br(t,{value:i,oldValue:e},s){t._modelValue=i;let n;if(Ct(i))n=lo(i,s.props.value)>-1;else if(Ji(i))n=i.has(s.props.value);else{if(i===e)return;n=Xi(i,Ul(t,!0))}t.checked!==n&&(t.checked=n)}const yu={deep:!0,created(t,{value:i,modifiers:{number:e}},s){t._modelValue=i,ci(t,"change",()=>{const n=Array.prototype.filter.call(t.options,r=>r.selected).map(r=>e?as(_n(r)):_n(r));t[ei](t.multiple?Ji(t._modelValue)?new Set(n):n:n[0]),t._assigning=!0,ll(()=>{t._assigning=!1})}),t[ei]=Zi(s)},mounted(t,{value:i}){yr(t,i)},beforeUpdate(t,{value:i},e){t._modelValue=i,t[ei]=Zi(e)},updated(t,{value:i}){t._assigning||yr(t,i)}};function yr(t,i){const e=t.multiple,s=Ct(i);if(!(e&&!s&&!Ji(i))){for(let n=0,r=t.options.length;n<r;n++){const l=t.options[n],o=_n(l);if(e)if(s){const a=typeof o;a==="string"||a==="number"?l.selected=i.some(c=>String(c)===String(o)):l.selected=lo(i,o)>-1}else l.selected=i.has(o);else if(Xi(_n(l),i)){t.selectedIndex!==n&&(t.selectedIndex=n);return}}!e&&t.selectedIndex!==-1&&(t.selectedIndex=-1)}}function _n(t){return"_value"in t?t._value:t.value}function Ul(t,i){const e=i?"_trueValue":"_falseValue";return e in t?t[e]:i}const wu=["ctrl","shift","alt","meta"],ku={stop:t=>t.stopPropagation(),prevent:t=>t.preventDefault(),self:t=>t.target!==t.currentTarget,ctrl:t=>!t.ctrlKey,shift:t=>!t.shiftKey,alt:t=>!t.altKey,meta:t=>!t.metaKey,left:t=>"button"in t&&t.button!==0,middle:t=>"button"in t&&t.button!==1,right:t=>"button"in t&&t.button!==2,exact:(t,i)=>wu.some(e=>t[`${e}Key`]&&!i.includes(e))},Te=(t,i)=>{if(!t)return t;const e=t._withMods||(t._withMods={}),s=i.join(".");return e[s]||(e[s]=((n,...r)=>{for(let l=0;l<i.length;l++){const o=ku[i[l]];if(o&&o(n,i))return}return t(n,...r)}))},xu={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},_u=(t,i)=>{const e=t._withKeys||(t._withKeys={}),s=i.join(".");return e[s]||(e[s]=(n=>{if(!("key"in n))return;const r=hi(n.key);if(i.some(l=>l===r||xu[l]===r))return t(n)}))},Su=se({patchProp:mu},Qd);let wr;function Cu(){return wr||(wr=Bd(Su))}const Wl=((...t)=>{const i=Cu().createApp(...t),{mount:e}=i;return i.mount=s=>{const n=Iu(s);if(!n)return;const r=i._component;!It(r)&&!r.render&&!r.template&&(r.template=n.innerHTML),n.nodeType===1&&(n.textContent="");const l=e(n,!1,$u(n));return n instanceof Element&&(n.removeAttribute("v-cloak"),n.setAttribute("data-v-app","")),l},i});function $u(t){if(t instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&t instanceof MathMLElement)return"mathml"}function Iu(t){return Yt(t)?document.querySelector(t):t}function Au(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function ke(t){const i=Au();if(i)try{return i(t)}catch{try{const e=t.startsWith("node:")?t.slice(5):`node:${t}`;return i(e)}catch{}}}function So(){var i;if(typeof window<"u"&&window.process)return window.process;const t=ke("process");return t&&t.versions?t:typeof process<"u"&&((i=process.versions)!=null&&i.node)?process:globalThis.process}function Vl(){var i,e;const t=So();if(t&&((i=t.versions)!=null&&i.node))return!0;if(typeof window<"u"&&window.siyuan){const s=ke("child_process");if(s&&typeof s.spawn=="function")return!0}return!!(typeof process<"u"&&((e=process.versions)!=null&&e.node))}function Sn(){const t=So();if(t!=null&&t.platform)return t.platform;if(typeof process<"u"&&process.platform)return process.platform;const i=ke("os");if(i&&typeof i.platform=="function")return i.platform();if(typeof navigator<"u"){const e=navigator.userAgent.toLowerCase();if(e.includes("win"))return"win32";if(e.includes("mac"))return"darwin";if(e.includes("linux"))return"linux"}return"web"}function Kl(){var s,n;const t=So(),i={...(t==null?void 0:t.env)||{}};if(Sn()==="win32"){const r=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(s=t==null?void 0:t.env)!=null&&s.APPDATA?`${t.env.APPDATA}\\npm`:"",(n=t==null?void 0:t.env)!=null&&n.USERPROFILE?`${t.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(i).find(c=>c.toLowerCase()==="path")||"PATH",a=(i[l]||"").split(";").filter(Boolean);for(const c of r)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);i[l]=a.join(";")}return i}function to(t){var e,s,n;if(!t)return"";if(/^[a-zA-Z]:[/\\]/.test(t))return t.replace(/\\/g,"/");let i="";if(typeof window<"u"&&((n=(s=(e=window.siyuan)==null?void 0:e.config)==null?void 0:s.system)!=null&&n.dataDir)&&(i=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),i&&t.startsWith("/data/")){const r=t.slice(6);return`${i}/${r}`.replace(/\\/g,"/")}return t}function Tu(){const t=ke("os"),i=ke("path");if(t&&typeof t.tmpdir=="function"){const e=t.tmpdir();return i&&typeof i.join=="function"?i.join(e,"siyuan-slidev-pro").replace(/\\/g,"/"):`${e}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class Co{constructor(i){wt(this,"runner");this.runner=i||Co.defaultRunner}static async defaultRunner(i,e){var s;try{let n=(s=ke("child_process"))==null?void 0:s.execFile;if(!n){const a=await import("node:child_process").catch(()=>({}));n=a==null?void 0:a.execFile}if(!n)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=Sn()==="win32",o=Kl();return await new Promise(a=>{n(i,e,{timeout:5e3,shell:l,env:o},(c,d,p)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:p?String(p).trim():""})})})}catch(n){return{code:-1,stdout:"",stderr:String(n)}}}async detect(){const i=Vl(),e=Sn();if(!i)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let s=!1,n,r=!1,l;try{const o=await this.runner("node",["-v"]);o.code===0&&o.stdout.startsWith("v")&&(s=!0,n=o.stdout)}catch{}if(s){try{const o=e==="win32"?"slidev.cmd":"slidev",a=await this.runner(o,["--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}if(!r)try{const o=e==="win32"?"npx.cmd":"npx",a=await this.runner(o,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}}return{hasNode:s,nodeVersion:n,hasSlidevCli:r,slidevVersion:l,platform:e,isDesktop:i}}}class Eu{constructor(){wt(this,"iframe",null);wt(this,"isReady",!1);wt(this,"pageChangedHandlers",[]);wt(this,"readyHandlers",[]);wt(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(i,e){var n;if(!((n=this.iframe)!=null&&n.contentWindow))return;const s={target:"slidev",sender:"siyuan",type:i,...e};try{this.iframe.contentWindow.postMessage(s,"*")}catch(r){console.warn("[NativeSlidevBridge] postMessage error:",r)}}navigateToPage(i){this.postMessage("navigate",{no:i})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(i){return this.pageChangedHandlers.push(i),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(e=>e!==i)}}onReady(i){return this.readyHandlers.push(i),()=>{this.readyHandlers=this.readyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){const e=i.data;if(!(!e||e.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const s of this.readyHandlers)s()}if(e.type==="update-state"&&e.navState){const s=e.navState;this.currentState={no:s.no??this.currentState.no,clicks:s.clicks??this.currentState.clicks,total:s.total??this.currentState.total,hasNext:s.hasNext,hasPrev:s.hasPrev};for(const n of this.pageChangedHandlers)n(this.currentState.no,this.currentState.total||1,this.currentState)}else if(e.type==="navigate"&&typeof e.no=="number"){this.currentState.no=e.no;for(const s of this.pageChangedHandlers)s(e.no,this.currentState.total||1,this.currentState)}}}}class Mu{constructor(i){wt(this,"childProcess",null);wt(this,"activePort",null);wt(this,"isRunning",!1);wt(this,"defaultPort");wt(this,"maxPortRetries");wt(this,"probeTimeoutMs");wt(this,"customSpawner");wt(this,"customPortChecker");this.defaultPort=(i==null?void 0:i.defaultPort)||3030,this.maxPortRetries=(i==null?void 0:i.maxPortRetries)||20,this.probeTimeoutMs=(i==null?void 0:i.probeTimeoutMs)||1e4,this.customSpawner=i==null?void 0:i.customSpawner,this.customPortChecker=i==null?void 0:i.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(i){if(this.customPortChecker)return this.customPortChecker(i);try{let e=ke("net");return e||(e=await import("node:net").catch(()=>({}))),e!=null&&e.createServer?await new Promise(s=>{const n=e.createServer();n.once("error",()=>s(!1)),n.once("listening",()=>{n.close(()=>s(!0))}),n.listen(i,"127.0.0.1")}):!0}catch{return!0}}async allocPort(i){const e=i||this.defaultPort;for(let s=0;s<this.maxPortRetries;s++){const n=e+s;if(await this.isPortAvailable(n))return n}return e}async pollServerReady(i,e=8e3,s=300){const n=Date.now();for(;Date.now()-n<e;){try{const r=new AbortController,l=setTimeout(()=>r.abort(),s),o=await fetch(i,{method:"HEAD",mode:"no-cors",signal:r.signal}).catch(()=>null);if(clearTimeout(l),o)return!0}catch{}await new Promise(r=>setTimeout(r,s))}return!1}async startServer(i,e){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const s=await this.allocPort(e);this.activePort=s;const r=Sn()==="win32"?"npx.cmd":"npx",l=to(i),o=["@slidev/cli",l,"--port",String(s),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(r,o,{detached:!1});else{let p=(a=ke("child_process"))==null?void 0:a.spawn;if(!p){const k=await import("node:child_process").catch(()=>({}));p=k==null?void 0:k.spawn}if(!p)throw new Error("child_process spawn not available in current runtime");const g=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,u=Kl();this.childProcess=p(r,o,{cwd:g,detached:!1,shell:!0,env:{...u,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${s}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:s,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${s})`}):{success:!0,port:s,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:s,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var i;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),Sn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const s=(i=ke("child_process"))==null?void 0:i.exec;s?s(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:n})=>{var r;n(`taskkill /pid ${(r=this.childProcess)==null?void 0:r.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class $o{constructor(){wt(this,"iframe",null);wt(this,"isReady",!1);wt(this,"pendingMessages",[]);wt(this,"slideChangedHandlers",[]);wt(this,"blockClickedHandlers",[]);wt(this,"openInEditorHandlers",[]);wt(this,"clientReadyHandlers",[]);wt(this,"openPeekDrawerHandlers",[]);wt(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(i,e){var n;const s={source:"siyuan-slidev-host",action:i,payload:e};if(!((n=this.iframe)!=null&&n.contentWindow)||!this.isReady){this.pendingMessages.push(s);return}try{this.iframe.contentWindow.postMessage(s,"*")}catch(r){console.warn("[WebSandboxBridge] postMessage error:",r)}}updateSlides(i,e,s,n){this.postMessage("UPDATE_SLIDES",{slides:i,config:e,fullMarkdown:s,customThemeCss:n})}navigatePage(i){this.postMessage("NAVIGATE_PAGE",{pageIndex:i})}highlightElement(i){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:i})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(i){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:i})}onSlideChanged(i){return this.slideChangedHandlers.push(i),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(e=>e!==i)}}onBlockClicked(i){return this.blockClickedHandlers.push(i),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(e=>e!==i)}}onOpenInEditor(i){return this.openInEditorHandlers.push(i),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(e=>e!==i)}}onOpenPeekDrawer(i){return this.openPeekDrawerHandlers.push(i),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(e=>e!==i)}}onRequestToggleFullscreen(i){return this.toggleFullscreenHandlers.push(i),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(e=>e!==i)}}onClientReady(i){return this.clientReadyHandlers.push(i),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){var s;const e=i.data;if(!(!e||e.source!=="siyuan-slidev-client"))switch(e.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const n=this.pendingMessages.shift();n&&((s=this.iframe)!=null&&s.contentWindow)&&this.iframe.contentWindow.postMessage(n,"*")}for(const n of this.clientReadyHandlers)n();break;case"SLIDE_CHANGED":if(e.payload.currentPage!==void 0)for(const n of this.slideChangedHandlers)n(e.payload.currentPage,e.payload.totalPages||1,e.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(e.payload.clickedBlockId)for(const n of this.blockClickedHandlers)n(e.payload.clickedBlockId,e.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(e.payload.blockId||e.payload.clickedBlockId){const n=e.payload.blockId||e.payload.clickedBlockId||"";for(const r of this.openInEditorHandlers)r(n,e.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(e.payload.peekType){const n=e.payload.blockId||e.payload.url||"",r={peekType:e.payload.peekType,target:n,title:e.payload.title};for(const l of this.openPeekDrawerHandlers)l(r)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const n of this.toggleFullscreenHandlers)n();break}}}const ql={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},Bu=`<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-3 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,Du=`// Auto-generated by SiYuan Slidev Studio
export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,Lu=`${js}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function Ou(t){var n;const i=[],e=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let s;for(;(s=e.exec(t))!==null;){const r=(n=s[1])==null?void 0:n.trim();r&&!i.includes(r)&&i.push(r)}return i}class Pu{constructor(i){wt(this,"workspacePath");wt(this,"slidesFileName");wt(this,"cliBridge",new io);const e=Tu();!(i!=null&&i.workspacePath)||i.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=e:this.workspacePath=i.workspacePath,this.slidesFileName=(i==null?void 0:i.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(i="default"){const e={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return i&&i!=="default"&&(e.dependencies[`@slidev/theme-${i}`]="latest"),JSON.stringify(e,null,2)}buildSlidesMarkdown(i){return this.cliBridge.buildStandardSlidevMarkdown(i)}async scaffold(i,e){const s=this.buildSlidesMarkdown(i),n=this.generatePackageJson(i.config.theme),r=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,o=to(r),a=to(l),c=Ou(s);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const v of c){const y=ql[v]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${v}
// #endregion snippet
`;d.set(v,y)}i.slides.some(v=>{var y;return((y=v.frontmatter)==null?void 0:y.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",Bu),d.set("setup/root.ts",Du),d.set("styles/index.css",Lu);const g=ke("fs"),u=ke("path");let k=!1;const h=u!=null&&u.dirname?u.dirname(o):"",b=/^[a-zA-Z]:[/\\]/.test(o)||o.includes("siyuan-slidev-pro");if(g&&u&&b)try{g.existsSync(h)||g.mkdirSync(h,{recursive:!0}),g.writeFileSync(a,n,"utf-8"),g.writeFileSync(o,s,"utf-8");for(const[v,y]of d.entries()){const $=u.join(h,v),A=u.dirname($);g.existsSync(A)||g.mkdirSync(A,{recursive:!0}),g.existsSync($)||g.writeFileSync($,y,"utf-8")}k=!0}catch{}if(!k&&e)try{const v=typeof Blob<"u"?new Blob([s],{type:"text/markdown;charset=utf-8"}):Buffer.from(s,"utf-8"),y=typeof Blob<"u"?new Blob([n],{type:"application/json;charset=utf-8"}):Buffer.from(n,"utf-8");await e(l,!1,y),await e(r,!1,v);for(const[$,A]of d.entries()){const x=`${this.workspacePath}/${$}`,_=typeof Blob<"u"?new Blob([A],{type:"text/plain;charset=utf-8"}):Buffer.from(A,"utf-8");await e(x,!1,_).catch(()=>{})}return{success:!0,slidesPath:r,physicalSlidesPath:o,packageJsonPath:l}}catch(v){return{success:!1,slidesPath:r,physicalSlidesPath:o,packageJsonPath:l,error:String(v)}}return{success:!0,slidesPath:r,physicalSlidesPath:o,packageJsonPath:l}}}class Ru{constructor(){wt(this,"mode","web-sandbox");wt(this,"webBridge");wt(this,"cliBridge");wt(this,"nativeBridge");wt(this,"processManager");wt(this,"scaffolder");wt(this,"envDetector");this.webBridge=new $o,this.cliBridge=new io,this.nativeBridge=new Eu,this.processManager=new Mu,this.scaffolder=new Pu,this.envDetector=new Co}getMode(){return this.mode}setMode(i){this.mode=i}async startProMode(i,e){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const n=await this.scaffolder.scaffold(i,e);if(!n.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${n.error}`};const r=n.physicalSlidesPath||n.slidesPath,l=await this.processManager.startServer(r);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const zu={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Nu={key:0},Fu={key:1},ju={key:2},Hu={key:3},Uu={key:4},Wu={key:5},Vu={key:6},Ku={key:7},qu={key:8},Gu={key:9},Zu={key:10},Yu={key:11},Ju={key:12},Xu={key:13},Qu={key:14},tf={key:15},ef={key:16},nf={key:17},sf={key:18},of={key:19},rf={key:20},lf={key:21},af={key:22},cf={key:23},df={key:24},uf={key:25},ff={key:26},pf={key:27},hf={key:28},mf={key:29},gf={key:30},vf={key:31},bf={key:32},yf={key:33},wf={key:34},kf={key:35},xf={key:36},_f={key:37},Sf={key:38},Cf={key:39},$f={key:40},If={key:41},Af={key:42},Tf={key:43},Ef={key:44},Mf={key:45},Bf={key:46},Df={key:47},Lf={key:48},Of={key:49},Pf={key:50},Rf={key:51},zf={key:52},Nf=be({__name:"SlidevIcon",props:{name:{}},setup(t){return(i,e)=>(et(),st("svg",zu,[t.name==="fullscreen"||t.name==="maximize"?(et(),st("g",Nu,[...e[0]||(e[0]=[m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("polyline",{points:"9 21 3 21 3 15"},null,-1),m("polyline",{points:"21 15 21 21 15 21"},null,-1),m("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):t.name==="minimize"?(et(),st("g",Fu,[...e[1]||(e[1]=[m("polyline",{points:"4 14 10 14 10 20"},null,-1),m("polyline",{points:"20 10 14 10 14 4"},null,-1),m("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),m("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):t.name==="close"||t.name==="x"?(et(),st("g",ju,[...e[2]||(e[2]=[m("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),m("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):t.name==="edit"?(et(),st("g",Hu,[...e[3]||(e[3]=[m("path",{d:"M12 20h9"},null,-1),m("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):t.name==="eye"?(et(),st("g",Uu,[...e[4]||(e[4]=[m("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),m("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):t.name==="external-link"||t.name==="window"?(et(),st("g",Wu,[...e[5]||(e[5]=[m("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):t.name==="arrow-left"?(et(),st("g",Vu,[...e[6]||(e[6]=[m("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),m("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):t.name==="arrow-right"?(et(),st("g",Ku,[...e[7]||(e[7]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):t.name==="plus"?(et(),st("g",qu,[...e[8]||(e[8]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="minus"?(et(),st("g",Gu,[...e[9]||(e[9]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="split-preview"?(et(),st("g",Zu,[...e[10]||(e[10]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),m("path",{d:"M12 3v18"},null,-1)])])):t.name==="import"?(et(),st("g",Yu,[...e[11]||(e[11]=[m("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),m("polyline",{points:"7 9 12 14 17 9"},null,-1),m("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):t.name==="presenter"?(et(),st("g",Ju,[...e[12]||(e[12]=[m("path",{d:"M2 3h20"},null,-1),m("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),m("path",{d:"m7 21 5-5 5 5"},null,-1)])])):t.name==="video"?(et(),st("g",Xu,[...e[13]||(e[13]=[m("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),m("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):t.name==="step"?(et(),st("g",Qu,[...e[14]||(e[14]=[m("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):t.name==="motion"?(et(),st("g",tf,[...e[15]||(e[15]=[m("path",{d:"M5 12h14"},null,-1),m("path",{d:"m12 5 7 7-7 7"},null,-1),m("path",{d:"M5 6h4"},null,-1),m("path",{d:"M5 18h4"},null,-1)])])):t.name==="columns"?(et(),st("g",ef,[...e[16]||(e[16]=[m("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),m("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):t.name==="code"?(et(),st("g",nf,[...e[17]||(e[17]=[m("polyline",{points:"16 18 22 12 16 6"},null,-1),m("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):t.name==="insert-above"?(et(),st("g",sf,[...e[18]||(e[18]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),m("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),m("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):t.name==="insert-below"?(et(),st("g",of,[...e[19]||(e[19]=[m("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),m("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="broom"?(et(),st("g",rf,[...e[20]||(e[20]=[m("path",{d:"m18 15-6-6"},null,-1),m("path",{d:"M4 20h16"},null,-1),m("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):t.name==="trash"?(et(),st("g",lf,[...e[21]||(e[21]=[m("path",{d:"M3 6h18"},null,-1),m("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),m("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):t.name==="ai"||t.name==="sparkles"?(et(),st("g",af,[...e[22]||(e[22]=[m("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):t.name==="palette"?(et(),st("g",cf,[...e[23]||(e[23]=[$e('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-b8552023></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-b8552023></path>',5)])])):t.name==="ratio"?(et(),st("g",df,[...e[24]||(e[24]=[m("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):t.name==="transition"?(et(),st("g",uf,[...e[25]||(e[25]=[m("path",{d:"M8 3 4 7l4 4"},null,-1),m("path",{d:"M4 7h16"},null,-1),m("path",{d:"m16 21 4-4-4-4"},null,-1),m("path",{d:"M20 17H4"},null,-1)])])):t.name==="export-html"?(et(),st("g",ff,[...e[26]||(e[26]=[m("polyline",{points:"16 16 12 12 8 16"},null,-1),m("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),m("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):t.name==="export-pdf"?(et(),st("g",pf,[...e[27]||(e[27]=[m("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),m("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),m("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):t.name==="pin"?(et(),st("g",hf,[...e[28]||(e[28]=[m("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),m("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):t.name==="refresh"?(et(),st("g",mf,[...e[29]||(e[29]=[m("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),m("path",{d:"M21 3v5h-5"},null,-1),m("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),m("path",{d:"M8 16H3v5"},null,-1)])])):t.name==="outline"?(et(),st("g",gf,[...e[30]||(e[30]=[m("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),m("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),m("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):t.name==="chevron-left"?(et(),st("g",vf,[...e[31]||(e[31]=[m("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):t.name==="chevron-right"?(et(),st("g",bf,[...e[32]||(e[32]=[m("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):t.name==="copy"?(et(),st("g",yf,[...e[33]||(e[33]=[m("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),m("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):t.name==="image"?(et(),st("g",wf,[...e[34]||(e[34]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),m("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),m("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):t.name==="search"?(et(),st("g",kf,[...e[35]||(e[35]=[m("circle",{cx:"11",cy:"11",r:"7"},null,-1),m("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):t.name==="settings"||t.name==="gear"?(et(),st("g",xf,[...e[36]||(e[36]=[m("circle",{cx:"12",cy:"12",r:"3"},null,-1),m("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):t.name==="notes"||t.name==="file-text"?(et(),st("g",_f,[...e[37]||(e[37]=[$e('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-b8552023></path><polyline points="14 2 14 8 20 8" data-v-b8552023></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-b8552023></line><line x1="16" y1="17" x2="8" y2="17" data-v-b8552023></line><line x1="10" y1="9" x2="8" y2="9" data-v-b8552023></line>',5)])])):t.name==="focus"||t.name==="target"?(et(),st("g",Sf,[...e[38]||(e[38]=[m("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),m("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),m("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):t.name==="layout-cover"||t.name==="cover"?(et(),st("g",Cf,[...e[39]||(e[39]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),m("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),m("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):t.name==="layout-default"||t.name==="default"?(et(),st("g",$f,[...e[40]||(e[40]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-b8552023></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-b8552023></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-b8552023></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-b8552023></line>',5)])])):t.name==="layout-two-cols"||t.name==="two-cols"?(et(),st("g",If,[...e[41]||(e[41]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-b8552023></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-b8552023></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-b8552023></line><line x1="5" y1="15" x2="8" y2="15" data-v-b8552023></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-b8552023></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-b8552023></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-b8552023></line>',8)])])):t.name==="layout-two-cols-header"||t.name==="two-cols-header"?(et(),st("g",Af,[...e[42]||(e[42]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b8552023></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-b8552023></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-b8552023></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-b8552023></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-b8552023></line>',7)])])):t.name==="layout-three-cols-header"||t.name==="three-cols-header"?(et(),st("g",Tf,[...e[43]||(e[43]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b8552023></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-b8552023></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-b8552023></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-b8552023></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-b8552023></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-b8552023></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-b8552023></line>',10)])])):t.name==="layout-image-right"||t.name==="image-right"?(et(),st("g",Ef,[...e[44]||(e[44]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b8552023></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-b8552023></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-b8552023></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-b8552023></line><circle cx="15.5" cy="8.5" r="1.2" data-v-b8552023></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-b8552023></polyline>',7)])])):t.name==="layout-image-left"||t.name==="image-left"?(et(),st("g",Mf,[...e[45]||(e[45]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b8552023></line><circle cx="6" cy="8.5" r="1.2" data-v-b8552023></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-b8552023></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-b8552023></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-b8552023></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-b8552023></line>',7)])])):t.name==="layout-center"||t.name==="center"?(et(),st("g",Bf,[...e[46]||(e[46]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="layout-fact"||t.name==="fact"?(et(),st("g",Df,[...e[47]||(e[47]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><circle cx="8" cy="9" r="1.5" data-v-b8552023></circle><line x1="14" y1="8" x2="9" y2="14" data-v-b8552023></line><circle cx="15" cy="13" r="1.5" data-v-b8552023></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-b8552023></line>',5)])])):t.name==="layout-intro"||t.name==="intro"?(et(),st("g",Lf,[...e[48]||(e[48]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><circle cx="7.5" cy="9.5" r="2" data-v-b8552023></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-b8552023></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-b8552023></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-b8552023></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-b8552023></line>',6)])])):t.name==="layout-quote"||t.name==="quote"?(et(),st("g",Of,[...e[49]||(e[49]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-b8552023></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-b8552023></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-b8552023></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-b8552023></line>',5)])])):t.name==="desktop"||t.name==="monitor"?(et(),st("g",Pf,[...e[50]||(e[50]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):t.name==="mobile"||t.name==="smartphone"||t.name==="phone"?(et(),st("g",Rf,[...e[51]||(e[51]=[m("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),m("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):(et(),st("g",zf,[...e[52]||(e[52]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Oe=(t,i)=>{const e=t.__vccOpts||t;for(const[s,n]of i)e[s]=n;return e},yt=Oe(Nf,[["__scopeId","data-v-b8552023"]]);function ee(t,i){var n;if(typeof document>"u"||!t)return;const e=(n=globalThis.CSS)!=null&&n.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),s=document.querySelectorAll(`[data-node-id="${e}"]`);!s||s.length===0||s.forEach(r=>{for(const[l,o]of Object.entries(i))o!=null&&o!==""?r.setAttribute(l,String(o)):r.removeAttribute(l)})}function Ff(t){if(typeof document>"u")return;const i=`.protyle-wysiwyg [${ft}], .protyle-wysiwyg [${Ut}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,e=document.querySelectorAll(i);!e||e.length===0||e.forEach(s=>{const n=s.getAttribute("data-node-id");if(!n){s.removeAttribute(ft),s.removeAttribute("custom-slidev-layout"),s.removeAttribute(Ut),s.removeAttribute("custom-slidev-role");return}const r=t.get(n),l=(r==null?void 0:r[ft])||(r==null?void 0:r["custom-slidev-layout"])||"",o=s.getAttribute(ft)||s.getAttribute("custom-slidev-layout");o&&o!==l&&(l?s.setAttribute(ft,l):(s.removeAttribute(ft),s.removeAttribute("custom-slidev-layout")));const a=(r==null?void 0:r[Ut])||(r==null?void 0:r["custom-slidev-role"])||"",c=s.getAttribute(Ut)||s.getAttribute("custom-slidev-role");c&&c!==a&&(a?s.setAttribute(Ut,a):(s.removeAttribute(Ut),s.removeAttribute("custom-slidev-role")))})}const jf={class:"spm-layout-picker"},Hf={class:"spm-layout-picker__grid"},Uf=["title","onClick"],Wf={class:"spm-layout-icon"},Vf={class:"spm-layout-label"},Kf=be({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,s=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"two-cols-header",label:"表头双栏",desc:"顶部通栏标题，下方左右双栏"},{name:"three-cols-header",label:"表头三栏",desc:"顶部通栏标题，下方等宽三栏"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function n(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(et(),st("div",jf,[l[0]||(l[0]=m("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),m("div",Hf,[(et(),st(Kt,null,ye(s,o=>m("div",{key:o.name,class:$t(["spm-layout-item",{active:t.modelValue===o.name}]),title:o.desc,onClick:a=>n(o.name)},[m("div",Wf,[pt(yt,{name:"layout-"+o.name},null,8,["name"])]),m("span",Vf,_t(o.label),1)],10,Uf)),64))])]))}}),Gl=Oe(Kf,[["__scopeId","data-v-c57441d5"]]),qf={key:0,class:"spm-transition-selector__header"},Gf={class:"spm-transition-list"},Zf=["onClick"],Yf={class:"spm-transition-meta"},Jf={class:"spm-transition-label"},Xf={class:"spm-transition-name"},Qf={class:"spm-transition-preview-box"},tp=be({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,s=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function n(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(et(),st("div",{class:$t(["spm-transition-selector",{"spm-transition-selector--no-header":t.hideHeader}])},[t.hideHeader?Rt("",!0):(et(),st("div",qf,_t(t.title||"转场动效"),1)),m("div",Gf,[(et(),st(Kt,null,ye(s,o=>m("div",{key:o.name,class:$t(["spm-transition-item",{active:t.modelValue===o.name}]),onClick:a=>n(o.name)},[m("div",Yf,[m("span",Jf,_t(o.label),1),m("span",Xf,"("+_t(o.name)+")",1)]),m("div",Qf,[m("div",{class:$t(["spm-anim-cube","anim-"+o.name])},null,2)])],10,Zf)),64))])],2))}}),Io=Oe(tp,[["__scopeId","data-v-b0aa61ff"]]),ep={class:"spm-divider-popover"},ip={class:"spm-divider-popover__title"},np={class:"spm-form-item"},sp={class:"spm-popover-footer"},op={class:"spm-save-hint"},rp=be({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(t,{emit:i}){var g,u,k;const e=t,s=i,n=ht(((g=e.initialAttrs)==null?void 0:g[ft])||"default"),r=ht(((u=e.initialAttrs)==null?void 0:u[Zt])||"slide-left"),l=ht(((k=e.initialAttrs)==null?void 0:k[Ft])||""),o=ht("");Ei(()=>e.initialAttrs,h=>{n.value=(h==null?void 0:h[ft])||"default",r.value=(h==null?void 0:h[Zt])||"slide-left",l.value=(h==null?void 0:h[Ft])||""},{deep:!0});async function a(h,b){if(e.blockId){o.value="正在同步...",Nt.setBlockAttrOverride(e.blockId,{[h]:b}),ee(e.blockId,{[h]:b});try{await Lt(e.blockId,{[h]:b}),o.value="已同步至块属性",s("updated",{[h]:b}),setTimeout(()=>{o.value=""},1500)}catch{o.value="同步失败"}}}function c(h){a(ft,h)}function d(h){a(Zt,h)}function p(){a(Ft,l.value.trim())}return(h,b)=>(et(),st("div",ep,[m("div",ip,[b[4]||(b[4]=m("span",null,"幻灯片页面设置",-1)),m("button",{class:"spm-close-btn",onClick:b[0]||(b[0]=v=>s("close"))},"✕")]),pt(Gl,{modelValue:n.value,"onUpdate:modelValue":b[1]||(b[1]=v=>n.value=v),onChange:c},null,8,["modelValue"]),pt(Io,{modelValue:r.value,"onUpdate:modelValue":b[2]||(b[2]=v=>r.value=v),onChange:d},null,8,["modelValue"]),m("div",np,[b[5]||(b[5]=m("label",{class:"spm-form-label"},"页面背景",-1)),Ie(m("input",{"onUpdate:modelValue":b[3]||(b[3]=v=>l.value=v),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:p},null,544),[[ns,l.value]])]),m("div",sp,[m("span",op,_t(o.value),1)])]))}}),lp=Oe(rp,[["__scopeId","data-v-e4871368"]]),ap={class:"spm-slide-inspector"},cp={class:"spm-inspector-header"},dp={class:"spm-inspector-list"},up=["onClick"],fp={class:"spm-card-top"},pp={class:"spm-card-badge"},hp={class:"spm-card-layout"},mp=["onClick"],gp={class:"spm-card-preview"},vp={key:0,class:"spm-card-notes",title:"演讲备忘录"},bp={class:"spm-inspector-modal-content"},yp=be({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(t,{emit:i}){const e=i,s=ht(null);function n(c){s.value=c}function r(c){const d={};return c.frontmatter.layout&&(d[ft]=c.frontmatter.layout),c.frontmatter.transition&&(d[Zt]=c.frontmatter.transition),c.frontmatter.background&&(d[Ft]=c.frontmatter.background),c.notes&&(d[zi]=c.notes),d}function l(c){s.value&&(c[ft]&&(s.value.frontmatter.layout=c[ft]),c[Zt]&&(s.value.frontmatter.transition=c[Zt]),c[Ft]&&(s.value.frontmatter.background=c[Ft]),c[zi]&&(s.value.notes=c[zi]),e("refresh"))}function o(c){e("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const d=c.blocks[0],p=d.content||d.rawMarkdown||"";return p.slice(0,40)+(p.length>40?"...":"")}return(c,d)=>(et(),st("div",ap,[m("div",cp,[m("span",null,"幻灯片大纲 ("+_t(t.slides.length)+" 页)",1)]),m("div",dp,[(et(!0),st(Kt,null,ye(t.slides,p=>(et(),st("div",{key:p.pageIndex,class:$t(["spm-card",{active:t.currentActivePage===p.pageIndex}]),onClick:g=>o(p.pageIndex)},[m("div",fp,[m("span",pp,"P"+_t(p.pageIndex),1),m("span",hp,_t(p.frontmatter.layout||"default"),1),m("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Te(g=>n(p),["stop"])},[pt(yt,{name:"settings"})],8,mp)]),m("div",gp,_t(a(p)),1),p.notes?(et(),st("div",vp,[pt(yt,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),m("span",null,_t(p.notes),1)])):Rt("",!0)],10,up))),128))]),s.value?(et(),st("div",{key:0,class:"spm-inspector-modal-mask",onClick:d[1]||(d[1]=Te(p=>s.value=null,["self"]))},[m("div",bp,[pt(lp,{"block-id":s.value.startBlockId,"initial-attrs":r(s.value),onClose:d[0]||(d[0]=p=>s.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Rt("",!0)]))}}),wp=Oe(yp,[["__scopeId","data-v-68b25edd"]]),kp={class:"spm-immersion-header"},xp={class:"spm-immersion-header__left"},_p={class:"spm-immersion-title"},Sp={class:"spm-immersion-header__center"},Cp={class:"spm-immersion-header__actions"},$p=["aria-label"],Ip={class:"spm-immersion-body"},Ap=be({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(t,{emit:i}){const e=t,s=i;function n(){s("update:visible",!1),s("close")}function r(){e.closeOnClickMask&&n()}function l(){s("update:isMaximized",!e.isMaximized),s("toggle-maximize")}function o(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),n())}return(a,c)=>Ie((et(),st("div",{class:$t(["spm-immersion-container",{"is-maximized":t.isMaximized}]),onKeydown:Te(o,["stop"])},[m("div",{class:"spm-immersion-mask",onClick:r}),m("div",{class:$t(["spm-immersion-drawer",{"is-maximized":t.isMaximized}])},[m("div",kp,[m("div",xp,[Rn(a.$slots,"header-left",{},()=>[m("span",_p,_t(t.title),1)])]),m("div",Sp,[Rn(a.$slots,"header-center",{},void 0)]),m("div",Cp,[Rn(a.$slots,"header-actions",{},void 0),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":t.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[pt(yt,{name:t.isMaximized?"minimize":"maximize"},null,8,["name"])],8,$p),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:n},[pt(yt,{name:"close"})])])]),m("div",Ip,[Rn(a.$slots,"default",{},void 0)])],2)],34)),[[Hl,t.visible]])}}),Tp=Oe(Ap,[["__scopeId","data-v-3f1665db"]]),Ep="slidev-config.json",Yi={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806"},Ii=us({...Yi});function Mp(t){if(!t||typeof t!="object")return{...Yi};const i=t;return{enableWebServeJump:!!i.enableWebServeJump,webServeUrl:typeof i.webServeUrl=="string"&&i.webServeUrl.trim()?i.webServeUrl.trim():Yi.webServeUrl}}function Vi(t){if(!t||typeof t!="object")return{...Ii};const i=t;return i.enableWebServeJump!==void 0&&(Ii.enableWebServeJump=!!i.enableWebServeJump),i.webServeUrl!==void 0&&(Ii.webServeUrl=String(i.webServeUrl)),{...Ii}}function Ao(){return{...Ii}}function Zl(t,i,e){const s=(t||Yi.webServeUrl).trim(),n=s.startsWith("http://")||s.startsWith("https://")?s:`http://${s}`,r=(e==null?void 0:e.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(n);let o=l.pathname.replace(/\/+$/,"");return o.endsWith("/stage/build/desktop")||(o=o?`${o}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${o}/`,l.searchParams.set("id",i),e!=null&&e.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",r),l.toString()}catch{const l=e!=null&&e.focus?"&focus=1":"";return`${n.replace(/\/+$/,"")}/stage/build/desktop/?id=${i}${l}&r=${r}`}}const Bp={class:"spm-protyle-drawer"},Dp={class:"spm-protyle-drawer__subbar"},Lp={class:"spm-protyle-drawer__nav"},Op=["title"],Pp={class:"spm-protyle-drawer__actions"},Rp=["aria-label"],zp=["aria-label"],Np=be({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(t,{emit:i}){const e=i,s=t,n=ht(s.blockId),r=ht(s.title||""),l=ht(!1),o=ht(!0),a=ht(!1),c=ht(""),d=Ii,p=ht([]),g=ht(null);let u=null;Ei(()=>s.blockId,S=>{S&&S!==n.value&&(n.value=S,r.value=s.title||"",p.value=[],h(S))}),In(()=>{n.value&&h(n.value)}),bo(()=>{b()});async function k(S){try{const D=await vn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${S}' LIMIT 1`);if(Array.isArray(D)&&D.length>0){const M=D[0];c.value=M.root_id||"";const P=M.id===M.root_id||M.type==="d";a.value=P,o.value=!P,!r.value&&M.content&&(r.value=M.content.trim().slice(0,30));return}}catch(D){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",D)}a.value=!1,o.value=!0}async function h(S,D){if(!g.value||!S)return;b(),await k(S),typeof D=="boolean"&&(o.value=!a.value&&D);let M,P;o.value&&!a.value?(M=["cb-get-all","cb-get-hl","cb-get-focus"],P={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(M=["cb-get-context","cb-get-hl"],P={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{u=new vt.Protyle(s.plugin.app,g.value,{blockId:S,action:M,render:P}),!l.value&&u&&typeof u.disable=="function"&&u.disable()}catch(J){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",J)}}function b(){if(u){try{typeof u.destroy=="function"&&u.destroy()}catch(S){console.warn("[ProtylePeekDrawer] Error destroying protyle:",S)}u=null}g.value&&(g.value.innerHTML="")}function v(){a.value||(o.value=!o.value,h(n.value,o.value))}function y(){l.value=!l.value,u&&(l.value?(typeof u.enable=="function"&&u.enable(),typeof u.focus=="function"&&u.focus()):typeof u.disable=="function"&&u.disable())}function $(){if(n.value)try{vt.openWindow({doc:{id:n.value},alwaysOnTop:!0})}catch(S){console.warn("[ProtylePeekDrawer] openWindow failed:",S)}}function A(){var M;if(!n.value)return;const S=Ao(),D=Zl(S.webServeUrl,n.value,{focus:!a.value});if(typeof window<"u"){const P=ke("electron");(M=P==null?void 0:P.shell)!=null&&M.openExternal?P.shell.openExternal(D).catch(()=>{window.open(D,"_blank")}):window.open(D,"_blank")}e("external-jump",D)}function x(){if(p.value.length>0){const S=p.value.pop();S&&(n.value=S.blockId,r.value=S.title,o.value=S.isFocusMode,a.value=S.isDoc,h(S.blockId,S.isFocusMode))}}function _(S){const D=S.target;if(!D)return;const M=D.closest('[data-type="block-ref"]');if(M){const J=M.getAttribute("data-id");if(J&&J!==n.value){S.preventDefault(),S.stopPropagation(),p.value.push({blockId:n.value,title:r.value||n.value,isFocusMode:o.value,isDoc:a.value}),n.value=J,r.value=M.innerText.trim()||J,h(J);return}}const P=D.closest("a");if(P&&P.href&&P.href.startsWith("siyuan://blocks/")){S.preventDefault(),S.stopPropagation();const J=P.href.replace("siyuan://blocks/","").split("?")[0];J&&J!==n.value&&(p.value.push({blockId:n.value,title:r.value||n.value,isFocusMode:o.value,isDoc:a.value}),n.value=J,r.value=P.innerText.trim()||J,h(J))}}return(S,D)=>(et(),st("div",Bp,[m("div",Dp,[m("div",Lp,[p.value.length>0?(et(),st("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:x},[pt(yt,{name:"arrow-left"}),D[0]||(D[0]=m("span",null,"返回",-1))])):Rt("",!0),m("span",{class:$t(["spm-protyle-badge",{"is-focus":o.value&&!a.value}])},_t(o.value&&!a.value?"思源块聚焦":"思源文档速览"),3),m("span",{class:"spm-protyle-id",title:r.value||n.value},_t(r.value||n.value),9,Op)]),m("div",Pp,[a.value?Rt("",!0):(et(),st("button",{key:0,class:$t(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":o.value}]),"aria-label":o.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:v},[pt(yt,{name:o.value?"focus":"file-text"},null,8,["name"]),m("span",null,_t(o.value?"块聚焦":"展开全文"),1)],10,Rp)),m("button",{class:$t(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:y},[pt(yt,{name:l.value?"edit":"eye"},null,8,["name"]),m("span",null,_t(l.value?"编辑中":"只读"),1)],10,zp),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:$},[pt(yt,{name:"window"}),D[1]||(D[1]=m("span",null,"独立窗口",-1))]),$i(d).enableWebServeJump?(et(),st("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:A},[pt(yt,{name:"external-link"}),D[2]||(D[2]=m("span",null,"外跳",-1))])):Rt("",!0)])]),m("div",{ref_key:"mountEl",ref:g,class:$t(["spm-protyle-mount",{"is-focus-mode":o.value&&!a.value}]),onClick:_},null,2)]))}}),Fp=Oe(Np,[["__scopeId","data-v-7e586ef3"]]),jp={class:"spm-webview-drawer"},Hp={class:"spm-webview-toolbar"},Up={class:"spm-webview-toolbar__nav"},Wp=["disabled"],Vp=["disabled"],Kp=["aria-label"],qp={class:"spm-webview-toolbar__address"},Gp=["aria-label"],Zp={class:"spm-webview-toolbar__actions"},Yp=["aria-label"],Jp={class:"spm-zoom-controller"},Xp=["disabled"],Qp=["disabled"],th={key:1,class:"spm-webview-fallback"},eh=["src"],kr="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",Yl="siyuan-slidev-peek-view-mode";let Jl="desktop";function ih(){if(typeof window<"u"&&window.localStorage)try{const t=window.localStorage.getItem(Yl);if(t==="mobile"||t==="desktop")return t}catch{}return Jl}function nh(t){if(Jl=t,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(Yl,t)}catch{}}const sh=be({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(t,{emit:i}){const e=i,s=t,n=ht(Vl()),r=ht(s.url),l=ht(s.url),o=ht(!1),a=ht(!1),c=ht(!1),d=ht(1),p=ht(!1),g=ht(ih());let u=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const k=St(()=>g.value==="mobile"?kr:u||void 0),h=ht(null),b=ht(null);let v=null,y=null,$=null;Ei(()=>s.url,tt=>{tt&&tt!==r.value&&(r.value=tt,l.value=tt,g.value==="mobile"&&D(!1),h.value&&typeof h.value.loadURL=="function"&&h.value.loadURL(tt))}),Ei(()=>s.visible,tt=>{if(tt)U(),g.value==="mobile"&&D(!1);else if(h.value)try{typeof h.value.stop=="function"&&h.value.stop()}catch{}}),In(()=>{A(),b.value&&typeof ResizeObserver<"u"&&(v=new ResizeObserver(()=>{const tt=h.value;if(tt&&typeof tt.invalidate=="function")try{tt.invalidate()}catch{}}),v.observe(b.value)),y=tt=>{var mt;const gt=tt.message||((mt=tt.error)==null?void 0:mt.message);if(typeof gt=="string"&&gt.includes("Invalid guestInstanceId"))return tt.preventDefault(),tt.stopImmediatePropagation(),!0},window.addEventListener("error",y,!0),$=tt=>{const gt=tt.reason,mt=typeof gt=="string"?gt:gt==null?void 0:gt.message;typeof mt=="string"&&mt.includes("Invalid guestInstanceId")&&tt.preventDefault()},window.addEventListener("unhandledrejection",$)}),bo(()=>{if(x(),v&&(v.disconnect(),v=null),y&&(window.removeEventListener("error",y,!0),y=null),$&&(window.removeEventListener("unhandledrejection",$),$=null),h.value)try{typeof h.value.stop=="function"&&h.value.stop()}catch{}});function A(){const tt=h.value;tt&&(tt.addEventListener("dom-ready",_),tt.addEventListener("did-start-loading",M),tt.addEventListener("did-stop-loading",P),tt.addEventListener("did-navigate",J),tt.addEventListener("did-navigate-in-page",T),tt.addEventListener("new-window",L))}function x(){const tt=h.value;if(tt)try{tt.removeEventListener("dom-ready",_),tt.removeEventListener("did-start-loading",M),tt.removeEventListener("did-stop-loading",P),tt.removeEventListener("did-navigate",J),tt.removeEventListener("did-navigate-in-page",T),tt.removeEventListener("new-window",L)}catch{}}function _(){const tt=h.value;if(tt&&typeof tt.getUserAgent=="function"&&!u)try{const gt=tt.getUserAgent();gt&&!gt.includes("iPhone")&&(u=gt)}catch{}g.value==="mobile"&&D(!1),U(),w()}function S(){const tt=g.value==="mobile"?"desktop":"mobile";g.value=tt,nh(tt),D(!0)}function D(tt=!1){const gt=h.value;if(!gt)return;const mt=g.value==="mobile"?kr:u;if(typeof gt.setUserAgent=="function"&&mt)try{gt.setUserAgent(mt)}catch(G){console.warn("[WebviewPeekDrawer] setUserAgent error:",G)}if(tt&&typeof gt.reload=="function")try{gt.reload()}catch(G){console.warn("[WebviewPeekDrawer] reload error:",G)}}function M(){o.value=!0}function P(){if(o.value=!1,w(),h.value&&typeof h.value.getURL=="function"){const tt=h.value.getURL();tt&&tt!=="about:blank"&&(r.value=tt,l.value=tt)}}function J(tt){tt!=null&&tt.url&&(r.value=tt.url,l.value=tt.url),w()}function T(tt){tt!=null&&tt.url&&(r.value=tt.url,l.value=tt.url),w()}function L(tt){tt&&tt.url&&(tt.preventDefault(),h.value&&typeof h.value.loadURL=="function"&&h.value.loadURL(tt.url))}function w(){const tt=h.value;tt&&(typeof tt.canGoBack=="function"&&(a.value=tt.canGoBack()),typeof tt.canGoForward=="function"&&(c.value=tt.canGoForward()))}function F(){h.value&&typeof h.value.goBack=="function"&&h.value.goBack()}function Q(){h.value&&typeof h.value.goForward=="function"&&h.value.goForward()}function V(){h.value&&typeof h.value.reload=="function"&&h.value.reload()}function it(){let tt=l.value.trim();tt&&(/^https?:\/\//i.test(tt)||(tt=`https://${tt}`),r.value=tt,l.value=tt,h.value&&typeof h.value.loadURL=="function"&&h.value.loadURL(tt))}function U(){const tt=h.value;if(tt&&typeof tt.setZoomFactor=="function")try{tt.setZoomFactor(d.value)}catch(gt){console.warn("[WebviewPeekDrawer] setZoomFactor error:",gt)}}function Y(){d.value=Math.min(2.5,Math.round((d.value+.1)*10)/10),U()}function W(){d.value=Math.max(.5,Math.round((d.value-.1)*10)/10),U()}function z(){d.value=1,U()}function ct(tt){tt.preventDefault(),tt.deltaY<0?Y():tt.deltaY>0&&W()}async function lt(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(r.value),p.value=!0,setTimeout(()=>{p.value=!1},2e3)}catch(tt){console.warn("Copy url failed:",tt)}}function ot(){var gt;const tt=r.value;if(typeof window<"u"){const mt=ke("electron");(gt=mt==null?void 0:mt.shell)!=null&&gt.openExternal?mt.shell.openExternal(tt).catch(()=>{window.open(tt,"_blank")}):window.open(tt,"_blank")}e("external-jump",tt)}return(tt,gt)=>{const mt=ad("webview");return et(),st("div",jp,[m("div",Hp,[m("div",Up,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!a.value,"aria-label":"后退",onClick:F},[pt(yt,{name:"arrow-left"})],8,Wp),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"前进",onClick:Q},[pt(yt,{name:"arrow-right"})],8,Vp),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":o.value?"正在加载...":"刷新页面",onClick:V},[pt(yt,{name:"refresh"})],8,Kp)]),m("div",qp,[Ie(m("input",{"onUpdate:modelValue":gt[0]||(gt[0]=G=>l.value=G),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:_u(it,["enter"])},null,544),[[ns,l.value]]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":p.value?"已复制地址！":"复制网址",onClick:lt},[pt(yt,{name:"copy"})],8,Gp)]),m("div",Zp,[m("button",{class:$t(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":g.value==="mobile"}]),"aria-label":g.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:S},[pt(yt,{name:g.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Yp),m("div",Jp,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:d.value<=.5,onClick:W},[pt(yt,{name:"minus"})],8,Xp),m("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:z},_t(Math.round(d.value*100))+"% ",1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:d.value>=2.5,onClick:Y},[pt(yt,{name:"plus"})],8,Qp)]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:ot},[pt(yt,{name:"external-link"}),gt[1]||(gt[1]=m("span",null,"外跳",-1))])])]),m("div",{ref_key:"containerEl",ref:b,class:$t(["spm-webview-body",{"is-mobile":g.value==="mobile"}]),onWheel:Te(ct,["ctrl"])},[m("div",{class:$t(["spm-webview-viewport",{"is-mobile":g.value==="mobile"}])},[n.value?(et(),Ee(mt,{key:0,ref_key:"webviewRef",ref:h,class:"spm-webview-frame",src:r.value,useragent:k.value,allowpopups:"true",partition:"persist:slidev-peek",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(et(),st("div",th,[m("iframe",{class:"spm-webview-fallback-frame",src:r.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,eh),m("div",{class:"spm-fallback-bar"},[gt[2]||(gt[2]=m("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),m("button",{class:"spm-icon-btn is-primary",onClick:ot}," 在新标签页中打开 ↗ ")])]))],2)],34)])}}}),oh=Oe(sh,[["__scopeId","data-v-40e35375"]]);class rh{constructor(){wt(this,"timers",new Map)}debounce(i,e,s=150){this.cancel(i);const n=setTimeout(()=>{this.timers.delete(i),e()},s);this.timers.set(i,n)}cancel(i){this.timers.has(i)&&(clearTimeout(this.timers.get(i)),this.timers.delete(i))}cancelAll(){for(const i of this.timers.values())clearTimeout(i);this.timers.clear()}hasPending(i){return this.timers.has(i)}}class lh{constructor(i){wt(this,"blockToPageMap",new Map);wt(this,"debounceCtrl",new rh);wt(this,"activeBlockId","");wt(this,"activePageIndex",1);wt(this,"currentDocId","");wt(this,"bridge",null);i&&(this.bridge=i)}setBridge(i){this.bridge=i}setDocId(i){this.currentDocId=i}updateSlidesIndex(i){this.blockToPageMap.clear();for(const e of i){e.startBlockId&&this.blockToPageMap.set(e.startBlockId,e.pageIndex);for(const s of e.blocks)this.blockToPageMap.set(s.id,e.pageIndex)}}getPageByBlockId(i){return this.blockToPageMap.get(i)??null}onCursorFocusBlock(i){if(!i||i===this.activeBlockId)return;this.activeBlockId=i;let e=this.getPageByBlockId(i);!e&&(i===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(e=1),e&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=e,this.bridge&&(this.bridge.navigatePage(e),this.bridge.highlightElement(i))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(i){this.activeBlockId=i;const e=this.getPageByBlockId(i);e&&(this.activePageIndex=e)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Mi(t,i){var r,l;if(!t||typeof document>"u")return!1;const e=(r=globalThis.CSS)!=null&&r.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),s=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`);if(!s){if(i)try{return vt.openTab({app:i,doc:{id:t,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(o){console.warn("[SelectionMirror] openTab fallback failed:",o)}return!1}try{s.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{s.scrollIntoView()}try{(l=s.focus)==null||l.call(s,{preventScroll:!0})}catch{}s.classList.add("protyle-wysiwyg--select");const n=s.style.outline;return s.style.outline="2px solid #3b82f6",s.style.transition="outline 0.3s ease",setTimeout(()=>{s.classList.remove("protyle-wysiwyg--select"),s.style.outline=n},1200),!0}function ie(t){return t?t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function ah(t){if(!t||t.trim()===""||t.trim()==="all")return"all";const i=new Set,e=t.split("|");for(const s of e){const n=s.trim();if(n==="all")return"all";if(n.includes("-")){const[r,l]=n.split("-"),o=parseInt(r,10),a=parseInt(l,10);if(!isNaN(o)&&!isNaN(a))for(let c=Math.min(o,a);c<=Math.max(o,a);c++)i.add(c)}else{const r=parseInt(n,10);isNaN(r)||i.add(r)}}return i}const ch=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function ge(t){if(!t)return"";const i=Lr(t),e=[],s=i.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(r,l)=>{const o=l.toLowerCase();if(!ch.has(o)||/on\w+\s*=|javascript:/i.test(r))return r;if(o==="v-mark"){const a=r.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return r.startsWith("</")?e.push("</mark>"):e.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${e.length-1}%%`}return e.push(r),`%%SAFE_HTML_${e.length-1}%%`});let n=ie(s);return n=n.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(r,l,o,a,c,d,p)=>{const u=(o??a??c??d??p??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${u}</a>`}),n=n.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),n=n.replace(/!\[(.*?)\]\((.*?)\)/g,(r,l,o)=>{const c=/\.gif(?:\?|$)/i.test(o)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${o}" class="${c}" />`}),n=n.replace(/\[(.*?)\]\((.*?)\)/g,(r,l,o)=>{if(o.startsWith("siyuan://blocks/")){const a=o.replace("siyuan://blocks/","").split("?")[0];return`<a href="${o}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${o}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),n=n.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(r,l,o,a)=>`${l}<a href="${o}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${o}</a>`),n=n.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),n=n.replace(/\*(.*?)\*/g,"<em>$1</em>"),n=n.replace(/~~(.*?)~~/g,"<del>$1</del>"),n=n.replace(/`([^`]+)`/g,"<code>$1</code>"),n=n.replace(/%%SAFE_HTML_(\d+)%%/g,(r,l)=>{const o=parseInt(l,10);return e[o]||""}),n}function dh(t,i="pdf-table"){if(t.length<2)return"";const e=t.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),s=e[0];let n=[],r=1;t.length>=2&&e[1].every(a=>/^:?-+:?$/.test(a))&&(n=e[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),r=2);const l=`<thead><tr>${s.map((a,c)=>`<th${n[c]?` style="text-align: ${n[c]}"`:""}>${ge(a)}</th>`).join("")}</tr></thead>`,o=e.slice(r).map(a=>`<tr>${a.map((c,d)=>`<td${n[d]?` style="text-align: ${n[d]}"`:""}>${ge(c)}</td>`).join("")}</tr>`).join("");return`<table class="${i}">${l}<tbody>${o}</tbody></table>`}function Ms(t){return String(t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function uh(t,i="ts"){if(!t)return"";if(t.trim().startsWith("//"))return`<span class="token-comment">${Ms(t)}</span>`;const e=[];function s(r,l){return e.push(`<span class="${r}">${Ms(l)}</span>`),`__TOK_${e.length-1}__`}let n=t.replace(/(['"`])(.*?)\1/g,(r,l,o)=>s("token-string",`${l}${o}${l}`));return n=n.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,r=>s("token-keyword",r)),n=n.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,r=>s("token-type",r)),n=n.replace(/\b(\d+)\b/g,r=>s("token-number",r)),n=Ms(n),n=n.replace(/__TOK_(\d+)__/g,(r,l)=>e[parseInt(l,10)]||""),n}function fh(t,i){if(!t)return null;const e=t.frontmatter||{};if(e.hideInToc===!0||e.hideInToc==="true")return null;let s=(e.title||"").trim(),n=e.level?parseInt(e.level,10):0;if(!s){const r=t.blocks||[];for(const l of r){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){n||(n=a[1].length),s=a[2].trim();break}}}return s?((!n||isNaN(n))&&(n=1),{pageIndex:t.pageIndex||i,title:s,level:n}):null}function ph(t,i=1,e={}){const s=e.minDepth!==void 0?Number(e.minDepth):1,n=e.maxDepth!==void 0?Number(e.maxDepth):1/0,r=[];Array.isArray(t)&&t.forEach((c,d)=>{const p=fh(c,d+1);p&&r.push(p)});const l=[];let o=null;for(const c of r){const d={...c,active:c.pageIndex===i,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),o=d):o?(d.active&&(o.hasActiveChild=!0),o.children.push(d)):l.push(d)}function a(c,d=1){if(d>n)return[];const p=[];for(const g of c){const u=a(g.children,d+1);d>=s?p.push({...g,children:u}):p.push(...u)}return p}return a(l,1)}function hh(t,i=1,e={}){const s=ph(t,i,e),n=e.columns?Number(e.columns):1,r=n>1?` style="column-count: ${n};"`:"",l=e.textSm?" text-sm":"";function o(c,d=1){if(!c||c.length===0)return"";const p=`slidev-toc-list slidev-toc-list-level-${d}`,g=c.map(u=>{const k=u.active?" slidev-toc-item-active":u.hasActiveChild?" slidev-toc-item-parent-active":"",h=u.children&&u.children.length>0?o(u.children,d+1):"";let b=ge(u.title);return b.includes("LaTeX")&&(b=b.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${k}" data-page="${u.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${b}</span>
          </a>
          ${h}
        </li>
      `}).join("");return`<ol class="${p}">${g}</ol>`}const a=o(s,1);return`<div class="slidev-toc${l}"${r}>${a}</div>`}function Xl(t,i,e){var k,h,b,v;const s=t.split(`
`);if(!s.some(y=>/^(\s*)([-*+]|\d+\.)\s+/.test(y)))return null;const r=[],l=[];let o=!1;for(let y=0;y<s.length;y++){const $=s[y];if(!$.trim())continue;const A=$.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(A){const D=A[1].length,M=Math.floor(D/2);l.push({type:"task",level:M,checked:A[2].toLowerCase()==="x",text:A[3],media:[]});continue}const x=$.match(/^(\s*)[-*+]\s+(.*)$/);if(x){const D=x[1].length,M=Math.floor(D/2);l.push({type:"unordered",level:M,text:x[2],media:[]});continue}const _=$.match(/^(\s*)\d+\.\s+(.*)$/);if(_){l.length===0&&(o=!0);const D=_[1].length,M=Math.floor(D/2);l.push({type:"ordered",level:M,text:_[2],media:[]});continue}const S=$.trim();if(!(!S||/^\{:.*?\}$/.test(S)))if(l.length>0){const D=S.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(D){const J=/\.gif(?:\?|$)/i.test(D[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${ie(D[1])}" src="${D[2]}" class="${J}" /></div>`);continue}if(S.match(/^<img\b[\s\S]*?\/?>$/i)){const P=S.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${P}</div>`);continue}if(/<video\b/i.test(S)){let P=S;if(!/<\/video>/i.test(P))for(;y+1<s.length&&!/<\/video>/i.test(P);)y++,P+=" "+s[y].trim();const J=((k=e==null?void 0:e.attributes)==null?void 0:k["custom-slidev-autoplay"])==="true"||/autoplay/i.test(P),T=((h=e==null?void 0:e.attributes)==null?void 0:h["custom-slidev-loop"])==="true"||/loop/i.test(P),L=((b=e==null?void 0:e.attributes)==null?void 0:b["custom-slidev-muted"])==="true"||J||/muted/i.test(P),w=((v=e==null?void 0:e.attributes)==null?void 0:v["custom-slidev-controls"])==="false",F=P.match(/\bsrc=["']([^"']+)["']/i),Q=F?F[1]:"",V=['class="slide-video-player"'];w||V.push("controls"),J&&(V.push("autoplay"),V.push("playsinline")),T&&V.push("loop"),L&&V.push("muted"),V.push('preload="metadata"'),Q&&V.push(`src="${Q}"`);const it=P.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let U=it?it[1].trim():"";!U&&Q&&(U=`<source src="${Q}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${J?"true":"false"}" data-muted="${L?"true":"false"}"><video ${V.join(" ")}>${U}</video></div>`);continue}l[l.length-1].text+=`
`+S}else r.push(S)}if(l.length===0)return null;function a(y){if(!y)return"";const $=y.split(`
`).map(D=>D.trim()).filter(Boolean);if($.length===0)return"";if(!$.some(D=>/^#{1,6}\s+/.test(D)))return ge($.join(" "));const x=[];let _=[];const S=()=>{if(_.length>0){const D=_.join(" ");x.push(`<p class="slide-list-item-desc">${ge(D)}</p>`),_=[]}};for(const D of $){const M=D.match(/^(#{1,6})\s+(.*)$/);if(M){S();const P=M[1].length,J=M[2].trim();x.push(`<h${P} class="slide-list-item-title">${ge(J)}</h${P}>`)}else _.push(D)}return S(),x.join(`
`)}function c(y){if(y.length===0)return"";const $=[];let A=[];const x=S=>{if(A.length>0){const D=A.join(" "),M=S?"slide-list-item-title":"slide-list-item-desc";$.push(`<p class="${M}">${ge(D)}</p>`),A=[]}};let _=!0;for(const S of y){const D=S.match(/^(#{1,6})\s+(.*)$/);if(D){x(_);const M=D[1].length,P=D[2].trim();$.push(`<h${M} class="slide-list-item-title">${ge(P)}</h${M}>`),_=!1}else A.push(S)}return x(_),$.join(`
`)+($.length>0?`
`:"")}const d=o?"ol":"ul",p=o?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered",g=l.map(y=>{const $=a(y.text),A=y.media&&y.media.length>0?`
${y.media.join(`
`)}`:"",x=y.level||0,_=x>0?` style="margin-left:${(x*1.25).toFixed(2)}em;${y.type==="unordered"?`list-style-type:${x%2===1?"circle":"square"} !important;`:""}"`:"",S=x>0?" slide-list-item--nested":"";if(y.type==="task"){const M=y.checked?' checked=""':"";return`<li class="pdf-task-item${S}"${_}><label><input type="checkbox" disabled=""${M}/> <span>${$}</span></label>${A}</li>`}return`<li${S?` class="${S.trim()}"`:""}${_}>${$}${A}</li>`}).join(`
`);return`${c(r)}<${d} class="${p}">
${g}
</${d}>`}function Re(t,i){var b,v,y,$,A,x,_,S,D;let e="",s="",n="";const r=[];(b=t.motion)!=null&&b.preset&&t.motion.preset!=="none"&&(e=` slidev-motion-${t.motion.preset.toLowerCase()}`,typeof t.motion.duration=="number"&&t.motion.duration>0&&r.push(`--motion-duration:${t.motion.duration}ms`),typeof t.motion.delay=="number"&&t.motion.delay>0&&r.push(`--motion-delay:${t.motion.delay}ms`));const l=((v=t.attributes)==null?void 0:v.style)||"";l&&(r.push(l),n=" slide-styled-block"),r.length>0&&(s=` style="${ie(r.join(";"))}"`);const a=`pdf-block${e}${n}`,c=(t.rawMarkdown||t.content||"").trim();if(!c)return`<div class="${a}"${s}></div>`;if(c.includes('class="slidev-block-ref"')||c.includes('class="slidev-ref-tag"'))return`<div class="${a}"${s}>${c}</div>`;if(c.startsWith("$$")&&c.endsWith("$$")){const M=c.slice(2,-2).trim();return`<div class="${a} katex-display-container"${s}><div class="katex-display font-math"><em>${ie(M)}</em></div></div>`}const d=c.match(/^(#{1,6})\s+(.*)$/);if(d){const M=d[1].length,P=ge(d[2]);return`<div class="${a}"${s}><h${M}>${P}</h${M}></div>`}if(c.startsWith(":::")){const M=c.split(`
`),J=M[0].replace(/^:::\s*/,"").trim()||"info",T=M.slice(1,M[M.length-1].startsWith(":::")?-1:void 0).join(`
`),L="pdf-callout";return`<div class="${a}"${s}><div class="${L} ${L}--${J}"><div class="${L}-title">${J.toUpperCase()}</div><div class="${L}-body">${ge(T)}</div></div></div>`}if(c.startsWith("<<<")){const J=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((F,Q)=>`<span class="code-line shiki-focus"><span class="line-no">${Q+1}</span><span class="line-content">${uh(F,"ts")}</span></span>`).join(`
`),T="pdf-code shiki-container",L=((y=t.attrs)==null?void 0:y["custom-slidev-max-height"])||t.maxHeight||"",w=L?` style="max-height:${ie(L)};overflow-y:auto;"`:"";return`<div class="${a}"${s}><pre class="${T}"${w}><span class="lang-badge">TS</span><code>${J}</code></pre></div>`}if(c.startsWith("<style")||c.startsWith("<!-- Inline style -->")||c.startsWith(`<!--
Notes`))return"";if(c.startsWith("```")){const M=c.split(`
`),P=M[0].slice(3).trim(),J=P.match(/^([^\s{\[]+)/),T=J?J[1]:"",L=P.match(/\[([^\]]+)\]/),w=L?L[1]:"",F=P.includes("twoslash"),Q=t.shikiLines||(($=P.match(/\{([^}]+)\}/))==null?void 0:$[1])||"",V=ah(Q),it=M.length>2?M[M.length-1]==="```"?M.slice(1,-1):M.slice(1):[c.slice(3).replace(/```$/,"")],U="pdf-code shiki-container",Y=w?`${U} has-filename`:U,W=V!=="all",z=it.map((gt,mt)=>{const G=mt+1,ut=V==="all"||V.has(G)?"code-line shiki-focus":W?"code-line shiki-dimmed":"code-line";let E=ie(gt);return F&&gt.includes("doubled.value = 2")?(E=E.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${ut}"><span class="line-no">${G}</span><span class="line-content">${E}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${ut}"><span class="line-no">${G}</span><span class="line-content">${E}</span></span>`}).join(`
`),ct=T?`<span class="lang-badge">${ie(T)}</span>`:"",lt=w?`<span class="code-filename">${ie(w)}</span>`:"",ot=((A=t.attrs)==null?void 0:A["custom-slidev-max-height"])||t.maxHeight||"",tt=ot?` style="max-height:${ie(ot)};overflow-y:auto;"`:"";return`<div class="${a}"${s}><pre class="${Y}"${tt}>${lt}${ct}<code>${z}</code></pre></div>`}if(c.includes("|")&&c.split(`
`).filter(M=>M.trim().startsWith("|")).length>=2){const M=c.split(`
`).filter(J=>J.trim().startsWith("|")),P=dh(M,i==null?void 0:i.tableClassName);return`<div class="${a}"${s}>${P}</div>`}if(c.startsWith("> "))return`<div class="${a}"${s}><blockquote class="pdf-quote"><p>${ge(c.slice(2))}</p></blockquote></div>`;const p=/<video\b/i.test(c)||t.type==="video"||t.type==="NodeVideo",g=/^(\s*)([-*+]|\d+\.)\s+/m.test(c),u=/(?:^|\n)\s*#{1,6}\s+/.test(c);if(p&&!g&&!u&&!c.includes(`
`)){const M=((x=t.attributes)==null?void 0:x["custom-slidev-autoplay"])==="true"||/autoplay/i.test(c),P=((_=t.attributes)==null?void 0:_["custom-slidev-loop"])==="true"||/loop/i.test(c),J=((S=t.attributes)==null?void 0:S["custom-slidev-muted"])==="true"||M||/muted/i.test(c),T=((D=t.attributes)==null?void 0:D["custom-slidev-controls"])==="false",L=c.match(/\bsrc=["']([^"']+)["']/i),w=L?L[1]:"",F=['class="slide-video-player"'];T||F.push("controls"),M&&(F.push("autoplay"),F.push("playsinline")),P&&F.push("loop"),J&&F.push("muted"),F.push('preload="metadata"'),w&&F.push(`src="${w}"`);const Q=c.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let V=Q?Q[1].trim():"";return!V&&w&&(V=`<source src="${w}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${a} ${a}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${M?"true":"false"}" data-muted="${J?"true":"false"}"${s}><video ${F.join(" ")}>${V}</video></div>`}const k=c.match(/^!\[(.*?)\]\((.*?)\)$/);if(k)return`<div class="${a} ${a}--image slide-media-block slide-media-container"${s}><img alt="${ie(k[1])}" src="${k[2]}" class="pdf-image slide-media-img" /></div>`;const h=Xl(c,i,t);if(h)return`<div class="${a} pdf-list-item"${s}>${h}</div>`;if(/<(?:Toc|toc)\b/i.test(c)&&!c.startsWith("```")){const M=c.match(/minDepth=["']?(\d+)["']?/i),P=c.match(/maxDepth=["']?(\d+)["']?/i),J=c.match(/columns=["']?(\d+)["']?/i);return`<div class="${a}"${s}>${hh([],1,{minDepth:M?parseInt(M[1],10):1,maxDepth:P?parseInt(P[1],10):1/0,columns:J?parseInt(J[1],10):1,textSm:c.includes("text-sm")})}</div>`}if(c.includes(`
`)||u){const M=mh(c,i,t);if(M)return`<div class="${a}"${s}>${M}</div>`}return`<div class="${a}"${s}><p>${ge(c)}</p></div>`}function mh(t,i,e){const s="pdf-block",n=t.split(/\r?\n/),r=[];let l=[];for(let a=0;a<n.length;a++){const c=n[a],d=c.trim();if(/^#{1,6}\s+/.test(d)){l.length>0&&(r.push(l.join(`
`)),l=[]),r.push(d);continue}if(!d){l.length>0&&(r.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(d)){l.length>0&&(r.push(l.join(`
`)),l=[]),r.push(d);continue}if(/<video\b/i.test(d)){l.length>0&&(r.push(l.join(`
`)),l=[]);let p=d;if(!/<\/video>/i.test(p))for(;a+1<n.length&&!/<\/video>/i.test(p);)a++,p+=`
`+n[a];r.push(p);continue}l.push(c)}return l.length>0&&r.push(l.join(`
`)),r.map(a=>{var u,k,h,b;const c=a.trim();if(!c)return"";const d=c.match(/^(#{1,6})\s+(.*)$/);if(d){const v=d[1].length;return`<h${v} class="slide-list-item-title">${ge(d[2].trim())}</h${v}>`}const p=c.match(/^!\[(.*?)\]\((.*?)\)$/);if(p){const y=/\.gif(?:\?|$)/i.test(p[2])?"list-item-gif":"pdf-image slide-media-img";return`<div class="${s} ${s}--image slide-media-block slide-media-container slide-list-media"><img alt="${ie(p[1])}" src="${p[2]}" class="${y}" /></div>`}if(/<video\b/i.test(c)){const v=((u=e==null?void 0:e.attributes)==null?void 0:u["custom-slidev-autoplay"])==="true"||/autoplay/i.test(c),y=((k=e==null?void 0:e.attributes)==null?void 0:k["custom-slidev-loop"])==="true"||/loop/i.test(c),$=((h=e==null?void 0:e.attributes)==null?void 0:h["custom-slidev-muted"])==="true"||v||/muted/i.test(c),A=((b=e==null?void 0:e.attributes)==null?void 0:b["custom-slidev-controls"])==="false",x=c.match(/\bsrc=["']([^"']+)["']/i),_=x?x[1]:"",S=['class="slide-video-player"'];A||S.push("controls"),v&&S.push("autoplay playsinline"),y&&S.push("loop"),$&&S.push("muted"),S.push('preload="metadata"'),_&&S.push(`src="${_}"`);const D=c.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let M=D?D[1].trim():"";return!M&&_&&(M=`<source src="${_}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${s} ${s}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${v?"true":"false"}" data-muted="${$?"true":"false"}"><video ${S.join(" ")}>${M}</video></div>`}const g=Xl(c,i,e);return g||`<p class="slide-list-item-desc">${ge(c)}</p>`}).filter(Boolean).join(`
`)}function gh(t,i){var r,l,o,a;const e=((r=t.frontmatter)==null?void 0:r.layout)||"default",n=(t.blocks||[]).filter(c=>c.slot!=="slot-divider-right");if(e==="two-cols"){const c=n.some(y=>y.slot==="right");let d=[],p=[];if(c)d=n.filter(y=>y.slot!=="right"),p=n.filter(y=>y.slot==="right");else{const y=Math.ceil(n.length/2);d=n.slice(0,y),p=n.slice(y)}const g=d.map(y=>Re(y,i)).join(`
`),u=p.map(y=>Re(y,i)).join(`
`),k="pdf-two-cols-wrapper layout-two-cols-grid",h=(l=t.frontmatter)!=null&&l.layoutClass?` ${t.frontmatter.layoutClass}`:"";return`
      <div class="${k}${h}">
        <div class="pdf-col pdf-col--left">${g}</div>
        <div class="pdf-col pdf-col--right">${u}</div>
      </div>
    `}if(e==="two-cols-header"){let c=[];const d=n.filter(y=>y.slot==="header");if(d.length>0)c=d;else if(n.length>0){const y=n.find($=>$.type==="h"&&(!$.slot||$.slot==="default"));y&&(c=[y])}const p=n.filter(y=>!c.includes(y)),g=p.filter(y=>y.slot==="right"||y.slot==="col-2"),u=p.filter(y=>!g.includes(y)),k=y=>{const $=y.filter(A=>!!(A.rawMarkdown||A.content||"").trim());if($.length>0){const A=$[0],x=(A.rawMarkdown||A.content||"").trim();(Ki(A)||/^(?:[-*+]|\d+\.)\s+/.test(x))&&(A.rawMarkdown=Fs(A.rawMarkdown||A.content||""),A.content=A.rawMarkdown)}return $.map(A=>Re(A,i)).join(`
`)},h=c.map(y=>Re(y,i)).join(`
`),b=k(u),v=k(g);return`
      <div class="layout-two-cols-header-container">
        <div class="layout-header-section">${h}</div>
        <div class="pdf-two-cols-wrapper layout-two-cols-grid">
          <div class="pdf-col pdf-col--left">${b}</div>
          <div class="pdf-col pdf-col--right">${v}</div>
        </div>
      </div>
    `}if(e==="three-cols-header"){let c=[];const d=n.filter(A=>A.slot==="header");if(d.length>0)c=d;else if(n.length>0){const A=n.find(x=>x.type==="h"&&(!x.slot||x.slot==="default"));A&&(c=[A])}const p=n.filter(A=>!c.includes(A)),{col1:g,col2:u,col3:k}=Pr(p),h=A=>{const x=A.filter(_=>!!(_.rawMarkdown||_.content||"").trim());if(x.length>0){const _=x[0],S=(_.rawMarkdown||_.content||"").trim();(Ki(_)||/^(?:[-*+]|\d+\.)\s+/.test(S))&&(_.rawMarkdown=Fs(_.rawMarkdown||_.content||""),_.content=_.rawMarkdown)}return x.map(_=>Re(_,i)).join(`
`)},b=c.map(A=>Re(A,i)).join(`
`),v=h(g),y=h(u),$=h(k);return`
      <div class="layout-three-cols-header-container">
        <div class="layout-header-section">${b}</div>
        <div class="pdf-three-cols-wrapper layout-three-cols-grid">
          <div class="pdf-col pdf-col--1">${v}</div>
          <div class="pdf-col pdf-col--2">${y}</div>
          <div class="pdf-col pdf-col--3">${$}</div>
        </div>
      </div>
    `}if(e==="image-right"||e==="image-left"){const c=e==="image-right",d=n.map(h=>Re(h,i)).join(`
`),p=((o=t.frontmatter)==null?void 0:o.image)||((a=t.frontmatter)==null?void 0:a.background)||"",g=`<div class="pdf-image-col" style="background-image:url('${ie(p)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${ie(p)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,u=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${d}</div>`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:1fr 1fr;grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${c?`${u}
${g}`:`${g}
${u}`}
      </div>
    `}return e==="fact"?`<div class="layout-fact-container">${n.map(d=>Re(d,i)).join(`
`)}</div>`:e==="cover"?`<div class="layout-cover-container">${n.map(d=>Re(d,i)).join(`
`)}</div>`:n.map(c=>Re(c,i)).join(`
`)}function Ql(t,i){const e="Slidev 演示文稿";let s=t.slides;const n=JSON.stringify(s),r=JSON.stringify(t.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${ie(e)}</title>
  <style>
    ${un(i==null?void 0:i.customInlineStyles)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      overflow-y: hidden !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(t.docId)},
      slides: ${n},
      config: ${r}
    };
  <\/script>
</head>
<body>
  <div id="app">
    <div class="slide-viewport slidev-theme-${t.config.theme||"default"}" id="viewport" data-slidev-theme="${t.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">⛶ 全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block) {
        const div = document.createElement("div");
        div.className = "slide-block";
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);

        if (md.startsWith("### ")) div.innerHTML = "<h3>" + md.slice(4) + "</h3>";
        else if (md.startsWith("## ")) div.innerHTML = "<h2>" + md.slice(3) + "</h2>";
        else if (md.startsWith("# ")) div.innerHTML = "<h1>" + md.slice(2) + "</h1>";
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            let pL = [];
            const flushLeadP = (isF) => {
              if (pL.length > 0) {
                let txt = pL.join(" ").replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                lParts.push('<p class="' + (isF ? "slide-list-item-title" : "slide-list-item-desc") + '">' + txt + '</p>');
                pL = [];
              }
            };
            let isF = true;
            for (const l of leadLines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushLeadP(isF);
                const lvl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                isF = false;
              } else {
                pL.push(l);
              }
            }
            flushLeadP(isF);
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = it.text.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.join(" ").replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              div.innerHTML = "<p>" + html + "</p>";
            }
          }
        }
        return div;
      }

      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          for (const b of leftList) leftCol.appendChild(renderBlock(b));
          for (const b of rightList) rightCol.appendChild(renderBlock(b));
          container.appendChild(leftCol);
          container.appendChild(rightCol);
        } else if (slide.frontmatter?.layout === "two-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-two-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-two-cols-wrapper layout-two-cols-grid";
          const leftCol = document.createElement("div");
          leftCol.className = "pdf-col pdf-col--left";
          const rightCol = document.createElement("div");
          rightCol.className = "pdf-col pdf-col--right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          let leftList = [];
          let rightList = [];
          for (const b of rem) {
            if (b.slot === "right" || b.slot === "col-2") rightList.push(b);
            else leftList.push(b);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of leftList) leftCol.appendChild(renderBlock(b));
          for (const b of rightList) rightCol.appendChild(renderBlock(b));
          gridDiv.appendChild(leftCol);
          gridDiv.appendChild(rightCol);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "three-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-three-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-three-cols-wrapper layout-three-cols-grid";
          const col1 = document.createElement("div");
          col1.className = "pdf-col pdf-col--1";
          const col2 = document.createElement("div");
          col2.className = "pdf-col pdf-col--2";
          const col3 = document.createElement("div");
          col3.className = "pdf-col pdf-col--3";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          let c1 = [], c2 = [], c3 = [];
          const hasExplicitCols = rem.some(b => b.slot === "col-1" || b.slot === "col-2" || b.slot === "col-3" || b.slot === "center" || b.slot === "left" || b.slot === "right");
          if (hasExplicitCols) {
            c2 = rem.filter(b => b.slot === "col-2" || b.slot === "center");
            c3 = rem.filter(b => b.slot === "col-3" || b.slot === "right");
            c1 = rem.filter(b => !c2.includes(b) && !c3.includes(b));
          } else if (rem.length >= 3) {
            const count1 = Math.ceil(rem.length / 3);
            const count2 = Math.ceil((rem.length - count1) / 2);
            c1 = rem.slice(0, count1);
            c2 = rem.slice(count1, count1 + count2);
            c3 = rem.slice(count1 + count2);
          } else if (rem.length === 2) {
            c1 = [rem[0]];
            c2 = [rem[1]];
            c3 = [];
          } else if (rem.length === 1) {
            const lines = (rem[0].rawMarkdown || rem[0].content || "").trim().split(/\r?
/);
            const itemStartIndices = [];
            for (let i = 0; i < lines.length; i++) {
              if (/^[ 	]*[-*+]s+|^[ 	]*d+.s+/.test(lines[i])) itemStartIndices.push(i);
            }
            if (itemStartIndices.length >= 3) {
              const count1 = Math.ceil(itemStartIndices.length / 3);
              const count2 = Math.ceil((itemStartIndices.length - count1) / 2);
              const items1 = lines.slice(itemStartIndices[0], itemStartIndices[count1]).join("
");
              const items2 = lines.slice(itemStartIndices[count1], itemStartIndices[count1 + count2]).join("
");
              const items3 = lines.slice(itemStartIndices[count1 + count2]).join("
");
              c1 = [{ ...rem[0], rawMarkdown: items1, content: items1 }];
              c2 = [{ ...rem[0], id: rem[0].id + "-col2", rawMarkdown: items2, content: items2 }];
              c3 = [{ ...rem[0], id: rem[0].id + "-col3", rawMarkdown: items3, content: items3 }];
            } else {
              c1 = rem;
            }
          } else {
            c1 = rem;
          }
          c1 = cleanColList(c1);
          c2 = cleanColList(c2);
          c3 = cleanColList(c3);
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of c1) col1.appendChild(renderBlock(b));
          for (const b of c2) col2.appendChild(renderBlock(b));
          for (const b of c3) col3.appendChild(renderBlock(b));
          gridDiv.appendChild(col1);
          gridDiv.appendChild(col2);
          gridDiv.appendChild(col3);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of (slide.blocks || [])) {
            contentCol.appendChild(renderBlock(block));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          if (isImageRight) {
            container.appendChild(contentCol);
            container.appendChild(imgCol);
          } else {
            container.appendChild(imgCol);
            container.appendChild(contentCol);
          }
        } else {
          for (const block of (slide.blocks || [])) {
            container.appendChild(renderBlock(block));
          }
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => renderSlide(currentIndex - 1));
      btnNext.addEventListener("click", () => renderSlide(currentIndex + 1));
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        if (e.key === "ArrowRight" || e.key === " ") renderSlide(currentIndex + 1);
        if (e.key === "ArrowLeft") renderSlide(currentIndex - 1);
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          renderSlide(currentIndex - 1);
        } else {
          renderSlide(currentIndex + 1);
        }
      });

      renderSlide(0);
      updateScale();
    })();
  <\/script>
</body>
</html>`}function ta(t,i){if(typeof document>"u")return!1;const e=new Blob([i],{type:"text/html;charset=utf-8"}),s=URL.createObjectURL(e),n=document.createElement("a");return n.href=s,n.download=t.endsWith(".html")?t:`${t}.html`,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(s),!0}function vh(t){switch(t){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function bh(t,i){const e="Slidev 演示讲义",s="16:9",n="light",r=vh(s),l=t.slides.map((o,a)=>{const c=o.frontmatter.layout||"default",d=o.frontmatter.spacing,p=d&&d!=="inherit"?d:t.config.spacing||"normal",g=gh(o),u=`${a+1} / ${t.slides.length}`;return`
      <section class="pdf-slide-page layout-${c} theme-${n} spacing-${p}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${ie(e)}</span>
          ${`<span class="pdf-page-badge">P. ${u}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${g}
        </div>
        ${o.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${ie(o.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${ie(e)} - 高保真讲义</title>
  <style>
    ${un(i==null?void 0:i.customInlineStyles)}

    @page {
      ${r}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
    }
  </style>
</head>
<body>
  ${l}
</body>
</html>`}function ea(t,i){var n;if(typeof window>"u"||typeof document>"u")return!1;const e=bh(t,i);try{const r=document.createElement("iframe");r.style.position="fixed",r.style.right="0",r.style.bottom="0",r.style.width="0",r.style.height="0",r.style.border="none",r.style.visibility="hidden",document.body.appendChild(r);const l=(n=r.contentWindow)==null?void 0:n.document;if(l)return l.open(),l.write(e),l.close(),setTimeout(()=>{var o,a;try{(o=r.contentWindow)==null||o.focus(),(a=r.contentWindow)==null||a.print()}finally{setTimeout(()=>{r.remove()},2e3)}},350),!0}catch(r){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",r)}const s=window.open("","_blank");return s?(s.document.write(e),s.document.close(),s.focus(),setTimeout(()=>{s.print(),s.close()},350),!0):!1}const yh={class:"spm-slidev-preview-tab"},wh={class:"spm-slidev-tab__toolbar"},kh={class:"spm-slidev-tab__actions"},xh=["disabled"],_h={class:"spm-page-badge"},Sh=["disabled"],Ch=["aria-label"],$h=["aria-label"],Ih=["src"],Ah=be({__name:"SlidevPreviewTab",setup(t,{expose:i}){const e=Qe("plugin"),s=Qe("sandboxBridge",new $o),n=new lh(s),r=new Ru,l=ht("web-sandbox"),o=ht(3030),a=ht(null),c=ht(!1),d=ht(null),p=ht(1),g=ht(1),u=ht([]),k=ht(!1),h=ht(!1),b=ht(!1),v=ht("siyuan"),y=ht(""),$=ht(""),A=ht(""),x=ht(!1),_=ht(!1),S=ht(""),D=ht("/plugins/siyuan-slidev/slidev-client/index.html");let M=null,P=null,J=null,T=null,L=null,w=null,F=null;In(()=>{d.value&&(s.attach(d.value),r.nativeBridge.attach(d.value)),M=s.onSlideChanged((G,rt)=>{p.value=G,g.value=rt}),P=s.onBlockClicked((G,rt)=>{p.value=rt,n.setActiveBlockId(G),e&&typeof e.handleBlockClickedFromSlide=="function"?e.handleBlockClickedFromSlide(G,rt):Mi(G,e==null?void 0:e.app)}),J=s.onOpenInEditor((G,rt)=>{p.value=rt,n.setActiveBlockId(G),Mi(G,e==null?void 0:e.app)}),T=r.nativeBridge.onPageChanged((G,rt)=>{p.value=G,g.value=rt}),L=s.onOpenPeekDrawer(async G=>{const rt=Ao();if(G.peekType==="siyuan"&&rt.enableWebServeJump){let ut=!1;if(F&&F.docId===G.target)ut=!0;else if(F&&F.slides&&F.slides.some(E=>{var R;return(R=E.blocks)==null?void 0:R.some(f=>f.id===G.target)}))ut=!1;else try{const E=await vn(`SELECT id, root_id, type FROM blocks WHERE id = '${G.target}' LIMIT 1`);E&&E.length>0&&(ut=E[0].type==="d"||E[0].id===E[0].root_id)}catch(E){console.warn("[SlidevPreviewTab] detect block type failed:",E)}v.value="web",x.value=!0,$.value=Zl(rt.webServeUrl,G.target,{focus:!ut}),A.value=G.title||`${ut?"思源文档":"思源块"}: ${G.target.slice(0,8)}`,h.value=!0,s.freezeKeyboardNav(!0)}else v.value=G.peekType,G.peekType==="siyuan"?(y.value=G.target,A.value=G.title||`块速览: ${G.target.slice(0,8)}`):(x.value=!0,$.value=G.target,A.value=G.title||G.target),h.value=!0,s.freezeKeyboardNav(!0)}),w=s.onRequestToggleFullscreen(()=>{ot()}),typeof document<"u"&&document.addEventListener("fullscreenchange",lt)}),yo(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",lt),L&&L(),w&&w(),M&&M(),P&&P(),J&&J(),T&&T(),s.detach(),n.destroy(),r.destroy()});async function Q(){if(l.value==="web-sandbox"){if(!F){vt.showMessage("请先在主编辑区打开演示文档");return}vt.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const G=await r.startProMode(F,Os);if(!G.success){vt.showMessage(`无法启动官方 Pro 模式：${G.error}`);return}l.value="pro-cli",o.value=G.port||3030,D.value=G.url,d.value&&r.nativeBridge.attach(d.value),vt.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${o.value})`)}else r.stopProMode(),l.value="web-sandbox",D.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&s.attach(d.value),vt.showMessage("已切回内置高保真沙箱")}function V(){_.value=!_.value,_.value?S.value=(F==null?void 0:F.docId)||"":(S.value="",W())}function it(){p.value>1&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(p.value-1):s.navigatePage(p.value-1))}function U(){p.value<g.value&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(p.value+1):s.navigatePage(p.value+1))}function Y(G){p.value=G,l.value==="pro-cli"?r.nativeBridge.navigateToPage(G):s.navigatePage(G)}function W(){e&&typeof e.compileCurrentDocument=="function"?e.compileCurrentDocument():e!=null&&e.eventBus&&typeof e.eventBus.emit=="function"&&e.eventBus.emit("slidev:request-compile")}function z(){h.value=!1,s.freezeKeyboardNav(!1)}function ct(){z()}function lt(){typeof document<"u"&&(c.value=!!document.fullscreenElement,s.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function ot(){const G=a.value||d.value;G&&(document.fullscreenElement?document.exitFullscreen().then(()=>{s.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):G.requestFullscreen().then(()=>{s.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function tt(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function gt(){if(!F){vt.showMessage("请先在主编辑区打开幻灯片文档");return}const G=Ql(F);ta("presentation.html",G)&&vt.showMessage("已开始下载单文件离线 HTML 演示包")}function mt(){if(!F){vt.showMessage("请先在主编辑区打开幻灯片文档");return}ea(F)&&vt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({updateDocument(G,rt){_.value&&S.value&&rt&&rt!==S.value||(F=G,_.value&&!S.value&&(S.value=G.docId),u.value=G.slides,g.value=G.slides.length,n.setDocId(G.docId),n.updateSlidesIndex(G.slides),l.value==="pro-cli"?r.scaffolder.scaffold(G,Os).catch(()=>{}):s.updateSlides(G.slides,G.config,G.fullMarkdown,G.customThemeCss))},navigateToBlock(G){n.onCursorFocusBlock(G)},isPinned:_,pinnedDocId:S,engineMode:l,toggleEngineMode:Q}),(G,rt)=>(et(),st("div",yh,[m("div",wh,[rt[4]||(rt[4]=m("div",{class:"spm-slidev-tab__title"},[m("svg",{class:"spm-slidev-tab__icon","aria-hidden":"true"},[m("use",{"xlink:href":"#iconSlidev"})]),m("span",null,"Slidev 演示预览")],-1)),m("div",kh,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value<=1,"aria-label":"上一页",onClick:it},[pt(yt,{name:"chevron-left"})],8,xh),m("span",_h,_t(p.value)+" / "+_t(g.value||1),1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value>=g.value,"aria-label":"下一页",onClick:U},[pt(yt,{name:"chevron-right"})],8,Sh),m("button",{class:$t(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":_.value}]),"aria-label":_.value?"已锁定当前文档（点击解除）："+S.value:"点击锁定当前文档（不随主编辑区切换）",onClick:V},[pt(yt,{name:"pin"}),m("span",null,_t(_.value?"已锁定":"跟随"),1)],10,Ch),m("button",{class:$t(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+o.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:Q},[pt(yt,{name:"step"}),m("span",null,_t(l.value==="pro-cli"?"Pro ("+o.value+")":"沙箱"),1)],10,$h),rt[3]||(rt[3]=m("span",{class:"spm-toolbar-divider"},null,-1)),m("button",{class:$t(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":k.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:rt[0]||(rt[0]=ut=>k.value=!k.value)},[pt(yt,{name:"outline"})],2),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:tt},[pt(yt,{name:"presenter"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:gt},[pt(yt,{name:"export-html"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:mt},[pt(yt,{name:"export-pdf"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:W},[pt(yt,{name:"refresh"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:ot},[pt(yt,{name:"fullscreen"})])])]),m("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container"},[m("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:D.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Ih),pt(Tp,{visible:h.value,"onUpdate:visible":rt[1]||(rt[1]=ut=>h.value=ut),"is-maximized":b.value,"onUpdate:isMaximized":rt[2]||(rt[2]=ut=>b.value=ut),title:A.value,onClose:z},{default:fl(()=>[v.value==="siyuan"&&y.value?(et(),Ee(Fp,{key:0,"block-id":y.value,title:A.value,plugin:$i(e),onExternalJump:ct},null,8,["block-id","title","plugin"])):Rt("",!0),x.value?Ie((et(),Ee(oh,{key:1,visible:h.value&&v.value==="web",url:$.value,title:A.value,onExternalJump:ct},null,8,["visible","url","title"])),[[Hl,v.value==="web"]]):Rt("",!0)]),_:1},8,["visible","is-maximized","title"])],512),k.value&&u.value.length>0?(et(),Ee(wp,{key:0,slides:u.value,"current-active-page":p.value,onNavigate:Y,onRefresh:W},null,8,["slides","current-active-page"])):Rt("",!0)]))}}),Th=Oe(Ah,[["__scopeId","data-v-2622f6d8"]]),Eh={class:"spm-section spm-section--page"},Mh={class:"spm-section-header"},Bh={class:"spm-card-control"},Dh={class:"spm-control-header"},Lh={class:"spm-control-title-group"},Oh={class:"spm-control-title"},Ph={class:"spm-segmented-group"},Rh={class:"spm-card-control"},zh={class:"spm-control-header"},Nh={class:"spm-control-title-group"},Fh={class:"spm-control-title"},jh={class:"spm-quick-chips"},Hh=["onClick"],Uh=["value"],Wh={key:0,class:"spm-card-control"},Vh={class:"spm-control-header"},Kh={class:"spm-control-title-group"},qh={class:"spm-control-title"},Gh={class:"spm-quick-chips"},Zh=["onClick"],Yh=["value"],Jh={class:"spm-card-control"},Xh={class:"spm-control-header"},Qh={class:"spm-control-title-group"},tm={class:"spm-control-title"},em={key:0,class:"spm-note-status-box"},im=["title"],nm={class:"spm-action-grid",style:{"margin-top":"6px"}},sm={key:1,class:"spm-note-empty-box"},om={class:"spm-card-control"},rm={class:"spm-action-grid"},lm=be({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","addNoteBlock","locateNoteBlock","generateNotes","insertDividerAfter","deleteDivider"],setup(t,{emit:i}){const e=t,s=St(()=>{if(!e.pageNotes)return"";const l=e.pageNotes.replace(/[\r\n]+/g," ").trim();return l.length>50?l.slice(0,50)+"...":l}),n=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],r=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(l,o)=>(et(),st("div",Eh,[m("div",Mh,[m("span",null,"幻灯片页面设置"+_t(t.pageIndex?` (第 ${t.pageIndex} 页)`:""),1)]),pt(Gl,{"model-value":t.pageLayout,onChange:o[0]||(o[0]=a=>l.$emit("update:pageLayout",a))},null,8,["model-value"]),pt(Io,{"model-value":t.pageTransition,onChange:o[1]||(o[1]=a=>l.$emit("update:pageTransition",a))},null,8,["model-value"]),m("div",Bh,[m("div",Dh,[m("div",Lh,[m("div",Oh,[pt(yt,{name:"ratio"}),o[16]||(o[16]=m("span",null,"页面间距 (Spacing)",-1))]),o[17]||(o[17]=m("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),m("div",Ph,[m("button",{class:$t(["spm-segmented-item",{active:!t.pageSpacing||t.pageSpacing==="inherit"}]),onClick:o[2]||(o[2]=a=>l.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),m("button",{class:$t(["spm-segmented-item",{active:t.pageSpacing==="compact"}]),onClick:o[3]||(o[3]=a=>l.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),m("button",{class:$t(["spm-segmented-item",{active:t.pageSpacing==="normal"}]),onClick:o[4]||(o[4]=a=>l.$emit("update:pageSpacing","normal"))}," 标准 ",2),m("button",{class:$t(["spm-segmented-item",{active:t.pageSpacing==="loose"}]),onClick:o[5]||(o[5]=a=>l.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),m("div",Rh,[m("div",zh,[m("div",Nh,[m("div",Fh,[pt(yt,{name:"palette"}),o[18]||(o[18]=m("span",null,"页面背景 (Background)",-1))]),o[19]||(o[19]=m("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),m("div",jh,[(et(),st(Kt,null,ye(n,a=>m("button",{key:a.value,class:$t(["spm-chip",{active:t.pageBackground===a.value}]),onClick:c=>l.$emit("update:pageBackground",a.value)},_t(a.label),11,Hh)),64))]),m("input",{value:t.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:o[6]||(o[6]=a=>l.$emit("update:pageBackground",a.target.value)),onChange:o[7]||(o[7]=a=>l.$emit("update:pageBackground",a.target.value))},null,40,Uh)]),t.pageLayout==="image-right"||t.pageLayout==="image-left"||t.pageImage?(et(),st("div",Wh,[m("div",Vh,[m("div",Kh,[m("div",qh,[pt(yt,{name:"image"}),o[20]||(o[20]=m("span",null,"页面图片 (Image)",-1))]),o[21]||(o[21]=m("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),m("div",Gh,[(et(),st(Kt,null,ye(r,a=>m("button",{key:a.value,class:$t(["spm-chip",{active:t.pageImage===a.value}]),onClick:c=>l.$emit("update:pageImage",a.value)},_t(a.label),11,Zh)),64))]),m("input",{value:t.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:o[8]||(o[8]=a=>l.$emit("update:pageImage",a.target.value)),onChange:o[9]||(o[9]=a=>l.$emit("update:pageImage",a.target.value))},null,40,Yh)])):Rt("",!0),m("div",Jh,[m("div",Xh,[m("div",Qh,[m("div",tm,[pt(yt,{name:"presenter"}),o[22]||(o[22]=m("span",null,"演讲者提词 (Notes)",-1))]),o[23]||(o[23]=m("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),m("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:o[10]||(o[10]=a=>l.$emit("generateNotes"))},[pt(yt,{name:"sparkles"}),o[24]||(o[24]=m("span",null,"AI 讲稿",-1))])]),t.pageNotes?(et(),st("div",em,[o[27]||(o[27]=m("div",{class:"spm-note-status-badge"},[m("span",{class:"spm-badge-dot"}),m("span",null,"已配置正文讲稿")],-1)),m("div",{class:"spm-note-preview-text",title:t.pageNotes},_t(s.value),9,im),m("div",nm,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:o[11]||(o[11]=a=>l.$emit("locateNoteBlock"))},[pt(yt,{name:"search"}),o[25]||(o[25]=m("span",null,"定位讲稿块",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:o[12]||(o[12]=a=>l.$emit("addNoteBlock"))},[pt(yt,{name:"insert-below"}),o[26]||(o[26]=m("span",null,"追加讲稿块",-1))])])])):(et(),st("div",sm,[o[29]||(o[29]=m("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:o[13]||(o[13]=a=>l.$emit("addNoteBlock"))},[pt(yt,{name:"insert-below"}),o[28]||(o[28]=m("span",null,"添加讲稿备注块",-1))])]))]),m("div",om,[o[32]||(o[32]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),m("div",rm,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:o[14]||(o[14]=a=>l.$emit("insertDividerAfter"))},[pt(yt,{name:"insert-below"}),o[30]||(o[30]=m("span",null,"插入新页",-1))]),m("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:o[15]||(o[15]=a=>l.$emit("deleteDivider"))},[pt(yt,{name:"trash"}),o[31]||(o[31]=m("span",null,"删除此页",-1))])])])]))}}),am=Oe(lm,[["__scopeId","data-v-4f1fa626"]]),cm={class:"spm-section spm-section--block"},dm={class:"spm-card-control"},um={class:"spm-control-header"},fm={class:"spm-control-title-group"},pm={class:"spm-control-title"},hm=["aria-label"],mm=["checked"],gm={key:0,class:"spm-card-control"},vm={class:"spm-control-header"},bm={class:"spm-control-title-group"},ym={class:"spm-control-title"},wm={class:"spm-quick-chips"},km={key:1,class:"spm-card-control"},xm={class:"spm-control-header"},_m={class:"spm-control-title-group"},Sm={class:"spm-control-title"},Cm={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},$m={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Im=["aria-label"],Am=["checked"],Tm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Em=["aria-label"],Mm=["checked"],Bm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Dm=["aria-label"],Lm=["checked"],Om={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Pm=["aria-label"],Rm=["checked"],zm={class:"spm-card-control"},Nm={class:"spm-control-header"},Fm={class:"spm-control-title-group"},jm={class:"spm-control-title"},Hm=["aria-label"],Um=["checked"],Wm={key:0,class:"spm-quick-chips"},Vm=["onClick"],Km={class:"spm-card-control"},qm={class:"spm-control-header"},Gm={class:"spm-control-title-group"},Zm={class:"spm-control-title"},Ym=["aria-label"],Jm=["checked"],Xm={key:0,class:"spm-quick-chips"},Qm=["onClick"],tg={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},eg={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},ig={style:{display:"flex",gap:"6px"}},ng=["value"],sg=["value"],og={key:2,class:"spm-card-control"},rg={class:"spm-control-header"},lg={class:"spm-control-title-group"},ag={class:"spm-control-title"},cg={class:"spm-control-desc"},dg={class:"spm-segmented-group"},ug=["onClick"],fg={key:3,class:"spm-card-control"},pg={class:"spm-control-header"},hg={class:"spm-control-title-group"},mg={class:"spm-control-title"},gg={class:"spm-quick-chips"},vg=["onClick"],bg=["value"],yg={key:4,class:"spm-card-control"},wg={class:"spm-control-header"},kg={class:"spm-control-title-group"},xg={class:"spm-control-title"},_g={class:"spm-quick-chips"},Sg=["onClick"],Cg=["value"],$g={class:"spm-card-control"},Ig={class:"spm-action-grid"},Ag=["aria-label"],Tg=be({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(t,{emit:i}){const e=t,s=St(()=>{const x=e.currentSlideLayout||"";return["col-1","col-2","col-3"].includes(e.elemSlot)?"three-cols-header":x}),n=St(()=>{const x=s.value;return["two-cols","two-cols-header","three-cols-header"].includes(x)}),r=St(()=>{const x=s.value;return x==="three-cols-header"?"三栏插槽归属 (Slot)":x==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),l=St(()=>{const x=s.value;return x==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":x==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":x==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),o=St(()=>{const x=s.value;return x==="three-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}]:x==="two-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]:x==="two-cols"?[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}]:[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]});function a(x){const _=e.elemSlot||"";return x?_===x||x==="col-1"&&_==="left"||x==="col-2"&&_==="center"||x==="col-3"&&_==="right"||x==="left"&&_==="col-1"||x==="right"&&(_==="col-2"||_==="col-3"):!_||_==="default"}const c=i,d=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],p=St(()=>{if(!e.elemMotion||e.elemMotion.trim()===""||e.elemMotion.trim()==="none")return null;try{const x=JSON.parse(e.elemMotion);if(typeof x=="object"&&x!==null)return{preset:x.preset||x.type||"slide-up",duration:typeof x.duration=="number"?x.duration:0,delay:typeof x.delay=="number"?x.delay:0}}catch{}return{preset:e.elemMotion.trim(),duration:0,delay:0}}),g=St(()=>!!p.value),u=St(()=>{var x;return((x=p.value)==null?void 0:x.preset)||"slide-up"}),k=St(()=>{var x;return((x=p.value)==null?void 0:x.duration)||0}),h=St(()=>{var x;return((x=p.value)==null?void 0:x.delay)||0});function b(){g.value?c("update:elemMotion",""):c("update:elemMotion","slide-up")}function v(x){A(x,k.value,h.value)}function y(x){A(u.value,x,h.value)}function $(x){A(u.value,k.value,x)}function A(x,_,S){if(!x||x==="none"){c("update:elemMotion","");return}if(!_&&!S){c("update:elemMotion",x);return}const D={preset:x};_>0&&(D.duration=_),S>0&&(D.delay=S),c("update:elemMotion",JSON.stringify(D))}return(x,_)=>(et(),st("div",cm,[_[53]||(_[53]=m("div",{class:"spm-section-header"},[m("span",null,"元素动效与排版")],-1)),m("div",dm,[m("div",um,[m("div",fm,[m("div",pm,[pt(yt,{name:"presenter"}),_[22]||(_[22]=m("span",null,"设为讲稿备注 (slidev-note)",-1))]),_[23]||(_[23]=m("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.isNote?"取消讲稿备注":"设为讲稿备注"},[m("input",{type:"checkbox",checked:!!t.isNote,onChange:_[0]||(_[0]=S=>x.$emit("toggleNote"))},null,40,mm),_[24]||(_[24]=m("span",{class:"spm-switch-slider"},null,-1))],8,hm)])]),t.isImage||t.imageRole?(et(),st("div",gm,[m("div",vm,[m("div",bm,[m("div",ym,[pt(yt,{name:"image"}),_[25]||(_[25]=m("span",null,"图片角色与分栏 (Image & Layout)",-1))]),_[26]||(_[26]=m("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),m("div",wm,[m("button",{class:$t(["spm-chip",{active:!t.imageRole}]),onClick:_[1]||(_[1]=S=>x.$emit("update:imageRole",""))}," 普通内容 ",2),m("button",{class:$t(["spm-chip",{active:t.imageRole==="background"}]),onClick:_[2]||(_[2]=S=>x.$emit("update:imageRole","background"))}," 🖼️ 背景图 ",2),m("button",{class:$t(["spm-chip",{active:t.imageRole==="image-left"}]),onClick:_[3]||(_[3]=S=>x.$emit("update:imageRole","image-left"))}," 🎨 图左 ",2),m("button",{class:$t(["spm-chip",{active:t.imageRole==="image-right"}]),onClick:_[4]||(_[4]=S=>x.$emit("update:imageRole","image-right"))}," 🖼️ 图右 ",2)])])):Rt("",!0),t.isVideo?(et(),st("div",km,[m("div",xm,[m("div",_m,[m("div",Sm,[pt(yt,{name:"video"}),_[27]||(_[27]=m("span",null,"视频播放设置 (Video Playback)",-1))]),_[28]||(_[28]=m("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),m("div",Cm,[m("div",$m,[_[30]||(_[30]=m("span",{style:{"font-size":"11px"}},"🎛️ 控制条",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoControls?"关闭控制条":"开启控制条"},[m("input",{type:"checkbox",checked:!!t.videoControls,onChange:_[5]||(_[5]=S=>x.$emit("toggleVideoControls"))},null,40,Am),_[29]||(_[29]=m("span",{class:"spm-switch-slider"},null,-1))],8,Im)]),m("div",Tm,[_[32]||(_[32]=m("span",{style:{"font-size":"11px"}},"▶️ 自动播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoAutoplay?"关闭自动播放":"开启自动播放"},[m("input",{type:"checkbox",checked:!!t.videoAutoplay,onChange:_[6]||(_[6]=S=>x.$emit("toggleVideoAutoplay"))},null,40,Mm),_[31]||(_[31]=m("span",{class:"spm-switch-slider"},null,-1))],8,Em)]),m("div",Bm,[_[34]||(_[34]=m("span",{style:{"font-size":"11px"}},"🔁 循环播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoLoop?"关闭循环播放":"开启循环播放"},[m("input",{type:"checkbox",checked:!!t.videoLoop,onChange:_[7]||(_[7]=S=>x.$emit("toggleVideoLoop"))},null,40,Lm),_[33]||(_[33]=m("span",{class:"spm-switch-slider"},null,-1))],8,Dm)]),m("div",Om,[_[36]||(_[36]=m("span",{style:{"font-size":"11px"}},"🔇 静音播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoMuted?"关闭静音":"开启静音"},[m("input",{type:"checkbox",checked:!!t.videoMuted,onChange:_[8]||(_[8]=S=>x.$emit("toggleVideoMuted"))},null,40,Rm),_[35]||(_[35]=m("span",{class:"spm-switch-slider"},null,-1))],8,Pm)])])])):Rt("",!0),m("div",zm,[m("div",Nm,[m("div",Fm,[m("div",jm,[pt(yt,{name:"step"}),_[37]||(_[37]=m("span",null,"逐步呈现 (v-click)",-1))]),_[38]||(_[38]=m("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[m("input",{type:"checkbox",checked:!!t.elemClick,onChange:_[9]||(_[9]=S=>x.$emit("toggleElemClick"))},null,40,Um),_[39]||(_[39]=m("span",{class:"spm-switch-slider"},null,-1))],8,Hm)]),t.elemClick?(et(),st("div",Wm,[(et(),st(Kt,null,ye(["+1","1","2","hide"],S=>m("button",{key:S,class:$t(["spm-chip",{active:t.elemClick===S}]),onClick:D=>x.$emit("update:elemClick",S)},_t(S==="+1"?"顺延 (+1)":S==="hide"?"隐藏 (hide)":"第 "+S+" 步"),11,Vm)),64))])):Rt("",!0)]),m("div",Km,[m("div",qm,[m("div",Gm,[m("div",Zm,[pt(yt,{name:"motion"}),_[40]||(_[40]=m("span",null,"入场微动效 (v-motion)",-1))]),_[41]||(_[41]=m("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":g.value?"关闭微动效":"开启微动效 (slide-up)"},[m("input",{type:"checkbox",checked:g.value,onChange:b},null,40,Jm),_[42]||(_[42]=m("span",{class:"spm-switch-slider"},null,-1))],8,Ym)]),g.value?(et(),st("div",Xm,[(et(),st(Kt,null,ye(d,S=>m("button",{key:S.value,class:$t(["spm-chip",{active:u.value===S.value}]),onClick:D=>v(S.value)},_t(S.label),11,Qm)),64))])):Rt("",!0),g.value?(et(),st("div",tg,[m("div",eg,[m("span",null,"时长: "+_t(k.value?k.value+"ms":"默认 (450ms)"),1),m("span",null,"延迟: "+_t(h.value?h.value+"ms":"0ms"),1)]),m("div",ig,[m("select",{class:"spm-select",style:{flex:"1"},value:k.value,onChange:_[10]||(_[10]=S=>y(Number(S.target.value)))},[..._[43]||(_[43]=[m("option",{value:0},"默认耗时",-1),m("option",{value:200},"极速 (200ms)",-1),m("option",{value:350},"较快 (350ms)",-1),m("option",{value:500},"平滑 (500ms)",-1),m("option",{value:800},"缓慢 (800ms)",-1)])],40,ng),m("select",{class:"spm-select",style:{flex:"1"},value:h.value,onChange:_[11]||(_[11]=S=>$(Number(S.target.value)))},[..._[44]||(_[44]=[m("option",{value:0},"无延迟",-1),m("option",{value:150},"延迟 150ms",-1),m("option",{value:300},"延迟 300ms",-1),m("option",{value:500},"延迟 500ms",-1)])],40,sg)])])):Rt("",!0)]),n.value||t.elemSlot?(et(),st("div",og,[m("div",rg,[m("div",lg,[m("div",ag,[pt(yt,{name:"columns"}),m("span",null,_t(r.value),1)]),m("span",cg,_t(l.value),1)])]),m("div",dg,[(et(!0),st(Kt,null,ye(o.value,S=>(et(),st("button",{key:S.value,class:$t(["spm-segmented-item",{active:a(S.value)}]),onClick:D=>x.$emit("update:elemSlot",S.value)},_t(S.label),11,ug))),128))])])):Rt("",!0),t.isCodeBlock?(et(),st("div",fg,[m("div",pg,[m("div",hg,[m("div",mg,[pt(yt,{name:"code"}),_[45]||(_[45]=m("span",null,"代码逐行聚光 (Shiki)",-1))]),_[46]||(_[46]=m("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),m("div",gg,[(et(),st(Kt,null,ye(["1-3","all","1|2|3","2-5"],S=>m("button",{key:S,class:$t(["spm-chip",{active:t.elemShikiLines===S}]),onClick:D=>x.$emit("update:elemShikiLines",S)},_t(S),11,vg)),64)),t.elemShikiLines?(et(),st("button",{key:0,class:"spm-chip spm-chip-clear",onClick:_[12]||(_[12]=S=>x.$emit("update:elemShikiLines",""))}," 清空 ")):Rt("",!0)]),m("input",{value:t.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:_[13]||(_[13]=S=>x.$emit("update:elemShikiLines",S.target.value)),onChange:_[14]||(_[14]=S=>x.$emit("update:elemShikiLines",S.target.value))},null,40,bg)])):Rt("",!0),t.isCodeBlock?(et(),st("div",yg,[m("div",wg,[m("div",kg,[m("div",xg,[pt(yt,{name:"code"}),_[47]||(_[47]=m("span",null,"代码块限高 (Max Height)",-1))]),_[48]||(_[48]=m("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),m("div",_g,[(et(),st(Kt,null,ye(["240px","320px","400px","50vh"],S=>m("button",{key:S,class:$t(["spm-chip",{active:t.elemMaxHeight===S}]),onClick:D=>x.$emit("update:elemMaxHeight",S)},_t(S),11,Sg)),64)),t.elemMaxHeight?(et(),st("button",{key:0,class:"spm-chip spm-chip-clear",onClick:_[15]||(_[15]=S=>x.$emit("update:elemMaxHeight",""))}," 自适应 ")):Rt("",!0)]),m("input",{value:t.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:_[16]||(_[16]=S=>x.$emit("update:elemMaxHeight",S.target.value)),onChange:_[17]||(_[17]=S=>x.$emit("update:elemMaxHeight",S.target.value))},null,40,Cg)])):Rt("",!0),m("div",$g,[_[52]||(_[52]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"快捷操作")])],-1)),m("div",Ig,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:_[18]||(_[18]=S=>x.$emit("insertDividerBefore"))},[pt(yt,{name:"insert-above"}),_[49]||(_[49]=m("span",null,"上方分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:_[19]||(_[19]=S=>x.$emit("insertDividerAfter"))},[pt(yt,{name:"insert-below"}),_[50]||(_[50]=m("span",null,"下方分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":s.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:_[20]||(_[20]=S=>x.$emit("setTwoColsContrast"))},[pt(yt,{name:"columns"}),m("span",null,_t(s.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,Ag),t.hasBlockAttrs?(et(),st("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:_[21]||(_[21]=S=>x.$emit("clearBlockAttrs"))},[pt(yt,{name:"broom"}),_[51]||(_[51]=m("span",null,"清除属性",-1))])):Rt("",!0)])])]))}}),Eg={class:"spm-section spm-section--doc"},Mg={class:"spm-card-control"},Bg={class:"spm-control-header"},Dg={class:"spm-control-title-group"},Lg={class:"spm-control-title"},Og={class:"spm-segmented-group"},Pg=["aria-label","onClick"],Rg={class:"spm-card-control"},zg={class:"spm-control-header"},Ng={class:"spm-control-title-group"},Fg={class:"spm-control-title"},jg={class:"spm-segmented-group"},Hg={class:"spm-card-control"},Ug={class:"spm-control-header"},Wg={class:"spm-control-title-group"},Vg={class:"spm-control-title"},Kg={class:"spm-segmented-group"},qg={class:"spm-card-control"},Gg={class:"spm-control-header"},Zg={class:"spm-control-title-group"},Yg={class:"spm-control-title"},Jg={class:"spm-card-control"},Xg={class:"spm-control-header"},Qg={class:"spm-control-title-group"},tv={class:"spm-control-title"},ev=["aria-label"],iv=["checked"],nv={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},sv=["value"],ov={class:"spm-card-control"},rv={class:"spm-action-grid"},lv=be({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(t){const i=Qe("plugin"),e=Ii,s=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function n(o){Vi({enableWebServeJump:o}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({enableWebServeJump:o})}function r(o){Vi({webServeUrl:o})}function l(o){Vi({webServeUrl:o}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({webServeUrl:o})}return(o,a)=>(et(),st("div",Eg,[a[35]||(a[35]=m("div",{class:"spm-section-header"},[m("span",null,"全局演示配置")],-1)),m("div",Mg,[m("div",Bg,[m("div",Dg,[m("div",Lg,[pt(yt,{name:"palette"}),a[17]||(a[17]=m("span",null,"幻灯片主题 (Theme)",-1))]),a[18]||(a[18]=m("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),m("div",Og,[(et(),st(Kt,null,ye(s,c=>m("button",{key:c.value,class:$t(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:t.docTheme===c.value}]),"aria-label":c.desc,onClick:d=>o.$emit("update:docTheme",c.value)},_t(c.label),11,Pg)),64))])]),m("div",Rg,[m("div",zg,[m("div",Ng,[m("div",Fg,[pt(yt,{name:"ratio"}),a[19]||(a[19]=m("span",null,"画幅比例 (Aspect Ratio)",-1))]),a[20]||(a[20]=m("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),m("div",jg,[m("button",{class:$t(["spm-segmented-item",{active:t.docAspectRatio==="16/9"}]),onClick:a[0]||(a[0]=c=>o.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),m("button",{class:$t(["spm-segmented-item",{active:t.docAspectRatio==="4/3"}]),onClick:a[1]||(a[1]=c=>o.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),m("button",{class:$t(["spm-segmented-item",{active:t.docAspectRatio==="16/10"}]),onClick:a[2]||(a[2]=c=>o.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),m("div",Hg,[m("div",Ug,[m("div",Wg,[m("div",Vg,[pt(yt,{name:"ratio"}),a[21]||(a[21]=m("span",null,"间距风格 (Spacing)",-1))]),a[22]||(a[22]=m("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),m("div",Kg,[m("button",{class:$t(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:a[3]||(a[3]=c=>o.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),m("button",{class:$t(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:a[4]||(a[4]=c=>o.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),m("button",{class:$t(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:a[5]||(a[5]=c=>o.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),m("div",qg,[m("div",Gg,[m("div",Zg,[m("div",Yg,[pt(yt,{name:"transition"}),a[23]||(a[23]=m("span",null,"全局默认转场",-1))]),a[24]||(a[24]=m("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),pt(Io,{"model-value":t.docDefaultTransition,"hide-header":!0,onChange:a[6]||(a[6]=c=>o.$emit("update:docDefaultTransition",c))},null,8,["model-value"])]),m("div",Jg,[m("div",Xg,[m("div",Qg,[m("div",tv,[pt(yt,{name:"external-link"}),a[25]||(a[25]=m("span",null,"本地网络伺服预览 (Web Serve)",-1))]),a[26]||(a[26]=m("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":$i(e).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[m("input",{type:"checkbox",checked:$i(e).enableWebServeJump,onChange:a[7]||(a[7]=c=>n(c.target.checked))},null,40,iv),a[27]||(a[27]=m("span",{class:"spm-switch-slider"},null,-1))],8,ev)]),$i(e).enableWebServeJump?(et(),st("div",nv,[m("input",{value:$i(e).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:a[8]||(a[8]=Te(()=>{},["stop"])),onKeyup:a[9]||(a[9]=Te(()=>{},["stop"])),onInput:a[10]||(a[10]=c=>r(c.target.value)),onChange:a[11]||(a[11]=c=>l(c.target.value))},null,40,sv),a[28]||(a[28]=m("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Rt("",!0)]),m("div",ov,[a[34]||(a[34]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"演示全局操作")])],-1)),m("div",rv,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:a[12]||(a[12]=c=>o.$emit("openBottomPreview"))},[pt(yt,{name:"split-preview"}),a[29]||(a[29]=m("span",null,"分屏预览",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:a[13]||(a[13]=c=>o.$emit("openPresenter"))},[pt(yt,{name:"presenter"}),a[30]||(a[30]=m("span",null,"演讲者视图",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:a[14]||(a[14]=c=>o.$emit("aiAutoSplit"))},[pt(yt,{name:"sparkles"}),a[31]||(a[31]=m("span",null,"AI 智能分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:a[15]||(a[15]=c=>o.$emit("exportHtml"))},[pt(yt,{name:"export-html"}),a[32]||(a[32]=m("span",null,"导出 HTML",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:a[16]||(a[16]=c=>o.$emit("exportPdf"))},[pt(yt,{name:"export-pdf"}),a[33]||(a[33]=m("span",null,"导出 PDF",-1))])])])]))}});var Nn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function av(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}function Fn(t){throw new Error('Could not dynamically require "'+t+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Bs={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var xr;function cv(){return xr||(xr=1,(function(t,i){(function(e){t.exports=e()})(function(){return(function e(s,n,r){function l(c,d){if(!n[c]){if(!s[c]){var p=typeof Fn=="function"&&Fn;if(!d&&p)return p(c,!0);if(o)return o(c,!0);var g=new Error("Cannot find module '"+c+"'");throw g.code="MODULE_NOT_FOUND",g}var u=n[c]={exports:{}};s[c][0].call(u.exports,function(k){var h=s[c][1][k];return l(h||k)},u,u.exports,e,s,n,r)}return n[c].exports}for(var o=typeof Fn=="function"&&Fn,a=0;a<r.length;a++)l(r[a]);return l})({1:[function(e,s,n){var r=e("./utils"),l=e("./support"),o="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";n.encode=function(a){for(var c,d,p,g,u,k,h,b=[],v=0,y=a.length,$=y,A=r.getTypeOf(a)!=="string";v<a.length;)$=y-v,p=A?(c=a[v++],d=v<y?a[v++]:0,v<y?a[v++]:0):(c=a.charCodeAt(v++),d=v<y?a.charCodeAt(v++):0,v<y?a.charCodeAt(v++):0),g=c>>2,u=(3&c)<<4|d>>4,k=1<$?(15&d)<<2|p>>6:64,h=2<$?63&p:64,b.push(o.charAt(g)+o.charAt(u)+o.charAt(k)+o.charAt(h));return b.join("")},n.decode=function(a){var c,d,p,g,u,k,h=0,b=0,v="data:";if(a.substr(0,v.length)===v)throw new Error("Invalid base64 input, it looks like a data url.");var y,$=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===o.charAt(64)&&$--,a.charAt(a.length-2)===o.charAt(64)&&$--,$%1!=0)throw new Error("Invalid base64 input, bad content length.");for(y=l.uint8array?new Uint8Array(0|$):new Array(0|$);h<a.length;)c=o.indexOf(a.charAt(h++))<<2|(g=o.indexOf(a.charAt(h++)))>>4,d=(15&g)<<4|(u=o.indexOf(a.charAt(h++)))>>2,p=(3&u)<<6|(k=o.indexOf(a.charAt(h++))),y[b++]=c,u!==64&&(y[b++]=d),k!==64&&(y[b++]=p);return y}},{"./support":30,"./utils":32}],2:[function(e,s,n){var r=e("./external"),l=e("./stream/DataWorker"),o=e("./stream/Crc32Probe"),a=e("./stream/DataLengthProbe");function c(d,p,g,u,k){this.compressedSize=d,this.uncompressedSize=p,this.crc32=g,this.compression=u,this.compressedContent=k}c.prototype={getContentWorker:function(){var d=new l(r.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),p=this;return d.on("end",function(){if(this.streamInfo.data_length!==p.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(r.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,p,g){return d.pipe(new o).pipe(new a("uncompressedSize")).pipe(p.compressWorker(g)).pipe(new a("compressedSize")).withStreamInfo("compression",p)},s.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(e,s,n){var r=e("./stream/GenericWorker");n.STORE={magic:"\0\0",compressWorker:function(){return new r("STORE compression")},uncompressWorker:function(){return new r("STORE decompression")}},n.DEFLATE=e("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(e,s,n){var r=e("./utils"),l=(function(){for(var o,a=[],c=0;c<256;c++){o=c;for(var d=0;d<8;d++)o=1&o?3988292384^o>>>1:o>>>1;a[c]=o}return a})();s.exports=function(o,a){return o!==void 0&&o.length?r.getTypeOf(o)!=="string"?(function(c,d,p,g){var u=l,k=g+p;c^=-1;for(var h=g;h<k;h++)c=c>>>8^u[255&(c^d[h])];return-1^c})(0|a,o,o.length,0):(function(c,d,p,g){var u=l,k=g+p;c^=-1;for(var h=g;h<k;h++)c=c>>>8^u[255&(c^d.charCodeAt(h))];return-1^c})(0|a,o,o.length,0):0}},{"./utils":32}],5:[function(e,s,n){n.base64=!1,n.binary=!1,n.dir=!1,n.createFolders=!0,n.date=null,n.compression=null,n.compressionOptions=null,n.comment=null,n.unixPermissions=null,n.dosPermissions=null},{}],6:[function(e,s,n){var r=null;r=typeof Promise<"u"?Promise:e("lie"),s.exports={Promise:r}},{lie:37}],7:[function(e,s,n){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=e("pako"),o=e("./utils"),a=e("./stream/GenericWorker"),c=r?"uint8array":"array";function d(p,g){a.call(this,"FlateWorker/"+p),this._pako=null,this._pakoAction=p,this._pakoOptions=g,this.meta={}}n.magic="\b\0",o.inherits(d,a),d.prototype.processChunk=function(p){this.meta=p.meta,this._pako===null&&this._createPako(),this._pako.push(o.transformTo(c,p.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var p=this;this._pako.onData=function(g){p.push({data:g,meta:p.meta})}},n.compressWorker=function(p){return new d("Deflate",p)},n.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(e,s,n){function r(u,k){var h,b="";for(h=0;h<k;h++)b+=String.fromCharCode(255&u),u>>>=8;return b}function l(u,k,h,b,v,y){var $,A,x=u.file,_=u.compression,S=y!==c.utf8encode,D=o.transformTo("string",y(x.name)),M=o.transformTo("string",c.utf8encode(x.name)),P=x.comment,J=o.transformTo("string",y(P)),T=o.transformTo("string",c.utf8encode(P)),L=M.length!==x.name.length,w=T.length!==P.length,F="",Q="",V="",it=x.dir,U=x.date,Y={crc32:0,compressedSize:0,uncompressedSize:0};k&&!h||(Y.crc32=u.crc32,Y.compressedSize=u.compressedSize,Y.uncompressedSize=u.uncompressedSize);var W=0;k&&(W|=8),S||!L&&!w||(W|=2048);var z=0,ct=0;it&&(z|=16),v==="UNIX"?(ct=798,z|=(function(ot,tt){var gt=ot;return ot||(gt=tt?16893:33204),(65535&gt)<<16})(x.unixPermissions,it)):(ct=20,z|=(function(ot){return 63&(ot||0)})(x.dosPermissions)),$=U.getUTCHours(),$<<=6,$|=U.getUTCMinutes(),$<<=5,$|=U.getUTCSeconds()/2,A=U.getUTCFullYear()-1980,A<<=4,A|=U.getUTCMonth()+1,A<<=5,A|=U.getUTCDate(),L&&(Q=r(1,1)+r(d(D),4)+M,F+="up"+r(Q.length,2)+Q),w&&(V=r(1,1)+r(d(J),4)+T,F+="uc"+r(V.length,2)+V);var lt="";return lt+=`
\0`,lt+=r(W,2),lt+=_.magic,lt+=r($,2),lt+=r(A,2),lt+=r(Y.crc32,4),lt+=r(Y.compressedSize,4),lt+=r(Y.uncompressedSize,4),lt+=r(D.length,2),lt+=r(F.length,2),{fileRecord:p.LOCAL_FILE_HEADER+lt+D+F,dirRecord:p.CENTRAL_FILE_HEADER+r(ct,2)+lt+r(J.length,2)+"\0\0\0\0"+r(z,4)+r(b,4)+D+F+J}}var o=e("../utils"),a=e("../stream/GenericWorker"),c=e("../utf8"),d=e("../crc32"),p=e("../signature");function g(u,k,h,b){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=k,this.zipPlatform=h,this.encodeFileName=b,this.streamFiles=u,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}o.inherits(g,a),g.prototype.push=function(u){var k=u.meta.percent||0,h=this.entriesCount,b=this._sources.length;this.accumulate?this.contentBuffer.push(u):(this.bytesWritten+=u.data.length,a.prototype.push.call(this,{data:u.data,meta:{currentFile:this.currentFile,percent:h?(k+100*(h-b-1))/h:100}}))},g.prototype.openedSource=function(u){this.currentSourceOffset=this.bytesWritten,this.currentFile=u.file.name;var k=this.streamFiles&&!u.file.dir;if(k){var h=l(u,k,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:h.fileRecord,meta:{percent:0}})}else this.accumulate=!0},g.prototype.closedSource=function(u){this.accumulate=!1;var k=this.streamFiles&&!u.file.dir,h=l(u,k,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(h.dirRecord),k)this.push({data:(function(b){return p.DATA_DESCRIPTOR+r(b.crc32,4)+r(b.compressedSize,4)+r(b.uncompressedSize,4)})(u),meta:{percent:100}});else for(this.push({data:h.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},g.prototype.flush=function(){for(var u=this.bytesWritten,k=0;k<this.dirRecords.length;k++)this.push({data:this.dirRecords[k],meta:{percent:100}});var h=this.bytesWritten-u,b=(function(v,y,$,A,x){var _=o.transformTo("string",x(A));return p.CENTRAL_DIRECTORY_END+"\0\0\0\0"+r(v,2)+r(v,2)+r(y,4)+r($,4)+r(_.length,2)+_})(this.dirRecords.length,h,u,this.zipComment,this.encodeFileName);this.push({data:b,meta:{percent:100}})},g.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},g.prototype.registerPrevious=function(u){this._sources.push(u);var k=this;return u.on("data",function(h){k.processChunk(h)}),u.on("end",function(){k.closedSource(k.previous.streamInfo),k._sources.length?k.prepareNextSource():k.end()}),u.on("error",function(h){k.error(h)}),this},g.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},g.prototype.error=function(u){var k=this._sources;if(!a.prototype.error.call(this,u))return!1;for(var h=0;h<k.length;h++)try{k[h].error(u)}catch{}return!0},g.prototype.lock=function(){a.prototype.lock.call(this);for(var u=this._sources,k=0;k<u.length;k++)u[k].lock()},s.exports=g},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(e,s,n){var r=e("../compressions"),l=e("./ZipFileWorker");n.generateWorker=function(o,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),p=0;try{o.forEach(function(g,u){p++;var k=(function(y,$){var A=y||$,x=r[A];if(!x)throw new Error(A+" is not a valid compression method !");return x})(u.options.compression,a.compression),h=u.options.compressionOptions||a.compressionOptions||{},b=u.dir,v=u.date;u._compressWorker(k,h).withStreamInfo("file",{name:g,dir:b,date:v,comment:u.comment||"",unixPermissions:u.unixPermissions,dosPermissions:u.dosPermissions}).pipe(d)}),d.entriesCount=p}catch(g){d.error(g)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(e,s,n){function r(){if(!(this instanceof r))return new r;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new r;for(var o in this)typeof this[o]!="function"&&(l[o]=this[o]);return l}}(r.prototype=e("./object")).loadAsync=e("./load"),r.support=e("./support"),r.defaults=e("./defaults"),r.version="3.10.1",r.loadAsync=function(l,o){return new r().loadAsync(l,o)},r.external=e("./external"),s.exports=r},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(e,s,n){var r=e("./utils"),l=e("./external"),o=e("./utf8"),a=e("./zipEntries"),c=e("./stream/Crc32Probe"),d=e("./nodejsUtils");function p(g){return new l.Promise(function(u,k){var h=g.decompressed.getContentWorker().pipe(new c);h.on("error",function(b){k(b)}).on("end",function(){h.streamInfo.crc32!==g.decompressed.crc32?k(new Error("Corrupted zip : CRC32 mismatch")):u()}).resume()})}s.exports=function(g,u){var k=this;return u=r.extend(u||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:o.utf8decode}),d.isNode&&d.isStream(g)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):r.prepareContent("the loaded zip file",g,!0,u.optimizedBinaryString,u.base64).then(function(h){var b=new a(u);return b.load(h),b}).then(function(h){var b=[l.Promise.resolve(h)],v=h.files;if(u.checkCRC32)for(var y=0;y<v.length;y++)b.push(p(v[y]));return l.Promise.all(b)}).then(function(h){for(var b=h.shift(),v=b.files,y=0;y<v.length;y++){var $=v[y],A=$.fileNameStr,x=r.resolve($.fileNameStr);k.file(x,$.decompressed,{binary:!0,optimizedBinaryString:!0,date:$.date,dir:$.dir,comment:$.fileCommentStr.length?$.fileCommentStr:null,unixPermissions:$.unixPermissions,dosPermissions:$.dosPermissions,createFolders:u.createFolders}),$.dir||(k.file(x).unsafeOriginalName=A)}return b.zipComment.length&&(k.comment=b.zipComment),k})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(e,s,n){var r=e("../utils"),l=e("../stream/GenericWorker");function o(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}r.inherits(o,l),o.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},o.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},o.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},s.exports=o},{"../stream/GenericWorker":28,"../utils":32}],13:[function(e,s,n){var r=e("readable-stream").Readable;function l(o,a,c){r.call(this,a),this._helper=o;var d=this;o.on("data",function(p,g){d.push(p)||d._helper.pause(),c&&c(g)}).on("error",function(p){d.emit("error",p)}).on("end",function(){d.push(null)})}e("../utils").inherits(l,r),l.prototype._read=function(){this._helper.resume()},s.exports=l},{"../utils":32,"readable-stream":16}],14:[function(e,s,n){s.exports={isNode:typeof Buffer<"u",newBufferFrom:function(r,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(r,l);if(typeof r=="number")throw new Error('The "data" argument must not be a number');return new Buffer(r,l)},allocBuffer:function(r){if(Buffer.alloc)return Buffer.alloc(r);var l=new Buffer(r);return l.fill(0),l},isBuffer:function(r){return Buffer.isBuffer(r)},isStream:function(r){return r&&typeof r.on=="function"&&typeof r.pause=="function"&&typeof r.resume=="function"}}},{}],15:[function(e,s,n){function r(x,_,S){var D,M=o.getTypeOf(_),P=o.extend(S||{},d);P.date=P.date||new Date,P.compression!==null&&(P.compression=P.compression.toUpperCase()),typeof P.unixPermissions=="string"&&(P.unixPermissions=parseInt(P.unixPermissions,8)),P.unixPermissions&&16384&P.unixPermissions&&(P.dir=!0),P.dosPermissions&&16&P.dosPermissions&&(P.dir=!0),P.dir&&(x=v(x)),P.createFolders&&(D=b(x))&&y.call(this,D,!0);var J=M==="string"&&P.binary===!1&&P.base64===!1;S&&S.binary!==void 0||(P.binary=!J),(_ instanceof p&&_.uncompressedSize===0||P.dir||!_||_.length===0)&&(P.base64=!1,P.binary=!0,_="",P.compression="STORE",M="string");var T=null;T=_ instanceof p||_ instanceof a?_:k.isNode&&k.isStream(_)?new h(x,_):o.prepareContent(x,_,P.binary,P.optimizedBinaryString,P.base64);var L=new g(x,T,P);this.files[x]=L}var l=e("./utf8"),o=e("./utils"),a=e("./stream/GenericWorker"),c=e("./stream/StreamHelper"),d=e("./defaults"),p=e("./compressedObject"),g=e("./zipObject"),u=e("./generate"),k=e("./nodejsUtils"),h=e("./nodejs/NodejsStreamInputAdapter"),b=function(x){x.slice(-1)==="/"&&(x=x.substring(0,x.length-1));var _=x.lastIndexOf("/");return 0<_?x.substring(0,_):""},v=function(x){return x.slice(-1)!=="/"&&(x+="/"),x},y=function(x,_){return _=_!==void 0?_:d.createFolders,x=v(x),this.files[x]||r.call(this,x,null,{dir:!0,createFolders:_}),this.files[x]};function $(x){return Object.prototype.toString.call(x)==="[object RegExp]"}var A={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(x){var _,S,D;for(_ in this.files)D=this.files[_],(S=_.slice(this.root.length,_.length))&&_.slice(0,this.root.length)===this.root&&x(S,D)},filter:function(x){var _=[];return this.forEach(function(S,D){x(S,D)&&_.push(D)}),_},file:function(x,_,S){if(arguments.length!==1)return x=this.root+x,r.call(this,x,_,S),this;if($(x)){var D=x;return this.filter(function(P,J){return!J.dir&&D.test(P)})}var M=this.files[this.root+x];return M&&!M.dir?M:null},folder:function(x){if(!x)return this;if($(x))return this.filter(function(M,P){return P.dir&&x.test(M)});var _=this.root+x,S=y.call(this,_),D=this.clone();return D.root=S.name,D},remove:function(x){x=this.root+x;var _=this.files[x];if(_||(x.slice(-1)!=="/"&&(x+="/"),_=this.files[x]),_&&!_.dir)delete this.files[x];else for(var S=this.filter(function(M,P){return P.name.slice(0,x.length)===x}),D=0;D<S.length;D++)delete this.files[S[D].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(x){var _,S={};try{if((S=o.extend(x||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=S.type.toLowerCase(),S.compression=S.compression.toUpperCase(),S.type==="binarystring"&&(S.type="string"),!S.type)throw new Error("No output type specified.");o.checkSupport(S.type),S.platform!=="darwin"&&S.platform!=="freebsd"&&S.platform!=="linux"&&S.platform!=="sunos"||(S.platform="UNIX"),S.platform==="win32"&&(S.platform="DOS");var D=S.comment||this.comment||"";_=u.generateWorker(this,S,D)}catch(M){(_=new a("error")).error(M)}return new c(_,S.type||"string",S.mimeType)},generateAsync:function(x,_){return this.generateInternalStream(x).accumulate(_)},generateNodeStream:function(x,_){return(x=x||{}).type||(x.type="nodebuffer"),this.generateInternalStream(x).toNodejsStream(_)}};s.exports=A},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(e,s,n){s.exports=e("stream")},{stream:void 0}],17:[function(e,s,n){var r=e("./DataReader");function l(o){r.call(this,o);for(var a=0;a<this.data.length;a++)o[a]=255&o[a]}e("../utils").inherits(l,r),l.prototype.byteAt=function(o){return this.data[this.zero+o]},l.prototype.lastIndexOfSignature=function(o){for(var a=o.charCodeAt(0),c=o.charCodeAt(1),d=o.charCodeAt(2),p=o.charCodeAt(3),g=this.length-4;0<=g;--g)if(this.data[g]===a&&this.data[g+1]===c&&this.data[g+2]===d&&this.data[g+3]===p)return g-this.zero;return-1},l.prototype.readAndCheckSignature=function(o){var a=o.charCodeAt(0),c=o.charCodeAt(1),d=o.charCodeAt(2),p=o.charCodeAt(3),g=this.readData(4);return a===g[0]&&c===g[1]&&d===g[2]&&p===g[3]},l.prototype.readData=function(o){if(this.checkOffset(o),o===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},s.exports=l},{"../utils":32,"./DataReader":18}],18:[function(e,s,n){var r=e("../utils");function l(o){this.data=o,this.length=o.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(o){this.checkIndex(this.index+o)},checkIndex:function(o){if(this.length<this.zero+o||o<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+o+"). Corrupted zip ?")},setIndex:function(o){this.checkIndex(o),this.index=o},skip:function(o){this.setIndex(this.index+o)},byteAt:function(){},readInt:function(o){var a,c=0;for(this.checkOffset(o),a=this.index+o-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=o,c},readString:function(o){return r.transformTo("string",this.readData(o))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var o=this.readInt(4);return new Date(Date.UTC(1980+(o>>25&127),(o>>21&15)-1,o>>16&31,o>>11&31,o>>5&63,(31&o)<<1))}},s.exports=l},{"../utils":32}],19:[function(e,s,n){var r=e("./Uint8ArrayReader");function l(o){r.call(this,o)}e("../utils").inherits(l,r),l.prototype.readData=function(o){this.checkOffset(o);var a=this.data.slice(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},s.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(e,s,n){var r=e("./DataReader");function l(o){r.call(this,o)}e("../utils").inherits(l,r),l.prototype.byteAt=function(o){return this.data.charCodeAt(this.zero+o)},l.prototype.lastIndexOfSignature=function(o){return this.data.lastIndexOf(o)-this.zero},l.prototype.readAndCheckSignature=function(o){return o===this.readData(4)},l.prototype.readData=function(o){this.checkOffset(o);var a=this.data.slice(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},s.exports=l},{"../utils":32,"./DataReader":18}],21:[function(e,s,n){var r=e("./ArrayReader");function l(o){r.call(this,o)}e("../utils").inherits(l,r),l.prototype.readData=function(o){if(this.checkOffset(o),o===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},s.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(e,s,n){var r=e("../utils"),l=e("../support"),o=e("./ArrayReader"),a=e("./StringReader"),c=e("./NodeBufferReader"),d=e("./Uint8ArrayReader");s.exports=function(p){var g=r.getTypeOf(p);return r.checkSupport(g),g!=="string"||l.uint8array?g==="nodebuffer"?new c(p):l.uint8array?new d(r.transformTo("uint8array",p)):new o(r.transformTo("array",p)):new a(p)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(e,s,n){n.LOCAL_FILE_HEADER="PK",n.CENTRAL_FILE_HEADER="PK",n.CENTRAL_DIRECTORY_END="PK",n.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",n.ZIP64_CENTRAL_DIRECTORY_END="PK",n.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(e,s,n){var r=e("./GenericWorker"),l=e("../utils");function o(a){r.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(o,r),o.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},s.exports=o},{"../utils":32,"./GenericWorker":28}],25:[function(e,s,n){var r=e("./GenericWorker"),l=e("../crc32");function o(){r.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}e("../utils").inherits(o,r),o.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},s.exports=o},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(e,s,n){var r=e("../utils"),l=e("./GenericWorker");function o(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}r.inherits(o,l),o.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},s.exports=o},{"../utils":32,"./GenericWorker":28}],27:[function(e,s,n){var r=e("../utils"),l=e("./GenericWorker");function o(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=r.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}r.inherits(o,l),o.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},o.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,r.delay(this._tickAndRepeat,[],this)),!0)},o.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(r.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},o.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},s.exports=o},{"../utils":32,"./GenericWorker":28}],28:[function(e,s,n){function r(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}r.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,o){return this._listeners[l].push(o),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,o){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,o)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var o=this;return l.on("data",function(a){o.processChunk(a)}),l.on("end",function(){o.end()}),l.on("error",function(a){o.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,o){return this.extraStreamInfo[l]=o,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},s.exports=r},{}],29:[function(e,s,n){var r=e("../utils"),l=e("./ConvertWorker"),o=e("./GenericWorker"),a=e("../base64"),c=e("../support"),d=e("../external"),p=null;if(c.nodestream)try{p=e("../nodejs/NodejsStreamOutputAdapter")}catch{}function g(k,h){return new d.Promise(function(b,v){var y=[],$=k._internalType,A=k._outputType,x=k._mimeType;k.on("data",function(_,S){y.push(_),h&&h(S)}).on("error",function(_){y=[],v(_)}).on("end",function(){try{var _=(function(S,D,M){switch(S){case"blob":return r.newBlob(r.transformTo("arraybuffer",D),M);case"base64":return a.encode(D);default:return r.transformTo(S,D)}})(A,(function(S,D){var M,P=0,J=null,T=0;for(M=0;M<D.length;M++)T+=D[M].length;switch(S){case"string":return D.join("");case"array":return Array.prototype.concat.apply([],D);case"uint8array":for(J=new Uint8Array(T),M=0;M<D.length;M++)J.set(D[M],P),P+=D[M].length;return J;case"nodebuffer":return Buffer.concat(D);default:throw new Error("concat : unsupported type '"+S+"'")}})($,y),x);b(_)}catch(S){v(S)}y=[]}).resume()})}function u(k,h,b){var v=h;switch(h){case"blob":case"arraybuffer":v="uint8array";break;case"base64":v="string"}try{this._internalType=v,this._outputType=h,this._mimeType=b,r.checkSupport(v),this._worker=k.pipe(new l(v)),k.lock()}catch(y){this._worker=new o("error"),this._worker.error(y)}}u.prototype={accumulate:function(k){return g(this,k)},on:function(k,h){var b=this;return k==="data"?this._worker.on(k,function(v){h.call(b,v.data,v.meta)}):this._worker.on(k,function(){r.delay(h,arguments,b)}),this},resume:function(){return r.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(k){if(r.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new p(this,{objectMode:this._outputType!=="nodebuffer"},k)}},s.exports=u},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(e,s,n){if(n.base64=!0,n.array=!0,n.string=!0,n.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",n.nodebuffer=typeof Buffer<"u",n.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")n.blob=!1;else{var r=new ArrayBuffer(0);try{n.blob=new Blob([r],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(r),n.blob=l.getBlob("application/zip").size===0}catch{n.blob=!1}}}try{n.nodestream=!!e("readable-stream").Readable}catch{n.nodestream=!1}},{"readable-stream":16}],31:[function(e,s,n){for(var r=e("./utils"),l=e("./support"),o=e("./nodejsUtils"),a=e("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function p(){a.call(this,"utf-8 decode"),this.leftOver=null}function g(){a.call(this,"utf-8 encode")}n.utf8encode=function(u){return l.nodebuffer?o.newBufferFrom(u,"utf-8"):(function(k){var h,b,v,y,$,A=k.length,x=0;for(y=0;y<A;y++)(64512&(b=k.charCodeAt(y)))==55296&&y+1<A&&(64512&(v=k.charCodeAt(y+1)))==56320&&(b=65536+(b-55296<<10)+(v-56320),y++),x+=b<128?1:b<2048?2:b<65536?3:4;for(h=l.uint8array?new Uint8Array(x):new Array(x),y=$=0;$<x;y++)(64512&(b=k.charCodeAt(y)))==55296&&y+1<A&&(64512&(v=k.charCodeAt(y+1)))==56320&&(b=65536+(b-55296<<10)+(v-56320),y++),b<128?h[$++]=b:(b<2048?h[$++]=192|b>>>6:(b<65536?h[$++]=224|b>>>12:(h[$++]=240|b>>>18,h[$++]=128|b>>>12&63),h[$++]=128|b>>>6&63),h[$++]=128|63&b);return h})(u)},n.utf8decode=function(u){return l.nodebuffer?r.transformTo("nodebuffer",u).toString("utf-8"):(function(k){var h,b,v,y,$=k.length,A=new Array(2*$);for(h=b=0;h<$;)if((v=k[h++])<128)A[b++]=v;else if(4<(y=c[v]))A[b++]=65533,h+=y-1;else{for(v&=y===2?31:y===3?15:7;1<y&&h<$;)v=v<<6|63&k[h++],y--;1<y?A[b++]=65533:v<65536?A[b++]=v:(v-=65536,A[b++]=55296|v>>10&1023,A[b++]=56320|1023&v)}return A.length!==b&&(A.subarray?A=A.subarray(0,b):A.length=b),r.applyFromCharCode(A)})(u=r.transformTo(l.uint8array?"uint8array":"array",u))},r.inherits(p,a),p.prototype.processChunk=function(u){var k=r.transformTo(l.uint8array?"uint8array":"array",u.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var h=k;(k=new Uint8Array(h.length+this.leftOver.length)).set(this.leftOver,0),k.set(h,this.leftOver.length)}else k=this.leftOver.concat(k);this.leftOver=null}var b=(function(y,$){var A;for(($=$||y.length)>y.length&&($=y.length),A=$-1;0<=A&&(192&y[A])==128;)A--;return A<0||A===0?$:A+c[y[A]]>$?A:$})(k),v=k;b!==k.length&&(l.uint8array?(v=k.subarray(0,b),this.leftOver=k.subarray(b,k.length)):(v=k.slice(0,b),this.leftOver=k.slice(b,k.length))),this.push({data:n.utf8decode(v),meta:u.meta})},p.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:n.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},n.Utf8DecodeWorker=p,r.inherits(g,a),g.prototype.processChunk=function(u){this.push({data:n.utf8encode(u.data),meta:u.meta})},n.Utf8EncodeWorker=g},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(e,s,n){var r=e("./support"),l=e("./base64"),o=e("./nodejsUtils"),a=e("./external");function c(h){return h}function d(h,b){for(var v=0;v<h.length;++v)b[v]=255&h.charCodeAt(v);return b}e("setimmediate"),n.newBlob=function(h,b){n.checkSupport("blob");try{return new Blob([h],{type:b})}catch{try{var v=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return v.append(h),v.getBlob(b)}catch{throw new Error("Bug : can't construct the Blob.")}}};var p={stringifyByChunk:function(h,b,v){var y=[],$=0,A=h.length;if(A<=v)return String.fromCharCode.apply(null,h);for(;$<A;)b==="array"||b==="nodebuffer"?y.push(String.fromCharCode.apply(null,h.slice($,Math.min($+v,A)))):y.push(String.fromCharCode.apply(null,h.subarray($,Math.min($+v,A)))),$+=v;return y.join("")},stringifyByChar:function(h){for(var b="",v=0;v<h.length;v++)b+=String.fromCharCode(h[v]);return b},applyCanBeUsed:{uint8array:(function(){try{return r.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return r.nodebuffer&&String.fromCharCode.apply(null,o.allocBuffer(1)).length===1}catch{return!1}})()}};function g(h){var b=65536,v=n.getTypeOf(h),y=!0;if(v==="uint8array"?y=p.applyCanBeUsed.uint8array:v==="nodebuffer"&&(y=p.applyCanBeUsed.nodebuffer),y)for(;1<b;)try{return p.stringifyByChunk(h,v,b)}catch{b=Math.floor(b/2)}return p.stringifyByChar(h)}function u(h,b){for(var v=0;v<h.length;v++)b[v]=h[v];return b}n.applyFromCharCode=g;var k={};k.string={string:c,array:function(h){return d(h,new Array(h.length))},arraybuffer:function(h){return k.string.uint8array(h).buffer},uint8array:function(h){return d(h,new Uint8Array(h.length))},nodebuffer:function(h){return d(h,o.allocBuffer(h.length))}},k.array={string:g,array:c,arraybuffer:function(h){return new Uint8Array(h).buffer},uint8array:function(h){return new Uint8Array(h)},nodebuffer:function(h){return o.newBufferFrom(h)}},k.arraybuffer={string:function(h){return g(new Uint8Array(h))},array:function(h){return u(new Uint8Array(h),new Array(h.byteLength))},arraybuffer:c,uint8array:function(h){return new Uint8Array(h)},nodebuffer:function(h){return o.newBufferFrom(new Uint8Array(h))}},k.uint8array={string:g,array:function(h){return u(h,new Array(h.length))},arraybuffer:function(h){return h.buffer},uint8array:c,nodebuffer:function(h){return o.newBufferFrom(h)}},k.nodebuffer={string:g,array:function(h){return u(h,new Array(h.length))},arraybuffer:function(h){return k.nodebuffer.uint8array(h).buffer},uint8array:function(h){return u(h,new Uint8Array(h.length))},nodebuffer:c},n.transformTo=function(h,b){if(b=b||"",!h)return b;n.checkSupport(h);var v=n.getTypeOf(b);return k[v][h](b)},n.resolve=function(h){for(var b=h.split("/"),v=[],y=0;y<b.length;y++){var $=b[y];$==="."||$===""&&y!==0&&y!==b.length-1||($===".."?v.pop():v.push($))}return v.join("/")},n.getTypeOf=function(h){return typeof h=="string"?"string":Object.prototype.toString.call(h)==="[object Array]"?"array":r.nodebuffer&&o.isBuffer(h)?"nodebuffer":r.uint8array&&h instanceof Uint8Array?"uint8array":r.arraybuffer&&h instanceof ArrayBuffer?"arraybuffer":void 0},n.checkSupport=function(h){if(!r[h.toLowerCase()])throw new Error(h+" is not supported by this platform")},n.MAX_VALUE_16BITS=65535,n.MAX_VALUE_32BITS=-1,n.pretty=function(h){var b,v,y="";for(v=0;v<(h||"").length;v++)y+="\\x"+((b=h.charCodeAt(v))<16?"0":"")+b.toString(16).toUpperCase();return y},n.delay=function(h,b,v){setImmediate(function(){h.apply(v||null,b||[])})},n.inherits=function(h,b){function v(){}v.prototype=b.prototype,h.prototype=new v},n.extend=function(){var h,b,v={};for(h=0;h<arguments.length;h++)for(b in arguments[h])Object.prototype.hasOwnProperty.call(arguments[h],b)&&v[b]===void 0&&(v[b]=arguments[h][b]);return v},n.prepareContent=function(h,b,v,y,$){return a.Promise.resolve(b).then(function(A){return r.blob&&(A instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(A))!==-1)&&typeof FileReader<"u"?new a.Promise(function(x,_){var S=new FileReader;S.onload=function(D){x(D.target.result)},S.onerror=function(D){_(D.target.error)},S.readAsArrayBuffer(A)}):A}).then(function(A){var x=n.getTypeOf(A);return x?(x==="arraybuffer"?A=n.transformTo("uint8array",A):x==="string"&&($?A=l.decode(A):v&&y!==!0&&(A=(function(_){return d(_,r.uint8array?new Uint8Array(_.length):new Array(_.length))})(A))),A):a.Promise.reject(new Error("Can't read the data of '"+h+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(e,s,n){var r=e("./reader/readerFor"),l=e("./utils"),o=e("./signature"),a=e("./zipEntry"),c=e("./support");function d(p){this.files=[],this.loadOptions=p}d.prototype={checkSignature:function(p){if(!this.reader.readAndCheckSignature(p)){this.reader.index-=4;var g=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(g)+", expected "+l.pretty(p)+")")}},isSignature:function(p,g){var u=this.reader.index;this.reader.setIndex(p);var k=this.reader.readString(4)===g;return this.reader.setIndex(u),k},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var p=this.reader.readData(this.zipCommentLength),g=c.uint8array?"uint8array":"array",u=l.transformTo(g,p);this.zipComment=this.loadOptions.decodeFileName(u)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var p,g,u,k=this.zip64EndOfCentralSize-44;0<k;)p=this.reader.readInt(2),g=this.reader.readInt(4),u=this.reader.readData(g),this.zip64ExtensibleData[p]={id:p,length:g,value:u}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var p,g;for(p=0;p<this.files.length;p++)g=this.files[p],this.reader.setIndex(g.localHeaderOffset),this.checkSignature(o.LOCAL_FILE_HEADER),g.readLocalPart(this.reader),g.handleUTF8(),g.processAttributes()},readCentralDir:function(){var p;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(o.CENTRAL_FILE_HEADER);)(p=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(p);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var p=this.reader.lastIndexOfSignature(o.CENTRAL_DIRECTORY_END);if(p<0)throw this.isSignature(0,o.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(p);var g=p;if(this.checkSignature(o.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(p=this.reader.lastIndexOfSignature(o.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(p),this.checkSignature(o.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,o.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(o.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(o.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var u=this.centralDirOffset+this.centralDirSize;this.zip64&&(u+=20,u+=12+this.zip64EndOfCentralSize);var k=g-u;if(0<k)this.isSignature(g,o.CENTRAL_FILE_HEADER)||(this.reader.zero=k);else if(k<0)throw new Error("Corrupted zip: missing "+Math.abs(k)+" bytes.")},prepareReader:function(p){this.reader=r(p)},load:function(p){this.prepareReader(p),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},s.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(e,s,n){var r=e("./reader/readerFor"),l=e("./utils"),o=e("./compressedObject"),a=e("./crc32"),c=e("./utf8"),d=e("./compressions"),p=e("./support");function g(u,k){this.options=u,this.loadOptions=k}g.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(u){var k,h;if(u.skip(22),this.fileNameLength=u.readInt(2),h=u.readInt(2),this.fileName=u.readData(this.fileNameLength),u.skip(h),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((k=(function(b){for(var v in d)if(Object.prototype.hasOwnProperty.call(d,v)&&d[v].magic===b)return d[v];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new o(this.compressedSize,this.uncompressedSize,this.crc32,k,u.readData(this.compressedSize))},readCentralPart:function(u){this.versionMadeBy=u.readInt(2),u.skip(2),this.bitFlag=u.readInt(2),this.compressionMethod=u.readString(2),this.date=u.readDate(),this.crc32=u.readInt(4),this.compressedSize=u.readInt(4),this.uncompressedSize=u.readInt(4);var k=u.readInt(2);if(this.extraFieldsLength=u.readInt(2),this.fileCommentLength=u.readInt(2),this.diskNumberStart=u.readInt(2),this.internalFileAttributes=u.readInt(2),this.externalFileAttributes=u.readInt(4),this.localHeaderOffset=u.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");u.skip(k),this.readExtraFields(u),this.parseZIP64ExtraField(u),this.fileComment=u.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var u=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),u==0&&(this.dosPermissions=63&this.externalFileAttributes),u==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var u=r(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=u.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=u.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=u.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=u.readInt(4))}},readExtraFields:function(u){var k,h,b,v=u.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});u.index+4<v;)k=u.readInt(2),h=u.readInt(2),b=u.readData(h),this.extraFields[k]={id:k,length:h,value:b};u.setIndex(v)},handleUTF8:function(){var u=p.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var k=this.findExtraFieldUnicodePath();if(k!==null)this.fileNameStr=k;else{var h=l.transformTo(u,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(h)}var b=this.findExtraFieldUnicodeComment();if(b!==null)this.fileCommentStr=b;else{var v=l.transformTo(u,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(v)}}},findExtraFieldUnicodePath:function(){var u=this.extraFields[28789];if(u){var k=r(u.value);return k.readInt(1)!==1||a(this.fileName)!==k.readInt(4)?null:c.utf8decode(k.readData(u.length-5))}return null},findExtraFieldUnicodeComment:function(){var u=this.extraFields[25461];if(u){var k=r(u.value);return k.readInt(1)!==1||a(this.fileComment)!==k.readInt(4)?null:c.utf8decode(k.readData(u.length-5))}return null}},s.exports=g},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(e,s,n){function r(k,h,b){this.name=k,this.dir=b.dir,this.date=b.date,this.comment=b.comment,this.unixPermissions=b.unixPermissions,this.dosPermissions=b.dosPermissions,this._data=h,this._dataBinary=b.binary,this.options={compression:b.compression,compressionOptions:b.compressionOptions}}var l=e("./stream/StreamHelper"),o=e("./stream/DataWorker"),a=e("./utf8"),c=e("./compressedObject"),d=e("./stream/GenericWorker");r.prototype={internalStream:function(k){var h=null,b="string";try{if(!k)throw new Error("No output type specified.");var v=(b=k.toLowerCase())==="string"||b==="text";b!=="binarystring"&&b!=="text"||(b="string"),h=this._decompressWorker();var y=!this._dataBinary;y&&!v&&(h=h.pipe(new a.Utf8EncodeWorker)),!y&&v&&(h=h.pipe(new a.Utf8DecodeWorker))}catch($){(h=new d("error")).error($)}return new l(h,b,"")},async:function(k,h){return this.internalStream(k).accumulate(h)},nodeStream:function(k,h){return this.internalStream(k||"nodebuffer").toNodejsStream(h)},_compressWorker:function(k,h){if(this._data instanceof c&&this._data.compression.magic===k.magic)return this._data.getCompressedWorker();var b=this._decompressWorker();return this._dataBinary||(b=b.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(b,k,h)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new o(this._data)}};for(var p=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],g=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},u=0;u<p.length;u++)r.prototype[p[u]]=g;s.exports=r},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(e,s,n){(function(r){var l,o,a=r.MutationObserver||r.WebKitMutationObserver;if(a){var c=0,d=new a(k),p=r.document.createTextNode("");d.observe(p,{characterData:!0}),l=function(){p.data=c=++c%2}}else if(r.setImmediate||r.MessageChannel===void 0)l="document"in r&&"onreadystatechange"in r.document.createElement("script")?function(){var h=r.document.createElement("script");h.onreadystatechange=function(){k(),h.onreadystatechange=null,h.parentNode.removeChild(h),h=null},r.document.documentElement.appendChild(h)}:function(){setTimeout(k,0)};else{var g=new r.MessageChannel;g.port1.onmessage=k,l=function(){g.port2.postMessage(0)}}var u=[];function k(){var h,b;o=!0;for(var v=u.length;v;){for(b=u,u=[],h=-1;++h<v;)b[h]();v=u.length}o=!1}s.exports=function(h){u.push(h)!==1||o||l()}}).call(this,typeof Nn<"u"?Nn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(e,s,n){var r=e("immediate");function l(){}var o={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function p(v){if(typeof v!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,v!==l&&h(this,v)}function g(v,y,$){this.promise=v,typeof y=="function"&&(this.onFulfilled=y,this.callFulfilled=this.otherCallFulfilled),typeof $=="function"&&(this.onRejected=$,this.callRejected=this.otherCallRejected)}function u(v,y,$){r(function(){var A;try{A=y($)}catch(x){return o.reject(v,x)}A===v?o.reject(v,new TypeError("Cannot resolve promise with itself")):o.resolve(v,A)})}function k(v){var y=v&&v.then;if(v&&(typeof v=="object"||typeof v=="function")&&typeof y=="function")return function(){y.apply(v,arguments)}}function h(v,y){var $=!1;function A(S){$||($=!0,o.reject(v,S))}function x(S){$||($=!0,o.resolve(v,S))}var _=b(function(){y(x,A)});_.status==="error"&&A(_.value)}function b(v,y){var $={};try{$.value=v(y),$.status="success"}catch(A){$.status="error",$.value=A}return $}(s.exports=p).prototype.finally=function(v){if(typeof v!="function")return this;var y=this.constructor;return this.then(function($){return y.resolve(v()).then(function(){return $})},function($){return y.resolve(v()).then(function(){throw $})})},p.prototype.catch=function(v){return this.then(null,v)},p.prototype.then=function(v,y){if(typeof v!="function"&&this.state===c||typeof y!="function"&&this.state===a)return this;var $=new this.constructor(l);return this.state!==d?u($,this.state===c?v:y,this.outcome):this.queue.push(new g($,v,y)),$},g.prototype.callFulfilled=function(v){o.resolve(this.promise,v)},g.prototype.otherCallFulfilled=function(v){u(this.promise,this.onFulfilled,v)},g.prototype.callRejected=function(v){o.reject(this.promise,v)},g.prototype.otherCallRejected=function(v){u(this.promise,this.onRejected,v)},o.resolve=function(v,y){var $=b(k,y);if($.status==="error")return o.reject(v,$.value);var A=$.value;if(A)h(v,A);else{v.state=c,v.outcome=y;for(var x=-1,_=v.queue.length;++x<_;)v.queue[x].callFulfilled(y)}return v},o.reject=function(v,y){v.state=a,v.outcome=y;for(var $=-1,A=v.queue.length;++$<A;)v.queue[$].callRejected(y);return v},p.resolve=function(v){return v instanceof this?v:o.resolve(new this(l),v)},p.reject=function(v){var y=new this(l);return o.reject(y,v)},p.all=function(v){var y=this;if(Object.prototype.toString.call(v)!=="[object Array]")return this.reject(new TypeError("must be an array"));var $=v.length,A=!1;if(!$)return this.resolve([]);for(var x=new Array($),_=0,S=-1,D=new this(l);++S<$;)M(v[S],S);return D;function M(P,J){y.resolve(P).then(function(T){x[J]=T,++_!==$||A||(A=!0,o.resolve(D,x))},function(T){A||(A=!0,o.reject(D,T))})}},p.race=function(v){var y=this;if(Object.prototype.toString.call(v)!=="[object Array]")return this.reject(new TypeError("must be an array"));var $=v.length,A=!1;if(!$)return this.resolve([]);for(var x=-1,_=new this(l);++x<$;)S=v[x],y.resolve(S).then(function(D){A||(A=!0,o.resolve(_,D))},function(D){A||(A=!0,o.reject(_,D))});var S;return _}},{immediate:36}],38:[function(e,s,n){var r={};(0,e("./lib/utils/common").assign)(r,e("./lib/deflate"),e("./lib/inflate"),e("./lib/zlib/constants")),s.exports=r},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(e,s,n){var r=e("./zlib/deflate"),l=e("./utils/common"),o=e("./utils/strings"),a=e("./zlib/messages"),c=e("./zlib/zstream"),d=Object.prototype.toString,p=0,g=-1,u=0,k=8;function h(v){if(!(this instanceof h))return new h(v);this.options=l.assign({level:g,method:k,chunkSize:16384,windowBits:15,memLevel:8,strategy:u,to:""},v||{});var y=this.options;y.raw&&0<y.windowBits?y.windowBits=-y.windowBits:y.gzip&&0<y.windowBits&&y.windowBits<16&&(y.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var $=r.deflateInit2(this.strm,y.level,y.method,y.windowBits,y.memLevel,y.strategy);if($!==p)throw new Error(a[$]);if(y.header&&r.deflateSetHeader(this.strm,y.header),y.dictionary){var A;if(A=typeof y.dictionary=="string"?o.string2buf(y.dictionary):d.call(y.dictionary)==="[object ArrayBuffer]"?new Uint8Array(y.dictionary):y.dictionary,($=r.deflateSetDictionary(this.strm,A))!==p)throw new Error(a[$]);this._dict_set=!0}}function b(v,y){var $=new h(y);if($.push(v,!0),$.err)throw $.msg||a[$.err];return $.result}h.prototype.push=function(v,y){var $,A,x=this.strm,_=this.options.chunkSize;if(this.ended)return!1;A=y===~~y?y:y===!0?4:0,typeof v=="string"?x.input=o.string2buf(v):d.call(v)==="[object ArrayBuffer]"?x.input=new Uint8Array(v):x.input=v,x.next_in=0,x.avail_in=x.input.length;do{if(x.avail_out===0&&(x.output=new l.Buf8(_),x.next_out=0,x.avail_out=_),($=r.deflate(x,A))!==1&&$!==p)return this.onEnd($),!(this.ended=!0);x.avail_out!==0&&(x.avail_in!==0||A!==4&&A!==2)||(this.options.to==="string"?this.onData(o.buf2binstring(l.shrinkBuf(x.output,x.next_out))):this.onData(l.shrinkBuf(x.output,x.next_out)))}while((0<x.avail_in||x.avail_out===0)&&$!==1);return A===4?($=r.deflateEnd(this.strm),this.onEnd($),this.ended=!0,$===p):A!==2||(this.onEnd(p),!(x.avail_out=0))},h.prototype.onData=function(v){this.chunks.push(v)},h.prototype.onEnd=function(v){v===p&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=v,this.msg=this.strm.msg},n.Deflate=h,n.deflate=b,n.deflateRaw=function(v,y){return(y=y||{}).raw=!0,b(v,y)},n.gzip=function(v,y){return(y=y||{}).gzip=!0,b(v,y)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(e,s,n){var r=e("./zlib/inflate"),l=e("./utils/common"),o=e("./utils/strings"),a=e("./zlib/constants"),c=e("./zlib/messages"),d=e("./zlib/zstream"),p=e("./zlib/gzheader"),g=Object.prototype.toString;function u(h){if(!(this instanceof u))return new u(h);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},h||{});var b=this.options;b.raw&&0<=b.windowBits&&b.windowBits<16&&(b.windowBits=-b.windowBits,b.windowBits===0&&(b.windowBits=-15)),!(0<=b.windowBits&&b.windowBits<16)||h&&h.windowBits||(b.windowBits+=32),15<b.windowBits&&b.windowBits<48&&(15&b.windowBits)==0&&(b.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var v=r.inflateInit2(this.strm,b.windowBits);if(v!==a.Z_OK)throw new Error(c[v]);this.header=new p,r.inflateGetHeader(this.strm,this.header)}function k(h,b){var v=new u(b);if(v.push(h,!0),v.err)throw v.msg||c[v.err];return v.result}u.prototype.push=function(h,b){var v,y,$,A,x,_,S=this.strm,D=this.options.chunkSize,M=this.options.dictionary,P=!1;if(this.ended)return!1;y=b===~~b?b:b===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof h=="string"?S.input=o.binstring2buf(h):g.call(h)==="[object ArrayBuffer]"?S.input=new Uint8Array(h):S.input=h,S.next_in=0,S.avail_in=S.input.length;do{if(S.avail_out===0&&(S.output=new l.Buf8(D),S.next_out=0,S.avail_out=D),(v=r.inflate(S,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&M&&(_=typeof M=="string"?o.string2buf(M):g.call(M)==="[object ArrayBuffer]"?new Uint8Array(M):M,v=r.inflateSetDictionary(this.strm,_)),v===a.Z_BUF_ERROR&&P===!0&&(v=a.Z_OK,P=!1),v!==a.Z_STREAM_END&&v!==a.Z_OK)return this.onEnd(v),!(this.ended=!0);S.next_out&&(S.avail_out!==0&&v!==a.Z_STREAM_END&&(S.avail_in!==0||y!==a.Z_FINISH&&y!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?($=o.utf8border(S.output,S.next_out),A=S.next_out-$,x=o.buf2string(S.output,$),S.next_out=A,S.avail_out=D-A,A&&l.arraySet(S.output,S.output,$,A,0),this.onData(x)):this.onData(l.shrinkBuf(S.output,S.next_out)))),S.avail_in===0&&S.avail_out===0&&(P=!0)}while((0<S.avail_in||S.avail_out===0)&&v!==a.Z_STREAM_END);return v===a.Z_STREAM_END&&(y=a.Z_FINISH),y===a.Z_FINISH?(v=r.inflateEnd(this.strm),this.onEnd(v),this.ended=!0,v===a.Z_OK):y!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(S.avail_out=0))},u.prototype.onData=function(h){this.chunks.push(h)},u.prototype.onEnd=function(h){h===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=h,this.msg=this.strm.msg},n.Inflate=u,n.inflate=k,n.inflateRaw=function(h,b){return(b=b||{}).raw=!0,k(h,b)},n.ungzip=k},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(e,s,n){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";n.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var p in d)d.hasOwnProperty(p)&&(a[p]=d[p])}}return a},n.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,p,g){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+p),g);else for(var u=0;u<p;u++)a[g+u]=c[d+u]},flattenChunks:function(a){var c,d,p,g,u,k;for(c=p=0,d=a.length;c<d;c++)p+=a[c].length;for(k=new Uint8Array(p),c=g=0,d=a.length;c<d;c++)u=a[c],k.set(u,g),g+=u.length;return k}},o={arraySet:function(a,c,d,p,g){for(var u=0;u<p;u++)a[g+u]=c[d+u]},flattenChunks:function(a){return[].concat.apply([],a)}};n.setTyped=function(a){a?(n.Buf8=Uint8Array,n.Buf16=Uint16Array,n.Buf32=Int32Array,n.assign(n,l)):(n.Buf8=Array,n.Buf16=Array,n.Buf32=Array,n.assign(n,o))},n.setTyped(r)},{}],42:[function(e,s,n){var r=e("./common"),l=!0,o=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{o=!1}for(var a=new r.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(p,g){if(g<65537&&(p.subarray&&o||!p.subarray&&l))return String.fromCharCode.apply(null,r.shrinkBuf(p,g));for(var u="",k=0;k<g;k++)u+=String.fromCharCode(p[k]);return u}a[254]=a[254]=1,n.string2buf=function(p){var g,u,k,h,b,v=p.length,y=0;for(h=0;h<v;h++)(64512&(u=p.charCodeAt(h)))==55296&&h+1<v&&(64512&(k=p.charCodeAt(h+1)))==56320&&(u=65536+(u-55296<<10)+(k-56320),h++),y+=u<128?1:u<2048?2:u<65536?3:4;for(g=new r.Buf8(y),h=b=0;b<y;h++)(64512&(u=p.charCodeAt(h)))==55296&&h+1<v&&(64512&(k=p.charCodeAt(h+1)))==56320&&(u=65536+(u-55296<<10)+(k-56320),h++),u<128?g[b++]=u:(u<2048?g[b++]=192|u>>>6:(u<65536?g[b++]=224|u>>>12:(g[b++]=240|u>>>18,g[b++]=128|u>>>12&63),g[b++]=128|u>>>6&63),g[b++]=128|63&u);return g},n.buf2binstring=function(p){return d(p,p.length)},n.binstring2buf=function(p){for(var g=new r.Buf8(p.length),u=0,k=g.length;u<k;u++)g[u]=p.charCodeAt(u);return g},n.buf2string=function(p,g){var u,k,h,b,v=g||p.length,y=new Array(2*v);for(u=k=0;u<v;)if((h=p[u++])<128)y[k++]=h;else if(4<(b=a[h]))y[k++]=65533,u+=b-1;else{for(h&=b===2?31:b===3?15:7;1<b&&u<v;)h=h<<6|63&p[u++],b--;1<b?y[k++]=65533:h<65536?y[k++]=h:(h-=65536,y[k++]=55296|h>>10&1023,y[k++]=56320|1023&h)}return d(y,k)},n.utf8border=function(p,g){var u;for((g=g||p.length)>p.length&&(g=p.length),u=g-1;0<=u&&(192&p[u])==128;)u--;return u<0||u===0?g:u+a[p[u]]>g?u:g}},{"./common":41}],43:[function(e,s,n){s.exports=function(r,l,o,a){for(var c=65535&r|0,d=r>>>16&65535|0,p=0;o!==0;){for(o-=p=2e3<o?2e3:o;d=d+(c=c+l[a++]|0)|0,--p;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(e,s,n){s.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(e,s,n){var r=(function(){for(var l,o=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;o[a]=l}return o})();s.exports=function(l,o,a,c){var d=r,p=c+a;l^=-1;for(var g=c;g<p;g++)l=l>>>8^d[255&(l^o[g])];return-1^l}},{}],46:[function(e,s,n){var r,l=e("../utils/common"),o=e("./trees"),a=e("./adler32"),c=e("./crc32"),d=e("./messages"),p=0,g=4,u=0,k=-2,h=-1,b=4,v=2,y=8,$=9,A=286,x=30,_=19,S=2*A+1,D=15,M=3,P=258,J=P+M+1,T=42,L=113,w=1,F=2,Q=3,V=4;function it(f,N){return f.msg=d[N],N}function U(f){return(f<<1)-(4<f?9:0)}function Y(f){for(var N=f.length;0<=--N;)f[N]=0}function W(f){var N=f.state,O=N.pending;O>f.avail_out&&(O=f.avail_out),O!==0&&(l.arraySet(f.output,N.pending_buf,N.pending_out,O,f.next_out),f.next_out+=O,N.pending_out+=O,f.total_out+=O,f.avail_out-=O,N.pending-=O,N.pending===0&&(N.pending_out=0))}function z(f,N){o._tr_flush_block(f,0<=f.block_start?f.block_start:-1,f.strstart-f.block_start,N),f.block_start=f.strstart,W(f.strm)}function ct(f,N){f.pending_buf[f.pending++]=N}function lt(f,N){f.pending_buf[f.pending++]=N>>>8&255,f.pending_buf[f.pending++]=255&N}function ot(f,N){var O,C,I=f.max_chain_length,B=f.strstart,K=f.prev_length,j=f.nice_match,H=f.strstart>f.w_size-J?f.strstart-(f.w_size-J):0,Z=f.window,nt=f.w_mask,X=f.prev,dt=f.strstart+P,xt=Z[B+K-1],bt=Z[B+K];f.prev_length>=f.good_match&&(I>>=2),j>f.lookahead&&(j=f.lookahead);do if(Z[(O=N)+K]===bt&&Z[O+K-1]===xt&&Z[O]===Z[B]&&Z[++O]===Z[B+1]){B+=2,O++;do;while(Z[++B]===Z[++O]&&Z[++B]===Z[++O]&&Z[++B]===Z[++O]&&Z[++B]===Z[++O]&&Z[++B]===Z[++O]&&Z[++B]===Z[++O]&&Z[++B]===Z[++O]&&Z[++B]===Z[++O]&&B<dt);if(C=P-(dt-B),B=dt-P,K<C){if(f.match_start=N,j<=(K=C))break;xt=Z[B+K-1],bt=Z[B+K]}}while((N=X[N&nt])>H&&--I!=0);return K<=f.lookahead?K:f.lookahead}function tt(f){var N,O,C,I,B,K,j,H,Z,nt,X=f.w_size;do{if(I=f.window_size-f.lookahead-f.strstart,f.strstart>=X+(X-J)){for(l.arraySet(f.window,f.window,X,X,0),f.match_start-=X,f.strstart-=X,f.block_start-=X,N=O=f.hash_size;C=f.head[--N],f.head[N]=X<=C?C-X:0,--O;);for(N=O=X;C=f.prev[--N],f.prev[N]=X<=C?C-X:0,--O;);I+=X}if(f.strm.avail_in===0)break;if(K=f.strm,j=f.window,H=f.strstart+f.lookahead,Z=I,nt=void 0,nt=K.avail_in,Z<nt&&(nt=Z),O=nt===0?0:(K.avail_in-=nt,l.arraySet(j,K.input,K.next_in,nt,H),K.state.wrap===1?K.adler=a(K.adler,j,nt,H):K.state.wrap===2&&(K.adler=c(K.adler,j,nt,H)),K.next_in+=nt,K.total_in+=nt,nt),f.lookahead+=O,f.lookahead+f.insert>=M)for(B=f.strstart-f.insert,f.ins_h=f.window[B],f.ins_h=(f.ins_h<<f.hash_shift^f.window[B+1])&f.hash_mask;f.insert&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[B+M-1])&f.hash_mask,f.prev[B&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=B,B++,f.insert--,!(f.lookahead+f.insert<M)););}while(f.lookahead<J&&f.strm.avail_in!==0)}function gt(f,N){for(var O,C;;){if(f.lookahead<J){if(tt(f),f.lookahead<J&&N===p)return w;if(f.lookahead===0)break}if(O=0,f.lookahead>=M&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+M-1])&f.hash_mask,O=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart),O!==0&&f.strstart-O<=f.w_size-J&&(f.match_length=ot(f,O)),f.match_length>=M)if(C=o._tr_tally(f,f.strstart-f.match_start,f.match_length-M),f.lookahead-=f.match_length,f.match_length<=f.max_lazy_match&&f.lookahead>=M){for(f.match_length--;f.strstart++,f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+M-1])&f.hash_mask,O=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart,--f.match_length!=0;);f.strstart++}else f.strstart+=f.match_length,f.match_length=0,f.ins_h=f.window[f.strstart],f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+1])&f.hash_mask;else C=o._tr_tally(f,0,f.window[f.strstart]),f.lookahead--,f.strstart++;if(C&&(z(f,!1),f.strm.avail_out===0))return w}return f.insert=f.strstart<M-1?f.strstart:M-1,N===g?(z(f,!0),f.strm.avail_out===0?Q:V):f.last_lit&&(z(f,!1),f.strm.avail_out===0)?w:F}function mt(f,N){for(var O,C,I;;){if(f.lookahead<J){if(tt(f),f.lookahead<J&&N===p)return w;if(f.lookahead===0)break}if(O=0,f.lookahead>=M&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+M-1])&f.hash_mask,O=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart),f.prev_length=f.match_length,f.prev_match=f.match_start,f.match_length=M-1,O!==0&&f.prev_length<f.max_lazy_match&&f.strstart-O<=f.w_size-J&&(f.match_length=ot(f,O),f.match_length<=5&&(f.strategy===1||f.match_length===M&&4096<f.strstart-f.match_start)&&(f.match_length=M-1)),f.prev_length>=M&&f.match_length<=f.prev_length){for(I=f.strstart+f.lookahead-M,C=o._tr_tally(f,f.strstart-1-f.prev_match,f.prev_length-M),f.lookahead-=f.prev_length-1,f.prev_length-=2;++f.strstart<=I&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+M-1])&f.hash_mask,O=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart),--f.prev_length!=0;);if(f.match_available=0,f.match_length=M-1,f.strstart++,C&&(z(f,!1),f.strm.avail_out===0))return w}else if(f.match_available){if((C=o._tr_tally(f,0,f.window[f.strstart-1]))&&z(f,!1),f.strstart++,f.lookahead--,f.strm.avail_out===0)return w}else f.match_available=1,f.strstart++,f.lookahead--}return f.match_available&&(C=o._tr_tally(f,0,f.window[f.strstart-1]),f.match_available=0),f.insert=f.strstart<M-1?f.strstart:M-1,N===g?(z(f,!0),f.strm.avail_out===0?Q:V):f.last_lit&&(z(f,!1),f.strm.avail_out===0)?w:F}function G(f,N,O,C,I){this.good_length=f,this.max_lazy=N,this.nice_length=O,this.max_chain=C,this.func=I}function rt(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=y,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*S),this.dyn_dtree=new l.Buf16(2*(2*x+1)),this.bl_tree=new l.Buf16(2*(2*_+1)),Y(this.dyn_ltree),Y(this.dyn_dtree),Y(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(D+1),this.heap=new l.Buf16(2*A+1),Y(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*A+1),Y(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ut(f){var N;return f&&f.state?(f.total_in=f.total_out=0,f.data_type=v,(N=f.state).pending=0,N.pending_out=0,N.wrap<0&&(N.wrap=-N.wrap),N.status=N.wrap?T:L,f.adler=N.wrap===2?0:1,N.last_flush=p,o._tr_init(N),u):it(f,k)}function E(f){var N=ut(f);return N===u&&(function(O){O.window_size=2*O.w_size,Y(O.head),O.max_lazy_match=r[O.level].max_lazy,O.good_match=r[O.level].good_length,O.nice_match=r[O.level].nice_length,O.max_chain_length=r[O.level].max_chain,O.strstart=0,O.block_start=0,O.lookahead=0,O.insert=0,O.match_length=O.prev_length=M-1,O.match_available=0,O.ins_h=0})(f.state),N}function R(f,N,O,C,I,B){if(!f)return k;var K=1;if(N===h&&(N=6),C<0?(K=0,C=-C):15<C&&(K=2,C-=16),I<1||$<I||O!==y||C<8||15<C||N<0||9<N||B<0||b<B)return it(f,k);C===8&&(C=9);var j=new rt;return(f.state=j).strm=f,j.wrap=K,j.gzhead=null,j.w_bits=C,j.w_size=1<<j.w_bits,j.w_mask=j.w_size-1,j.hash_bits=I+7,j.hash_size=1<<j.hash_bits,j.hash_mask=j.hash_size-1,j.hash_shift=~~((j.hash_bits+M-1)/M),j.window=new l.Buf8(2*j.w_size),j.head=new l.Buf16(j.hash_size),j.prev=new l.Buf16(j.w_size),j.lit_bufsize=1<<I+6,j.pending_buf_size=4*j.lit_bufsize,j.pending_buf=new l.Buf8(j.pending_buf_size),j.d_buf=1*j.lit_bufsize,j.l_buf=3*j.lit_bufsize,j.level=N,j.strategy=B,j.method=O,E(f)}r=[new G(0,0,0,0,function(f,N){var O=65535;for(O>f.pending_buf_size-5&&(O=f.pending_buf_size-5);;){if(f.lookahead<=1){if(tt(f),f.lookahead===0&&N===p)return w;if(f.lookahead===0)break}f.strstart+=f.lookahead,f.lookahead=0;var C=f.block_start+O;if((f.strstart===0||f.strstart>=C)&&(f.lookahead=f.strstart-C,f.strstart=C,z(f,!1),f.strm.avail_out===0)||f.strstart-f.block_start>=f.w_size-J&&(z(f,!1),f.strm.avail_out===0))return w}return f.insert=0,N===g?(z(f,!0),f.strm.avail_out===0?Q:V):(f.strstart>f.block_start&&(z(f,!1),f.strm.avail_out),w)}),new G(4,4,8,4,gt),new G(4,5,16,8,gt),new G(4,6,32,32,gt),new G(4,4,16,16,mt),new G(8,16,32,32,mt),new G(8,16,128,128,mt),new G(8,32,128,256,mt),new G(32,128,258,1024,mt),new G(32,258,258,4096,mt)],n.deflateInit=function(f,N){return R(f,N,y,15,8,0)},n.deflateInit2=R,n.deflateReset=E,n.deflateResetKeep=ut,n.deflateSetHeader=function(f,N){return f&&f.state?f.state.wrap!==2?k:(f.state.gzhead=N,u):k},n.deflate=function(f,N){var O,C,I,B;if(!f||!f.state||5<N||N<0)return f?it(f,k):k;if(C=f.state,!f.output||!f.input&&f.avail_in!==0||C.status===666&&N!==g)return it(f,f.avail_out===0?-5:k);if(C.strm=f,O=C.last_flush,C.last_flush=N,C.status===T)if(C.wrap===2)f.adler=0,ct(C,31),ct(C,139),ct(C,8),C.gzhead?(ct(C,(C.gzhead.text?1:0)+(C.gzhead.hcrc?2:0)+(C.gzhead.extra?4:0)+(C.gzhead.name?8:0)+(C.gzhead.comment?16:0)),ct(C,255&C.gzhead.time),ct(C,C.gzhead.time>>8&255),ct(C,C.gzhead.time>>16&255),ct(C,C.gzhead.time>>24&255),ct(C,C.level===9?2:2<=C.strategy||C.level<2?4:0),ct(C,255&C.gzhead.os),C.gzhead.extra&&C.gzhead.extra.length&&(ct(C,255&C.gzhead.extra.length),ct(C,C.gzhead.extra.length>>8&255)),C.gzhead.hcrc&&(f.adler=c(f.adler,C.pending_buf,C.pending,0)),C.gzindex=0,C.status=69):(ct(C,0),ct(C,0),ct(C,0),ct(C,0),ct(C,0),ct(C,C.level===9?2:2<=C.strategy||C.level<2?4:0),ct(C,3),C.status=L);else{var K=y+(C.w_bits-8<<4)<<8;K|=(2<=C.strategy||C.level<2?0:C.level<6?1:C.level===6?2:3)<<6,C.strstart!==0&&(K|=32),K+=31-K%31,C.status=L,lt(C,K),C.strstart!==0&&(lt(C,f.adler>>>16),lt(C,65535&f.adler)),f.adler=1}if(C.status===69)if(C.gzhead.extra){for(I=C.pending;C.gzindex<(65535&C.gzhead.extra.length)&&(C.pending!==C.pending_buf_size||(C.gzhead.hcrc&&C.pending>I&&(f.adler=c(f.adler,C.pending_buf,C.pending-I,I)),W(f),I=C.pending,C.pending!==C.pending_buf_size));)ct(C,255&C.gzhead.extra[C.gzindex]),C.gzindex++;C.gzhead.hcrc&&C.pending>I&&(f.adler=c(f.adler,C.pending_buf,C.pending-I,I)),C.gzindex===C.gzhead.extra.length&&(C.gzindex=0,C.status=73)}else C.status=73;if(C.status===73)if(C.gzhead.name){I=C.pending;do{if(C.pending===C.pending_buf_size&&(C.gzhead.hcrc&&C.pending>I&&(f.adler=c(f.adler,C.pending_buf,C.pending-I,I)),W(f),I=C.pending,C.pending===C.pending_buf_size)){B=1;break}B=C.gzindex<C.gzhead.name.length?255&C.gzhead.name.charCodeAt(C.gzindex++):0,ct(C,B)}while(B!==0);C.gzhead.hcrc&&C.pending>I&&(f.adler=c(f.adler,C.pending_buf,C.pending-I,I)),B===0&&(C.gzindex=0,C.status=91)}else C.status=91;if(C.status===91)if(C.gzhead.comment){I=C.pending;do{if(C.pending===C.pending_buf_size&&(C.gzhead.hcrc&&C.pending>I&&(f.adler=c(f.adler,C.pending_buf,C.pending-I,I)),W(f),I=C.pending,C.pending===C.pending_buf_size)){B=1;break}B=C.gzindex<C.gzhead.comment.length?255&C.gzhead.comment.charCodeAt(C.gzindex++):0,ct(C,B)}while(B!==0);C.gzhead.hcrc&&C.pending>I&&(f.adler=c(f.adler,C.pending_buf,C.pending-I,I)),B===0&&(C.status=103)}else C.status=103;if(C.status===103&&(C.gzhead.hcrc?(C.pending+2>C.pending_buf_size&&W(f),C.pending+2<=C.pending_buf_size&&(ct(C,255&f.adler),ct(C,f.adler>>8&255),f.adler=0,C.status=L)):C.status=L),C.pending!==0){if(W(f),f.avail_out===0)return C.last_flush=-1,u}else if(f.avail_in===0&&U(N)<=U(O)&&N!==g)return it(f,-5);if(C.status===666&&f.avail_in!==0)return it(f,-5);if(f.avail_in!==0||C.lookahead!==0||N!==p&&C.status!==666){var j=C.strategy===2?(function(H,Z){for(var nt;;){if(H.lookahead===0&&(tt(H),H.lookahead===0)){if(Z===p)return w;break}if(H.match_length=0,nt=o._tr_tally(H,0,H.window[H.strstart]),H.lookahead--,H.strstart++,nt&&(z(H,!1),H.strm.avail_out===0))return w}return H.insert=0,Z===g?(z(H,!0),H.strm.avail_out===0?Q:V):H.last_lit&&(z(H,!1),H.strm.avail_out===0)?w:F})(C,N):C.strategy===3?(function(H,Z){for(var nt,X,dt,xt,bt=H.window;;){if(H.lookahead<=P){if(tt(H),H.lookahead<=P&&Z===p)return w;if(H.lookahead===0)break}if(H.match_length=0,H.lookahead>=M&&0<H.strstart&&(X=bt[dt=H.strstart-1])===bt[++dt]&&X===bt[++dt]&&X===bt[++dt]){xt=H.strstart+P;do;while(X===bt[++dt]&&X===bt[++dt]&&X===bt[++dt]&&X===bt[++dt]&&X===bt[++dt]&&X===bt[++dt]&&X===bt[++dt]&&X===bt[++dt]&&dt<xt);H.match_length=P-(xt-dt),H.match_length>H.lookahead&&(H.match_length=H.lookahead)}if(H.match_length>=M?(nt=o._tr_tally(H,1,H.match_length-M),H.lookahead-=H.match_length,H.strstart+=H.match_length,H.match_length=0):(nt=o._tr_tally(H,0,H.window[H.strstart]),H.lookahead--,H.strstart++),nt&&(z(H,!1),H.strm.avail_out===0))return w}return H.insert=0,Z===g?(z(H,!0),H.strm.avail_out===0?Q:V):H.last_lit&&(z(H,!1),H.strm.avail_out===0)?w:F})(C,N):r[C.level].func(C,N);if(j!==Q&&j!==V||(C.status=666),j===w||j===Q)return f.avail_out===0&&(C.last_flush=-1),u;if(j===F&&(N===1?o._tr_align(C):N!==5&&(o._tr_stored_block(C,0,0,!1),N===3&&(Y(C.head),C.lookahead===0&&(C.strstart=0,C.block_start=0,C.insert=0))),W(f),f.avail_out===0))return C.last_flush=-1,u}return N!==g?u:C.wrap<=0?1:(C.wrap===2?(ct(C,255&f.adler),ct(C,f.adler>>8&255),ct(C,f.adler>>16&255),ct(C,f.adler>>24&255),ct(C,255&f.total_in),ct(C,f.total_in>>8&255),ct(C,f.total_in>>16&255),ct(C,f.total_in>>24&255)):(lt(C,f.adler>>>16),lt(C,65535&f.adler)),W(f),0<C.wrap&&(C.wrap=-C.wrap),C.pending!==0?u:1)},n.deflateEnd=function(f){var N;return f&&f.state?(N=f.state.status)!==T&&N!==69&&N!==73&&N!==91&&N!==103&&N!==L&&N!==666?it(f,k):(f.state=null,N===L?it(f,-3):u):k},n.deflateSetDictionary=function(f,N){var O,C,I,B,K,j,H,Z,nt=N.length;if(!f||!f.state||(B=(O=f.state).wrap)===2||B===1&&O.status!==T||O.lookahead)return k;for(B===1&&(f.adler=a(f.adler,N,nt,0)),O.wrap=0,nt>=O.w_size&&(B===0&&(Y(O.head),O.strstart=0,O.block_start=0,O.insert=0),Z=new l.Buf8(O.w_size),l.arraySet(Z,N,nt-O.w_size,O.w_size,0),N=Z,nt=O.w_size),K=f.avail_in,j=f.next_in,H=f.input,f.avail_in=nt,f.next_in=0,f.input=N,tt(O);O.lookahead>=M;){for(C=O.strstart,I=O.lookahead-(M-1);O.ins_h=(O.ins_h<<O.hash_shift^O.window[C+M-1])&O.hash_mask,O.prev[C&O.w_mask]=O.head[O.ins_h],O.head[O.ins_h]=C,C++,--I;);O.strstart=C,O.lookahead=M-1,tt(O)}return O.strstart+=O.lookahead,O.block_start=O.strstart,O.insert=O.lookahead,O.lookahead=0,O.match_length=O.prev_length=M-1,O.match_available=0,f.next_in=j,f.input=H,f.avail_in=K,O.wrap=B,u},n.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(e,s,n){s.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(e,s,n){s.exports=function(r,l){var o,a,c,d,p,g,u,k,h,b,v,y,$,A,x,_,S,D,M,P,J,T,L,w,F;o=r.state,a=r.next_in,w=r.input,c=a+(r.avail_in-5),d=r.next_out,F=r.output,p=d-(l-r.avail_out),g=d+(r.avail_out-257),u=o.dmax,k=o.wsize,h=o.whave,b=o.wnext,v=o.window,y=o.hold,$=o.bits,A=o.lencode,x=o.distcode,_=(1<<o.lenbits)-1,S=(1<<o.distbits)-1;t:do{$<15&&(y+=w[a++]<<$,$+=8,y+=w[a++]<<$,$+=8),D=A[y&_];e:for(;;){if(y>>>=M=D>>>24,$-=M,(M=D>>>16&255)===0)F[d++]=65535&D;else{if(!(16&M)){if((64&M)==0){D=A[(65535&D)+(y&(1<<M)-1)];continue e}if(32&M){o.mode=12;break t}r.msg="invalid literal/length code",o.mode=30;break t}P=65535&D,(M&=15)&&($<M&&(y+=w[a++]<<$,$+=8),P+=y&(1<<M)-1,y>>>=M,$-=M),$<15&&(y+=w[a++]<<$,$+=8,y+=w[a++]<<$,$+=8),D=x[y&S];i:for(;;){if(y>>>=M=D>>>24,$-=M,!(16&(M=D>>>16&255))){if((64&M)==0){D=x[(65535&D)+(y&(1<<M)-1)];continue i}r.msg="invalid distance code",o.mode=30;break t}if(J=65535&D,$<(M&=15)&&(y+=w[a++]<<$,($+=8)<M&&(y+=w[a++]<<$,$+=8)),u<(J+=y&(1<<M)-1)){r.msg="invalid distance too far back",o.mode=30;break t}if(y>>>=M,$-=M,(M=d-p)<J){if(h<(M=J-M)&&o.sane){r.msg="invalid distance too far back",o.mode=30;break t}if(L=v,(T=0)===b){if(T+=k-M,M<P){for(P-=M;F[d++]=v[T++],--M;);T=d-J,L=F}}else if(b<M){if(T+=k+b-M,(M-=b)<P){for(P-=M;F[d++]=v[T++],--M;);if(T=0,b<P){for(P-=M=b;F[d++]=v[T++],--M;);T=d-J,L=F}}}else if(T+=b-M,M<P){for(P-=M;F[d++]=v[T++],--M;);T=d-J,L=F}for(;2<P;)F[d++]=L[T++],F[d++]=L[T++],F[d++]=L[T++],P-=3;P&&(F[d++]=L[T++],1<P&&(F[d++]=L[T++]))}else{for(T=d-J;F[d++]=F[T++],F[d++]=F[T++],F[d++]=F[T++],2<(P-=3););P&&(F[d++]=F[T++],1<P&&(F[d++]=F[T++]))}break}}break}}while(a<c&&d<g);a-=P=$>>3,y&=(1<<($-=P<<3))-1,r.next_in=a,r.next_out=d,r.avail_in=a<c?c-a+5:5-(a-c),r.avail_out=d<g?g-d+257:257-(d-g),o.hold=y,o.bits=$}},{}],49:[function(e,s,n){var r=e("../utils/common"),l=e("./adler32"),o=e("./crc32"),a=e("./inffast"),c=e("./inftrees"),d=1,p=2,g=0,u=-2,k=1,h=852,b=592;function v(T){return(T>>>24&255)+(T>>>8&65280)+((65280&T)<<8)+((255&T)<<24)}function y(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new r.Buf16(320),this.work=new r.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function $(T){var L;return T&&T.state?(L=T.state,T.total_in=T.total_out=L.total=0,T.msg="",L.wrap&&(T.adler=1&L.wrap),L.mode=k,L.last=0,L.havedict=0,L.dmax=32768,L.head=null,L.hold=0,L.bits=0,L.lencode=L.lendyn=new r.Buf32(h),L.distcode=L.distdyn=new r.Buf32(b),L.sane=1,L.back=-1,g):u}function A(T){var L;return T&&T.state?((L=T.state).wsize=0,L.whave=0,L.wnext=0,$(T)):u}function x(T,L){var w,F;return T&&T.state?(F=T.state,L<0?(w=0,L=-L):(w=1+(L>>4),L<48&&(L&=15)),L&&(L<8||15<L)?u:(F.window!==null&&F.wbits!==L&&(F.window=null),F.wrap=w,F.wbits=L,A(T))):u}function _(T,L){var w,F;return T?(F=new y,(T.state=F).window=null,(w=x(T,L))!==g&&(T.state=null),w):u}var S,D,M=!0;function P(T){if(M){var L;for(S=new r.Buf32(512),D=new r.Buf32(32),L=0;L<144;)T.lens[L++]=8;for(;L<256;)T.lens[L++]=9;for(;L<280;)T.lens[L++]=7;for(;L<288;)T.lens[L++]=8;for(c(d,T.lens,0,288,S,0,T.work,{bits:9}),L=0;L<32;)T.lens[L++]=5;c(p,T.lens,0,32,D,0,T.work,{bits:5}),M=!1}T.lencode=S,T.lenbits=9,T.distcode=D,T.distbits=5}function J(T,L,w,F){var Q,V=T.state;return V.window===null&&(V.wsize=1<<V.wbits,V.wnext=0,V.whave=0,V.window=new r.Buf8(V.wsize)),F>=V.wsize?(r.arraySet(V.window,L,w-V.wsize,V.wsize,0),V.wnext=0,V.whave=V.wsize):(F<(Q=V.wsize-V.wnext)&&(Q=F),r.arraySet(V.window,L,w-F,Q,V.wnext),(F-=Q)?(r.arraySet(V.window,L,w-F,F,0),V.wnext=F,V.whave=V.wsize):(V.wnext+=Q,V.wnext===V.wsize&&(V.wnext=0),V.whave<V.wsize&&(V.whave+=Q))),0}n.inflateReset=A,n.inflateReset2=x,n.inflateResetKeep=$,n.inflateInit=function(T){return _(T,15)},n.inflateInit2=_,n.inflate=function(T,L){var w,F,Q,V,it,U,Y,W,z,ct,lt,ot,tt,gt,mt,G,rt,ut,E,R,f,N,O,C,I=0,B=new r.Buf8(4),K=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!T||!T.state||!T.output||!T.input&&T.avail_in!==0)return u;(w=T.state).mode===12&&(w.mode=13),it=T.next_out,Q=T.output,Y=T.avail_out,V=T.next_in,F=T.input,U=T.avail_in,W=w.hold,z=w.bits,ct=U,lt=Y,N=g;t:for(;;)switch(w.mode){case k:if(w.wrap===0){w.mode=13;break}for(;z<16;){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}if(2&w.wrap&&W===35615){B[w.check=0]=255&W,B[1]=W>>>8&255,w.check=o(w.check,B,2,0),z=W=0,w.mode=2;break}if(w.flags=0,w.head&&(w.head.done=!1),!(1&w.wrap)||(((255&W)<<8)+(W>>8))%31){T.msg="incorrect header check",w.mode=30;break}if((15&W)!=8){T.msg="unknown compression method",w.mode=30;break}if(z-=4,f=8+(15&(W>>>=4)),w.wbits===0)w.wbits=f;else if(f>w.wbits){T.msg="invalid window size",w.mode=30;break}w.dmax=1<<f,T.adler=w.check=1,w.mode=512&W?10:12,z=W=0;break;case 2:for(;z<16;){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}if(w.flags=W,(255&w.flags)!=8){T.msg="unknown compression method",w.mode=30;break}if(57344&w.flags){T.msg="unknown header flags set",w.mode=30;break}w.head&&(w.head.text=W>>8&1),512&w.flags&&(B[0]=255&W,B[1]=W>>>8&255,w.check=o(w.check,B,2,0)),z=W=0,w.mode=3;case 3:for(;z<32;){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}w.head&&(w.head.time=W),512&w.flags&&(B[0]=255&W,B[1]=W>>>8&255,B[2]=W>>>16&255,B[3]=W>>>24&255,w.check=o(w.check,B,4,0)),z=W=0,w.mode=4;case 4:for(;z<16;){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}w.head&&(w.head.xflags=255&W,w.head.os=W>>8),512&w.flags&&(B[0]=255&W,B[1]=W>>>8&255,w.check=o(w.check,B,2,0)),z=W=0,w.mode=5;case 5:if(1024&w.flags){for(;z<16;){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}w.length=W,w.head&&(w.head.extra_len=W),512&w.flags&&(B[0]=255&W,B[1]=W>>>8&255,w.check=o(w.check,B,2,0)),z=W=0}else w.head&&(w.head.extra=null);w.mode=6;case 6:if(1024&w.flags&&(U<(ot=w.length)&&(ot=U),ot&&(w.head&&(f=w.head.extra_len-w.length,w.head.extra||(w.head.extra=new Array(w.head.extra_len)),r.arraySet(w.head.extra,F,V,ot,f)),512&w.flags&&(w.check=o(w.check,F,ot,V)),U-=ot,V+=ot,w.length-=ot),w.length))break t;w.length=0,w.mode=7;case 7:if(2048&w.flags){if(U===0)break t;for(ot=0;f=F[V+ot++],w.head&&f&&w.length<65536&&(w.head.name+=String.fromCharCode(f)),f&&ot<U;);if(512&w.flags&&(w.check=o(w.check,F,ot,V)),U-=ot,V+=ot,f)break t}else w.head&&(w.head.name=null);w.length=0,w.mode=8;case 8:if(4096&w.flags){if(U===0)break t;for(ot=0;f=F[V+ot++],w.head&&f&&w.length<65536&&(w.head.comment+=String.fromCharCode(f)),f&&ot<U;);if(512&w.flags&&(w.check=o(w.check,F,ot,V)),U-=ot,V+=ot,f)break t}else w.head&&(w.head.comment=null);w.mode=9;case 9:if(512&w.flags){for(;z<16;){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}if(W!==(65535&w.check)){T.msg="header crc mismatch",w.mode=30;break}z=W=0}w.head&&(w.head.hcrc=w.flags>>9&1,w.head.done=!0),T.adler=w.check=0,w.mode=12;break;case 10:for(;z<32;){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}T.adler=w.check=v(W),z=W=0,w.mode=11;case 11:if(w.havedict===0)return T.next_out=it,T.avail_out=Y,T.next_in=V,T.avail_in=U,w.hold=W,w.bits=z,2;T.adler=w.check=1,w.mode=12;case 12:if(L===5||L===6)break t;case 13:if(w.last){W>>>=7&z,z-=7&z,w.mode=27;break}for(;z<3;){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}switch(w.last=1&W,z-=1,3&(W>>>=1)){case 0:w.mode=14;break;case 1:if(P(w),w.mode=20,L!==6)break;W>>>=2,z-=2;break t;case 2:w.mode=17;break;case 3:T.msg="invalid block type",w.mode=30}W>>>=2,z-=2;break;case 14:for(W>>>=7&z,z-=7&z;z<32;){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}if((65535&W)!=(W>>>16^65535)){T.msg="invalid stored block lengths",w.mode=30;break}if(w.length=65535&W,z=W=0,w.mode=15,L===6)break t;case 15:w.mode=16;case 16:if(ot=w.length){if(U<ot&&(ot=U),Y<ot&&(ot=Y),ot===0)break t;r.arraySet(Q,F,V,ot,it),U-=ot,V+=ot,Y-=ot,it+=ot,w.length-=ot;break}w.mode=12;break;case 17:for(;z<14;){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}if(w.nlen=257+(31&W),W>>>=5,z-=5,w.ndist=1+(31&W),W>>>=5,z-=5,w.ncode=4+(15&W),W>>>=4,z-=4,286<w.nlen||30<w.ndist){T.msg="too many length or distance symbols",w.mode=30;break}w.have=0,w.mode=18;case 18:for(;w.have<w.ncode;){for(;z<3;){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}w.lens[K[w.have++]]=7&W,W>>>=3,z-=3}for(;w.have<19;)w.lens[K[w.have++]]=0;if(w.lencode=w.lendyn,w.lenbits=7,O={bits:w.lenbits},N=c(0,w.lens,0,19,w.lencode,0,w.work,O),w.lenbits=O.bits,N){T.msg="invalid code lengths set",w.mode=30;break}w.have=0,w.mode=19;case 19:for(;w.have<w.nlen+w.ndist;){for(;G=(I=w.lencode[W&(1<<w.lenbits)-1])>>>16&255,rt=65535&I,!((mt=I>>>24)<=z);){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}if(rt<16)W>>>=mt,z-=mt,w.lens[w.have++]=rt;else{if(rt===16){for(C=mt+2;z<C;){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}if(W>>>=mt,z-=mt,w.have===0){T.msg="invalid bit length repeat",w.mode=30;break}f=w.lens[w.have-1],ot=3+(3&W),W>>>=2,z-=2}else if(rt===17){for(C=mt+3;z<C;){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}z-=mt,f=0,ot=3+(7&(W>>>=mt)),W>>>=3,z-=3}else{for(C=mt+7;z<C;){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}z-=mt,f=0,ot=11+(127&(W>>>=mt)),W>>>=7,z-=7}if(w.have+ot>w.nlen+w.ndist){T.msg="invalid bit length repeat",w.mode=30;break}for(;ot--;)w.lens[w.have++]=f}}if(w.mode===30)break;if(w.lens[256]===0){T.msg="invalid code -- missing end-of-block",w.mode=30;break}if(w.lenbits=9,O={bits:w.lenbits},N=c(d,w.lens,0,w.nlen,w.lencode,0,w.work,O),w.lenbits=O.bits,N){T.msg="invalid literal/lengths set",w.mode=30;break}if(w.distbits=6,w.distcode=w.distdyn,O={bits:w.distbits},N=c(p,w.lens,w.nlen,w.ndist,w.distcode,0,w.work,O),w.distbits=O.bits,N){T.msg="invalid distances set",w.mode=30;break}if(w.mode=20,L===6)break t;case 20:w.mode=21;case 21:if(6<=U&&258<=Y){T.next_out=it,T.avail_out=Y,T.next_in=V,T.avail_in=U,w.hold=W,w.bits=z,a(T,lt),it=T.next_out,Q=T.output,Y=T.avail_out,V=T.next_in,F=T.input,U=T.avail_in,W=w.hold,z=w.bits,w.mode===12&&(w.back=-1);break}for(w.back=0;G=(I=w.lencode[W&(1<<w.lenbits)-1])>>>16&255,rt=65535&I,!((mt=I>>>24)<=z);){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}if(G&&(240&G)==0){for(ut=mt,E=G,R=rt;G=(I=w.lencode[R+((W&(1<<ut+E)-1)>>ut)])>>>16&255,rt=65535&I,!(ut+(mt=I>>>24)<=z);){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}W>>>=ut,z-=ut,w.back+=ut}if(W>>>=mt,z-=mt,w.back+=mt,w.length=rt,G===0){w.mode=26;break}if(32&G){w.back=-1,w.mode=12;break}if(64&G){T.msg="invalid literal/length code",w.mode=30;break}w.extra=15&G,w.mode=22;case 22:if(w.extra){for(C=w.extra;z<C;){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}w.length+=W&(1<<w.extra)-1,W>>>=w.extra,z-=w.extra,w.back+=w.extra}w.was=w.length,w.mode=23;case 23:for(;G=(I=w.distcode[W&(1<<w.distbits)-1])>>>16&255,rt=65535&I,!((mt=I>>>24)<=z);){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}if((240&G)==0){for(ut=mt,E=G,R=rt;G=(I=w.distcode[R+((W&(1<<ut+E)-1)>>ut)])>>>16&255,rt=65535&I,!(ut+(mt=I>>>24)<=z);){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}W>>>=ut,z-=ut,w.back+=ut}if(W>>>=mt,z-=mt,w.back+=mt,64&G){T.msg="invalid distance code",w.mode=30;break}w.offset=rt,w.extra=15&G,w.mode=24;case 24:if(w.extra){for(C=w.extra;z<C;){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}w.offset+=W&(1<<w.extra)-1,W>>>=w.extra,z-=w.extra,w.back+=w.extra}if(w.offset>w.dmax){T.msg="invalid distance too far back",w.mode=30;break}w.mode=25;case 25:if(Y===0)break t;if(ot=lt-Y,w.offset>ot){if((ot=w.offset-ot)>w.whave&&w.sane){T.msg="invalid distance too far back",w.mode=30;break}tt=ot>w.wnext?(ot-=w.wnext,w.wsize-ot):w.wnext-ot,ot>w.length&&(ot=w.length),gt=w.window}else gt=Q,tt=it-w.offset,ot=w.length;for(Y<ot&&(ot=Y),Y-=ot,w.length-=ot;Q[it++]=gt[tt++],--ot;);w.length===0&&(w.mode=21);break;case 26:if(Y===0)break t;Q[it++]=w.length,Y--,w.mode=21;break;case 27:if(w.wrap){for(;z<32;){if(U===0)break t;U--,W|=F[V++]<<z,z+=8}if(lt-=Y,T.total_out+=lt,w.total+=lt,lt&&(T.adler=w.check=w.flags?o(w.check,Q,lt,it-lt):l(w.check,Q,lt,it-lt)),lt=Y,(w.flags?W:v(W))!==w.check){T.msg="incorrect data check",w.mode=30;break}z=W=0}w.mode=28;case 28:if(w.wrap&&w.flags){for(;z<32;){if(U===0)break t;U--,W+=F[V++]<<z,z+=8}if(W!==(4294967295&w.total)){T.msg="incorrect length check",w.mode=30;break}z=W=0}w.mode=29;case 29:N=1;break t;case 30:N=-3;break t;case 31:return-4;case 32:default:return u}return T.next_out=it,T.avail_out=Y,T.next_in=V,T.avail_in=U,w.hold=W,w.bits=z,(w.wsize||lt!==T.avail_out&&w.mode<30&&(w.mode<27||L!==4))&&J(T,T.output,T.next_out,lt-T.avail_out)?(w.mode=31,-4):(ct-=T.avail_in,lt-=T.avail_out,T.total_in+=ct,T.total_out+=lt,w.total+=lt,w.wrap&&lt&&(T.adler=w.check=w.flags?o(w.check,Q,lt,T.next_out-lt):l(w.check,Q,lt,T.next_out-lt)),T.data_type=w.bits+(w.last?64:0)+(w.mode===12?128:0)+(w.mode===20||w.mode===15?256:0),(ct==0&&lt===0||L===4)&&N===g&&(N=-5),N)},n.inflateEnd=function(T){if(!T||!T.state)return u;var L=T.state;return L.window&&(L.window=null),T.state=null,g},n.inflateGetHeader=function(T,L){var w;return T&&T.state?(2&(w=T.state).wrap)==0?u:((w.head=L).done=!1,g):u},n.inflateSetDictionary=function(T,L){var w,F=L.length;return T&&T.state?(w=T.state).wrap!==0&&w.mode!==11?u:w.mode===11&&l(1,L,F,0)!==w.check?-3:J(T,L,F,F)?(w.mode=31,-4):(w.havedict=1,g):u},n.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(e,s,n){var r=e("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],o=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];s.exports=function(d,p,g,u,k,h,b,v){var y,$,A,x,_,S,D,M,P,J=v.bits,T=0,L=0,w=0,F=0,Q=0,V=0,it=0,U=0,Y=0,W=0,z=null,ct=0,lt=new r.Buf16(16),ot=new r.Buf16(16),tt=null,gt=0;for(T=0;T<=15;T++)lt[T]=0;for(L=0;L<u;L++)lt[p[g+L]]++;for(Q=J,F=15;1<=F&&lt[F]===0;F--);if(F<Q&&(Q=F),F===0)return k[h++]=20971520,k[h++]=20971520,v.bits=1,0;for(w=1;w<F&&lt[w]===0;w++);for(Q<w&&(Q=w),T=U=1;T<=15;T++)if(U<<=1,(U-=lt[T])<0)return-1;if(0<U&&(d===0||F!==1))return-1;for(ot[1]=0,T=1;T<15;T++)ot[T+1]=ot[T]+lt[T];for(L=0;L<u;L++)p[g+L]!==0&&(b[ot[p[g+L]]++]=L);if(S=d===0?(z=tt=b,19):d===1?(z=l,ct-=257,tt=o,gt-=257,256):(z=a,tt=c,-1),T=w,_=h,it=L=W=0,A=-1,x=(Y=1<<(V=Q))-1,d===1&&852<Y||d===2&&592<Y)return 1;for(;;){for(D=T-it,P=b[L]<S?(M=0,b[L]):b[L]>S?(M=tt[gt+b[L]],z[ct+b[L]]):(M=96,0),y=1<<T-it,w=$=1<<V;k[_+(W>>it)+($-=y)]=D<<24|M<<16|P|0,$!==0;);for(y=1<<T-1;W&y;)y>>=1;if(y!==0?(W&=y-1,W+=y):W=0,L++,--lt[T]==0){if(T===F)break;T=p[g+b[L]]}if(Q<T&&(W&x)!==A){for(it===0&&(it=Q),_+=w,U=1<<(V=T-it);V+it<F&&!((U-=lt[V+it])<=0);)V++,U<<=1;if(Y+=1<<V,d===1&&852<Y||d===2&&592<Y)return 1;k[A=W&x]=Q<<24|V<<16|_-h|0}}return W!==0&&(k[_+W]=T-it<<24|64<<16|0),v.bits=Q,0}},{"../utils/common":41}],51:[function(e,s,n){s.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(e,s,n){var r=e("../utils/common"),l=0,o=1;function a(I){for(var B=I.length;0<=--B;)I[B]=0}var c=0,d=29,p=256,g=p+1+d,u=30,k=19,h=2*g+1,b=15,v=16,y=7,$=256,A=16,x=17,_=18,S=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],D=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],M=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],P=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],J=new Array(2*(g+2));a(J);var T=new Array(2*u);a(T);var L=new Array(512);a(L);var w=new Array(256);a(w);var F=new Array(d);a(F);var Q,V,it,U=new Array(u);function Y(I,B,K,j,H){this.static_tree=I,this.extra_bits=B,this.extra_base=K,this.elems=j,this.max_length=H,this.has_stree=I&&I.length}function W(I,B){this.dyn_tree=I,this.max_code=0,this.stat_desc=B}function z(I){return I<256?L[I]:L[256+(I>>>7)]}function ct(I,B){I.pending_buf[I.pending++]=255&B,I.pending_buf[I.pending++]=B>>>8&255}function lt(I,B,K){I.bi_valid>v-K?(I.bi_buf|=B<<I.bi_valid&65535,ct(I,I.bi_buf),I.bi_buf=B>>v-I.bi_valid,I.bi_valid+=K-v):(I.bi_buf|=B<<I.bi_valid&65535,I.bi_valid+=K)}function ot(I,B,K){lt(I,K[2*B],K[2*B+1])}function tt(I,B){for(var K=0;K|=1&I,I>>>=1,K<<=1,0<--B;);return K>>>1}function gt(I,B,K){var j,H,Z=new Array(b+1),nt=0;for(j=1;j<=b;j++)Z[j]=nt=nt+K[j-1]<<1;for(H=0;H<=B;H++){var X=I[2*H+1];X!==0&&(I[2*H]=tt(Z[X]++,X))}}function mt(I){var B;for(B=0;B<g;B++)I.dyn_ltree[2*B]=0;for(B=0;B<u;B++)I.dyn_dtree[2*B]=0;for(B=0;B<k;B++)I.bl_tree[2*B]=0;I.dyn_ltree[2*$]=1,I.opt_len=I.static_len=0,I.last_lit=I.matches=0}function G(I){8<I.bi_valid?ct(I,I.bi_buf):0<I.bi_valid&&(I.pending_buf[I.pending++]=I.bi_buf),I.bi_buf=0,I.bi_valid=0}function rt(I,B,K,j){var H=2*B,Z=2*K;return I[H]<I[Z]||I[H]===I[Z]&&j[B]<=j[K]}function ut(I,B,K){for(var j=I.heap[K],H=K<<1;H<=I.heap_len&&(H<I.heap_len&&rt(B,I.heap[H+1],I.heap[H],I.depth)&&H++,!rt(B,j,I.heap[H],I.depth));)I.heap[K]=I.heap[H],K=H,H<<=1;I.heap[K]=j}function E(I,B,K){var j,H,Z,nt,X=0;if(I.last_lit!==0)for(;j=I.pending_buf[I.d_buf+2*X]<<8|I.pending_buf[I.d_buf+2*X+1],H=I.pending_buf[I.l_buf+X],X++,j===0?ot(I,H,B):(ot(I,(Z=w[H])+p+1,B),(nt=S[Z])!==0&&lt(I,H-=F[Z],nt),ot(I,Z=z(--j),K),(nt=D[Z])!==0&&lt(I,j-=U[Z],nt)),X<I.last_lit;);ot(I,$,B)}function R(I,B){var K,j,H,Z=B.dyn_tree,nt=B.stat_desc.static_tree,X=B.stat_desc.has_stree,dt=B.stat_desc.elems,xt=-1;for(I.heap_len=0,I.heap_max=h,K=0;K<dt;K++)Z[2*K]!==0?(I.heap[++I.heap_len]=xt=K,I.depth[K]=0):Z[2*K+1]=0;for(;I.heap_len<2;)Z[2*(H=I.heap[++I.heap_len]=xt<2?++xt:0)]=1,I.depth[H]=0,I.opt_len--,X&&(I.static_len-=nt[2*H+1]);for(B.max_code=xt,K=I.heap_len>>1;1<=K;K--)ut(I,Z,K);for(H=dt;K=I.heap[1],I.heap[1]=I.heap[I.heap_len--],ut(I,Z,1),j=I.heap[1],I.heap[--I.heap_max]=K,I.heap[--I.heap_max]=j,Z[2*H]=Z[2*K]+Z[2*j],I.depth[H]=(I.depth[K]>=I.depth[j]?I.depth[K]:I.depth[j])+1,Z[2*K+1]=Z[2*j+1]=H,I.heap[1]=H++,ut(I,Z,1),2<=I.heap_len;);I.heap[--I.heap_max]=I.heap[1],(function(bt,Et){var Wt,qt,Xt,Mt,Ve,Jt,Gt=Et.dyn_tree,mi=Et.max_code,Di=Et.stat_desc.static_tree,vs=Et.stat_desc.has_stree,bs=Et.stat_desc.extra_bits,En=Et.stat_desc.extra_base,gi=Et.stat_desc.max_length,Li=0;for(Mt=0;Mt<=b;Mt++)bt.bl_count[Mt]=0;for(Gt[2*bt.heap[bt.heap_max]+1]=0,Wt=bt.heap_max+1;Wt<h;Wt++)gi<(Mt=Gt[2*Gt[2*(qt=bt.heap[Wt])+1]+1]+1)&&(Mt=gi,Li++),Gt[2*qt+1]=Mt,mi<qt||(bt.bl_count[Mt]++,Ve=0,En<=qt&&(Ve=bs[qt-En]),Jt=Gt[2*qt],bt.opt_len+=Jt*(Mt+Ve),vs&&(bt.static_len+=Jt*(Di[2*qt+1]+Ve)));if(Li!==0){do{for(Mt=gi-1;bt.bl_count[Mt]===0;)Mt--;bt.bl_count[Mt]--,bt.bl_count[Mt+1]+=2,bt.bl_count[gi]--,Li-=2}while(0<Li);for(Mt=gi;Mt!==0;Mt--)for(qt=bt.bl_count[Mt];qt!==0;)mi<(Xt=bt.heap[--Wt])||(Gt[2*Xt+1]!==Mt&&(bt.opt_len+=(Mt-Gt[2*Xt+1])*Gt[2*Xt],Gt[2*Xt+1]=Mt),qt--)}})(I,B),gt(Z,xt,I.bl_count)}function f(I,B,K){var j,H,Z=-1,nt=B[1],X=0,dt=7,xt=4;for(nt===0&&(dt=138,xt=3),B[2*(K+1)+1]=65535,j=0;j<=K;j++)H=nt,nt=B[2*(j+1)+1],++X<dt&&H===nt||(X<xt?I.bl_tree[2*H]+=X:H!==0?(H!==Z&&I.bl_tree[2*H]++,I.bl_tree[2*A]++):X<=10?I.bl_tree[2*x]++:I.bl_tree[2*_]++,Z=H,xt=(X=0)===nt?(dt=138,3):H===nt?(dt=6,3):(dt=7,4))}function N(I,B,K){var j,H,Z=-1,nt=B[1],X=0,dt=7,xt=4;for(nt===0&&(dt=138,xt=3),j=0;j<=K;j++)if(H=nt,nt=B[2*(j+1)+1],!(++X<dt&&H===nt)){if(X<xt)for(;ot(I,H,I.bl_tree),--X!=0;);else H!==0?(H!==Z&&(ot(I,H,I.bl_tree),X--),ot(I,A,I.bl_tree),lt(I,X-3,2)):X<=10?(ot(I,x,I.bl_tree),lt(I,X-3,3)):(ot(I,_,I.bl_tree),lt(I,X-11,7));Z=H,xt=(X=0)===nt?(dt=138,3):H===nt?(dt=6,3):(dt=7,4)}}a(U);var O=!1;function C(I,B,K,j){lt(I,(c<<1)+(j?1:0),3),(function(H,Z,nt,X){G(H),ct(H,nt),ct(H,~nt),r.arraySet(H.pending_buf,H.window,Z,nt,H.pending),H.pending+=nt})(I,B,K)}n._tr_init=function(I){O||((function(){var B,K,j,H,Z,nt=new Array(b+1);for(H=j=0;H<d-1;H++)for(F[H]=j,B=0;B<1<<S[H];B++)w[j++]=H;for(w[j-1]=H,H=Z=0;H<16;H++)for(U[H]=Z,B=0;B<1<<D[H];B++)L[Z++]=H;for(Z>>=7;H<u;H++)for(U[H]=Z<<7,B=0;B<1<<D[H]-7;B++)L[256+Z++]=H;for(K=0;K<=b;K++)nt[K]=0;for(B=0;B<=143;)J[2*B+1]=8,B++,nt[8]++;for(;B<=255;)J[2*B+1]=9,B++,nt[9]++;for(;B<=279;)J[2*B+1]=7,B++,nt[7]++;for(;B<=287;)J[2*B+1]=8,B++,nt[8]++;for(gt(J,g+1,nt),B=0;B<u;B++)T[2*B+1]=5,T[2*B]=tt(B,5);Q=new Y(J,S,p+1,g,b),V=new Y(T,D,0,u,b),it=new Y(new Array(0),M,0,k,y)})(),O=!0),I.l_desc=new W(I.dyn_ltree,Q),I.d_desc=new W(I.dyn_dtree,V),I.bl_desc=new W(I.bl_tree,it),I.bi_buf=0,I.bi_valid=0,mt(I)},n._tr_stored_block=C,n._tr_flush_block=function(I,B,K,j){var H,Z,nt=0;0<I.level?(I.strm.data_type===2&&(I.strm.data_type=(function(X){var dt,xt=4093624447;for(dt=0;dt<=31;dt++,xt>>>=1)if(1&xt&&X.dyn_ltree[2*dt]!==0)return l;if(X.dyn_ltree[18]!==0||X.dyn_ltree[20]!==0||X.dyn_ltree[26]!==0)return o;for(dt=32;dt<p;dt++)if(X.dyn_ltree[2*dt]!==0)return o;return l})(I)),R(I,I.l_desc),R(I,I.d_desc),nt=(function(X){var dt;for(f(X,X.dyn_ltree,X.l_desc.max_code),f(X,X.dyn_dtree,X.d_desc.max_code),R(X,X.bl_desc),dt=k-1;3<=dt&&X.bl_tree[2*P[dt]+1]===0;dt--);return X.opt_len+=3*(dt+1)+5+5+4,dt})(I),H=I.opt_len+3+7>>>3,(Z=I.static_len+3+7>>>3)<=H&&(H=Z)):H=Z=K+5,K+4<=H&&B!==-1?C(I,B,K,j):I.strategy===4||Z===H?(lt(I,2+(j?1:0),3),E(I,J,T)):(lt(I,4+(j?1:0),3),(function(X,dt,xt,bt){var Et;for(lt(X,dt-257,5),lt(X,xt-1,5),lt(X,bt-4,4),Et=0;Et<bt;Et++)lt(X,X.bl_tree[2*P[Et]+1],3);N(X,X.dyn_ltree,dt-1),N(X,X.dyn_dtree,xt-1)})(I,I.l_desc.max_code+1,I.d_desc.max_code+1,nt+1),E(I,I.dyn_ltree,I.dyn_dtree)),mt(I),j&&G(I)},n._tr_tally=function(I,B,K){return I.pending_buf[I.d_buf+2*I.last_lit]=B>>>8&255,I.pending_buf[I.d_buf+2*I.last_lit+1]=255&B,I.pending_buf[I.l_buf+I.last_lit]=255&K,I.last_lit++,B===0?I.dyn_ltree[2*K]++:(I.matches++,B--,I.dyn_ltree[2*(w[K]+p+1)]++,I.dyn_dtree[2*z(B)]++),I.last_lit===I.lit_bufsize-1},n._tr_align=function(I){lt(I,2,3),ot(I,$,J),(function(B){B.bi_valid===16?(ct(B,B.bi_buf),B.bi_buf=0,B.bi_valid=0):8<=B.bi_valid&&(B.pending_buf[B.pending++]=255&B.bi_buf,B.bi_buf>>=8,B.bi_valid-=8)})(I)}},{"../utils/common":41}],53:[function(e,s,n){s.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(e,s,n){(function(r){(function(l,o){if(!l.setImmediate){var a,c,d,p,g=1,u={},k=!1,h=l.document,b=Object.getPrototypeOf&&Object.getPrototypeOf(l);b=b&&b.setTimeout?b:l,a={}.toString.call(l.process)==="[object process]"?function(A){process.nextTick(function(){y(A)})}:(function(){if(l.postMessage&&!l.importScripts){var A=!0,x=l.onmessage;return l.onmessage=function(){A=!1},l.postMessage("","*"),l.onmessage=x,A}})()?(p="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",$,!1):l.attachEvent("onmessage",$),function(A){l.postMessage(p+A,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(A){y(A.data)},function(A){d.port2.postMessage(A)}):h&&"onreadystatechange"in h.createElement("script")?(c=h.documentElement,function(A){var x=h.createElement("script");x.onreadystatechange=function(){y(A),x.onreadystatechange=null,c.removeChild(x),x=null},c.appendChild(x)}):function(A){setTimeout(y,0,A)},b.setImmediate=function(A){typeof A!="function"&&(A=new Function(""+A));for(var x=new Array(arguments.length-1),_=0;_<x.length;_++)x[_]=arguments[_+1];var S={callback:A,args:x};return u[g]=S,a(g),g++},b.clearImmediate=v}function v(A){delete u[A]}function y(A){if(k)setTimeout(y,0,A);else{var x=u[A];if(x){k=!0;try{(function(_){var S=_.callback,D=_.args;switch(D.length){case 0:S();break;case 1:S(D[0]);break;case 2:S(D[0],D[1]);break;case 3:S(D[0],D[1],D[2]);break;default:S.apply(o,D)}})(x)}finally{v(A),k=!1}}}}function $(A){A.source===l&&typeof A.data=="string"&&A.data.indexOf(p)===0&&y(+A.data.slice(p.length))}})(typeof self>"u"?r===void 0?this:r:self)}).call(this,typeof Nn<"u"?Nn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Bs)),Bs.exports}var dv=cv();const uv=av(dv),fv=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,pv=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function hv(t){const i=await uv.loadAsync(t),e={},s=[];let n="",r="";const l=[];i.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let o=l.find(a=>a.path.toLowerCase()==="slides.md");o||(o=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),o||(o=l.find(a=>a.path.toLowerCase().endsWith(".md"))),o&&(n=await o.file.async("string"),r=o.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||pv.test(c)||c.includes("snippets/")){const d=await a.file.async("string");e[c]=d;const p=c.split("/");p.length>1&&(e[p.slice(1).join("/")]=d)}else if(fv.test(c)){const d=await a.file.async("uint8array"),p=c.split("/").pop()||c,g=typeof Blob<"u"?new Blob([d]):void 0;s.push({zipPath:c,fileName:p,data:d,blob:g})}}return{entryMarkdown:n,entryMarkdownPath:r,virtualFiles:e,assets:s}}function mv(t,i){if(Object.keys(i).length===0)return t;function e(n){const r=n.trim().replace(/^['"]|['"]$/g,""),l=r.split("/").pop()||r;if(i[r])return i[r];const o=r.replace(/^\.?\//,"");return i[o]?i[o]:i[l]?i[l]:null}function s(n){let r=n;return r=r.replace(/!\[(.*?)\]\((.*?)\)/g,(l,o,a)=>{const c=e(a);return c?`![${o}](${c})`:l}),r=r.replace(/\bsrc=["'](.*?)["']/gi,(l,o)=>{const a=e(o);return a?`src="${a}"`:l}),r}for(const n of t.slides)if(n.rawMarkdown=s(n.rawMarkdown),n.pageAttrs["custom-slidev-background"]){const r=n.pageAttrs["custom-slidev-background"],l=e(r);l&&(n.pageAttrs["custom-slidev-background"]=l)}if(t.flattenedMarkdown=s(t.flattenedMarkdown),t.docRootAttrs["custom-slidev-background"]){const n=t.docRootAttrs["custom-slidev-background"],r=e(n);r&&(t.docRootAttrs["custom-slidev-background"]=r)}return t}function ia(t){try{if(typeof process<"u"&&typeof require<"u"){const i=require("fs");if(i.existsSync(t))return i.readFileSync(t,"utf-8")}}catch{}return null}function gv(t,i){const e=t.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!e)return null;const s=e[1].trim(),n=s.indexOf("#"),r=n!==-1?s.slice(0,n):s,l=n!==-1?s.slice(n+1):"",o=r.replace(/^@\//,"").replace(/^\.\//,""),a=(i==null?void 0:i.virtualFiles)||{};let c=a[r]||a[o]||a[`./${o}`]||a[`@/${o}`];if(!c&&Object.keys(a).length>0){const u=o.split("/").pop();for(const[k,h]of Object.entries(a))if(k.endsWith(`/${o}`)||u&&k.endsWith(`/${u}`)){c=h;break}}if(!c){const u=[];if(i!=null&&i.baseDir)try{const k=require("path");u.push(k.resolve(i.baseDir,o)),u.push(k.resolve(i.baseDir,r))}catch{}try{const k=require("path");u.push(k.resolve(process.cwd(),o))}catch{}for(const k of u){const h=ia(k);if(h!==null){c=h;break}}}if(!c){const u=ql||{};if(c=u[r]||u[o]||u[`snippets/${o}`],!c){const k=o.split("/").pop();for(const[h,b]of Object.entries(u))if(h.endsWith(`/${o}`)||k&&h.endsWith(`/${k}`)){c=b;break}}}if(!c)return null;let d=c;if(l){const u=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),k=c.match(u);if(k){const h=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(h?h[1]:"")+k[1].trimEnd()}}const p=o.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${p?p[1]:""}
${d}
\`\`\``}function vv(t){let i=!1,e=!1;for(let s=0;s<t.length;s++){const n=t[s];if(n==="'"&&!e)i=!i;else if(n==='"'&&!i)e=!e;else if(n==="#"&&!i&&!e)return t.slice(0,s).trim()}return t.trim()}function Vn(t){const i={},e=t.split(/\r?\n/);let s=0;for(;s<e.length;){const n=e[s],r=n.trim();if(!r||r.startsWith("#")){s++;continue}const l=n.indexOf(":");if(l>0){const o=n.slice(0,l).trim();let a=n.slice(l+1).trim();if(a==="|"||a===">"){s++;const c=[];let d=-1;for(;s<e.length;){const p=e[s];if(!p.trim()){c.push(""),s++;continue}const u=p.match(/^(\s+)/),k=u?u[1].length:0;if(d===-1&&(d=k),k<d)break;c.push(p.slice(d)),s++}for(;c.length>0&&c[c.length-1]==="";)c.pop();i[o]=a===">"?c.join(" "):c.join(`
`);continue}if(a=vv(a),!a){let c=s+1;const d=[];let p=-1;for(;c<e.length;){const g=e[c],u=g.trim();if(!u||u.startsWith("#")){p!==-1&&d.push(""),c++;continue}const k=g.match(/^(\s+)/),h=k?k[1].length:0;if(p===-1)if(h>0)p=h;else break;if(h<p)break;d.push(g.slice(p)),c++}if(d.length>0){i[o]=Vn(d.join(`
`)),s=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),i[o]=a}s++}return i}const bv=/^\s*```ya?ml([\s\S]*?)```/;function _r(t){let i={},e=t.trim();const s=e.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(s&&!s[1].includes("```")){const r=Vn(s[1]);if(Object.keys(r).length>0||!s[1].trim())return i=r,e=e.slice(s[0].length).trim(),{frontmatter:i,content:e}}if(e.startsWith("---")){const r=e.match(/^---[^\n\r]*(?:\r?\n|$)/);r&&(e=e.slice(r[0].length).trim())}const n=e.match(bv);if(n)i=Vn(n[1]),e=e.slice(n[0].length).trim();else{const r=e.split(/\r?\n/),l=[];let o=0;for(let a=0;a<r.length;a++){const c=r[a].trim();if(!c){if(l.length>0){o=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{o=a;break}}l.length>0&&(i=Vn(l.join(`
`)),e=r.slice(o).join(`
`).trim())}return{frontmatter:i,content:e}}function yv(t){const i=t.split(/\r?\n/),e=[];let s=0,n=!1;function r(l){if(s>=l)return;const o=i.slice(s,l).join(`
`).trim();o&&e.push(o),s=l+1}for(let l=0;l<i.length;l++){const a=i[l].trimEnd();if(n){a.includes("-->")&&(n=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(n=!0);continue}if(a.startsWith("---")){r(l);const c=i[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(s=l,l+=1;l<i.length&&i[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let p=l+1;for(;p<i.length&&!i[p].trimStart().startsWith(d);p++);p<i.length&&(l=p)}}return s<i.length&&r(i.length),e}function Kn(t,i={}){const{stripNotesFromMarkdown:e=!0,cleanVClicks:s=!0,cleanShikiLines:n=!0,cleanSlots:r=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:o=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=i;let d=t;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const p=yv(d),g={};let u="",k="",h=0;if(p.length>0){const P=p[0],J=_r(P),T=Object.keys(J.frontmatter).length>0,L=J.content.length>0;T&&!L&&p.length>1?(h=1,b(J.frontmatter)):T&&b(J.frontmatter)}function b(P){u=P.title||"",P.theme&&(g[rn]=String(P.theme)),P.aspectRatio&&(g[ln]=String(P.aspectRatio)),P.highlighter&&(g[Ar]=String(P.highlighter)),P.transition&&(g[an]=String(P.transition)),P.colorSchema&&(g[Tr]=String(P.colorSchema)),P.layout&&(g[ft]=String(P.layout)),P.background&&(g[Ft]=String(P.background)),P.image&&(g[Ae]=String(P.image)),P.class&&(g[Ni]=String(P.class));for(const[J,T]of Object.entries(P))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(J)||(g[`custom-slidev-${J}`]=typeof T=="object"?JSON.stringify(T):String(T))}const v=[];let y=0,$=0,A=0,x=0;const _=new Set,S={};let D=1;for(let P=h;P<p.length;P++){const J=p[P],{frontmatter:T,content:L}=_r(J),w=J.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),F=T.src||(w?w[1]:void 0);if(F){const G=String(F).trim().replace(/^['"]|['"]$/g,"");let rt=c[G]||c[G.replace(/^\.\//,"")]||c[`pages/${G.replace(/^.*pages\//,"")}`];if(!rt){const E=G.replace(/^\.\//,""),R=[];if(i.baseDir)try{const f=require("path");R.push(f.resolve(i.baseDir,E)),R.push(f.resolve(i.baseDir,G))}catch{}try{const f=require("path");R.push(f.resolve(process.cwd(),E)),R.push(f.resolve(process.cwd(),G))}catch{}for(const f of R){const N=ia(f);if(N!==null){rt=N;break}}}const ut={};T.layout&&(ut[ft]=String(T.layout)),T.transition&&(ut[Zt]=String(T.transition)),T.background&&(ut[Ft]=String(T.background)),T.image&&(ut[Ae]=String(T.image)),T.class&&(ut[Ni]=String(T.class));for(const[E,R]of Object.entries(T))["src","layout","transition","background","image","class"].includes(E)||(ut[`custom-slidev-${E}`]=typeof R=="object"?JSON.stringify(R):String(R));if(rt){const E=Kn(rt,{...i,virtualFiles:c});for(const R of E.slides){R.pageIndex=D++,R.pageAttrs={...ut,...R.pageAttrs},v.push(R);const f=R.pageAttrs[ft]||"default";S[f]=(S[f]||0)+1}continue}else{v.push({pageIndex:D++,pageAttrs:{...ut,"custom-slidev-src":G},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${G}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const E=ut[ft]||"default";S[E]=(S[E]||0)+1;continue}}const Q={};T.layout&&(Q[ft]=String(T.layout)),T.transition&&(Q[Zt]=String(T.transition)),T.background&&(Q[Ft]=String(T.background)),T.image&&(Q[Ae]=String(T.image)),T.class&&(Q[Ni]=String(T.class));for(const[G,rt]of Object.entries(T))["layout","transition","background","image","class"].includes(G)||(Q[`custom-slidev-${G}`]=typeof rt=="object"?JSON.stringify(rt):String(rt));let V=L;const it=[];let U=V.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,G=>{const rt=`__CODE_TOKEN_NOTE_${it.length}__`;return it.push(G),rt});U=U.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,G=>{const rt=`__CODE_TOKEN_NOTE_${it.length}__`;return it.push(G),rt});let Y="";const W=Array.from(U.matchAll(/<!--([\s\S]*?)-->/g));if(W.length>0){const G=W[W.length-1],rt=U.slice(G.index+G[0].length).trim();if(!rt||!rt.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const E=G[1].trim();E.startsWith("TODO:")||(Y=E,y++),e&&(U=U.slice(0,G.index).trimEnd()+U.slice(G.index+G[0].length))}}e&&(U=U.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let G=0;G<it.length;G++)U=U.replace(`__CODE_TOKEN_NOTE_${G}__`,it[G]);if(V=U,Y){for(let ut=0;ut<it.length;ut++)Y=Y.replace(`__CODE_TOKEN_NOTE_${ut}__`,it[ut]);const rt=`> [!NOTE] 💡 演讲备注
${Y.split(/\r?\n/).map(ut=>`> ${ut}`).join(`
`)}
{: custom-slidev-note="true"}`;V=V?`${V}

${rt}`:rt}let z=!1;if(/<style\b/i.test(V)){z=!0;const G=V.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(G){for(const rt of G){const ut=rt.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();k=k?`${k}

${ut}`:ut}l&&(V=V.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const ct=V.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);ct&&($+=ct.length);const lt=V.match(/```\w+\s+\{[^}]+\}/g);lt&&(A+=lt.length);const ot=V.match(/::\w+::|<template\s+#[^>]+>/g);if(ot&&(x+=ot.length),V=V.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,G=>gv(G,{...i,virtualFiles:c})||G),s&&(V=V.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),n&&(V=V.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),V=V.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),r&&(V=V.replace(/^::\w+::\s*$/gm,"")),o&&(V=Ga(V)),a){let G=V.trim(),rt="";const ut=G.lastIndexOf("> [!NOTE] 💡 演讲备注");if(ut!==-1&&(rt=G.slice(ut),G=G.slice(0,ut).trim()),(T.layout==="image-left"||T.layout==="image-right")&&T.image){const E=String(T.image).trim(),R=T.layout==="image-left"?"image-left":"image-right",f=`![配图](${E})
{: custom-slidev-layout="${R}" }`;T.layout==="image-left"?G=`{{{col

${f}

${G}

}}}`:G=`{{{col

${G}

${f}

}}}`}if(T.background){const R=`![背景图](${String(T.background).trim()})
{: custom-slidev-role="background" }`;G=G?`${R}

${G}`:R}V=rt?`${G}

${rt}`:G}const tt=wv(V);Q[Ft]&&tt.push(Q[Ft]),Q[Ae]&&tt.push(Q[Ae]);for(const G of tt)_.add(G);const gt=/<[A-Z][a-zA-Z0-9]+/.test(V),mt=Q[ft]||(D===1?g[ft]||"cover":"default");S[mt]=(S[mt]||0)+1,v.push({pageIndex:D++,pageAttrs:Q,notes:Y,rawMarkdown:V,hasVueComponent:gt,hasStyleTag:z,assetReferences:tt})}if(!u&&v.length>0){const P=v[0].rawMarkdown.match(/^#\s+(.+)$/m);P&&(u=P[1].trim())}k&&(g["custom-slidev-custom-css"]=k);let M=v.map(P=>`---

${P.rawMarkdown}`).join(`

`);return M.trimStart().startsWith("---")||(M=`---

${M.trimStart()}`),{docTitle:u||"Slidev 演示文稿",docRootAttrs:g,slides:v,totalSlides:v.length,stats:{totalNotes:y,totalVClicks:$,totalShikiHighlights:A,totalSlots:x,discoveredAssets:Array.from(_),layoutDistribution:S},flattenedMarkdown:M,customCss:k}}function wv(t){const i=[],e=/!\[.*?\]\((.*?)\)/g;let s;for(;(s=e.exec(t))!==null;){const r=s[1].split(/\s+/)[0].trim();r&&i.push(r)}const n=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(s=n.exec(t))!==null;){const r=s[1].trim();r&&i.push(r)}return i}const kv={class:"spm-import-dialog"},xv={class:"spm-tabs-header"},_v={class:"spm-dialog-body"},Sv={key:0,class:"spm-file-section"},Cv={key:0,class:"spm-dropzone-prompt"},$v={key:1,class:"spm-dropzone-active"},Iv={class:"spm-file-badge"},Av={class:"spm-file-size"},Tv={key:1,class:"spm-text-section"},Ev={key:2,class:"spm-error-banner"},Mv={key:3,class:"spm-preview-card"},Bv={class:"spm-config-grid"},Dv={class:"spm-form-item"},Lv={class:"spm-form-item"},Ov=["value"],Pv={class:"spm-stats-grid"},Rv={class:"spm-stat-box"},zv={class:"spm-stat-value"},Nv={class:"spm-stat-box"},Fv={class:"spm-stat-value"},jv={class:"spm-stat-box"},Hv={class:"spm-stat-value"},Uv={class:"spm-stat-box"},Wv={class:"spm-stat-value"},Vv={key:0,class:"spm-chips-row"},Kv={class:"spm-options-group"},qv={class:"spm-checkbox-label"},Gv={class:"spm-checkbox-label"},Zv={class:"spm-checkbox-label"},Yv={class:"spm-checkbox-label"},Jv={class:"spm-dialog-footer"},Xv=["disabled"],Qv=["disabled"],tb={key:0},eb={key:1},ib=be({__name:"SlidevImportDialog",emits:["close","success"],setup(t,{emit:i}){const e=i,s=Qe("plugin"),n=ht("file"),r=ht(!1),l=ht(!1),o=ht(""),a=ht(null),c=ht(null),d=ht(""),p=ht(0),g=ht(""),u=ht([]),k=ht(null),h=ht(""),b=ht([]),v=ht(""),y=ht(!0),$=ht(!0),A=ht(!0),x=ht(!0);async function _(){c.value?await F(c.value):g.value&&Q()}const S=St(()=>{const U=p.value;if(U===0)return"0 B";const Y=1024,W=["B","KB","MB","GB"],z=Math.floor(Math.log(U)/Math.log(Y));return`${(U/Y**z).toFixed(1)} ${W[z]}`}),D=St(()=>{var U;return((U=k.value)==null?void 0:U.docRootAttrs["custom-slidev-theme"])||"default"}),M=St(()=>{var U;return u.value.length>0?u.value.length:((U=k.value)==null?void 0:U.stats.discoveredAssets.length)||0}),P=St(()=>{var Y;const U=((Y=k.value)==null?void 0:Y.stats.layoutDistribution)||{};return Object.entries(U).map(([W,z])=>({name:W,count:z}))});In(async()=>{try{const U=await Sa();U!=null&&U.notebooks&&Array.isArray(U.notebooks)&&(b.value=U.notebooks.filter(Y=>!Y.closed),b.value.length>0&&(v.value=b.value[0].id))}catch(U){console.warn("获取笔记本列表失败:",U)}});function J(){var U;(U=a.value)==null||U.click()}function T(){c.value=null,d.value="",p.value=0,k.value=null,u.value=[],o.value=""}async function L(U){const Y=U.target;Y.files&&Y.files[0]&&await F(Y.files[0])}async function w(U){var Y;r.value=!1,(Y=U.dataTransfer)!=null&&Y.files&&U.dataTransfer.files[0]&&await F(U.dataTransfer.files[0])}async function F(U){o.value="",c.value=U,d.value=U.name,p.value=U.size;try{if(U.name.toLowerCase().endsWith(".zip")){const W=await U.arrayBuffer(),z=await hv(W);if(!z.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=z.assets;const ct=Kn(z.entryMarkdown,{stripNotesFromMarkdown:$.value,cleanHtmlToMarkdown:y.value,cleanSlots:!1,virtualFiles:z.virtualFiles});k.value=ct,h.value=ct.docTitle||U.name.replace(/\.zip$/i,"")}else{const W=await U.text();u.value=[];const z=U.path||"",ct=z?z.replace(/[\\/][^\\/]+$/,""):"",lt=Kn(W,{stripNotesFromMarkdown:$.value,cleanHtmlToMarkdown:y.value,cleanSlots:!1,baseDir:ct||void 0});k.value=lt,h.value=lt.docTitle||U.name.replace(/\.md$/i,"")}}catch(Y){console.error("解析文件失败:",Y),o.value=`解析文件失败: ${Y.message||String(Y)}`}}function Q(){if(o.value="",!g.value.trim()){k.value=null;return}try{const U=Kn(g.value,{stripNotesFromMarkdown:$.value,cleanHtmlToMarkdown:y.value,cleanSlots:!1});k.value=U,h.value=U.docTitle||"Slidev 演示文稿"}catch(U){o.value=`解析 Markdown 源码失败: ${U.message||String(U)}`}}async function V(){var U;if(k.value){if(!v.value&&b.value.length>0&&(v.value=b.value[0].id),!v.value){o.value="请先选择目标笔记本";return}l.value=!0,o.value="";try{const Y=k.value,W={};if(A.value&&u.value.length>0){const rt=[];for(const ut of u.value){const E=new File([ut.data],ut.fileName,{type:"application/octet-stream"});rt.push(E)}try{const ut=await $a("/data/assets",rt);if(ut!=null&&ut.succMap)for(const[E,R]of Object.entries(ut.succMap))W[E]=String(R)}catch(ut){console.warn("上传本地静态资产失败，保留原路径:",ut)}}Object.keys(W).length>0&&mv(Y,W);const z=(h.value.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_"),ct=`/${z}`,lt=await Ca(v.value,ct,Y.flattenedMarkdown);if(!lt)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const ot=((U=Y.slides[0])==null?void 0:U.pageAttrs)||{};await Lt(lt,{...ot,...Y.docRootAttrs});const tt=await qn(lt).catch(()=>[]),gt=rt=>{if(!rt)return!1;const ut=String(rt.type||"").toLowerCase(),E=String(rt.markdown||"").trim(),R=String(rt.content||"").trim();return ut==="tb"||ut==="thematic-break"||ut==="nodethematicbreak"||E==="---"||E==="***"||R==="---"||R==="***"},mt=tt.filter(gt);if(mt.length>=Y.slides.length)for(let rt=0;rt<Y.slides.length;rt++){const ut=Y.slides[rt],E=mt[rt];E&&E.id&&Object.keys(ut.pageAttrs).length>0&&await Lt(E.id,ut.pageAttrs)}else for(let rt=1;rt<Y.slides.length;rt++){const ut=Y.slides[rt],E=mt[rt-1];E&&E.id&&Object.keys(ut.pageAttrs).length>0&&await Lt(E.id,ut.pageAttrs)}let G=!1;for(const rt of tt){if(gt(rt)){G=!1;continue}const ut=(rt.markdown||rt.content||"").trim();if(ut==="::right::"||ut.startsWith("::right::")){G=!0;continue}G&&rt.id&&await Lt(rt.id,{[At]:"right"}).catch(()=>{})}vt.showMessage(`🎉 成功导入 Slidev 演示文档《${z}》！`),e("success",{docId:lt}),e("close"),x.value&&s&&(s.currentDocId=lt,await vt.openTab({app:s.app,doc:{id:lt}}),s.openBottomPreviewTab&&s.openBottomPreviewTab())}catch(Y){console.error("导入 Slidev 演示失败:",Y),o.value=`导入执行失败: ${Y.message||String(Y)}`}finally{l.value=!1}}}function it(){e("close")}return(U,Y)=>(et(),st("div",{class:"spm-modal-overlay",onClick:Te(it,["self"])},[m("div",kv,[m("div",{class:"spm-dialog-header"},[Y[11]||(Y[11]=m("div",{class:"spm-dialog-title"},[m("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[m("use",{"xlink:href":"#iconSlidev"})]),m("span",null,"导入 Slidev 演示文档")],-1)),m("button",{class:"spm-close-btn",title:"关闭",onClick:it},"✕")]),m("div",xv,[m("button",{class:$t(["spm-tab-btn",{active:n.value==="file"}]),onClick:Y[0]||(Y[0]=W=>n.value="file")}," 📦 文件 / 压缩包导入 (.zip / .md) ",2),m("button",{class:$t(["spm-tab-btn",{active:n.value==="text"}]),onClick:Y[1]||(Y[1]=W=>n.value="text")}," 📝 粘贴 Markdown 源码 ",2)]),m("div",_v,[n.value==="file"?(et(),st("div",Sv,[m("div",{class:$t(["spm-dropzone",{dragover:r.value,"has-file":!!d.value}]),onDragover:Y[2]||(Y[2]=Te(W=>r.value=!0,["prevent"])),onDragleave:Y[3]||(Y[3]=Te(W=>r.value=!1,["prevent"])),onDrop:Te(w,["prevent"]),onClick:J},[m("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:L},null,544),d.value?(et(),st("div",$v,[m("span",Iv,"📄 "+_t(d.value),1),m("span",Av,"("+_t(S.value)+")",1),m("button",{class:"spm-btn-text",onClick:Te(T,["stop"])},"更换文件")])):(et(),st("div",Cv,[...Y[12]||(Y[12]=[m("span",{class:"spm-dropzone-icon"},"📁",-1),m("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1),m("p",{class:"spm-dropzone-hint"},[Js(" 支持 Slidev 完整工程 "),m("strong",null,".zip"),Js("（自动解包 public/ 静态素材）或单文件 "),m("strong",null,".md")],-1)])]))],34)])):(et(),st("div",Tv,[Ie(m("textarea",{"onUpdate:modelValue":Y[4]||(Y[4]=W=>g.value=W),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:Q},null,544),[[ns,g.value]])])),o.value?(et(),st("div",Ev," ⚠️ "+_t(o.value),1)):Rt("",!0),k.value?(et(),st("div",Mv,[Y[24]||(Y[24]=m("div",{class:"spm-preview-card__header"},[m("span",null,"✨ 演示解析摘要"),m("span",{class:"spm-badge-success"},"预检就绪")],-1)),m("div",Bv,[m("div",Dv,[Y[13]||(Y[13]=m("label",{class:"spm-form-label"},"笔记文档标题",-1)),Ie(m("input",{"onUpdate:modelValue":Y[5]||(Y[5]=W=>h.value=W),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[ns,h.value]])]),m("div",Lv,[Y[14]||(Y[14]=m("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Ie(m("select",{"onUpdate:modelValue":Y[6]||(Y[6]=W=>v.value=W),class:"spm-select"},[(et(!0),st(Kt,null,ye(b.value,W=>(et(),st("option",{key:W.id,value:W.id},_t(W.name),9,Ov))),128))],512),[[yu,v.value]])])]),m("div",Pv,[m("div",Rv,[m("span",zv,_t(k.value.totalSlides),1),Y[15]||(Y[15]=m("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),m("div",Nv,[m("span",Fv,_t(D.value),1),Y[16]||(Y[16]=m("span",{class:"spm-stat-label"},"演示主题",-1))]),m("div",jv,[m("span",Hv,_t(k.value.stats.totalNotes),1),Y[17]||(Y[17]=m("span",{class:"spm-stat-label"},"演讲者提词",-1))]),m("div",Uv,[m("span",Wv,_t(M.value),1),Y[18]||(Y[18]=m("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),P.value.length>0?(et(),st("div",Vv,[Y[19]||(Y[19]=m("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(et(!0),st(Kt,null,ye(P.value,W=>(et(),st("span",{key:W.name,class:"spm-chip-badge"},_t(W.name)+": "+_t(W.count),1))),128))])):Rt("",!0),m("div",Kv,[m("label",qv,[Ie(m("input",{"onUpdate:modelValue":Y[7]||(Y[7]=W=>y.value=W),type:"checkbox",onChange:_},null,544),[[zn,y.value]]),Y[20]||(Y[20]=m("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),m("label",Gv,[Ie(m("input",{"onUpdate:modelValue":Y[8]||(Y[8]=W=>$.value=W),type:"checkbox",onChange:_},null,544),[[zn,$.value]]),Y[21]||(Y[21]=m("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),m("label",Zv,[Ie(m("input",{"onUpdate:modelValue":Y[9]||(Y[9]=W=>A.value=W),type:"checkbox"},null,512),[[zn,A.value]]),Y[22]||(Y[22]=m("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),m("label",Yv,[Ie(m("input",{"onUpdate:modelValue":Y[10]||(Y[10]=W=>x.value=W),type:"checkbox"},null,512),[[zn,x.value]]),Y[23]||(Y[23]=m("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Rt("",!0)]),m("div",Jv,[m("button",{class:"spm-btn-secondary",disabled:l.value,onClick:it}," 取消 ",8,Xv),m("button",{class:"spm-btn-primary",disabled:!k.value||l.value,onClick:V},[l.value?(et(),st("span",tb,"⏳ 正在导入生成中...")):(et(),st("span",eb,"🚀 确认导入思源笔记"))],8,Qv)])])]))}}),nb=Oe(ib,[["__scopeId","data-v-8771dc8a"]]);function na(t){return t?t==="NodeThematicBreak"||t==="tb"||t==="thematic-break":!1}function sb(t,i){var o;if(!t||t.length===0)return null;const e=i.activeBlockId||"",s=i.currentTopBlockId||e,n=i.currentPageDividerId||"",r=i.activeBlockType||"";if(na(r)&&e){let a=t.find(c=>c.startBlockId===e);if(a||(a=t.find(c=>{var d,p;return((p=(d=c.blocks)==null?void 0:d[0])==null?void 0:p.id)===e}),a)||(a=t.find(c=>{var d;return(d=c.allBlockIds)==null?void 0:d.includes(e)}),a))return a}if(n){let a=t.find(c=>c.startBlockId===n);if(a||(a=t.find(c=>{var d,p;return((p=(d=c.blocks)==null?void 0:d[0])==null?void 0:p.id)===n}),a))return a}if(e){let a=t.find(d=>d.startBlockId===e);if(a||(a=t.find(d=>{var p,g;return((p=d.blocks)==null?void 0:p.some(u=>u.id===e))||((g=d.allBlockIds)==null?void 0:g.includes(e))}),a)||s&&s!==e&&(a=t.find(d=>{var p,g;return((p=d.blocks)==null?void 0:p.some(u=>u.id===s))||((g=d.allBlockIds)==null?void 0:g.includes(s))}),a)||(a=t.find(d=>{var p;return(p=d.noteBlocks)==null?void 0:p.some(g=>g.id===e||g.id===s)}),a))return a;const c=(o=i.activeBlockAttrs)==null?void 0:o[At];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=t.find(d=>{var p,g;return((p=d.frontmatter)==null?void 0:p.layout)==="three-cols-header"||((g=d.blocks)==null?void 0:g.some(u=>u.slot==="col-1"||u.slot==="col-2"||u.slot==="col-3"))}),a))return a}return t[0]||null}const ob={class:"spm-slidev-inspector"},rb={class:"spm-inspector-topbar"},lb={class:"spm-inspector-title"},ab={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},cb={class:"spm-inspector-topbar-actions"},db={class:"spm-target-banner"},ub={class:"spm-target-info"},fb=["aria-label"],pb={key:0,class:"spm-save-status"},hb=["title"],mb={class:"spm-inspector-body"},gb=be({__name:"SlidevInspectorDockView",setup(t,{expose:i}){const e=Qe("plugin"),s=ht(!1);function n(q){s.value=!1,c.value=q.docId,e!=null&&e.compileCurrentDocument&&e.compileCurrentDocument(q.docId)}const r=ht(""),l=ht(""),o=ht({}),a=ht(""),c=ht(""),d=ht(""),p=ht(""),g=ht(""),u=ht(null),k=ht(""),h=ht("");let b=null;function v(q="已同步"){k.value=q,b&&window.clearTimeout(b),b=window.setTimeout(()=>{k.value=""},1200)}function y(){var at;const q=r.value||c.value;q&&(at=navigator==null?void 0:navigator.clipboard)!=null&&at.writeText&&navigator.clipboard.writeText(q).then(()=>{h.value="已复制！",setTimeout(()=>{h.value=""},1500)}).catch(()=>{})}const $=St(()=>na(l.value)),A=St(()=>l.value==="NodeCodeBlock"),x=ht(!1),_=St(()=>{if(x.value||j.value)return!0;const q=a.value||"";return!!fi(q)}),S=St(()=>{const q=l.value||"";if(q==="NodeVideo"||q==="video")return!0;const at=a.value||"";return!!(/<video\b/i.test(at)||/\.mp4\b/i.test(at))}),D=St(()=>!r.value||r.value===c.value||l.value==="doc"||l.value==="NodeDocument"),M=St(()=>{const q=r.value||c.value||"";return q.length>8?q.slice(-8):q||"无"}),P=St(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),J=St(()=>{if($.value)return"分页符 (---)";if(D.value)return"全局文档";if(S.value)return"视频块";switch(l.value){case"NodeHeading":return"标题块";case"NodeParagraph":return"段落块";case"NodeCodeBlock":return"代码块";case"NodeVideo":return"视频块";case"NodeList":case"NodeListItem":return"列表项";case"NodeBlockquote":return"引述块";case"NodeTable":return"表格块";case"NodeSuperBlock":case"s":case"sb":return"超级块";default:return"内容块"}}),T=St(()=>$.value?"tag-divider":D.value?"tag-doc":"tag-block"),L=St(()=>o.value[ft]||"default"),w=St(()=>o.value[Zt]||"slide-left"),F=ht(""),Q=ht(""),V=St(()=>o.value[cn]||"inherit"),it=St(()=>{var q;return sb((q=u.value)==null?void 0:q.slides,{activeBlockId:r.value,activeBlockType:l.value,currentTopBlockId:d.value,currentPageDividerId:p.value,activeBlockAttrs:o.value})}),U=St(()=>{var q;return((q=it.value)==null?void 0:q.notes)||""}),Y=St(()=>{var q,at,kt;return((kt=(at=(q=it.value)==null?void 0:q.noteBlocks)==null?void 0:at[0])==null?void 0:kt.id)||""}),W=St(()=>{var Tt,Ot,Pt,de,oe,xe;if($.value){const Vt=o.value[ft]||o.value["custom-slidev-layout"];if(Vt)return Vt}const q=o.value[At]||o.value["custom-slidev-slot"];if(q&&["col-1","col-2","col-3"].includes(q))return"three-cols-header";if(g.value)return g.value;const at=p.value||($.value?r.value:"");if(at){const Vt=Nt.getBlockAttrOverride(at);if(Vt!=null&&Vt[ft])return Vt[ft]}if(at&&((Tt=u.value)!=null&&Tt.slides)){const Vt=u.value.slides.find(li=>li.startBlockId===at);if((Ot=Vt==null?void 0:Vt.frontmatter)!=null&&Ot.layout)return Vt.frontmatter.layout}if((de=(Pt=it.value)==null?void 0:Pt.frontmatter)!=null&&de.layout)return it.value.frontmatter.layout;if((xe=(oe=it.value)==null?void 0:oe.blocks)!=null&&xe.some(Vt=>Vt.slot==="col-1"||Vt.slot==="col-2"||Vt.slot==="col-3"))return"three-cols-header";const kt=Nt.getBlockAttrOverride(c.value);return kt!=null&&kt[ft]?kt[ft]:"default"}),z=St(()=>{var q;return((q=it.value)==null?void 0:q.pageIndex)||1}),ct=St(()=>!!(o.value[Qt]||o.value["slidev-note"])),lt=St(()=>{var at;if(o.value[Se])return o.value[Se];const q=r.value;if(q&&((at=it.value)!=null&&at.blocks)){const kt=it.value.blocks.find(Tt=>Tt.id===q);if(kt!=null&&kt.clicks)return kt.clicks}return""}),ot=St(()=>{var at;if(o.value[je])return o.value[je];const q=r.value;if(q&&((at=it.value)!=null&&at.blocks)){const kt=it.value.blocks.find(Tt=>Tt.id===q);if(kt!=null&&kt.motion)return typeof kt.motion=="string"?kt.motion:JSON.stringify(kt.motion)}return""}),tt=St(()=>{var at;if(o.value[At])return o.value[At];const q=r.value;if(q&&((at=it.value)!=null&&at.blocks)){const kt=it.value.blocks.find(Tt=>Tt.id===q);if(kt!=null&&kt.slot)return kt.slot}return""}),gt=ht(""),mt=ht(""),G=St(()=>o.value[vi]==="true"),rt=St(()=>o.value[Bn]==="true"),ut=St(()=>o.value[Oi]==="true"),E=St(()=>o.value[Dn]!=="false");async function R(){(G.value?"false":"true")==="true"?(await Z({[vi]:"true",[Oi]:"true"}),o.value[vi]="true",o.value[Oi]="true"):(await X(vi,"false"),o.value[vi]="false")}async function f(){const q=rt.value?"false":"true";await X(Bn,q)}async function N(){const q=ut.value?"false":"true";await X(Oi,q)}async function O(){const q=E.value?"false":"true";await X(Dn,q)}const C=St(()=>{var q,at;return((at=(q=u.value)==null?void 0:q.config)==null?void 0:at.theme)||o.value[rn]||"default"}),I=St(()=>{var q,at;return((at=(q=u.value)==null?void 0:q.config)==null?void 0:at.aspectRatio)||o.value[ln]||"16/9"}),B=St(()=>{var q,at;return((at=(q=u.value)==null?void 0:q.config)==null?void 0:at.defaultTransition)||o.value[an]||"slide-left"}),K=St(()=>{var q,at;return((at=(q=u.value)==null?void 0:q.config)==null?void 0:at.spacing)||o.value[Ps]||"normal"}),j=St(()=>{var Ot,Pt;if((o.value[Ut]||o.value["slidev-role"])===Er||o.value[Ft]==="true")return"background";const at=o.value[ft]||o.value["slidev-layout"];if(at==="image-left"||at==="image-right")return at;const kt=a.value||"",Tt=fi(kt);if(Tt&&((Pt=(Ot=it.value)==null?void 0:Ot.frontmatter)!=null&&Pt.background)){const de=it.value.frontmatter.background;if(de===Tt||de.endsWith(Tt)||Tt.endsWith(de))return"background"}return""});async function H(q){var Pt;const at=r.value;if(!at)return;const kt=a.value||"",Tt=fi(kt)||"",Ot=p.value||c.value;if(q)if(q==="background"){const de={[Ut]:"background",[ft]:""};Ot&&Tt&&(F.value=Tt,await Lt(Ot,{[Ft]:Tt}).catch(()=>{}),Nt.setBlockAttrOverride(Ot,{[Ft]:Tt}),ee(Ot,{[Ft]:Tt}),it.value&&(it.value.frontmatter||(it.value.frontmatter={}),it.value.frontmatter.background=Tt)),await Z(de)}else(q==="image-left"||q==="image-right")&&await Z({[ft]:q,[Ut]:""});else{const de={[Ut]:"",[ft]:""};if(o.value[Ft]==="true"&&(de[Ft]=""),Ot&&Tt&&F.value===Tt&&(F.value="",await Lt(Ot,{[Ft]:""}).catch(()=>{}),Nt.setBlockAttrOverride(Ot,{[Ft]:""}),ee(Ot,{[Ft]:""}),(Pt=it.value)!=null&&Pt.frontmatter&&delete it.value.frontmatter.background),await Z(de),typeof document<"u"){const oe=document.querySelector(`.protyle-wysiwyg [data-node-id="${at}"]`),xe=oe==null?void 0:oe.closest('[data-type="NodeListItem"]'),Vt=xe==null?void 0:xe.getAttribute("data-node-id");if(Vt&&Vt!==at){const li={[ft]:"",[Ut]:""};ee(Vt,li),Nt.setBlockAttrOverride(Vt,li),await Lt(Vt,li).catch(()=>{})}}}}async function Z(q){const at=r.value||c.value;if(at){for(const[kt,Tt]of Object.entries(q))o.value[kt]=Tt;if(Nt.setBlockAttrOverride(at,q),ee(at,q),ft in q){const kt=q[ft];g.value=kt,it.value&&(it.value.frontmatter||(it.value.frontmatter={}),it.value.frontmatter.layout=kt)}v("保存中...");try{await Lt(at,q),v("已同步"),e&&await e.compileCurrentDocument()}catch{v("同步失败")}}}const nt=St(()=>!!(o.value[Se]||o.value[je]||o.value[At]||o.value[Ci]||o.value[Qt]||o.value["slidev-note"]||o.value[Ut]||o.value[ft]||o.value[vi]||o.value[Bn]||o.value[Oi]||o.value[Dn]));async function X(q,at){const kt=r.value||c.value;if(kt){o.value[q]=at,Nt.setBlockAttrOverride(kt,{[q]:at}),ee(kt,{[q]:at}),q===ft&&(g.value=at,it.value&&(it.value.frontmatter||(it.value.frontmatter={}),it.value.frontmatter.layout=at)),v("保存中...");try{await Lt(kt,{[q]:at}),v("已同步"),e&&await e.compileCurrentDocument()}catch{v("同步失败")}}}async function dt(q,at){var Tt;const kt=c.value||r.value;if(kt){o.value[q]=at,Nt.setBlockAttrOverride(kt,{[q]:at}),ee(kt,{[q]:at}),(Tt=u.value)!=null&&Tt.config&&(q===rn&&(u.value.config.theme=at),q===ln&&(u.value.config.aspectRatio=at),q===an&&(u.value.config.defaultTransition=at)),v("更新中...");try{await Lt(kt,{[q]:at}),v("已更新"),e&&await e.compileCurrentDocument(kt)}catch{v("更新失败")}}}function xt(q){X(ft,q)}function bt(q){X(Zt,q)}function Et(q){F.value=q,X(Ft,q)}function Wt(q){Q.value=q,X(Ae,q)}function qt(q){X(cn,q==="inherit"?"":q)}async function Xt(){const q=r.value;if(q)if(ct.value){v("取消中...");try{await Lt(q,{[Qt]:"","slidev-note":""}),Nt.setBlockAttrOverride(q,{[Qt]:"","slidev-note":""}),ee(q,{[Qt]:"","slidev-note":""}),delete o.value[Qt],delete o.value["slidev-note"],v("已取消备注"),vt.showMessage("已取消讲稿备注"),e&&await e.compileCurrentDocument()}catch(at){console.error("[SiYuanSlidev] 取消讲稿备注失败:",at),v("取消失败"),vt.showMessage("取消讲稿备注失败")}}else{v("转换中...");try{let at=a.value;try{const Pt=await Aa(q);Pt!=null&&Pt.kramdown&&(at=Pt.kramdown)}catch{}const Ot=`> [!NOTE] 💡 演讲备注
${(Or(at)||at.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(Pt=>`> ${Pt}`).join(`
`)}
{: custom-slidev-note="true"}`;await Ro("markdown",Ot,q),await Lt(q,{[Qt]:"true"}),Nt.setBlockAttrOverride(q,{[Qt]:"true"}),ee(q,{[Qt]:"true"}),o.value[Qt]="true",l.value="NodeCallout",v("已设为讲稿备注"),vt.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e&&await e.compileCurrentDocument()}catch(at){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",at),v("设置失败"),vt.showMessage("转为讲稿备注提示块失败")}}}async function Mt(q){var Vt,li,Mo,Bo,Do,Lo,Oo;const Tt=`> [!NOTE] 💡 演讲备注
${(q||"在此输入本页讲稿提词...").split(/\r?\n/).map(Ke=>`> ${Ke}`).join(`
`)}
{: custom-slidev-note="true"}`,Ot=((Vt=u.value)==null?void 0:Vt.slides)||[],Pt=it.value,de=Pt?Ot.findIndex(Ke=>Ke===Pt):-1;let oe=null;if(de!==-1&&de<Ot.length-1){const Ke=Ot[de+1];oe=await nn("markdown",Tt,Ke.startBlockId)}else{const Ke=((li=Pt==null?void 0:Pt.noteBlocks)==null?void 0:li.slice(-1)[0])||((Mo=Pt==null?void 0:Pt.blocks)==null?void 0:Mo.slice(-1)[0]),Po=(Ke==null?void 0:Ke.id)||(Pt==null?void 0:Pt.startBlockId);Po?oe=await nn("markdown",Tt,void 0,Po):oe=await $r("markdown",Tt,c.value)}const xe=((Lo=(Do=(Bo=oe==null?void 0:oe[0])==null?void 0:Bo.doOperations)==null?void 0:Do[0])==null?void 0:Lo.id)||((Oo=oe==null?void 0:oe[0])==null?void 0:Oo.id);return xe&&(await Lt(xe,{[Qt]:"true"}),Nt.setBlockAttrOverride(xe,{[Qt]:"true"}),Mi(xe,e==null?void 0:e.app)),e&&await e.compileCurrentDocument(),xe}async function Ve(){try{await Mt(),vt.showMessage("已在正文末尾插入讲稿备注提示块")}catch(q){vt.showMessage("插入讲稿备注块失败"),console.error(q)}}function Jt(){const q=Y.value;if(!q){vt.showMessage("未找到本页关联的讲稿备注块");return}Mi(q,e==null?void 0:e.app)?vt.showMessage("已在编辑区定位讲稿备注块"):vt.showMessage("定位讲稿备注块失败")}async function Gt(){if(!c.value)return;const q=it.value||{startBlockId:r.value||c.value,blocks:a.value&&a.value!=="---"?[{id:r.value,type:l.value,content:a.value,rawMarkdown:""}]:[],rawMarkdown:a.value&&a.value!=="---"?a.value:""};vt.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const at=await Mr(q,Ir);if(at.notes){const kt=Y.value;if(kt){const Tt=`> [!NOTE] 💡 演讲备注
${at.notes.split(/\r?\n/).map(Ot=>`> ${Ot}`).join(`
`)}
{: custom-slidev-note="true"}`;await Ro("markdown",Tt,kt),await Lt(kt,{[Qt]:"true"}),Nt.setBlockAttrOverride(kt,{[Qt]:"true"}),Mi(kt,e==null?void 0:e.app)}else await Mt(at.notes);at.isAiGenerated?vt.showMessage("思源 AI 演讲提词卡生成成功！"):vt.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e&&await e.compileCurrentDocument()}}function mi(){lt.value?X(Se,""):X(Se,"+1")}function Di(q){X(Se,q)}function vs(q){X(je,q)}function bs(q){(o.value[At]||"")===q?X(At,""):X(At,q)}function En(q){gt.value=q,X(Ci,q)}function gi(q){mt.value=q,X(dn,q)}async function Li(){const q=W.value==="three-cols-header";await X(At,q?"col-1":"left"),vt.showMessage(q?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function ra(){const q=r.value;if(!q)return;const at={[Se]:"",[je]:"",[At]:"",[Ci]:"",[dn]:"",[Qt]:"","slidev-note":"",[ft]:"",[Ut]:"",[Zt]:"",[Ft]:"",[Ae]:"",[vi]:"",[Bn]:"",[Oi]:"",[Dn]:""};if(ee(q,at),await Lt(q,at),Nt.clearBlockAttrOverride(q),typeof document<"u"){const kt=document.querySelector(`.protyle-wysiwyg [data-node-id="${q}"]`),Tt=kt==null?void 0:kt.closest('[data-type="NodeListItem"]'),Ot=Tt==null?void 0:Tt.getAttribute("data-node-id");Ot&&Ot!==q&&(ee(Ot,at),await Lt(Ot,at).catch(()=>{}),Nt.clearBlockAttrOverride(Ot))}o.value={},gt.value="",mt.value="",F.value="",Q.value="",vt.showMessage("已清除本块演示属性"),e&&await e.compileCurrentDocument()}function la(q){dt(rn,q)}function aa(q){dt(ln,q)}function ca(q){dt(an,q)}function da(q){dt(Ps,q)}async function ua(){if(r.value)try{await nn("markdown","---",r.value,void 0),vt.showMessage("已在上方插入分页符 (---)"),e&&e.compileCurrentDocument()}catch{vt.showMessage("插入分页符失败")}}async function To(){const q=r.value||c.value;if(q)try{await nn("markdown","---",void 0,q),vt.showMessage("已在下方插入分页符 (---)"),e&&e.compileCurrentDocument()}catch{vt.showMessage("插入分页符失败")}}async function fa(){if(r.value)try{await Ia(r.value),vt.showMessage("已删除该分页符"),r.value="",l.value="",e&&e.compileCurrentDocument()}catch{vt.showMessage("删除失败")}}function Eo(){e!=null&&e.openBottomPreviewTab&&e.openBottomPreviewTab()}function pa(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function ha(){e!=null&&e.executeCommand&&e.executeCommand("slidevAiSplit")}function ma(){if(!u.value){vt.showMessage("请先在主编辑区打开幻灯片文档");return}const q=Ql(u.value);ta("presentation.html",q)&&vt.showMessage("已开始下载单文件离线 HTML 演示包")}function ga(){if(!u.value){vt.showMessage("请先在主编辑区打开幻灯片文档");return}ea(u.value)&&vt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({setActiveBlock(q){r.value=q.id,l.value=q.type,o.value={...q.attrs},a.value=q.content||q.markdown||"",d.value=q.topBlockId||q.id,p.value=q.pageDividerId||"",g.value=q.pageDividerLayout||"",q.rootId?c.value=q.rootId:(q.type==="doc"||q.type==="NodeDocument")&&q.id&&(c.value=q.id),F.value=q.attrs[Ft]||"",Q.value=q.attrs[Ae]||"",gt.value=q.attrs[Ci]||"",mt.value=q.attrs[dn]||"",x.value=!!q.isImage},updateDocument(q){u.value=q,c.value=q.docId},openImportDialog(){s.value=!0},setCurrentDocId(q){c.value=q}}),(q,at)=>(et(),st("div",ob,[m("div",rb,[m("div",lb,[(et(),st("svg",ab,[...at[2]||(at[2]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),at[3]||(at[3]=m("span",null,"演示配置",-1))]),m("div",cb,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:at[0]||(at[0]=kt=>s.value=!0)},[pt(yt,{name:"import"}),at[4]||(at[4]=m("span",null,"导入",-1))]),m("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:Eo},[pt(yt,{name:"split-preview"}),at[5]||(at[5]=m("span",null,"分屏预览",-1))])])]),m("div",db,[m("div",ub,[m("span",{class:$t(["spm-target-tag",T.value])},_t(J.value),3),m("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":h.value||"点击复制 ID: "+(r.value||c.value),onClick:y},[pt(yt,{name:"copy"}),m("span",null,"#"+_t(M.value),1)],8,fb)]),k.value?(et(),st("span",pb,"● "+_t(k.value),1)):Rt("",!0)]),P.value?(et(),st("div",{key:0,class:"spm-context-quote",title:a.value},_t(P.value),9,hb)):Rt("",!0),m("div",mb,[$.value?(et(),Ee(am,{key:0,"page-layout":L.value,"page-transition":w.value,"page-background":F.value,"page-spacing":V.value,"page-image":Q.value,"page-notes":U.value,"page-index":z.value,"onUpdate:pageLayout":xt,"onUpdate:pageTransition":bt,"onUpdate:pageBackground":Et,"onUpdate:pageSpacing":qt,"onUpdate:pageImage":Wt,onAddNoteBlock:Ve,onLocateNoteBlock:Jt,onGenerateNotes:Gt,onInsertDividerAfter:To,onDeleteDivider:fa},null,8,["page-layout","page-transition","page-background","page-spacing","page-image","page-notes","page-index"])):r.value&&!D.value?(et(),Ee(Tg,{key:1,"elem-click":lt.value,"elem-motion":ot.value,"elem-slot":tt.value,"elem-shiki-lines":gt.value,"elem-max-height":mt.value,"is-code-block":A.value,"is-image":_.value,"is-video":S.value,"video-autoplay":G.value,"video-loop":rt.value,"video-muted":ut.value,"video-controls":E.value,"has-block-attrs":nt.value,"is-note":ct.value,"image-role":j.value,"current-slide-layout":W.value,onToggleNote:Xt,onToggleElemClick:mi,onToggleVideoAutoplay:R,onToggleVideoLoop:f,onToggleVideoMuted:N,onToggleVideoControls:O,"onUpdate:imageRole":H,"onUpdate:elemClick":Di,"onUpdate:elemMotion":vs,"onUpdate:elemSlot":bs,"onUpdate:elemShikiLines":En,"onUpdate:elemMaxHeight":gi,onInsertDividerBefore:ua,onInsertDividerAfter:To,onSetTwoColsContrast:Li,onClearBlockAttrs:ra},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout"])):(et(),Ee(lv,{key:2,"doc-theme":C.value,"doc-aspect-ratio":I.value,"doc-default-transition":B.value,"doc-spacing":K.value,"onUpdate:docTheme":la,"onUpdate:docAspectRatio":aa,"onUpdate:docDefaultTransition":ca,"onUpdate:docSpacing":da,onOpenBottomPreview:Eo,onOpenPresenter:pa,onAiAutoSplit:ha,onExportHtml:ma,onExportPdf:ga},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing"]))]),s.value?(et(),Ee(nb,{key:1,onClose:at[1]||(at[1]=kt=>s.value=!1),onSuccess:n})):Rt("",!0)]))}}),Tn=new $o;let di=null,Ue=null;function vb(t,i){di&&sa(),di=Wl(Th),di.provide("plugin",i),di.provide("sandboxBridge",Tn);const e=di.mount(t);return Ue=e,e}function sa(t){di&&(di.unmount(),di=null,Ue=null)}let ui=null,ve=null;function bb(t,i){ui&&oa(),ui=Wl(gb),ui.provide("plugin",i),ui.provide("sandboxBridge",Tn);const e=ui.mount(t);return ve=e,e}function oa(t){ui&&(ui.unmount(),ui=null,ve=null)}function yb(t,i){ve!=null&&ve.updateDocument&&ve.updateDocument(t),Ue!=null&&Ue.updateDocument?Ue.updateDocument(t,i):Tn.updateSlides(t.slides,t.config,t.fullMarkdown)}function Ds(t){Ue!=null&&Ue.navigateToBlock?Ue.navigateToBlock(t):Tn.highlightElement(t)}function jn(t){ve!=null&&ve.setActiveBlock&&ve.setActiveBlock(t)}function wb(){return ve!=null&&ve.openImportDialog?(ve.openImportDialog(),!0):!1}const kb=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:_i,value:"true"},{key:ft,value:"cover"},{key:Zt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:_i,value:"true"},{key:ft,value:"two-cols"},{key:Zt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:_i,value:"true"},{key:ft,value:"fact"},{key:Zt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:_i,value:"true"},{key:ft,value:"intro"},{key:Zt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:_i,value:"true"},{key:ft,value:"quote"},{key:Zt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Se,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Se,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:At,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Ci,value:"1-3"}]}];class Ls{getPresetTemplates(){return kb}buildScanSlidevBlocksSql(i="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${i}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${Zt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(i,e,s,n){const r=`SELECT block_id FROM attributes WHERE name = '${Zt}' AND value = '${i}'`,l=await s(r);let o=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{[Zt]:e}),o++)}return{updatedCount:o}}async batchUpdateLayout(i,e,s,n){const r=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${i}'`,l=await s(r);let o=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{"custom-slidev-layout":e}),o++)}return{updatedCount:o}}exportTemplatesJson(){const i=this.getPresetTemplates();return JSON.stringify({templates:i,counter:i.length},null,2)}formatTransitionSummary(i){return!i||i.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${i.map(s=>`${s.value}: ${s.count} 个`).join("，")}`}}const xb=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,_b="slidev-dock",Sr="slidev-preview-tab",Cr=Ep;class Sb extends vt.Plugin{constructor(){super(...arguments);wt(this,"isMobile",!1);wt(this,"currentDocId","");wt(this,"latestCompiledDoc",null);wt(this,"cliBridge",new io);wt(this,"debounceTimer",null);wt(this,"activeCursorBlockId","");wt(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));wt(this,"onWsMainBound",this.onWsMain.bind(this));wt(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));wt(this,"onClickEditorTitleIconBound",this.onClickEditorTitleIcon.bind(this));wt(this,"onEditorClickBound",this.onEditorClick.bind(this));wt(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));wt(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this))}async onload(){const e=vt.getFrontend();this.isMobile=e==="mobile"||e==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(xb),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"Slidev 演示 (下方分屏)",position:"right",callback:()=>{this.openBottomPreviewTab()}}),this.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{this.openBottomPreviewTab()}}),this.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{wb()||vt.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),this.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!this.currentDocId){const n=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(n==null?void 0:n.getAttribute("data-doc-id"))||""}this.currentDocId&&(await Lt(this.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),vt.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(this.currentDocId))}}),this.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!this.currentDocId){const a=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(a==null?void 0:a.getAttribute("data-doc-id"))||""}if(!this.currentDocId){vt.showMessage("请先打开一篇思源笔记文档");return}const n=await qn(this.currentDocId).catch(()=>[]);if(!n||n.length===0){vt.showMessage("当前文档无内容，无需断页");return}const r=n.map(a=>({id:a.id,type:a.type,subType:a.subType,content:a.content||"",markdown:a.markdown||""})),l=Ba(r);if(l.length===0){vt.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}vt.showMessage(`AI 分析完毕：发现 ${l.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const a of l)try{await nn("markdown","---",void 0,a.blockId),await Lt(a.blockId,{"custom-slidev-layout":a.recommendedLayout}),o++}catch(c){console.warn("Failed to insert divider:",c)}vt.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),this.compileCurrentDocument(this.currentDocId)}}),this.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var p,g,u,k;if(!this.currentDocId){const h=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(h==null?void 0:h.getAttribute("data-doc-id"))||""}if(!this.currentDocId){vt.showMessage("请先打开一篇思源笔记文档");return}vt.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const n=await qn(this.currentDocId).catch(()=>[]),r={startBlockId:this.currentDocId,blocks:n.map(h=>({id:h.id,type:h.type,content:h.content||"",rawMarkdown:h.markdown||""})),rawMarkdown:""},a=`> [!NOTE] 💡 演讲备注
${(await Da(r,Ir)).split(/\r?\n/).map(h=>`> ${h}`).join(`
`)}
{: custom-slidev-note="true"}`,c=await $r("markdown",a,this.currentDocId).catch(()=>null),d=((u=(g=(p=c==null?void 0:c[0])==null?void 0:p.doOperations)==null?void 0:g[0])==null?void 0:u.id)||((k=c==null?void 0:c[0])==null?void 0:k.id);d&&(await Lt(d,{"custom-slidev-note":"true"}),Nt.setBlockAttrOverride(d,{"custom-slidev-note":"true"}),Mi(d,this.app)),vt.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),this.compileCurrentDocument(this.currentDocId)}}),this.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const n=new Ls,r=n.buildTransitionStatsSql(),l=await vn(r).catch(()=>[]),o=n.formatTransitionSummary(l||[]);vt.showMessage(o)}}),this.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const r=new Ls().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(r),vt.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):vt.showMessage(`已生成模板数据（请在控制台查看）：
`+r)}}),this.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const r=await new Ls().batchUpdateTransitions("fade","slide-left",l=>vn(l).catch(()=>[]),(l,o)=>Lt(l,o));vt.showMessage(`全库批量替换完成：已将 ${r.updatedCount} 处 fade 转场更新为 slide-left`),this.compileCurrentDocument()}}),this.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),this.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(this.latestCompiledDoc||await this.compileCurrentDocument(),!this.latestCompiledDoc){vt.showMessage("请先打开并放映一篇思源笔记文档");return}this.cliBridge.downloadSlidesMd(this.latestCompiledDoc,`slides-${this.currentDocId||"demo"}.md`)&&vt.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),this.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{vt.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await this.cliBridge.probeServer(1500)?vt.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):vt.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),this.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(this.latestCompiledDoc||await this.compileCurrentDocument(),!this.latestCompiledDoc){vt.showMessage("请先打开并放映一篇思源笔记文档");return}const n=await this.cliBridge.syncToWorkspaceFile(this.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",Os);n.success?vt.showMessage(`已成功同步最新 slides.md 至工作空间：${n.path}`):vt.showMessage(`同步失败：${n.error}`)}});const s=this;if(this.addTab({type:Sr,init(){vb(this.element,s)},destroy(){sa(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:_b,init(){bb(this.element,s)},destroy(){oa(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(n,r)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${n}`,{detail:r}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound)),typeof document<"u"){const n=()=>{const r=this.getActiveDocumentId();r&&(r!==this.currentDocId&&(this.currentDocId=r),this.latestCompiledDoc||this.compileCurrentDocument(r))};setTimeout(n,300),setTimeout(n,1e3)}}async onDataChanged(e){await this.loadGlobalSettings(),this.currentDocId&&await this.compileCurrentDocument(this.currentDocId)}async loadGlobalSettings(){try{const e=await this.loadData(Cr),s=Mp(e);return Vi(s),s}catch{return Vi(Yi),Yi}}async saveGlobalSettings(e){const s=Ao(),n=Vi({...s,...e||{}});try{await this.saveData(Cr,n)}catch(r){console.error("保存 Slidev 全局配置失败",r)}return n}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound)),Tn.detach()}async openBottomPreviewTab(){if(!this.currentDocId){const e=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(e==null?void 0:e.getAttribute("data-doc-id"))||""}await vt.openTab({app:this.app,custom:{id:this.name+Sr,title:"Slidev 演示预览",icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId)}onClickEditorTitleIcon(e){var l;const s=e.detail,n=s==null?void 0:s.menu,r=((l=s==null?void 0:s.data)==null?void 0:l.id)||this.currentDocId;!n||!r||n.addItem({icon:"iconSlidev",label:"Slidev 全局演示配置",submenu:[{label:"初始化演示属性 (custom-slidev-*)",click:async()=>{await Lt(r,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),vt.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"主题: 默认 (default)",click:async()=>{await Lt(r,{"custom-slidev-theme":"default"}),vt.showMessage("已切换为 default 主题"),this.compileCurrentDocument(r)}},{label:"主题: 优雅衬线 (seriph)",click:async()=>{await Lt(r,{"custom-slidev-theme":"seriph"}),vt.showMessage("已切换为 seriph 主题"),this.compileCurrentDocument(r)}},{label:"主题: 苹果极简 (apple-basic)",click:async()=>{await Lt(r,{"custom-slidev-theme":"apple-basic"}),vt.showMessage("已切换为 apple-basic 主题"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"画幅: 16 / 9 (宽屏)",click:async()=>{await Lt(r,{"custom-slidev-aspect-ratio":"16/9"}),vt.showMessage("已切换画幅为 16/9"),this.compileCurrentDocument(r)}},{label:"画幅: 4 / 3 (标屏)",click:async()=>{await Lt(r,{"custom-slidev-aspect-ratio":"4/3"}),vt.showMessage("已切换画幅为 4/3"),this.compileCurrentDocument(r)}}]})}async onSwitchProtyle(e){var r,l;const s=(r=e.detail)==null?void 0:r.protyle,n=(l=s==null?void 0:s.block)==null?void 0:l.rootID;if(n&&n!==this.currentDocId){this.currentDocId=n,this.activeCursorBlockId=n;const o=await Ge(n).catch(()=>({}));jn({id:n,rootId:n,type:"doc",attrs:o}),this.compileCurrentDocument(n)}}onClickEditorContent(e){var r,l;const s=e==null?void 0:e.detail;if(!s)return;const n=(l=(r=s.protyle)==null?void 0:r.block)==null?void 0:l.rootID;n&&(!this.currentDocId||this.currentDocId!==n)&&(this.currentDocId=n),s.event&&this.onEditorClick(s.event)}getActiveDocumentId(){if(typeof document>"u")return"";const e=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),s=e==null?void 0:e.getAttribute("data-node-id");if(s)return s;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),r=n==null?void 0:n.getAttribute("data-node-id");if(r)return r;const l=document.querySelector("[data-doc-id]"),o=l==null?void 0:l.getAttribute("data-doc-id");return o||""}resolveDocIdFromElement(e){const s=e.closest(".protyle-title"),n=s==null?void 0:s.getAttribute("data-node-id");if(n)return n;const r=e.closest(".protyle"),l=r==null?void 0:r.querySelector(".protyle-title"),o=l==null?void 0:l.getAttribute("data-node-id");if(o)return o;const a=e.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||this.currentDocId}async switchToDocGlobalInspector(e,s){var l;if(!e)return;this.activeCursorBlockId=e,this.currentDocId=e;let n=s||"";if(!n&&typeof document<"u"){const o=document.querySelector(`.protyle-title[data-node-id="${e}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${e}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((l=o==null?void 0:o.innerText)==null?void 0:l.trim())||""}const r=await Ge(e).catch(()=>({}));jn({id:e,rootId:e,type:"doc",content:n,attrs:r,isDivider:!1,isCode:!1}),Ds(e)}onWsMain(e){const s=e.detail;if(s){if(s.cmd==="transactions"&&Array.isArray(s.data)){for(const n of s.data)if(Array.isArray(n==null?void 0:n.doOperations)){for(const r of n.doOperations)if((r==null?void 0:r.action)==="updateAttrs"&&r.id&&r.data){const l=r.data.old||{},o=r.data.new||{},a={};for(const c of Object.keys(l))c in o||(a[c]="");for(const[c,d]of Object.entries(o))a[c]=String(d??"");ee(r.id,a),Nt.setBlockAttrOverride(r.id,a)}}}this.debounceTimer&&window.clearTimeout(this.debounceTimer),this.debounceTimer=window.setTimeout(()=>{this.compileCurrentDocument()},150)}}handleBlockClickedFromSlide(e,s){var o,a;if(!e)return!1;this.activeCursorBlockId=e;const n=Mi(e,this.app),r=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`),l=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,e,l);else{let c="",d="";if((o=this.latestCompiledDoc)!=null&&o.slides){const p=this.latestCompiledDoc.slides.find(g=>{var u,k,h;return g.startBlockId===e||((u=g.blocks)==null?void 0:u.some(b=>b.id===e))||((k=g.allBlockIds)==null?void 0:k.includes(e))||((h=g.noteBlocks)==null?void 0:h.some(b=>b.id===e))});p!=null&&p.startBlockId&&(c=p.startBlockId),(a=p==null?void 0:p.frontmatter)!=null&&a.layout&&(d=p.frontmatter.layout)}Ge(e).then(async p=>{if(c&&!d){const g=Nt.getBlockAttrOverride(c);if(g!=null&&g[ft]||g!=null&&g["custom-slidev-layout"])d=g[ft]||g["custom-slidev-layout"]||"";else{const u=await Ge(c).catch(()=>({}))||{};d=u[ft]||u["custom-slidev-layout"]||"",u&&Object.keys(u).length>0&&Nt.setBlockAttrOverride(c,u)}}jn({id:e,rootId:this.currentDocId,type:l||"NodeParagraph",attrs:p||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return n}onBlockClickedFromSlide(e){const s=(e==null?void 0:e.detail)||e;s!=null&&s.blockId&&this.handleBlockClickedFromSlide(s.blockId,s.page)}onEditorClick(e){const s=e.target;if(!s)return;const n=s.closest(".protyle-title")||s.closest(".protyle-background");if(!!(n||s.closest(".protyle-content")&&!s.closest(".protyle-wysiwyg")&&!s.closest(".protyle-breadcrumb")&&!s.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(s);if(d&&this.activeCursorBlockId!==d){const p=n||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=p==null?void 0:p.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!s.closest(".protyle-wysiwyg"))return;const o=s.closest("[data-node-id]");if(!o)return;const a=o.getAttribute("data-node-id"),c=o.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(s)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Ds(a)),this.syncInspectorBlock(o,a,c))}onSelectionChange(){if(typeof window>"u")return;const e=window.getSelection();if(!e||e.rangeCount===0)return;const s=e.anchorNode;if(!s)return;const n=s.nodeType===Node.ELEMENT_NODE?s:s.parentElement;if(!n)return;const r=n.closest(".protyle-title");if(!!(r||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const p=r||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=p==null?void 0:p.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!n.closest(".protyle-wysiwyg"))return;const o=n.closest("[data-node-id]"),a=o==null?void 0:o.getAttribute("data-node-id"),c=(o==null?void 0:o.getAttribute("data-type"))||"";o&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Ds(a)),this.syncInspectorBlock(o,a,c))}async syncInspectorBlock(e,s,n){var J,T,L,w,F,Q,V,it,U,Y,W;let r=e,l=s,o=n;const a=e.closest('[data-type="NodeCallout"]');if(a&&a!==e){const z=a.getAttribute("data-node-id");if(z){const ct=await Ge(z).catch(()=>({}))||{},lt=Nt.getBlockAttrOverride(z)||{},ot={...ct,...lt};(ot[Qt]||ot["slidev-note"])&&(r=a,l=z,o="NodeCallout")}}const c=r.closest(".protyle-wysiwyg > [data-node-id]")||r,d=(c==null?void 0:c.getAttribute("data-node-id"))||l,p=o==="NodeThematicBreak"||o==="tb"||o==="thematic-break"||(c==null?void 0:c.getAttribute("data-type"))==="NodeThematicBreak"||(c==null?void 0:c.getAttribute("data-type"))==="tb"||!!((J=c==null?void 0:c.classList)!=null&&J.contains("hr")),g=o==="NodeCodeBlock",u=((T=r.innerText)==null?void 0:T.trim())||"",k=await Ge(l).catch(()=>({}))||{},h=Nt.getBlockAttrOverride(l)||{},b={...k,...h};let v="",y="";if(p)v=l,y=b[ft]||b["custom-slidev-layout"]||"";else{let z=c.previousElementSibling;for(;z;){const ct=z.getAttribute("data-type");if(ct==="NodeThematicBreak"||ct==="tb"||(L=z.classList)!=null&&L.contains("hr")){v=z.getAttribute("data-node-id")||"";break}z=z.previousElementSibling}}if((w=this.latestCompiledDoc)!=null&&w.slides){const z=[l,d];let ct=r.parentElement;for(;ct&&!ct.classList.contains("protyle-wysiwyg");){const ot=ct.getAttribute("data-node-id");ot&&!z.includes(ot)&&z.push(ot),ct=ct.parentElement}const lt=this.latestCompiledDoc.slides.find(ot=>{var tt,gt,mt;return z.includes(ot.startBlockId)||((tt=ot.blocks)==null?void 0:tt.some(G=>z.includes(G.id)))||((gt=ot.allBlockIds)==null?void 0:gt.some(G=>z.includes(G)))||((mt=ot.noteBlocks)==null?void 0:mt.some(G=>z.includes(G.id)))});lt&&(!v&&lt.startBlockId&&(v=lt.startBlockId),!y&&((F=lt.frontmatter)!=null&&F.layout)&&(y=lt.frontmatter.layout))}if(v){const z=Nt.getBlockAttrOverride(v);if(z&&(ft in z||"custom-slidev-layout"in z)&&(y=z[ft]||z["custom-slidev-layout"]||""),!y&&((Q=this.latestCompiledDoc)!=null&&Q.slides)){const ct=this.latestCompiledDoc.slides.find(lt=>lt.startBlockId===v);(V=ct==null?void 0:ct.frontmatter)!=null&&V.layout&&(y=ct.frontmatter.layout)}if(!y){const ct=await Ge(v).catch(()=>({}))||{};y=ct[ft]||ct["custom-slidev-layout"]||"",ct&&Object.keys(ct).length>0&&Nt.setBlockAttrOverride(v,ct)}ee(v,{[ft]:y||""})}else if(this.currentDocId){const z=Nt.getBlockAttrOverride(this.currentDocId);z&&(ft in z||"custom-slidev-layout"in z)?y=z[ft]||z["custom-slidev-layout"]||"":!y&&((W=(Y=(U=(it=this.latestCompiledDoc)==null?void 0:it.slides)==null?void 0:U[0])==null?void 0:Y.frontmatter)!=null&&W.layout)&&(y=this.latestCompiledDoc.slides[0].frontmatter.layout)}const $=r.getAttribute(ft)||r.getAttribute("custom-slidev-layout"),A=b[ft]||b["custom-slidev-layout"]||"";$&&$!==A&&ee(l,{[ft]:A});const x=r.getAttribute(Ut)||r.getAttribute("custom-slidev-role"),_=b[Ut]||b["custom-slidev-role"]||"";x&&x!==_&&ee(l,{[Ut]:_});const S=r.closest('[data-type="NodeListItem"]');if(S&&S!==r){const z=S.getAttribute("data-node-id");if(z){const ct=await Ge(z).catch(()=>({}))||{},lt=Nt.getBlockAttrOverride(z)||{},ot={...ct,...lt},tt=ot[ft]||ot["custom-slidev-layout"]||"",gt=S.getAttribute(ft)||S.getAttribute("custom-slidev-layout");gt&&gt!==tt&&ee(z,{[ft]:tt});const mt=ot[Ut]||ot["custom-slidev-role"]||"",G=S.getAttribute(Ut)||S.getAttribute("custom-slidev-role");G&&G!==mt&&ee(z,{[Ut]:mt})}}const D=!!r.querySelector("img, span[data-type='img']"),M=(r.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),P=D&&M.length<=50;jn({id:l,rootId:this.currentDocId,type:o,content:u,attrs:b,isDivider:p,isCode:g,isImage:P,topBlockId:d,pageDividerId:v,pageDividerLayout:y})}async compileCurrentDocument(e){var n,r,l,o;let s=e||this.currentDocId;if(!s){const a=document.querySelector(".protyle.layout__wnd--active, .layout__wnd--active .protyle, .protyle"),c=(a==null?void 0:a.getAttribute("data-doc-id"))||((n=a==null?void 0:a.querySelector(".protyle-wysiwyg"))==null?void 0:n.getAttribute("data-doc-id"))||((r=a==null?void 0:a.querySelector(".protyle-title"))==null?void 0:r.getAttribute("data-node-id"))||((l=document.querySelector(".protyle-content[data-doc-id]"))==null?void 0:l.getAttribute("data-doc-id"))||((o=document.querySelector("[data-doc-id]"))==null?void 0:o.getAttribute("data-doc-id"));if(c)this.currentDocId=c,s=c;else return}try{const a=await Nt.compile(s);this.latestCompiledDoc=a,yb(a,s),this.purgeStaleDomSlidevAttrs(a)}catch(a){console.error("[SiYuanSlidev] Failed to compile document:",a)}}purgeStaleDomSlidevAttrs(e){var r,l,o;if(typeof document>"u"||!e)return;const s=new Map;if(Array.isArray(e.slides))for(const a of e.slides){if(a.startBlockId){const c=s.get(a.startBlockId)||{};(r=a.frontmatter)!=null&&r.layout&&(c[ft]=a.frontmatter.layout),s.set(a.startBlockId,c)}if(Array.isArray(a.blocks)){for(const c of a.blocks)if(c.id){const d=s.get(c.id)||{};(l=c.ial)!=null&&l[ft]&&(d[ft]=c.ial[ft]),(o=c.ial)!=null&&o[Ut]&&(d[Ut]=c.ial[Ut]),Object.keys(d).length>0&&s.set(c.id,d)}}}const n=Nt.getAllAttrOverrides();for(const[a,c]of n.entries()){const d=s.get(a)||{};c[ft]!==void 0&&(d[ft]=c[ft]),c[Ut]!==void 0&&(d[Ut]=c[Ut]),s.set(a,d)}Ff(s)}}module.exports=Sb;
