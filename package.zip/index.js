"use strict";var Bc=Object.create;var Vs=Object.defineProperty;var Mc=Object.getOwnPropertyDescriptor;var Dc=Object.getOwnPropertyNames;var Lc=Object.getPrototypeOf,Pc=Object.prototype.hasOwnProperty;var Oc=(e,t,i)=>t in e?Vs(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i;var Rc=(e,t,i,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let s of Dc(t))!Pc.call(e,s)&&s!==i&&Vs(e,s,{get:()=>t[s],enumerable:!(n=Mc(t,s))||n.enumerable});return e};var Gn=(e,t,i)=>(i=e!=null?Bc(Lc(e)):{},Rc(t||!e||!e.__esModule?Vs(i,"default",{value:e,enumerable:!0}):i,e));var Se=(e,t,i)=>Oc(e,typeof t!="symbol"?t+"":t,i);const me=require("siyuan");async function gt(e,t){const i=await me.fetchSyncPost(e,t);return i.code===0?i.data:null}async function Nc(){return gt("/api/notebook/lsNotebooks","")}async function zc(e,t,i){return gt("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:i})}async function nl(e,t){const i=new FormData;i.append("assetsDirPath",e);for(const s of t)i.append("file[]",s);return gt("/api/asset/upload",i)}async function Mi(e,t,i,n,s){return gt("/api/block/insertBlock",{dataType:e,data:t,nextID:i,previousID:n,parentID:s})}async function uo(e,t,i){return gt("/api/block/appendBlock",{dataType:e,data:t,parentID:i})}async function dr(e,t,i){return gt("/api/block/updateBlock",{dataType:e,data:t,id:i})}async function sl(e){return gt("/api/block/deleteBlock",{id:e})}async function Fc(e){return gt("/api/block/getBlockKramdown",{id:e})}async function us(e){return gt("/api/block/getChildBlocks",{id:e})}async function Hc(e){return gt("/api/block/getDocBlocksOrders",{id:e})}async function He(e,t){return gt("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function Mo(e){return gt("/api/attr/getBlockAttrs",{id:e})}async function sn(e){return gt("/api/query/sql",{stmt:e})}async function fo(e,t,i){const n=new FormData;return n.append("path",e),n.append("isDir",t.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",i),gt("/api/file/putFile",n)}async function ol(e){const t="/api/ai/chatGPT";try{const i=await gt(t,{msg:e});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function jc(){return gt("/api/storage/getInlineStyles","")}const rl=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function Wc(e){const t=[];if(!e)return t;const i=new RegExp(rl.source,"g");let n;for(;(n=i.exec(e))!==null;){const s=n[2]??n[3]??n[4];t.push({fullMatch:n[0],blockId:n[1],anchorText:s?s.trim():void 0})}return t}function Uc(e,t){if(!e)return"";const i=new RegExp(rl.source,"g");return e.replace(i,(n,s,o,l,r)=>{const a=(o??l??r??"").trim();if(t&&t[s]){const d=t[s].trim();return`<div class="slidev-block-ref" data-ref-id="${s}">${d}</div>`}const c=a||`Ref(${s.slice(0,8)})`;return`<a href="siyuan://blocks/${s}" data-ref-id="${s}" class="slidev-ref-tag">🔗 ${c}</a>`})}const An="custom-slidev-theme",Bn="custom-slidev-aspect-ratio",ll="custom-slidev-highlighter",Mn="custom-slidev-default-transition",al="custom-slidev-color-schema",po="custom-slidev-spacing",Ai="custom-slidev-slide",ge="custom-slidev-layout",tt="custom-slidev-transition",Ke="custom-slidev-background",Dt="custom-slidev-image",Ki="custom-slidev-notes",Gi="custom-slidev-class",wn="custom-slidev-spacing",kt="custom-slidev-layout-ratio",qi="custom-slidev-mask",Zi="custom-slidev-mask-ratio",Yi="custom-slidev-mask-style",Ji="custom-slidev-mask-initial",Ye="custom-slidev-click",qt="custom-slidev-motion",Ni="custom-slidev-shiki-lines",$e="custom-slidev-slot",nt="custom-slidev-note",Ze="custom-slidev-role",Dn="custom-slidev-max-height",Bi="custom-slidev-autoplay",fs="custom-slidev-loop",Vi="custom-slidev-muted",ps="custom-slidev-controls",cl="background",hs="image-left",ms="image-right";function Ln(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function Vc(e){if(!e||typeof e!="string")return{steps:2,breakpoints:[50,100]};const t=e.trim();if(!t)return{steps:2,breakpoints:[50,100]};const i=t.split(":").map(c=>parseFloat(c.trim())).filter(c=>!isNaN(c)&&c>0);if(i.length===0)return{steps:2,breakpoints:[50,100]};if(i.length===1){const c=Math.min(100,Math.max(1,i[0]));return c===100?{steps:1,breakpoints:[100]}:{steps:2,breakpoints:[Math.round(c*100)/100,100]}}const n=i.every((c,d)=>d===0||c>i[d-1]),s=i[i.length-1];if(n&&(s===100||i.some(c=>c>10))){const c=i.map(d=>Math.min(100,Math.round(d*100)/100));return c[c.length-1]<100&&c.push(100),{steps:c.length,breakpoints:c}}const l=i.reduce((c,d)=>c+d,0);if(l<=0)return{steps:2,breakpoints:[50,100]};let r=0;const a=[];for(let c=0;c<i.length;c++)r+=i[c],c===i.length-1?a.push(100):a.push(Math.round(r/l*1e4)/100);return{steps:a.length,breakpoints:a}}function Kc(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function Gc(e){const t={};if(!e)return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(i))!==null;){const o=s[1],l=s[2]??s[3]??s[4]??"";t[o]=l}return t}function dl(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function ul(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function Tt(e,t){if(!dl(e))return e;const i=ul(e);return t!=null&&t.base64Map&&t.base64Map[i]?t.base64Map[i]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function qc(e,t){if(!e)return"";let i=e;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,s,o)=>{const l=Tt(o,t);return`![${s}](${l})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,s,o,l)=>{const r=Tt(o,t);return`${s}${r}${l}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,s,o,l)=>{const r=Tt(o,t);return`${s}${r}${l}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Do(e){const t=Object.create(null);for(const i of e.split(","))t[i]=1;return i=>i in t}const Ge={},Xi=[],Zt=()=>{},fl=()=>!1,Is=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),Ts=e=>e.startsWith("onUpdate:"),dt=Object.assign,Lo=(e,t)=>{const i=e.indexOf(t);i>-1&&e.splice(i,1)},Zc=Object.prototype.hasOwnProperty,Fe=(e,t)=>Zc.call(e,t),Ie=Array.isArray,Qi=e=>jn(e)==="[object Map]",cn=e=>jn(e)==="[object Set]",ur=e=>jn(e)==="[object Date]",Ae=e=>typeof e=="function",it=e=>typeof e=="string",Nt=e=>typeof e=="symbol",Ve=e=>e!==null&&typeof e=="object",pl=e=>(Ve(e)||Ae(e))&&Ae(e.then)&&Ae(e.catch),hl=Object.prototype.toString,jn=e=>hl.call(e),Yc=e=>jn(e).slice(8,-1),ml=e=>jn(e)==="[object Object]",Po=e=>it(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,xn=Do(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Es=e=>{const t=Object.create(null);return(i=>t[i]||(t[i]=e(i)))},Jc=/-\w/g,wt=Es(e=>e.replace(Jc,t=>t.slice(1).toUpperCase())),Xc=/\B([A-Z])/g,xi=Es(e=>e.replace(Xc,"-$1").toLowerCase()),As=Es(e=>e.charAt(0).toUpperCase()+e.slice(1)),Ks=Es(e=>e?`on${As(e)}`:""),Kt=(e,t)=>!Object.is(e,t),is=(e,...t)=>{for(let i=0;i<e.length;i++)e[i](...t)},gl=(e,t,i,n=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:n,value:i})},Bs=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let fr;const Ms=()=>fr||(fr=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function Gt(e){if(Ie(e)){const t={};for(let i=0;i<e.length;i++){const n=e[i],s=it(n)?id(n):Gt(n);if(s)for(const o in s)t[o]=s[o]}return t}else if(it(e)||Ve(e))return e}const Qc=/;(?![^(]*\))/g,ed=/:([^]+)/,td=/\/\*[^]*?\*\//g;function id(e){const t={};return e.replace(td,"").split(Qc).forEach(i=>{if(i){const n=i.split(ed);n.length>1&&(t[n[0].trim()]=n[1].trim())}}),t}function _e(e){let t="";if(it(e))t=e;else if(Ie(e))for(let i=0;i<e.length;i++){const n=_e(e[i]);n&&(t+=n+" ")}else if(Ve(e))for(const i in e)e[i]&&(t+=i+" ");return t.trim()}const nd="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",sd=Do(nd);function vl(e){return!!e||e===""}function od(e,t){if(e.length!==t.length)return!1;let i=!0;for(let n=0;i&&n<e.length;n++)i=dn(e[n],t[n]);return i}function dn(e,t){if(e===t)return!0;let i=ur(e),n=ur(t);if(i||n)return i&&n?e.getTime()===t.getTime():!1;if(i=Nt(e),n=Nt(t),i||n)return e===t;if(i=Ie(e),n=Ie(t),i||n)return i&&n?od(e,t):!1;if(i=Ve(e),n=Ve(t),i||n){if(!i||!n)return!1;const s=Object.keys(e).length,o=Object.keys(t).length;if(s!==o)return!1;for(const l in e){const r=e.hasOwnProperty(l),a=t.hasOwnProperty(l);if(r&&!a||!r&&a||!dn(e[l],t[l]))return!1}}return String(e)===String(t)}function Oo(e,t){return e.findIndex(i=>dn(i,t))}const bl=e=>!!(e&&e.__v_isRef===!0),ke=e=>it(e)?e:e==null?"":Ie(e)||Ve(e)&&(e.toString===hl||!Ae(e.toString))?bl(e)?ke(e.value):JSON.stringify(e,yl,2):String(e),yl=(e,t)=>bl(t)?yl(e,t.value):Qi(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((i,[n,s],o)=>(i[Gs(n,o)+" =>"]=s,i),{})}:cn(t)?{[`Set(${t.size})`]:[...t.values()].map(i=>Gs(i))}:Nt(t)?Gs(t):Ve(t)&&!Ie(t)&&!ml(t)?String(t):t,Gs=(e,t="")=>{var i;return Nt(e)?`Symbol(${(i=e.description)!=null?i:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let at;class rd{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&at&&(at.active?(this.parent=at,this.index=(at.scopes||(at.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,i;if(this.scopes){const n=this.scopes.slice();for(t=0,i=n.length;t<i;t++)n[t].pause()}for(t=0,i=this.effects.length;t<i;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,i;if(this.scopes){const s=this.scopes.slice();for(t=0,i=s.length;t<i;t++)s[t].resume()}const n=this.effects.slice();for(t=0,i=n.length;t<i;t++)n[t].resume()}}run(t){if(this._active){const i=at;try{return at=this,t()}finally{at=i}}}on(){++this._on===1&&(this.prevScope=at,at=this)}off(){if(this._on>0&&--this._on===0){if(at===this)at=this.prevScope;else{let t=at;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let i,n;for(i=0,n=this.effects.length;i<n;i++)this.effects[i].stop();for(this.effects.length=0,i=0,n=this.cleanups.length;i<n;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const s=this.scopes.slice();for(i=0,n=s.length;i<n;i++)s[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const s=this.parent.scopes.pop();s&&s!==this&&(this.parent.scopes[this.index]=s,s.index=this.index)}this.parent=void 0}}}function ld(){return at}let qe;const qs=new WeakSet;class kl{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,at&&(at.active?at.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,qs.has(this)&&(qs.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||xl(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,pr(this),Sl(this);const t=qe,i=Ot;qe=this,Ot=!0;try{return this.fn()}finally{_l(this),qe=t,Ot=i,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)zo(t);this.deps=this.depsTail=void 0,pr(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?qs.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){ho(this)&&this.run()}get dirty(){return ho(this)}}let wl=0,Sn,_n;function xl(e,t=!1){if(e.flags|=8,t){e.next=_n,_n=e;return}e.next=Sn,Sn=e}function Ro(){wl++}function No(){if(--wl>0)return;if(_n){let t=_n;for(_n=void 0;t;){const i=t.next;t.next=void 0,t.flags&=-9,t=i}}let e;for(;Sn;){let t=Sn;for(Sn=void 0;t;){const i=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(n){e||(e=n)}t=i}}if(e)throw e}function Sl(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function _l(e){let t,i=e.depsTail,n=i;for(;n;){const s=n.prevDep;n.version===-1?(n===i&&(i=s),zo(n),ad(n)):t=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=s}e.deps=t,e.depsTail=i}function ho(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(Cl(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function Cl(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===Pn)||(e.globalVersion=Pn,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!ho(e))))return;e.flags|=2;const t=e.dep,i=qe,n=Ot;qe=e,Ot=!0;try{Sl(e);const s=e.fn(e._value);(t.version===0||Kt(s,e._value))&&(e.flags|=128,e._value=s,t.version++)}catch(s){throw t.version++,s}finally{qe=i,Ot=n,_l(e),e.flags&=-3}}function zo(e,t=!1){const{dep:i,prevSub:n,nextSub:s}=e;if(n&&(n.nextSub=s,e.prevSub=void 0),s&&(s.prevSub=n,e.nextSub=void 0),i.subs===e&&(i.subs=n,!n&&i.computed)){i.computed.flags&=-5;for(let o=i.computed.deps;o;o=o.nextDep)zo(o,!0)}!t&&!--i.sc&&i.map&&i.map.delete(i.key)}function ad(e){const{prevDep:t,nextDep:i}=e;t&&(t.nextDep=i,e.prevDep=void 0),i&&(i.prevDep=t,e.nextDep=void 0)}let Ot=!0;const $l=[];function oi(){$l.push(Ot),Ot=!1}function ri(){const e=$l.pop();Ot=e===void 0?!0:e}function pr(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const i=qe;qe=void 0;try{t()}finally{qe=i}}}let Pn=0;class cd{constructor(t,i){this.sub=t,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class Fo{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!qe||!Ot||qe===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==qe)i=this.activeLink=new cd(qe,this),qe.deps?(i.prevDep=qe.depsTail,qe.depsTail.nextDep=i,qe.depsTail=i):qe.deps=qe.depsTail=i,Il(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const n=i.nextDep;n.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=n),i.prevDep=qe.depsTail,i.nextDep=void 0,qe.depsTail.nextDep=i,qe.depsTail=i,qe.deps===i&&(qe.deps=n)}return i}trigger(t){this.version++,Pn++,this.notify(t)}notify(t){Ro();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{No()}}}function Il(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let n=t.deps;n;n=n.nextDep)Il(n)}const i=e.dep.subs;i!==e&&(e.prevSub=i,i&&(i.nextSub=e)),e.dep.subs=e}}const mo=new WeakMap,Pi=Symbol(""),go=Symbol(""),On=Symbol("");function pt(e,t,i){if(Ot&&qe){let n=mo.get(e);n||mo.set(e,n=new Map);let s=n.get(i);s||(n.set(i,s=new Fo),s.map=n,s.key=i),s.track()}}function ti(e,t,i,n,s,o){const l=mo.get(e);if(!l){Pn++;return}const r=a=>{a&&a.trigger()};if(Ro(),t==="clear")l.forEach(r);else{const a=Ie(e),c=a&&Po(i);if(a&&i==="length"){const d=Number(n);l.forEach((p,g)=>{(g==="length"||g===On||!Nt(g)&&g>=d)&&r(p)})}else switch((i!==void 0||l.has(void 0))&&r(l.get(i)),c&&r(l.get(On)),t){case"add":a?c&&r(l.get("length")):(r(l.get(Pi)),Qi(e)&&r(l.get(go)));break;case"delete":a||(r(l.get(Pi)),Qi(e)&&r(l.get(go)));break;case"set":Qi(e)&&r(l.get(Pi));break}}No()}function Wi(e){const t=ze(e);return t===e?t:(pt(t,"iterate",On),Bt(e)?t:t.map(zt))}function Ds(e){return pt(e=ze(e),"iterate",On),e}function Ut(e,t){return li(e)?on(Oi(e)?zt(t):t):zt(t)}const dd={__proto__:null,[Symbol.iterator](){return Zs(this,Symbol.iterator,e=>Ut(this,e))},concat(...e){return Wi(this).concat(...e.map(t=>Ie(t)?Wi(t):t))},entries(){return Zs(this,"entries",e=>(e[1]=Ut(this,e[1]),e))},every(e,t){return Xt(this,"every",e,t,void 0,arguments)},filter(e,t){return Xt(this,"filter",e,t,i=>i.map(n=>Ut(this,n)),arguments)},find(e,t){return Xt(this,"find",e,t,i=>Ut(this,i),arguments)},findIndex(e,t){return Xt(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return Xt(this,"findLast",e,t,i=>Ut(this,i),arguments)},findLastIndex(e,t){return Xt(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return Xt(this,"forEach",e,t,void 0,arguments)},includes(...e){return Ys(this,"includes",e)},indexOf(...e){return Ys(this,"indexOf",e)},join(e){return Wi(this).join(e)},lastIndexOf(...e){return Ys(this,"lastIndexOf",e)},map(e,t){return Xt(this,"map",e,t,void 0,arguments)},pop(){return gn(this,"pop")},push(...e){return gn(this,"push",e)},reduce(e,...t){return hr(this,"reduce",e,t)},reduceRight(e,...t){return hr(this,"reduceRight",e,t)},shift(){return gn(this,"shift")},some(e,t){return Xt(this,"some",e,t,void 0,arguments)},splice(...e){return gn(this,"splice",e)},toReversed(){return Wi(this).toReversed()},toSorted(e){return Wi(this).toSorted(e)},toSpliced(...e){return Wi(this).toSpliced(...e)},unshift(...e){return gn(this,"unshift",e)},values(){return Zs(this,"values",e=>Ut(this,e))}};function Zs(e,t,i){const n=Ds(e),s=n[t]();return n!==e&&!Bt(e)&&(s._next=s.next,s.next=()=>{const o=s._next();return o.done||(o.value=i(o.value)),o}),s}const ud=Array.prototype;function Xt(e,t,i,n,s,o){const l=Ds(e),r=l!==e&&!Bt(e),a=l[t];if(a!==ud[t]){const p=a.apply(e,o);return r?zt(p):p}let c=i;l!==e&&(r?c=function(p,g){return i.call(this,Ut(e,p),g,e)}:i.length>2&&(c=function(p,g){return i.call(this,p,g,e)}));const d=a.call(l,c,n);return r&&s?s(d):d}function hr(e,t,i,n){const s=Ds(e),o=s!==e&&!Bt(e);let l=i,r=!1;s!==e&&(o?(r=n.length===0,l=function(c,d,p){return r&&(r=!1,c=Ut(e,c)),i.call(this,c,Ut(e,d),p,e)}):i.length>3&&(l=function(c,d,p){return i.call(this,c,d,p,e)}));const a=s[t](l,...n);return r?Ut(e,a):a}function Ys(e,t,i){const n=ze(e);pt(n,"iterate",On);const s=n[t](...i);return(s===-1||s===!1)&&Wo(i[0])?(i[0]=ze(i[0]),n[t](...i)):s}function gn(e,t,i=[]){oi(),Ro();const n=ze(e)[t].apply(e,i);return No(),ri(),n}const fd=Do("__proto__,__v_isRef,__isVue"),Tl=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Nt));function pd(e){Nt(e)||(e=String(e));const t=ze(this);return pt(t,"has",e),t.hasOwnProperty(e)}class El{constructor(t=!1,i=!1){this._isReadonly=t,this._isShallow=i}get(t,i,n){if(i==="__v_skip")return t.__v_skip;const s=this._isReadonly,o=this._isShallow;if(i==="__v_isReactive")return!s;if(i==="__v_isReadonly")return s;if(i==="__v_isShallow")return o;if(i==="__v_raw")return n===(s?o?Sd:Dl:o?Ml:Bl).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(n)?t:void 0;const l=Ie(t);if(!s){let a;if(l&&(a=dd[i]))return a;if(i==="hasOwnProperty")return pd}const r=Reflect.get(t,i,Je(t)?t:n);if((Nt(i)?Tl.has(i):fd(i))||(s||pt(t,"get",i),o))return r;if(Je(r)){const a=l&&Po(i)?r:r.value;return s&&Ve(a)?bo(a):a}return Ve(r)?s?bo(r):Ls(r):r}}class Al extends El{constructor(t=!1){super(!1,t)}set(t,i,n,s){let o=t[i];const l=Ie(t)&&Po(i);if(!this._isShallow){const c=li(o);if(!Bt(n)&&!li(n)&&(o=ze(o),n=ze(n)),!l&&Je(o)&&!Je(n))return c||(o.value=n),!0}const r=l?Number(i)<t.length:Fe(t,i),a=Reflect.set(t,i,n,Je(t)?t:s);return t===ze(s)&&a&&(r?Kt(n,o)&&ti(t,"set",i,n):ti(t,"add",i,n)),a}deleteProperty(t,i){const n=Fe(t,i);t[i];const s=Reflect.deleteProperty(t,i);return s&&n&&ti(t,"delete",i,void 0),s}has(t,i){const n=Reflect.has(t,i);return(!Nt(i)||!Tl.has(i))&&pt(t,"has",i),n}ownKeys(t){return pt(t,"iterate",Ie(t)?"length":Pi),Reflect.ownKeys(t)}}class hd extends El{constructor(t=!1){super(!0,t)}set(t,i){return!0}deleteProperty(t,i){return!0}}const md=new Al,gd=new hd,vd=new Al(!0);const vo=e=>e,qn=e=>Reflect.getPrototypeOf(e);function bd(e,t,i){return function(...n){const s=this.__v_raw,o=ze(s),l=Qi(o),r=e==="entries"||e===Symbol.iterator&&l,a=e==="keys"&&l,c=s[e](...n),d=i?vo:t?on:zt;return!t&&pt(o,"iterate",a?go:Pi),dt(Object.create(c),{next(){const{value:p,done:g}=c.next();return g?{value:p,done:g}:{value:r?[d(p[0]),d(p[1])]:d(p),done:g}}})}}function Zn(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function yd(e,t){const i={get(s){const o=this.__v_raw,l=ze(o),r=ze(s);e||(Kt(s,r)&&pt(l,"get",s),pt(l,"get",r));const{has:a}=qn(l),c=t?vo:e?on:zt;if(a.call(l,s))return c(o.get(s));if(a.call(l,r))return c(o.get(r));o!==l&&o.get(s)},get size(){const s=this.__v_raw;return!e&&pt(ze(s),"iterate",Pi),s.size},has(s){const o=this.__v_raw,l=ze(o),r=ze(s);return e||(Kt(s,r)&&pt(l,"has",s),pt(l,"has",r)),s===r?o.has(s):o.has(s)||o.has(r)},forEach(s,o){const l=this,r=l.__v_raw,a=ze(r),c=t?vo:e?on:zt;return!e&&pt(a,"iterate",Pi),r.forEach((d,p)=>s.call(o,c(d),c(p),l))}};return dt(i,e?{add:Zn("add"),set:Zn("set"),delete:Zn("delete"),clear:Zn("clear")}:{add(s){const o=ze(this),l=qn(o),r=ze(s),a=!t&&!Bt(s)&&!li(s)?r:s;return l.has.call(o,a)||Kt(s,a)&&l.has.call(o,s)||Kt(r,a)&&l.has.call(o,r)||(o.add(a),ti(o,"add",a,a)),this},set(s,o){!t&&!Bt(o)&&!li(o)&&(o=ze(o));const l=ze(this),{has:r,get:a}=qn(l);let c=r.call(l,s);c||(s=ze(s),c=r.call(l,s));const d=a.call(l,s);return l.set(s,o),c?Kt(o,d)&&ti(l,"set",s,o):ti(l,"add",s,o),this},delete(s){const o=ze(this),{has:l,get:r}=qn(o);let a=l.call(o,s);a||(s=ze(s),a=l.call(o,s)),r&&r.call(o,s);const c=o.delete(s);return a&&ti(o,"delete",s,void 0),c},clear(){const s=ze(this),o=s.size!==0,l=s.clear();return o&&ti(s,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(s=>{i[s]=bd(s,e,t)}),i}function Ho(e,t){const i=yd(e,t);return(n,s,o)=>s==="__v_isReactive"?!e:s==="__v_isReadonly"?e:s==="__v_raw"?n:Reflect.get(Fe(i,s)&&s in n?i:n,s,o)}const kd={get:Ho(!1,!1)},wd={get:Ho(!1,!0)},xd={get:Ho(!0,!1)};const Bl=new WeakMap,Ml=new WeakMap,Dl=new WeakMap,Sd=new WeakMap;function _d(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Ls(e){return li(e)?e:jo(e,!1,md,kd,Bl)}function Cd(e){return jo(e,!1,vd,wd,Ml)}function bo(e){return jo(e,!0,gd,xd,Dl)}function jo(e,t,i,n,s){if(!Ve(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const o=s.get(e);if(o)return o;const l=_d(Yc(e));if(l===0)return e;const r=new Proxy(e,l===2?n:i);return s.set(e,r),r}function Oi(e){return li(e)?Oi(e.__v_raw):!!(e&&e.__v_isReactive)}function li(e){return!!(e&&e.__v_isReadonly)}function Bt(e){return!!(e&&e.__v_isShallow)}function Wo(e){return e?!!e.__v_raw:!1}function ze(e){const t=e&&e.__v_raw;return t?ze(t):e}function $d(e){return!Fe(e,"__v_skip")&&Object.isExtensible(e)&&gl(e,"__v_skip",!0),e}const zt=e=>Ve(e)?Ls(e):e,on=e=>Ve(e)?bo(e):e;function Je(e){return e?e.__v_isRef===!0:!1}function pe(e){return Id(e,!1)}function Id(e,t){return Je(e)?e:new Td(e,t)}class Td{constructor(t,i){this.dep=new Fo,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?t:ze(t),this._value=i?t:zt(t),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(t){const i=this._rawValue,n=this.__v_isShallow||Bt(t)||li(t);t=n?t:ze(t),Kt(t,i)&&(this._rawValue=t,this._value=n?t:zt(t),this.dep.trigger())}}function ye(e){return Je(e)?e.value:e}const Ed={get:(e,t,i)=>t==="__v_raw"?e:ye(Reflect.get(e,t,i)),set:(e,t,i,n)=>{const s=e[t];return Je(s)&&!Je(i)?(s.value=i,!0):Reflect.set(e,t,i,n)}};function Ll(e){return Oi(e)?e:new Proxy(e,Ed)}class Ad{constructor(t,i,n){this.fn=t,this.setter=i,this._value=void 0,this.dep=new Fo(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=Pn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&qe!==this)return xl(this,!0),!0}get value(){const t=this.dep.track();return Cl(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function Bd(e,t,i=!1){let n,s;return Ae(e)?n=e:(n=e.get,s=e.set),new Ad(n,s,i)}const Yn={},gs=new WeakMap;let Ei;function Md(e,t=!1,i=Ei){if(i){let n=gs.get(i);n||gs.set(i,n=[]),n.push(e)}}function Dd(e,t,i=Ge){const{immediate:n,deep:s,once:o,scheduler:l,augmentJob:r,call:a}=i,c=B=>s?B:Bt(B)||s===!1||s===0?ii(B,1):ii(B);let d,p,g,u,m=!1,h=!1;if(Je(e)?(p=()=>e.value,m=Bt(e)):Oi(e)?(p=()=>c(e),m=!0):Ie(e)?(h=!0,m=e.some(B=>Oi(B)||Bt(B)),p=()=>e.map(B=>{if(Je(B))return B.value;if(Oi(B))return c(B);if(Ae(B))return a?a(B,2):B()})):Ae(e)?t?p=a?()=>a(e,2):e:p=()=>{if(g){oi();try{g()}finally{ri()}}const B=Ei;Ei=d;try{return a?a(e,3,[u]):e(u)}finally{Ei=B}}:p=Zt,t&&s){const B=p,M=s===!0?1/0:s;p=()=>ii(B(),M)}const b=ld(),y=()=>{d.stop(),b&&b.active&&Lo(b.effects,d)};if(o&&t){const B=t;t=(...M)=>{const T=B(...M);return y(),T}}let x=h?new Array(e.length).fill(Yn):Yn;const _=B=>{if(!(!(d.flags&1)||!d.dirty&&!B))if(t){const M=d.run();if(B||s||m||(h?M.some((T,w)=>Kt(T,x[w])):Kt(M,x))){g&&g();const T=Ei;Ei=d;try{const w=[M,x===Yn?void 0:h&&x[0]===Yn?[]:x,u];x=M,a?a(t,3,w):t(...w)}finally{Ei=T}}}else d.run()};return r&&r(_),d=new kl(p),d.scheduler=l?()=>l(_,!1):_,u=B=>Md(B,!1,d),g=d.onStop=()=>{const B=gs.get(d);if(B){if(a)a(B,4);else for(const M of B)M();gs.delete(d)}},t?n?_(!0):x=d.run():l?l(_.bind(null,!0),!0):d.run(),y.pause=d.pause.bind(d),y.resume=d.resume.bind(d),y.stop=y,y}function ii(e,t=1/0,i){if(t<=0||!Ve(e)||e.__v_skip||(i=i||new Map,(i.get(e)||0)>=t))return e;if(i.set(e,t),t--,Je(e))ii(e.value,t,i);else if(Ie(e))for(let n=0;n<e.length;n++)ii(e[n],t,i);else if(cn(e)||Qi(e))e.forEach(n=>{ii(n,t,i)});else if(ml(e)){for(const n in e)ii(e[n],t,i);for(const n of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,n)&&ii(e[n],t,i)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Wn(e,t,i,n){try{return n?e(...n):e()}catch(s){Ps(s,t,i)}}function Ft(e,t,i,n){if(Ae(e)){const s=Wn(e,t,i,n);return s&&pl(s)&&s.catch(o=>{Ps(o,t,i)}),s}if(Ie(e)){const s=[];for(let o=0;o<e.length;o++)s.push(Ft(e[o],t,i,n));return s}}function Ps(e,t,i,n=!0){const s=t?t.vnode:null,{errorHandler:o,throwUnhandledErrorInProduction:l}=t&&t.appContext.config||Ge;if(t){let r=t.parent;const a=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const d=r.ec;if(d){for(let p=0;p<d.length;p++)if(d[p](e,a,c)===!1)return}r=r.parent}if(o){oi(),Wn(o,null,10,[e,a,c]),ri();return}}Ld(e,i,s,n,l)}function Ld(e,t,i,n=!0,s=!1){if(s)throw e;console.error(e)}const yt=[];let Wt=-1;const en=[];let hi=null,Ui=0;const Pl=Promise.resolve();let vs=null;function bs(e){const t=vs||Pl;return e?t.then(this?e.bind(this):e):t}function Pd(e){let t=Wt+1,i=yt.length;for(;t<i;){const n=t+i>>>1,s=yt[n],o=Rn(s);o<e||o===e&&s.flags&2?t=n+1:i=n}return t}function Uo(e){if(!(e.flags&1)){const t=Rn(e),i=yt[yt.length-1];!i||!(e.flags&2)&&t>=Rn(i)?yt.push(e):yt.splice(Pd(t),0,e),e.flags|=1,Ol()}}function Ol(){vs||(vs=Pl.then(Nl))}function Od(e){Ie(e)?en.push(...e):hi&&e.id===-1?hi.splice(Ui+1,0,e):e.flags&1||(en.push(e),e.flags|=1),Ol()}function mr(e,t,i=Wt+1){for(;i<yt.length;i++){const n=yt[i];if(n&&n.flags&2){if(e&&n.id!==e.uid)continue;yt.splice(i,1),i--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function Rl(e){if(en.length){const t=[...new Set(en)].sort((i,n)=>Rn(i)-Rn(n));if(en.length=0,hi){hi.push(...t);return}for(hi=t,Ui=0;Ui<hi.length;Ui++){const i=hi[Ui];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}hi=null,Ui=0}}const Rn=e=>e.id==null?e.flags&2?-1:1/0:e.id;function Nl(e){try{for(Wt=0;Wt<yt.length;Wt++){const t=yt[Wt];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),Wn(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;Wt<yt.length;Wt++){const t=yt[Wt];t&&(t.flags&=-2)}Wt=-1,yt.length=0,Rl(),vs=null,(yt.length||en.length)&&Nl()}}let ct=null,zl=null;function ys(e){const t=ct;return ct=e,zl=e&&e.type.__scopeId||null,t}function Fl(e,t=ct,i){if(!t||e._n)return e;const n=(...s)=>{n._d&&Ir(-1);const o=ys(t),l=ni.length;let r;try{r=e(...s)}finally{for(let a=ni.length;a>l;a--)Zo();ys(o),n._d&&Ir(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Et(e,t){if(ct===null)return e;const i=Fs(ct),n=e.dirs||(e.dirs=[]);for(let s=0;s<t.length;s++){let[o,l,r,a=Ge]=t[s];o&&(Ae(o)&&(o={mounted:o,updated:o}),o.deep&&ii(l),n.push({dir:o,instance:i,value:l,oldValue:void 0,arg:r,modifiers:a}))}return e}function _i(e,t,i,n){const s=e.dirs,o=t&&t.dirs;for(let l=0;l<s.length;l++){const r=s[l];o&&(r.oldValue=o[l].value);let a=r.dir[n];a&&(oi(),Ft(a,i,8,[e.el,r,e,t]),ri())}}function Rd(e,t){if(mt){let i=mt.provides;const n=mt.parent&&mt.parent.provides;n===i&&(i=mt.provides=Object.create(n)),i[e]=t}}function Rt(e,t,i=!1){const n=Pu();if(n||nn){let s=nn?nn._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(s&&e in s)return s[e];if(arguments.length>1)return i&&Ae(t)?t.call(n&&n.proxy):t}}const Nd=Symbol.for("v-scx"),zd=()=>Rt(Nd);function ki(e,t,i){return Hl(e,t,i)}function Hl(e,t,i=Ge){const{immediate:n,deep:s,flush:o,once:l}=i,r=dt({},i),a=t&&n||!t&&o!=="post";let c;if(zn){if(o==="sync"){const u=zd();c=u.__watcherHandles||(u.__watcherHandles=[])}else if(!a){const u=()=>{};return u.stop=Zt,u.resume=Zt,u.pause=Zt,u}}const d=mt;r.call=(u,m,h)=>Ft(u,d,m,h);let p=!1;o==="post"?r.scheduler=u=>{St(u,d&&d.suspense)}:o!=="sync"&&(p=!0,r.scheduler=(u,m)=>{m?u():Uo(u)}),r.augmentJob=u=>{t&&(u.flags|=4),p&&(u.flags|=2,d&&(u.id=d.uid,u.i=d))};const g=Dd(e,t,r);return zn&&(c?c.push(g):a&&g()),g}function Fd(e,t,i){const n=this.proxy,s=it(e)?e.includes(".")?jl(n,e):()=>n[e]:e.bind(n,n);let o;Ae(t)?o=t:(o=t.handler,i=t);const l=Un(this),r=Hl(s,o.bind(n),i);return l(),r}function jl(e,t){const i=t.split(".");return()=>{let n=e;for(let s=0;s<i.length&&n;s++)n=n[i[s]];return n}}const Hd=Symbol("_vte"),jd=e=>e.__isTeleport,Js=Symbol("_leaveCb");function Vo(e,t){e.shapeFlag&6&&e.component?(e.transition=t,Vo(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function xt(e,t){return Ae(e)?dt({name:e.name},t,{setup:e}):e}function Wl(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function gr(e,t){let i;return!!((i=Object.getOwnPropertyDescriptor(e,t))&&!i.configurable)}const ks=new WeakMap;function Cn(e,t,i,n,s=!1){if(Ie(e)){e.forEach((h,b)=>Cn(h,t&&(Ie(t)?t[b]:t),i,n,s));return}if(tn(n)&&!s){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&Cn(e,t,i,n.component.subTree);return}const o=n.shapeFlag&4?Fs(n.component):n.el,l=s?null:o,{i:r,r:a}=e,c=t&&t.r,d=r.refs===Ge?r.refs={}:r.refs,p=r.setupState,g=ze(p),u=p===Ge?fl:h=>gr(d,h)?!1:Fe(g,h),m=(h,b)=>!(b&&gr(d,b));if(c!=null&&c!==a){if(vr(t),it(c))d[c]=null,u(c)&&(p[c]=null);else if(Je(c)){const h=t;m(c,h.k)&&(c.value=null),h.k&&(d[h.k]=null)}}if(Ae(a))Wn(a,r,12,[l,d]);else{const h=it(a),b=Je(a);if(h||b){const y=()=>{if(e.f){const x=h?u(a)?p[a]:d[a]:m()||!e.k?a.value:d[e.k];if(s)Ie(x)&&Lo(x,o);else if(Ie(x))x.includes(o)||x.push(o);else if(h)d[a]=[o],u(a)&&(p[a]=d[a]);else{const _=[o];m(a,e.k)&&(a.value=_),e.k&&(d[e.k]=_)}}else h?(d[a]=l,u(a)&&(p[a]=l)):b&&(m(a,e.k)&&(a.value=l),e.k&&(d[e.k]=l))};if(l){const x=()=>{y(),ks.delete(e)};x.id=-1,ks.set(e,x),St(x,i)}else vr(e),y()}}}function vr(e){const t=ks.get(e);t&&(t.flags|=8,ks.delete(e))}Ms().requestIdleCallback;Ms().cancelIdleCallback;const tn=e=>!!e.type.__asyncLoader,Ul=e=>e.type.__isKeepAlive;function Wd(e,t){Vl(e,"a",t)}function Ud(e,t){Vl(e,"da",t)}function Vl(e,t,i=mt){const n=e.__wdc||(e.__wdc=()=>{let s=i;for(;s;){if(s.isDeactivated)return;s=s.parent}return e()});if(Os(t,n,i),i){let s=i.parent;for(;s&&s.parent;)Ul(s.parent.vnode)&&Vd(n,t,i,s),s=s.parent}}function Vd(e,t,i,n){const s=Os(t,e,n,!0);Rs(()=>{Lo(n[t],s)},i)}function Os(e,t,i=mt,n=!1){if(i){const s=i[e]||(i[e]=[]),o=t.__weh||(t.__weh=(...l)=>{oi();const r=Un(i),a=Ft(t,i,e,l);return r(),ri(),a});return n?s.unshift(o):s.push(o),o}}const ci=e=>(t,i=mt)=>{(!zn||e==="sp")&&Os(e,(...n)=>t(...n),i)},Kd=ci("bm"),un=ci("m"),Gd=ci("bu"),qd=ci("u"),Ko=ci("bum"),Rs=ci("um"),Zd=ci("sp"),Yd=ci("rtg"),Jd=ci("rtc");function Xd(e,t=mt){Os("ec",e,t)}const Qd="components";function eu(e,t){return iu(Qd,e,!0,t)||e}const tu=Symbol.for("v-ndc");function iu(e,t,i=!0,n=!1){const s=ct||mt;if(s){const o=s.type;{const r=Fu(o,!1);if(r&&(r===t||r===wt(t)||r===As(wt(t))))return o}const l=br(s[e]||o[e],t)||br(s.appContext[e],t);return!l&&n?o:l}}function br(e,t){return e&&(e[t]||e[wt(t)]||e[As(wt(t))])}function ht(e,t,i,n){let s;const o=i,l=Ie(e);if(l||it(e)){const r=l&&Oi(e);let a=!1,c=!1;r&&(a=!Bt(e),c=li(e),e=Ds(e)),s=new Array(e.length);for(let d=0,p=e.length;d<p;d++)s[d]=t(a?c?on(zt(e[d])):zt(e[d]):e[d],d,void 0,o)}else if(typeof e=="number"){s=new Array(e);for(let r=0;r<e;r++)s[r]=t(r+1,r,void 0,o)}else if(Ve(e))if(e[Symbol.iterator])s=Array.from(e,(r,a)=>t(r,a,void 0,o));else{const r=Object.keys(e);s=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const d=r[a];s[a]=t(e[d],d,a,o)}}else s=[];return s}function Jn(e,t,i={},n,s,o){if(ct.ce||ct.parent&&tn(ct.parent)&&ct.parent.ce){const c=i,d=Object.keys(c).length>0;return t!=="default"&&(c.name=t),J(),Pt(Ue,null,[re("slot",c,n&&n())],d?-2:64)}let l=e[t];l&&l._c&&(l._d=!1);const r=ni.length;J();let a;try{const c=l&&Kl(l(i)),d=i.key||o||c&&c.key;a=Pt(Ue,{key:(d&&!Nt(d)?d:`_${t}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&e._===1?64:-2)}catch(c){for(let d=ni.length;d>r;d--)Zo();throw c}finally{l&&l._c&&(l._d=!0)}return a}function Kl(e){return e.some(t=>Yo(t)?!(t.type===ai||t.type===Ue&&!Kl(t.children)):!0)?e:null}const yo=e=>e?fa(e)?Fs(e):yo(e.parent):null,$n=dt(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>yo(e.parent),$root:e=>yo(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>ql(e),$forceUpdate:e=>e.f||(e.f=()=>{Uo(e.update)}),$nextTick:e=>e.n||(e.n=bs.bind(e.proxy)),$watch:e=>Fd.bind(e)}),Xs=(e,t)=>e!==Ge&&!e.__isScriptSetup&&Fe(e,t),nu={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:i,setupState:n,data:s,props:o,accessCache:l,type:r,appContext:a}=e;if(t[0]!=="$"){const g=l[t];if(g!==void 0)switch(g){case 1:return n[t];case 2:return s[t];case 4:return i[t];case 3:return o[t]}else{if(Xs(n,t))return l[t]=1,n[t];if(s!==Ge&&Fe(s,t))return l[t]=2,s[t];if(Fe(o,t))return l[t]=3,o[t];if(i!==Ge&&Fe(i,t))return l[t]=4,i[t];ko&&(l[t]=0)}}const c=$n[t];let d,p;if(c)return t==="$attrs"&&pt(e.attrs,"get",""),c(e);if((d=r.__cssModules)&&(d=d[t]))return d;if(i!==Ge&&Fe(i,t))return l[t]=4,i[t];if(p=a.config.globalProperties,Fe(p,t))return p[t]},set({_:e},t,i){const{data:n,setupState:s,ctx:o}=e;return Xs(s,t)?(s[t]=i,!0):n!==Ge&&Fe(n,t)?(n[t]=i,!0):Fe(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(o[t]=i,!0)},has({_:{data:e,setupState:t,accessCache:i,ctx:n,appContext:s,props:o,type:l}},r){let a;return!!(i[r]||e!==Ge&&r[0]!=="$"&&Fe(e,r)||Xs(t,r)||Fe(o,r)||Fe(n,r)||Fe($n,r)||Fe(s.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(e,t,i){return i.get!=null?e._.accessCache[t]=0:Fe(i,"value")&&this.set(e,t,i.value,null),Reflect.defineProperty(e,t,i)}};function yr(e){return Ie(e)?e.reduce((t,i)=>(t[i]=null,t),{}):e}let ko=!0;function su(e){const t=ql(e),i=e.proxy,n=e.ctx;ko=!1,t.beforeCreate&&kr(t.beforeCreate,e,"bc");const{data:s,computed:o,methods:l,watch:r,provide:a,inject:c,created:d,beforeMount:p,mounted:g,beforeUpdate:u,updated:m,activated:h,deactivated:b,beforeDestroy:y,beforeUnmount:x,destroyed:_,unmounted:B,render:M,renderTracked:T,renderTriggered:w,errorCaptured:R,serverPrefetch:O,expose:N,inheritAttrs:Z,components:S,directives:z,filters:k}=t;if(c&&ou(c,n,null),l)for(const E in l){const D=l[E];Ae(D)&&(n[E]=D.bind(i))}if(s){const E=s.call(i,i);Ve(E)&&(e.data=Ls(E))}if(ko=!0,o)for(const E in o){const D=o[E],P=Ae(D)?D.bind(i,i):Ae(D.get)?D.get.bind(i,i):Zt,X=!Ae(D)&&Ae(D.set)?D.set.bind(i):Zt,G=we({get:P,set:X});Object.defineProperty(n,E,{enumerable:!0,configurable:!0,get:()=>G.value,set:W=>G.value=W})}if(r)for(const E in r)Gl(r[E],n,i,E);if(a){const E=Ae(a)?a.call(i):a;Reflect.ownKeys(E).forEach(D=>{Rd(D,E[D])})}d&&kr(d,e,"c");function F(E,D){Ie(D)?D.forEach(P=>E(P.bind(i))):D&&E(D.bind(i))}if(F(Kd,p),F(un,g),F(Gd,u),F(qd,m),F(Wd,h),F(Ud,b),F(Xd,R),F(Jd,T),F(Yd,w),F(Ko,x),F(Rs,B),F(Zd,O),Ie(N))if(N.length){const E=e.exposed||(e.exposed={});N.forEach(D=>{Object.defineProperty(E,D,{get:()=>i[D],set:P=>i[D]=P,enumerable:!0})})}else e.exposed||(e.exposed={});M&&e.render===Zt&&(e.render=M),Z!=null&&(e.inheritAttrs=Z),S&&(e.components=S),z&&(e.directives=z),O&&Wl(e)}function ou(e,t,i=Zt){Ie(e)&&(e=wo(e));for(const n in e){const s=e[n];let o;Ve(s)?"default"in s?o=Rt(s.from||n,s.default,!0):o=Rt(s.from||n):o=Rt(s),Je(o)?Object.defineProperty(t,n,{enumerable:!0,configurable:!0,get:()=>o.value,set:l=>o.value=l}):t[n]=o}}function kr(e,t,i){Ft(Ie(e)?e.map(n=>n.bind(t.proxy)):e.bind(t.proxy),t,i)}function Gl(e,t,i,n){let s=n.includes(".")?jl(i,n):()=>i[n];if(it(e)){const o=t[e];Ae(o)&&ki(s,o)}else if(Ae(e))ki(s,e.bind(i));else if(Ve(e))if(Ie(e))e.forEach(o=>Gl(o,t,i,n));else{const o=Ae(e.handler)?e.handler.bind(i):t[e.handler];Ae(o)&&ki(s,o,e)}}function ql(e){const t=e.type,{mixins:i,extends:n}=t,{mixins:s,optionsCache:o,config:{optionMergeStrategies:l}}=e.appContext,r=o.get(t);let a;return r?a=r:!s.length&&!i&&!n?a=t:(a={},s.length&&s.forEach(c=>ws(a,c,l,!0)),ws(a,t,l)),Ve(t)&&o.set(t,a),a}function ws(e,t,i,n=!1){const{mixins:s,extends:o}=t;o&&ws(e,o,i,!0),s&&s.forEach(l=>ws(e,l,i,!0));for(const l in t)if(!(n&&l==="expose")){const r=ru[l]||i&&i[l];e[l]=r?r(e[l],t[l]):t[l]}return e}const ru={data:wr,props:xr,emits:xr,methods:yn,computed:yn,beforeCreate:bt,created:bt,beforeMount:bt,mounted:bt,beforeUpdate:bt,updated:bt,beforeDestroy:bt,beforeUnmount:bt,destroyed:bt,unmounted:bt,activated:bt,deactivated:bt,errorCaptured:bt,serverPrefetch:bt,components:yn,directives:yn,watch:au,provide:wr,inject:lu};function wr(e,t){return t?e?function(){return dt(Ae(e)?e.call(this,this):e,Ae(t)?t.call(this,this):t)}:t:e}function lu(e,t){return yn(wo(e),wo(t))}function wo(e){if(Ie(e)){const t={};for(let i=0;i<e.length;i++)t[e[i]]=e[i];return t}return e}function bt(e,t){return e?[...new Set([].concat(e,t))]:t}function yn(e,t){return e?dt(Object.create(null),e,t):t}function xr(e,t){return e?Ie(e)&&Ie(t)?[...new Set([...e,...t])]:dt(Object.create(null),yr(e),yr(t??{})):t}function au(e,t){if(!e)return t;if(!t)return e;const i=dt(Object.create(null),e);for(const n in t)i[n]=bt(e[n],t[n]);return i}function Zl(){return{app:null,config:{isNativeTag:fl,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let cu=0;function du(e,t){return function(n,s=null){Ae(n)||(n=dt({},n)),s!=null&&!Ve(s)&&(s=null);const o=Zl(),l=new WeakSet,r=[];let a=!1;const c=o.app={_uid:cu++,_component:n,_props:s,_container:null,_context:o,_instance:null,version:ju,get config(){return o.config},set config(d){},use(d,...p){return l.has(d)||(d&&Ae(d.install)?(l.add(d),d.install(c,...p)):Ae(d)&&(l.add(d),d(c,...p))),c},mixin(d){return o.mixins.includes(d)||o.mixins.push(d),c},component(d,p){return p?(o.components[d]=p,c):o.components[d]},directive(d,p){return p?(o.directives[d]=p,c):o.directives[d]},mount(d,p,g){if(!a){const u=c._ceVNode||re(n,s);return u.appContext=o,g===!0?g="svg":g===!1&&(g=void 0),e(u,d,g),a=!0,c._container=d,d.__vue_app__=c,Fs(u.component)}},onUnmount(d){r.push(d)},unmount(){a&&(Ft(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(d,p){return o.provides[d]=p,c},runWithContext(d){const p=nn;nn=c;try{return d()}finally{nn=p}}};return c}}let nn=null;const uu=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${wt(t)}Modifiers`]||e[`${xi(t)}Modifiers`];function fu(e,t,...i){if(e.isUnmounted)return;const n=e.vnode.props||Ge;let s=i;const o=t.startsWith("update:"),l=o&&uu(n,t.slice(7));l&&(l.trim&&(s=i.map(d=>it(d)?d.trim():d)),l.number&&(s=i.map(Bs)));let r,a=n[r=Ks(t)]||n[r=Ks(wt(t))];!a&&o&&(a=n[r=Ks(xi(t))]),a&&Ft(a,e,6,s);const c=n[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,Ft(c,e,6,s)}}const pu=new WeakMap;function Yl(e,t,i=!1){const n=i?pu:t.emitsCache,s=n.get(e);if(s!==void 0)return s;const o=e.emits;let l={},r=!1;if(!Ae(e)){const a=c=>{const d=Yl(c,t,!0);d&&(r=!0,dt(l,d))};!i&&t.mixins.length&&t.mixins.forEach(a),e.extends&&a(e.extends),e.mixins&&e.mixins.forEach(a)}return!o&&!r?(Ve(e)&&n.set(e,null),null):(Ie(o)?o.forEach(a=>l[a]=null):dt(l,o),Ve(e)&&n.set(e,l),l)}function Ns(e,t){return!e||!Is(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),Fe(e,t[0].toLowerCase()+t.slice(1))||Fe(e,xi(t))||Fe(e,t))}function Sr(e){const{type:t,vnode:i,proxy:n,withProxy:s,propsOptions:[o],slots:l,attrs:r,emit:a,render:c,renderCache:d,props:p,data:g,setupState:u,ctx:m,inheritAttrs:h}=e,b=ys(e);let y,x;try{if(i.shapeFlag&4){const B=s||n,M=B;y=Vt(c.call(M,B,d,p,u,g,m)),x=r}else{const B=t;y=Vt(B.length>1?B(p,{attrs:r,slots:l,emit:a}):B(p,null)),x=t.props?r:hu(r)}}catch(B){ni.length=0,Ps(B,e,1),y=re(ai)}let _=y;if(x&&h!==!1){const B=Object.keys(x),{shapeFlag:M}=_;B.length&&M&7&&(o&&B.some(Ts)&&(x=mu(x,o)),_=rn(_,x,!1,!0))}return i.dirs&&(_=rn(_,null,!1,!0),_.dirs=_.dirs?_.dirs.concat(i.dirs):i.dirs),i.transition&&Vo(_,i.transition),y=_,ys(b),y}const hu=e=>{let t;for(const i in e)(i==="class"||i==="style"||Is(i))&&((t||(t={}))[i]=e[i]);return t},mu=(e,t)=>{const i={};for(const n in e)(!Ts(n)||!(n.slice(9)in t))&&(i[n]=e[n]);return i};function gu(e,t,i){const{props:n,children:s,component:o}=e,{props:l,children:r,patchFlag:a}=t,c=o.emitsOptions;if(t.dirs||t.transition)return!0;if(i&&a>=0){if(a&1024)return!0;if(a&16)return n?_r(n,l,c):!!l;if(a&8){const d=t.dynamicProps;for(let p=0;p<d.length;p++){const g=d[p];if(Jl(l,n,g)&&!Ns(c,g))return!0}}}else return(s||r)&&(!r||!r.$stable)?!0:n===l?!1:n?l?_r(n,l,c):!0:!!l;return!1}function _r(e,t,i){const n=Object.keys(t);if(n.length!==Object.keys(e).length)return!0;for(let s=0;s<n.length;s++){const o=n[s];if(Jl(t,e,o)&&!Ns(i,o))return!0}return!1}function Jl(e,t,i){const n=e[i],s=t[i];return i==="style"&&Ve(n)&&Ve(s)?!dn(n,s):n!==s}function vu({vnode:e,parent:t,suspense:i},n){for(;t;){const s=t.subTree;if(s.suspense&&s.suspense.activeBranch===e&&(s.suspense.vnode.el=s.el=n,e=s),s===e)(e=t.vnode).el=n,t=t.parent;else break}i&&i.activeBranch===e&&(i.vnode.el=n)}const Xl={},Ql=()=>Object.create(Xl),ea=e=>Object.getPrototypeOf(e)===Xl;function bu(e,t,i,n=!1){const s={},o=Ql();e.propsDefaults=Object.create(null),ta(e,t,s,o);for(const l in e.propsOptions[0])l in s||(s[l]=void 0);i?e.props=n?s:Cd(s):e.type.props?e.props=s:e.props=o,e.attrs=o}function yu(e,t,i,n){const{props:s,attrs:o,vnode:{patchFlag:l}}=e,r=ze(s),[a]=e.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const d=e.vnode.dynamicProps;for(let p=0;p<d.length;p++){let g=d[p];if(Ns(e.emitsOptions,g))continue;const u=t[g];if(a)if(Fe(o,g))u!==o[g]&&(o[g]=u,c=!0);else{const m=wt(g);s[m]=xo(a,r,m,u,e,!1)}else u!==o[g]&&(o[g]=u,c=!0)}}}else{ta(e,t,s,o)&&(c=!0);let d;for(const p in r)(!t||!Fe(t,p)&&((d=xi(p))===p||!Fe(t,d)))&&(a?i&&(i[p]!==void 0||i[d]!==void 0)&&(s[p]=xo(a,r,p,void 0,e,!0)):delete s[p]);if(o!==r)for(const p in o)(!t||!Fe(t,p))&&(delete o[p],c=!0)}c&&ti(e.attrs,"set","")}function ta(e,t,i,n){const[s,o]=e.propsOptions;let l=!1,r;if(t)for(let a in t){if(xn(a))continue;const c=t[a];let d;s&&Fe(s,d=wt(a))?!o||!o.includes(d)?i[d]=c:(r||(r={}))[d]=c:Ns(e.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(o){const a=ze(i),c=r||Ge;for(let d=0;d<o.length;d++){const p=o[d];i[p]=xo(s,a,p,c[p],e,!Fe(c,p))}}return l}function xo(e,t,i,n,s,o){const l=e[i];if(l!=null){const r=Fe(l,"default");if(r&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&Ae(a)){const{propsDefaults:c}=s;if(i in c)n=c[i];else{const d=Un(s);n=c[i]=a.call(null,t),d()}}else n=a;s.ce&&s.ce._setProp(i,n)}l[0]&&(o&&!r?n=!1:l[1]&&(n===""||n===xi(i))&&(n=!0))}return n}const ku=new WeakMap;function ia(e,t,i=!1){const n=i?ku:t.propsCache,s=n.get(e);if(s)return s;const o=e.props,l={},r=[];let a=!1;if(!Ae(e)){const d=p=>{a=!0;const[g,u]=ia(p,t,!0);dt(l,g),u&&r.push(...u)};!i&&t.mixins.length&&t.mixins.forEach(d),e.extends&&d(e.extends),e.mixins&&e.mixins.forEach(d)}if(!o&&!a)return Ve(e)&&n.set(e,Xi),Xi;if(Ie(o))for(let d=0;d<o.length;d++){const p=wt(o[d]);Cr(p)&&(l[p]=Ge)}else if(o)for(const d in o){const p=wt(d);if(Cr(p)){const g=o[d],u=l[p]=Ie(g)||Ae(g)?{type:g}:dt({},g),m=u.type;let h=!1,b=!0;if(Ie(m))for(let y=0;y<m.length;++y){const x=m[y],_=Ae(x)&&x.name;if(_==="Boolean"){h=!0;break}else _==="String"&&(b=!1)}else h=Ae(m)&&m.name==="Boolean";u[0]=h,u[1]=b,(h||Fe(u,"default"))&&r.push(p)}}const c=[l,r];return Ve(e)&&n.set(e,c),c}function Cr(e){return e[0]!=="$"&&!xn(e)}const Go=e=>e==="_"||e==="_ctx"||e==="$stable",qo=e=>Ie(e)?e.map(Vt):[Vt(e)],wu=(e,t,i)=>{if(t._n)return t;const n=Fl((...s)=>qo(t(...s)),i);return n._c=!1,n},na=(e,t,i)=>{const n=e._ctx;for(const s in e){if(Go(s))continue;const o=e[s];if(Ae(o))t[s]=wu(s,o,n);else if(o!=null){const l=qo(o);t[s]=()=>l}}},sa=(e,t)=>{const i=qo(t);e.slots.default=()=>i},oa=(e,t,i)=>{for(const n in t)(i||!Go(n))&&(e[n]=t[n])},xu=(e,t,i)=>{const n=e.slots=Ql();if(e.vnode.shapeFlag&32){const s=t._;s?(oa(n,t,i),i&&gl(n,"_",s,!0)):na(t,n)}else t&&sa(e,t)},Su=(e,t,i)=>{const{vnode:n,slots:s}=e;let o=!0,l=Ge;if(n.shapeFlag&32){const r=t._;r?i&&r===1?o=!1:oa(s,t,i):(o=!t.$stable,na(t,s)),l=t}else t&&(sa(e,t),l={default:1});if(o)for(const r in s)!Go(r)&&l[r]==null&&delete s[r]},St=Tu;function _u(e){return Cu(e)}function Cu(e,t){const i=Ms();i.__VUE__=!0;const{insert:n,remove:s,patchProp:o,createElement:l,createText:r,createComment:a,setText:c,setElementText:d,parentNode:p,nextSibling:g,setScopeId:u=Zt,insertStaticContent:m}=e,h=(L,j,v,U=null,H=null,$=null,I=void 0,C=null,V=!!j.dynamicChildren)=>{if(L===j)return;L&&!vn(L,j)&&(U=Te(L),W(L,H,$,!0),L=null),j.patchFlag===-2&&(V=!1,j.dynamicChildren=null);const{type:q,ref:K,shapeFlag:ee}=j;switch(q){case zs:b(L,j,v,U);break;case ai:y(L,j,v,U);break;case ns:L==null&&x(j,v,U,I);break;case Ue:S(L,j,v,U,H,$,I,C,V);break;default:ee&1?M(L,j,v,U,H,$,I,C,V):ee&6?z(L,j,v,U,H,$,I,C,V):(ee&64||ee&128)&&q.process(L,j,v,U,H,$,I,C,V,Y)}K!=null&&H?Cn(K,L&&L.ref,$,j||L,!j):K==null&&L&&L.ref!=null&&Cn(L.ref,null,$,L,!0)},b=(L,j,v,U)=>{if(L==null)n(j.el=r(j.children),v,U);else{const H=j.el=L.el;j.children!==L.children&&c(H,j.children)}},y=(L,j,v,U)=>{L==null?n(j.el=a(j.children||""),v,U):j.el=L.el},x=(L,j,v,U)=>{[L.el,L.anchor]=m(L.children,j,v,U,L.el,L.anchor)},_=({el:L,anchor:j},v,U)=>{let H;for(;L&&L!==j;)H=g(L),n(L,v,U),L=H;n(j,v,U)},B=({el:L,anchor:j})=>{let v;for(;L&&L!==j;)v=g(L),s(L),L=v;s(j)},M=(L,j,v,U,H,$,I,C,V)=>{if(j.type==="svg"?I="svg":j.type==="math"&&(I="mathml"),L==null)T(j,v,U,H,$,I,C,V);else{const q=L.el&&L.el._isVueCE?L.el:null;try{q&&q._beginPatch(),O(L,j,H,$,I,C,V)}finally{q&&q._endPatch()}}},T=(L,j,v,U,H,$,I,C)=>{let V,q;const{props:K,shapeFlag:ee,transition:le,dirs:oe}=L;if(V=L.el=l(L.type,$,K&&K.is,K),ee&8?d(V,L.children):ee&16&&R(L.children,V,null,U,H,Qs(L,$),I,C),oe&&_i(L,null,U,"created"),w(V,L,L.scopeId,I,U),K){for(const ie in K)ie!=="value"&&!xn(ie)&&o(V,ie,null,K[ie],$,U);"value"in K&&o(V,"value",null,K.value,$),(q=K.onVnodeBeforeMount)&&jt(q,U,L)}oe&&_i(L,null,U,"beforeMount");const he=$u(H,le);he&&le.beforeEnter(V),n(V,j,v),((q=K&&K.onVnodeMounted)||he||oe)&&St(()=>{try{q&&jt(q,U,L),he&&le.enter(V),oe&&_i(L,null,U,"mounted")}finally{}},H)},w=(L,j,v,U,H)=>{if(v&&u(L,v),U)for(let $=0;$<U.length;$++)u(L,U[$]);if(H){let $=H.subTree;if(j===$||ca($.type)&&($.ssContent===j||$.ssFallback===j)){const I=H.vnode;w(L,I,I.scopeId,I.slotScopeIds,H.parent)}}},R=(L,j,v,U,H,$,I,C,V=0)=>{for(let q=V;q<L.length;q++){const K=L[q]=C?ei(L[q]):Vt(L[q]);h(null,K,j,v,U,H,$,I,C)}},O=(L,j,v,U,H,$,I)=>{const C=j.el=L.el;let{patchFlag:V,dynamicChildren:q,dirs:K}=j;V|=L.patchFlag&16;const ee=L.props||Ge,le=j.props||Ge;let oe;if(v&&Ci(v,!1),(oe=le.onVnodeBeforeUpdate)&&jt(oe,v,j,L),K&&_i(j,L,v,"beforeUpdate"),v&&Ci(v,!0),q&&(!L.dynamicChildren||L.dynamicChildren.length!==q.length)&&(V=0,I=!1,q=null),(ee.innerHTML&&le.innerHTML==null||ee.textContent&&le.textContent==null)&&d(C,""),q?N(L.dynamicChildren,q,C,v,U,Qs(j,H),$):I||D(L,j,C,null,v,U,Qs(j,H),$,!1),V>0){if(V&16)Z(C,ee,le,v,H);else if(V&2&&ee.class!==le.class&&o(C,"class",null,le.class,H),V&4&&o(C,"style",ee.style,le.style,H),V&8){const he=j.dynamicProps;for(let ie=0;ie<he.length;ie++){const ne=he[ie],Ce=ee[ne],Be=le[ne];(Be!==Ce||ne==="value")&&o(C,ne,Ce,Be,H,v)}}V&1&&L.children!==j.children&&d(C,j.children)}else!I&&q==null&&Z(C,ee,le,v,H);((oe=le.onVnodeUpdated)||K)&&St(()=>{oe&&jt(oe,v,j,L),K&&_i(j,L,v,"updated")},U)},N=(L,j,v,U,H,$,I)=>{for(let C=0;C<j.length;C++){const V=L[C],q=j[C],K=V.el&&(V.type===Ue||!vn(V,q)||V.shapeFlag&198)?p(V.el):v;h(V,q,K,null,U,H,$,I,!0)}},Z=(L,j,v,U,H)=>{if(j!==v){if(j!==Ge)for(const $ in j)!xn($)&&!($ in v)&&o(L,$,j[$],null,H,U);for(const $ in v){if(xn($))continue;const I=v[$],C=j[$];I!==C&&$!=="value"&&o(L,$,C,I,H,U)}"value"in v&&o(L,"value",j.value,v.value,H)}},S=(L,j,v,U,H,$,I,C,V)=>{const q=j.el=L?L.el:r(""),K=j.anchor=L?L.anchor:r("");let{patchFlag:ee,dynamicChildren:le,slotScopeIds:oe}=j;oe&&(C=C?C.concat(oe):oe),L==null?(n(q,v,U),n(K,v,U),R(j.children||[],v,K,H,$,I,C,V)):ee>0&&ee&64&&le&&L.dynamicChildren&&L.dynamicChildren.length===le.length?(N(L.dynamicChildren,le,v,H,$,I,C),(j.key!=null||H&&j===H.subTree)&&ra(L,j,!0)):D(L,j,v,K,H,$,I,C,V)},z=(L,j,v,U,H,$,I,C,V)=>{j.slotScopeIds=C,L==null?j.shapeFlag&512?H.ctx.activate(j,v,U,I,V):k(j,v,U,H,$,I,V):A(L,j,V)},k=(L,j,v,U,H,$,I)=>{const C=L.component=Lu(L,U,H);if(Ul(L)&&(C.ctx.renderer=Y),Ou(C,!1,I),C.asyncDep){if(H&&H.registerDep(C,F,I),!L.el){const V=C.subTree=re(ai);y(null,V,j,v),L.placeholder=V.el}}else F(C,L,j,v,H,$,I)},A=(L,j,v)=>{const U=j.component=L.component;if(gu(L,j,v))if(U.asyncDep&&!U.asyncResolved){E(U,j,v);return}else U.next=j,U.update();else j.el=L.el,U.vnode=j},F=(L,j,v,U,H,$,I)=>{const C=()=>{if(L.isMounted){let{next:ee,bu:le,u:oe,parent:he,vnode:ie}=L;{const Re=la(L);if(Re){ee&&(ee.el=ie.el,E(L,ee,I)),Re.asyncDep.then(()=>{St(()=>{L.isUnmounted||q()},H)});return}}let ne=ee,Ce;Ci(L,!1),ee?(ee.el=ie.el,E(L,ee,I)):ee=ie,le&&is(le),(Ce=ee.props&&ee.props.onVnodeBeforeUpdate)&&jt(Ce,he,ee,ie),Ci(L,!0);const Be=Sr(L),Ne=L.subTree;L.subTree=Be,h(Ne,Be,p(Ne.el),Te(Ne),L,H,$),ee.el=Be.el,ne===null&&vu(L,Be.el),oe&&St(oe,H),(Ce=ee.props&&ee.props.onVnodeUpdated)&&St(()=>jt(Ce,he,ee,ie),H)}else{let ee;const{el:le,props:oe}=j,{bm:he,m:ie,parent:ne,root:Ce,type:Be}=L,Ne=tn(j);Ci(L,!1),he&&is(he),!Ne&&(ee=oe&&oe.onVnodeBeforeMount)&&jt(ee,ne,j),Ci(L,!0);{Ce.ce&&Ce.ce._hasShadowRoot()&&Ce.ce._injectChildStyle(Be,L.parent?L.parent.type:void 0);const Re=L.subTree=Sr(L);h(null,Re,v,U,L,H,$),j.el=Re.el}if(ie&&St(ie,H),!Ne&&(ee=oe&&oe.onVnodeMounted)){const Re=j;St(()=>jt(ee,ne,Re),H)}(j.shapeFlag&256||ne&&tn(ne.vnode)&&ne.vnode.shapeFlag&256)&&L.a&&St(L.a,H),L.isMounted=!0,j=v=U=null}};L.scope.on();const V=L.effect=new kl(C);L.scope.off();const q=L.update=V.run.bind(V),K=L.job=V.runIfDirty.bind(V);K.i=L,K.id=L.uid,V.scheduler=()=>Uo(K),Ci(L,!0),q()},E=(L,j,v)=>{j.component=L;const U=L.vnode.props;L.vnode=j,L.next=null,yu(L,j.props,U,v),Su(L,j.children,v),oi(),mr(L),ri()},D=(L,j,v,U,H,$,I,C,V=!1)=>{const q=L&&L.children,K=L?L.shapeFlag:0,ee=j.children,{patchFlag:le,shapeFlag:oe}=j;if(le>0){if(le&128){X(q,ee,v,U,H,$,I,C,V);return}else if(le&256){P(q,ee,v,U,H,$,I,C,V);return}}oe&8?(K&16&&ve(q,H,$),ee!==q&&d(v,ee)):K&16?oe&16?X(q,ee,v,U,H,$,I,C,V):ve(q,H,$,!0):(K&8&&d(v,""),oe&16&&R(ee,v,U,H,$,I,C,V))},P=(L,j,v,U,H,$,I,C,V)=>{L=L||Xi,j=j||Xi;const q=L.length,K=j.length,ee=Math.min(q,K);let le;for(le=0;le<ee;le++){const oe=j[le]=V?ei(j[le]):Vt(j[le]);h(L[le],oe,v,null,H,$,I,C,V)}q>K?ve(L,H,$,!0,!1,ee):R(j,v,U,H,$,I,C,V,ee)},X=(L,j,v,U,H,$,I,C,V)=>{let q=0;const K=j.length;let ee=L.length-1,le=K-1;for(;q<=ee&&q<=le;){const oe=L[q],he=j[q]=V?ei(j[q]):Vt(j[q]);if(vn(oe,he))h(oe,he,v,null,H,$,I,C,V);else break;q++}for(;q<=ee&&q<=le;){const oe=L[ee],he=j[le]=V?ei(j[le]):Vt(j[le]);if(vn(oe,he))h(oe,he,v,null,H,$,I,C,V);else break;ee--,le--}if(q>ee){if(q<=le){const oe=le+1,he=oe<K?j[oe].el:U;for(;q<=le;)h(null,j[q]=V?ei(j[q]):Vt(j[q]),v,he,H,$,I,C,V),q++}}else if(q>le)for(;q<=ee;)W(L[q],H,$,!0),q++;else{const oe=q,he=q,ie=new Map;for(q=he;q<=le;q++){const rt=j[q]=V?ei(j[q]):Vt(j[q]);rt.key!=null&&ie.set(rt.key,q)}let ne,Ce=0;const Be=le-he+1;let Ne=!1,Re=0;const Le=new Array(Be);for(q=0;q<Be;q++)Le[q]=0;for(q=oe;q<=ee;q++){const rt=L[q];if(Ce>=Be){W(rt,H,$,!0);continue}let Xe;if(rt.key!=null)Xe=ie.get(rt.key);else for(ne=he;ne<=le;ne++)if(Le[ne-he]===0&&vn(rt,j[ne])){Xe=ne;break}Xe===void 0?W(rt,H,$,!0):(Le[Xe-he]=q+1,Xe>=Re?Re=Xe:Ne=!0,h(rt,j[Xe],v,null,H,$,I,C,V),Ce++)}const Jt=Ne?Iu(Le):Xi;for(ne=Jt.length-1,q=Be-1;q>=0;q--){const rt=he+q,Xe=j[rt],Ht=j[rt+1],Fi=rt+1<K?Ht.el||aa(Ht):U;Le[q]===0?h(null,Xe,v,Fi,H,$,I,C,V):Ne&&(ne<0||q!==Jt[ne]?G(Xe,v,Fi,2):ne--)}}},G=(L,j,v,U,H=null)=>{const{el:$,type:I,transition:C,children:V,shapeFlag:q}=L;if(q&6){G(L.component.subTree,j,v,U);return}if(q&128){L.suspense.move(j,v,U);return}if(q&64){I.move(L,j,v,Y);return}if(I===Ue){n($,j,v);for(let ee=0;ee<V.length;ee++)G(V[ee],j,v,U);n(L.anchor,j,v);return}if(I===ns){_(L,j,v);return}if(U!==2&&q&1&&C)if(U===0)C.persisted&&!$[Js]?n($,j,v):(C.beforeEnter($),n($,j,v),St(()=>C.enter($),H));else{const{leave:ee,delayLeave:le,afterLeave:oe}=C,he=()=>{L.ctx.isUnmounted?s($):n($,j,v)},ie=()=>{const ne=$._isLeaving||!!$[Js];$._isLeaving&&$[Js](!0),C.persisted&&!ne?he():ee($,()=>{he(),oe&&oe()})};le?le($,he,ie):ie()}else n($,j,v)},W=(L,j,v,U=!1,H=!1)=>{const{type:$,props:I,ref:C,children:V,dynamicChildren:q,shapeFlag:K,patchFlag:ee,dirs:le,cacheIndex:oe,memo:he}=L;if(ee===-2&&(H=!1),C!=null&&(oi(),Cn(C,null,v,L,!0),ri()),oe!=null&&(j.renderCache[oe]=void 0),K&256){j.ctx.deactivate(L);return}const ie=K&1&&le,ne=!tn(L);let Ce;if(ne&&(Ce=I&&I.onVnodeBeforeUnmount)&&jt(Ce,j,L),K&6)ce(L.component,v,U);else{if(K&128){L.suspense.unmount(v,U);return}ie&&_i(L,null,j,"beforeUnmount"),K&64?L.type.remove(L,j,v,Y,U):q&&!q.hasOnce&&($!==Ue||ee>0&&ee&64)?ve(q,j,v,!1,!0):($===Ue&&ee&384||!H&&K&16)&&ve(V,j,v),U&&se(L)}const Be=he!=null&&oe==null;(ne&&(Ce=I&&I.onVnodeUnmounted)||ie||Be)&&St(()=>{Ce&&jt(Ce,j,L),ie&&_i(L,null,j,"unmounted"),Be&&(L.el=null)},v)},se=L=>{const{type:j,el:v,anchor:U,transition:H}=L;if(j===Ue){ae(v,U);return}if(j===ns){B(L);return}const $=()=>{s(v),H&&!H.persisted&&H.afterLeave&&H.afterLeave()};if(L.shapeFlag&1&&H&&!H.persisted){const{leave:I,delayLeave:C}=H,V=()=>I(v,$);C?C(L.el,$,V):V()}else $()},ae=(L,j)=>{let v;for(;L!==j;)v=g(L),s(L),L=v;s(j)},ce=(L,j,v)=>{const{bum:U,scope:H,job:$,subTree:I,um:C,m:V,a:q}=L;$r(V),$r(q),U&&is(U),H.stop(),$&&($.flags|=8,W(I,L,j,v)),C&&St(C,j),St(()=>{L.isUnmounted=!0},j)},ve=(L,j,v,U=!1,H=!1,$=0)=>{for(let I=$;I<L.length;I++)W(L[I],j,v,U,H)},Te=L=>{if(L.shapeFlag&6)return Te(L.component.subTree);if(L.shapeFlag&128)return L.suspense.next();const j=g(L.anchor||L.el),v=j&&j[Hd];return v?g(v):j};let xe=!1;const ue=(L,j,v)=>{let U;L==null?j._vnode&&(W(j._vnode,null,null,!0),U=j._vnode.component):h(j._vnode||null,L,j,null,null,null,v),j._vnode=L,xe||(xe=!0,mr(U),Rl(),xe=!1)},Y={p:h,um:W,m:G,r:se,mt:k,mc:R,pc:D,pbc:N,n:Te,o:e};return{render:ue,hydrate:void 0,createApp:du(ue)}}function Qs({type:e,props:t},i){return i==="svg"&&e==="foreignObject"||i==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:i}function Ci({effect:e,job:t},i){i?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function $u(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function ra(e,t,i=!1){const n=e.children,s=t.children;if(Ie(n)&&Ie(s))for(let o=0;o<n.length;o++){const l=n[o];let r=s[o];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=s[o]=ei(s[o]),r.el=l.el),!i&&r.patchFlag!==-2&&ra(l,r)),r.type===zs&&(r.patchFlag===-1&&(r=s[o]=ei(r)),r.el=l.el),r.type===ai&&!r.el&&(r.el=l.el)}}function Iu(e){const t=e.slice(),i=[0];let n,s,o,l,r;const a=e.length;for(n=0;n<a;n++){const c=e[n];if(c!==0){if(s=i[i.length-1],e[s]<c){t[n]=s,i.push(n);continue}for(o=0,l=i.length-1;o<l;)r=o+l>>1,e[i[r]]<c?o=r+1:l=r;c<e[i[o]]&&(o>0&&(t[n]=i[o-1]),i[o]=n)}}for(o=i.length,l=i[o-1];o-- >0;)i[o]=l,l=t[l];return i}function la(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:la(t)}function $r(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function aa(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?aa(t.subTree):null}const ca=e=>e.__isSuspense;function Tu(e,t){t&&t.pendingBranch?Ie(e)?t.effects.push(...e):t.effects.push(e):Od(e)}const Ue=Symbol.for("v-fgt"),zs=Symbol.for("v-txt"),ai=Symbol.for("v-cmt"),ns=Symbol.for("v-stc"),ni=[];let It=null;function J(e=!1){ni.push(It=e?null:[])}function Zo(){ni.pop(),It=ni[ni.length-1]||null}let Nn=1;function Ir(e,t=!1){Nn+=e,e<0&&It&&t&&(It.hasOnce=!0)}function da(e){return e.dynamicChildren=Nn>0?It||Xi:null,Zo(),Nn>0&&It&&It.push(e),e}function te(e,t,i,n,s,o){return da(f(e,t,i,n,s,o,!0))}function Pt(e,t,i,n,s){return da(re(e,t,i,n,s,!0))}function Yo(e){return e?e.__v_isVNode===!0:!1}function vn(e,t){return e.type===t.type&&e.key===t.key}const ua=({key:e})=>e??null,ss=({ref:e,ref_key:t,ref_for:i})=>(typeof e=="number"&&(e=""+e),e!=null?it(e)||Je(e)||Ae(e)?{i:ct,r:e,k:t,f:!!i}:e:null);function f(e,t=null,i=null,n=0,s=null,o=e===Ue?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&ua(t),ref:t&&ss(t),scopeId:zl,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:o,patchFlag:n,dynamicProps:s,dynamicChildren:null,appContext:null,ctx:ct};return r?(xs(a,i),o&128&&e.normalize(a)):i&&(a.shapeFlag|=it(i)?8:16),Nn>0&&!l&&It&&(a.patchFlag>0||o&6)&&a.patchFlag!==32&&It.push(a),a}const re=Eu;function Eu(e,t=null,i=null,n=0,s=null,o=!1){if((!e||e===tu)&&(e=ai),Yo(e)){const r=rn(e,t,!0);return i&&xs(r,i),Nn>0&&!o&&It&&(r.shapeFlag&6?It[It.indexOf(e)]=r:It.push(r)),r.patchFlag=-2,r}if(Hu(e)&&(e=e.__vccOpts),t){t=Au(t);let{class:r,style:a}=t;r&&!it(r)&&(t.class=_e(r)),Ve(a)&&(Wo(a)&&!Ie(a)&&(a=dt({},a)),t.style=Gt(a))}const l=it(e)?1:ca(e)?128:jd(e)?64:Ve(e)?4:Ae(e)?2:0;return f(e,t,i,n,s,l,o,!0)}function Au(e){return e?Wo(e)||ea(e)?dt({},e):e:null}function rn(e,t,i=!1,n=!1){const{props:s,ref:o,patchFlag:l,children:r,transition:a}=e,c=t?Bu(s||{},t):s,d={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&ua(c),ref:t&&t.ref?i&&o?Ie(o)?o.concat(ss(t)):[o,ss(t)]:ss(t):o,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Ue?l===-1?16:l|16:l,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:a,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&rn(e.ssContent),ssFallback:e.ssFallback&&rn(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return a&&n&&Vo(d,a.clone(d)),d}function _t(e=" ",t=0){return re(zs,null,e,t)}function vt(e,t){const i=re(ns,null,e);return i.staticCount=t,i}function De(e="",t=!1){return t?(J(),Pt(ai,null,e)):re(ai,null,e)}function Vt(e){return e==null||typeof e=="boolean"?re(ai):Ie(e)?re(Ue,null,e.slice()):Yo(e)?ei(e):re(zs,null,String(e))}function ei(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:rn(e)}function xs(e,t){let i=0;const{shapeFlag:n}=e;if(t==null)t=null;else if(Ie(t))i=16;else if(typeof t=="object")if(n&65){const s=t.default;s&&(s._c&&(s._d=!1),xs(e,s()),s._c&&(s._d=!0));return}else{i=32;const s=t._;!s&&!ea(t)?t._ctx=ct:s===3&&ct&&(ct.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(Ae(t)){if(n&65){xs(e,{default:t});return}t={default:t,_ctx:ct},i=32}else t=String(t),n&64?(i=16,t=[_t(t)]):i=8;e.children=t,e.shapeFlag|=i}function Bu(...e){const t={};for(let i=0;i<e.length;i++){const n=e[i];for(const s in n)if(s==="class")t.class!==n.class&&(t.class=_e([t.class,n.class]));else if(s==="style")t.style=Gt([t.style,n.style]);else if(Is(s)){const o=t[s],l=n[s];l&&o!==l&&!(Ie(o)&&o.includes(l))?t[s]=o?[].concat(o,l):l:l==null&&o==null&&!Ts(s)&&(t[s]=l)}else s!==""&&(t[s]=n[s])}return t}function jt(e,t,i,n=null){Ft(e,t,7,[i,n])}const Mu=Zl();let Du=0;function Lu(e,t,i){const n=e.type,s=(t?t.appContext:e.appContext)||Mu,o={uid:Du++,vnode:e,type:n,parent:t,appContext:s,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new rd(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(s.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:ia(n,s),emitsOptions:Yl(n,s),emit:null,emitted:null,propsDefaults:Ge,inheritAttrs:n.inheritAttrs,ctx:Ge,data:Ge,props:Ge,attrs:Ge,slots:Ge,refs:Ge,setupState:Ge,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return o.ctx={_:o},o.root=t?t.root:o,o.emit=fu.bind(null,o),e.ce&&e.ce(o),o}let mt=null;const Pu=()=>mt||ct;let Ss,So;{const e=Ms(),t=(i,n)=>{let s;return(s=e[i])||(s=e[i]=[]),s.push(n),o=>{s.length>1?s.forEach(l=>l(o)):s[0](o)}};Ss=t("__VUE_INSTANCE_SETTERS__",i=>mt=i),So=t("__VUE_SSR_SETTERS__",i=>zn=i)}const Un=e=>{const t=mt;return Ss(e),e.scope.on(),()=>{e.scope.off(),Ss(t)}},Tr=()=>{mt&&mt.scope.off(),Ss(null)};function fa(e){return e.vnode.shapeFlag&4}let zn=!1;function Ou(e,t=!1,i=!1){t&&So(t);const{props:n,children:s}=e.vnode,o=fa(e);bu(e,n,o,t),xu(e,s,i||t);const l=o?Ru(e,t):void 0;return t&&So(!1),l}function Ru(e,t){const i=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,nu);const{setup:n}=i;if(n){oi();const s=e.setupContext=n.length>1?zu(e):null,o=Un(e),l=Wn(n,e,0,[e.props,s]),r=pl(l);if(ri(),o(),(r||e.sp)&&!tn(e)&&Wl(e),r){if(l.then(Tr,Tr),t)return l.then(a=>{Er(e,a)}).catch(a=>{Ps(a,e,0)});e.asyncDep=l}else Er(e,l)}else pa(e)}function Er(e,t,i){Ae(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:Ve(t)&&(e.setupState=Ll(t)),pa(e)}function pa(e,t,i){const n=e.type;e.render||(e.render=n.render||Zt);{const s=Un(e);oi();try{su(e)}finally{ri(),s()}}}const Nu={get(e,t){return pt(e,"get",""),e[t]}};function zu(e){const t=i=>{e.exposed=i||{}};return{attrs:new Proxy(e.attrs,Nu),slots:e.slots,emit:e.emit,expose:t}}function Fs(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(Ll($d(e.exposed)),{get(t,i){if(i in t)return t[i];if(i in $n)return $n[i](e)},has(t,i){return i in t||i in $n}})):e.proxy}function Fu(e,t=!0){return Ae(e)?e.displayName||e.name:e.name||t&&e.__name}function Hu(e){return Ae(e)&&"__vccOpts"in e}const we=(e,t)=>Bd(e,t,zn),ju="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let _o;const Ar=typeof window<"u"&&window.trustedTypes;if(Ar)try{_o=Ar.createPolicy("vue",{createHTML:e=>e})}catch{}const ha=_o?e=>_o.createHTML(e):e=>e,Wu="http://www.w3.org/2000/svg",Uu="http://www.w3.org/1998/Math/MathML",Qt=typeof document<"u"?document:null,Br=Qt&&Qt.createElement("template"),Vu={insert:(e,t,i)=>{t.insertBefore(e,i||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,i,n)=>{const s=t==="svg"?Qt.createElementNS(Wu,e):t==="mathml"?Qt.createElementNS(Uu,e):i?Qt.createElement(e,{is:i}):Qt.createElement(e);return e==="select"&&n&&n.multiple!=null&&s.setAttribute("multiple",n.multiple),s},createText:e=>Qt.createTextNode(e),createComment:e=>Qt.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>Qt.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,i,n,s,o){const l=i?i.previousSibling:t.lastChild;if(s&&(s===o||s.nextSibling))for(;t.insertBefore(s.cloneNode(!0),i),!(s===o||!(s=s.nextSibling)););else{Br.innerHTML=ha(n==="svg"?`<svg>${e}</svg>`:n==="mathml"?`<math>${e}</math>`:e);const r=Br.content;if(n==="svg"||n==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}t.insertBefore(r,i)}return[l?l.nextSibling:t.firstChild,i?i.previousSibling:t.lastChild]}},Ku=Symbol("_vtc");function Gu(e,t,i){const n=e[Ku];n&&(t=(t?[t,...n]:[...n]).join(" ")),t==null?e.removeAttribute("class"):i?e.setAttribute("class",t):e.className=t}const _s=Symbol("_vod"),ma=Symbol("_vsh"),Co={name:"show",beforeMount(e,{value:t},{transition:i}){e[_s]=e.style.display==="none"?"":e.style.display,i&&t?i.beforeEnter(e):bn(e,t)},mounted(e,{value:t},{transition:i}){i&&t&&i.enter(e)},updated(e,{value:t,oldValue:i},{transition:n}){!t!=!i&&(n?t?(n.beforeEnter(e),bn(e,!0),n.enter(e)):n.leave(e,()=>{bn(e,!1)}):bn(e,t))},beforeUnmount(e,{value:t}){bn(e,t)}};function bn(e,t){e.style.display=t?e[_s]:"none",e[ma]=!t}const qu=Symbol(""),Zu=/(?:^|;)\s*display\s*:/;function Yu(e,t,i){const n=e.style,s=it(i);let o=!1;if(i&&!s){if(t)if(it(t))for(const l of t.split(";")){const r=l.slice(0,l.indexOf(":")).trim();i[r]==null&&kn(n,r,"")}else for(const l in t)i[l]==null&&kn(n,l,"");for(const l in i){l==="display"&&(o=!0);const r=i[l];r!=null?Xu(e,l,!it(t)&&t?t[l]:void 0,r)||kn(n,l,r):kn(n,l,"")}}else if(s){if(t!==i){const l=n[qu];l&&(i+=";"+l),n.cssText=i,o=Zu.test(i)}}else t&&e.removeAttribute("style");_s in e&&(e[_s]=o?n.display:"",e[ma]&&(n.display="none"))}const Mr=/\s*!important$/;function kn(e,t,i){if(Ie(i))i.forEach(n=>kn(e,t,n));else if(i==null&&(i=""),t.startsWith("--"))e.setProperty(t,i);else{const n=Ju(e,t);Mr.test(i)?e.setProperty(xi(n),i.replace(Mr,""),"important"):e[n]=i}}const Dr=["Webkit","Moz","ms"],eo={};function Ju(e,t){const i=eo[t];if(i)return i;let n=wt(t);if(n!=="filter"&&n in e)return eo[t]=n;n=As(n);for(let s=0;s<Dr.length;s++){const o=Dr[s]+n;if(o in e)return eo[t]=o}return t}function Xu(e,t,i,n){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&it(n)&&i===n}const Lr="http://www.w3.org/1999/xlink";function Pr(e,t,i,n,s,o=sd(t)){n&&t.startsWith("xlink:")?i==null?e.removeAttributeNS(Lr,t.slice(6,t.length)):e.setAttributeNS(Lr,t,i):i==null||o&&!vl(i)?e.removeAttribute(t):e.setAttribute(t,o?"":Nt(i)?String(i):i)}function Or(e,t,i,n,s){if(t==="innerHTML"||t==="textContent"){i!=null&&(e[t]=t==="innerHTML"?ha(i):i);return}const o=e.tagName;if(t==="value"&&o!=="PROGRESS"&&!o.includes("-")){const r=o==="OPTION"?e.getAttribute("value")||"":e.value,a=i==null?e.type==="checkbox"?"on":"":String(i);(r!==a||!("_value"in e))&&(e.value=a),i==null&&e.removeAttribute(t),e._value=i;return}let l=!1;if(i===""||i==null){const r=typeof e[t];r==="boolean"?i=vl(i):i==null&&r==="string"?(i="",l=!0):r==="number"&&(i=0,l=!0)}try{e[t]=i}catch{}l&&e.removeAttribute(s||t)}function mi(e,t,i,n){e.addEventListener(t,i,n)}function Qu(e,t,i,n){e.removeEventListener(t,i,n)}const Rr=Symbol("_vei");function ef(e,t,i,n,s=null){const o=e[Rr]||(e[Rr]={}),l=o[t];if(n&&l)l.value=n;else{const[r,a]=sf(t);if(n){const c=o[t]=lf(n,s);mi(e,r,c,a)}else l&&(Qu(e,r,l,a),o[t]=void 0)}}const tf=/(Once|Passive|Capture)$/,nf=/^on:?(?:Once|Passive|Capture)$/;function sf(e){let t,i;for(;(i=e.match(tf))&&!nf.test(e);)t||(t={}),e=e.slice(0,e.length-i[1].length),t[i[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):xi(e.slice(2)),t]}let to=0;const of=Promise.resolve(),rf=()=>to||(of.then(()=>to=0),to=Date.now());function lf(e,t){const i=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=i.attached)return;const s=i.value;if(Ie(s)){const o=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{o.call(n),n._stopped=!0};const l=s.slice(),r=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Ft(c,t,5,r)}}else Ft(s,t,5,[n])};return i.value=e,i.attached=rf(),i}const Nr=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,af=(e,t,i,n,s,o)=>{const l=s==="svg";t==="class"?Gu(e,n,l):t==="style"?Yu(e,i,n):Is(t)?Ts(t)||ef(e,t,i,n,o):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):cf(e,t,n,l))?(Or(e,t,n),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&Pr(e,t,n,l,o,t!=="value")):e._isVueCE&&(df(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!it(n)))?Or(e,wt(t),n,o,t):(t==="true-value"?e._trueValue=n:t==="false-value"&&(e._falseValue=n),Pr(e,t,n,l))};function cf(e,t,i,n){if(n)return!!(t==="innerHTML"||t==="textContent"||t in e&&Nr(t)&&Ae(i));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const s=e.tagName;if(s==="IMG"||s==="VIDEO"||s==="CANVAS"||s==="SOURCE")return!1}return Nr(t)&&it(i)?!1:t in e}function df(e,t){const i=e._def.props;if(!i)return!1;const n=wt(t);return Array.isArray(i)?i.some(s=>wt(s)===n):Object.keys(i).some(s=>wt(s)===n)}const ln=e=>{const t=e.props["onUpdate:modelValue"]||!1;return Ie(t)?i=>is(t,i):t};function uf(e){e.target.composing=!0}function zr(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const si=Symbol("_assign");function Fr(e,t,i){return t&&(e=e.trim()),i&&(e=Bs(e)),e}const Cs={created(e,{modifiers:{lazy:t,trim:i,number:n}},s){e[si]=ln(s);const o=n||s.props&&s.props.type==="number";mi(e,t?"change":"input",l=>{l.target.composing||e[si](Fr(e.value,i,o))}),(i||o)&&mi(e,"change",()=>{e.value=Fr(e.value,i,o)}),t||(mi(e,"compositionstart",uf),mi(e,"compositionend",zr),mi(e,"change",zr))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:i,modifiers:{lazy:n,trim:s,number:o}},l){if(e[si]=ln(l),e.composing)return;const r=(o||e.type==="number")&&!/^0\d/.test(e.value)?Bs(e.value):e.value,a=t??"";if(r===a)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(n&&t===i||s&&e.value.trim()===a)||(e.value=a)}},Xn={deep:!0,created(e,t,i){e[si]=ln(i),mi(e,"change",()=>{const n=e._modelValue,s=Fn(e),o=e.checked,l=e[si];if(Ie(n)){const r=Oo(n,s),a=r!==-1;if(o&&!a)l(n.concat(s));else if(!o&&a){const c=[...n];c.splice(r,1),l(c)}}else if(cn(n)){const r=new Set(n);o?r.add(s):r.delete(s),l(r)}else l(ga(e,o))})},mounted:Hr,beforeUpdate(e,t,i){e[si]=ln(i),Hr(e,t,i)}};function Hr(e,{value:t,oldValue:i},n){e._modelValue=t;let s;if(Ie(t))s=Oo(t,n.props.value)>-1;else if(cn(t))s=t.has(n.props.value);else{if(t===i)return;s=dn(t,ga(e,!0))}e.checked!==s&&(e.checked=s)}const ff={deep:!0,created(e,{value:t,modifiers:{number:i}},n){e._modelValue=t,mi(e,"change",()=>{const s=Array.prototype.filter.call(e.options,o=>o.selected).map(o=>i?Bs(Fn(o)):Fn(o));e[si](e.multiple?cn(e._modelValue)?new Set(s):s:s[0]),e._assigning=!0,bs(()=>{e._assigning=!1})}),e[si]=ln(n)},mounted(e,{value:t}){jr(e,t)},beforeUpdate(e,{value:t},i){e._modelValue=t,e[si]=ln(i)},updated(e,{value:t}){e._assigning||jr(e,t)}};function jr(e,t){const i=e.multiple,n=Ie(t);if(!(i&&!n&&!cn(t))){for(let s=0,o=e.options.length;s<o;s++){const l=e.options[s],r=Fn(l);if(i)if(n){const a=typeof r;a==="string"||a==="number"?l.selected=t.some(c=>String(c)===String(r)):l.selected=Oo(t,r)>-1}else l.selected=t.has(r);else if(dn(Fn(l),t)){e.selectedIndex!==s&&(e.selectedIndex=s);return}}!i&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function Fn(e){return"_value"in e?e._value:e.value}function ga(e,t){const i=t?"_trueValue":"_falseValue";return i in e?e[i]:t}const pf=["ctrl","shift","alt","meta"],hf={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>pf.some(i=>e[`${i}Key`]&&!t.includes(i))},Lt=(e,t)=>{if(!e)return e;const i=e._withMods||(e._withMods={}),n=t.join(".");return i[n]||(i[n]=((s,...o)=>{for(let l=0;l<t.length;l++){const r=hf[t[l]];if(r&&r(s,t))return}return e(s,...o)}))},mf={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},gf=(e,t)=>{const i=e._withKeys||(e._withKeys={}),n=t.join(".");return i[n]||(i[n]=(s=>{if(!("key"in s))return;const o=xi(s.key);if(t.some(l=>l===o||mf[l]===o))return e(s)}))},vf=dt({patchProp:af},Vu);let Wr;function bf(){return Wr||(Wr=_u(vf))}const Jo=((...e)=>{const t=bf().createApp(...e),{mount:i}=t;return t.mount=n=>{const s=kf(n);if(!s)return;const o=t._component;!Ae(o)&&!o.render&&!o.template&&(o.template=s.innerHTML),s.nodeType===1&&(s.textContent="");const l=i(s,!1,yf(s));return s instanceof Element&&(s.removeAttribute("v-cloak"),s.setAttribute("data-v-app","")),l},t});function yf(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function kf(e){return it(e)?document.querySelector(e):e}const wf="slidev-config.json",an={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1},gi=Ls({...an});function xf(e){if(!e||typeof e!="object")return{...an};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():an.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes}}function Di(e){if(!e||typeof e!="object")return{...gi};const t=e;return t.enableWebServeJump!==void 0&&(gi.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(gi.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(gi.normalizeHeadingSizes=!!t.normalizeHeadingSizes),{...gi}}function Hs(){return{...gi}}function va(e,t,i){const n=(e||an.webServeUrl).trim(),s=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,o=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(s);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",t),i!=null&&i.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",o),l.toString()}catch{const l=i!=null&&i.focus?"&focus=1":"";return`${s.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${l}&r=${o}`}}const $i={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1};function Sf(e){var i,n,s,o,l,r;const t=Hs();return e?{theme:((i=e[An])==null?void 0:i.trim())||$i.theme,aspectRatio:((n=e[Bn])==null?void 0:n.trim())||$i.aspectRatio,highlighter:((s=e[ll])==null?void 0:s.trim())||$i.highlighter,defaultTransition:((o=e[Mn])==null?void 0:o.trim())||$i.defaultTransition,colorSchema:((l=e[al])==null?void 0:l.trim())||$i.colorSchema,spacing:((r=e[po])==null?void 0:r.trim())||$i.spacing,normalizeHeadingSizes:t.normalizeHeadingSizes}:{...$i,normalizeHeadingSizes:t.normalizeHeadingSizes}}function $s(e){var i,n,s,o,l;const t=(i=e.ial)==null?void 0:i[Ai];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((n=e.markdown)==null?void 0:n.trim())==="---"||((s=e.markdown)==null?void 0:s.trim())==="***"||e.type==="b"&&(((o=e.markdown)==null?void 0:o.trim())==="---"||((l=e.content)==null?void 0:l.trim())==="---"))}function Ur(e){const t={};let i="";if(!e)return{frontmatter:t,notes:i};e[ge]&&(t.layout=e[ge].trim()),e[tt]&&(t.transition=e[tt].trim()),e[Ke]&&(t.background=e[Ke].trim()),e[Dt]&&(t.image=e[Dt].trim()),e[Gi]&&(t.class=e[Gi].trim()),e[wn]&&(t.spacing=e[wn].trim()),e[kt]&&(t.layoutRatio=e[kt].trim()),e[qi]&&(t.mask=e[qi].trim()),e[Zi]&&(t.maskRatio=e[Zi].trim()),e[Yi]&&(t.maskStyle=e[Yi].trim()),e[Ji]&&(t.maskInitial=e[Ji].trim()),e[Ki]&&(i=e[Ki].trim());for(const[n,s]of Object.entries(e))if(n.startsWith("custom-slidev-")&&![ge,kt,qi,Zi,Yi,Ji,tt,Ke,Dt,Gi,wn,Ki,Ai].includes(n)){const o=n.replace(/^custom-slidev-/,"");try{t[o]=JSON.parse(s)}catch{t[o]=s}}return{frontmatter:t,notes:i}}function _f(e){const t={};if(!e)return t;const i=e[nt]??e["slidev-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(t.isNote=!0);const n=e[Ze]??e["slidev-role"],s=e[Ke]??e["slidev-background"];(n===cl||s==="true"||s==="1")&&(t.isBackground=!0);const o=e[ge]??e["slidev-layout"];o===hs||o===ms?t.imageLayout=o:(n===hs||n===ms)&&(t.imageLayout=n);const l=e[Ye]??e["custom-slidev-clicks"]??e["slidev-click"]??e["slidev-clicks"];if(l!=null&&(t.clicks=l.trim()),e[qt])try{const r=JSON.parse(e[qt]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[qt].trim()}}return e[Ni]&&(t.shikiLines=e[Ni].trim()),e[Dn]&&(t.maxHeight=e[Dn].trim()),e[$e]&&(t.slot=e[$e].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function wi(e,t){const i=(e||t||"").trim();if(!i)return null;const n=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const s=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(s)return s[1].trim();const o=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(o)?o:null}function In(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const i=t[0],n=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return e;const s=n[1].length,o=n[2].trim(),l=i.length-n[2].length;if(t.length===1)return o;const r=[o];for(let a=1;a<t.length;a++){const c=t[a];if(!c.trim()){r.push("");continue}const d=c.match(/^(\s*)/),p=d?d[1].length:0;p>=l?r.push(c.slice(l)):p>s?r.push(c.slice(p)):r.push(c)}return r.join(`
`)}function zi(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const i=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function io(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const i=e.trim();if(!i)return`repeat(${t}, 1fr)`;if(i.includes(":")){const s=i.split(":").map(o=>parseFloat(o.trim())).filter(o=>!isNaN(o)&&o>0);if(s.length>=2)return s.map(o=>`${o}fr`).join(" ")}const n=i.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${t}, 1fr)`}function Tn(e){if(!e)return[];if(ot(e)&&Yt(e)&&!di(e)){const n=fn(e),s=[];for(const o of n)s.push(...Tn(o));return s}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const l=e.children.filter(zi);if(l.length>0)return l}const s=(e.markdown||e.content||"").trim().split(/\r?\n/),o=[];for(let l=0;l<s.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(s[l])&&o.push(l);if(o.length>=2){const l=[];for(let r=0;r<o.length;r++){const a=o[r],c=r+1<o.length?o[r+1]:s.length,d=s.slice(a,c).join(`
`);l.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:d,content:d,ial:{...e.ial||{}}})}return l}}return zi(e)?[e]:[]}function Xo(e){var s;if(!e||!ot(e)||!Yt(e)||di(e))return null;const t=fn(e);if(t.length===0)return null;if(t.length===1&&ot(t[0])&&Yt(t[0])){const o=Xo(t[0]);return o?{items:o.items,nestedSuperBlocks:[t[0],...o.nestedSuperBlocks]}:null}const i=[];for(const o of t)if(ot(o)){i.push(o);const l=((s=o.children)==null?void 0:s.filter(ot))||[];i.push(...l)}const n=t.map(Tn);if(n.length>=2&&n.every(o=>o.length>0)){const o=n.flat();if(o.length>=2&&o.length<=6)return{items:o,nestedSuperBlocks:i}}if(t.length===2){const o=Tn(t[0]),l=Tn(t[1]);if(o.length+l.length>=2&&o.length+l.length<=6&&(o.length>0||l.length>0))return{items:[...o,...l],nestedSuperBlocks:i}}return null}function Cf(e){if(!e||!ot(e)||!Yt(e)||di(e))return null;const t=Xo(e);if(!t)return null;const{items:i,nestedSuperBlocks:n}=t;if(i.length<2||i.length>6)return null;const s=Qo(e)||void 0,o=i.length;return{superBlockNode:e,nestedSuperBlocks:n,count:o,layout:"cols-header",items:i,slots:i.map((l,r)=>`col-${r+1}`),ratio:s}}function ba(e){if(!e||!ot(e)||!Yt(e)||di(e))return null;const t=fn(e);if(t.length===0)return null;const i=[];for(const n of t){const s=Tn(n);if(s.length===0)return null;i.push(...s)}return i}function $f(e){if(!e||!ot(e)||!Yt(e)||di(e))return null;const t=ba(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function If(e){if(!e||!ot(e)||!Yt(e)||di(e))return null;const t=Xo(e);if(t&&t.items.length===4)return t.items;const i=ba(e);if(i&&i.length===4)return i;const n=fn(e);return n.length===4?n:null}function Tf(e,t){if(!e||e.length===0)return null;const i=[];function n(r,a){if(ot(r)){const c=If(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,a)}for(let r=0;r<e.length;r++)n(e[r],r);if(i.length===0)return null;let s=null;t&&(s=i.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const a=c=>c.id===t?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),s||(s=i[0]);const l=e.slice(0,s.topLevelIndex).slice().reverse().find(r=>ya(r));return{superBlockNode:s.sbNode,items:s.items,headerNode:l}}function Ef(e,t,i){var d,p,g,u,m;const n=[],s=[],o=(i==null?void 0:i.tracked)||[],l=[];let r={pageTargetId:e,blocks:[]};l.push(r);for(let h=0;h<t.length;h++){const b=t[h];if($s(b)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=b.id,r.blocks.push(b);continue}r={pageTargetId:b.id,blocks:[b]},l.push(r)}else r.blocks.push(b)}function a(h){const b=[];for(const y of h)ot(y)&&b.push(y),y.children&&y.children.length>0&&b.push(...a(y.children));return b}function c(h,b,y){const x={blockId:h,attrs:b,previousAttrs:y};n.push(x),i!=null&&i.onTagChange&&i.onTagChange(x)}for(const h of l){const b=h.pageTargetId,y=t.find(T=>T.id===b),x=o.find(T=>T.pageTargetId===b);if(h.blocks.some(T=>{var w,R;return!!(di(T)||$o(T)&&(((w=T.ial)==null?void 0:w[ge])==="image-left"||((R=T.ial)==null?void 0:R[ge])==="image-right"))})){if(x){const T=x.headerId;if(T){c(T,{[$e]:""});const w=t.find(R=>R.id===T);w!=null&&w.ial&&(w.ial[$e]="")}for(const w of x.itemIds){c(w,{[$e]:""});const R=t.find(O=>O.id===w);R!=null&&R.ial&&(R.ial[$e]="")}}continue}let B=null,M=-1;for(let T=0;T<h.blocks.length;T++){const w=h.blocks[T],R=ot(w)?[w,...a(w.children||[])]:w.children?a(w.children):[];for(const O of R){const N=Cf(O);if(N){B=N,M=T;break}}if(B)break}if(B){const{superBlockNode:T,layout:w,items:R,slots:O}=B,Z=h.blocks.slice(0,M).find(E=>ya(E)),S=Z==null?void 0:Z.id,z=((d=y==null?void 0:y.ial)==null?void 0:d[ge])||"",k=z==="clover",A=k?"clover":w;if(z!==A&&(c(b,{[ge]:A},{[ge]:z}),y&&(y.ial||(y.ial={}),y.ial[ge]=A)),Z){const E=((p=Z.ial)==null?void 0:p[$e])||"";E!=="header"&&(c(Z.id,{[$e]:"header"},{[$e]:E}),Z.ial||(Z.ial={}),Z.ial[$e]="header")}if(x!=null&&x.headerId&&x.headerId!==S){c(x.headerId,{[$e]:""});const E=t.find(D=>D.id===x.headerId);E&&(E.ial||(E.ial={}),E.ial[$e]="")}const F=[];for(let E=0;E<R.length;E++){const D=R[E],P=O[E];F.push(D.id);const X=((g=D.ial)==null?void 0:g[$e])||"";if(X!==P&&(c(D.id,{[$e]:P},{[$e]:X}),D.ial||(D.ial={}),D.ial[$e]=P),D.children&&D.children.length>0)for(const G of D.children)G.ial||(G.ial={}),G.ial[$e]!==P&&(G.ial[$e]=P)}if(x!=null&&x.itemIds){for(const E of x.itemIds)if(!F.includes(E)){c(E,{[$e]:""});const D=t.find(P=>P.id===E);D&&(D.ial||(D.ial={}),D.ial[$e]="")}}s.push({superBlockId:T.id,nestedSuperBlockIds:(u=B.nestedSuperBlocks)==null?void 0:u.map(E=>E.id),pageTargetId:b,headerId:S,itemIds:F,layout:k?"clover":w})}else{let T=!1;const w=[];for(const N of h.blocks){const Z=ot(N)?[N,...a(N.children||[])]:N.children?a(N.children):[];for(const S of Z){const z=$f(S);if(z){T=!0;for(const k of z.items)w.push(k.id)}}}const R=((m=y==null?void 0:y.ial)==null?void 0:m[ge])||"",O=Ln(R);if(x||T&&O){c(b,{[ge]:""},{[ge]:R}),y&&(y.ial||(y.ial={}),y.ial[ge]="");const N=x==null?void 0:x.headerId;if(N){c(N,{[$e]:""});const S=t.find(z=>z.id===N);S&&(S.ial||(S.ial={}),S.ial[$e]="")}const Z=new Set([...(x==null?void 0:x.itemIds)||[],...w]);for(const S of Z){c(S,{[$e]:""});const z=t.find(k=>k.id===S);z&&(z.ial||(z.ial={}),z.ial[$e]="")}}}}return{changes:n,newTracked:s}}function ot(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function Yt(e){if(!ot(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const n=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(e.children&&e.children.length>0){for(const n of e.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const s=(n.content||n.markdown||"").trim().toLowerCase();if(s==="col"||s==="h")return!0;if(s==="row"||s==="v")return!1}}const i=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function $o(e){return!e||zi(e)||ot(e)||!wi(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function Qo(e){var g;if(!e||!ot(e)||!Yt(e))return null;const t=fn(e);if(!t||t.length<2)return null;const i=[];let n=!1;for(const u of t){const m=(((g=u.ial)==null?void 0:g.style)||u.style||"").trim();let h=null;if(m){const b=m.match(/calc\(\s*([\d.]+)%/i);if(b)h=parseFloat(b[1]);else{const y=m.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);y&&(h=parseFloat(y[1]))}}h!==null&&!isNaN(h)&&h>0?(i.push(h),n=!0):i.push(null)}if(!n)return null;const s=t.length,o=i.reduce((u,m)=>u+(m||0),0),l=i.filter(u=>u===null).length,r=Math.max(0,100-o),a=l>0?r/l:100/s,c=i.map(u=>u!==null?u:a),d=c.reduce((u,m)=>u+m,0);if(d<=0)return null;const p=c.map(u=>u/d*100);if(p.length===2){const[u]=p;if(u>=48&&u<=52)return"1:1";if(u>=31&&u<=35)return"1:2";if(u>=65&&u<=69)return"2:1";if(u>=28&&u<=32)return"3:7";if(u>=68&&u<=72)return"7:3";if(u>=38&&u<=42)return"4:6";if(u>=58&&u<=62)return"6:4";if(u>=23&&u<=27)return"1:3";if(u>=73&&u<=77)return"3:1";const m=Math.round(u),h=100-m;return`${m}:${h}`}if(p.length===3){const[u,m,h]=p;if(u>=31&&u<=35&&m>=31&&m<=35&&h>=31&&h<=35)return"1:1:1";if(u>=23&&u<=27&&m>=48&&m<=52&&h>=23&&h<=27)return"1:2:1";if(u>=48&&u<=52&&m>=23&&m<=27&&h>=23&&h<=27)return"2:1:1";if(u>=23&&u<=27&&m>=23&&m<=27&&h>=48&&h<=52)return"1:1:2";if(u>=18&&u<=22&&m>=58&&m<=62&&h>=18&&h<=22)return"1:3:1";const b=Math.round(u),y=Math.round(m),x=100-b-y;return`${b}:${y}:${x}`}return p.map(u=>Math.round(u)).join(":")}function di(e){if(!e||!ot(e)||!Yt(e))return null;const t=(e.children||[]).filter(o=>{const l=o.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(o.markdown||o.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const i=$o(t[0]),n=$o(t[t.length-1]),s=Qo(e)||void 0;if(i&&!n){const o=wi(t[0].markdown,t[0].content);if(o)return{imageNode:t[0],imageUrl:o,layout:hs,contentNodes:t.slice(1),ratio:s}}if(!i&&n){const o=wi(t[t.length-1].markdown,t[t.length-1].content);if(o)return{imageNode:t[t.length-1],imageUrl:o,layout:ms,contentNodes:t.slice(0,t.length-1),ratio:s}}return null}function Af(e,t){const i=[];function n(s){for(const o of s){const l=di(o);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const d=r.ial[ge];if(d!==a){const g={blockId:r.id,layout:a,previousLayout:d,ratio:c};r.ial[ge]=a,i.push(g),t&&t(g)}}o.children&&o.children.length>0&&n(o.children)}}return n(e),i}function fn(e){return(e.children||[]).filter(t=>{const i=t.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const n=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function ya(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const i=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function Ii(e,t,i){let n="",s=0;const o=/<div\b([^>]*)>/gi;for(;s<e.length;){o.lastIndex=s;let l,r=!1,a=-1,c=0;for(;(l=o.exec(e))!==null;){const y=l[1].match(/\bclass=["']([^"']*)["']/i);if(y){const x=y[1];if(typeof t=="string"?x.split(/\s+/).includes(t):t.test(x)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){n+=e.slice(s);break}n+=e.slice(s,a);const d=a+c;let p=1,g=-1,u=-1;const m=/<\/?div\b[^>]*>/gi;m.lastIndex=d;let h;for(;(h=m.exec(e))!==null;)if(h[0].startsWith("</")){if(p--,p===0){g=h.index,u=h.index+h[0].length;break}}else p++;if(g!==-1&&u!==-1){const b=e.slice(d,g);n+=i(b),s=u}else n+=e.slice(a,d),s=d}return n}function Bf(e){const t=[];let i="",n=0;const s=/<div\b([^>]*)>/gi;for(;n<e.length;){s.lastIndex=n;let o,l=!1,r=-1,a=0;for(;(o=s.exec(e))!==null;){const h=o[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(h)){l=!0,r=o.index,a=o[0].length;break}}if(!l){i+=e.slice(n);break}i+=e.slice(n,r);const c=r+a;let d=1,p=-1,g=-1;const u=/<\/?div\b[^>]*>/gi;u.lastIndex=c;let m;for(;(m=u.exec(e))!==null;)if(m[0].startsWith("</")){if(d--,d===0){p=m.index,g=m.index+m[0].length;break}}else d++;if(p!==-1&&g!==-1){const h=e.slice(r,g),b=`__VUE_DIV_TOKEN_${t.length}__`;t.push(h),i+=b,n=g}else i+=e.slice(r,c),n=c}return{text:i,tokens:t}}function Mf(e){const t=[];let i=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});const n=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),a});const{text:s,tokens:o}=Bf(i);i=s;const l=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=Ii(i,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),p=c[3].trim();return`**${d}:**
\`\`\`yaml
${p}
\`\`\``}).join(`

`)+`
`:r}),i=Ii(i,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),i=Ii(i,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let p="-";return d.includes("warn")?p="- ⚠️":d.includes("bad")?p="- ❌":d.includes("ok")&&(p="- ✅"),`${p} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=Ii(i,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const g=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${g}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=Ii(i,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=Ii(i,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=Ii(i,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((p,g)=>Math.max(p,g.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,d,p)=>{const g=p.trim();return g.includes("<")||g.includes(`
`)?r:`[${g}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,l[r]);for(let r=0;r<o.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,o[r]);for(let r=0;r<n.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,n[r]);for(let r=0;r<t.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,t[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function ka(e){if(!e||typeof e!="string")return"";const t=[];let i=e.replace(/`([^`]+)`/g,n=>(t.push(n),`%%INLINE_CODE_${t.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(n,s)=>t[parseInt(s,10)]||""),i}function Df(e){const t=Object.entries(e).filter(([n,s])=>s!=null&&s!=="");return t.length===0?"":`---
${t.map(([n,s])=>typeof s=="string"?s.includes(":")||s.includes(`
`)||s.includes("#")?`${n}: "${s.replace(/"/g,'\\"')}"`:`${n}: ${s}`:`${n}: ${JSON.stringify(s)}`).join(`
`)}
---`}function Lf(e,t){if(!t||!e.startsWith("```"))return e;const i=e.indexOf(`
`);if(i===-1)return e;const n=e.slice(0,i).trim(),s=e.slice(i);return n.includes("{")?e:`${n} {${t}}${s}`}function wa(e,t){if(t==null)return e;const i=t.trim();return i===""||i==="+1"?`<v-click>

${e}

</v-click>`:i==="hide"?`<v-click hide>

${e}

</v-click>`:`<v-click at="${i}">

${e}

</v-click>`}function Pf(e){if(!e||!e.preset)return null;const t=e.preset.toLowerCase().trim();if(!t||t==="none")return null;let i={opacity:0},n={opacity:1};switch(t){case"slide-up":i={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},n={opacity:1};break}e.initial&&typeof e.initial=="object"&&(i={...i,...e.initial}),e.enter&&typeof e.enter=="object"&&(n={...n,...e.enter});const s={...n.transition||{}};return typeof e.duration=="number"&&e.duration>0&&(s.duration=e.duration),typeof e.delay=="number"&&e.delay>0&&(s.delay=e.delay),Object.keys(s).length>0&&(n.transition=s),{initial:i,enter:n}}function Qn(e,t,i,n){const s=t!=null&&t.trim()!=="",o=Pf(i),l=n==null?void 0:n.trim(),r=l!==void 0&&l!=="",a=r?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!s&&!o)return r?`<div${a}>

${e}

</div>`:e;if(s&&!o){if(r){const m=t.trim();let h="v-click";return m==="hide"?h="v-click.hide":m!==""&&m!=="+1"&&(h=`v-click="${m}"`),`<div ${h}${a}>

${e}

</div>`}return wa(e,t)}const c=JSON.stringify(o.initial).replace(/"/g,"'"),d=JSON.stringify(o.enter).replace(/"/g,"'"),p=`v-motion :initial="${c}" :enter="${d}"`;if(!s)return`<div ${p}${a}>

${e}

</div>`;const g=t.trim();let u="v-click";return g==="hide"?u="v-click.hide":g!==""&&g!=="+1"&&(u=`v-click="${g}"`),`<div ${u} ${p}${a}>

${e}

</div>`}function xa(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let s=t.split(/\r?\n/).map(o=>o.trim().replace(/^>\s*/,"")).join(`
`).trim();return s=s.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),s=s.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),s=s.replace(/^[-*+]\s+/,""),s=s.replace(/^\d+\.\s+/,""),s.trim()}function Of(e){var n;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const i=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:e.type==="h"?(n=e.ial)!=null&&n.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function Sa(e,t=2){const i=Math.max(2,t);if(!e||e.length===0)return Array.from({length:i},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,d=Array.from({length:i},()=>[]),p=Math.min(i,c.length),g=Math.floor(c.length/p),u=c.length%p;let m=0;for(let h=0;h<p;h++){const b=g+(h<u?1:0);d[h]=c.slice(m,m+b),m+=b}return d}const n=c=>{const d=(c.slot||"").trim();if(!d)return null;if(d==="left")return 1;if(d==="center")return 2;if(d==="right")return i===2?2:i;const p=d.match(/^col-(\d+)$/i);if(p){const g=parseInt(p[1],10);if(g>=1&&g<=i)return g}return null},s=e.map(n);if(s.some(c=>c!==null)){if(s.some(u=>u!==null&&u>=2)){const u=Array.from({length:i},()=>[]);let m=1;for(const h of e){const b=n(h);b!==null&&(m=b),u[m-1].push(h)}return u}const d=e.filter(u=>n(u)===1),p=e.filter(u=>n(u)===null),g=i-1;if(p.length>=g){const u=Math.floor(p.length/g),m=p.length%g,h=[d];let b=0;for(let y=0;y<g;y++){const x=u+(y<m?1:0);h.push(p.slice(b,b+x)),b+=x}return h}else if(p.length>0){const u=[d];for(let m=0;m<g;m++)u.push(m<p.length?[p[m]]:[]);return u}else return[d,...Array.from({length:g},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const d=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(d)},r=e.map((c,d)=>l(c)?d:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let d=0;d<i;d++){const p=r[d],g=d+1<i?r[d+1]:e.length;c[d]=e.slice(p,g)}return c}if(e.length>=i){const c=Array.from({length:i},()=>[]);let d=0;for(let p=0;p<i;p++){const g=i-p,u=e.length-d,m=Math.ceil(u/g);c[p]=e.slice(d,d+m),d+=m}return c}if(e.length>1&&e.length<i){const c=Array.from({length:i},()=>[]);for(let d=0;d<e.length;d++)c[d]=[e[d]];return c}if(e.length===1){const c=e[0],d=(c.rawMarkdown||c.content||"").trim(),p=d.split(/\r?\n/),g=[];for(let h=0;h<p.length;h++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(p[h])&&g.push(h);if(g.length>=i){const h=Array.from({length:i},()=>[]);let b=0;for(let y=0;y<i;y++){const x=i-y,_=g.length-b,B=Math.ceil(_/x),M=g[b],T=b+B<g.length?g[b+B]:p.length,w=p.slice(M,T).join(`
`);h[y]=[{...c,id:y===0?c.id:`${c.id}-col${y+1}`,rawMarkdown:w,content:w}],b+=B}return h}const u=d.match(/<li[\s\S]*?<\/li>/gi);if(u&&u.length>=i){const h=Array.from({length:i},()=>[]);let b=0;for(let y=0;y<i;y++){const x=i-y,_=u.length-b,B=Math.ceil(_/x),M=`<ul>
${u.slice(b,b+B).join(`
`)}
</ul>`;h[y]=[{...c,id:y===0?c.id:`${c.id}-col${y+1}`,rawMarkdown:M,content:M}],b+=B}return h}const m=d.split(/\r?\n\s*\r?\n/).filter(h=>h.trim()!=="");if(m.length>=i){const h=Array.from({length:i},()=>[]);let b=0;for(let y=0;y<i;y++){const x=i-y,_=m.length-b,B=Math.ceil(_/x),M=m.slice(b,b+B).join(`

`);h[y]=[{...c,id:y===0?c.id:`${c.id}-col${y+1}`,rawMarkdown:M,content:M}],b+=B}return h}}const a=Array.from({length:i},()=>[]);return a[0]=e,a}function Vr(e,t,i,n){var d;const s=Sf(t),o=[],l=Ur(t);let r={pageIndex:1,startBlockId:e,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};r.frontmatter.background&&(r.frontmatter.background=Tt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Tt(r.frontmatter.image,n)),o.push(r);let a=[];for(const p of i){if($s(p)){a=[];const u=Ur(p.ial);if(o.length===1&&r.blocks.length===0){r.startBlockId=p.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(p.id)||r.allBlockIds.push(p.id),u.frontmatter.layout&&(r.frontmatter.layout=u.frontmatter.layout),Object.assign(r.frontmatter,u.frontmatter),!u.frontmatter.image&&l.frontmatter.image&&(r.frontmatter.image=l.frontmatter.image),!u.frontmatter.background&&l.frontmatter.background&&(r.frontmatter.background=l.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=Tt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Tt(r.frontmatter.image,n));continue}r={pageIndex:o.length+1,startBlockId:p.id,frontmatter:{layout:u.frontmatter.layout||"default",...u.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[p.id]},r.frontmatter.background&&(r.frontmatter.background=Tt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Tt(r.frontmatter.image,n)),o.push(r);continue}const g=(u,m)=>{var F,E,D,P;if(r.allBlockIds||(r.allBlockIds=[]),u.id&&!r.allBlockIds.includes(u.id)&&r.allBlockIds.push(u.id),u.children&&u.children.length>0){const X=G=>{for(const W of G)W.id&&!r.allBlockIds.includes(W.id)&&r.allBlockIds.push(W.id),W.children&&W.children.length>0&&X(W.children)};X(u.children)}let h=Kc(u),b=u.ial?{...u.ial}:{};const y=h.match(/\{:\s*([^}]+)\s*\}\s*$/);y&&(b={...Gc(y[0]),...b},h=h.slice(0,y.index).trim()),u.type!=="c"&&!h.startsWith("```")&&(h=ka(h));let x=h.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(x)||x==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(x)&&/\r?\n\}\}\}$/.test(x)&&(h=x.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),x=h.trim());const _=_f(b);if(h=qc(h,n),h=Uc(h,n==null?void 0:n.refContentMap),u.children&&u.children.length>0){const X=["custom-slidev-autoplay","custom-slidev-loop","custom-slidev-muted","custom-slidev-controls"],G=W=>{for(const se of W){if(se.ial)for(const[ae,ce]of Object.entries(se.ial))X.includes(ae)&&!b[ae]&&(b[ae]=ce);se.children&&se.children.length>0&&G(se.children)}};G(u.children)}const B=u.type==="video"||u.type==="NodeVideo"||/<video\b/i.test(h);if(B){const X=b["custom-slidev-autoplay"]==="true",G=b["custom-slidev-loop"]==="true",W=b["custom-slidev-muted"]==="true"||X,se=b["custom-slidev-controls"]==="false";h=h.replace(/<video\b([^>]*)>/gi,(ae,ce)=>{let ve=ce;return se?ve=ve.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(ve)||(ve+=" controls"),X&&!/autoplay/i.test(ve)?ve+=" autoplay playsinline":!X&&b["custom-slidev-autoplay"]==="false"&&(ve=ve.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),G&&!/loop/i.test(ve)?ve+=" loop":!G&&b["custom-slidev-loop"]==="false"&&(ve=ve.replace(/\bloop\b/gi,"").trim()),W&&!/muted/i.test(ve)?ve+=" muted":!W&&b["custom-slidev-muted"]==="false"&&(ve=ve.replace(/\bmuted\b/gi,"").trim()),`<video ${ve.trim()}>`})}if(_.isBackground){const X=wi(h,u.content);if(X){r.frontmatter.background=Tt(X,n);return}}const M=di(u);if(M){r.frontmatter.layout=M.layout,r.frontmatter.image=Tt(M.imageUrl,n),!r.frontmatter.layoutRatio&&M.ratio&&(r.frontmatter.layoutRatio=M.ratio);for(const X of M.contentNodes)g(X);return}if(_.imageLayout==="image-left"||_.imageLayout==="image-right"){const X=wi(h,u.content);if(X){r.frontmatter.layout=_.imageLayout,r.frontmatter.image=Tt(X,n),!r.frontmatter.layoutRatio&&((F=u.ial)!=null&&F[kt])&&(r.frontmatter.layoutRatio=u.ial[kt]);return}}if(ot(u)&&u.children&&u.children.length>0){for(const X of u.children)g(X);return}const T=!!(_.slot||m!=null&&m.defaultSlot||r.frontmatter.layout==="clover"||Ln(r.frontmatter.layout)||r.frontmatter.layout==="two-cols");if((u.type==="l"||u.type==="NodeList"||u.type==="list")&&u.children&&u.children.length>0&&(u.children.some(X=>{var G,W;return((G=X.ial)==null?void 0:G[$e])||((W=X.ial)==null?void 0:W[Ye])})||_.slot||_.clicks||T)){for(const X of u.children)_.slot&&(!X.ial||!X.ial[$e])&&(X.ial||(X.ial={}),X.ial[$e]=_.slot),g(X,{...m,parentClicks:_.clicks||(m==null?void 0:m.parentClicks),defaultSlot:_.slot||(m==null?void 0:m.defaultSlot)});return}const w=!!(u.children&&u.children.length>=2)||!!_.clicks||!!((E=u.children)!=null&&E.some(X=>{var G;return(G=X.ial)==null?void 0:G[Ye]}))||!u.markdown&&!!(u.children&&u.children.length>0);if(zi(u)&&u.children&&u.children.length>0&&(T||_.clicks||u.children.some(X=>{var G;return(G=X.ial)==null?void 0:G[Ye]}))&&w){const X=!!(u.children&&u.children.length>=2),G=u.children.find(xe=>!!(xe.markdown||xe.content||"").trim())||u.children[0],W=((D=G==null?void 0:G.ial)==null?void 0:D[Ye])||((P=G==null?void 0:G.ial)==null?void 0:P["custom-slidev-click"]),se=!!(!_.clicks&&X&&W),ae=_.clicks||(se?W:void 0)||(m==null?void 0:m.parentClicks),ce=u.id||(m==null?void 0:m.parentContainerId),ve=_.slot||(m==null?void 0:m.defaultSlot);let Te=!0;for(const xe of u.children){ve&&(!xe.ial||!xe.ial[$e])&&(xe.ial||(xe.ial={}),xe.ial[$e]=ve);const ue=!!(xe.markdown||xe.content||"").trim(),Y=Te&&ue;Y&&(xe.markdown&&(xe.markdown=In(xe.markdown)),xe.content&&(xe.content=In(xe.content)),Te=!1);let fe=xe;Y&&ae&&X&&(fe={...xe,ial:{...xe.ial||{}}},delete fe.ial[Ye],delete fe.ial["custom-slidev-click"]),g(fe,{parentClicks:ae,parentContainerId:ce,defaultSlot:ve})}return}if(_.isNote){const X=xa(h);X&&(r.notes?r.notes+=`

`+X:r.notes=X),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:u.id,type:u.type,content:X||u.content||"",rawMarkdown:h,isNote:!0,attributes:u.ial});return}_.shikiLines&&(h=Lf(h,_.shikiLines)),x=h.trim();const R=(u.content||"").trim();if(x==="::right::"||R==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(x)||x.startsWith("::right::")){r.blocks.push({id:u.id,type:u.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:u.ial});return}const N=Of(u);let Z=_.slot,S=_.clicks,z=_.motion,k={...u.ial||{}};if(N!==null){for(;a.length>0&&a[a.length-1].level>=N;)a.pop();const X=a.length>0?a[a.length-1]:void 0;!Z&&(X!=null&&X.slot)&&(Z=X.slot),!S&&(X!=null&&X.clicks)&&!(m!=null&&m.parentContainerId)&&(S=X.clicks),!z&&(X!=null&&X.motion)&&(z=X.motion);const G={...(X==null?void 0:X.customAttrs)||{}};if(u.ial)for(const[W,se]of Object.entries(u.ial))W.startsWith("custom-slidev-")&&!W.startsWith("custom-slidev-slide")&&(G[W]=se);m!=null&&m.parentContainerId||a.push({level:N,slot:Z,clicks:S,motion:z,customAttrs:G})}else{const X=a.length>0?a[a.length-1]:void 0;X&&(!Z&&X.slot&&X.slot!=="header"&&(Z=X.slot),!S&&X.clicks&&!(m!=null&&m.parentContainerId)&&(S=X.clicks),!z&&X.motion&&(z=X.motion),X.customAttrs&&(k={...X.customAttrs,...k}))}!Z&&r.blocks.some(X=>X.slot==="slot-divider-right")&&(Z="right"),!Z&&(m!=null&&m.defaultSlot)&&(Z=m.defaultSlot),Z&&(k[$e]=Z),S&&!k[Ye]&&(k[Ye]=S),z&&!k[qt]&&(k[qt]=JSON.stringify(z)),(B||b["custom-slidev-autoplay"]||b["custom-slidev-muted"])&&(b["custom-slidev-autoplay"]&&(k["custom-slidev-autoplay"]=b["custom-slidev-autoplay"],b["custom-slidev-autoplay"]==="true"&&!b["custom-slidev-muted"]&&(k["custom-slidev-muted"]="true")),b["custom-slidev-loop"]&&(k["custom-slidev-loop"]=b["custom-slidev-loop"]),b["custom-slidev-muted"]&&(k["custom-slidev-muted"]=b["custom-slidev-muted"]),b["custom-slidev-controls"]&&(k["custom-slidev-controls"]=b["custom-slidev-controls"]));const A={id:u.id,type:u.type,content:u.content||"",rawMarkdown:h,clicks:S,parentClicks:m==null?void 0:m.parentClicks,parentContainerId:m==null?void 0:m.parentContainerId,motion:z,shikiLines:_.shikiLines,slot:Z,attributes:k,rawNode:u};r.blocks.push(A)};g(p)}for(let p=0;p<o.length;p++){const g=o[p],u=[],m={...g.frontmatter};p===0&&(m.theme=s.theme,m.aspectRatio=s.aspectRatio,m.highlighter=s.highlighter,m.transition=g.frontmatter.transition||s.defaultTransition);const h=Df(m);h&&u.push(h);const b=g.blocks.filter(M=>M.slot!=="slot-divider-right"),y=M=>M.filter(T=>!!(T.rawMarkdown||T.content||"").trim()).map(T=>{var w;return Qn(T.rawMarkdown,T.clicks,T.motion,(w=T.attributes)==null?void 0:w.style)}).join(`

`),x=M=>{const T=M.filter(N=>!!(N.rawMarkdown||N.content||"").trim());if(T.length===0)return;const w=T[0],R=(w.rawMarkdown||w.content||"").trim();(zi(w)||/^(?:[-*+]|\d+\.)\s+/.test(R))&&(w.rawMarkdown=In(w.rawMarkdown||w.content||""),w.content=w.rawMarkdown)},_=M=>{var N,Z;if(M.length===0)return"";x(M);const T=(N=M.find(S=>S.parentClicks))==null?void 0:N.parentClicks;if(!T)return M.filter(S=>!!(S.rawMarkdown||S.content||"").trim()).map(S=>{var z;return Qn(S.rawMarkdown,S.clicks,S.motion,(z=S.attributes)==null?void 0:z.style)}).join(`

`);const w=[];let R=[];const O=()=>{if(R.length===0)return;const S=R.map(z=>(z.rawMarkdown||z.content||"").trim()).filter(Boolean).join(`

`);S&&w.push(wa(S,T)),R=[]};for(const S of M){if(!(S.rawMarkdown||S.content||"").trim())continue;!!(S.clicks&&S.clicks.trim()!=="")?(O(),w.push(Qn(S.rawMarkdown,S.clicks,S.motion,(Z=S.attributes)==null?void 0:Z.style))):R.push(S)}return O(),w.join(`

`)},B=g.frontmatter.layout||"default";if(B==="clover"||Ln(B)){let M=[];const T=b.filter(S=>S.slot==="header");if(T.length>0)M=T;else if(b.length>0){const S=b.find(z=>z.type==="h"&&(!z.slot||z.slot==="default"));S&&(M=[S])}const w=b.filter(S=>!M.includes(S));let R=2;if(B==="clover")R=4;else if(B==="three-cols-header")R=3;else if(B==="two-cols-header")R=2;else{let S=0;for(const z of w){const k=(z.slot||"").match(/^col-(\d+)$/i);k&&(S=Math.max(S,parseInt(k[1],10)))}if(S>=2)R=S;else if(g.frontmatter.layoutRatio){const z=g.frontmatter.layoutRatio.trim();if(z.includes(":")){const k=z.split(":").map(A=>parseFloat(A.trim())).filter(A=>!isNaN(A)&&A>0);k.length>=2&&(R=k.length)}else{const k=z.split(/\s+/).filter(Boolean);k.length>=2&&(R=k.length)}}else w.length===1&&w[0].children&&w[0].children.length>=2&&(R=Math.min(6,w[0].children.length))}const O=Sa(w,R);O.forEach((S,z)=>{const k=`col-${z+1}`;for(const A of S)(!A.slot||A.slot==="default")&&(A.slot=k);x(S)});const N=O.flat();if(w.length===1&&N.length>1){const S=g.blocks.findIndex(z=>z.id===w[0].id);S!==-1&&g.blocks.splice(S,1,...N)}const Z=y(M);if(Z&&u.push(Z),B==="two-cols-header"&&R===2){const S=_(O[0]||[]),z=_(O[1]||[]);S&&u.push(`::left::

${S}`),z&&u.push(`::right::

${z}`)}else O.forEach((S,z)=>{const k=_(S);k&&u.push(`::col-${z+1}::

${k}`)})}else if(B==="two-cols"){const M=b.filter(O=>O.slot==="left"),T=b.filter(O=>O.slot==="right");x(M),x(T);const w=y(M.length>0?M:b.filter(O=>O.slot!=="right")),R=y(T);u.push(w),R&&u.push(`::right::

${R}`)}else for(const M of b)u.push(Qn(M.rawMarkdown,M.clicks,M.motion,(d=M.attributes)==null?void 0:d.style));g.notes&&u.push(`<!--
${g.notes}
-->`),g.rawMarkdown=u.join(`

`).trim()}const c=o.map(p=>p.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:e,config:s,slides:o,fullMarkdown:c}}const Io=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function Rf(e){var s,o,l,r,a,c,d,p,g,u,m,h;if(!e||typeof e!="object")return"";const t=[],i=[];if(Array.isArray(e.styles))for(const b of e.styles){if(!b||!b.id)continue;const y=`--b3-inline-style-${b.id}`;(s=b.light)!=null&&s.color&&t.push(`  ${y}-color: ${b.light.color};`),(o=b.light)!=null&&o.backgroundColor&&t.push(`  ${y}-background-color: ${b.light.backgroundColor};`),(l=b.dark)!=null&&l.color&&i.push(`  ${y}-color: ${b.dark.color};`),(r=b.dark)!=null&&r.backgroundColor&&i.push(`  ${y}-background-color: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const b of e.builtin.colors){if(!b||typeof b.index!="number")continue;const y=b.index;(a=b.light)!=null&&a.color&&t.push(`  --b3-font-color${y}: ${b.light.color};`),(c=b.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${y}: ${b.light.backgroundColor};`),(d=b.dark)!=null&&d.color&&i.push(`  --b3-font-color${y}: ${b.dark.color};`),(p=b.dark)!=null&&p.backgroundColor&&i.push(`  --b3-font-background${y}: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const b of e.builtin.styles){if(!b||!b.id)continue;const y=b.id;(g=b.light)!=null&&g.color&&t.push(`  --b3-card-${y}-color: ${b.light.color};`),(u=b.light)!=null&&u.backgroundColor&&t.push(`  --b3-card-${y}-background: ${b.light.backgroundColor};`),(m=b.dark)!=null&&m.color&&i.push(`  --b3-card-${y}-color: ${b.dark.color};`),(h=b.dark)!=null&&h.backgroundColor&&i.push(`  --b3-card-${y}-background: ${b.dark.backgroundColor};`)}if(t.length===0&&i.length===0)return"";const n=[];return t.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),i.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),n.join(`

`)}function En(e){const t=Rf(e);return t?`${Io}

/* Custom Workspace Inline Styles */
${t}`:Io}function no(e){const t={};if(!e||typeof e!="string")return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(i))!==null;){const o=s[1],l=s[2]??s[3]??s[4]??"";t[o]=l}return t}function Nf(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function zf(e,t){const i=new Map,n=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:i,rebuildRoots:n};const s=new Map;for(const o of t)o!=null&&o.id&&s.set(o.id,o);for(const o of e||[]){if(!(o!=null&&o.id))continue;const l=s.get(o.id);if(!l)continue;const r=o.content??"",a=o.markdown??"";(l.content??"")===r&&(l.markdown??"")===a||(Nf(l)?n.push(o.id):i.set(o.id,{content:r,markdown:a}))}return{usable:!0,reason:"",leafPatch:i,rebuildRoots:n}}function Ff(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function To(e){return ot(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function Hf(e,t,i,n=8,s){const o=new Map;for(const g of t)g!=null&&g.id&&o.set(g.id,g);const l=g=>({id:g.id,parent_id:g.parent_id,root_id:g.root_id||e,type:g.type,subType:g.subtype??g.subType??"",content:g.content||"",markdown:g.markdown||"",ial:i(g.id,g.ial),children:[]}),r=g=>{let u=g.parent_id,m=0;for(;u&&u!==e&&m++<16;){const h=o.get(u);if(!h||!Ff(h))return u;u=h.parent_id}return u||e},a=new Map;for(const g of t){if(!(g!=null&&g.id)||g.id===e||s&&s.size>0&&!s.has(g.id))continue;const u=r(g),m=a.get(u);m?m.push(g):a.set(u,[g])}if(s&&s.size>0)for(const g of a.values())g.sort((u,m)=>(s.get(u.id)??Number.MAX_SAFE_INTEGER)-(s.get(m.id)??Number.MAX_SAFE_INTEGER));const c=new Map,d=(g,u)=>{const m=l(g);if(c.set(m.id,m),u>=n||!To(m))return m;const h=a.get(m.id);return h&&h.length>0&&(m.children=h.map(b=>d(b,u+1))),m};return{topLevel:(a.get(e)||[]).map(g=>d(g,0)),byId:c}}const jf={getBlockAttrs:Mo,getChildBlocks:us,getDocBlocksOrders:Hc,setBlockAttrs:He,sql:sn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:jc};class Wf{constructor(t){Se(this,"deps");Se(this,"attrOverrides",new Map);Se(this,"trackedListSuperBlocks",new Map);Se(this,"fallbackWarnedDocId","");this.deps={...jf,...t||{}}}setBlockAttrOverride(t,i){if(!t||!i)return;const s={...this.attrOverrides.get(t)||{}};for(const[o,l]of Object.entries(i))l===""||l===null||l===void 0?delete s[o]:s[o]=String(l);Object.keys(s).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,s)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,i){if(!t)return;if(!i){this.attrOverrides.delete(t);return}const n=this.attrOverrides.get(t);n&&(delete n[i],Object.keys(n).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const i=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},n=this.attrOverrides.get(t);n&&Object.assign(i,n);const s=await this.deps.getChildBlocks(t).catch(()=>[])||[],o=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],l=new Map;for(let A=0;A<o.length;A++)o[A]&&l.set(o[A],A);const r=l.size>0,a=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[],d=zf(s,c),p=new Map;if(Array.isArray(c))for(const A of c)A.id&&A.ial&&p.set(A.id,no(A.ial));const g=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,u=await this.deps.sql(g).catch(()=>[])||[];if(Array.isArray(u)){for(const A of u)if(A.block_id&&A.name){let F=p.get(A.block_id);F||(F={},p.set(A.block_id,F)),F[A.name]=A.value||""}}const m=(A,F)=>{const E={...p.get(A)||(F?no(F):{})},D=this.attrOverrides.get(A);return D&&Object.assign(E,D),E},h=Array.isArray(c)&&c.length>0?Hf(t,c,m,8,l):null,b=s.map(A=>A.id).filter(Boolean),y=A=>({id:A.id,parent_id:A.parent_id,root_id:A.root_id||t,type:A.type,subType:A.subType,content:A.content||"",markdown:A.markdown||"",ial:m(A.id,A.ial),children:A.children}),x=async(A,F=0)=>{if(!A||F>8||!To(A))return;const E=await this.deps.getChildBlocks(A.id).catch(()=>[])||[];if(!(!Array.isArray(E)||E.length===0)){A.children=E.filter(D=>D==null?void 0:D.id).map(D=>({id:D.id,parent_id:A.id,root_id:t,type:D.type,subType:D.subType,content:D.content||"",markdown:D.markdown||"",ial:m(D.id,D.ial),children:[]}));for(const D of A.children)await x(D,F+1)}},_=new Map;for(const A of c)A!=null&&A.id&&_.set(A.id,A);const B=b.every(A=>{const F=_.get(A);return!F||!!F.type});let M=[],T=!1;if(h&&d.usable&&r&&B){this.fallbackWarnedDocId="";for(const[F,E]of d.leafPatch){const D=h.byId.get(F);D&&(D.content=E.content,D.markdown=E.markdown)}const A=new Map;for(const F of s)F!=null&&F.id&&A.set(F.id,F);for(const F of d.rebuildRoots){const E=h.byId.get(F),D=A.get(F);E&&D&&(E.content=D.content||"",E.markdown=D.markdown||""),await x(E)}for(const F of s){if(!(F!=null&&F.id)||h.byId.has(F.id))continue;const E=y(F);await x(E),h.byId.set(E.id,E),h.topLevel.push(E)}M=h.topLevel.filter(F=>l.has(F.id)).sort((F,E)=>(l.get(F.id)??0)-(l.get(E.id)??0))}else b.length>0?(T=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${b.length} 索引行=${c.length} 文档序=${o.length} 原因=${d.reason||"缺少实时文档序"}`)),M=s.map(A=>y(A))):h&&(M=h.topLevel);const w=async(A,F=0)=>{if(!(!A||A.length===0||F>8))for(const E of A){if(To(E)&&(!E.children||E.children.length===0)){let P=await this.deps.getChildBlocks(E.id).catch(()=>[]);if(!P||P.length===0){const X=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${E.id}' ORDER BY sort ASC, created ASC`;P=await this.deps.sql(X).catch(()=>[])||[]}if(Array.isArray(P)&&P.length>0){const X=new Set(M.map(W=>W.id)),G=P.filter(W=>W.id!==E.id&&!X.has(W.id));G.length>0&&(E.children=G.map(W=>{const se=p.get(W.id)||(W.ial?no(W.ial):{}),ae=this.attrOverrides.get(W.id);return ae&&Object.assign(se,ae),{id:W.id,parent_id:W.parent_id||E.id,root_id:W.root_id||t,type:W.type,subType:W.subType,content:W.content||"",markdown:W.markdown||"",ial:se}}))}}E.children&&E.children.length>0&&await w(E.children,F+1)}};T&&await w(M);const R=A=>{var F,E;for(const D of A)if(D.children&&D.children.length>0){R(D.children);for(const P of D.children)if(P.ial)for(const[X,G]of Object.entries(P.ial))X.startsWith("custom-slidev-")&&!((F=D.ial)!=null&&F[X])&&(D.ial||(D.ial={}),D.ial[X]=G);if(D.ial){for(const[P,X]of Object.entries(D.ial))if(P.startsWith("custom-slidev-"))for(const G of D.children)(G.type==="video"||G.type==="NodeVideo"||/<video\b/i.test(G.markdown||G.content||""))&&!((E=G.ial)!=null&&E[P])&&(G.ial||(G.ial={}),G.ial[P]=X)}}};R(M),Af(M,A=>{const F={[ge]:A.layout};this.setBlockAttrOverride(A.blockId,F),(this.deps.setBlockAttrs||He)(A.blockId,F).catch(D=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",D)})});const O=this.trackedListSuperBlocks.get(t)||[],N=Ef(t,M,{tracked:O,onTagChange:A=>{this.setBlockAttrOverride(A.blockId,A.attrs),A.blockId===t&&Object.assign(i,A.attrs);const F=D=>{for(const P of D)P.id===A.blockId&&(P.ial||(P.ial={}),Object.assign(P.ial,A.attrs)),P.children&&P.children.length>0&&F(P.children)};F(M),(this.deps.setBlockAttrs||He)(A.blockId,A.attrs).catch(D=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",D)})}});this.trackedListSuperBlocks.set(t,N.newTracked);const Z=new Set;for(const A of M){const F=A.markdown||A.content||"";if(F.includes("((")){const E=Wc(F);for(const D of E)Z.add(D.blockId)}}const S={};if(Z.size>0){const A=Array.from(Z).map(E=>`'${E}'`).join(","),F=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${A})`).catch(()=>[])||[];if(Array.isArray(F))for(const E of F)E.id&&(S[E.id]=E.markdown||E.content||"")}const z=this.deps.getBaseUrl?this.deps.getBaseUrl():"",k=Vr(t,i,M,{baseUrl:z,refContentMap:S});try{const A=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;k.customThemeCss=En(A)}catch{k.customThemeCss=En(null)}return k}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const n=Vr(t,{},[],{});return n.customThemeCss=En(null),n}}}const Pe=new Wf;class er{constructor(t){Se(this,"devServerUrl","http://localhost:3030");Se(this,"isConnected",!1);Se(this,"lastSyncTime",null);t&&(this.devServerUrl=t)}getUrl(){return this.devServerUrl}setUrl(t){this.devServerUrl=t.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(t=1500){try{const i=new AbortController,n=setTimeout(()=>i.abort(),t),s=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!s,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(t){const i=t.config,n=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.colorSchema&&i.colorSchema!=="auto"&&n.push(`colorSchema: ${i.colorSchema}`),n.push("drawings:","  persist: false","---","");const s=n.join(`
`),o=t.slides.map((r,a)=>{const c=r.frontmatter||{},d=[],p=a===0;c.layout&&c.layout!=="default"&&d.push(`layout: ${c.layout}`),c.transition&&d.push(`transition: ${c.transition}`),c.background&&d.push(`background: ${c.background}`),c.class&&d.push(`class: "${c.class}"`);let g="";d.length>0?g=p?"":`---
${d.join(`
`)}
---

`:p||(g=`---

`);let u="";if(c.layout==="two-cols"){const h=r.blocks.filter(_=>_.slot!=="right"),b=r.blocks.filter(_=>_.slot==="right"),y=h.map(_=>_.rawMarkdown||_.content||"").join(`

`),x=b.map(_=>_.rawMarkdown||_.content||"").join(`

`);u=`${y}

::right::

${x}`}else u=r.blocks.map(h=>h.rawMarkdown||h.content||"").join(`

`);let m="";return r.notes&&r.notes.trim()&&(m=`

<!--
${r.notes.trim()}
-->`),`${g}${u}${m}`}).join(`

`);let l="";return t.config.normalizeHeadingSizes&&(l=`

<style>
/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}
</style>`),`${s}${o}${l}
`}async syncToWorkspaceFile(t,i="/data/storage/petal/siyuan-slidev/slides.md",n){const s=this.buildStandardSlidevMarkdown(t);if(this.lastSyncTime=Date.now(),n)try{const o=typeof Blob<"u"?new Blob([s],{type:"text/markdown;charset=utf-8"}):Buffer.from(s,"utf-8");return await n(i,!1,o),{success:!0,path:i}}catch(o){return{success:!1,path:i,error:String(o)}}return{success:!0,path:i}}downloadSlidesMd(t,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(t),s=new Blob([n],{type:"text/markdown;charset=utf-8"}),o=URL.createObjectURL(s),l=document.createElement("a");return l.href=o,l.download=i,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(o),!0}}function Uf(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function $t(e){const t=Uf();if(t)try{return t(e)}catch{try{const i=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(i)}catch{}}}function tr(){var t;if(typeof window<"u"&&window.process)return window.process;const e=$t("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function _a(){var t,i;const e=tr();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const n=$t("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function Vf(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function Hn(){const e=tr();if(e!=null&&e.platform)return e.platform;if(typeof process<"u"&&process.platform)return process.platform;const t=$t("os");if(t&&typeof t.platform=="function")return t.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function Ca(){var n,s;const e=tr(),t={...(e==null?void 0:e.env)||{}};if(Hn()==="win32"){const o=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=e==null?void 0:e.env)!=null&&n.APPDATA?`${e.env.APPDATA}\\npm`:"",(s=e==null?void 0:e.env)!=null&&s.USERPROFILE?`${e.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(t).find(c=>c.toLowerCase()==="path")||"PATH",a=(t[l]||"").split(";").filter(Boolean);for(const c of o)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);t[l]=a.join(";")}return t}function Eo(e){var i,n,s;if(!e)return"";if(/^[a-zA-Z]:[/\\]/.test(e))return e.replace(/\\/g,"/");let t="";if(typeof window<"u"&&((s=(n=(i=window.siyuan)==null?void 0:i.config)==null?void 0:n.system)!=null&&s.dataDir)&&(t=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),t&&e.startsWith("/data/")){const o=e.slice(6);return`${t}/${o}`.replace(/\\/g,"/")}return e}function Kf(){const e=$t("os"),t=$t("path");if(e&&typeof e.tmpdir=="function"){const i=e.tmpdir();return t&&typeof t.join=="function"?t.join(i,"siyuan-slidev-pro").replace(/\\/g,"/"):`${i}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class ir{constructor(t){Se(this,"runner");this.runner=t||ir.defaultRunner}static async defaultRunner(t,i){var n;try{let s=(n=$t("child_process"))==null?void 0:n.execFile;if(!s){const a=await import("node:child_process").catch(()=>({}));s=a==null?void 0:a.execFile}if(!s)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=Hn()==="win32",r=Ca();return await new Promise(a=>{s(t,i,{timeout:5e3,shell:l,env:r},(c,d,p)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:p?String(p).trim():""})})})}catch(s){return{code:-1,stdout:"",stderr:String(s)}}}async detect(){const t=_a(),i=Hn();if(!t)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,s,o=!1,l;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,s=r.stdout)}catch{}if(n){try{const r=i==="win32"?"slidev.cmd":"slidev",a=await this.runner(r,["--version"]);a.code===0&&a.stdout&&(o=!0,l=a.stdout)}catch{}if(!o)try{const r=i==="win32"?"npx.cmd":"npx",a=await this.runner(r,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(o=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:s,hasSlidevCli:o,slidevVersion:l,platform:i,isDesktop:t}}}class Gf{constructor(){Se(this,"iframe",null);Se(this,"isReady",!1);Se(this,"pageChangedHandlers",[]);Se(this,"readyHandlers",[]);Se(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(t,i){var s;if(!((s=this.iframe)!=null&&s.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:t,...i};try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[NativeSlidevBridge] postMessage error:",o)}}navigateToPage(t){this.postMessage("navigate",{no:t})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(t){return this.pageChangedHandlers.push(t),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==t)}}onReady(t){return this.readyHandlers.push(t),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){const i=t.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(i.type==="update-state"&&i.navState){const n=i.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const s of this.pageChangedHandlers)s(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const n of this.pageChangedHandlers)n(i.no,this.currentState.total||1,this.currentState)}}}}class qf{constructor(t){Se(this,"childProcess",null);Se(this,"activePort",null);Se(this,"isRunning",!1);Se(this,"defaultPort");Se(this,"maxPortRetries");Se(this,"probeTimeoutMs");Se(this,"customSpawner");Se(this,"customPortChecker");this.defaultPort=(t==null?void 0:t.defaultPort)||3030,this.maxPortRetries=(t==null?void 0:t.maxPortRetries)||20,this.probeTimeoutMs=(t==null?void 0:t.probeTimeoutMs)||1e4,this.customSpawner=t==null?void 0:t.customSpawner,this.customPortChecker=t==null?void 0:t.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(t){if(this.customPortChecker)return this.customPortChecker(t);try{let i=$t("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(n=>{const s=i.createServer();s.once("error",()=>n(!1)),s.once("listening",()=>{s.close(()=>n(!0))}),s.listen(t,"127.0.0.1")}):!0}catch{return!0}}async allocPort(t){const i=t||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const s=i+n;if(await this.isPortAvailable(s))return s}return i}async pollServerReady(t,i=8e3,n=300){const s=Date.now();for(;Date.now()-s<i;){try{const o=new AbortController,l=setTimeout(()=>o.abort(),n),r=await fetch(t,{method:"HEAD",mode:"no-cors",signal:o.signal}).catch(()=>null);if(clearTimeout(l),r)return!0}catch{}await new Promise(o=>setTimeout(o,n))}return!1}async startServer(t,i){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(i);this.activePort=n;const o=Hn()==="win32"?"npx.cmd":"npx",l=Eo(t),r=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(o,r,{detached:!1});else{let p=(a=$t("child_process"))==null?void 0:a.spawn;if(!p){const m=await import("node:child_process").catch(()=>({}));p=m==null?void 0:m.spawn}if(!p)throw new Error("child_process spawn not available in current runtime");const g=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,u=Ca();this.childProcess=p(o,r,{cwd:g,detached:!1,shell:!0,env:{...u,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var t;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),Hn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(t=$t("child_process"))==null?void 0:t.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:s})=>{var o;s(`taskkill /pid ${(o=this.childProcess)==null?void 0:o.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class js{constructor(){Se(this,"iframe",null);Se(this,"isReady",!1);Se(this,"pendingMessages",[]);Se(this,"slideChangedHandlers",[]);Se(this,"blockClickedHandlers",[]);Se(this,"openInEditorHandlers",[]);Se(this,"clientReadyHandlers",[]);Se(this,"openPeekDrawerHandlers",[]);Se(this,"toggleFullscreenHandlers",[]);Se(this,"openPresenterHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(t,i){var s;const n={source:"siyuan-slidev-host",action:t,payload:i};if(!((s=this.iframe)!=null&&s.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[WebSandboxBridge] postMessage error:",o)}}updateSlides(t,i,n,s){this.postMessage("UPDATE_SLIDES",{slides:t,config:i,fullMarkdown:n,customThemeCss:s})}navigatePage(t,i){const n={pageIndex:t};typeof i=="number"&&(n.step=i),this.postMessage("NAVIGATE_PAGE",n)}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(i=>i!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){var n;const i=t.data;if(!(!i||i.source!=="siyuan-slidev-client"))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const s=this.pendingMessages.shift();s&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(s,"*")}for(const s of this.clientReadyHandlers)s();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const s of this.slideChangedHandlers)i.payload.currentStep!==void 0||i.payload.maxStep!==void 0?s(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"",i.payload.currentStep,i.payload.maxStep):s(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const s of this.blockClickedHandlers)s(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const s=i.payload.blockId||i.payload.clickedBlockId||"";for(const o of this.openInEditorHandlers)o(s,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const s=i.payload.blockId||i.payload.url||"",o={peekType:i.payload.peekType,target:s,title:i.payload.title};for(const l of this.openPeekDrawerHandlers)l(o)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const s of this.toggleFullscreenHandlers)s();break;case"OPEN_PRESENTER":for(const s of this.openPresenterHandlers)s();break}}}const $a={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},Zf=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,Yf=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,Jf=`<script setup lang="ts">
import { useSlots } from 'vue'

const slots = useSlots()
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-2 grid-rows-2 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
    </div>
  </div>
</template>
`,Xf=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slidev-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,Qf=`${Io}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function ep(e){var s;const t=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=i.exec(e))!==null;){const o=(s=n[1])==null?void 0:s.trim();o&&!t.includes(o)&&t.push(o)}return t}class tp{constructor(t){Se(this,"workspacePath");Se(this,"slidesFileName");Se(this,"cliBridge",new er);const i=Kf();!(t!=null&&t.workspacePath)||t.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=i:this.workspacePath=t.workspacePath,this.slidesFileName=(t==null?void 0:t.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(t="default"){const i={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return t&&t!=="default"&&(i.dependencies[`@slidev/theme-${t}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(t){return this.cliBridge.buildStandardSlidevMarkdown(t)}async scaffold(t,i){const n=this.buildSlidesMarkdown(t),s=this.generatePackageJson(t.config.theme),o=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,r=Eo(o),a=Eo(l),c=ep(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const _ of c){const B=$a[_]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${_}
// #endregion snippet
`;d.set(_,B)}t.slides.some(_=>{var B;return((B=_.frontmatter)==null?void 0:B.layout)==="cols-header"})&&d.set("layouts/cols-header.vue",Zf),t.slides.some(_=>{var B;return((B=_.frontmatter)==null?void 0:B.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",Yf),t.slides.some(_=>{var B;return((B=_.frontmatter)==null?void 0:B.layout)==="clover"})&&d.set("layouts/clover.vue",Jf),d.set("setup/root.ts",Xf),d.set("styles/index.css",Qf);const m=$t("fs"),h=$t("path");let b=!1;const y=h!=null&&h.dirname?h.dirname(r):"",x=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-slidev-pro");if(m&&h&&x)try{m.existsSync(y)||m.mkdirSync(y,{recursive:!0}),m.writeFileSync(a,s,"utf-8"),m.writeFileSync(r,n,"utf-8");for(const[_,B]of d.entries()){const M=h.join(y,_),T=h.dirname(M);m.existsSync(T)||m.mkdirSync(T,{recursive:!0}),m.existsSync(M)||m.writeFileSync(M,B,"utf-8")}b=!0}catch{}if(!b&&i)try{const _=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),B=typeof Blob<"u"?new Blob([s],{type:"application/json;charset=utf-8"}):Buffer.from(s,"utf-8");await i(l,!1,B),await i(o,!1,_);for(const[M,T]of d.entries()){const w=`${this.workspacePath}/${M}`,R=typeof Blob<"u"?new Blob([T],{type:"text/plain;charset=utf-8"}):Buffer.from(T,"utf-8");await i(w,!1,R).catch(()=>{})}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:l}}catch(_){return{success:!1,slidesPath:o,physicalSlidesPath:r,packageJsonPath:l,error:String(_)}}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:l}}}class ip{constructor(){Se(this,"mode","web-sandbox");Se(this,"webBridge");Se(this,"cliBridge");Se(this,"nativeBridge");Se(this,"processManager");Se(this,"scaffolder");Se(this,"envDetector");this.webBridge=new js,this.cliBridge=new er,this.nativeBridge=new Gf,this.processManager=new qf,this.scaffolder=new tp,this.envDetector=new ir}getMode(){return this.mode}setMode(t){this.mode=t}async startProMode(t,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const s=await this.scaffolder.scaffold(t,i);if(!s.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${s.error}`};const o=s.physicalSlidesPath||s.slidesPath,l=await this.processManager.startServer(o);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const np={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},sp={key:0},op={key:1},rp={key:2},lp={key:3},ap={key:4},cp={key:5},dp={key:6},up={key:7},fp={key:8},pp={key:9},hp={key:10},mp={key:11},gp={key:12},vp={key:13},bp={key:14},yp={key:15},kp={key:16},wp={key:17},xp={key:18},Sp={key:19},_p={key:20},Cp={key:21},$p={key:22},Ip={key:23},Tp={key:24},Ep={key:25},Ap={key:26},Bp={key:27},Mp={key:28},Dp={key:29},Lp={key:30},Pp={key:31},Op={key:32},Rp={key:33},Np={key:34},zp={key:35},Fp={key:36},Hp={key:37},jp={key:38},Wp={key:39},Up={key:40},Vp={key:41},Kp={key:42},Gp={key:43},qp={key:44},Zp={key:45},Yp={key:46},Jp={key:47},Xp={key:48},Qp={key:49},eh={key:50},th={key:51},ih={key:52},nh={key:53},sh={key:54},oh={key:55},rh={key:56},lh={key:57},ah={key:58},ch={key:59},dh={key:60},uh={key:61},fh={key:62},ph={key:63},hh={key:64},mh={key:65},gh={key:66},vh={key:67},bh={key:68},yh={key:69},kh={key:70},wh={key:71},xh=xt({__name:"SlidevIcon",props:{name:{}},setup(e){return(t,i)=>(J(),te("svg",np,[e.name==="fullscreen"||e.name==="maximize"?(J(),te("g",sp,[...i[0]||(i[0]=[f("polyline",{points:"15 3 21 3 21 9"},null,-1),f("polyline",{points:"9 21 3 21 3 15"},null,-1),f("polyline",{points:"21 15 21 21 15 21"},null,-1),f("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(J(),te("g",op,[...i[1]||(i[1]=[f("polyline",{points:"4 14 10 14 10 20"},null,-1),f("polyline",{points:"20 10 14 10 14 4"},null,-1),f("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),f("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(J(),te("g",rp,[...i[2]||(i[2]=[f("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),f("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(J(),te("g",lp,[...i[3]||(i[3]=[f("path",{d:"M12 20h9"},null,-1),f("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(J(),te("g",ap,[...i[4]||(i[4]=[f("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),f("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(J(),te("g",cp,[...i[5]||(i[5]=[f("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),f("polyline",{points:"15 3 21 3 21 9"},null,-1),f("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(J(),te("g",dp,[...i[6]||(i[6]=[f("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),f("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(J(),te("g",up,[...i[7]||(i[7]=[f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),f("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(J(),te("g",fp,[...i[8]||(i[8]=[f("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(J(),te("g",pp,[...i[9]||(i[9]=[f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(J(),te("g",hp,[...i[10]||(i[10]=[f("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),f("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(J(),te("g",mp,[...i[11]||(i[11]=[f("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),f("polyline",{points:"7 9 12 14 17 9"},null,-1),f("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(J(),te("g",gp,[...i[12]||(i[12]=[f("path",{d:"M2 3h20"},null,-1),f("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),f("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(J(),te("g",vp,[...i[13]||(i[13]=[f("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),f("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(J(),te("g",bp,[...i[14]||(i[14]=[f("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(J(),te("g",yp,[...i[15]||(i[15]=[f("path",{d:"M5 12h14"},null,-1),f("path",{d:"m12 5 7 7-7 7"},null,-1),f("path",{d:"M5 6h4"},null,-1),f("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(J(),te("g",kp,[...i[16]||(i[16]=[f("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),f("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="code"?(J(),te("g",wp,[...i[17]||(i[17]=[f("polyline",{points:"16 18 22 12 16 6"},null,-1),f("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="insert-above"?(J(),te("g",xp,[...i[18]||(i[18]=[f("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),f("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),f("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(J(),te("g",Sp,[...i[19]||(i[19]=[f("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),f("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),f("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(J(),te("g",_p,[...i[20]||(i[20]=[f("path",{d:"m18 15-6-6"},null,-1),f("path",{d:"M4 20h16"},null,-1),f("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(J(),te("g",Cp,[...i[21]||(i[21]=[f("path",{d:"M3 6h18"},null,-1),f("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),f("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(J(),te("g",$p,[...i[22]||(i[22]=[f("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(J(),te("g",Ip,[...i[23]||(i[23]=[vt('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-94a8372f></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-94a8372f></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-94a8372f></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-94a8372f></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-94a8372f></path>',5)])])):e.name==="ratio"?(J(),te("g",Tp,[...i[24]||(i[24]=[f("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(J(),te("g",Ep,[...i[25]||(i[25]=[f("path",{d:"M8 3 4 7l4 4"},null,-1),f("path",{d:"M4 7h16"},null,-1),f("path",{d:"m16 21 4-4-4-4"},null,-1),f("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(J(),te("g",Ap,[...i[26]||(i[26]=[f("polyline",{points:"16 16 12 12 8 16"},null,-1),f("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),f("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(J(),te("g",Bp,[...i[27]||(i[27]=[f("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),f("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),f("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(J(),te("g",Mp,[...i[28]||(i[28]=[f("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),f("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(J(),te("g",Dp,[...i[29]||(i[29]=[f("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),f("path",{d:"M21 3v5h-5"},null,-1),f("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),f("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(J(),te("g",Lp,[...i[30]||(i[30]=[f("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),f("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),f("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="outline"?(J(),te("g",Pp,[...i[31]||(i[31]=[f("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),f("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),f("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):e.name==="chevron-left"?(J(),te("g",Op,[...i[32]||(i[32]=[f("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(J(),te("g",Rp,[...i[33]||(i[33]=[f("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="chevrons-left"?(J(),te("g",Np,[...i[34]||(i[34]=[f("polyline",{points:"11 17 6 12 11 7"},null,-1),f("polyline",{points:"18 17 13 12 18 7"},null,-1)])])):e.name==="chevrons-right"?(J(),te("g",zp,[...i[35]||(i[35]=[f("polyline",{points:"13 17 18 12 13 7"},null,-1),f("polyline",{points:"6 17 11 12 6 7"},null,-1)])])):e.name==="play"?(J(),te("g",Fp,[...i[36]||(i[36]=[f("polygon",{points:"6 3 20 12 6 21 6 3"},null,-1)])])):e.name==="pause"?(J(),te("g",Hp,[...i[37]||(i[37]=[f("line",{x1:"10",y1:"4",x2:"10",y2:"20"},null,-1),f("line",{x1:"14",y1:"4",x2:"14",y2:"20"},null,-1)])])):e.name==="clock"?(J(),te("g",jp,[...i[38]||(i[38]=[f("circle",{cx:"12",cy:"12",r:"10"},null,-1),f("polyline",{points:"12 6 12 12 16 14"},null,-1)])])):e.name==="copy"?(J(),te("g",Wp,[...i[39]||(i[39]=[f("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),f("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"?(J(),te("g",Up,[...i[40]||(i[40]=[f("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),f("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),f("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(J(),te("g",Vp,[...i[41]||(i[41]=[f("circle",{cx:"11",cy:"11",r:"7"},null,-1),f("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(J(),te("g",Kp,[...i[42]||(i[42]=[f("circle",{cx:"12",cy:"12",r:"3"},null,-1),f("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(J(),te("g",Gp,[...i[43]||(i[43]=[vt('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-94a8372f></path><polyline points="14 2 14 8 20 8" data-v-94a8372f></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-94a8372f></line><line x1="16" y1="17" x2="8" y2="17" data-v-94a8372f></line><line x1="10" y1="9" x2="8" y2="9" data-v-94a8372f></line>',5)])])):e.name==="focus"||e.name==="target"?(J(),te("g",qp,[...i[44]||(i[44]=[f("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),f("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),f("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(J(),te("g",Zp,[...i[45]||(i[45]=[f("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),f("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),f("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),f("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(J(),te("g",Yp,[...i[46]||(i[46]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-94a8372f></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-94a8372f></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-94a8372f></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-94a8372f></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-94a8372f></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(J(),te("g",Jp,[...i[47]||(i[47]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-94a8372f></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-94a8372f></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-94a8372f></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-94a8372f></line><line x1="5" y1="15" x2="8" y2="15" data-v-94a8372f></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-94a8372f></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-94a8372f></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-94a8372f></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(J(),te("g",Xp,[...i[48]||(i[48]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-94a8372f></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-94a8372f></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-94a8372f></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-94a8372f></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-94a8372f></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-94a8372f></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-94a8372f></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(J(),te("g",Qp,[...i[49]||(i[49]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-94a8372f></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-94a8372f></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-94a8372f></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-94a8372f></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-94a8372f></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-94a8372f></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-94a8372f></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-94a8372f></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-94a8372f></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-94a8372f></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(J(),te("g",eh,[...i[50]||(i[50]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-94a8372f></rect><line x1="5" y1="7" x2="13" y2="7" data-v-94a8372f></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-94a8372f></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-94a8372f></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-94a8372f></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-94a8372f></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-94a8372f></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-94a8372f></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(J(),te("g",th,[...i[51]||(i[51]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-94a8372f></rect><line x1="12" y1="4" x2="12" y2="20" data-v-94a8372f></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-94a8372f></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-94a8372f></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-94a8372f></line><circle cx="15.5" cy="8.5" r="1.2" data-v-94a8372f></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-94a8372f></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(J(),te("g",ih,[...i[52]||(i[52]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-94a8372f></rect><line x1="12" y1="4" x2="12" y2="20" data-v-94a8372f></line><circle cx="6" cy="8.5" r="1.2" data-v-94a8372f></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-94a8372f></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-94a8372f></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-94a8372f></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-94a8372f></line>',7)])])):e.name==="layout-center"||e.name==="center"?(J(),te("g",nh,[...i[53]||(i[53]=[f("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),f("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),f("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(J(),te("g",sh,[...i[54]||(i[54]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-94a8372f></rect><circle cx="8" cy="9" r="1.5" data-v-94a8372f></circle><line x1="14" y1="8" x2="9" y2="14" data-v-94a8372f></line><circle cx="15" cy="13" r="1.5" data-v-94a8372f></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-94a8372f></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(J(),te("g",oh,[...i[55]||(i[55]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-94a8372f></rect><circle cx="7.5" cy="9.5" r="2" data-v-94a8372f></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-94a8372f></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-94a8372f></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-94a8372f></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-94a8372f></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(J(),te("g",rh,[...i[56]||(i[56]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-94a8372f></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-94a8372f></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-94a8372f></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-94a8372f></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-94a8372f></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(J(),te("g",lh,[...i[57]||(i[57]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(J(),te("g",ah,[...i[58]||(i[58]=[f("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),f("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(J(),te("g",ch,[...i[59]||(i[59]=[f("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),f("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),f("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(J(),te("g",dh,[...i[60]||(i[60]=[f("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),f("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(J(),te("g",uh,[...i[61]||(i[61]=[f("path",{d:"m17 1 4 4-4 4"},null,-1),f("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),f("path",{d:"m7 23-4-4 4-4"},null,-1),f("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(J(),te("g",fh,[...i[62]||(i[62]=[f("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),f("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),f("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(J(),te("g",ph,[...i[63]||(i[63]=[vt('<line x1="4" y1="21" x2="4" y2="14" data-v-94a8372f></line><line x1="4" y1="10" x2="4" y2="3" data-v-94a8372f></line><line x1="12" y1="21" x2="12" y2="12" data-v-94a8372f></line><line x1="12" y1="8" x2="12" y2="3" data-v-94a8372f></line><line x1="20" y1="21" x2="20" y2="16" data-v-94a8372f></line><line x1="20" y1="12" x2="20" y2="3" data-v-94a8372f></line><line x1="1" y1="14" x2="7" y2="14" data-v-94a8372f></line><line x1="9" y1="8" x2="15" y2="8" data-v-94a8372f></line><line x1="17" y1="16" x2="23" y2="16" data-v-94a8372f></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(J(),te("g",hh,[...i[64]||(i[64]=[f("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),f("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),f("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),f("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(J(),te("g",mh,[...i[65]||(i[65]=[f("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(J(),te("g",gh,[...i[66]||(i[66]=[f("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),f("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),f("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),f("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(J(),te("g",vh,[...i[67]||(i[67]=[f("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),f("path",{d:"m13 8 2 2"},null,-1),f("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(J(),te("g",bh,[...i[68]||(i[68]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-94a8372f></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-94a8372f></rect><line x1="13" y1="8" x2="19" y2="8" data-v-94a8372f></line><line x1="13" y1="12" x2="19" y2="12" data-v-94a8372f></line><line x1="13" y1="16" x2="17" y2="16" data-v-94a8372f></line>',5)])])):e.name==="image-right"?(J(),te("g",yh,[...i[69]||(i[69]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-94a8372f></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-94a8372f></rect><line x1="5" y1="8" x2="11" y2="8" data-v-94a8372f></line><line x1="5" y1="12" x2="11" y2="12" data-v-94a8372f></line><line x1="5" y1="16" x2="9" y2="16" data-v-94a8372f></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(J(),te("g",kh,[...i[70]||(i[70]=[f("circle",{cx:"12",cy:"12",r:"10"},null,-1),f("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),f("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(J(),te("g",wh,[...i[71]||(i[71]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Mt=(e,t)=>{const i=e.__vccOpts||e;for(const[n,s]of t)i[n]=s;return i},de=Mt(xh,[["__scopeId","data-v-94a8372f"]]);function et(e,t){var s;if(typeof document>"u"||!e)return;const i=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${i}"]`);!n||n.length===0||n.forEach(o=>{for(const[l,r]of Object.entries(t))r!=null&&r!==""?o.setAttribute(l,String(r)):o.removeAttribute(l)})}function Sh(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${ge}], .protyle-wysiwyg [${Ze}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,i=document.querySelectorAll(t);!i||i.length===0||i.forEach(n=>{const s=n.getAttribute("data-node-id");if(!s){n.removeAttribute(ge),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(Ze),n.removeAttribute("custom-slidev-role");return}const o=e.get(s),l=(o==null?void 0:o[ge])||(o==null?void 0:o["custom-slidev-layout"])||"",r=n.getAttribute(ge)||n.getAttribute("custom-slidev-layout");r&&r!==l&&(l?n.setAttribute(ge,l):(n.removeAttribute(ge),n.removeAttribute("custom-slidev-layout")));const a=(o==null?void 0:o[Ze])||(o==null?void 0:o["custom-slidev-role"])||"",c=n.getAttribute(Ze)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(Ze,a):(n.removeAttribute(Ze),n.removeAttribute("custom-slidev-role")))})}const _h={class:"spm-layout-picker"},Ch={class:"spm-layout-picker__grid"},$h=["title","onClick"],Ih={class:"spm-layout-icon"},Th={class:"spm-layout-label"},Eh=xt({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=e,n=t,s=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"4 项超级块 2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function o(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function l(r){n("update:modelValue",r),n("change",r)}return(r,a)=>(J(),te("div",_h,[a[0]||(a[0]=f("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),f("div",Ch,[(J(),te(Ue,null,ht(s,c=>f("div",{key:c.name,class:_e(["spm-layout-item",{active:o(c.name)}]),title:c.desc,onClick:d=>l(c.name)},[f("div",Ih,[re(de,{name:"layout-"+c.name},null,8,["name"])]),f("span",Th,ke(c.label),1)],10,$h)),64))])]))}}),Ia=Mt(Eh,[["__scopeId","data-v-1964d02c"]]),Ah={key:0,class:"spm-transition-selector__header"},Bh={class:"spm-transition-list"},Mh=["onClick"],Dh={class:"spm-transition-meta"},Lh={class:"spm-transition-label"},Ph={class:"spm-transition-name"},Oh={class:"spm-transition-preview-box"},Rh=xt({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=t,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function s(o){i("update:modelValue",o),i("change",o)}return(o,l)=>(J(),te("div",{class:_e(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?De("",!0):(J(),te("div",Ah,ke(e.title||"转场动效"),1)),f("div",Bh,[(J(),te(Ue,null,ht(n,r=>f("div",{key:r.name,class:_e(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:a=>s(r.name)},[f("div",Dh,[f("span",Lh,ke(r.label),1),f("span",Ph,"("+ke(r.name)+")",1)]),f("div",Oh,[f("div",{class:_e(["spm-anim-cube","anim-"+r.name])},null,2)])],10,Mh)),64))])],2))}}),nr=Mt(Rh,[["__scopeId","data-v-8597e99e"]]),Nh={class:"spm-divider-popover"},zh={class:"spm-divider-popover__title"},Fh={class:"spm-form-item"},Hh={class:"spm-popover-footer"},jh={class:"spm-save-hint"},Wh=xt({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(e,{emit:t}){var g,u,m;const i=e,n=t,s=pe(((g=i.initialAttrs)==null?void 0:g[ge])||"default"),o=pe(((u=i.initialAttrs)==null?void 0:u[tt])||"slide-left"),l=pe(((m=i.initialAttrs)==null?void 0:m[Ke])||""),r=pe("");ki(()=>i.initialAttrs,h=>{s.value=(h==null?void 0:h[ge])||"default",o.value=(h==null?void 0:h[tt])||"slide-left",l.value=(h==null?void 0:h[Ke])||""},{deep:!0});async function a(h,b){if(i.blockId){r.value="正在同步...",Pe.setBlockAttrOverride(i.blockId,{[h]:b}),et(i.blockId,{[h]:b});try{await He(i.blockId,{[h]:b}),r.value="已同步至块属性",n("updated",{[h]:b}),setTimeout(()=>{r.value=""},1500)}catch{r.value="同步失败"}}}function c(h){a(ge,h)}function d(h){a(tt,h)}function p(){a(Ke,l.value.trim())}return(h,b)=>(J(),te("div",Nh,[f("div",zh,[b[4]||(b[4]=f("span",null,"幻灯片页面设置",-1)),f("button",{class:"spm-close-btn",onClick:b[0]||(b[0]=y=>n("close"))},"✕")]),re(Ia,{modelValue:s.value,"onUpdate:modelValue":b[1]||(b[1]=y=>s.value=y),onChange:c},null,8,["modelValue"]),re(nr,{modelValue:o.value,"onUpdate:modelValue":b[2]||(b[2]=y=>o.value=y),onChange:d},null,8,["modelValue"]),f("div",Fh,[b[5]||(b[5]=f("label",{class:"spm-form-label"},"页面背景",-1)),Et(f("input",{"onUpdate:modelValue":b[3]||(b[3]=y=>l.value=y),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:p},null,544),[[Cs,l.value]])]),f("div",Hh,[f("span",jh,ke(r.value),1)])]))}}),Uh=Mt(Wh,[["__scopeId","data-v-e4871368"]]),Vh={class:"spm-slide-inspector"},Kh={class:"spm-inspector-header"},Gh={class:"spm-inspector-list"},qh=["onClick"],Zh={class:"spm-card-top"},Yh={class:"spm-card-badge"},Jh={class:"spm-card-layout"},Xh=["onClick"],Qh={class:"spm-card-preview"},em={key:0,class:"spm-card-notes",title:"演讲备忘录"},tm={class:"spm-inspector-modal-content"},im=xt({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(e,{emit:t}){const i=t,n=pe(null);function s(c){n.value=c}function o(c){const d={};return c.frontmatter.layout&&(d[ge]=c.frontmatter.layout),c.frontmatter.transition&&(d[tt]=c.frontmatter.transition),c.frontmatter.background&&(d[Ke]=c.frontmatter.background),c.notes&&(d[Ki]=c.notes),d}function l(c){n.value&&(c[ge]&&(n.value.frontmatter.layout=c[ge]),c[tt]&&(n.value.frontmatter.transition=c[tt]),c[Ke]&&(n.value.frontmatter.background=c[Ke]),c[Ki]&&(n.value.notes=c[Ki]),i("refresh"))}function r(c){i("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const d=c.blocks[0],p=d.content||d.rawMarkdown||"";return p.slice(0,40)+(p.length>40?"...":"")}return(c,d)=>(J(),te("div",Vh,[f("div",Kh,[f("span",null,"幻灯片大纲 ("+ke(e.slides.length)+" 页)",1)]),f("div",Gh,[(J(!0),te(Ue,null,ht(e.slides,p=>(J(),te("div",{key:p.pageIndex,class:_e(["spm-card",{active:e.currentActivePage===p.pageIndex}]),onClick:g=>r(p.pageIndex)},[f("div",Zh,[f("span",Yh,"P"+ke(p.pageIndex),1),f("span",Jh,ke(p.frontmatter.layout||"default"),1),f("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Lt(g=>s(p),["stop"])},[re(de,{name:"settings"})],8,Xh)]),f("div",Qh,ke(a(p)),1),p.notes?(J(),te("div",em,[re(de,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),f("span",null,ke(p.notes),1)])):De("",!0)],10,qh))),128))]),n.value?(J(),te("div",{key:0,class:"spm-inspector-modal-mask",onClick:d[1]||(d[1]=Lt(p=>n.value=null,["self"]))},[f("div",tm,[re(Uh,{"block-id":n.value.startBlockId,"initial-attrs":o(n.value),onClose:d[0]||(d[0]=p=>n.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):De("",!0)]))}}),nm=Mt(im,[["__scopeId","data-v-1b2a5ad6"]]),sm={class:"spm-immersion-header"},om={class:"spm-immersion-header__left"},rm={class:"spm-immersion-title"},lm={class:"spm-immersion-header__center"},am={class:"spm-immersion-header__actions"},cm=["aria-label"],dm={class:"spm-immersion-body"},um=xt({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const i=e,n=t;function s(){n("update:visible",!1),n("close")}function o(){i.closeOnClickMask&&s()}function l(){n("update:isMaximized",!i.isMaximized),n("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),s())}return(a,c)=>Et((J(),te("div",{class:_e(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:Lt(r,["stop"])},[f("div",{class:"spm-immersion-mask",onClick:o}),f("div",{class:_e(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[f("div",sm,[f("div",om,[Jn(a.$slots,"header-left",{},()=>[f("span",rm,ke(e.title),1)])]),f("div",lm,[Jn(a.$slots,"header-center",{},void 0)]),f("div",am,[Jn(a.$slots,"header-actions",{},void 0),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[re(de,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,cm),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:s},[re(de,{name:"close"})])])]),f("div",dm,[Jn(a.$slots,"default",{},void 0)])],2)],34)),[[Co,e.visible]])}}),fm=Mt(um,[["__scopeId","data-v-3f1665db"]]),pm={class:"spm-protyle-drawer"},hm={class:"spm-protyle-drawer__subbar"},mm={class:"spm-protyle-drawer__nav"},gm=["title"],vm={class:"spm-protyle-drawer__actions"},bm=["aria-label"],ym=["aria-label"],km=xt({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,s=pe(n.blockId),o=pe(n.title||""),l=pe(!1),r=pe(!0),a=pe(!1),c=pe(""),d=gi,p=pe([]),g=pe(null);let u=null;ki(()=>n.blockId,w=>{w&&w!==s.value&&(s.value=w,o.value=n.title||"",p.value=[],h(w))}),un(()=>{s.value&&h(s.value)}),Ko(()=>{b()});async function m(w){try{const R=await sn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${w}' LIMIT 1`);if(Array.isArray(R)&&R.length>0){const O=R[0];c.value=O.root_id||"";const N=O.id===O.root_id||O.type==="d";a.value=N,r.value=!N,!o.value&&O.content&&(o.value=O.content.trim().slice(0,30));return}}catch(R){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",R)}a.value=!1,r.value=!0}async function h(w,R){if(!g.value||!w)return;b(),await m(w),typeof R=="boolean"&&(r.value=!a.value&&R);let O,N;r.value&&!a.value?(O=["cb-get-all","cb-get-hl","cb-get-focus"],N={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(O=["cb-get-context","cb-get-hl"],N={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{u=new me.Protyle(n.plugin.app,g.value,{blockId:w,action:O,render:N}),!l.value&&u&&typeof u.disable=="function"&&u.disable()}catch(Z){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",Z)}}function b(){if(u){try{typeof u.destroy=="function"&&u.destroy()}catch(w){console.warn("[ProtylePeekDrawer] Error destroying protyle:",w)}u=null}g.value&&(g.value.innerHTML="")}function y(){a.value||(r.value=!r.value,h(s.value,r.value))}function x(){l.value=!l.value,u&&(l.value?(typeof u.enable=="function"&&u.enable(),typeof u.focus=="function"&&u.focus()):typeof u.disable=="function"&&u.disable())}function _(){if(s.value)try{me.openWindow({doc:{id:s.value},alwaysOnTop:!0})}catch(w){console.warn("[ProtylePeekDrawer] openWindow failed:",w)}}function B(){var O;if(!s.value)return;const w=Hs(),R=va(w.webServeUrl,s.value,{focus:!a.value});if(typeof window<"u"){const N=$t("electron");(O=N==null?void 0:N.shell)!=null&&O.openExternal?N.shell.openExternal(R).catch(()=>{window.open(R,"_blank")}):window.open(R,"_blank")}i("external-jump",R)}function M(){if(p.value.length>0){const w=p.value.pop();w&&(s.value=w.blockId,o.value=w.title,r.value=w.isFocusMode,a.value=w.isDoc,h(w.blockId,w.isFocusMode))}}function T(w){const R=w.target;if(!R)return;const O=R.closest('[data-type="block-ref"]');if(O){const Z=O.getAttribute("data-id");if(Z&&Z!==s.value){w.preventDefault(),w.stopPropagation(),p.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:a.value}),s.value=Z,o.value=O.innerText.trim()||Z,h(Z);return}}const N=R.closest("a");if(N&&N.href&&N.href.startsWith("siyuan://blocks/")){w.preventDefault(),w.stopPropagation();const Z=N.href.replace("siyuan://blocks/","").split("?")[0];Z&&Z!==s.value&&(p.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:a.value}),s.value=Z,o.value=N.innerText.trim()||Z,h(Z))}}return(w,R)=>(J(),te("div",pm,[f("div",hm,[f("div",mm,[p.value.length>0?(J(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:M},[re(de,{name:"arrow-left"}),R[0]||(R[0]=f("span",null,"返回",-1))])):De("",!0),f("span",{class:_e(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},ke(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),f("span",{class:"spm-protyle-id",title:o.value||s.value},ke(o.value||s.value),9,gm)]),f("div",vm,[a.value?De("",!0):(J(),te("button",{key:0,class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:y},[re(de,{name:r.value?"focus":"file-text"},null,8,["name"]),f("span",null,ke(r.value?"块聚焦":"展开全文"),1)],10,bm)),f("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:x},[re(de,{name:l.value?"edit":"eye"},null,8,["name"]),f("span",null,ke(l.value?"编辑中":"只读"),1)],10,ym),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:_},[re(de,{name:"window"}),R[1]||(R[1]=f("span",null,"独立窗口",-1))]),ye(d).enableWebServeJump?(J(),te("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:B},[re(de,{name:"external-link"}),R[2]||(R[2]=f("span",null,"外跳",-1))])):De("",!0)])]),f("div",{ref_key:"mountEl",ref:g,class:_e(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:T},null,2)]))}}),wm=Mt(km,[["__scopeId","data-v-7e586ef3"]]),xm=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,Sm=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function Kr(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(i)return`/assets/${i[1]}`;const n=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return n?`/plugins/${n[1]}`:null}function Ta(e){const t=(e||"").replace(/^file:\/\//i,"");let i=t;try{i=decodeURIComponent(t)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const n=i.indexOf("/");return n>=0?i.slice(n):i}function _m(e){const t=e.split(/[/?#]/)[0];return!t||Sm.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function Cm(e){const t=e.indexOf("#"),i=t>=0?e.slice(t):"",n=t>=0?e.slice(0,t):e,s=n.indexOf("?"),o=s>=0?n.slice(0,s):n,l=s>=0?n.slice(s+1):"";if(!/^\/?assets\/.+\.html?$/i.test(o))return e;const r=new URLSearchParams(l);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${o}?${r.toString()}${i}`)}function Ea(e){const t=$m(e);return t.external||!t.url?t:{url:Cm(t.url),external:!1}}function $m(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(dl(t))return{url:`/${ul(t)}`,external:!1};if(/^file:/i.test(t)){const n=Kr(Ta(t));return n?{url:n,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const n=Kr(t);return n?{url:n,external:!1}:{url:t,external:!0}}return xm.test(t)?{url:t,external:!0}:_m(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const Im={class:"spm-webview-drawer"},Tm={class:"spm-webview-toolbar"},Em={class:"spm-webview-toolbar__nav"},Am=["disabled"],Bm=["disabled"],Mm=["aria-label"],Dm={class:"spm-webview-toolbar__address"},Lm=["aria-label"],Pm={class:"spm-webview-toolbar__actions"},Om=["aria-label"],Rm={class:"spm-zoom-controller"},Nm=["disabled"],zm=["disabled"],Fm={key:1,class:"spm-webview-fallback"},Hm=["src"],jm={key:2,class:"spm-load-error"},Wm={class:"spm-load-error__code"},Um={class:"spm-load-error__code-num"},Vm={class:"spm-load-error__url"},Km={class:"spm-load-error__hint"},Gm={class:"spm-load-error__actions"},Gr="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",Aa="siyuan-slidev-peek-view-mode";let Ba="desktop";function qm(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(Aa);if(e==="mobile"||e==="desktop")return e}catch{}return Ba}function Zm(e){if(Ba=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(Aa,e)}catch{}}function Ym(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const Jm=xt({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,s=pe(_a()&&!Vf()),o=pe(n.url),l=pe(n.url),r=n.url,a=pe(!1),c=pe(null),d=pe(!1),p=pe(!1),g=pe(1),u=pe(!1),m=pe(qm());let h=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const b=we(()=>m.value==="mobile"?Gr:h||void 0),y=pe(null),x=pe(null);let _=null,B=null,M=null;ki(()=>n.url,Y=>{Y&&Y!==o.value&&(o.value=Y,l.value=Y,m.value==="mobile"&&N(!1),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(Y))}),ki(()=>n.visible,Y=>{if(Y)se(),m.value==="mobile"&&N(!1);else if(y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}}),un(()=>{T(),x.value&&typeof ResizeObserver<"u"&&(_=new ResizeObserver(()=>{const Y=y.value;if(Y&&typeof Y.invalidate=="function")try{Y.invalidate()}catch{}}),_.observe(x.value)),B=Y=>{var L;const fe=Y.message||((L=Y.error)==null?void 0:L.message);if(typeof fe=="string"&&fe.includes("Invalid guestInstanceId"))return Y.preventDefault(),Y.stopImmediatePropagation(),!0},window.addEventListener("error",B,!0),M=Y=>{const fe=Y.reason,L=typeof fe=="string"?fe:fe==null?void 0:fe.message;typeof L=="string"&&L.includes("Invalid guestInstanceId")&&Y.preventDefault()},window.addEventListener("unhandledrejection",M)}),Ko(()=>{if(w(),_&&(_.disconnect(),_=null),B&&(window.removeEventListener("error",B,!0),B=null),M&&(window.removeEventListener("unhandledrejection",M),M=null),y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}});function T(){const Y=y.value;Y&&(Y.addEventListener("dom-ready",R),Y.addEventListener("did-start-loading",Z),Y.addEventListener("did-stop-loading",k),Y.addEventListener("did-navigate",A),Y.addEventListener("did-navigate-in-page",F),Y.addEventListener("new-window",E),Y.addEventListener("did-fail-load",S),Y.addEventListener("did-fail-provisional-load",S))}function w(){const Y=y.value;if(Y)try{Y.removeEventListener("dom-ready",R),Y.removeEventListener("did-start-loading",Z),Y.removeEventListener("did-stop-loading",k),Y.removeEventListener("did-navigate",A),Y.removeEventListener("did-navigate-in-page",F),Y.removeEventListener("new-window",E),Y.removeEventListener("did-fail-load",S),Y.removeEventListener("did-fail-provisional-load",S)}catch{}}function R(){const Y=y.value;if(Y&&typeof Y.getUserAgent=="function"&&!h)try{const fe=Y.getUserAgent();fe&&!fe.includes("iPhone")&&(h=fe)}catch{}m.value==="mobile"&&N(!1),se(),D()}function O(){const Y=m.value==="mobile"?"desktop":"mobile";m.value=Y,Zm(Y),N(!0)}function N(Y=!1){const fe=y.value;if(!fe)return;const L=m.value==="mobile"?Gr:h;if(typeof fe.setUserAgent=="function"&&L)try{fe.setUserAgent(L)}catch(j){console.warn("[WebviewPeekDrawer] setUserAgent error:",j)}if(Y&&typeof fe.reload=="function")try{fe.reload()}catch(j){console.warn("[WebviewPeekDrawer] reload error:",j)}}function Z(){a.value=!0,c.value=null}function S(Y){if(Y&&Y.isMainFrame===!1||Y&&Number(Y.errorCode)===-3)return;const fe=String((Y==null?void 0:Y.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((Y==null?void 0:Y.errorCode)??0),description:fe,validatedURL:String((Y==null?void 0:Y.validatedURL)||o.value),hint:Ym(fe)},a.value=!1}function z(){c.value=null,G()}function k(){if(a.value=!1,D(),y.value&&typeof y.value.getURL=="function"){const Y=y.value.getURL();Y&&Y!=="about:blank"&&(o.value=Y,l.value=Y)}}function A(Y){Y!=null&&Y.url&&(o.value=Y.url,l.value=Y.url),D()}function F(Y){Y!=null&&Y.url&&(o.value=Y.url,l.value=Y.url),D()}function E(Y){Y&&Y.url&&(Y.preventDefault(),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(Y.url))}function D(){const Y=y.value;Y&&(typeof Y.canGoBack=="function"&&(d.value=Y.canGoBack()),typeof Y.canGoForward=="function"&&(p.value=Y.canGoForward()))}function P(){y.value&&typeof y.value.goBack=="function"&&y.value.goBack()}function X(){y.value&&typeof y.value.goForward=="function"&&y.value.goForward()}function G(){y.value&&typeof y.value.reload=="function"&&y.value.reload()}function W(){const Y=Ea(l.value);if(Y.url){if(Y.external){o.value=Y.url,ue();return}o.value=Y.url,l.value=Y.url,y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(Y.url)}}function se(){const Y=y.value;if(Y&&typeof Y.setZoomFactor=="function")try{Y.setZoomFactor(g.value)}catch(fe){console.warn("[WebviewPeekDrawer] setZoomFactor error:",fe)}}function ae(){g.value=Math.min(2.5,Math.round((g.value+.1)*10)/10),se()}function ce(){g.value=Math.max(.5,Math.round((g.value-.1)*10)/10),se()}function ve(){g.value=1,se()}function Te(Y){Y.preventDefault(),Y.deltaY<0?ae():Y.deltaY>0&&ce()}async function xe(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(o.value),u.value=!0,setTimeout(()=>{u.value=!1},2e3)}catch(Y){console.warn("Copy url failed:",Y)}}function ue(){var fe;const Y=o.value;if(typeof window<"u"){const L=$t("electron");(fe=L==null?void 0:L.shell)!=null&&fe.openExternal?L.shell.openExternal(Y).catch(()=>{window.open(Y,"_blank")}):window.open(Y,"_blank")}i("external-jump",Y)}return(Y,fe)=>{const L=eu("webview");return J(),te("div",Im,[f("div",Tm,[f("div",Em,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!d.value,"aria-label":"后退",onClick:P},[re(de,{name:"arrow-left"})],8,Am),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!p.value,"aria-label":"前进",onClick:X},[re(de,{name:"arrow-right"})],8,Bm),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":a.value?"正在加载...":"刷新页面",onClick:G},[re(de,{name:"refresh"})],8,Mm)]),f("div",Dm,[Et(f("input",{"onUpdate:modelValue":fe[0]||(fe[0]=j=>l.value=j),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:gf(W,["enter"])},null,544),[[Cs,l.value]]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":u.value?"已复制地址！":"复制网址",onClick:xe},[re(de,{name:"copy"})],8,Lm)]),f("div",Pm,[f("button",{class:_e(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":m.value==="mobile"}]),"aria-label":m.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:O},[re(de,{name:m.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Om),f("div",Rm,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:g.value<=.5,onClick:ce},[re(de,{name:"minus"})],8,Nm),f("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:ve},ke(Math.round(g.value*100))+"% ",1),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:g.value>=2.5,onClick:ae},[re(de,{name:"plus"})],8,zm)]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:ue},[re(de,{name:"external-link"}),fe[1]||(fe[1]=f("span",null,"外跳",-1))])])]),f("div",{ref_key:"containerEl",ref:x,class:_e(["spm-webview-body",{"is-mobile":m.value==="mobile"}]),onWheel:Lt(Te,["ctrl"])},[f("div",{class:_e(["spm-webview-viewport",{"is-mobile":m.value==="mobile"}])},[s.value?(J(),Pt(L,{key:0,ref_key:"webviewRef",ref:y,class:"spm-webview-frame",src:ye(r),useragent:b.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(J(),te("div",Fm,[f("iframe",{class:"spm-webview-fallback-frame",src:o.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Hm),f("div",{class:"spm-fallback-bar"},[fe[2]||(fe[2]=f("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),f("button",{class:"spm-icon-btn is-primary",onClick:ue}," 在新标签页中打开 ↗ ")])])),c.value?(J(),te("div",jm,[re(de,{name:"alert",class:"spm-load-error__icon"}),fe[5]||(fe[5]=f("div",{class:"spm-load-error__title"},"页面加载失败",-1)),f("div",Wm,[_t(ke(c.value.description)+" ",1),f("span",Um,"("+ke(c.value.errorCode)+")",1)]),f("div",Vm,ke(c.value.validatedURL),1),f("p",Km,ke(c.value.hint),1),f("div",Gm,[f("button",{class:"spm-icon-btn","aria-label":"重试",onClick:z},[re(de,{name:"refresh"}),fe[3]||(fe[3]=f("span",null,"重试",-1))]),f("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:ue},[re(de,{name:"external-link"}),fe[4]||(fe[4]=f("span",null,"用系统浏览器打开 ↗",-1))])])])):De("",!0)],2)],34)])}}}),Xm=Mt(Jm,[["__scopeId","data-v-192d3665"]]);class Qm{constructor(){Se(this,"timers",new Map)}debounce(t,i,n=150){this.cancel(t);const s=setTimeout(()=>{this.timers.delete(t),i()},n);this.timers.set(t,s)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class eg{constructor(t){Se(this,"blockToPageMap",new Map);Se(this,"debounceCtrl",new Qm);Se(this,"activeBlockId","");Se(this,"activePageIndex",1);Se(this,"currentDocId","");Se(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t}updateSlidesIndex(t){this.blockToPageMap.clear();for(const i of t){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const n of i.blocks)this.blockToPageMap.set(n.id,i.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;this.activeBlockId=t;let i=this.getPageByBlockId(t);!i&&(t===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t;const i=this.getPageByBlockId(t);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Ri(e,t){var o,l;if(!e||typeof document>"u")return!1;const i=(o=globalThis.CSS)!=null&&o.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!n){if(t)try{return me.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(r){console.warn("[SelectionMirror] openTab fallback failed:",r)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const s=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=s},1200),!0}function tg(e){if(!e)return"";const t=e.split(`
`).map(l=>l.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(l=>/^#{1,6}\s+/.test(l)))return t.map(l=>lt(l)).join("<br/>");const n=[];let s=[];const o=()=>{if(s.length>0){const l=s.map(r=>lt(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${l}</p>`),s=[]}};for(const l of t){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){o();const a=r[1].length,c=r[2].trim();n.push(`<h${a} class="slide-list-item-title">${lt(c)}</h${a}>`)}else s.push(l)}return o(),n.join(`
`)}function ig(e){if(e.length===0)return"";const t=[],i=e[0],n=i.match(/^(#{1,6})\s+(.*)$/);if(n){const s=n[1].length,o=n[2].trim();t.push(`<h${s} class="slide-list-item-title">${lt(o)}</h${s}>`)}else t.push(`<p class="slide-list-item-title">${lt(i)}</p>`);if(e.length>1){const s=e.slice(1);let o=[];const l=()=>{if(o.length>0){const r=o.map(a=>lt(a)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),o=[]}};for(const r of s){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,d=a[2].trim();t.push(`<h${c} class="slide-list-item-title">${lt(d)}</h${c}>`)}else o.push(r)}l()}return t.join(`
`)+(t.length>0?`
`:"")}function Ma(e,t,i){var g,u,m,h;const n=e.split(`
`);if(!n.some(b=>/^(\s*)([-*+]|\d+\.)\s+/.test(b)))return null;const o=[],l=[];let r=!1;for(let b=0;b<n.length;b++){const y=n[b];if(!y.trim())continue;const x=y.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(x){const T=x[1].length,w=Math.floor(T/2);l.push({type:"task",level:w,checked:x[2].toLowerCase()==="x",text:x[3],media:[]});continue}const _=y.match(/^(\s*)[-*+]\s+(.*)$/);if(_){const T=_[1].length,w=Math.floor(T/2);l.push({type:"unordered",level:w,text:_[2],media:[]});continue}const B=y.match(/^(\s*)\d+\.\s+(.*)$/);if(B){l.length===0&&(r=!0);const T=B[1].length,w=Math.floor(T/2);l.push({type:"ordered",level:w,text:B[2],media:[]});continue}const M=y.trim();if(!(!M||/^\{:.*?\}$/.test(M)))if(l.length>0){const T=M.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(T){const O=/\.gif(?:\?|$)/i.test(T[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${st(T[1])}" src="${T[2]}" class="${O}" /></div>`);continue}if(M.match(/^<img\b[\s\S]*?\/?>$/i)){const R=M.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${R}</div>`);continue}if(/<video\b/i.test(M)){let R=M;if(!/<\/video>/i.test(R))for(;b+1<n.length&&!/<\/video>/i.test(R);)b++,R+=" "+n[b].trim();const O=((g=i==null?void 0:i.attributes)==null?void 0:g["custom-slidev-autoplay"])==="true"||/autoplay/i.test(R),N=((u=i==null?void 0:i.attributes)==null?void 0:u["custom-slidev-loop"])==="true"||/loop/i.test(R),Z=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slidev-muted"])==="true"||O||/muted/i.test(R),S=((h=i==null?void 0:i.attributes)==null?void 0:h["custom-slidev-controls"])==="false",z=R.match(/\bsrc=["']([^"']+)["']/i),k=z?z[1]:"",A=['class="slide-video-player"'];S||A.push("controls"),O&&(A.push("autoplay"),A.push("playsinline")),N&&A.push("loop"),Z&&A.push("muted"),A.push('preload="metadata"'),k&&A.push(`src="${k}"`);const F=R.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let E=F?F[1].trim():"";!E&&k&&(E=`<source src="${k}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${O?"true":"false"}" data-muted="${Z?"true":"false"}"><video ${A.join(" ")}>${E}</video></div>`);continue}l[l.length-1].text+=`
`+M}else o.push(M)}if(l.length===0)return null;const a=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),d=l.map(b=>{const y=tg(b.text),x=b.media&&b.media.length>0?`
${b.media.join(`
`)}`:"",_=b.level||0,B=_>0?` style="margin-left:${(_*1.25).toFixed(2)}em;${b.type==="unordered"?`list-style-type:${_%2===1?"circle":"square"} !important;`:""}"`:"",M=_>0?" slide-list-item--nested":"";if(b.type==="task"){const w=b.checked?' checked=""':"";return`<li class="pdf-task-item${M}"${B}><label><input type="checkbox" disabled=""${w}/> <span>${y}</span></label>${x}</li>`}return`<li${M?` class="${M.trim()}"`:""}${B}>${y}${x}</li>`}).join(`
`);return`${ig(o)}<${a} class="${c}">
${d}
</${a}>`}function ng(e,t,i){const n=(t==null?void 0:t.containerClassName)||"pdf-block",s=e.split(/\r?\n/),o=[];let l=[];for(let c=0;c<s.length;c++){const d=s[c],p=d.trim();if(/^#{1,6}\s+/.test(p)){l.length>0&&(o.push(l.join(`
`)),l=[]),o.push(p);continue}if(!p){l.length>0&&(o.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(p)){l.length>0&&(o.push(l.join(`
`)),l=[]),o.push(p);continue}if(/<video\b/i.test(p)){l.length>0&&(o.push(l.join(`
`)),l=[]);let g=p;if(!/<\/video>/i.test(g))for(;c+1<s.length&&!/<\/video>/i.test(g);)c++,g+=`
`+s[c];o.push(g);continue}l.push(d)}l.length>0&&o.push(l.join(`
`));let r=!0;return o.map(c=>{var m,h,b,y;const d=c.trim();if(!d)return"";const p=d.match(/^(#{1,6})\s+(.*)$/);if(p){r=!1;const x=p[1].length;return`<h${x} class="slide-list-item-title">${lt(p[2].trim())}</h${x}>`}const g=d.match(/^!\[(.*?)\]\((.*?)\)$/);if(g){const x=/\.gif(?:\?|$)/i.test(g[2]),_=(t==null?void 0:t.imageClassName)||(x?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${st(g[1])}" src="${g[2]}" class="${_}" /></div>`}if(/<video\b/i.test(d)){const x=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slidev-autoplay"])==="true"||/autoplay/i.test(d),_=((h=i==null?void 0:i.attributes)==null?void 0:h["custom-slidev-loop"])==="true"||/loop/i.test(d),B=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slidev-muted"])==="true"||x||/muted/i.test(d),M=((y=i==null?void 0:i.attributes)==null?void 0:y["custom-slidev-controls"])==="false",T=d.match(/\bsrc=["']([^"']+)["']/i),w=T?T[1]:"",R=['class="slide-video-player"'];M||R.push("controls"),x&&R.push("autoplay playsinline"),_&&R.push("loop"),B&&R.push("muted"),R.push('preload="metadata"'),w&&R.push(`src="${w}"`);const O=d.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let N=O?O[1].trim():"";return!N&&w&&(N=`<source src="${w}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${x?"true":"false"}" data-muted="${B?"true":"false"}"><video ${R.join(" ")}>${N}</video></div>`}const u=Ma(d,t,i);if(u)return r=!1,u;if(r){r=!1;const x=d.split(/\r?\n/).map(T=>T.trim()).filter(Boolean);if(x.length===1)return`<p class="slide-list-item-title">${lt(x[0])}</p>`;const _=x[0],M=x.slice(1).map(T=>lt(T)).join("<br/>");return`<p class="slide-list-item-title">${lt(_)}</p>
<p class="slide-list-item-desc">${M}</p>`}return`<p class="slide-list-item-desc">${lt(d)}</p>`}).filter(Boolean).join(`
`)}function so(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function Da(e,t){var r,a,c,d,p,g,u,m;const i=((r=e.frontmatter)==null?void 0:r.layout)||"default",s=(e.blocks||[]).filter(h=>h.slot!=="slot-divider-right"),l=i==="cover"?null:s.find(so);if(i==="two-cols"){const h=s.some(Z=>Z.slot==="right");let b=[],y=[];if(h)b=s.filter(Z=>Z.slot!=="right"),y=s.filter(Z=>Z.slot==="right");else{const Z=Math.ceil(s.length/2);b=s.slice(0,Z),y=s.slice(Z)}const x=Z=>{const S=Z.filter(z=>!!(z.rawMarkdown||z.content||"").trim());if(S.length>0){const z=S[0],k=(z.rawMarkdown||z.content||"").trim();(zi(z)||/^(?:[-*+]|\d+\.)\s+/.test(k))&&(z.rawMarkdown=In(z.rawMarkdown||z.content||""),z.content=z.rawMarkdown)}};x(b),x(y);const _=b.map(Z=>pi(Z,t)).join(`
`),B=y.map(Z=>pi(Z,t)).join(`
`),M=(t==null?void 0:t.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",T=(a=e.frontmatter)!=null&&a.layoutClass?` ${e.frontmatter.layoutClass}`:"",w=(t==null?void 0:t.leftColClass)||"pdf-col pdf-col--left",R=(t==null?void 0:t.rightColClass)||"pdf-col pdf-col--right",N=`style="grid-template-columns: ${io((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${M}${T}" ${N}>
        <div class="${w}">${_}</div>
        <div class="${R}">${B}</div>
      </div>
    `}if(i==="clover"||Ln(i)){const h=i==="clover";let b=[];const y=s.filter(A=>A.slot==="header");if(y.length>0)b=y;else if(s.length>0){const A=s.find(F=>F.type==="h"&&(!F.slot||F.slot==="default"));A&&(b=[A])}const x=s.filter(A=>!b.includes(A));let _=2;if(h)_=4;else if(i==="three-cols-header")_=3;else if(i==="two-cols-header")_=2;else{let A=0;for(const F of x){const E=(F.slot||"").match(/^col-(\d+)$/i);E&&(A=Math.max(A,parseInt(E[1],10)))}if(A>=2)_=A;else if((d=e.frontmatter)!=null&&d.layoutRatio){const F=e.frontmatter.layoutRatio.trim();if(F.includes(":")){const E=F.split(":").map(D=>parseFloat(D.trim())).filter(D=>!isNaN(D)&&D>0);E.length>=2&&(_=E.length)}else{const E=F.split(/\s+/).filter(Boolean);E.length>=2&&(_=E.length)}}else x.length===1&&x[0].children&&x[0].children.length>=2&&(_=Math.min(6,x[0].children.length))}const B=Sa(x,_),M=x.some(A=>A.slot&&/^(?:col-\d+|left|right)$/i.test(A.slot)),T=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||Ln(i)&&M,w=A=>{const F=A.filter(D=>!!(D.rawMarkdown||D.content||"").trim());if(T&&F.length>0){const D=F[0],P=(D.rawMarkdown||D.content||"").trim();(zi(D)||/^(?:[-*+]|\d+\.)\s+/.test(P))&&(D.rawMarkdown=In(D.rawMarkdown||D.content||""),D.content=D.rawMarkdown),D.isColFirst=!0}const E=T?F.find(so):null;return F.map(D=>pi(D,{...t,extraClassName:D===E?"slidev-col-first-heading-block":""})).join(`
`)},R=b.find(so),O=b.map(A=>pi(A,{...t,extraClassName:A===R?"slidev-page-first-heading-block":""})).join(`
`),N=h?"repeat(2, minmax(0, 1fr))":io((p=e.frontmatter)==null?void 0:p.layoutRatio,_),Z=h?`style="grid-template-columns: ${N}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${N};"`,S=[h?"layout-clover-container":"layout-cols-header-container",_===2?"layout-two-cols-header-container":"",_===3?"layout-three-cols-header-container":"",`layout-${i}-container`,T?"has-superblock-cols":""].filter(Boolean).join(" "),z=[h?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",_===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",_===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",T?"has-superblock-cols":""].filter(Boolean).join(" "),k=B.map((A,F)=>{const E=F+1;return`<div class="${["pdf-col",_===2&&E===1?"pdf-col--left":"",_===2&&E===2?"pdf-col--right":"",`pdf-col--${E}`,`col-${E}`].filter(Boolean).join(" ")}">${w(A)}</div>`}).join(`
`);return`
      <div class="${S}">
        <div class="layout-header-section">${O}</div>
        <div class="${z}" ${Z}>
          ${k}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const h=i==="image-right",b=s.map(T=>pi(T,t)).join(`
`),y=((g=e.frontmatter)==null?void 0:g.image)||((u=e.frontmatter)==null?void 0:u.background)||"",x=`<div class="pdf-image-col" style="background-image:url('${st(y)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${st(y)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,_=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${b}</div>`,B=h?`${_}
${x}`:`${x}
${_}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${io((m=e.frontmatter)==null?void 0:m.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${B}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${s.map(b=>pi(b,t)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${s.map(b=>pi(b,t)).join(`
`)}</div>`:s.map(h=>pi(h,{...t,extraClassName:h===l?"slidev-page-first-heading-block":""})).join(`
`)}function st(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function sg(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,i=e.split("|");for(const n of i){const s=n.trim();if(s==="all")return"all";if(s.includes("-")){const[o,l]=s.split("-"),r=parseInt(o,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)t.add(c)}else{const o=parseInt(s,10);isNaN(o)||t.add(o)}}return t}const og=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function lt(e){if(!e)return"";const t=ka(e),i=[],n=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(o,l)=>{const r=l.toLowerCase();if(!og.has(r)||/on\w+\s*=|javascript:/i.test(o))return o;if(r==="v-mark"){const a=o.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return o.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(o),`%%SAFE_HTML_${i.length-1}%%`});let s=st(n);return s=s.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(o,l,r,a,c,d,p)=>{const u=(r??a??c??d??p??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${u}</a>`}),s=s.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(o,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),s=s.replace(/\[(.*?)\]\((.*?)\)/g,(o,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),s=s.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(o,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${r}</a>`),s=s.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),s=s.replace(/\*(.*?)\*/g,"<em>$1</em>"),s=s.replace(/~~(.*?)~~/g,"<del>$1</del>"),s=s.replace(/`([^`]+)`/g,"<code>$1</code>"),s=s.replace(/%%SAFE_HTML_(\d+)%%/g,(o,l)=>{const r=parseInt(l,10);return i[r]||""}),s}function rg(e,t="pdf-table"){if(e.length<2)return"";const i=e.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=i[0];let s=[],o=1;e.length>=2&&i[1].every(a=>/^:?-+:?$/.test(a))&&(s=i[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),o=2);const l=`<thead><tr>${n.map((a,c)=>`<th${s[c]?` style="text-align: ${s[c]}"`:""}>${lt(a)}</th>`).join("")}</tr></thead>`,r=i.slice(o).map(a=>`<tr>${a.map((c,d)=>`<td${s[d]?` style="text-align: ${s[d]}"`:""}>${lt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${l}<tbody>${r}</tbody></table>`}function oo(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function qr(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${oo(e)}</span>`;const i=[];function n(o,l){return i.push(`<span class="${o}">${oo(l)}</span>`),`__TOK_${i.length-1}__`}let s=e.replace(/(['"`])(.*?)\1/g,(o,l,r)=>n("token-string",`${l}${r}${l}`));return s=s.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,o=>n("token-keyword",o)),s=s.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,o=>n("token-type",o)),s=s.replace(/\b(\d+)\b/g,o=>n("token-number",o)),s=oo(s),s=s.replace(/__TOK_(\d+)__/g,(o,l)=>i[parseInt(l,10)]||""),s}function lg(e,t){if(!e)return null;const i=e.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let n=(i.title||"").trim(),s=i.level?parseInt(i.level,10):0;if(!n){const o=e.blocks||[];for(const l of o){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){s||(s=a[1].length),n=a[2].trim();break}}}return n?((!s||isNaN(s))&&(s=1),{pageIndex:e.pageIndex||t,title:n,level:s}):null}function ag(e,t=1,i={}){const n=i.minDepth!==void 0?Number(i.minDepth):1,s=i.maxDepth!==void 0?Number(i.maxDepth):1/0,o=[];Array.isArray(e)&&e.forEach((c,d)=>{const p=lg(c,d+1);p&&o.push(p)});const l=[];let r=null;for(const c of o){const d={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),r=d):r?(d.active&&(r.hasActiveChild=!0),r.children.push(d)):l.push(d)}function a(c,d=1){if(d>s)return[];const p=[];for(const g of c){const u=a(g.children,d+1);d>=n?p.push({...g,children:u}):p.push(...u)}return p}return a(l,1)}function cg(e,t=1,i={}){const n=ag(e,t,i),s=i.columns?Number(i.columns):1,o=s>1?` style="column-count: ${s};"`:"",l=i.textSm?" text-sm":"";function r(c,d=1){if(!c||c.length===0)return"";const p=`slidev-toc-list slidev-toc-list-level-${d}`,g=c.map(u=>{const m=u.active?" slidev-toc-item-active":u.hasActiveChild?" slidev-toc-item-parent-active":"",h=u.children&&u.children.length>0?r(u.children,d+1):"";let b=lt(u.title);return b.includes("LaTeX")&&(b=b.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${m}" data-page="${u.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${b}</span>
          </a>
          ${h}
        </li>
      `}).join("");return`<ol class="${p}">${g}</ol>`}const a=r(n,1);return`<div class="slidev-toc${l}"${o}>${a}</div>`}function pi(e,t){var M,T,w,R,O,N,Z,S,z,k;let i="",n="",s="";const o=[];(M=e.motion)!=null&&M.preset&&e.motion.preset!=="none"&&(i=` slidev-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&o.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&o.push(`--motion-delay:${e.motion.delay}ms`));const l=((T=e.attributes)==null?void 0:T.style)||"";l&&(o.push(l),s=" slide-styled-block"),o.length>0&&(n=` style="${st(o.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",a=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=t!=null&&t.blockClassResolver?t.blockClassResolver(e):"",d=c?` ${c}`:"",p=`${r}${i}${s}${a}${d}`,g=(e.rawMarkdown||e.content||"").trim();if(!g)return`<div class="${p}"${n}></div>`;if(g.includes('class="slidev-block-ref"')||g.includes('class="slidev-ref-tag"'))return`<div class="${p}"${n}>${g}</div>`;if(g.startsWith("$$")&&g.endsWith("$$")){const A=g.slice(2,-2).trim();return`<div class="${p} katex-display-container"${n}><div class="katex-display font-math"><em>${st(A)}</em></div></div>`}const u=g.match(/^(#{1,6})\s+(.*)$/);if(u){const A=u[1].length,F=lt(u[2]),D=!!(e.isColFirst||e.type==="i"&&((w=t==null?void 0:t.extraClassName)!=null&&w.includes("slidev-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${p}"${n}><h${A}${D}>${F}</h${A}></div>`}if(g.startsWith(":::")){const A=g.split(`
`),E=A[0].replace(/^:::\s*/,"").trim()||"info",D=A.slice(1,A[A.length-1].startsWith(":::")?-1:void 0).join(`
`),P=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${p}"${n}><div class="${P} ${P}--${E}"><div class="${P}-title">${E.toUpperCase()}</div><div class="${P}-body">${lt(D)}</div></div></div>`}if(g.startsWith("<<<")){const E=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((G,W)=>`<span class="code-line shiki-focus"><span class="line-no">${W+1}</span><span class="line-content">${qr(G,"ts")}</span></span>`).join(`
`),D=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",P=((R=e.attrs)==null?void 0:R["custom-slidev-max-height"])||e.maxHeight||"",X=P?` style="max-height:${st(P)};overflow-y:auto;"`:"";return`<div class="${p}"${n}><pre class="${D}"${X}><span class="lang-badge">TS</span><code>${E}</code></pre></div>`}if(g.startsWith("<style")||g.startsWith("<!-- Inline style -->")||g.startsWith(`<!--
Notes`))return"";if(g.startsWith("```")){const A=g.split(`
`),F=A[0].slice(3).trim(),E=F.match(/^([^\s{\[]+)/),D=E?E[1]:"",P=F.match(/\[([^\]]+)\]/),X=P?P[1]:"",G=F.includes("twoslash"),W=e.shikiLines||((O=F.match(/\{([^}]+)\}/))==null?void 0:O[1])||"",se=sg(W),ae=A.length>2?A[A.length-1]==="```"?A.slice(1,-1):A.slice(1):[g.slice(3).replace(/```$/,"")],ce=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",ve=X?`${ce} has-filename`:ce,Te=se!=="all",xe=ae.map((j,v)=>{const U=v+1,$=se==="all"||se.has(U)?"code-line shiki-focus":Te?"code-line shiki-dimmed":"code-line";let C=(t==null?void 0:t.highlight)===!0?qr(j,D):st(j);return G&&j.includes("doubled.value = 2")?(C=C.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${$}"><span class="line-no">${U}</span><span class="line-content">${C}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${$}"><span class="line-no">${U}</span><span class="line-content">${C}</span></span>`}).join(`
`),ue=D?`<span class="lang-badge">${st(D)}</span>`:"",Y=X?`<span class="code-filename">${st(X)}</span>`:"",fe=((N=e.attrs)==null?void 0:N["custom-slidev-max-height"])||e.maxHeight||"",L=fe?` style="max-height:${st(fe)};overflow-y:auto;"`:"";return`<div class="${p}"${n}><pre class="${ve}"${L}>${Y}${ue}<code>${xe}</code></pre></div>`}if(g.includes("|")&&g.split(`
`).filter(A=>A.trim().startsWith("|")).length>=2){const A=g.split(`
`).filter(E=>E.trim().startsWith("|")),F=rg(A,t==null?void 0:t.tableClassName);return`<div class="${p}"${n}>${F}</div>`}if(g.startsWith("> ")){const A=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${p}"${n}><blockquote class="${A}"><p>${lt(g.slice(2))}</p></blockquote></div>`}const m=/<video\b/i.test(g)||e.type==="video"||e.type==="NodeVideo",h=/^(\s*)([-*+]|\d+\.)\s+/m.test(g),b=/(?:^|\n)\s*#{1,6}\s+/.test(g);if(m&&!h&&!b&&!g.includes(`
`)){const A=((Z=e.attributes)==null?void 0:Z["custom-slidev-autoplay"])==="true"||/autoplay/i.test(g),F=((S=e.attributes)==null?void 0:S["custom-slidev-loop"])==="true"||/loop/i.test(g),E=((z=e.attributes)==null?void 0:z["custom-slidev-muted"])==="true"||A||/muted/i.test(g),D=((k=e.attributes)==null?void 0:k["custom-slidev-controls"])==="false",P=g.match(/\bsrc=["']([^"']+)["']/i),X=P?P[1]:"",G=['class="slide-video-player"'];D||G.push("controls"),A&&(G.push("autoplay"),G.push("playsinline")),F&&G.push("loop"),E&&G.push("muted"),G.push('preload="metadata"'),X&&G.push(`src="${X}"`);const W=g.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let se=W?W[1].trim():"";return!se&&X&&(se=`<source src="${X}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${p} ${p}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${A?"true":"false"}" data-muted="${E?"true":"false"}"${n}><video ${G.join(" ")}>${se}</video></div>`}const y=g.match(/^!\[(.*?)\]\((.*?)\)$/);if(y){const A=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${p} ${p}--image slide-media-block slide-media-container"${n}><img alt="${st(y[1])}" src="${y[2]}" class="${A}" /></div>`}const x=Ma(g,t,e);if(x)return`<div class="${p} pdf-list-item"${n}>${x}</div>`;if(/<(?:Toc|toc)\b/i.test(g)&&!g.startsWith("```")){const A=g.match(/minDepth=["']?(\d+)["']?/i),F=g.match(/maxDepth=["']?(\d+)["']?/i),E=g.match(/columns=["']?(\d+)["']?/i),D=(t==null?void 0:t.allSlides)||[];return`<div class="${p}"${n}>${cg(D,(t==null?void 0:t.currentPageIndex)||1,{minDepth:A?parseInt(A[1],10):1,maxDepth:F?parseInt(F[1],10):1/0,columns:E?parseInt(E[1],10):1,textSm:g.includes("text-sm")})}</div>`}if(g.includes(`
`)||b){const A=ng(g,t,e);if(A)return`<div class="${p}"${n}>${A}</div>`}const B=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${p}"${n}><p${B}>${lt(g)}</p></div>`}function dg(e){return`
    ${En(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slidev-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slidev-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slidev-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slidev-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slidev-padding-y, 32px)) !important;
      padding-left: var(--slidev-padding-x, 48px) !important;
      padding-right: var(--slidev-padding-x, 48px) !important;
      padding-bottom: var(--slidev-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slidev-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slidev-mask-body-container--has-mask:first-child,
    .slide-content > .slidev-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slidev-padding-y, 32px)) !important;
      padding-top: var(--slidev-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slidev-padding-x: 0px !important;
      --slidev-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slidev-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slidev-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slidev-mask-layer--solid .slidev-mask-overlay,
    .slidev-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slidev-mask-layer--solid .slidev-mask-overlay,
    [data-theme="dark"] .slidev-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slidev-mask-layer--blur .slidev-mask-overlay,
    .slidev-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slidev-mask-layer--blur .slidev-mask-overlay,
    [data-theme="dark"] .slidev-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slidev-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slidev-mask-layer--down .slidev-mask-divider-line,
    .slidev-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slidev-mask-layer--right .slidev-mask-divider-line,
    .slidev-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }`}function ug(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function fg(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slidev-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slidev-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slidev-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slidev-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slidev-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slidev-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slidev-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slidev-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slidev-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slidev-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slidev-overview-canvas *{scrollbar-width:none;}.slidev-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slidev-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slidev-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slidev-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slidev-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function pg(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr) {
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: 2, breakpoints: [50, 100] };
        }
        const clean = ratioStr.trim();
        if (!clean) return { steps: 2, breakpoints: [50, 100] };
        const parts = clean.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
        if (parts.length === 0) return { steps: 2, breakpoints: [50, 100] };
        if (parts.length === 1) {
          const val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        const isMonotonic = parts.every((val, idx) => idx === 0 || val > parts[idx - 1]);
        const maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(p => p > 10))) {
          const bps = parts.map(p => Math.min(100, Math.round(p * 100) / 100));
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        const totalWeight = parts.reduce((acc, cur) => acc + cur, 0);
        if (totalWeight <= 0) return { steps: 2, breakpoints: [50, 100] };
        let accumulated = 0;
        const bps = [];
        for (let i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex - 1);
      }

`}function hg(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

`}function mg(){return`      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        if (maskDir === "down" || maskDir === "right") {
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: maskDir,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          currentMaskStep = 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slidev-mask-layer slidev-mask-layer--" + currentMaskConfig.style + " slidev-mask-layer--" + currentMaskConfig.direction;
          const overlay = document.createElement("div");
          overlay.className = "slidev-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slidev-mask-divider-line";
          divider.style.opacity = "0";
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slidev-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slidev-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slidev-mask-body-container slidev-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slidev-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slidev-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slidev-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slidev-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function gg(){return`      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function vg(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function bg(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slidev-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slidev-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slidev-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background;
          if (bg) {
            if (/^(http|/|data:|assets/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slidev-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slidev-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slidev-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slidev-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slidev-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function yg(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slidev-viewport") || cur.classList.contains("slidev-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) return;
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slidev-lightbox-img, .slidev-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function kg(){return[ug(),fg(),pg(),hg(),mg(),gg(),vg(),bg(),yg()].join("")}function La(e,t){const i="Slidev 演示文稿";let n=e.slides;const s=JSON.stringify(n),o=JSON.stringify(e.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${st(i)}</title>
  <style>
${dg(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${s},
      config: ${o}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
    <div class="slide-viewport slidev-theme-${e.config.theme||"default"}" id="viewport" data-slidev-theme="${e.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${kg()}
  <\/script>
</body>
</html>`}function Pa(e,t){if(typeof document>"u")return!1;const i=new Blob([t],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(i),s=document.createElement("a");return s.href=n,s.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(n),!0}function wg(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function xg(e){const t=wg(e==null?void 0:e.pageRatio);return`
    ${En(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slidev-mask-layer,
      .slidev-mask-overlay,
      .slidev-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
      }
      .slidev-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function Sg(e,t){const i="Slidev 演示讲义",n="16:9",s="light",o=e.slides.map((l,r)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,d=c&&c!=="inherit"?c:e.config.spacing||"normal",p=Da(l),g=`${r+1} / ${e.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${s} spacing-${d}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${st(i)}</span>
          ${`<span class="pdf-page-badge">P. ${g}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${p}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${st(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${st(i)} - 高保真讲义</title>
  <style>
    ${xg({pageRatio:n,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
  ${o}
</body>
</html>`}function Oa(e,t){var s;if(typeof window>"u"||typeof document>"u")return!1;const i=Sg(e,t);try{const o=document.createElement("iframe");o.style.position="fixed",o.style.right="0",o.style.bottom="0",o.style.width="0",o.style.height="0",o.style.border="none",o.style.visibility="hidden",document.body.appendChild(o);const l=(s=o.contentWindow)==null?void 0:s.document;if(l)return l.open(),l.write(i),l.close(),setTimeout(()=>{var r,a;try{(r=o.contentWindow)==null||r.focus(),(a=o.contentWindow)==null||a.print()}finally{setTimeout(()=>{o.remove()},2e3)}},350),!0}catch(o){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",o)}const n=window.open("","_blank");return n?(n.document.write(i),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const _g=1500,Cg=500,$g=4,Ig=new Set(["INPUT","TEXTAREA","SELECT"]);function Ra(e){const t=e;return!t||!t.tagName?!1:Ig.has(t.tagName)||t.isContentEditable===!0}function Tg(e){let t="",i=!1,n=null,s=null;function o(){e.onStateChange&&e.onStateChange({display:t,invalid:i})}function l(){n&&(clearTimeout(n),n=null),s&&(clearTimeout(s),s=null)}function r(){l(),t="",i=!1,o()}function a(){n&&clearTimeout(n),n=setTimeout(r,_g)}function c(){n&&(clearTimeout(n),n=null),i=!0,o(),s&&clearTimeout(s),s=setTimeout(r,Cg)}function d(p){if(e.isEnabled&&!e.isEnabled()||Ra(p.target)||p.isComposing||p.ctrlKey||p.metaKey||p.altKey)return!1;if(/^[0-9]$/.test(p.key))return i||t.length>=$g||(t+=p.key,o(),a()),!0;if(p.key==="Enter"){if(!t||i)return!1;const u=parseInt(t,10),m=e.getTotalPages();return!isNaN(u)&&u>=1&&m>0&&u<=m?(r(),e.onJump(u),!0):(c(),!0)}return p.key==="Escape"&&(t||i)?(r(),!0):!1}return{handleKeydown:d,getState:()=>({display:t,invalid:i}),clear:r}}const Eg={class:"spm-slidev-tab__toolbar"},Ag={class:"spm-slidev-tab__nav"},Bg=["disabled"],Mg={class:"spm-page-badge"},Dg=["disabled"],Lg=["aria-label"],Pg=["aria-label"],Og={class:"spm-slidev-tab__tools"},Rg=["src"],Ng=xt({__name:"SlidevPreviewTab",setup(e,{expose:t}){const i=Rt("plugin"),n=Rt("sandboxBridge",new js),s=new eg(n),o=new ip,l=pe("web-sandbox"),r=pe(3030),a=pe(null),c=pe(!1),d=pe(null),p=pe(1),g=pe(1),u=pe([]),m=pe(!1),h=pe(!1),b=pe(!1),y=pe("siyuan"),x=pe(""),_=pe(""),B=pe(""),M=pe(!1),T=pe(!1),w=pe(""),R=pe(""),O=pe(!1),N=Tg({getTotalPages:()=>g.value,isEnabled:()=>!h.value,onJump:C=>z(C),onStateChange:C=>{R.value=C.display,O.value=C.invalid}});function Z(C){if(C.key==="o"||C.key==="O"){if(h.value||C.isComposing||C.ctrlKey||C.metaKey||C.altKey||Ra(C.target))return;C.preventDefault(),S();return}N.handleKeydown(C)&&C.preventDefault()}function S(){var C,V;if(l.value==="pro-cli"){(C=d.value)==null||C.focus(),me.showMessage("Pro 模式使用官方原生总览：在画面内按 O 呼出");return}n.toggleOverview(),(V=d.value)==null||V.focus()}function z(C){var V;p.value=C,l.value==="pro-cli"?o.nativeBridge.navigateToPage(C):n.navigatePage(C),(V=d.value)==null||V.focus()}const k=pe("/plugins/siyuan-slidev/slidev-client/index.html");let A=null,F=null,E=null,D=null,P=null,X=null,G=null,W=null;un(()=>{d.value&&(n.attach(d.value),o.nativeBridge.attach(d.value)),A=n.onSlideChanged((C,V)=>{p.value=C,g.value=V}),F=n.onBlockClicked((C,V)=>{p.value=V,s.setActiveBlockId(C),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide(C,V):Ri(C,i==null?void 0:i.app)}),E=n.onOpenInEditor((C,V)=>{p.value=V,s.setActiveBlockId(C),Ri(C,i==null?void 0:i.app)}),D=o.nativeBridge.onPageChanged((C,V)=>{p.value=C,g.value=V}),P=n.onOpenPeekDrawer(async C=>{const V=Hs();if(C.peekType==="siyuan"&&V.enableWebServeJump){let q=!1;if(W&&W.docId===C.target)q=!0;else if(W&&W.slides&&W.slides.some(K=>{var ee;return(ee=K.blocks)==null?void 0:ee.some(le=>le.id===C.target)}))q=!1;else try{const K=await sn(`SELECT id, root_id, type FROM blocks WHERE id = '${C.target}' LIMIT 1`);K&&K.length>0&&(q=K[0].type==="d"||K[0].id===K[0].root_id)}catch(K){console.warn("[SlidevPreviewTab] detect block type failed:",K)}y.value="web",M.value=!0,_.value=va(V.webServeUrl,C.target,{focus:!q}),B.value=C.title||`${q?"思源文档":"思源块"}: ${C.target.slice(0,8)}`,h.value=!0,n.freezeKeyboardNav(!0)}else{if(y.value=C.peekType,C.peekType==="siyuan")x.value=C.target,B.value=C.title||`块速览: ${C.target.slice(0,8)}`;else{const q=Ea(C.target);if(q.external){j(C.target);return}M.value=!0,_.value=q.url,B.value=C.title||q.url}h.value=!0,n.freezeKeyboardNav(!0)}}),X=n.onRequestToggleFullscreen(()=>{U()}),G=n.onOpenPresenter(()=>{H()}),typeof document<"u"&&document.addEventListener("fullscreenchange",v)}),Rs(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",v),P&&P(),X&&X(),G&&G(),A&&A(),F&&F(),E&&E(),D&&D(),n.detach(),N.clear(),s.destroy(),o.destroy()});async function se(){if(l.value==="web-sandbox"){if(!W){me.showMessage("请先在主编辑区打开演示文档");return}me.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const C=await o.startProMode(W,fo);if(!C.success){me.showMessage(`无法启动官方 Pro 模式：${C.error}`);return}l.value="pro-cli",r.value=C.port||3030,k.value=C.url,d.value&&o.nativeBridge.attach(d.value),me.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else o.stopProMode(),l.value="web-sandbox",k.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&n.attach(d.value),me.showMessage("已切回内置高保真沙箱")}function ae(){T.value=!T.value,T.value?(w.value=(W==null?void 0:W.docId)||"",i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",w.value)):(w.value="",Y(),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader())}let ce=0;function ve(C){if(h.value||Math.abs(C.deltaY)<Math.abs(C.deltaX)||Math.abs(C.deltaY)<15)return;const V=Date.now();V-ce<280||(ce=V,C.deltaY>0?xe():Te())}function Te(){if(p.value>1){const C=p.value-1;p.value=C,l.value==="pro-cli"?o.nativeBridge.navigateToPage(C):n.navigatePage(C)}}function xe(){if(p.value<g.value){const C=p.value+1;p.value=C,l.value==="pro-cli"?o.nativeBridge.navigateToPage(C):n.navigatePage(C)}}function ue(C){p.value=C,l.value==="pro-cli"?o.nativeBridge.navigateToPage(C):n.navigatePage(C)}function Y(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slidev:request-compile")}function fe(){h.value=!1,n.freezeKeyboardNav(!1)}function L(){fe()}function j(C){var ee,le;const V=/^file:/i.test(C),q=V||/^[a-zA-Z]:[\\/]/.test(C),K=$t("electron");if(q&&typeof((ee=K==null?void 0:K.shell)==null?void 0:ee.openPath)=="function"){K.shell.openPath(V?Ta(C):C),me.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((le=K==null?void 0:K.shell)==null?void 0:le.openExternal)=="function"?K.shell.openExternal(C).catch(()=>{typeof window<"u"&&window.open(C,"_blank")}):typeof window<"u"&&window.open(C,"_blank"),me.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function v(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function U(){const C=a.value||d.value;C&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):C.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function H(){i&&typeof i.openPresenterTab=="function"&&i.openPresenterTab()}function $(){if(!W){me.showMessage("请先在主编辑区打开幻灯片文档");return}const C=La(W);Pa("presentation.html",C)&&me.showMessage("已开始下载单文件离线 HTML 演示包")}function I(){if(!W){me.showMessage("请先在主编辑区打开幻灯片文档");return}Oa(W)&&me.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return t({updateDocument(C,V){T.value&&w.value&&V&&V!==w.value||(W=C,T.value&&!w.value&&(w.value=C.docId),u.value=C.slides,g.value=C.slides.length,s.setDocId(C.docId),s.updateSlidesIndex(C.slides),l.value==="pro-cli"?o.scaffolder.scaffold(C,fo).catch(()=>{}):n.updateSlides(C.slides,C.config,C.fullMarkdown,C.customThemeCss),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",C.docId))},navigateToBlock(C){s.onCursorFocusBlock(C)},isPinned:T,pinnedDocId:w,engineMode:l,toggleEngineMode:se}),(C,V)=>(J(),te("div",{class:"spm-slidev-preview-tab",onKeydown:Z},[f("div",Eg,[f("div",Ag,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value<=1,"aria-label":"上一页",onClick:Te},[re(de,{name:"chevron-left"})],8,Bg),f("span",Mg,ke(p.value)+" / "+ke(g.value||1),1),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value>=g.value,"aria-label":"下一页",onClick:xe},[re(de,{name:"chevron-right"})],8,Dg),f("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":T.value}]),"aria-label":T.value?"已锁定当前文档（点击解除）："+w.value:"点击锁定当前文档（不随主编辑区切换）",onClick:ae},[re(de,{name:"pin"}),f("span",null,ke(T.value?"已锁定":"跟随"),1)],10,Lg),f("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:se},[re(de,{name:"rocket"}),f("span",null,ke(l.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,Pg)]),f("div",Og,[f("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":m.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:V[0]||(V[0]=q=>m.value=!m.value)},[re(de,{name:"outline"})],2),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:S},[re(de,{name:"columns"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:H},[re(de,{name:"presenter"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:$},[re(de,{name:"export-html"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:I},[re(de,{name:"export-pdf"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:Y},[re(de,{name:"refresh"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:U},[re(de,{name:"fullscreen"})])])]),f("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container",onWheel:ve},[f("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:k.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Rg),re(fm,{visible:h.value,"onUpdate:visible":V[1]||(V[1]=q=>h.value=q),"is-maximized":b.value,"onUpdate:isMaximized":V[2]||(V[2]=q=>b.value=q),title:B.value,onClose:fe},{default:Fl(()=>[y.value==="siyuan"&&x.value?(J(),Pt(wm,{key:0,"block-id":x.value,title:B.value,plugin:ye(i),onExternalJump:L},null,8,["block-id","title","plugin"])):De("",!0),M.value?Et((J(),Pt(Xm,{key:1,visible:h.value&&y.value==="web",url:_.value,title:B.value,onExternalJump:L},null,8,["visible","url","title"])),[[Co,y.value==="web"]]):De("",!0)]),_:1},8,["visible","is-maximized","title"]),Et(f("div",{class:_e(["spm-jump-badge",{"is-invalid":O.value}])},ke(R.value),3),[[Co,R.value]])],544),m.value&&u.value.length>0?(J(),Pt(nm,{key:0,slides:u.value,"current-active-page":p.value,onNavigate:ue,onRefresh:Y},null,8,["slides","current-active-page"])):De("",!0)],32))}}),zg=Mt(Ng,[["__scopeId","data-v-3d9b9312"]]);function Na(e){if(!e||e.length===0)return{maxStep:0,blockMap:new Map,idMap:new Map};const t=new Map,i=new Map,n=new Map;let s=0;const o=(r,a)=>{t.set(r,a);const c=r.id||r.blockId;c&&i.set(c,a)},l=e.filter(r=>r.slot!=="slot-divider-right");for(const r of l){if(r.parentContainerId&&r.parentClicks&&r.parentClicks.trim()!==""&&!n.has(r.parentContainerId)){const p=String(r.parentClicks).trim();if(/^\d+$/.test(p)){const g=parseInt(p,10);s=Math.max(s,g),n.set(r.parentContainerId,g)}else s+=1,n.set(r.parentContainerId,s)}if(!!!(r.clicks&&String(r.clicks).trim()!=="")){if(r.parentContainerId&&n.has(r.parentContainerId)){const p=n.get(r.parentContainerId);o(r,{type:"step",step:p})}else o(r,{type:"always"});continue}const c=String(r.clicks).trim();if(!c){s+=1,o(r,{type:"step",step:s});continue}if(c.startsWith("[")&&c.endsWith("]"))try{const p=JSON.parse(c);if(Array.isArray(p)&&p.length>=2){const g=Math.min(Number(p[0]),Number(p[1])),u=Math.max(Number(p[0]),Number(p[1]));if(!isNaN(g)&&!isNaN(u)){s=Math.max(s,u),o(r,{type:"range",min:g,max:u});continue}}}catch{}if(c.toLowerCase()==="hide"){s+=1,o(r,{type:"hide",step:s});continue}if(/^\+\d+$/.test(c)||c==="true"){const p=c==="true"?1:parseInt(c.slice(1),10)||1;s+=p,o(r,{type:"step",step:s});continue}if(/^-\d+$/.test(c)){const p=parseInt(c.slice(1),10)||1;s=Math.max(1,s-p),o(r,{type:"step",step:s});continue}if(/^\d+$/.test(c)){const p=parseInt(c,10);if(!isNaN(p)){s=Math.max(s,p),o(r,{type:"step",step:p});continue}}const d=parseInt(c,10);!isNaN(d)&&d>0?(s=Math.max(s,d),o(r,{type:"step",step:d})):(s+=1,o(r,{type:"step",step:s}))}return{maxStep:s,blockMap:t,idMap:i}}function Fg(e,t,i){if(!e)return"v-click-visible";const n=e.id||e.blockId,s=i.blockMap.get(e)||(n?i.idMap.get(n):null);return!s||s.type==="always"?"v-click-visible":s.type==="range"?t>=s.min&&t<=s.max?"v-click-visible":"v-click-hidden":s.type==="hide"?t<s.step?"v-click-visible":"v-click-hidden":s.type==="step"?t>=s.step?"v-click-visible":"v-click-hidden":"v-click-visible"}const Ao=980;function Hg(e){if(!e)return 0;const i=Na(e.blocks||[]).maxStep||0,n=e.frontmatter||{},s=n.mask;if(s!=="down"&&s!=="right")return i;const o=Vc(n.maskRatio),r=n.maskInitial==="revealed"?Math.max(0,o.steps-1):o.steps;return Math.max(i,r)}function jg(e,t=Ao){const i=(e||"16/9").trim();let n=16/9;if(i==="4/3"||i==="4:3")n=4/3;else if(i==="16/10"||i==="16:10")n=16/10;else if(i.includes("/")||i.includes(":")){const o=i.includes("/")?"/":":",l=i.split(o).map(r=>parseFloat(r.trim()));l.length===2&&l[0]>0&&l[1]>0&&!isNaN(l[0])&&!isNaN(l[1])&&(n=l[0]/l[1])}else{const o=parseFloat(i);!isNaN(o)&&o>.2&&o<5&&(n=o)}const s=Math.ceil(t/n);return{baseWidth:t,baseHeight:s,ratio:n}}function Zr(e,t,i=Ao,n=552,s=16){const o=i>0?i:Ao,l=n>0?n:552,r=Math.max(0,e-s),a=Math.max(0,t-s);if(r<=0||a<=0)return{scale:.36,boxWidth:Math.round(o*.36),boxHeight:Math.round(l*.36)};const c=Math.min(r/o,a/l),d=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:d,boxWidth:Math.max(1,Math.round(o*d)),boxHeight:Math.max(1,Math.round(l*d))}}function Wg(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0,motion:t.motion?{...t.motion}:void 0,children:Array.isArray(t.children)?t.children.map(i=>({...i,attrs:i.attrs?{...i.attrs}:void 0,attributes:i.attributes?{...i.attributes}:void 0})):void 0})):[]}}function Yr(e,t){if(!e)return"";const i=Wg(e),n=i.frontmatter||{},s=n.layout||"default",o=(t==null?void 0:t.config)||{};(s==="image-right"||s==="image-left")&&!n.image&&!n.background&&o.image&&(n.image=o.image);const l=typeof(t==null?void 0:t.currentStep)=="number",r=l?Math.max(0,t.currentStep):0,a=l?Na(i.blocks||[]):null,d=Da(i,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(t==null?void 0:t.allSlides)||[],currentPageIndex:(t==null?void 0:t.pageIndex)||i.pageIndex||1,highlight:!0,blockClassResolver:a?_=>{if(Fg(_,r,a)==="v-click-hidden")return"presenter-v-click-pending";if(r>0){const M=_.id||_.blockId,T=a.blockMap.get(_)||(M?a.idMap.get(M):void 0);if((T==null?void 0:T.type)==="step"&&T.step===r||(T==null?void 0:T.type)==="range"&&T.min===r)return"presenter-v-click-active"}return""}:void 0}).replace(/<video\b([^>]*)>/gi,(_,B)=>{let M=B.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test(M)||(M+=" muted"),`<video ${M.trim()}>`}),p=n.spacing,g=p&&p!=="inherit"?p:o.spacing||"normal",u=["slide-content",`layout-${s}`,`spacing-${g}`,n.class||"",n.layoutClass||""].filter(Boolean).join(" "),m=[],h=(n.background||"").trim();if(h)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(h)){const _=h.startsWith("assets/")?`/${h}`:h.startsWith("./assets/")?h.slice(1):h;m.push(`background-image:url('${st(_)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else m.push(`background:${st(h)};`);const b=typeof n.zoom=="number"?n.zoom:typeof n.zoom=="string"?parseFloat(n.zoom):1,y=!isNaN(b)&&b>0?b:1;y!==1&&m.push(`width:${(100/y).toFixed(2)}%;height:${(100/y).toFixed(2)}%;transform-origin:top left;transform:scale(${y});`);const x=m.length>0?` style="${m.join("")}"`:"";return`<div class="${st(u)}"${x}>${d}</div>`}const Ug={class:"presenter-header"},Vg={class:"presenter-title-area"},Kg={class:"presenter-brand"},Gg={class:"header-pills"},qg={class:"pill pill-page"},Zg={key:0,class:"pill pill-step"},Yg={class:"header-toolbar"},Jg={class:"timer-capsule"},Xg={class:"timer-digits"},Qg={class:"timer-actions"},ev=["aria-label"],tv={class:"wall-clock b3-tooltips b3-tooltips__sw","aria-label":"系统当前时间"},iv={key:0,class:"presenter-grid"},nv={class:"slide-panels"},sv={class:"panel-box current-slide-panel"},ov={class:"panel-header"},rv={class:"panel-header-left"},lv={class:"panel-page-num"},av={class:"panel-header-meta"},cv={key:0,class:"panel-step-pill"},dv={class:"panel-layout-pill"},uv=["aria-label"],fv=["data-theme","data-slidev-theme","data-normalize-headings","innerHTML"],pv={key:1,class:"panel-fallback"},hv=["aria-label"],mv={class:"panel-header"},gv={class:"panel-header-left"},vv={key:0,class:"panel-page-num"},bv={class:"panel-header-meta"},yv={key:0,class:"panel-end-pill"},kv={key:1,class:"panel-layout-pill"},wv=["aria-label"],xv=["data-theme","data-slidev-theme","data-normalize-headings","innerHTML"],Sv={key:1,class:"panel-fallback"},_v={class:"notes-panel"},Cv={class:"panel-header"},$v={class:"panel-header-left"},Iv={class:"notes-size-controls"},Tv=["disabled"],Ev={class:"notes-size-value"},Av=["disabled"],Bv={key:1,class:"presenter-empty"},Mv={class:"empty-icon-wrap"},Dv={class:"empty-actions"},Lv={class:"presenter-actions"},Pv={class:"nav-btn-group"},Ov=["disabled"],Rv=["disabled"],Nv={class:"actions-center"},zv={class:"center-meta"},Fv={class:"progress-pill"},Hv={class:"nav-btn-group"},jv=["aria-label"],Wv={class:"step-dots-text"},Uv=["disabled"],Vv=["disabled"],Kv=280,Gv=15,qv=xt({__name:"SlidevPresenterTab",setup(e,{expose:t}){const i=Rt("plugin"),n=Rt("sandboxBridge",new js),s=pe([]),o=pe({}),l=pe(1),r=pe(0),a=pe(0),c=pe(0),d=we(()=>s.value.length||a.value),p=pe(null),g=pe(null),u=pe({width:0,height:0}),m=pe({width:0,height:0}),h=we(()=>{var ie;return jg((ie=o.value)==null?void 0:ie.aspectRatio)}),b=we(()=>{var ie;return((ie=o.value)==null?void 0:ie.theme)||"default"}),y=we(()=>{var ie;return((ie=o.value)==null?void 0:ie.colorSchema)==="light"?"light":"dark"}),x=we(()=>{var ie;return!!((ie=o.value)!=null&&ie.normalizeHeadingSizes)}),_=we(()=>Zr(u.value.width,u.value.height,h.value.baseWidth,h.value.baseHeight,14)),B=we(()=>Zr(m.value.width,m.value.height,h.value.baseWidth,h.value.baseHeight,14));function M(){p.value&&(u.value={width:p.value.clientWidth,height:p.value.clientHeight}),g.value&&(m.value={width:g.value.clientWidth,height:g.value.clientHeight})}let T=null;function w(){typeof window>"u"||typeof window.ResizeObserver!="function"||(T||(T=new window.ResizeObserver(()=>{M()})),T.disconnect(),p.value&&T.observe(p.value),g.value&&T.observe(g.value))}ki([p,g,d],()=>{bs(()=>{w(),M()})},{flush:"post"});const R=pe(0),O=pe(!0);let N=null;const Z=we(()=>{const ie=String(Math.floor(R.value/60)).padStart(2,"0"),ne=String(R.value%60).padStart(2,"0");return`${ie}:${ne}`});function S(){O.value=!O.value}function z(){R.value=0}const k=pe("");let A=null;function F(){const ie=new Date,ne=String(ie.getHours()).padStart(2,"0"),Ce=String(ie.getMinutes()).padStart(2,"0");k.value=`${ne}:${Ce}`}const E=we(()=>s.value.length===0?null:s.value[l.value-1]||null),D=we(()=>l.value>=s.value.length?null:s.value[l.value]||null),P=we(()=>E.value?Hg(E.value):c.value),X=we(()=>l.value>1||r.value>0),G=we(()=>l.value<d.value||r.value<P.value),W=we(()=>Yr(E.value,{config:o.value,allSlides:s.value,pageIndex:l.value,currentStep:r.value})),se=we(()=>Yr(D.value,{config:o.value,allSlides:s.value,pageIndex:l.value+1})),ae=we(()=>{var ne;if(!E.value)return"无内容";const ie=(ne=E.value.blocks)==null?void 0:ne[0];return(ie==null?void 0:ie.content)||(ie==null?void 0:ie.rawMarkdown)||`第 ${l.value} 页`});function ce(ie){return(ie||[]).slice(1).map(ne=>(ne.content||ne.rawMarkdown||"").trim()).filter(ne=>ne&&!/^(image\s+)?assets\/\S*$/i.test(ne)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(ne)).join(" | ").slice(0,120)}const ve=we(()=>{var ie;return ce((ie=E.value)==null?void 0:ie.blocks)}),Te=we(()=>{var ne;if(!D.value)return"演示结束";const ie=(ne=D.value.blocks)==null?void 0:ne[0];return(ie==null?void 0:ie.content)||(ie==null?void 0:ie.rawMarkdown)||`第 ${l.value+1} 页`}),xe=we(()=>D.value?ce(D.value.blocks):"这是最后一页"),ue=we(()=>{var ie;return((ie=E.value)==null?void 0:ie.notes)||""}),Y=pe(20);function fe(){Y.value<36&&(Y.value+=2)}function L(){Y.value>14&&(Y.value-=2)}const j=we(()=>d.value<=1?100:Math.round(l.value/d.value*100));let v=null;try{v=new BroadcastChannel("siyuan-slidev-sync"),v.onmessage=ie=>{const ne=ie.data;if(ne&&(ne.type==="SYNC_PAGE"&&typeof ne.page=="number"&&(l.value=ne.page,r.value=typeof ne.step=="number"?Math.max(0,ne.step):0,typeof ne.maxStep=="number"&&(c.value=Math.max(0,ne.maxStep))),ne.type==="SYNC_SLIDES"&&Array.isArray(ne.slides)&&(s.value=ne.slides,ne.config&&typeof ne.config=="object"&&(o.value=ne.config)),ne.type==="REQUEST_SYNC"&&s.value.length>0))try{v==null||v.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(s.value)),config:JSON.parse(JSON.stringify(o.value||{}))}),v==null||v.postMessage({type:"SYNC_PAGE",page:l.value,step:r.value,maxStep:P.value})}catch{}}}catch{v=null}function U(ie,ne=0){const Ce=Number(ie)||1,Be=Math.max(0,Number(ne)||0);n.navigatePage(Ce,Be);try{v==null||v.postMessage({type:"SYNC_PAGE",page:Ce,step:Be,maxStep:P.value})}catch{}}function H(){if(r.value<P.value){r.value++,U(l.value,r.value);return}l.value<d.value&&(l.value++,r.value=0,U(l.value,0))}function $(){if(r.value>0){r.value--,U(l.value,r.value);return}l.value>1&&(l.value--,r.value=0,U(l.value,0))}function I(){l.value<d.value&&(l.value++,r.value=0,U(l.value,0))}function C(){l.value>1&&(l.value--,r.value=0,U(l.value,0))}function V(){l.value=1,r.value=0,z(),U(1,0)}function q(){const ie=i;typeof(ie==null?void 0:ie.openBottomPreviewTab)=="function"&&ie.openBottomPreviewTab()}function K(){const ie=i;typeof(ie==null?void 0:ie.openStandalonePreviewWindow)=="function"&&ie.openStandalonePreviewWindow()}function ee(ie){var ne,Ce;if(!(ie.key===" "&&((Ce=(ne=ie.target)==null?void 0:ne.closest)!=null&&Ce.call(ne,"button")))){if(ie.shiftKey&&ie.key==="ArrowRight"||ie.key==="ArrowDown"){ie.preventDefault(),I();return}if(ie.shiftKey&&ie.key==="ArrowLeft"||ie.key==="ArrowUp"){ie.preventDefault(),C();return}ie.key==="ArrowRight"||ie.key===" "||ie.key==="PageDown"?(ie.preventDefault(),H()):(ie.key==="ArrowLeft"||ie.key==="PageUp")&&(ie.preventDefault(),$())}}let le=0;function oe(ie){var Be,Ne;if(Math.abs(ie.deltaY)<Gv)return;const ne=(Ne=(Be=ie.target)==null?void 0:Be.closest)==null?void 0:Ne.call(Be,".notes-content");if(ne){const Re=ne.scrollHeight-ne.clientHeight;if(Re>2&&(ie.deltaY>0&&ne.scrollTop<Re-1||ie.deltaY<0&&ne.scrollTop>1))return}const Ce=Date.now();Ce-le<Kv||(le=Ce,ie.deltaY>0?H():$())}let he=null;return un(()=>{var ne;N=window.setInterval(()=>{O.value&&R.value++},1e3),F(),A=window.setInterval(F,1e3),he=n.onSlideChanged((Ce,Be,Ne,Re,Le)=>{l.value=Ce,Be>0&&(a.value=Be),typeof Re=="number"&&(r.value=Math.max(0,Re)),typeof Le=="number"&&(c.value=Math.max(0,Le))});try{v==null||v.postMessage({type:"REQUEST_SYNC"})}catch{}const ie=i==null?void 0:i.latestCompiledDoc;(ne=ie==null?void 0:ie.slides)!=null&&ne.length&&(s.value=ie.slides,ie.config&&(o.value=ie.config)),typeof window<"u"&&window.addEventListener("resize",M),bs(()=>{w(),M()})}),Rs(()=>{N&&(window.clearInterval(N),N=null),A&&(window.clearInterval(A),A=null),he&&he(),typeof window<"u"&&window.removeEventListener("resize",M),T&&(T.disconnect(),T=null);try{v==null||v.close()}catch{}v=null}),t({updateDocument(ie){var ne;(ne=ie==null?void 0:ie.slides)!=null&&ne.length&&(s.value=ie.slides),ie!=null&&ie.config&&(o.value=ie.config)}}),(ie,ne)=>{var Ce,Be,Ne;return J(),te("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:ee,onWheel:oe},[f("header",Ug,[f("div",Vg,[f("div",Kg,[re(de,{name:"presenter",class:"brand-icon"}),ne[1]||(ne[1]=f("span",{class:"title-name"},"演讲者控制台",-1))]),f("div",Gg,[f("span",qg,"P."+ke(l.value)+" / "+ke(d.value||1),1),P.value>0?(J(),te("span",Zg,[re(de,{name:"step",class:"pill-icon"}),_t(" 步进 "+ke(r.value)+" / "+ke(P.value),1)])):De("",!0)])]),f("div",Yg,[f("button",{class:"btn-tool b3-tooltips b3-tooltips__s","aria-label":"弹出大屏放映独立窗口 (16:9)",onClick:K},[re(de,{name:"window"}),ne[2]||(ne[2]=f("span",{class:"btn-tool-label"},"独立放映",-1))]),f("div",Jg,[re(de,{name:"clock",class:"timer-icon"}),f("span",Xg,ke(Z.value),1),f("div",Qg,[f("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":O.value?"暂停计时":"继续计时",onClick:S},[re(de,{name:O.value?"pause":"play"},null,8,["name"])],8,ev),f("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":"重置计时",onClick:z},[re(de,{name:"reset"})])])]),f("div",tv,[f("span",null,ke(k.value),1)])])]),d.value>0?(J(),te("main",iv,[f("section",nv,[f("div",sv,[f("div",ov,[f("div",rv,[ne[3]||(ne[3]=f("span",{class:"panel-tag is-current"},"当前放映",-1)),f("span",lv,"P."+ke(l.value),1)]),f("div",av,[P.value>0?(J(),te("span",cv," 步进 "+ke(r.value)+" / "+ke(P.value),1)):De("",!0),f("span",dv,ke(((Be=(Ce=E.value)==null?void 0:Ce.frontmatter)==null?void 0:Be.layout)||"default"),1)])]),f("div",{ref_key:"currentPreviewRef",ref:p,class:"panel-preview","aria-label":ae.value},[E.value?(J(),te("div",{key:0,class:"presenter-thumb-box",style:Gt({width:_.value.boxWidth+"px",height:_.value.boxHeight+"px"})},[f("div",{class:_e(["presenter-thumb-viewport slide-viewport","slidev-theme-"+b.value]),"data-theme":y.value,"data-slidev-theme":b.value,"data-normalize-headings":x.value?"true":"false",style:Gt({width:h.value.baseWidth+"px",height:h.value.baseHeight+"px",transform:"scale("+_.value.scale+")"}),innerHTML:W.value},null,14,fv)],4)):(J(),te("div",pv,[f("h2",null,ke(ae.value),1),f("p",null,ke(ve.value),1)]))],8,uv)]),f("div",{class:_e(["panel-box next-slide-panel",{"is-clickable":!!D.value,"b3-tooltips b3-tooltips__n":!!D.value}]),"aria-label":D.value?"点击直接跳至下一页":"",onClick:ne[0]||(ne[0]=Re=>D.value&&I())},[f("div",mv,[f("div",gv,[ne[4]||(ne[4]=f("span",{class:"panel-tag"},"下一页预告",-1)),l.value<d.value?(J(),te("span",vv,"P."+ke(l.value+1),1)):De("",!0)]),f("div",bv,[l.value>=d.value?(J(),te("span",yv,"已到尾页")):D.value?(J(),te("span",kv,ke(((Ne=D.value.frontmatter)==null?void 0:Ne.layout)||"default"),1)):De("",!0)])]),f("div",{ref_key:"nextPreviewRef",ref:g,class:"panel-preview panel-preview--dim","aria-label":Te.value},[D.value?(J(),te("div",{key:0,class:"presenter-thumb-box",style:Gt({width:B.value.boxWidth+"px",height:B.value.boxHeight+"px"})},[f("div",{class:_e(["presenter-thumb-viewport slide-viewport","slidev-theme-"+b.value]),"data-theme":y.value,"data-slidev-theme":b.value,"data-normalize-headings":x.value?"true":"false",style:Gt({width:h.value.baseWidth+"px",height:h.value.baseHeight+"px",transform:"scale("+B.value.scale+")"}),innerHTML:se.value},null,14,xv)],4)):(J(),te("div",Sv,[f("h2",null,ke(Te.value),1),f("p",null,ke(xe.value),1)]))],8,wv)],10,hv)]),f("section",_v,[f("div",Cv,[f("div",$v,[re(de,{name:"notes",class:"panel-title-icon"}),ne[5]||(ne[5]=f("span",null,"讲稿备忘",-1))]),f("div",Iv,[f("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"减小字体",disabled:Y.value<=14,onClick:L},[re(de,{name:"minus"})],8,Tv),f("span",Ev,ke(Y.value)+"px",1),f("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"增大字体",disabled:Y.value>=36,onClick:fe},[re(de,{name:"plus"})],8,Av)])]),f("div",{class:_e(["notes-content",{"is-empty":!ue.value}]),style:Gt({fontSize:Y.value+"px"})},ke(ue.value||"（本页未设置演讲者备忘录）"),7)])])):(J(),te("main",Bv,[f("div",Mv,[re(de,{name:"refresh",class:"empty-icon"})]),ne[8]||(ne[8]=f("h2",null,"等待大屏放映数据",-1)),ne[9]||(ne[9]=f("p",null,"未检测到活跃的幻灯片数据，请先开启大屏放映端。",-1)),f("div",Dv,[f("button",{class:"btn-empty-action b3-tooltips b3-tooltips__n","aria-label":"在思源中打开底部演示预览页签",onClick:q},[re(de,{name:"presenter"}),ne[6]||(ne[6]=f("span",null,"打开大屏放映页签",-1))]),f("button",{class:"btn-empty-action btn-empty-action--popout b3-tooltips b3-tooltips__n","aria-label":"将放映端弹出为独立窗口 (16:9)",onClick:K},[re(de,{name:"window"}),ne[7]||(ne[7]=f("span",null,"弹出独立放映窗口",-1))])])])),f("footer",Lv,[f("div",Pv,[f("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__ne",disabled:l.value<=1,"aria-label":"快速返回上一页 (Shift + ←)",onClick:C},[re(de,{name:"chevrons-left"}),ne[10]||(ne[10]=f("span",null,"上一页",-1))],8,Ov),f("button",{class:"btn-nav btn-nav--step b3-tooltips b3-tooltips__n",disabled:!X.value,"aria-label":"回退一步 (←)",onClick:$},[re(de,{name:"chevron-left"}),ne[11]||(ne[11]=f("span",null,"上一步",-1))],8,Rv)]),f("div",Nv,[f("div",zv,[f("span",Fv,ke(j.value)+"%",1)]),f("button",{class:"btn-restart b3-tooltips b3-tooltips__n","aria-label":"从第一页重新放映 (Home)",onClick:V},[re(de,{name:"reset"}),ne[12]||(ne[12]=f("span",null,"重头放映",-1))])]),f("div",Hv,[P.value>0?(J(),te("div",{key:0,class:"step-dots-bar b3-tooltips b3-tooltips__n","aria-label":`步进进度: ${r.value} / ${P.value}`},[(J(!0),te(Ue,null,ht(P.value,Re=>(J(),te("span",{key:Re,class:_e(["step-dot",{"is-active":Re<=r.value}])},null,2))),128)),f("span",Wv,ke(r.value)+"/"+ke(P.value),1)],8,jv)):De("",!0),f("button",{class:"btn-nav btn-nav--step btn-nav--primary b3-tooltips b3-tooltips__n",disabled:!G.value,"aria-label":"触发下一步骤或进入下一页 (Space / →)",onClick:H},[ne[13]||(ne[13]=f("span",null,"下一步",-1)),re(de,{name:"chevron-right"})],8,Uv),f("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__nw",disabled:l.value>=d.value,"aria-label":"跳过本页剩余步骤，直接进入下一页 (Shift + →)",onClick:I},[ne[14]||(ne[14]=f("span",null,"下一页",-1)),re(de,{name:"chevrons-right"})],8,Vv)])])],32)}}}),Zv=Mt(qv,[["__scopeId","data-v-aa1ee0a8"]]),Yv={class:"spm-section spm-section--page"},Jv={class:"spm-section-header"},Xv={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},Qv={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},eb={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},tb={key:1,class:"spm-card-control"},ib={class:"spm-control-header"},nb={class:"spm-control-title-group"},sb={class:"spm-control-title"},ob={class:"spm-quick-chips"},rb=["onClick"],lb={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},ab=["value"],cb=["aria-label"],db={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__w",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},ub={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},fb={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},pb={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},hb={class:"spm-card-control"},mb={class:"spm-control-header"},gb={class:"spm-control-title-group"},vb={class:"spm-control-title"},bb={class:"spm-segmented-group"},yb={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},kb={style:{display:"flex","align-items":"center","justify-content":"space-between"}},wb={class:"b3-tooltips b3-tooltips__w","aria-label":`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},xb={class:"spm-quick-chips"},Sb=["onClick"],_b={class:"b3-tooltips b3-tooltips__n",style:{width:"100%",display:"block"},"aria-label":"输入权重比例（如 1:2:1）或绝对累计百分比断点（如 25:75:100），冒号项数决定点击步数"},Cb=["value"],$b={style:{display:"flex",gap:"8px","margin-top":"2px"}},Ib={style:{flex:"1"}},Tb={class:"spm-segmented-group"},Eb={style:{flex:"1"}},Ab={class:"spm-segmented-group"},Bb={class:"spm-card-control"},Mb={class:"spm-control-header"},Db={class:"spm-control-title-group"},Lb={class:"spm-control-title"},Pb={class:"spm-segmented-group"},Ob={class:"spm-card-control"},Rb={class:"spm-control-header"},Nb={class:"spm-control-title-group"},zb={class:"spm-control-title"},Fb={class:"spm-quick-chips"},Hb=["onClick"],jb=["value"],Wb={key:2,class:"spm-card-control"},Ub={class:"spm-control-header"},Vb={class:"spm-control-title-group"},Kb={class:"spm-control-title"},Gb={class:"spm-quick-chips"},qb=["onClick"],Zb=["value"],Yb={class:"spm-card-control"},Jb={class:"spm-control-header"},Xb={class:"spm-control-title-group"},Qb={class:"spm-control-title"},e1={key:0,class:"spm-note-status-box"},t1=["title"],i1={class:"spm-action-grid",style:{"margin-top":"6px"}},n1={key:1,class:"spm-note-empty-box"},s1={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},o1={class:"spm-action-grid"},r1=["disabled"],l1=["disabled"],a1={class:"spm-card-control"},c1={class:"spm-action-grid"},d1=xt({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(e,{emit:t}){const i=e,n=t,s=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],o=we(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),l=we(()=>{var h,b;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const u=(i.pageLayoutRatio||"").trim();if(u.includes(":")){const y=u.split(":").filter(Boolean).length;if(y>=2&&y<=6)return y}const m=(i.detectedSbRatio||"").trim();if(m.includes(":")){const y=m.split(":").filter(Boolean).length;if(y>=2&&y<=6)return y}if((h=i.detectedSbInfo)!=null&&h.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((b=i.detectedSbInfo)!=null&&b.slots&&Array.isArray(i.detectedSbInfo.slots)){const y=i.detectedSbInfo.slots.length;if(y>=2&&y<=6)return y}return 2}),r=we(()=>{const u=l.value;return u===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:u===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:u===5?[{label:"默认 1:1:1:1:1",value:""}]:u===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),a=we(()=>i.pageLayoutRatio||"");function c(){const u=l.value||2,m=Array(u).fill("1").join(":");n("update:pageLayoutRatio",m),n("resetSuperblockRatio")}const d=we(()=>{if(!i.pageNotes)return"";const u=i.pageNotes.replace(/[\r\n]+/g," ").trim();return u.length>50?u.slice(0,50)+"...":u}),p=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],g=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(u,m)=>(J(),te("div",Yv,[f("div",Jv,[f("span",null,"幻灯片页面设置"+ke(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),re(Ia,{"model-value":e.pageLayout,onChange:m[0]||(m[0]=h=>u.$emit("update:pageLayout",h))},null,8,["model-value"]),!o.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(J(),te("div",Xv,[f("div",Qv,[f("div",eb,[re(de,{name:"sparkles"}),f("span",null,[m[31]||(m[31]=_t("检测到本页横向超级块列宽比例：",-1)),f("b",null,ke(e.detectedSbRatio),1)])]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__w","aria-label":"一键将本页版式设为分栏并应用超级块列宽",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:m[1]||(m[1]=h=>u.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[re(de,{name:"columns"}),m[32]||(m[32]=f("span",null,"设为分栏",-1))])])])):De("",!0),o.value?(J(),te("div",tb,[f("div",ib,[f("div",nb,[f("div",sb,[re(de,{name:"ratio"}),m[33]||(m[33]=f("span",null,"分栏比例 (Ratio)",-1))]),m[34]||(m[34]=f("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),f("div",ob,[(J(!0),te(Ue,null,ht(r.value,h=>(J(),te("button",{key:h.value,class:_e(["spm-chip",{active:a.value===h.value}]),onClick:b=>u.$emit("update:pageLayoutRatio",h.value)},ke(h.label),11,rb))),128))]),f("div",lb,[f("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:m[2]||(m[2]=h=>u.$emit("update:pageLayoutRatio",h.target.value)),onChange:m[3]||(m[3]=h=>u.$emit("update:pageLayoutRatio",h.target.value))},null,40,ab),e.detectedSbRatio?(J(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":`从当前页思源超级块读取实际宽度比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:m[4]||(m[4]=h=>u.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[re(de,{name:"sparkles"}),m[35]||(m[35]=f("span",null,"读取",-1))],8,cb)):(J(),te("button",db,[re(de,{name:"sparkles"}),m[36]||(m[36]=f("span",null,"读取",-1))])),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":"重置渲染比例为平均分布，并立即重置文档中超级块内容分布比例",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:c},[re(de,{name:"reset"}),m[37]||(m[37]=f("span",null,"重置",-1))])]),e.detectedSbRatio?(J(),te("div",ub,[re(de,{name:"ratio"}),m[38]||(m[38]=f("span",null,"检测到思源超级块宽度：",-1)),f("code",fb,ke(e.detectedSbRatio),1)])):(J(),te("div",pb,[re(de,{name:"ratio"}),m[39]||(m[39]=f("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):De("",!0),re(nr,{"model-value":e.pageTransition,onChange:m[5]||(m[5]=h=>u.$emit("update:pageTransition",h))},null,8,["model-value"]),f("div",hb,[f("div",mb,[f("div",gb,[f("div",vb,[re(de,{name:"sparkles"}),m[40]||(m[40]=f("span",null,"页面动态蒙版 (Dynamic Mask)",-1))]),m[41]||(m[41]=f("span",{class:"spm-control-desc"},"随着点击操作分段展露正文内容",-1))])]),f("div",bb,[f("button",{class:_e(["spm-segmented-item",{active:!e.pageMask}]),onClick:m[6]||(m[6]=h=>u.$emit("update:pageMask",""))}," 关闭 ",2),f("button",{class:_e(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:m[7]||(m[7]=h=>u.$emit("update:pageMask","down"))}," 从上至下 ",2),f("button",{class:_e(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:m[8]||(m[8]=h=>u.$emit("update:pageMask","right"))}," 从左至右 ",2)]),e.pageMask?(J(),te("div",yb,[f("div",kb,[m[43]||(m[43]=f("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),f("span",wb,[re(de,{name:"help"}),m[42]||(m[42]=f("span",null,"输入规则",-1))])]),f("div",xb,[(J(),te(Ue,null,ht(s,h=>f("button",{key:h.value,class:_e(["spm-chip",{active:(e.pageMaskRatio||"1:1")===h.value}]),onClick:b=>u.$emit("update:pageMaskRatio",h.value)},ke(h.label),11,Sb)),64))]),f("div",_b,[f("input",{value:e.pageMaskRatio||"1:1",class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:m[9]||(m[9]=h=>u.$emit("update:pageMaskRatio",h.target.value)),onChange:m[10]||(m[10]=h=>u.$emit("update:pageMaskRatio",h.target.value))},null,40,Cb)]),m[46]||(m[46]=f("div",{style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}}," 提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数 ",-1)),f("div",$b,[f("div",Ib,[m[44]||(m[44]=f("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),f("div",Tb,[f("button",{class:_e(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:m[11]||(m[11]=h=>u.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),f("button",{class:_e(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:m[12]||(m[12]=h=>u.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),f("div",Eb,[m[45]||(m[45]=f("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),f("div",Ab,[f("button",{class:_e(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:m[13]||(m[13]=h=>u.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),f("button",{class:_e(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:m[14]||(m[14]=h=>u.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):De("",!0)]),f("div",Bb,[f("div",Mb,[f("div",Db,[f("div",Lb,[re(de,{name:"ratio"}),m[47]||(m[47]=f("span",null,"页面间距 (Spacing)",-1))]),m[48]||(m[48]=f("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),f("div",Pb,[f("button",{class:_e(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:m[15]||(m[15]=h=>u.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),f("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="compact"}]),onClick:m[16]||(m[16]=h=>u.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),f("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="normal"}]),onClick:m[17]||(m[17]=h=>u.$emit("update:pageSpacing","normal"))}," 标准 ",2),f("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="loose"}]),onClick:m[18]||(m[18]=h=>u.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),f("div",Ob,[f("div",Rb,[f("div",Nb,[f("div",zb,[re(de,{name:"palette"}),m[49]||(m[49]=f("span",null,"页面背景 (Background)",-1))]),m[50]||(m[50]=f("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),f("div",Fb,[(J(),te(Ue,null,ht(p,h=>f("button",{key:h.value,class:_e(["spm-chip",{active:e.pageBackground===h.value}]),onClick:b=>u.$emit("update:pageBackground",h.value)},ke(h.label),11,Hb)),64))]),f("input",{value:e.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:m[19]||(m[19]=h=>u.$emit("update:pageBackground",h.target.value)),onChange:m[20]||(m[20]=h=>u.$emit("update:pageBackground",h.target.value))},null,40,jb)]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(J(),te("div",Wb,[f("div",Ub,[f("div",Vb,[f("div",Kb,[re(de,{name:"image"}),m[51]||(m[51]=f("span",null,"页面图片 (Image)",-1))]),m[52]||(m[52]=f("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),f("div",Gb,[(J(),te(Ue,null,ht(g,h=>f("button",{key:h.value,class:_e(["spm-chip",{active:e.pageImage===h.value}]),onClick:b=>u.$emit("update:pageImage",h.value)},ke(h.label),11,qb)),64))]),f("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:m[21]||(m[21]=h=>u.$emit("update:pageImage",h.target.value)),onChange:m[22]||(m[22]=h=>u.$emit("update:pageImage",h.target.value))},null,40,Zb)])):De("",!0),f("div",Yb,[f("div",Jb,[f("div",Xb,[f("div",Qb,[re(de,{name:"presenter"}),m[53]||(m[53]=f("span",null,"演讲者提词 (Notes)",-1))]),m[54]||(m[54]=f("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),f("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:m[23]||(m[23]=h=>u.$emit("generateNotes"))},[re(de,{name:"sparkles"}),m[55]||(m[55]=f("span",null,"AI 讲稿",-1))])]),e.pageNotes?(J(),te("div",e1,[m[58]||(m[58]=f("div",{class:"spm-note-status-badge"},[f("span",{class:"spm-badge-dot"}),f("span",null,"已配置正文讲稿")],-1)),f("div",{class:"spm-note-preview-text",title:e.pageNotes},ke(d.value),9,t1),f("div",i1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:m[24]||(m[24]=h=>u.$emit("locateNoteBlock"))},[re(de,{name:"search"}),m[56]||(m[56]=f("span",null,"定位讲稿块",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:m[25]||(m[25]=h=>u.$emit("addNoteBlock"))},[re(de,{name:"insert-below"}),m[57]||(m[57]=f("span",null,"追加讲稿块",-1))])])])):(J(),te("div",n1,[m[60]||(m[60]=f("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:m[26]||(m[26]=h=>u.$emit("addNoteBlock"))},[re(de,{name:"insert-below"}),m[59]||(m[59]=f("span",null,"添加讲稿备注块",-1))])])),f("div",s1,[f("div",o1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",disabled:e.isBatchProcessing,style:Gt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:m[27]||(m[27]=h=>u.$emit("batchAppendNotes"))},[re(de,{name:"insert-below"}),m[61]||(m[61]=f("span",null,"全部追加",-1))],12,r1),f("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s",disabled:e.isBatchProcessing,style:Gt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:m[28]||(m[28]=h=>u.$emit("batchDeleteNotes"))},[re(de,{name:"trash"}),m[62]||(m[62]=f("span",null,"全部删除",-1))],12,l1)])])]),f("div",a1,[m[65]||(m[65]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),f("div",c1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:m[29]||(m[29]=h=>u.$emit("insertDividerAfter"))},[re(de,{name:"insert-below"}),m[63]||(m[63]=f("span",null,"插入新页",-1))]),f("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:m[30]||(m[30]=h=>u.$emit("deleteDivider"))},[re(de,{name:"trash"}),m[64]||(m[64]=f("span",null,"删除此页",-1))])])])]))}}),u1=Mt(d1,[["__scopeId","data-v-1f9d4630"]]),f1={class:"spm-section spm-section--block"},p1={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},h1={class:"spm-control-header"},m1={class:"spm-control-title-group"},g1={class:"spm-control-title"},v1={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},b1={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},y1={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},k1={key:0},w1={key:1},x1={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},S1={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},_1={class:"spm-action-grid"},C1={class:"spm-card-control"},$1={class:"spm-control-header"},I1={class:"spm-control-title-group"},T1={class:"spm-control-title"},E1=["aria-label"],A1=["checked"],B1={key:1,class:"spm-card-control"},M1={class:"spm-control-header"},D1={class:"spm-control-title-group"},L1={class:"spm-control-title"},P1={class:"spm-quick-chips"},O1={key:2,class:"spm-card-control"},R1={class:"spm-control-header"},N1={class:"spm-control-title-group"},z1={class:"spm-control-title"},F1={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},H1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},j1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},W1=["aria-label"],U1=["checked"],V1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},K1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},G1=["aria-label"],q1=["checked"],Z1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Y1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},J1=["aria-label"],X1=["checked"],Q1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},ey={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},ty=["aria-label"],iy=["checked"],ny={class:"spm-card-control"},sy={class:"spm-control-header"},oy={class:"spm-control-title-group"},ry={class:"spm-control-title"},ly=["aria-label"],ay=["checked"],cy={key:0,class:"spm-quick-chips"},dy=["onClick"],uy={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},fy={class:"spm-card-control"},py={class:"spm-control-header"},hy={class:"spm-control-title-group"},my={class:"spm-control-title"},gy=["aria-label"],vy=["checked"],by={key:0,class:"spm-quick-chips"},yy=["onClick"],ky={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},wy={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},xy={style:{display:"flex",gap:"6px"}},Sy=["value"],_y=["value"],Cy={key:3,class:"spm-card-control"},$y={class:"spm-control-header"},Iy={class:"spm-control-title-group"},Ty={class:"spm-control-title"},Ey={class:"spm-control-desc"},Ay={class:"spm-segmented-group"},By=["onClick"],My={key:4,class:"spm-card-control"},Dy={class:"spm-control-header"},Ly={class:"spm-control-title-group"},Py={class:"spm-control-title"},Oy={class:"spm-quick-chips"},Ry=["onClick"],Ny=["value"],zy={key:5,class:"spm-card-control"},Fy={class:"spm-control-header"},Hy={class:"spm-control-title-group"},jy={class:"spm-control-title"},Wy={class:"spm-quick-chips"},Uy=["onClick"],Vy=["value"],Ky={class:"spm-card-control"},Gy={class:"spm-action-grid"},qy=["aria-label"],Zy=xt({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const i=e,n=we(()=>{const T=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":T}),s=we(()=>{const T=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(T)}),o=we(()=>{var w,R,O,N;if((w=i.detectedSbInfo)!=null&&w.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const T=(R=i.elemSlot)==null?void 0:R.match(/^col-(\d+)$/);if(T){const Z=parseInt(T[1],10);if(Z>=2&&Z<=6)return Math.max(Z,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((N=(O=i.detectedSbInfo)==null?void 0:O.ratio)!=null&&N.includes(":")){const Z=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(Z.length>=2)return Math.min(Z.length,6)}return 3}),l=we(()=>{const T=n.value;return T==="cols-header"?"多栏插槽归属 (Slot)":T==="three-cols-header"?"三栏插槽归属 (Slot)":T==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),r=we(()=>{const T=n.value;return T==="cols-header"?`在 cols-header 表头多栏（${o.value} 栏）中的内容块位置`:T==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":T==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":T==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=we(()=>{const T=n.value;if(T==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(T==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(T==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const w=o.value,R=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let O=1;O<=w;O++)R.push({value:`col-${O}`,label:`第 ${O} 栏`});return R});function c(T){const w=i.elemSlot||"";return T?w===T||T==="col-1"&&w==="left"||T==="col-2"&&w==="center"||T==="col-3"&&w==="right"&&o.value===3||T==="col-2"&&w==="right"&&o.value===2||T==="left"&&w==="col-1"||T==="right"&&(w==="col-2"||w==="col-3"):!w||w==="default"}const d=t,p=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],g=we(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const T=JSON.parse(i.elemMotion);if(typeof T=="object"&&T!==null)return{preset:T.preset||T.type||"slide-up",duration:typeof T.duration=="number"?T.duration:0,delay:typeof T.delay=="number"?T.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),u=we(()=>!!g.value),m=we(()=>{var T;return((T=g.value)==null?void 0:T.preset)||"slide-up"}),h=we(()=>{var T;return((T=g.value)==null?void 0:T.duration)||0}),b=we(()=>{var T;return((T=g.value)==null?void 0:T.delay)||0});function y(){u.value?d("update:elemMotion",""):d("update:elemMotion","slide-up")}function x(T){M(T,h.value,b.value)}function _(T){M(m.value,T,b.value)}function B(T){M(m.value,h.value,T)}function M(T,w,R){if(!T||T==="none"){d("update:elemMotion","");return}if(!w&&!R){d("update:elemMotion",T);return}const O={preset:T};w>0&&(O.duration=w),R>0&&(O.delay=R),d("update:elemMotion",JSON.stringify(O))}return(T,w)=>{var R,O,N,Z,S,z;return J(),te("div",f1,[w[62]||(w[62]=f("div",{class:"spm-section-header"},[f("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(R=e.detectedSbInfo)!=null&&R.hasSuperBlock?(J(),te("div",p1,[f("div",h1,[f("div",m1,[f("div",g1,[re(de,{name:"ratio"}),w[24]||(w[24]=f("span",null,"超级块列宽与布局",-1))]),w[25]||(w[25]=f("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),f("div",v1,[f("div",b1,[f("div",y1,[re(de,{name:"ratio"}),(O=e.detectedSbInfo)!=null&&O.isCustomWidth?(J(),te("span",k1,"已识别自定义列宽比例")):(J(),te("span",w1,"识别到 "+ke(((N=e.detectedSbInfo)==null?void 0:N.colCount)||2)+" 列超级块分栏",1))]),f("code",x1,ke(((Z=e.detectedSbInfo)==null?void 0:Z.ratio)||"1:1"),1)]),f("div",S1,ke((S=e.detectedSbInfo)!=null&&S.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),f("div",_1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:w[0]||(w[0]=k=>T.$emit("applySuperBlockLayout",e.detectedSbInfo))},[re(de,{name:"sparkles"}),w[26]||(w[26]=f("span",null,"应用版式与比例",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:w[1]||(w[1]=k=>{var A;return T.$emit("applySuperBlockRatio",((A=e.detectedSbInfo)==null?void 0:A.ratio)||"1:1")})},[re(de,{name:"check"}),f("span",null,"应用比例 ("+ke(((z=e.detectedSbInfo)==null?void 0:z.ratio)||"1:1")+")",1)])])])):De("",!0),f("div",C1,[f("div",$1,[f("div",I1,[f("div",T1,[re(de,{name:"presenter"}),w[27]||(w[27]=f("span",null,"设为讲稿备注",-1))]),w[28]||(w[28]=f("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.isNote?"取消讲稿备注":"设为讲稿备注"},[f("input",{type:"checkbox",checked:!!e.isNote,onChange:w[2]||(w[2]=k=>T.$emit("toggleNote"))},null,40,A1),w[29]||(w[29]=f("span",{class:"spm-switch-slider"},null,-1))],8,E1)])]),e.isImage||e.imageRole?(J(),te("div",B1,[f("div",M1,[f("div",D1,[f("div",L1,[re(de,{name:"image"}),w[30]||(w[30]=f("span",null,"图片角色与分栏 (Image & Layout)",-1))]),w[31]||(w[31]=f("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),f("div",P1,[f("button",{class:_e(["spm-chip",{active:!e.imageRole}]),onClick:w[3]||(w[3]=k=>T.$emit("update:imageRole",""))}," 普通内容 ",2),f("button",{class:_e(["spm-chip",{active:e.imageRole==="background"}]),onClick:w[4]||(w[4]=k=>T.$emit("update:imageRole","background"))},[re(de,{name:"image"}),w[32]||(w[32]=f("span",null,"背景图",-1))],2),f("button",{class:_e(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:w[5]||(w[5]=k=>T.$emit("update:imageRole","image-left"))},[re(de,{name:"image-left"}),w[33]||(w[33]=f("span",null,"图左",-1))],2),f("button",{class:_e(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:w[6]||(w[6]=k=>T.$emit("update:imageRole","image-right"))},[re(de,{name:"image-right"}),w[34]||(w[34]=f("span",null,"图右",-1))],2)])])):De("",!0),e.isVideo?(J(),te("div",O1,[f("div",R1,[f("div",N1,[f("div",z1,[re(de,{name:"video"}),w[35]||(w[35]=f("span",null,"视频播放设置 (Video Playback)",-1))]),w[36]||(w[36]=f("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),f("div",F1,[f("div",H1,[f("span",j1,[re(de,{name:"sliders"}),w[37]||(w[37]=_t(" 控制条",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[f("input",{type:"checkbox",checked:!!e.videoControls,onChange:w[7]||(w[7]=k=>T.$emit("toggleVideoControls"))},null,40,U1),w[38]||(w[38]=f("span",{class:"spm-switch-slider"},null,-1))],8,W1)]),f("div",V1,[f("span",K1,[re(de,{name:"video"}),w[39]||(w[39]=_t(" 自动播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[f("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:w[8]||(w[8]=k=>T.$emit("toggleVideoAutoplay"))},null,40,q1),w[40]||(w[40]=f("span",{class:"spm-switch-slider"},null,-1))],8,G1)]),f("div",Z1,[f("span",Y1,[re(de,{name:"repeat"}),w[41]||(w[41]=_t(" 循环播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[f("input",{type:"checkbox",checked:!!e.videoLoop,onChange:w[9]||(w[9]=k=>T.$emit("toggleVideoLoop"))},null,40,X1),w[42]||(w[42]=f("span",{class:"spm-switch-slider"},null,-1))],8,J1)]),f("div",Q1,[f("span",ey,[re(de,{name:"volume-x"}),w[43]||(w[43]=_t(" 静音播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoMuted?"关闭静音":"开启静音"},[f("input",{type:"checkbox",checked:!!e.videoMuted,onChange:w[10]||(w[10]=k=>T.$emit("toggleVideoMuted"))},null,40,iy),w[44]||(w[44]=f("span",{class:"spm-switch-slider"},null,-1))],8,ty)])])])):De("",!0),f("div",ny,[f("div",sy,[f("div",oy,[f("div",ry,[re(de,{name:"step"}),w[45]||(w[45]=f("span",null,"逐步呈现 (v-click)",-1))]),w[46]||(w[46]=f("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[f("input",{type:"checkbox",checked:!!e.elemClick,onChange:w[11]||(w[11]=k=>T.$emit("toggleElemClick"))},null,40,ay),w[47]||(w[47]=f("span",{class:"spm-switch-slider"},null,-1))],8,ly)]),e.elemClick?(J(),te("div",cy,[(J(),te(Ue,null,ht(["+1","1","2","hide"],k=>f("button",{key:k,class:_e(["spm-chip",{active:e.elemClick===k}]),onClick:A=>T.$emit("update:elemClick",k)},ke(k==="+1"?"顺延 (+1)":k==="hide"?"隐藏 (hide)":"第 "+k+" 步"),11,dy)),64))])):e.parentElemClick?(J(),te("div",uy,[re(de,{name:"check"}),w[48]||(w[48]=f("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):De("",!0)]),f("div",fy,[f("div",py,[f("div",hy,[f("div",my,[re(de,{name:"motion"}),w[49]||(w[49]=f("span",null,"入场微动效 (v-motion)",-1))]),w[50]||(w[50]=f("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":u.value?"关闭微动效":"开启微动效 (slide-up)"},[f("input",{type:"checkbox",checked:u.value,onChange:y},null,40,vy),w[51]||(w[51]=f("span",{class:"spm-switch-slider"},null,-1))],8,gy)]),u.value?(J(),te("div",by,[(J(),te(Ue,null,ht(p,k=>f("button",{key:k.value,class:_e(["spm-chip",{active:m.value===k.value}]),onClick:A=>x(k.value)},ke(k.label),11,yy)),64))])):De("",!0),u.value?(J(),te("div",ky,[f("div",wy,[f("span",null,"时长: "+ke(h.value?h.value+"ms":"默认 (450ms)"),1),f("span",null,"延迟: "+ke(b.value?b.value+"ms":"0ms"),1)]),f("div",xy,[f("select",{class:"spm-select",style:{flex:"1"},value:h.value,onChange:w[12]||(w[12]=k=>_(Number(k.target.value)))},[...w[52]||(w[52]=[f("option",{value:0},"默认耗时",-1),f("option",{value:200},"极速 (200ms)",-1),f("option",{value:350},"较快 (350ms)",-1),f("option",{value:500},"平滑 (500ms)",-1),f("option",{value:800},"缓慢 (800ms)",-1)])],40,Sy),f("select",{class:"spm-select",style:{flex:"1"},value:b.value,onChange:w[13]||(w[13]=k=>B(Number(k.target.value)))},[...w[53]||(w[53]=[f("option",{value:0},"无延迟",-1),f("option",{value:150},"延迟 150ms",-1),f("option",{value:300},"延迟 300ms",-1),f("option",{value:500},"延迟 500ms",-1)])],40,_y)])])):De("",!0)]),s.value||e.elemSlot?(J(),te("div",Cy,[f("div",$y,[f("div",Iy,[f("div",Ty,[re(de,{name:"columns"}),f("span",null,ke(l.value),1)]),f("span",Ey,ke(r.value),1)])]),f("div",Ay,[(J(!0),te(Ue,null,ht(a.value,k=>(J(),te("button",{key:k.value,class:_e(["spm-segmented-item",{active:c(k.value)}]),onClick:A=>T.$emit("update:elemSlot",k.value)},ke(k.label),11,By))),128))])])):De("",!0),e.isCodeBlock?(J(),te("div",My,[f("div",Dy,[f("div",Ly,[f("div",Py,[re(de,{name:"code"}),w[54]||(w[54]=f("span",null,"代码逐行聚光 (Shiki)",-1))]),w[55]||(w[55]=f("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),f("div",Oy,[(J(),te(Ue,null,ht(["1-3","all","1|2|3","2-5"],k=>f("button",{key:k,class:_e(["spm-chip",{active:e.elemShikiLines===k}]),onClick:A=>T.$emit("update:elemShikiLines",k)},ke(k),11,Ry)),64)),e.elemShikiLines?(J(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[14]||(w[14]=k=>T.$emit("update:elemShikiLines",""))}," 清空 ")):De("",!0)]),f("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:w[15]||(w[15]=k=>T.$emit("update:elemShikiLines",k.target.value)),onChange:w[16]||(w[16]=k=>T.$emit("update:elemShikiLines",k.target.value))},null,40,Ny)])):De("",!0),e.isCodeBlock?(J(),te("div",zy,[f("div",Fy,[f("div",Hy,[f("div",jy,[re(de,{name:"code"}),w[56]||(w[56]=f("span",null,"代码块限高 (Max Height)",-1))]),w[57]||(w[57]=f("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),f("div",Wy,[(J(),te(Ue,null,ht(["240px","320px","400px","50vh"],k=>f("button",{key:k,class:_e(["spm-chip",{active:e.elemMaxHeight===k}]),onClick:A=>T.$emit("update:elemMaxHeight",k)},ke(k),11,Uy)),64)),e.elemMaxHeight?(J(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[17]||(w[17]=k=>T.$emit("update:elemMaxHeight",""))}," 自适应 ")):De("",!0)]),f("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:w[18]||(w[18]=k=>T.$emit("update:elemMaxHeight",k.target.value)),onChange:w[19]||(w[19]=k=>T.$emit("update:elemMaxHeight",k.target.value))},null,40,Vy)])):De("",!0),f("div",Ky,[w[61]||(w[61]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"快捷操作")])],-1)),f("div",Gy,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:w[20]||(w[20]=k=>T.$emit("insertDividerBefore"))},[re(de,{name:"insert-above"}),w[58]||(w[58]=f("span",null,"上方分页",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:w[21]||(w[21]=k=>T.$emit("insertDividerAfter"))},[re(de,{name:"insert-below"}),w[59]||(w[59]=f("span",null,"下方分页",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:w[22]||(w[22]=k=>T.$emit("setTwoColsContrast"))},[re(de,{name:"columns"}),f("span",null,ke(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,qy),e.hasBlockAttrs?(J(),te("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:w[23]||(w[23]=k=>T.$emit("clearBlockAttrs"))},[re(de,{name:"broom"}),w[60]||(w[60]=f("span",null,"清除属性",-1))])):De("",!0)])])])}}}),Yy={class:"spm-section spm-section--doc"},Jy={class:"spm-card-control"},Xy={class:"spm-control-header"},Qy={class:"spm-control-title-group"},e0={class:"spm-control-title"},t0={class:"spm-segmented-group"},i0=["aria-label","onClick"],n0={class:"spm-card-control"},s0={class:"spm-control-header"},o0={class:"spm-control-title-group"},r0={class:"spm-control-title"},l0={class:"spm-segmented-group"},a0={class:"spm-card-control"},c0={class:"spm-control-header"},d0={class:"spm-control-title-group"},u0={class:"spm-control-title"},f0={class:"spm-segmented-group"},p0={class:"spm-card-control"},h0={class:"spm-control-header"},m0={class:"spm-control-title-group"},g0={class:"spm-control-title"},v0={class:"spm-card-control"},b0={class:"spm-control-header"},y0={class:"spm-control-title-group"},k0={class:"spm-control-title"},w0=["aria-label"],x0=["checked"],S0={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},_0=["value"],C0={class:"spm-card-control"},$0={class:"spm-control-header"},I0={class:"spm-control-title-group"},T0={class:"spm-control-title"},E0=["aria-label"],A0=["checked"],B0={class:"spm-card-control"},M0={class:"spm-action-grid"},D0=xt({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(e){const t=Rt("plugin"),i=gi,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function s(a){Di({enableWebServeJump:a}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({enableWebServeJump:a})}async function o(a){var c;Di({normalizeHeadingSizes:a}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({normalizeHeadingSizes:a}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((c=t.getActiveDocumentId)==null?void 0:c.call(t)))}function l(a){Di({webServeUrl:a})}function r(a){Di({webServeUrl:a}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({webServeUrl:a})}return(a,c)=>(J(),te("div",Yy,[c[39]||(c[39]=f("div",{class:"spm-section-header"},[f("span",null,"全局演示配置")],-1)),f("div",Jy,[f("div",Xy,[f("div",Qy,[f("div",e0,[re(de,{name:"palette"}),c[18]||(c[18]=f("span",null,"幻灯片主题 (Theme)",-1))]),c[19]||(c[19]=f("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),f("div",t0,[(J(),te(Ue,null,ht(n,d=>f("button",{key:d.value,class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.docTheme===d.value}]),"aria-label":d.desc,onClick:p=>a.$emit("update:docTheme",d.value)},ke(d.label),11,i0)),64))])]),f("div",n0,[f("div",s0,[f("div",o0,[f("div",r0,[re(de,{name:"ratio"}),c[20]||(c[20]=f("span",null,"画幅比例 (Aspect Ratio)",-1))]),c[21]||(c[21]=f("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),f("div",l0,[f("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:c[0]||(c[0]=d=>a.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),f("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:c[1]||(c[1]=d=>a.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),f("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:c[2]||(c[2]=d=>a.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),f("div",a0,[f("div",c0,[f("div",d0,[f("div",u0,[re(de,{name:"ratio"}),c[22]||(c[22]=f("span",null,"间距风格 (Spacing)",-1))]),c[23]||(c[23]=f("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),f("div",f0,[f("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:c[3]||(c[3]=d=>a.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),f("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:c[4]||(c[4]=d=>a.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),f("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:c[5]||(c[5]=d=>a.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),f("div",p0,[f("div",h0,[f("div",m0,[f("div",g0,[re(de,{name:"transition"}),c[24]||(c[24]=f("span",null,"全局默认转场",-1))]),c[25]||(c[25]=f("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),re(nr,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:c[6]||(c[6]=d=>a.$emit("update:docDefaultTransition",d))},null,8,["model-value"])]),f("div",v0,[f("div",b0,[f("div",y0,[f("div",k0,[re(de,{name:"external-link"}),c[26]||(c[26]=f("span",null,"本地网络伺服预览 (Web Serve)",-1))]),c[27]||(c[27]=f("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ye(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[f("input",{type:"checkbox",checked:ye(i).enableWebServeJump,onChange:c[7]||(c[7]=d=>s(d.target.checked))},null,40,x0),c[28]||(c[28]=f("span",{class:"spm-switch-slider"},null,-1))],8,w0)]),ye(i).enableWebServeJump?(J(),te("div",S0,[f("input",{value:ye(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:c[8]||(c[8]=Lt(()=>{},["stop"])),onKeyup:c[9]||(c[9]=Lt(()=>{},["stop"])),onInput:c[10]||(c[10]=d=>l(d.target.value)),onChange:c[11]||(c[11]=d=>r(d.target.value))},null,40,_0),c[29]||(c[29]=f("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):De("",!0)]),f("div",C0,[f("div",$0,[f("div",I0,[f("div",T0,[re(de,{name:"type"}),c[30]||(c[30]=f("span",null,"固定特定标题大小",-1))]),c[31]||(c[31]=f("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ye(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[f("input",{type:"checkbox",checked:ye(i).normalizeHeadingSizes,onChange:c[12]||(c[12]=d=>o(d.target.checked))},null,40,A0),c[32]||(c[32]=f("span",{class:"spm-switch-slider"},null,-1))],8,E0)])]),f("div",B0,[c[38]||(c[38]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"演示全局操作")])],-1)),f("div",M0,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:c[13]||(c[13]=d=>a.$emit("openBottomPreview"))},[re(de,{name:"split-preview"}),c[33]||(c[33]=f("span",null,"分屏预览",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:c[14]||(c[14]=d=>a.$emit("openPresenter"))},[re(de,{name:"presenter"}),c[34]||(c[34]=f("span",null,"演讲者视图",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:c[15]||(c[15]=d=>a.$emit("aiAutoSplit"))},[re(de,{name:"sparkles"}),c[35]||(c[35]=f("span",null,"AI 智能分页",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:c[16]||(c[16]=d=>a.$emit("exportHtml"))},[re(de,{name:"export-html"}),c[36]||(c[36]=f("span",null,"导出 HTML",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:c[17]||(c[17]=d=>a.$emit("exportPdf"))},[re(de,{name:"export-pdf"}),c[37]||(c[37]=f("span",null,"导出 PDF",-1))])])])]))}});var es=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function L0(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function ts(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var ro={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var Jr;function P0(){return Jr||(Jr=1,(function(e,t){(function(i){e.exports=i()})(function(){return(function i(n,s,o){function l(c,d){if(!s[c]){if(!n[c]){var p=typeof ts=="function"&&ts;if(!d&&p)return p(c,!0);if(r)return r(c,!0);var g=new Error("Cannot find module '"+c+"'");throw g.code="MODULE_NOT_FOUND",g}var u=s[c]={exports:{}};n[c][0].call(u.exports,function(m){var h=n[c][1][m];return l(h||m)},u,u.exports,i,n,s,o)}return s[c].exports}for(var r=typeof ts=="function"&&ts,a=0;a<o.length;a++)l(o[a]);return l})({1:[function(i,n,s){var o=i("./utils"),l=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";s.encode=function(a){for(var c,d,p,g,u,m,h,b=[],y=0,x=a.length,_=x,B=o.getTypeOf(a)!=="string";y<a.length;)_=x-y,p=B?(c=a[y++],d=y<x?a[y++]:0,y<x?a[y++]:0):(c=a.charCodeAt(y++),d=y<x?a.charCodeAt(y++):0,y<x?a.charCodeAt(y++):0),g=c>>2,u=(3&c)<<4|d>>4,m=1<_?(15&d)<<2|p>>6:64,h=2<_?63&p:64,b.push(r.charAt(g)+r.charAt(u)+r.charAt(m)+r.charAt(h));return b.join("")},s.decode=function(a){var c,d,p,g,u,m,h=0,b=0,y="data:";if(a.substr(0,y.length)===y)throw new Error("Invalid base64 input, it looks like a data url.");var x,_=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&_--,a.charAt(a.length-2)===r.charAt(64)&&_--,_%1!=0)throw new Error("Invalid base64 input, bad content length.");for(x=l.uint8array?new Uint8Array(0|_):new Array(0|_);h<a.length;)c=r.indexOf(a.charAt(h++))<<2|(g=r.indexOf(a.charAt(h++)))>>4,d=(15&g)<<4|(u=r.indexOf(a.charAt(h++)))>>2,p=(3&u)<<6|(m=r.indexOf(a.charAt(h++))),x[b++]=c,u!==64&&(x[b++]=d),m!==64&&(x[b++]=p);return x}},{"./support":30,"./utils":32}],2:[function(i,n,s){var o=i("./external"),l=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),a=i("./stream/DataLengthProbe");function c(d,p,g,u,m){this.compressedSize=d,this.uncompressedSize=p,this.crc32=g,this.compression=u,this.compressedContent=m}c.prototype={getContentWorker:function(){var d=new l(o.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),p=this;return d.on("end",function(){if(this.streamInfo.data_length!==p.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(o.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,p,g){return d.pipe(new r).pipe(new a("uncompressedSize")).pipe(p.compressWorker(g)).pipe(new a("compressedSize")).withStreamInfo("compression",p)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,n,s){var o=i("./stream/GenericWorker");s.STORE={magic:"\0\0",compressWorker:function(){return new o("STORE compression")},uncompressWorker:function(){return new o("STORE decompression")}},s.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,n,s){var o=i("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var d=0;d<8;d++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();n.exports=function(r,a){return r!==void 0&&r.length?o.getTypeOf(r)!=="string"?(function(c,d,p,g){var u=l,m=g+p;c^=-1;for(var h=g;h<m;h++)c=c>>>8^u[255&(c^d[h])];return-1^c})(0|a,r,r.length,0):(function(c,d,p,g){var u=l,m=g+p;c^=-1;for(var h=g;h<m;h++)c=c>>>8^u[255&(c^d.charCodeAt(h))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(i,n,s){s.base64=!1,s.binary=!1,s.dir=!1,s.createFolders=!0,s.date=null,s.compression=null,s.compressionOptions=null,s.comment=null,s.unixPermissions=null,s.dosPermissions=null},{}],6:[function(i,n,s){var o=null;o=typeof Promise<"u"?Promise:i("lie"),n.exports={Promise:o}},{lie:37}],7:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=i("pako"),r=i("./utils"),a=i("./stream/GenericWorker"),c=o?"uint8array":"array";function d(p,g){a.call(this,"FlateWorker/"+p),this._pako=null,this._pakoAction=p,this._pakoOptions=g,this.meta={}}s.magic="\b\0",r.inherits(d,a),d.prototype.processChunk=function(p){this.meta=p.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,p.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var p=this;this._pako.onData=function(g){p.push({data:g,meta:p.meta})}},s.compressWorker=function(p){return new d("Deflate",p)},s.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,n,s){function o(u,m){var h,b="";for(h=0;h<m;h++)b+=String.fromCharCode(255&u),u>>>=8;return b}function l(u,m,h,b,y,x){var _,B,M=u.file,T=u.compression,w=x!==c.utf8encode,R=r.transformTo("string",x(M.name)),O=r.transformTo("string",c.utf8encode(M.name)),N=M.comment,Z=r.transformTo("string",x(N)),S=r.transformTo("string",c.utf8encode(N)),z=O.length!==M.name.length,k=S.length!==N.length,A="",F="",E="",D=M.dir,P=M.date,X={crc32:0,compressedSize:0,uncompressedSize:0};m&&!h||(X.crc32=u.crc32,X.compressedSize=u.compressedSize,X.uncompressedSize=u.uncompressedSize);var G=0;m&&(G|=8),w||!z&&!k||(G|=2048);var W=0,se=0;D&&(W|=16),y==="UNIX"?(se=798,W|=(function(ce,ve){var Te=ce;return ce||(Te=ve?16893:33204),(65535&Te)<<16})(M.unixPermissions,D)):(se=20,W|=(function(ce){return 63&(ce||0)})(M.dosPermissions)),_=P.getUTCHours(),_<<=6,_|=P.getUTCMinutes(),_<<=5,_|=P.getUTCSeconds()/2,B=P.getUTCFullYear()-1980,B<<=4,B|=P.getUTCMonth()+1,B<<=5,B|=P.getUTCDate(),z&&(F=o(1,1)+o(d(R),4)+O,A+="up"+o(F.length,2)+F),k&&(E=o(1,1)+o(d(Z),4)+S,A+="uc"+o(E.length,2)+E);var ae="";return ae+=`
\0`,ae+=o(G,2),ae+=T.magic,ae+=o(_,2),ae+=o(B,2),ae+=o(X.crc32,4),ae+=o(X.compressedSize,4),ae+=o(X.uncompressedSize,4),ae+=o(R.length,2),ae+=o(A.length,2),{fileRecord:p.LOCAL_FILE_HEADER+ae+R+A,dirRecord:p.CENTRAL_FILE_HEADER+o(se,2)+ae+o(Z.length,2)+"\0\0\0\0"+o(W,4)+o(b,4)+R+A+Z}}var r=i("../utils"),a=i("../stream/GenericWorker"),c=i("../utf8"),d=i("../crc32"),p=i("../signature");function g(u,m,h,b){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=m,this.zipPlatform=h,this.encodeFileName=b,this.streamFiles=u,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(g,a),g.prototype.push=function(u){var m=u.meta.percent||0,h=this.entriesCount,b=this._sources.length;this.accumulate?this.contentBuffer.push(u):(this.bytesWritten+=u.data.length,a.prototype.push.call(this,{data:u.data,meta:{currentFile:this.currentFile,percent:h?(m+100*(h-b-1))/h:100}}))},g.prototype.openedSource=function(u){this.currentSourceOffset=this.bytesWritten,this.currentFile=u.file.name;var m=this.streamFiles&&!u.file.dir;if(m){var h=l(u,m,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:h.fileRecord,meta:{percent:0}})}else this.accumulate=!0},g.prototype.closedSource=function(u){this.accumulate=!1;var m=this.streamFiles&&!u.file.dir,h=l(u,m,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(h.dirRecord),m)this.push({data:(function(b){return p.DATA_DESCRIPTOR+o(b.crc32,4)+o(b.compressedSize,4)+o(b.uncompressedSize,4)})(u),meta:{percent:100}});else for(this.push({data:h.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},g.prototype.flush=function(){for(var u=this.bytesWritten,m=0;m<this.dirRecords.length;m++)this.push({data:this.dirRecords[m],meta:{percent:100}});var h=this.bytesWritten-u,b=(function(y,x,_,B,M){var T=r.transformTo("string",M(B));return p.CENTRAL_DIRECTORY_END+"\0\0\0\0"+o(y,2)+o(y,2)+o(x,4)+o(_,4)+o(T.length,2)+T})(this.dirRecords.length,h,u,this.zipComment,this.encodeFileName);this.push({data:b,meta:{percent:100}})},g.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},g.prototype.registerPrevious=function(u){this._sources.push(u);var m=this;return u.on("data",function(h){m.processChunk(h)}),u.on("end",function(){m.closedSource(m.previous.streamInfo),m._sources.length?m.prepareNextSource():m.end()}),u.on("error",function(h){m.error(h)}),this},g.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},g.prototype.error=function(u){var m=this._sources;if(!a.prototype.error.call(this,u))return!1;for(var h=0;h<m.length;h++)try{m[h].error(u)}catch{}return!0},g.prototype.lock=function(){a.prototype.lock.call(this);for(var u=this._sources,m=0;m<u.length;m++)u[m].lock()},n.exports=g},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,n,s){var o=i("../compressions"),l=i("./ZipFileWorker");s.generateWorker=function(r,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),p=0;try{r.forEach(function(g,u){p++;var m=(function(x,_){var B=x||_,M=o[B];if(!M)throw new Error(B+" is not a valid compression method !");return M})(u.options.compression,a.compression),h=u.options.compressionOptions||a.compressionOptions||{},b=u.dir,y=u.date;u._compressWorker(m,h).withStreamInfo("file",{name:g,dir:b,date:y,comment:u.comment||"",unixPermissions:u.unixPermissions,dosPermissions:u.dosPermissions}).pipe(d)}),d.entriesCount=p}catch(g){d.error(g)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,n,s){function o(){if(!(this instanceof o))return new o;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new o;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(o.prototype=i("./object")).loadAsync=i("./load"),o.support=i("./support"),o.defaults=i("./defaults"),o.version="3.10.1",o.loadAsync=function(l,r){return new o().loadAsync(l,r)},o.external=i("./external"),n.exports=o},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,n,s){var o=i("./utils"),l=i("./external"),r=i("./utf8"),a=i("./zipEntries"),c=i("./stream/Crc32Probe"),d=i("./nodejsUtils");function p(g){return new l.Promise(function(u,m){var h=g.decompressed.getContentWorker().pipe(new c);h.on("error",function(b){m(b)}).on("end",function(){h.streamInfo.crc32!==g.decompressed.crc32?m(new Error("Corrupted zip : CRC32 mismatch")):u()}).resume()})}n.exports=function(g,u){var m=this;return u=o.extend(u||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),d.isNode&&d.isStream(g)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):o.prepareContent("the loaded zip file",g,!0,u.optimizedBinaryString,u.base64).then(function(h){var b=new a(u);return b.load(h),b}).then(function(h){var b=[l.Promise.resolve(h)],y=h.files;if(u.checkCRC32)for(var x=0;x<y.length;x++)b.push(p(y[x]));return l.Promise.all(b)}).then(function(h){for(var b=h.shift(),y=b.files,x=0;x<y.length;x++){var _=y[x],B=_.fileNameStr,M=o.resolve(_.fileNameStr);m.file(M,_.decompressed,{binary:!0,optimizedBinaryString:!0,date:_.date,dir:_.dir,comment:_.fileCommentStr.length?_.fileCommentStr:null,unixPermissions:_.unixPermissions,dosPermissions:_.dosPermissions,createFolders:u.createFolders}),_.dir||(m.file(M).unsafeOriginalName=B)}return b.zipComment.length&&(m.comment=b.zipComment),m})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,n,s){var o=i("../utils"),l=i("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}o.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,n,s){var o=i("readable-stream").Readable;function l(r,a,c){o.call(this,a),this._helper=r;var d=this;r.on("data",function(p,g){d.push(p)||d._helper.pause(),c&&c(g)}).on("error",function(p){d.emit("error",p)}).on("end",function(){d.push(null)})}i("../utils").inherits(l,o),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(i,n,s){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(o,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(o,l);if(typeof o=="number")throw new Error('The "data" argument must not be a number');return new Buffer(o,l)},allocBuffer:function(o){if(Buffer.alloc)return Buffer.alloc(o);var l=new Buffer(o);return l.fill(0),l},isBuffer:function(o){return Buffer.isBuffer(o)},isStream:function(o){return o&&typeof o.on=="function"&&typeof o.pause=="function"&&typeof o.resume=="function"}}},{}],15:[function(i,n,s){function o(M,T,w){var R,O=r.getTypeOf(T),N=r.extend(w||{},d);N.date=N.date||new Date,N.compression!==null&&(N.compression=N.compression.toUpperCase()),typeof N.unixPermissions=="string"&&(N.unixPermissions=parseInt(N.unixPermissions,8)),N.unixPermissions&&16384&N.unixPermissions&&(N.dir=!0),N.dosPermissions&&16&N.dosPermissions&&(N.dir=!0),N.dir&&(M=y(M)),N.createFolders&&(R=b(M))&&x.call(this,R,!0);var Z=O==="string"&&N.binary===!1&&N.base64===!1;w&&w.binary!==void 0||(N.binary=!Z),(T instanceof p&&T.uncompressedSize===0||N.dir||!T||T.length===0)&&(N.base64=!1,N.binary=!0,T="",N.compression="STORE",O="string");var S=null;S=T instanceof p||T instanceof a?T:m.isNode&&m.isStream(T)?new h(M,T):r.prepareContent(M,T,N.binary,N.optimizedBinaryString,N.base64);var z=new g(M,S,N);this.files[M]=z}var l=i("./utf8"),r=i("./utils"),a=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),d=i("./defaults"),p=i("./compressedObject"),g=i("./zipObject"),u=i("./generate"),m=i("./nodejsUtils"),h=i("./nodejs/NodejsStreamInputAdapter"),b=function(M){M.slice(-1)==="/"&&(M=M.substring(0,M.length-1));var T=M.lastIndexOf("/");return 0<T?M.substring(0,T):""},y=function(M){return M.slice(-1)!=="/"&&(M+="/"),M},x=function(M,T){return T=T!==void 0?T:d.createFolders,M=y(M),this.files[M]||o.call(this,M,null,{dir:!0,createFolders:T}),this.files[M]};function _(M){return Object.prototype.toString.call(M)==="[object RegExp]"}var B={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(M){var T,w,R;for(T in this.files)R=this.files[T],(w=T.slice(this.root.length,T.length))&&T.slice(0,this.root.length)===this.root&&M(w,R)},filter:function(M){var T=[];return this.forEach(function(w,R){M(w,R)&&T.push(R)}),T},file:function(M,T,w){if(arguments.length!==1)return M=this.root+M,o.call(this,M,T,w),this;if(_(M)){var R=M;return this.filter(function(N,Z){return!Z.dir&&R.test(N)})}var O=this.files[this.root+M];return O&&!O.dir?O:null},folder:function(M){if(!M)return this;if(_(M))return this.filter(function(O,N){return N.dir&&M.test(O)});var T=this.root+M,w=x.call(this,T),R=this.clone();return R.root=w.name,R},remove:function(M){M=this.root+M;var T=this.files[M];if(T||(M.slice(-1)!=="/"&&(M+="/"),T=this.files[M]),T&&!T.dir)delete this.files[M];else for(var w=this.filter(function(O,N){return N.name.slice(0,M.length)===M}),R=0;R<w.length;R++)delete this.files[w[R].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(M){var T,w={};try{if((w=r.extend(M||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=w.type.toLowerCase(),w.compression=w.compression.toUpperCase(),w.type==="binarystring"&&(w.type="string"),!w.type)throw new Error("No output type specified.");r.checkSupport(w.type),w.platform!=="darwin"&&w.platform!=="freebsd"&&w.platform!=="linux"&&w.platform!=="sunos"||(w.platform="UNIX"),w.platform==="win32"&&(w.platform="DOS");var R=w.comment||this.comment||"";T=u.generateWorker(this,w,R)}catch(O){(T=new a("error")).error(O)}return new c(T,w.type||"string",w.mimeType)},generateAsync:function(M,T){return this.generateInternalStream(M).accumulate(T)},generateNodeStream:function(M,T){return(M=M||{}).type||(M.type="nodebuffer"),this.generateInternalStream(M).toNodejsStream(T)}};n.exports=B},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,n,s){n.exports=i("stream")},{stream:void 0}],17:[function(i,n,s){var o=i("./DataReader");function l(r){o.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}i("../utils").inherits(l,o),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),p=r.charCodeAt(3),g=this.length-4;0<=g;--g)if(this.data[g]===a&&this.data[g+1]===c&&this.data[g+2]===d&&this.data[g+3]===p)return g-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),p=r.charCodeAt(3),g=this.readData(4);return a===g[0]&&c===g[1]&&d===g[2]&&p===g[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(i,n,s){var o=i("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return o.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=l},{"../utils":32}],19:[function(i,n,s){var o=i("./Uint8ArrayReader");function l(r){o.call(this,r)}i("../utils").inherits(l,o),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,n,s){var o=i("./DataReader");function l(r){o.call(this,r)}i("../utils").inherits(l,o),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(i,n,s){var o=i("./ArrayReader");function l(r){o.call(this,r)}i("../utils").inherits(l,o),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(i,n,s){var o=i("../utils"),l=i("../support"),r=i("./ArrayReader"),a=i("./StringReader"),c=i("./NodeBufferReader"),d=i("./Uint8ArrayReader");n.exports=function(p){var g=o.getTypeOf(p);return o.checkSupport(g),g!=="string"||l.uint8array?g==="nodebuffer"?new c(p):l.uint8array?new d(o.transformTo("uint8array",p)):new r(o.transformTo("array",p)):new a(p)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,n,s){s.LOCAL_FILE_HEADER="PK",s.CENTRAL_FILE_HEADER="PK",s.CENTRAL_DIRECTORY_END="PK",s.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",s.ZIP64_CENTRAL_DIRECTORY_END="PK",s.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,n,s){var o=i("./GenericWorker"),l=i("../utils");function r(a){o.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,o),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,n,s){var o=i("./GenericWorker"),l=i("../crc32");function r(){o.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,o),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,n,s){var o=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}o.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,n,s){var o=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=o.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}o.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,o.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(o.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,n,s){function o(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}o.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=o},{}],29:[function(i,n,s){var o=i("../utils"),l=i("./ConvertWorker"),r=i("./GenericWorker"),a=i("../base64"),c=i("../support"),d=i("../external"),p=null;if(c.nodestream)try{p=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function g(m,h){return new d.Promise(function(b,y){var x=[],_=m._internalType,B=m._outputType,M=m._mimeType;m.on("data",function(T,w){x.push(T),h&&h(w)}).on("error",function(T){x=[],y(T)}).on("end",function(){try{var T=(function(w,R,O){switch(w){case"blob":return o.newBlob(o.transformTo("arraybuffer",R),O);case"base64":return a.encode(R);default:return o.transformTo(w,R)}})(B,(function(w,R){var O,N=0,Z=null,S=0;for(O=0;O<R.length;O++)S+=R[O].length;switch(w){case"string":return R.join("");case"array":return Array.prototype.concat.apply([],R);case"uint8array":for(Z=new Uint8Array(S),O=0;O<R.length;O++)Z.set(R[O],N),N+=R[O].length;return Z;case"nodebuffer":return Buffer.concat(R);default:throw new Error("concat : unsupported type '"+w+"'")}})(_,x),M);b(T)}catch(w){y(w)}x=[]}).resume()})}function u(m,h,b){var y=h;switch(h){case"blob":case"arraybuffer":y="uint8array";break;case"base64":y="string"}try{this._internalType=y,this._outputType=h,this._mimeType=b,o.checkSupport(y),this._worker=m.pipe(new l(y)),m.lock()}catch(x){this._worker=new r("error"),this._worker.error(x)}}u.prototype={accumulate:function(m){return g(this,m)},on:function(m,h){var b=this;return m==="data"?this._worker.on(m,function(y){h.call(b,y.data,y.meta)}):this._worker.on(m,function(){o.delay(h,arguments,b)}),this},resume:function(){return o.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(m){if(o.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new p(this,{objectMode:this._outputType!=="nodebuffer"},m)}},n.exports=u},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,n,s){if(s.base64=!0,s.array=!0,s.string=!0,s.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",s.nodebuffer=typeof Buffer<"u",s.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")s.blob=!1;else{var o=new ArrayBuffer(0);try{s.blob=new Blob([o],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(o),s.blob=l.getBlob("application/zip").size===0}catch{s.blob=!1}}}try{s.nodestream=!!i("readable-stream").Readable}catch{s.nodestream=!1}},{"readable-stream":16}],31:[function(i,n,s){for(var o=i("./utils"),l=i("./support"),r=i("./nodejsUtils"),a=i("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function p(){a.call(this,"utf-8 decode"),this.leftOver=null}function g(){a.call(this,"utf-8 encode")}s.utf8encode=function(u){return l.nodebuffer?r.newBufferFrom(u,"utf-8"):(function(m){var h,b,y,x,_,B=m.length,M=0;for(x=0;x<B;x++)(64512&(b=m.charCodeAt(x)))==55296&&x+1<B&&(64512&(y=m.charCodeAt(x+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),x++),M+=b<128?1:b<2048?2:b<65536?3:4;for(h=l.uint8array?new Uint8Array(M):new Array(M),x=_=0;_<M;x++)(64512&(b=m.charCodeAt(x)))==55296&&x+1<B&&(64512&(y=m.charCodeAt(x+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),x++),b<128?h[_++]=b:(b<2048?h[_++]=192|b>>>6:(b<65536?h[_++]=224|b>>>12:(h[_++]=240|b>>>18,h[_++]=128|b>>>12&63),h[_++]=128|b>>>6&63),h[_++]=128|63&b);return h})(u)},s.utf8decode=function(u){return l.nodebuffer?o.transformTo("nodebuffer",u).toString("utf-8"):(function(m){var h,b,y,x,_=m.length,B=new Array(2*_);for(h=b=0;h<_;)if((y=m[h++])<128)B[b++]=y;else if(4<(x=c[y]))B[b++]=65533,h+=x-1;else{for(y&=x===2?31:x===3?15:7;1<x&&h<_;)y=y<<6|63&m[h++],x--;1<x?B[b++]=65533:y<65536?B[b++]=y:(y-=65536,B[b++]=55296|y>>10&1023,B[b++]=56320|1023&y)}return B.length!==b&&(B.subarray?B=B.subarray(0,b):B.length=b),o.applyFromCharCode(B)})(u=o.transformTo(l.uint8array?"uint8array":"array",u))},o.inherits(p,a),p.prototype.processChunk=function(u){var m=o.transformTo(l.uint8array?"uint8array":"array",u.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var h=m;(m=new Uint8Array(h.length+this.leftOver.length)).set(this.leftOver,0),m.set(h,this.leftOver.length)}else m=this.leftOver.concat(m);this.leftOver=null}var b=(function(x,_){var B;for((_=_||x.length)>x.length&&(_=x.length),B=_-1;0<=B&&(192&x[B])==128;)B--;return B<0||B===0?_:B+c[x[B]]>_?B:_})(m),y=m;b!==m.length&&(l.uint8array?(y=m.subarray(0,b),this.leftOver=m.subarray(b,m.length)):(y=m.slice(0,b),this.leftOver=m.slice(b,m.length))),this.push({data:s.utf8decode(y),meta:u.meta})},p.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:s.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},s.Utf8DecodeWorker=p,o.inherits(g,a),g.prototype.processChunk=function(u){this.push({data:s.utf8encode(u.data),meta:u.meta})},s.Utf8EncodeWorker=g},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,n,s){var o=i("./support"),l=i("./base64"),r=i("./nodejsUtils"),a=i("./external");function c(h){return h}function d(h,b){for(var y=0;y<h.length;++y)b[y]=255&h.charCodeAt(y);return b}i("setimmediate"),s.newBlob=function(h,b){s.checkSupport("blob");try{return new Blob([h],{type:b})}catch{try{var y=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return y.append(h),y.getBlob(b)}catch{throw new Error("Bug : can't construct the Blob.")}}};var p={stringifyByChunk:function(h,b,y){var x=[],_=0,B=h.length;if(B<=y)return String.fromCharCode.apply(null,h);for(;_<B;)b==="array"||b==="nodebuffer"?x.push(String.fromCharCode.apply(null,h.slice(_,Math.min(_+y,B)))):x.push(String.fromCharCode.apply(null,h.subarray(_,Math.min(_+y,B)))),_+=y;return x.join("")},stringifyByChar:function(h){for(var b="",y=0;y<h.length;y++)b+=String.fromCharCode(h[y]);return b},applyCanBeUsed:{uint8array:(function(){try{return o.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return o.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function g(h){var b=65536,y=s.getTypeOf(h),x=!0;if(y==="uint8array"?x=p.applyCanBeUsed.uint8array:y==="nodebuffer"&&(x=p.applyCanBeUsed.nodebuffer),x)for(;1<b;)try{return p.stringifyByChunk(h,y,b)}catch{b=Math.floor(b/2)}return p.stringifyByChar(h)}function u(h,b){for(var y=0;y<h.length;y++)b[y]=h[y];return b}s.applyFromCharCode=g;var m={};m.string={string:c,array:function(h){return d(h,new Array(h.length))},arraybuffer:function(h){return m.string.uint8array(h).buffer},uint8array:function(h){return d(h,new Uint8Array(h.length))},nodebuffer:function(h){return d(h,r.allocBuffer(h.length))}},m.array={string:g,array:c,arraybuffer:function(h){return new Uint8Array(h).buffer},uint8array:function(h){return new Uint8Array(h)},nodebuffer:function(h){return r.newBufferFrom(h)}},m.arraybuffer={string:function(h){return g(new Uint8Array(h))},array:function(h){return u(new Uint8Array(h),new Array(h.byteLength))},arraybuffer:c,uint8array:function(h){return new Uint8Array(h)},nodebuffer:function(h){return r.newBufferFrom(new Uint8Array(h))}},m.uint8array={string:g,array:function(h){return u(h,new Array(h.length))},arraybuffer:function(h){return h.buffer},uint8array:c,nodebuffer:function(h){return r.newBufferFrom(h)}},m.nodebuffer={string:g,array:function(h){return u(h,new Array(h.length))},arraybuffer:function(h){return m.nodebuffer.uint8array(h).buffer},uint8array:function(h){return u(h,new Uint8Array(h.length))},nodebuffer:c},s.transformTo=function(h,b){if(b=b||"",!h)return b;s.checkSupport(h);var y=s.getTypeOf(b);return m[y][h](b)},s.resolve=function(h){for(var b=h.split("/"),y=[],x=0;x<b.length;x++){var _=b[x];_==="."||_===""&&x!==0&&x!==b.length-1||(_===".."?y.pop():y.push(_))}return y.join("/")},s.getTypeOf=function(h){return typeof h=="string"?"string":Object.prototype.toString.call(h)==="[object Array]"?"array":o.nodebuffer&&r.isBuffer(h)?"nodebuffer":o.uint8array&&h instanceof Uint8Array?"uint8array":o.arraybuffer&&h instanceof ArrayBuffer?"arraybuffer":void 0},s.checkSupport=function(h){if(!o[h.toLowerCase()])throw new Error(h+" is not supported by this platform")},s.MAX_VALUE_16BITS=65535,s.MAX_VALUE_32BITS=-1,s.pretty=function(h){var b,y,x="";for(y=0;y<(h||"").length;y++)x+="\\x"+((b=h.charCodeAt(y))<16?"0":"")+b.toString(16).toUpperCase();return x},s.delay=function(h,b,y){setImmediate(function(){h.apply(y||null,b||[])})},s.inherits=function(h,b){function y(){}y.prototype=b.prototype,h.prototype=new y},s.extend=function(){var h,b,y={};for(h=0;h<arguments.length;h++)for(b in arguments[h])Object.prototype.hasOwnProperty.call(arguments[h],b)&&y[b]===void 0&&(y[b]=arguments[h][b]);return y},s.prepareContent=function(h,b,y,x,_){return a.Promise.resolve(b).then(function(B){return o.blob&&(B instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(B))!==-1)&&typeof FileReader<"u"?new a.Promise(function(M,T){var w=new FileReader;w.onload=function(R){M(R.target.result)},w.onerror=function(R){T(R.target.error)},w.readAsArrayBuffer(B)}):B}).then(function(B){var M=s.getTypeOf(B);return M?(M==="arraybuffer"?B=s.transformTo("uint8array",B):M==="string"&&(_?B=l.decode(B):y&&x!==!0&&(B=(function(T){return d(T,o.uint8array?new Uint8Array(T.length):new Array(T.length))})(B))),B):a.Promise.reject(new Error("Can't read the data of '"+h+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,n,s){var o=i("./reader/readerFor"),l=i("./utils"),r=i("./signature"),a=i("./zipEntry"),c=i("./support");function d(p){this.files=[],this.loadOptions=p}d.prototype={checkSignature:function(p){if(!this.reader.readAndCheckSignature(p)){this.reader.index-=4;var g=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(g)+", expected "+l.pretty(p)+")")}},isSignature:function(p,g){var u=this.reader.index;this.reader.setIndex(p);var m=this.reader.readString(4)===g;return this.reader.setIndex(u),m},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var p=this.reader.readData(this.zipCommentLength),g=c.uint8array?"uint8array":"array",u=l.transformTo(g,p);this.zipComment=this.loadOptions.decodeFileName(u)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var p,g,u,m=this.zip64EndOfCentralSize-44;0<m;)p=this.reader.readInt(2),g=this.reader.readInt(4),u=this.reader.readData(g),this.zip64ExtensibleData[p]={id:p,length:g,value:u}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var p,g;for(p=0;p<this.files.length;p++)g=this.files[p],this.reader.setIndex(g.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),g.readLocalPart(this.reader),g.handleUTF8(),g.processAttributes()},readCentralDir:function(){var p;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(p=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(p);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var p=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(p<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(p);var g=p;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(p=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(p),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var u=this.centralDirOffset+this.centralDirSize;this.zip64&&(u+=20,u+=12+this.zip64EndOfCentralSize);var m=g-u;if(0<m)this.isSignature(g,r.CENTRAL_FILE_HEADER)||(this.reader.zero=m);else if(m<0)throw new Error("Corrupted zip: missing "+Math.abs(m)+" bytes.")},prepareReader:function(p){this.reader=o(p)},load:function(p){this.prepareReader(p),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,n,s){var o=i("./reader/readerFor"),l=i("./utils"),r=i("./compressedObject"),a=i("./crc32"),c=i("./utf8"),d=i("./compressions"),p=i("./support");function g(u,m){this.options=u,this.loadOptions=m}g.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(u){var m,h;if(u.skip(22),this.fileNameLength=u.readInt(2),h=u.readInt(2),this.fileName=u.readData(this.fileNameLength),u.skip(h),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((m=(function(b){for(var y in d)if(Object.prototype.hasOwnProperty.call(d,y)&&d[y].magic===b)return d[y];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,m,u.readData(this.compressedSize))},readCentralPart:function(u){this.versionMadeBy=u.readInt(2),u.skip(2),this.bitFlag=u.readInt(2),this.compressionMethod=u.readString(2),this.date=u.readDate(),this.crc32=u.readInt(4),this.compressedSize=u.readInt(4),this.uncompressedSize=u.readInt(4);var m=u.readInt(2);if(this.extraFieldsLength=u.readInt(2),this.fileCommentLength=u.readInt(2),this.diskNumberStart=u.readInt(2),this.internalFileAttributes=u.readInt(2),this.externalFileAttributes=u.readInt(4),this.localHeaderOffset=u.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");u.skip(m),this.readExtraFields(u),this.parseZIP64ExtraField(u),this.fileComment=u.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var u=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),u==0&&(this.dosPermissions=63&this.externalFileAttributes),u==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var u=o(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=u.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=u.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=u.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=u.readInt(4))}},readExtraFields:function(u){var m,h,b,y=u.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});u.index+4<y;)m=u.readInt(2),h=u.readInt(2),b=u.readData(h),this.extraFields[m]={id:m,length:h,value:b};u.setIndex(y)},handleUTF8:function(){var u=p.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var m=this.findExtraFieldUnicodePath();if(m!==null)this.fileNameStr=m;else{var h=l.transformTo(u,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(h)}var b=this.findExtraFieldUnicodeComment();if(b!==null)this.fileCommentStr=b;else{var y=l.transformTo(u,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(y)}}},findExtraFieldUnicodePath:function(){var u=this.extraFields[28789];if(u){var m=o(u.value);return m.readInt(1)!==1||a(this.fileName)!==m.readInt(4)?null:c.utf8decode(m.readData(u.length-5))}return null},findExtraFieldUnicodeComment:function(){var u=this.extraFields[25461];if(u){var m=o(u.value);return m.readInt(1)!==1||a(this.fileComment)!==m.readInt(4)?null:c.utf8decode(m.readData(u.length-5))}return null}},n.exports=g},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,n,s){function o(m,h,b){this.name=m,this.dir=b.dir,this.date=b.date,this.comment=b.comment,this.unixPermissions=b.unixPermissions,this.dosPermissions=b.dosPermissions,this._data=h,this._dataBinary=b.binary,this.options={compression:b.compression,compressionOptions:b.compressionOptions}}var l=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),a=i("./utf8"),c=i("./compressedObject"),d=i("./stream/GenericWorker");o.prototype={internalStream:function(m){var h=null,b="string";try{if(!m)throw new Error("No output type specified.");var y=(b=m.toLowerCase())==="string"||b==="text";b!=="binarystring"&&b!=="text"||(b="string"),h=this._decompressWorker();var x=!this._dataBinary;x&&!y&&(h=h.pipe(new a.Utf8EncodeWorker)),!x&&y&&(h=h.pipe(new a.Utf8DecodeWorker))}catch(_){(h=new d("error")).error(_)}return new l(h,b,"")},async:function(m,h){return this.internalStream(m).accumulate(h)},nodeStream:function(m,h){return this.internalStream(m||"nodebuffer").toNodejsStream(h)},_compressWorker:function(m,h){if(this._data instanceof c&&this._data.compression.magic===m.magic)return this._data.getCompressedWorker();var b=this._decompressWorker();return this._dataBinary||(b=b.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(b,m,h)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new r(this._data)}};for(var p=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],g=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},u=0;u<p.length;u++)o.prototype[p[u]]=g;n.exports=o},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,n,s){(function(o){var l,r,a=o.MutationObserver||o.WebKitMutationObserver;if(a){var c=0,d=new a(m),p=o.document.createTextNode("");d.observe(p,{characterData:!0}),l=function(){p.data=c=++c%2}}else if(o.setImmediate||o.MessageChannel===void 0)l="document"in o&&"onreadystatechange"in o.document.createElement("script")?function(){var h=o.document.createElement("script");h.onreadystatechange=function(){m(),h.onreadystatechange=null,h.parentNode.removeChild(h),h=null},o.document.documentElement.appendChild(h)}:function(){setTimeout(m,0)};else{var g=new o.MessageChannel;g.port1.onmessage=m,l=function(){g.port2.postMessage(0)}}var u=[];function m(){var h,b;r=!0;for(var y=u.length;y;){for(b=u,u=[],h=-1;++h<y;)b[h]();y=u.length}r=!1}n.exports=function(h){u.push(h)!==1||r||l()}}).call(this,typeof es<"u"?es:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,n,s){var o=i("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function p(y){if(typeof y!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,y!==l&&h(this,y)}function g(y,x,_){this.promise=y,typeof x=="function"&&(this.onFulfilled=x,this.callFulfilled=this.otherCallFulfilled),typeof _=="function"&&(this.onRejected=_,this.callRejected=this.otherCallRejected)}function u(y,x,_){o(function(){var B;try{B=x(_)}catch(M){return r.reject(y,M)}B===y?r.reject(y,new TypeError("Cannot resolve promise with itself")):r.resolve(y,B)})}function m(y){var x=y&&y.then;if(y&&(typeof y=="object"||typeof y=="function")&&typeof x=="function")return function(){x.apply(y,arguments)}}function h(y,x){var _=!1;function B(w){_||(_=!0,r.reject(y,w))}function M(w){_||(_=!0,r.resolve(y,w))}var T=b(function(){x(M,B)});T.status==="error"&&B(T.value)}function b(y,x){var _={};try{_.value=y(x),_.status="success"}catch(B){_.status="error",_.value=B}return _}(n.exports=p).prototype.finally=function(y){if(typeof y!="function")return this;var x=this.constructor;return this.then(function(_){return x.resolve(y()).then(function(){return _})},function(_){return x.resolve(y()).then(function(){throw _})})},p.prototype.catch=function(y){return this.then(null,y)},p.prototype.then=function(y,x){if(typeof y!="function"&&this.state===c||typeof x!="function"&&this.state===a)return this;var _=new this.constructor(l);return this.state!==d?u(_,this.state===c?y:x,this.outcome):this.queue.push(new g(_,y,x)),_},g.prototype.callFulfilled=function(y){r.resolve(this.promise,y)},g.prototype.otherCallFulfilled=function(y){u(this.promise,this.onFulfilled,y)},g.prototype.callRejected=function(y){r.reject(this.promise,y)},g.prototype.otherCallRejected=function(y){u(this.promise,this.onRejected,y)},r.resolve=function(y,x){var _=b(m,x);if(_.status==="error")return r.reject(y,_.value);var B=_.value;if(B)h(y,B);else{y.state=c,y.outcome=x;for(var M=-1,T=y.queue.length;++M<T;)y.queue[M].callFulfilled(x)}return y},r.reject=function(y,x){y.state=a,y.outcome=x;for(var _=-1,B=y.queue.length;++_<B;)y.queue[_].callRejected(x);return y},p.resolve=function(y){return y instanceof this?y:r.resolve(new this(l),y)},p.reject=function(y){var x=new this(l);return r.reject(x,y)},p.all=function(y){var x=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var _=y.length,B=!1;if(!_)return this.resolve([]);for(var M=new Array(_),T=0,w=-1,R=new this(l);++w<_;)O(y[w],w);return R;function O(N,Z){x.resolve(N).then(function(S){M[Z]=S,++T!==_||B||(B=!0,r.resolve(R,M))},function(S){B||(B=!0,r.reject(R,S))})}},p.race=function(y){var x=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var _=y.length,B=!1;if(!_)return this.resolve([]);for(var M=-1,T=new this(l);++M<_;)w=y[M],x.resolve(w).then(function(R){B||(B=!0,r.resolve(T,R))},function(R){B||(B=!0,r.reject(T,R))});var w;return T}},{immediate:36}],38:[function(i,n,s){var o={};(0,i("./lib/utils/common").assign)(o,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),n.exports=o},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,n,s){var o=i("./zlib/deflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/messages"),c=i("./zlib/zstream"),d=Object.prototype.toString,p=0,g=-1,u=0,m=8;function h(y){if(!(this instanceof h))return new h(y);this.options=l.assign({level:g,method:m,chunkSize:16384,windowBits:15,memLevel:8,strategy:u,to:""},y||{});var x=this.options;x.raw&&0<x.windowBits?x.windowBits=-x.windowBits:x.gzip&&0<x.windowBits&&x.windowBits<16&&(x.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var _=o.deflateInit2(this.strm,x.level,x.method,x.windowBits,x.memLevel,x.strategy);if(_!==p)throw new Error(a[_]);if(x.header&&o.deflateSetHeader(this.strm,x.header),x.dictionary){var B;if(B=typeof x.dictionary=="string"?r.string2buf(x.dictionary):d.call(x.dictionary)==="[object ArrayBuffer]"?new Uint8Array(x.dictionary):x.dictionary,(_=o.deflateSetDictionary(this.strm,B))!==p)throw new Error(a[_]);this._dict_set=!0}}function b(y,x){var _=new h(x);if(_.push(y,!0),_.err)throw _.msg||a[_.err];return _.result}h.prototype.push=function(y,x){var _,B,M=this.strm,T=this.options.chunkSize;if(this.ended)return!1;B=x===~~x?x:x===!0?4:0,typeof y=="string"?M.input=r.string2buf(y):d.call(y)==="[object ArrayBuffer]"?M.input=new Uint8Array(y):M.input=y,M.next_in=0,M.avail_in=M.input.length;do{if(M.avail_out===0&&(M.output=new l.Buf8(T),M.next_out=0,M.avail_out=T),(_=o.deflate(M,B))!==1&&_!==p)return this.onEnd(_),!(this.ended=!0);M.avail_out!==0&&(M.avail_in!==0||B!==4&&B!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(M.output,M.next_out))):this.onData(l.shrinkBuf(M.output,M.next_out)))}while((0<M.avail_in||M.avail_out===0)&&_!==1);return B===4?(_=o.deflateEnd(this.strm),this.onEnd(_),this.ended=!0,_===p):B!==2||(this.onEnd(p),!(M.avail_out=0))},h.prototype.onData=function(y){this.chunks.push(y)},h.prototype.onEnd=function(y){y===p&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=y,this.msg=this.strm.msg},s.Deflate=h,s.deflate=b,s.deflateRaw=function(y,x){return(x=x||{}).raw=!0,b(y,x)},s.gzip=function(y,x){return(x=x||{}).gzip=!0,b(y,x)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,n,s){var o=i("./zlib/inflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/constants"),c=i("./zlib/messages"),d=i("./zlib/zstream"),p=i("./zlib/gzheader"),g=Object.prototype.toString;function u(h){if(!(this instanceof u))return new u(h);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},h||{});var b=this.options;b.raw&&0<=b.windowBits&&b.windowBits<16&&(b.windowBits=-b.windowBits,b.windowBits===0&&(b.windowBits=-15)),!(0<=b.windowBits&&b.windowBits<16)||h&&h.windowBits||(b.windowBits+=32),15<b.windowBits&&b.windowBits<48&&(15&b.windowBits)==0&&(b.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var y=o.inflateInit2(this.strm,b.windowBits);if(y!==a.Z_OK)throw new Error(c[y]);this.header=new p,o.inflateGetHeader(this.strm,this.header)}function m(h,b){var y=new u(b);if(y.push(h,!0),y.err)throw y.msg||c[y.err];return y.result}u.prototype.push=function(h,b){var y,x,_,B,M,T,w=this.strm,R=this.options.chunkSize,O=this.options.dictionary,N=!1;if(this.ended)return!1;x=b===~~b?b:b===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof h=="string"?w.input=r.binstring2buf(h):g.call(h)==="[object ArrayBuffer]"?w.input=new Uint8Array(h):w.input=h,w.next_in=0,w.avail_in=w.input.length;do{if(w.avail_out===0&&(w.output=new l.Buf8(R),w.next_out=0,w.avail_out=R),(y=o.inflate(w,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&O&&(T=typeof O=="string"?r.string2buf(O):g.call(O)==="[object ArrayBuffer]"?new Uint8Array(O):O,y=o.inflateSetDictionary(this.strm,T)),y===a.Z_BUF_ERROR&&N===!0&&(y=a.Z_OK,N=!1),y!==a.Z_STREAM_END&&y!==a.Z_OK)return this.onEnd(y),!(this.ended=!0);w.next_out&&(w.avail_out!==0&&y!==a.Z_STREAM_END&&(w.avail_in!==0||x!==a.Z_FINISH&&x!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(_=r.utf8border(w.output,w.next_out),B=w.next_out-_,M=r.buf2string(w.output,_),w.next_out=B,w.avail_out=R-B,B&&l.arraySet(w.output,w.output,_,B,0),this.onData(M)):this.onData(l.shrinkBuf(w.output,w.next_out)))),w.avail_in===0&&w.avail_out===0&&(N=!0)}while((0<w.avail_in||w.avail_out===0)&&y!==a.Z_STREAM_END);return y===a.Z_STREAM_END&&(x=a.Z_FINISH),x===a.Z_FINISH?(y=o.inflateEnd(this.strm),this.onEnd(y),this.ended=!0,y===a.Z_OK):x!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(w.avail_out=0))},u.prototype.onData=function(h){this.chunks.push(h)},u.prototype.onEnd=function(h){h===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=h,this.msg=this.strm.msg},s.Inflate=u,s.inflate=m,s.inflateRaw=function(h,b){return(b=b||{}).raw=!0,m(h,b)},s.ungzip=m},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";s.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var p in d)d.hasOwnProperty(p)&&(a[p]=d[p])}}return a},s.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,p,g){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+p),g);else for(var u=0;u<p;u++)a[g+u]=c[d+u]},flattenChunks:function(a){var c,d,p,g,u,m;for(c=p=0,d=a.length;c<d;c++)p+=a[c].length;for(m=new Uint8Array(p),c=g=0,d=a.length;c<d;c++)u=a[c],m.set(u,g),g+=u.length;return m}},r={arraySet:function(a,c,d,p,g){for(var u=0;u<p;u++)a[g+u]=c[d+u]},flattenChunks:function(a){return[].concat.apply([],a)}};s.setTyped=function(a){a?(s.Buf8=Uint8Array,s.Buf16=Uint16Array,s.Buf32=Int32Array,s.assign(s,l)):(s.Buf8=Array,s.Buf16=Array,s.Buf32=Array,s.assign(s,r))},s.setTyped(o)},{}],42:[function(i,n,s){var o=i("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new o.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(p,g){if(g<65537&&(p.subarray&&r||!p.subarray&&l))return String.fromCharCode.apply(null,o.shrinkBuf(p,g));for(var u="",m=0;m<g;m++)u+=String.fromCharCode(p[m]);return u}a[254]=a[254]=1,s.string2buf=function(p){var g,u,m,h,b,y=p.length,x=0;for(h=0;h<y;h++)(64512&(u=p.charCodeAt(h)))==55296&&h+1<y&&(64512&(m=p.charCodeAt(h+1)))==56320&&(u=65536+(u-55296<<10)+(m-56320),h++),x+=u<128?1:u<2048?2:u<65536?3:4;for(g=new o.Buf8(x),h=b=0;b<x;h++)(64512&(u=p.charCodeAt(h)))==55296&&h+1<y&&(64512&(m=p.charCodeAt(h+1)))==56320&&(u=65536+(u-55296<<10)+(m-56320),h++),u<128?g[b++]=u:(u<2048?g[b++]=192|u>>>6:(u<65536?g[b++]=224|u>>>12:(g[b++]=240|u>>>18,g[b++]=128|u>>>12&63),g[b++]=128|u>>>6&63),g[b++]=128|63&u);return g},s.buf2binstring=function(p){return d(p,p.length)},s.binstring2buf=function(p){for(var g=new o.Buf8(p.length),u=0,m=g.length;u<m;u++)g[u]=p.charCodeAt(u);return g},s.buf2string=function(p,g){var u,m,h,b,y=g||p.length,x=new Array(2*y);for(u=m=0;u<y;)if((h=p[u++])<128)x[m++]=h;else if(4<(b=a[h]))x[m++]=65533,u+=b-1;else{for(h&=b===2?31:b===3?15:7;1<b&&u<y;)h=h<<6|63&p[u++],b--;1<b?x[m++]=65533:h<65536?x[m++]=h:(h-=65536,x[m++]=55296|h>>10&1023,x[m++]=56320|1023&h)}return d(x,m)},s.utf8border=function(p,g){var u;for((g=g||p.length)>p.length&&(g=p.length),u=g-1;0<=u&&(192&p[u])==128;)u--;return u<0||u===0?g:u+a[p[u]]>g?u:g}},{"./common":41}],43:[function(i,n,s){n.exports=function(o,l,r,a){for(var c=65535&o|0,d=o>>>16&65535|0,p=0;r!==0;){for(r-=p=2e3<r?2e3:r;d=d+(c=c+l[a++]|0)|0,--p;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(i,n,s){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,n,s){var o=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();n.exports=function(l,r,a,c){var d=o,p=c+a;l^=-1;for(var g=c;g<p;g++)l=l>>>8^d[255&(l^r[g])];return-1^l}},{}],46:[function(i,n,s){var o,l=i("../utils/common"),r=i("./trees"),a=i("./adler32"),c=i("./crc32"),d=i("./messages"),p=0,g=4,u=0,m=-2,h=-1,b=4,y=2,x=8,_=9,B=286,M=30,T=19,w=2*B+1,R=15,O=3,N=258,Z=N+O+1,S=42,z=113,k=1,A=2,F=3,E=4;function D(v,U){return v.msg=d[U],U}function P(v){return(v<<1)-(4<v?9:0)}function X(v){for(var U=v.length;0<=--U;)v[U]=0}function G(v){var U=v.state,H=U.pending;H>v.avail_out&&(H=v.avail_out),H!==0&&(l.arraySet(v.output,U.pending_buf,U.pending_out,H,v.next_out),v.next_out+=H,U.pending_out+=H,v.total_out+=H,v.avail_out-=H,U.pending-=H,U.pending===0&&(U.pending_out=0))}function W(v,U){r._tr_flush_block(v,0<=v.block_start?v.block_start:-1,v.strstart-v.block_start,U),v.block_start=v.strstart,G(v.strm)}function se(v,U){v.pending_buf[v.pending++]=U}function ae(v,U){v.pending_buf[v.pending++]=U>>>8&255,v.pending_buf[v.pending++]=255&U}function ce(v,U){var H,$,I=v.max_chain_length,C=v.strstart,V=v.prev_length,q=v.nice_match,K=v.strstart>v.w_size-Z?v.strstart-(v.w_size-Z):0,ee=v.window,le=v.w_mask,oe=v.prev,he=v.strstart+N,ie=ee[C+V-1],ne=ee[C+V];v.prev_length>=v.good_match&&(I>>=2),q>v.lookahead&&(q=v.lookahead);do if(ee[(H=U)+V]===ne&&ee[H+V-1]===ie&&ee[H]===ee[C]&&ee[++H]===ee[C+1]){C+=2,H++;do;while(ee[++C]===ee[++H]&&ee[++C]===ee[++H]&&ee[++C]===ee[++H]&&ee[++C]===ee[++H]&&ee[++C]===ee[++H]&&ee[++C]===ee[++H]&&ee[++C]===ee[++H]&&ee[++C]===ee[++H]&&C<he);if($=N-(he-C),C=he-N,V<$){if(v.match_start=U,q<=(V=$))break;ie=ee[C+V-1],ne=ee[C+V]}}while((U=oe[U&le])>K&&--I!=0);return V<=v.lookahead?V:v.lookahead}function ve(v){var U,H,$,I,C,V,q,K,ee,le,oe=v.w_size;do{if(I=v.window_size-v.lookahead-v.strstart,v.strstart>=oe+(oe-Z)){for(l.arraySet(v.window,v.window,oe,oe,0),v.match_start-=oe,v.strstart-=oe,v.block_start-=oe,U=H=v.hash_size;$=v.head[--U],v.head[U]=oe<=$?$-oe:0,--H;);for(U=H=oe;$=v.prev[--U],v.prev[U]=oe<=$?$-oe:0,--H;);I+=oe}if(v.strm.avail_in===0)break;if(V=v.strm,q=v.window,K=v.strstart+v.lookahead,ee=I,le=void 0,le=V.avail_in,ee<le&&(le=ee),H=le===0?0:(V.avail_in-=le,l.arraySet(q,V.input,V.next_in,le,K),V.state.wrap===1?V.adler=a(V.adler,q,le,K):V.state.wrap===2&&(V.adler=c(V.adler,q,le,K)),V.next_in+=le,V.total_in+=le,le),v.lookahead+=H,v.lookahead+v.insert>=O)for(C=v.strstart-v.insert,v.ins_h=v.window[C],v.ins_h=(v.ins_h<<v.hash_shift^v.window[C+1])&v.hash_mask;v.insert&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[C+O-1])&v.hash_mask,v.prev[C&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=C,C++,v.insert--,!(v.lookahead+v.insert<O)););}while(v.lookahead<Z&&v.strm.avail_in!==0)}function Te(v,U){for(var H,$;;){if(v.lookahead<Z){if(ve(v),v.lookahead<Z&&U===p)return k;if(v.lookahead===0)break}if(H=0,v.lookahead>=O&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+O-1])&v.hash_mask,H=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),H!==0&&v.strstart-H<=v.w_size-Z&&(v.match_length=ce(v,H)),v.match_length>=O)if($=r._tr_tally(v,v.strstart-v.match_start,v.match_length-O),v.lookahead-=v.match_length,v.match_length<=v.max_lazy_match&&v.lookahead>=O){for(v.match_length--;v.strstart++,v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+O-1])&v.hash_mask,H=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart,--v.match_length!=0;);v.strstart++}else v.strstart+=v.match_length,v.match_length=0,v.ins_h=v.window[v.strstart],v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+1])&v.hash_mask;else $=r._tr_tally(v,0,v.window[v.strstart]),v.lookahead--,v.strstart++;if($&&(W(v,!1),v.strm.avail_out===0))return k}return v.insert=v.strstart<O-1?v.strstart:O-1,U===g?(W(v,!0),v.strm.avail_out===0?F:E):v.last_lit&&(W(v,!1),v.strm.avail_out===0)?k:A}function xe(v,U){for(var H,$,I;;){if(v.lookahead<Z){if(ve(v),v.lookahead<Z&&U===p)return k;if(v.lookahead===0)break}if(H=0,v.lookahead>=O&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+O-1])&v.hash_mask,H=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),v.prev_length=v.match_length,v.prev_match=v.match_start,v.match_length=O-1,H!==0&&v.prev_length<v.max_lazy_match&&v.strstart-H<=v.w_size-Z&&(v.match_length=ce(v,H),v.match_length<=5&&(v.strategy===1||v.match_length===O&&4096<v.strstart-v.match_start)&&(v.match_length=O-1)),v.prev_length>=O&&v.match_length<=v.prev_length){for(I=v.strstart+v.lookahead-O,$=r._tr_tally(v,v.strstart-1-v.prev_match,v.prev_length-O),v.lookahead-=v.prev_length-1,v.prev_length-=2;++v.strstart<=I&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+O-1])&v.hash_mask,H=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),--v.prev_length!=0;);if(v.match_available=0,v.match_length=O-1,v.strstart++,$&&(W(v,!1),v.strm.avail_out===0))return k}else if(v.match_available){if(($=r._tr_tally(v,0,v.window[v.strstart-1]))&&W(v,!1),v.strstart++,v.lookahead--,v.strm.avail_out===0)return k}else v.match_available=1,v.strstart++,v.lookahead--}return v.match_available&&($=r._tr_tally(v,0,v.window[v.strstart-1]),v.match_available=0),v.insert=v.strstart<O-1?v.strstart:O-1,U===g?(W(v,!0),v.strm.avail_out===0?F:E):v.last_lit&&(W(v,!1),v.strm.avail_out===0)?k:A}function ue(v,U,H,$,I){this.good_length=v,this.max_lazy=U,this.nice_length=H,this.max_chain=$,this.func=I}function Y(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=x,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*w),this.dyn_dtree=new l.Buf16(2*(2*M+1)),this.bl_tree=new l.Buf16(2*(2*T+1)),X(this.dyn_ltree),X(this.dyn_dtree),X(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(R+1),this.heap=new l.Buf16(2*B+1),X(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*B+1),X(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function fe(v){var U;return v&&v.state?(v.total_in=v.total_out=0,v.data_type=y,(U=v.state).pending=0,U.pending_out=0,U.wrap<0&&(U.wrap=-U.wrap),U.status=U.wrap?S:z,v.adler=U.wrap===2?0:1,U.last_flush=p,r._tr_init(U),u):D(v,m)}function L(v){var U=fe(v);return U===u&&(function(H){H.window_size=2*H.w_size,X(H.head),H.max_lazy_match=o[H.level].max_lazy,H.good_match=o[H.level].good_length,H.nice_match=o[H.level].nice_length,H.max_chain_length=o[H.level].max_chain,H.strstart=0,H.block_start=0,H.lookahead=0,H.insert=0,H.match_length=H.prev_length=O-1,H.match_available=0,H.ins_h=0})(v.state),U}function j(v,U,H,$,I,C){if(!v)return m;var V=1;if(U===h&&(U=6),$<0?(V=0,$=-$):15<$&&(V=2,$-=16),I<1||_<I||H!==x||$<8||15<$||U<0||9<U||C<0||b<C)return D(v,m);$===8&&($=9);var q=new Y;return(v.state=q).strm=v,q.wrap=V,q.gzhead=null,q.w_bits=$,q.w_size=1<<q.w_bits,q.w_mask=q.w_size-1,q.hash_bits=I+7,q.hash_size=1<<q.hash_bits,q.hash_mask=q.hash_size-1,q.hash_shift=~~((q.hash_bits+O-1)/O),q.window=new l.Buf8(2*q.w_size),q.head=new l.Buf16(q.hash_size),q.prev=new l.Buf16(q.w_size),q.lit_bufsize=1<<I+6,q.pending_buf_size=4*q.lit_bufsize,q.pending_buf=new l.Buf8(q.pending_buf_size),q.d_buf=1*q.lit_bufsize,q.l_buf=3*q.lit_bufsize,q.level=U,q.strategy=C,q.method=H,L(v)}o=[new ue(0,0,0,0,function(v,U){var H=65535;for(H>v.pending_buf_size-5&&(H=v.pending_buf_size-5);;){if(v.lookahead<=1){if(ve(v),v.lookahead===0&&U===p)return k;if(v.lookahead===0)break}v.strstart+=v.lookahead,v.lookahead=0;var $=v.block_start+H;if((v.strstart===0||v.strstart>=$)&&(v.lookahead=v.strstart-$,v.strstart=$,W(v,!1),v.strm.avail_out===0)||v.strstart-v.block_start>=v.w_size-Z&&(W(v,!1),v.strm.avail_out===0))return k}return v.insert=0,U===g?(W(v,!0),v.strm.avail_out===0?F:E):(v.strstart>v.block_start&&(W(v,!1),v.strm.avail_out),k)}),new ue(4,4,8,4,Te),new ue(4,5,16,8,Te),new ue(4,6,32,32,Te),new ue(4,4,16,16,xe),new ue(8,16,32,32,xe),new ue(8,16,128,128,xe),new ue(8,32,128,256,xe),new ue(32,128,258,1024,xe),new ue(32,258,258,4096,xe)],s.deflateInit=function(v,U){return j(v,U,x,15,8,0)},s.deflateInit2=j,s.deflateReset=L,s.deflateResetKeep=fe,s.deflateSetHeader=function(v,U){return v&&v.state?v.state.wrap!==2?m:(v.state.gzhead=U,u):m},s.deflate=function(v,U){var H,$,I,C;if(!v||!v.state||5<U||U<0)return v?D(v,m):m;if($=v.state,!v.output||!v.input&&v.avail_in!==0||$.status===666&&U!==g)return D(v,v.avail_out===0?-5:m);if($.strm=v,H=$.last_flush,$.last_flush=U,$.status===S)if($.wrap===2)v.adler=0,se($,31),se($,139),se($,8),$.gzhead?(se($,($.gzhead.text?1:0)+($.gzhead.hcrc?2:0)+($.gzhead.extra?4:0)+($.gzhead.name?8:0)+($.gzhead.comment?16:0)),se($,255&$.gzhead.time),se($,$.gzhead.time>>8&255),se($,$.gzhead.time>>16&255),se($,$.gzhead.time>>24&255),se($,$.level===9?2:2<=$.strategy||$.level<2?4:0),se($,255&$.gzhead.os),$.gzhead.extra&&$.gzhead.extra.length&&(se($,255&$.gzhead.extra.length),se($,$.gzhead.extra.length>>8&255)),$.gzhead.hcrc&&(v.adler=c(v.adler,$.pending_buf,$.pending,0)),$.gzindex=0,$.status=69):(se($,0),se($,0),se($,0),se($,0),se($,0),se($,$.level===9?2:2<=$.strategy||$.level<2?4:0),se($,3),$.status=z);else{var V=x+($.w_bits-8<<4)<<8;V|=(2<=$.strategy||$.level<2?0:$.level<6?1:$.level===6?2:3)<<6,$.strstart!==0&&(V|=32),V+=31-V%31,$.status=z,ae($,V),$.strstart!==0&&(ae($,v.adler>>>16),ae($,65535&v.adler)),v.adler=1}if($.status===69)if($.gzhead.extra){for(I=$.pending;$.gzindex<(65535&$.gzhead.extra.length)&&($.pending!==$.pending_buf_size||($.gzhead.hcrc&&$.pending>I&&(v.adler=c(v.adler,$.pending_buf,$.pending-I,I)),G(v),I=$.pending,$.pending!==$.pending_buf_size));)se($,255&$.gzhead.extra[$.gzindex]),$.gzindex++;$.gzhead.hcrc&&$.pending>I&&(v.adler=c(v.adler,$.pending_buf,$.pending-I,I)),$.gzindex===$.gzhead.extra.length&&($.gzindex=0,$.status=73)}else $.status=73;if($.status===73)if($.gzhead.name){I=$.pending;do{if($.pending===$.pending_buf_size&&($.gzhead.hcrc&&$.pending>I&&(v.adler=c(v.adler,$.pending_buf,$.pending-I,I)),G(v),I=$.pending,$.pending===$.pending_buf_size)){C=1;break}C=$.gzindex<$.gzhead.name.length?255&$.gzhead.name.charCodeAt($.gzindex++):0,se($,C)}while(C!==0);$.gzhead.hcrc&&$.pending>I&&(v.adler=c(v.adler,$.pending_buf,$.pending-I,I)),C===0&&($.gzindex=0,$.status=91)}else $.status=91;if($.status===91)if($.gzhead.comment){I=$.pending;do{if($.pending===$.pending_buf_size&&($.gzhead.hcrc&&$.pending>I&&(v.adler=c(v.adler,$.pending_buf,$.pending-I,I)),G(v),I=$.pending,$.pending===$.pending_buf_size)){C=1;break}C=$.gzindex<$.gzhead.comment.length?255&$.gzhead.comment.charCodeAt($.gzindex++):0,se($,C)}while(C!==0);$.gzhead.hcrc&&$.pending>I&&(v.adler=c(v.adler,$.pending_buf,$.pending-I,I)),C===0&&($.status=103)}else $.status=103;if($.status===103&&($.gzhead.hcrc?($.pending+2>$.pending_buf_size&&G(v),$.pending+2<=$.pending_buf_size&&(se($,255&v.adler),se($,v.adler>>8&255),v.adler=0,$.status=z)):$.status=z),$.pending!==0){if(G(v),v.avail_out===0)return $.last_flush=-1,u}else if(v.avail_in===0&&P(U)<=P(H)&&U!==g)return D(v,-5);if($.status===666&&v.avail_in!==0)return D(v,-5);if(v.avail_in!==0||$.lookahead!==0||U!==p&&$.status!==666){var q=$.strategy===2?(function(K,ee){for(var le;;){if(K.lookahead===0&&(ve(K),K.lookahead===0)){if(ee===p)return k;break}if(K.match_length=0,le=r._tr_tally(K,0,K.window[K.strstart]),K.lookahead--,K.strstart++,le&&(W(K,!1),K.strm.avail_out===0))return k}return K.insert=0,ee===g?(W(K,!0),K.strm.avail_out===0?F:E):K.last_lit&&(W(K,!1),K.strm.avail_out===0)?k:A})($,U):$.strategy===3?(function(K,ee){for(var le,oe,he,ie,ne=K.window;;){if(K.lookahead<=N){if(ve(K),K.lookahead<=N&&ee===p)return k;if(K.lookahead===0)break}if(K.match_length=0,K.lookahead>=O&&0<K.strstart&&(oe=ne[he=K.strstart-1])===ne[++he]&&oe===ne[++he]&&oe===ne[++he]){ie=K.strstart+N;do;while(oe===ne[++he]&&oe===ne[++he]&&oe===ne[++he]&&oe===ne[++he]&&oe===ne[++he]&&oe===ne[++he]&&oe===ne[++he]&&oe===ne[++he]&&he<ie);K.match_length=N-(ie-he),K.match_length>K.lookahead&&(K.match_length=K.lookahead)}if(K.match_length>=O?(le=r._tr_tally(K,1,K.match_length-O),K.lookahead-=K.match_length,K.strstart+=K.match_length,K.match_length=0):(le=r._tr_tally(K,0,K.window[K.strstart]),K.lookahead--,K.strstart++),le&&(W(K,!1),K.strm.avail_out===0))return k}return K.insert=0,ee===g?(W(K,!0),K.strm.avail_out===0?F:E):K.last_lit&&(W(K,!1),K.strm.avail_out===0)?k:A})($,U):o[$.level].func($,U);if(q!==F&&q!==E||($.status=666),q===k||q===F)return v.avail_out===0&&($.last_flush=-1),u;if(q===A&&(U===1?r._tr_align($):U!==5&&(r._tr_stored_block($,0,0,!1),U===3&&(X($.head),$.lookahead===0&&($.strstart=0,$.block_start=0,$.insert=0))),G(v),v.avail_out===0))return $.last_flush=-1,u}return U!==g?u:$.wrap<=0?1:($.wrap===2?(se($,255&v.adler),se($,v.adler>>8&255),se($,v.adler>>16&255),se($,v.adler>>24&255),se($,255&v.total_in),se($,v.total_in>>8&255),se($,v.total_in>>16&255),se($,v.total_in>>24&255)):(ae($,v.adler>>>16),ae($,65535&v.adler)),G(v),0<$.wrap&&($.wrap=-$.wrap),$.pending!==0?u:1)},s.deflateEnd=function(v){var U;return v&&v.state?(U=v.state.status)!==S&&U!==69&&U!==73&&U!==91&&U!==103&&U!==z&&U!==666?D(v,m):(v.state=null,U===z?D(v,-3):u):m},s.deflateSetDictionary=function(v,U){var H,$,I,C,V,q,K,ee,le=U.length;if(!v||!v.state||(C=(H=v.state).wrap)===2||C===1&&H.status!==S||H.lookahead)return m;for(C===1&&(v.adler=a(v.adler,U,le,0)),H.wrap=0,le>=H.w_size&&(C===0&&(X(H.head),H.strstart=0,H.block_start=0,H.insert=0),ee=new l.Buf8(H.w_size),l.arraySet(ee,U,le-H.w_size,H.w_size,0),U=ee,le=H.w_size),V=v.avail_in,q=v.next_in,K=v.input,v.avail_in=le,v.next_in=0,v.input=U,ve(H);H.lookahead>=O;){for($=H.strstart,I=H.lookahead-(O-1);H.ins_h=(H.ins_h<<H.hash_shift^H.window[$+O-1])&H.hash_mask,H.prev[$&H.w_mask]=H.head[H.ins_h],H.head[H.ins_h]=$,$++,--I;);H.strstart=$,H.lookahead=O-1,ve(H)}return H.strstart+=H.lookahead,H.block_start=H.strstart,H.insert=H.lookahead,H.lookahead=0,H.match_length=H.prev_length=O-1,H.match_available=0,v.next_in=q,v.input=K,v.avail_in=V,H.wrap=C,u},s.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,n,s){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,n,s){n.exports=function(o,l){var r,a,c,d,p,g,u,m,h,b,y,x,_,B,M,T,w,R,O,N,Z,S,z,k,A;r=o.state,a=o.next_in,k=o.input,c=a+(o.avail_in-5),d=o.next_out,A=o.output,p=d-(l-o.avail_out),g=d+(o.avail_out-257),u=r.dmax,m=r.wsize,h=r.whave,b=r.wnext,y=r.window,x=r.hold,_=r.bits,B=r.lencode,M=r.distcode,T=(1<<r.lenbits)-1,w=(1<<r.distbits)-1;e:do{_<15&&(x+=k[a++]<<_,_+=8,x+=k[a++]<<_,_+=8),R=B[x&T];t:for(;;){if(x>>>=O=R>>>24,_-=O,(O=R>>>16&255)===0)A[d++]=65535&R;else{if(!(16&O)){if((64&O)==0){R=B[(65535&R)+(x&(1<<O)-1)];continue t}if(32&O){r.mode=12;break e}o.msg="invalid literal/length code",r.mode=30;break e}N=65535&R,(O&=15)&&(_<O&&(x+=k[a++]<<_,_+=8),N+=x&(1<<O)-1,x>>>=O,_-=O),_<15&&(x+=k[a++]<<_,_+=8,x+=k[a++]<<_,_+=8),R=M[x&w];i:for(;;){if(x>>>=O=R>>>24,_-=O,!(16&(O=R>>>16&255))){if((64&O)==0){R=M[(65535&R)+(x&(1<<O)-1)];continue i}o.msg="invalid distance code",r.mode=30;break e}if(Z=65535&R,_<(O&=15)&&(x+=k[a++]<<_,(_+=8)<O&&(x+=k[a++]<<_,_+=8)),u<(Z+=x&(1<<O)-1)){o.msg="invalid distance too far back",r.mode=30;break e}if(x>>>=O,_-=O,(O=d-p)<Z){if(h<(O=Z-O)&&r.sane){o.msg="invalid distance too far back",r.mode=30;break e}if(z=y,(S=0)===b){if(S+=m-O,O<N){for(N-=O;A[d++]=y[S++],--O;);S=d-Z,z=A}}else if(b<O){if(S+=m+b-O,(O-=b)<N){for(N-=O;A[d++]=y[S++],--O;);if(S=0,b<N){for(N-=O=b;A[d++]=y[S++],--O;);S=d-Z,z=A}}}else if(S+=b-O,O<N){for(N-=O;A[d++]=y[S++],--O;);S=d-Z,z=A}for(;2<N;)A[d++]=z[S++],A[d++]=z[S++],A[d++]=z[S++],N-=3;N&&(A[d++]=z[S++],1<N&&(A[d++]=z[S++]))}else{for(S=d-Z;A[d++]=A[S++],A[d++]=A[S++],A[d++]=A[S++],2<(N-=3););N&&(A[d++]=A[S++],1<N&&(A[d++]=A[S++]))}break}}break}}while(a<c&&d<g);a-=N=_>>3,x&=(1<<(_-=N<<3))-1,o.next_in=a,o.next_out=d,o.avail_in=a<c?c-a+5:5-(a-c),o.avail_out=d<g?g-d+257:257-(d-g),r.hold=x,r.bits=_}},{}],49:[function(i,n,s){var o=i("../utils/common"),l=i("./adler32"),r=i("./crc32"),a=i("./inffast"),c=i("./inftrees"),d=1,p=2,g=0,u=-2,m=1,h=852,b=592;function y(S){return(S>>>24&255)+(S>>>8&65280)+((65280&S)<<8)+((255&S)<<24)}function x(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new o.Buf16(320),this.work=new o.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function _(S){var z;return S&&S.state?(z=S.state,S.total_in=S.total_out=z.total=0,S.msg="",z.wrap&&(S.adler=1&z.wrap),z.mode=m,z.last=0,z.havedict=0,z.dmax=32768,z.head=null,z.hold=0,z.bits=0,z.lencode=z.lendyn=new o.Buf32(h),z.distcode=z.distdyn=new o.Buf32(b),z.sane=1,z.back=-1,g):u}function B(S){var z;return S&&S.state?((z=S.state).wsize=0,z.whave=0,z.wnext=0,_(S)):u}function M(S,z){var k,A;return S&&S.state?(A=S.state,z<0?(k=0,z=-z):(k=1+(z>>4),z<48&&(z&=15)),z&&(z<8||15<z)?u:(A.window!==null&&A.wbits!==z&&(A.window=null),A.wrap=k,A.wbits=z,B(S))):u}function T(S,z){var k,A;return S?(A=new x,(S.state=A).window=null,(k=M(S,z))!==g&&(S.state=null),k):u}var w,R,O=!0;function N(S){if(O){var z;for(w=new o.Buf32(512),R=new o.Buf32(32),z=0;z<144;)S.lens[z++]=8;for(;z<256;)S.lens[z++]=9;for(;z<280;)S.lens[z++]=7;for(;z<288;)S.lens[z++]=8;for(c(d,S.lens,0,288,w,0,S.work,{bits:9}),z=0;z<32;)S.lens[z++]=5;c(p,S.lens,0,32,R,0,S.work,{bits:5}),O=!1}S.lencode=w,S.lenbits=9,S.distcode=R,S.distbits=5}function Z(S,z,k,A){var F,E=S.state;return E.window===null&&(E.wsize=1<<E.wbits,E.wnext=0,E.whave=0,E.window=new o.Buf8(E.wsize)),A>=E.wsize?(o.arraySet(E.window,z,k-E.wsize,E.wsize,0),E.wnext=0,E.whave=E.wsize):(A<(F=E.wsize-E.wnext)&&(F=A),o.arraySet(E.window,z,k-A,F,E.wnext),(A-=F)?(o.arraySet(E.window,z,k-A,A,0),E.wnext=A,E.whave=E.wsize):(E.wnext+=F,E.wnext===E.wsize&&(E.wnext=0),E.whave<E.wsize&&(E.whave+=F))),0}s.inflateReset=B,s.inflateReset2=M,s.inflateResetKeep=_,s.inflateInit=function(S){return T(S,15)},s.inflateInit2=T,s.inflate=function(S,z){var k,A,F,E,D,P,X,G,W,se,ae,ce,ve,Te,xe,ue,Y,fe,L,j,v,U,H,$,I=0,C=new o.Buf8(4),V=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!S||!S.state||!S.output||!S.input&&S.avail_in!==0)return u;(k=S.state).mode===12&&(k.mode=13),D=S.next_out,F=S.output,X=S.avail_out,E=S.next_in,A=S.input,P=S.avail_in,G=k.hold,W=k.bits,se=P,ae=X,U=g;e:for(;;)switch(k.mode){case m:if(k.wrap===0){k.mode=13;break}for(;W<16;){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}if(2&k.wrap&&G===35615){C[k.check=0]=255&G,C[1]=G>>>8&255,k.check=r(k.check,C,2,0),W=G=0,k.mode=2;break}if(k.flags=0,k.head&&(k.head.done=!1),!(1&k.wrap)||(((255&G)<<8)+(G>>8))%31){S.msg="incorrect header check",k.mode=30;break}if((15&G)!=8){S.msg="unknown compression method",k.mode=30;break}if(W-=4,v=8+(15&(G>>>=4)),k.wbits===0)k.wbits=v;else if(v>k.wbits){S.msg="invalid window size",k.mode=30;break}k.dmax=1<<v,S.adler=k.check=1,k.mode=512&G?10:12,W=G=0;break;case 2:for(;W<16;){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}if(k.flags=G,(255&k.flags)!=8){S.msg="unknown compression method",k.mode=30;break}if(57344&k.flags){S.msg="unknown header flags set",k.mode=30;break}k.head&&(k.head.text=G>>8&1),512&k.flags&&(C[0]=255&G,C[1]=G>>>8&255,k.check=r(k.check,C,2,0)),W=G=0,k.mode=3;case 3:for(;W<32;){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}k.head&&(k.head.time=G),512&k.flags&&(C[0]=255&G,C[1]=G>>>8&255,C[2]=G>>>16&255,C[3]=G>>>24&255,k.check=r(k.check,C,4,0)),W=G=0,k.mode=4;case 4:for(;W<16;){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}k.head&&(k.head.xflags=255&G,k.head.os=G>>8),512&k.flags&&(C[0]=255&G,C[1]=G>>>8&255,k.check=r(k.check,C,2,0)),W=G=0,k.mode=5;case 5:if(1024&k.flags){for(;W<16;){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}k.length=G,k.head&&(k.head.extra_len=G),512&k.flags&&(C[0]=255&G,C[1]=G>>>8&255,k.check=r(k.check,C,2,0)),W=G=0}else k.head&&(k.head.extra=null);k.mode=6;case 6:if(1024&k.flags&&(P<(ce=k.length)&&(ce=P),ce&&(k.head&&(v=k.head.extra_len-k.length,k.head.extra||(k.head.extra=new Array(k.head.extra_len)),o.arraySet(k.head.extra,A,E,ce,v)),512&k.flags&&(k.check=r(k.check,A,ce,E)),P-=ce,E+=ce,k.length-=ce),k.length))break e;k.length=0,k.mode=7;case 7:if(2048&k.flags){if(P===0)break e;for(ce=0;v=A[E+ce++],k.head&&v&&k.length<65536&&(k.head.name+=String.fromCharCode(v)),v&&ce<P;);if(512&k.flags&&(k.check=r(k.check,A,ce,E)),P-=ce,E+=ce,v)break e}else k.head&&(k.head.name=null);k.length=0,k.mode=8;case 8:if(4096&k.flags){if(P===0)break e;for(ce=0;v=A[E+ce++],k.head&&v&&k.length<65536&&(k.head.comment+=String.fromCharCode(v)),v&&ce<P;);if(512&k.flags&&(k.check=r(k.check,A,ce,E)),P-=ce,E+=ce,v)break e}else k.head&&(k.head.comment=null);k.mode=9;case 9:if(512&k.flags){for(;W<16;){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}if(G!==(65535&k.check)){S.msg="header crc mismatch",k.mode=30;break}W=G=0}k.head&&(k.head.hcrc=k.flags>>9&1,k.head.done=!0),S.adler=k.check=0,k.mode=12;break;case 10:for(;W<32;){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}S.adler=k.check=y(G),W=G=0,k.mode=11;case 11:if(k.havedict===0)return S.next_out=D,S.avail_out=X,S.next_in=E,S.avail_in=P,k.hold=G,k.bits=W,2;S.adler=k.check=1,k.mode=12;case 12:if(z===5||z===6)break e;case 13:if(k.last){G>>>=7&W,W-=7&W,k.mode=27;break}for(;W<3;){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}switch(k.last=1&G,W-=1,3&(G>>>=1)){case 0:k.mode=14;break;case 1:if(N(k),k.mode=20,z!==6)break;G>>>=2,W-=2;break e;case 2:k.mode=17;break;case 3:S.msg="invalid block type",k.mode=30}G>>>=2,W-=2;break;case 14:for(G>>>=7&W,W-=7&W;W<32;){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}if((65535&G)!=(G>>>16^65535)){S.msg="invalid stored block lengths",k.mode=30;break}if(k.length=65535&G,W=G=0,k.mode=15,z===6)break e;case 15:k.mode=16;case 16:if(ce=k.length){if(P<ce&&(ce=P),X<ce&&(ce=X),ce===0)break e;o.arraySet(F,A,E,ce,D),P-=ce,E+=ce,X-=ce,D+=ce,k.length-=ce;break}k.mode=12;break;case 17:for(;W<14;){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}if(k.nlen=257+(31&G),G>>>=5,W-=5,k.ndist=1+(31&G),G>>>=5,W-=5,k.ncode=4+(15&G),G>>>=4,W-=4,286<k.nlen||30<k.ndist){S.msg="too many length or distance symbols",k.mode=30;break}k.have=0,k.mode=18;case 18:for(;k.have<k.ncode;){for(;W<3;){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}k.lens[V[k.have++]]=7&G,G>>>=3,W-=3}for(;k.have<19;)k.lens[V[k.have++]]=0;if(k.lencode=k.lendyn,k.lenbits=7,H={bits:k.lenbits},U=c(0,k.lens,0,19,k.lencode,0,k.work,H),k.lenbits=H.bits,U){S.msg="invalid code lengths set",k.mode=30;break}k.have=0,k.mode=19;case 19:for(;k.have<k.nlen+k.ndist;){for(;ue=(I=k.lencode[G&(1<<k.lenbits)-1])>>>16&255,Y=65535&I,!((xe=I>>>24)<=W);){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}if(Y<16)G>>>=xe,W-=xe,k.lens[k.have++]=Y;else{if(Y===16){for($=xe+2;W<$;){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}if(G>>>=xe,W-=xe,k.have===0){S.msg="invalid bit length repeat",k.mode=30;break}v=k.lens[k.have-1],ce=3+(3&G),G>>>=2,W-=2}else if(Y===17){for($=xe+3;W<$;){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}W-=xe,v=0,ce=3+(7&(G>>>=xe)),G>>>=3,W-=3}else{for($=xe+7;W<$;){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}W-=xe,v=0,ce=11+(127&(G>>>=xe)),G>>>=7,W-=7}if(k.have+ce>k.nlen+k.ndist){S.msg="invalid bit length repeat",k.mode=30;break}for(;ce--;)k.lens[k.have++]=v}}if(k.mode===30)break;if(k.lens[256]===0){S.msg="invalid code -- missing end-of-block",k.mode=30;break}if(k.lenbits=9,H={bits:k.lenbits},U=c(d,k.lens,0,k.nlen,k.lencode,0,k.work,H),k.lenbits=H.bits,U){S.msg="invalid literal/lengths set",k.mode=30;break}if(k.distbits=6,k.distcode=k.distdyn,H={bits:k.distbits},U=c(p,k.lens,k.nlen,k.ndist,k.distcode,0,k.work,H),k.distbits=H.bits,U){S.msg="invalid distances set",k.mode=30;break}if(k.mode=20,z===6)break e;case 20:k.mode=21;case 21:if(6<=P&&258<=X){S.next_out=D,S.avail_out=X,S.next_in=E,S.avail_in=P,k.hold=G,k.bits=W,a(S,ae),D=S.next_out,F=S.output,X=S.avail_out,E=S.next_in,A=S.input,P=S.avail_in,G=k.hold,W=k.bits,k.mode===12&&(k.back=-1);break}for(k.back=0;ue=(I=k.lencode[G&(1<<k.lenbits)-1])>>>16&255,Y=65535&I,!((xe=I>>>24)<=W);){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}if(ue&&(240&ue)==0){for(fe=xe,L=ue,j=Y;ue=(I=k.lencode[j+((G&(1<<fe+L)-1)>>fe)])>>>16&255,Y=65535&I,!(fe+(xe=I>>>24)<=W);){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}G>>>=fe,W-=fe,k.back+=fe}if(G>>>=xe,W-=xe,k.back+=xe,k.length=Y,ue===0){k.mode=26;break}if(32&ue){k.back=-1,k.mode=12;break}if(64&ue){S.msg="invalid literal/length code",k.mode=30;break}k.extra=15&ue,k.mode=22;case 22:if(k.extra){for($=k.extra;W<$;){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}k.length+=G&(1<<k.extra)-1,G>>>=k.extra,W-=k.extra,k.back+=k.extra}k.was=k.length,k.mode=23;case 23:for(;ue=(I=k.distcode[G&(1<<k.distbits)-1])>>>16&255,Y=65535&I,!((xe=I>>>24)<=W);){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}if((240&ue)==0){for(fe=xe,L=ue,j=Y;ue=(I=k.distcode[j+((G&(1<<fe+L)-1)>>fe)])>>>16&255,Y=65535&I,!(fe+(xe=I>>>24)<=W);){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}G>>>=fe,W-=fe,k.back+=fe}if(G>>>=xe,W-=xe,k.back+=xe,64&ue){S.msg="invalid distance code",k.mode=30;break}k.offset=Y,k.extra=15&ue,k.mode=24;case 24:if(k.extra){for($=k.extra;W<$;){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}k.offset+=G&(1<<k.extra)-1,G>>>=k.extra,W-=k.extra,k.back+=k.extra}if(k.offset>k.dmax){S.msg="invalid distance too far back",k.mode=30;break}k.mode=25;case 25:if(X===0)break e;if(ce=ae-X,k.offset>ce){if((ce=k.offset-ce)>k.whave&&k.sane){S.msg="invalid distance too far back",k.mode=30;break}ve=ce>k.wnext?(ce-=k.wnext,k.wsize-ce):k.wnext-ce,ce>k.length&&(ce=k.length),Te=k.window}else Te=F,ve=D-k.offset,ce=k.length;for(X<ce&&(ce=X),X-=ce,k.length-=ce;F[D++]=Te[ve++],--ce;);k.length===0&&(k.mode=21);break;case 26:if(X===0)break e;F[D++]=k.length,X--,k.mode=21;break;case 27:if(k.wrap){for(;W<32;){if(P===0)break e;P--,G|=A[E++]<<W,W+=8}if(ae-=X,S.total_out+=ae,k.total+=ae,ae&&(S.adler=k.check=k.flags?r(k.check,F,ae,D-ae):l(k.check,F,ae,D-ae)),ae=X,(k.flags?G:y(G))!==k.check){S.msg="incorrect data check",k.mode=30;break}W=G=0}k.mode=28;case 28:if(k.wrap&&k.flags){for(;W<32;){if(P===0)break e;P--,G+=A[E++]<<W,W+=8}if(G!==(4294967295&k.total)){S.msg="incorrect length check",k.mode=30;break}W=G=0}k.mode=29;case 29:U=1;break e;case 30:U=-3;break e;case 31:return-4;case 32:default:return u}return S.next_out=D,S.avail_out=X,S.next_in=E,S.avail_in=P,k.hold=G,k.bits=W,(k.wsize||ae!==S.avail_out&&k.mode<30&&(k.mode<27||z!==4))&&Z(S,S.output,S.next_out,ae-S.avail_out)?(k.mode=31,-4):(se-=S.avail_in,ae-=S.avail_out,S.total_in+=se,S.total_out+=ae,k.total+=ae,k.wrap&&ae&&(S.adler=k.check=k.flags?r(k.check,F,ae,S.next_out-ae):l(k.check,F,ae,S.next_out-ae)),S.data_type=k.bits+(k.last?64:0)+(k.mode===12?128:0)+(k.mode===20||k.mode===15?256:0),(se==0&&ae===0||z===4)&&U===g&&(U=-5),U)},s.inflateEnd=function(S){if(!S||!S.state)return u;var z=S.state;return z.window&&(z.window=null),S.state=null,g},s.inflateGetHeader=function(S,z){var k;return S&&S.state?(2&(k=S.state).wrap)==0?u:((k.head=z).done=!1,g):u},s.inflateSetDictionary=function(S,z){var k,A=z.length;return S&&S.state?(k=S.state).wrap!==0&&k.mode!==11?u:k.mode===11&&l(1,z,A,0)!==k.check?-3:Z(S,z,A,A)?(k.mode=31,-4):(k.havedict=1,g):u},s.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,n,s){var o=i("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(d,p,g,u,m,h,b,y){var x,_,B,M,T,w,R,O,N,Z=y.bits,S=0,z=0,k=0,A=0,F=0,E=0,D=0,P=0,X=0,G=0,W=null,se=0,ae=new o.Buf16(16),ce=new o.Buf16(16),ve=null,Te=0;for(S=0;S<=15;S++)ae[S]=0;for(z=0;z<u;z++)ae[p[g+z]]++;for(F=Z,A=15;1<=A&&ae[A]===0;A--);if(A<F&&(F=A),A===0)return m[h++]=20971520,m[h++]=20971520,y.bits=1,0;for(k=1;k<A&&ae[k]===0;k++);for(F<k&&(F=k),S=P=1;S<=15;S++)if(P<<=1,(P-=ae[S])<0)return-1;if(0<P&&(d===0||A!==1))return-1;for(ce[1]=0,S=1;S<15;S++)ce[S+1]=ce[S]+ae[S];for(z=0;z<u;z++)p[g+z]!==0&&(b[ce[p[g+z]]++]=z);if(w=d===0?(W=ve=b,19):d===1?(W=l,se-=257,ve=r,Te-=257,256):(W=a,ve=c,-1),S=k,T=h,D=z=G=0,B=-1,M=(X=1<<(E=F))-1,d===1&&852<X||d===2&&592<X)return 1;for(;;){for(R=S-D,N=b[z]<w?(O=0,b[z]):b[z]>w?(O=ve[Te+b[z]],W[se+b[z]]):(O=96,0),x=1<<S-D,k=_=1<<E;m[T+(G>>D)+(_-=x)]=R<<24|O<<16|N|0,_!==0;);for(x=1<<S-1;G&x;)x>>=1;if(x!==0?(G&=x-1,G+=x):G=0,z++,--ae[S]==0){if(S===A)break;S=p[g+b[z]]}if(F<S&&(G&M)!==B){for(D===0&&(D=F),T+=k,P=1<<(E=S-D);E+D<A&&!((P-=ae[E+D])<=0);)E++,P<<=1;if(X+=1<<E,d===1&&852<X||d===2&&592<X)return 1;m[B=G&M]=F<<24|E<<16|T-h|0}}return G!==0&&(m[T+G]=S-D<<24|64<<16|0),y.bits=F,0}},{"../utils/common":41}],51:[function(i,n,s){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,n,s){var o=i("../utils/common"),l=0,r=1;function a(I){for(var C=I.length;0<=--C;)I[C]=0}var c=0,d=29,p=256,g=p+1+d,u=30,m=19,h=2*g+1,b=15,y=16,x=7,_=256,B=16,M=17,T=18,w=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],R=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],O=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],N=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],Z=new Array(2*(g+2));a(Z);var S=new Array(2*u);a(S);var z=new Array(512);a(z);var k=new Array(256);a(k);var A=new Array(d);a(A);var F,E,D,P=new Array(u);function X(I,C,V,q,K){this.static_tree=I,this.extra_bits=C,this.extra_base=V,this.elems=q,this.max_length=K,this.has_stree=I&&I.length}function G(I,C){this.dyn_tree=I,this.max_code=0,this.stat_desc=C}function W(I){return I<256?z[I]:z[256+(I>>>7)]}function se(I,C){I.pending_buf[I.pending++]=255&C,I.pending_buf[I.pending++]=C>>>8&255}function ae(I,C,V){I.bi_valid>y-V?(I.bi_buf|=C<<I.bi_valid&65535,se(I,I.bi_buf),I.bi_buf=C>>y-I.bi_valid,I.bi_valid+=V-y):(I.bi_buf|=C<<I.bi_valid&65535,I.bi_valid+=V)}function ce(I,C,V){ae(I,V[2*C],V[2*C+1])}function ve(I,C){for(var V=0;V|=1&I,I>>>=1,V<<=1,0<--C;);return V>>>1}function Te(I,C,V){var q,K,ee=new Array(b+1),le=0;for(q=1;q<=b;q++)ee[q]=le=le+V[q-1]<<1;for(K=0;K<=C;K++){var oe=I[2*K+1];oe!==0&&(I[2*K]=ve(ee[oe]++,oe))}}function xe(I){var C;for(C=0;C<g;C++)I.dyn_ltree[2*C]=0;for(C=0;C<u;C++)I.dyn_dtree[2*C]=0;for(C=0;C<m;C++)I.bl_tree[2*C]=0;I.dyn_ltree[2*_]=1,I.opt_len=I.static_len=0,I.last_lit=I.matches=0}function ue(I){8<I.bi_valid?se(I,I.bi_buf):0<I.bi_valid&&(I.pending_buf[I.pending++]=I.bi_buf),I.bi_buf=0,I.bi_valid=0}function Y(I,C,V,q){var K=2*C,ee=2*V;return I[K]<I[ee]||I[K]===I[ee]&&q[C]<=q[V]}function fe(I,C,V){for(var q=I.heap[V],K=V<<1;K<=I.heap_len&&(K<I.heap_len&&Y(C,I.heap[K+1],I.heap[K],I.depth)&&K++,!Y(C,q,I.heap[K],I.depth));)I.heap[V]=I.heap[K],V=K,K<<=1;I.heap[V]=q}function L(I,C,V){var q,K,ee,le,oe=0;if(I.last_lit!==0)for(;q=I.pending_buf[I.d_buf+2*oe]<<8|I.pending_buf[I.d_buf+2*oe+1],K=I.pending_buf[I.l_buf+oe],oe++,q===0?ce(I,K,C):(ce(I,(ee=k[K])+p+1,C),(le=w[ee])!==0&&ae(I,K-=A[ee],le),ce(I,ee=W(--q),V),(le=R[ee])!==0&&ae(I,q-=P[ee],le)),oe<I.last_lit;);ce(I,_,C)}function j(I,C){var V,q,K,ee=C.dyn_tree,le=C.stat_desc.static_tree,oe=C.stat_desc.has_stree,he=C.stat_desc.elems,ie=-1;for(I.heap_len=0,I.heap_max=h,V=0;V<he;V++)ee[2*V]!==0?(I.heap[++I.heap_len]=ie=V,I.depth[V]=0):ee[2*V+1]=0;for(;I.heap_len<2;)ee[2*(K=I.heap[++I.heap_len]=ie<2?++ie:0)]=1,I.depth[K]=0,I.opt_len--,oe&&(I.static_len-=le[2*K+1]);for(C.max_code=ie,V=I.heap_len>>1;1<=V;V--)fe(I,ee,V);for(K=he;V=I.heap[1],I.heap[1]=I.heap[I.heap_len--],fe(I,ee,1),q=I.heap[1],I.heap[--I.heap_max]=V,I.heap[--I.heap_max]=q,ee[2*K]=ee[2*V]+ee[2*q],I.depth[K]=(I.depth[V]>=I.depth[q]?I.depth[V]:I.depth[q])+1,ee[2*V+1]=ee[2*q+1]=K,I.heap[1]=K++,fe(I,ee,1),2<=I.heap_len;);I.heap[--I.heap_max]=I.heap[1],(function(ne,Ce){var Be,Ne,Re,Le,Jt,rt,Xe=Ce.dyn_tree,Ht=Ce.max_code,Fi=Ce.stat_desc.static_tree,Ws=Ce.stat_desc.has_stree,Us=Ce.stat_desc.extra_bits,Vn=Ce.stat_desc.extra_base,Si=Ce.stat_desc.max_length,Hi=0;for(Le=0;Le<=b;Le++)ne.bl_count[Le]=0;for(Xe[2*ne.heap[ne.heap_max]+1]=0,Be=ne.heap_max+1;Be<h;Be++)Si<(Le=Xe[2*Xe[2*(Ne=ne.heap[Be])+1]+1]+1)&&(Le=Si,Hi++),Xe[2*Ne+1]=Le,Ht<Ne||(ne.bl_count[Le]++,Jt=0,Vn<=Ne&&(Jt=Us[Ne-Vn]),rt=Xe[2*Ne],ne.opt_len+=rt*(Le+Jt),Ws&&(ne.static_len+=rt*(Fi[2*Ne+1]+Jt)));if(Hi!==0){do{for(Le=Si-1;ne.bl_count[Le]===0;)Le--;ne.bl_count[Le]--,ne.bl_count[Le+1]+=2,ne.bl_count[Si]--,Hi-=2}while(0<Hi);for(Le=Si;Le!==0;Le--)for(Ne=ne.bl_count[Le];Ne!==0;)Ht<(Re=ne.heap[--Be])||(Xe[2*Re+1]!==Le&&(ne.opt_len+=(Le-Xe[2*Re+1])*Xe[2*Re],Xe[2*Re+1]=Le),Ne--)}})(I,C),Te(ee,ie,I.bl_count)}function v(I,C,V){var q,K,ee=-1,le=C[1],oe=0,he=7,ie=4;for(le===0&&(he=138,ie=3),C[2*(V+1)+1]=65535,q=0;q<=V;q++)K=le,le=C[2*(q+1)+1],++oe<he&&K===le||(oe<ie?I.bl_tree[2*K]+=oe:K!==0?(K!==ee&&I.bl_tree[2*K]++,I.bl_tree[2*B]++):oe<=10?I.bl_tree[2*M]++:I.bl_tree[2*T]++,ee=K,ie=(oe=0)===le?(he=138,3):K===le?(he=6,3):(he=7,4))}function U(I,C,V){var q,K,ee=-1,le=C[1],oe=0,he=7,ie=4;for(le===0&&(he=138,ie=3),q=0;q<=V;q++)if(K=le,le=C[2*(q+1)+1],!(++oe<he&&K===le)){if(oe<ie)for(;ce(I,K,I.bl_tree),--oe!=0;);else K!==0?(K!==ee&&(ce(I,K,I.bl_tree),oe--),ce(I,B,I.bl_tree),ae(I,oe-3,2)):oe<=10?(ce(I,M,I.bl_tree),ae(I,oe-3,3)):(ce(I,T,I.bl_tree),ae(I,oe-11,7));ee=K,ie=(oe=0)===le?(he=138,3):K===le?(he=6,3):(he=7,4)}}a(P);var H=!1;function $(I,C,V,q){ae(I,(c<<1)+(q?1:0),3),(function(K,ee,le,oe){ue(K),se(K,le),se(K,~le),o.arraySet(K.pending_buf,K.window,ee,le,K.pending),K.pending+=le})(I,C,V)}s._tr_init=function(I){H||((function(){var C,V,q,K,ee,le=new Array(b+1);for(K=q=0;K<d-1;K++)for(A[K]=q,C=0;C<1<<w[K];C++)k[q++]=K;for(k[q-1]=K,K=ee=0;K<16;K++)for(P[K]=ee,C=0;C<1<<R[K];C++)z[ee++]=K;for(ee>>=7;K<u;K++)for(P[K]=ee<<7,C=0;C<1<<R[K]-7;C++)z[256+ee++]=K;for(V=0;V<=b;V++)le[V]=0;for(C=0;C<=143;)Z[2*C+1]=8,C++,le[8]++;for(;C<=255;)Z[2*C+1]=9,C++,le[9]++;for(;C<=279;)Z[2*C+1]=7,C++,le[7]++;for(;C<=287;)Z[2*C+1]=8,C++,le[8]++;for(Te(Z,g+1,le),C=0;C<u;C++)S[2*C+1]=5,S[2*C]=ve(C,5);F=new X(Z,w,p+1,g,b),E=new X(S,R,0,u,b),D=new X(new Array(0),O,0,m,x)})(),H=!0),I.l_desc=new G(I.dyn_ltree,F),I.d_desc=new G(I.dyn_dtree,E),I.bl_desc=new G(I.bl_tree,D),I.bi_buf=0,I.bi_valid=0,xe(I)},s._tr_stored_block=$,s._tr_flush_block=function(I,C,V,q){var K,ee,le=0;0<I.level?(I.strm.data_type===2&&(I.strm.data_type=(function(oe){var he,ie=4093624447;for(he=0;he<=31;he++,ie>>>=1)if(1&ie&&oe.dyn_ltree[2*he]!==0)return l;if(oe.dyn_ltree[18]!==0||oe.dyn_ltree[20]!==0||oe.dyn_ltree[26]!==0)return r;for(he=32;he<p;he++)if(oe.dyn_ltree[2*he]!==0)return r;return l})(I)),j(I,I.l_desc),j(I,I.d_desc),le=(function(oe){var he;for(v(oe,oe.dyn_ltree,oe.l_desc.max_code),v(oe,oe.dyn_dtree,oe.d_desc.max_code),j(oe,oe.bl_desc),he=m-1;3<=he&&oe.bl_tree[2*N[he]+1]===0;he--);return oe.opt_len+=3*(he+1)+5+5+4,he})(I),K=I.opt_len+3+7>>>3,(ee=I.static_len+3+7>>>3)<=K&&(K=ee)):K=ee=V+5,V+4<=K&&C!==-1?$(I,C,V,q):I.strategy===4||ee===K?(ae(I,2+(q?1:0),3),L(I,Z,S)):(ae(I,4+(q?1:0),3),(function(oe,he,ie,ne){var Ce;for(ae(oe,he-257,5),ae(oe,ie-1,5),ae(oe,ne-4,4),Ce=0;Ce<ne;Ce++)ae(oe,oe.bl_tree[2*N[Ce]+1],3);U(oe,oe.dyn_ltree,he-1),U(oe,oe.dyn_dtree,ie-1)})(I,I.l_desc.max_code+1,I.d_desc.max_code+1,le+1),L(I,I.dyn_ltree,I.dyn_dtree)),xe(I),q&&ue(I)},s._tr_tally=function(I,C,V){return I.pending_buf[I.d_buf+2*I.last_lit]=C>>>8&255,I.pending_buf[I.d_buf+2*I.last_lit+1]=255&C,I.pending_buf[I.l_buf+I.last_lit]=255&V,I.last_lit++,C===0?I.dyn_ltree[2*V]++:(I.matches++,C--,I.dyn_ltree[2*(k[V]+p+1)]++,I.dyn_dtree[2*W(C)]++),I.last_lit===I.lit_bufsize-1},s._tr_align=function(I){ae(I,2,3),ce(I,_,Z),(function(C){C.bi_valid===16?(se(C,C.bi_buf),C.bi_buf=0,C.bi_valid=0):8<=C.bi_valid&&(C.pending_buf[C.pending++]=255&C.bi_buf,C.bi_buf>>=8,C.bi_valid-=8)})(I)}},{"../utils/common":41}],53:[function(i,n,s){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,n,s){(function(o){(function(l,r){if(!l.setImmediate){var a,c,d,p,g=1,u={},m=!1,h=l.document,b=Object.getPrototypeOf&&Object.getPrototypeOf(l);b=b&&b.setTimeout?b:l,a={}.toString.call(l.process)==="[object process]"?function(B){process.nextTick(function(){x(B)})}:(function(){if(l.postMessage&&!l.importScripts){var B=!0,M=l.onmessage;return l.onmessage=function(){B=!1},l.postMessage("","*"),l.onmessage=M,B}})()?(p="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",_,!1):l.attachEvent("onmessage",_),function(B){l.postMessage(p+B,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(B){x(B.data)},function(B){d.port2.postMessage(B)}):h&&"onreadystatechange"in h.createElement("script")?(c=h.documentElement,function(B){var M=h.createElement("script");M.onreadystatechange=function(){x(B),M.onreadystatechange=null,c.removeChild(M),M=null},c.appendChild(M)}):function(B){setTimeout(x,0,B)},b.setImmediate=function(B){typeof B!="function"&&(B=new Function(""+B));for(var M=new Array(arguments.length-1),T=0;T<M.length;T++)M[T]=arguments[T+1];var w={callback:B,args:M};return u[g]=w,a(g),g++},b.clearImmediate=y}function y(B){delete u[B]}function x(B){if(m)setTimeout(x,0,B);else{var M=u[B];if(M){m=!0;try{(function(T){var w=T.callback,R=T.args;switch(R.length){case 0:w();break;case 1:w(R[0]);break;case 2:w(R[0],R[1]);break;case 3:w(R[0],R[1],R[2]);break;default:w.apply(r,R)}})(M)}finally{y(B),m=!1}}}}function _(B){B.source===l&&typeof B.data=="string"&&B.data.indexOf(p)===0&&x(+B.data.slice(p.length))}})(typeof self>"u"?o===void 0?this:o:self)}).call(this,typeof es<"u"?es:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(ro)),ro.exports}var O0=P0();const R0=L0(O0),N0=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,z0=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function F0(e){const t=await R0.loadAsync(e),i={},n=[];let s="",o="";const l=[];t.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(s=await r.file.async("string"),o=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||z0.test(c)||c.includes("snippets/")){const d=await a.file.async("string");i[c]=d;const p=c.split("/");p.length>1&&(i[p.slice(1).join("/")]=d)}else if(N0.test(c)){const d=await a.file.async("uint8array"),p=c.split("/").pop()||c,g=typeof Blob<"u"?new Blob([d]):void 0;n.push({zipPath:c,fileName:p,data:d,blob:g})}}return{entryMarkdown:s,entryMarkdownPath:o,virtualFiles:i,assets:n}}function H0(e,t){if(Object.keys(t).length===0)return e;function i(s){const o=s.trim().replace(/^['"]|['"]$/g,""),l=o.split("/").pop()||o;if(t[o])return t[o];const r=o.replace(/^\.?\//,"");return t[r]?t[r]:t[l]?t[l]:null}function n(s){let o=s;return o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=i(a);return c?`![${r}](${c})`:l}),o=o.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=i(r);return a?`src="${a}"`:l}),o}for(const s of e.slides)if(s.rawMarkdown=n(s.rawMarkdown),s.pageAttrs["custom-slidev-background"]){const o=s.pageAttrs["custom-slidev-background"],l=i(o);l&&(s.pageAttrs["custom-slidev-background"]=l)}if(e.flattenedMarkdown=n(e.flattenedMarkdown),e.docRootAttrs["custom-slidev-background"]){const s=e.docRootAttrs["custom-slidev-background"],o=i(s);o&&(e.docRootAttrs["custom-slidev-background"]=o)}return e}function za(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function j0(e,t){const i=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const n=i[1].trim(),s=n.indexOf("#"),o=s!==-1?n.slice(0,s):n,l=s!==-1?n.slice(s+1):"",r=o.replace(/^@\//,"").replace(/^\.\//,""),a=(t==null?void 0:t.virtualFiles)||{};let c=a[o]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const u=r.split("/").pop();for(const[m,h]of Object.entries(a))if(m.endsWith(`/${r}`)||u&&m.endsWith(`/${u}`)){c=h;break}}if(!c){const u=[];if(t!=null&&t.baseDir)try{const m=require("path");u.push(m.resolve(t.baseDir,r)),u.push(m.resolve(t.baseDir,o))}catch{}try{const m=require("path");u.push(m.resolve(process.cwd(),r))}catch{}for(const m of u){const h=za(m);if(h!==null){c=h;break}}}if(!c){const u=$a||{};if(c=u[o]||u[r]||u[`snippets/${r}`],!c){const m=r.split("/").pop();for(const[h,b]of Object.entries(u))if(h.endsWith(`/${r}`)||m&&h.endsWith(`/${m}`)){c=b;break}}}if(!c)return null;let d=c;if(l){const u=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),m=c.match(u);if(m){const h=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(h?h[1]:"")+m[1].trimEnd()}}const p=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${p?p[1]:""}
${d}
\`\`\``}function W0(e){let t=!1,i=!1;for(let n=0;n<e.length;n++){const s=e[n];if(s==="'"&&!i)t=!t;else if(s==='"'&&!t)i=!i;else if(s==="#"&&!t&&!i)return e.slice(0,n).trim()}return e.trim()}function os(e){const t={},i=e.split(/\r?\n/);let n=0;for(;n<i.length;){const s=i[n],o=s.trim();if(!o||o.startsWith("#")){n++;continue}const l=s.indexOf(":");if(l>0){const r=s.slice(0,l).trim();let a=s.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let d=-1;for(;n<i.length;){const p=i[n];if(!p.trim()){c.push(""),n++;continue}const u=p.match(/^(\s+)/),m=u?u[1].length:0;if(d===-1&&(d=m),m<d)break;c.push(p.slice(d)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=W0(a),!a){let c=n+1;const d=[];let p=-1;for(;c<i.length;){const g=i[c],u=g.trim();if(!u||u.startsWith("#")){p!==-1&&d.push(""),c++;continue}const m=g.match(/^(\s+)/),h=m?m[1].length:0;if(p===-1)if(h>0)p=h;else break;if(h<p)break;d.push(g.slice(p)),c++}if(d.length>0){t[r]=os(d.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),t[r]=a}n++}return t}const U0=/^\s*```ya?ml([\s\S]*?)```/;function Xr(e){let t={},i=e.trim();const n=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const o=os(n[1]);if(Object.keys(o).length>0||!n[1].trim())return t=o,i=i.slice(n[0].length).trim(),{frontmatter:t,content:i}}if(i.startsWith("---")){const o=i.match(/^---[^\n\r]*(?:\r?\n|$)/);o&&(i=i.slice(o[0].length).trim())}const s=i.match(U0);if(s)t=os(s[1]),i=i.slice(s[0].length).trim();else{const o=i.split(/\r?\n/),l=[];let r=0;for(let a=0;a<o.length;a++){const c=o[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(t=os(l.join(`
`)),i=o.slice(r).join(`
`).trim())}return{frontmatter:t,content:i}}function V0(e){const t=e.split(/\r?\n/),i=[];let n=0,s=!1;function o(l){if(n>=l)return;const r=t.slice(n,l).join(`
`).trim();r&&i.push(r),n=l+1}for(let l=0;l<t.length;l++){const a=t[l].trimEnd();if(s){a.includes("-->")&&(s=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(s=!0);continue}if(a.startsWith("---")){o(l);const c=t[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<t.length&&t[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let p=l+1;for(;p<t.length&&!t[p].trimStart().startsWith(d);p++);p<t.length&&(l=p)}}return n<t.length&&o(t.length),i}function rs(e,t={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:n=!0,cleanShikiLines:s=!0,cleanSlots:o=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=t;let d=e;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const p=V0(d),g={};let u="",m="",h=0;if(p.length>0){const N=p[0],Z=Xr(N),S=Object.keys(Z.frontmatter).length>0,z=Z.content.length>0;S&&!z&&p.length>1?(h=1,b(Z.frontmatter)):S&&b(Z.frontmatter)}function b(N){u=N.title||"",N.theme&&(g[An]=String(N.theme)),N.aspectRatio&&(g[Bn]=String(N.aspectRatio)),N.highlighter&&(g[ll]=String(N.highlighter)),N.transition&&(g[Mn]=String(N.transition)),N.colorSchema&&(g[al]=String(N.colorSchema)),N.layout&&(g[ge]=String(N.layout)),N.background&&(g[Ke]=String(N.background)),N.image&&(g[Dt]=String(N.image)),N.class&&(g[Gi]=String(N.class));for(const[Z,S]of Object.entries(N))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(Z)||(g[`custom-slidev-${Z}`]=typeof S=="object"?JSON.stringify(S):String(S))}const y=[];let x=0,_=0,B=0,M=0;const T=new Set,w={};let R=1;for(let N=h;N<p.length;N++){const Z=p[N],{frontmatter:S,content:z}=Xr(Z),k=Z.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),A=S.src||(k?k[1]:void 0);if(A){const ue=String(A).trim().replace(/^['"]|['"]$/g,"");let Y=c[ue]||c[ue.replace(/^\.\//,"")]||c[`pages/${ue.replace(/^.*pages\//,"")}`];if(!Y){const L=ue.replace(/^\.\//,""),j=[];if(t.baseDir)try{const v=require("path");j.push(v.resolve(t.baseDir,L)),j.push(v.resolve(t.baseDir,ue))}catch{}try{const v=require("path");j.push(v.resolve(process.cwd(),L)),j.push(v.resolve(process.cwd(),ue))}catch{}for(const v of j){const U=za(v);if(U!==null){Y=U;break}}}const fe={};S.layout&&(fe[ge]=String(S.layout)),S.transition&&(fe[tt]=String(S.transition)),S.background&&(fe[Ke]=String(S.background)),S.image&&(fe[Dt]=String(S.image)),S.class&&(fe[Gi]=String(S.class));for(const[L,j]of Object.entries(S))["src","layout","transition","background","image","class"].includes(L)||(fe[`custom-slidev-${L}`]=typeof j=="object"?JSON.stringify(j):String(j));if(Y){const L=rs(Y,{...t,virtualFiles:c});for(const j of L.slides){j.pageIndex=R++,j.pageAttrs={...fe,...j.pageAttrs},y.push(j);const v=j.pageAttrs[ge]||"default";w[v]=(w[v]||0)+1}continue}else{y.push({pageIndex:R++,pageAttrs:{...fe,"custom-slidev-src":ue},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${ue}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const L=fe[ge]||"default";w[L]=(w[L]||0)+1;continue}}const F={};S.layout&&(F[ge]=String(S.layout)),S.transition&&(F[tt]=String(S.transition)),S.background&&(F[Ke]=String(S.background)),S.image&&(F[Dt]=String(S.image)),S.class&&(F[Gi]=String(S.class)),S.mask&&(F[qi]=String(S.mask)),(S.maskRatio||S["mask-ratio"])&&(F[Zi]=String(S.maskRatio||S["mask-ratio"])),(S.maskStyle||S["mask-style"])&&(F[Yi]=String(S.maskStyle||S["mask-style"])),(S.maskInitial||S["mask-initial"])&&(F[Ji]=String(S.maskInitial||S["mask-initial"]));for(const[ue,Y]of Object.entries(S))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(ue)||(F[`custom-slidev-${ue}`]=typeof Y=="object"?JSON.stringify(Y):String(Y));let E=z;const D=[];let P=E.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,ue=>{const Y=`__CODE_TOKEN_NOTE_${D.length}__`;return D.push(ue),Y});P=P.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,ue=>{const Y=`__CODE_TOKEN_NOTE_${D.length}__`;return D.push(ue),Y});let X="";const G=Array.from(P.matchAll(/<!--([\s\S]*?)-->/g));if(G.length>0){const ue=G[G.length-1],Y=P.slice(ue.index+ue[0].length).trim();if(!Y||!Y.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const L=ue[1].trim();L.startsWith("TODO:")||(X=L,x++),i&&(P=P.slice(0,ue.index).trimEnd()+P.slice(ue.index+ue[0].length))}}i&&(P=P.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let ue=0;ue<D.length;ue++)P=P.replace(`__CODE_TOKEN_NOTE_${ue}__`,D[ue]);if(E=P,X){for(let fe=0;fe<D.length;fe++)X=X.replace(`__CODE_TOKEN_NOTE_${fe}__`,D[fe]);const Y=`> [!NOTE] 💡 演讲备注
${X.split(/\r?\n/).map(fe=>`> ${fe}`).join(`
`)}
{: custom-slidev-note="true"}`;E=E?`${E}

${Y}`:Y}let W=!1;if(/<style\b/i.test(E)){W=!0;const ue=E.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(ue){for(const Y of ue){const fe=Y.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();m=m?`${m}

${fe}`:fe}l&&(E=E.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const se=E.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);se&&(_+=se.length);const ae=E.match(/```\w+\s+\{[^}]+\}/g);ae&&(B+=ae.length);const ce=E.match(/::\w+::|<template\s+#[^>]+>/g);if(ce&&(M+=ce.length),E=E.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,ue=>j0(ue,{...t,virtualFiles:c})||ue),n&&(E=E.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),s&&(E=E.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),E=E.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),o&&(E=E.replace(/^::\w+::\s*$/gm,"")),r&&(E=Mf(E)),a){let ue=E.trim(),Y="";const fe=ue.lastIndexOf("> [!NOTE] 💡 演讲备注");if(fe!==-1&&(Y=ue.slice(fe),ue=ue.slice(0,fe).trim()),(S.layout==="image-left"||S.layout==="image-right")&&S.image){const L=String(S.image).trim(),j=S.layout==="image-left"?"image-left":"image-right",v=`![配图](${L})
{: custom-slidev-layout="${j}" }`;S.layout==="image-left"?ue=`{{{col

${v}

${ue}

}}}`:ue=`{{{col

${ue}

${v}

}}}`}if(S.background){const j=`![背景图](${String(S.background).trim()})
{: custom-slidev-role="background" }`;ue=ue?`${j}

${ue}`:j}E=Y?`${ue}

${Y}`:ue}const ve=K0(E);F[Ke]&&ve.push(F[Ke]),F[Dt]&&ve.push(F[Dt]);for(const ue of ve)T.add(ue);const Te=/<[A-Z][a-zA-Z0-9]+/.test(E),xe=F[ge]||(R===1?g[ge]||"cover":"default");w[xe]=(w[xe]||0)+1,y.push({pageIndex:R++,pageAttrs:F,notes:X,rawMarkdown:E,hasVueComponent:Te,hasStyleTag:W,assetReferences:ve})}if(!u&&y.length>0){const N=y[0].rawMarkdown.match(/^#\s+(.+)$/m);N&&(u=N[1].trim())}m&&(g["custom-slidev-custom-css"]=m);let O=y.map(N=>`---

${N.rawMarkdown}`).join(`

`);return O.trimStart().startsWith("---")||(O=`---

${O.trimStart()}`),{docTitle:u||"Slidev 演示文稿",docRootAttrs:g,slides:y,totalSlides:y.length,stats:{totalNotes:x,totalVClicks:_,totalShikiHighlights:B,totalSlots:M,discoveredAssets:Array.from(T),layoutDistribution:w},flattenedMarkdown:O,customCss:m}}function K0(e){const t=[],i=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=i.exec(e))!==null;){const o=n[1].split(/\s+/)[0].trim();o&&t.push(o)}const s=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=s.exec(e))!==null;){const o=n[1].trim();o&&t.push(o)}return t}function Fa(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),i=String(e.markdown||"").trim(),n=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||i==="---"||i==="***"||n==="---"||n==="***"}function G0(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function q0(e,t,i=He){const n=e.filter(Fa);let s=0;if(n.length>=t.length)for(let o=0;o<t.length;o++){const l=t[o],r=n[o];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),s++)}else for(let o=1;o<t.length;o++){const l=t[o],r=n[o-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),s++)}return s}async function Z0(e,t=He){let i=!1,n=0;for(const s of e){if(Fa(s)){i=!1;continue}const o=(s.markdown||s.content||"").trim();if(o==="::right::"||o.startsWith("::right::")){i=!0;continue}i&&s.id&&(await t(s.id,{[$e]:"right"}).catch(()=>{}),n++)}return n}async function Y0(e,t,i=nl){const n={};if(!t||t.length===0)return n;const s=[];for(const o of t){const l=new File([o.data],o.fileName,{type:"application/octet-stream"});s.push(l)}try{const o=await i("/data/assets",s);if(o!=null&&o.succMap)for(const[l,r]of Object.entries(o.succMap))n[l]=String(r)}catch(o){console.warn("上传本地静态资产失败，保留原路径:",o)}return Object.keys(n).length>0&&H0(e,n),n}async function J0(e){var B;const{presentation:t,notebookId:i,docTitle:n,extractedAssets:s=[],uploadAssets:o=!0,autoPreview:l=!0,plugin:r,api:a={}}=e,c=a.uploadFn||nl,d=a.createDocFn||zc,p=a.setAttrsFn||He,g=a.getChildBlocksFn||us,u=a.openTabFn||me.openTab,m=a.showMessageFn||me.showMessage;o&&s.length>0&&await Y0(t,s,c);const h=G0(n),b=`/${h}`,y=await d(i,b,t.flattenedMarkdown);if(!y)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const x=((B=t.slides[0])==null?void 0:B.pageAttrs)||{};await p(y,{...x,...t.docRootAttrs});const _=await g(y).catch(()=>[]);return Array.isArray(_)&&_.length>0&&(await q0(_,t.slides,p),await Z0(_,p)),m(`🎉 成功导入 Slidev 演示文档《${h}》！`),l&&r&&(r.currentDocId=y,await u({app:r.app,doc:{id:y}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),y}function X0(e){const t=pe("file"),i=pe(!1),n=pe(!1),s=pe(""),o=pe(null),l=pe(null),r=pe(""),a=pe(0),c=pe(""),d=pe([]),p=pe(null),g=pe(""),u=pe([]),m=pe(""),h=pe(!0),b=pe(!0),y=pe(!0),x=pe(!0),_=we(()=>{const F=a.value;if(F===0)return"0 B";const E=1024,D=["B","KB","MB","GB"],P=Math.floor(Math.log(F)/Math.log(E));return`${(F/E**P).toFixed(1)} ${D[P]}`}),B=we(()=>{var F;return((F=p.value)==null?void 0:F.docRootAttrs["custom-slidev-theme"])||"default"}),M=we(()=>{var F;return d.value.length>0?d.value.length:((F=p.value)==null?void 0:F.stats.discoveredAssets.length)||0}),T=we(()=>{var E;const F=((E=p.value)==null?void 0:E.stats.layoutDistribution)||{};return Object.entries(F).map(([D,P])=>({name:D,count:P}))});async function w(F=Nc){try{const E=await F();E!=null&&E.notebooks&&Array.isArray(E.notebooks)&&(u.value=E.notebooks.filter(D=>!D.closed),u.value.length>0&&!m.value&&(m.value=u.value[0].id))}catch(E){console.warn("获取笔记本列表失败:",E)}}function R(){var F;(F=o.value)==null||F.click()}function O(){l.value=null,r.value="",a.value=0,p.value=null,d.value=[],s.value=""}async function N(F){s.value="",l.value=F,r.value=F.name,a.value=F.size;try{if(F.name.toLowerCase().endsWith(".zip")){const D=await F.arrayBuffer(),P=await F0(D);if(!P.entryMarkdown){s.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}d.value=P.assets;const X=rs(P.entryMarkdown,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:h.value,cleanSlots:!1,virtualFiles:P.virtualFiles});p.value=X,g.value=X.docTitle||F.name.replace(/\.zip$/i,"")}else{const D=await F.text();d.value=[];const P=F.path||"",X=P?P.replace(/[\\/][^\\/]+$/,""):"",G=rs(D,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:h.value,cleanSlots:!1,baseDir:X||void 0});p.value=G,g.value=G.docTitle||F.name.replace(/\.md$/i,"")}}catch(E){console.error("解析文件失败:",E),s.value=`解析文件失败: ${E.message||String(E)}`}}function Z(){if(s.value="",!c.value.trim()){p.value=null;return}try{const F=rs(c.value,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:h.value,cleanSlots:!1});p.value=F,g.value=F.docTitle||"Slidev 演示文稿"}catch(F){s.value=`解析 Markdown 源码失败: ${F.message||String(F)}`}}async function S(){l.value?await N(l.value):c.value&&Z()}async function z(F){const E=F.target;E.files&&E.files[0]&&await N(E.files[0])}async function k(F){var E;i.value=!1,(E=F.dataTransfer)!=null&&E.files&&F.dataTransfer.files[0]&&await N(F.dataTransfer.files[0])}async function A(F=e){if(p.value){if(!m.value&&u.value.length>0&&(m.value=u.value[0].id),!m.value){s.value="请先选择目标笔记本";return}n.value=!0,s.value="";try{return await J0({presentation:p.value,notebookId:m.value,docTitle:g.value,extractedAssets:d.value,uploadAssets:y.value,autoPreview:x.value,plugin:F})}catch(E){console.error("导入 Slidev 演示失败:",E),s.value=`导入执行失败: ${E.message||String(E)}`}finally{n.value=!1}}}return{inputMode:t,isDragging:i,isImporting:n,errorMessage:s,fileInputRef:o,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:d,parsedPresentation:p,customDocTitle:g,notebooks:u,selectedNotebookId:m,optCleanHtml:h,optStripNotes:b,optUploadAssets:y,optAutoPreview:x,formattedFileSize:_,currentTheme:B,extractedAssetsCount:M,layoutChips:T,fetchNotebooks:w,triggerFileInput:R,clearFile:O,processFile:N,onFileSelected:z,onFileDrop:k,onTextChange:Z,reprocessCurrentInput:S,handleConfirmImport:A}}const Q0={class:"spm-import-dialog"},ek={class:"spm-tabs-header"},tk={class:"spm-dialog-body"},ik={key:0,class:"spm-file-section"},nk={key:0,class:"spm-dropzone-prompt"},sk={class:"spm-dropzone-icon"},ok={key:1,class:"spm-dropzone-active"},rk={class:"spm-file-badge"},lk={class:"spm-file-size"},ak={key:1,class:"spm-text-section"},ck={key:2,class:"spm-error-banner"},dk={key:3,class:"spm-preview-card"},uk={class:"spm-preview-card__header"},fk={style:{display:"inline-flex","align-items":"center",gap:"4px"}},pk={class:"spm-config-grid"},hk={class:"spm-form-item"},mk={class:"spm-form-item"},gk=["value"],vk={class:"spm-stats-grid"},bk={class:"spm-stat-box"},yk={class:"spm-stat-value"},kk={class:"spm-stat-box"},wk={class:"spm-stat-value"},xk={class:"spm-stat-box"},Sk={class:"spm-stat-value"},_k={class:"spm-stat-box"},Ck={class:"spm-stat-value"},$k={key:0,class:"spm-chips-row"},Ik={class:"spm-options-group"},Tk={class:"spm-checkbox-label"},Ek={class:"spm-checkbox-label"},Ak={class:"spm-checkbox-label"},Bk={class:"spm-checkbox-label"},Mk={class:"spm-dialog-footer"},Dk=["disabled"],Lk=["disabled"],Pk={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Ok={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Rk=xt({__name:"SlidevImportDialog",emits:["close","success"],setup(e,{emit:t}){const i=t,n=Rt("plugin"),{inputMode:s,isDragging:o,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:d,extractedAssetsCount:p,parsedPresentation:g,customDocTitle:u,notebooks:m,selectedNotebookId:h,optCleanHtml:b,optStripNotes:y,optUploadAssets:x,optAutoPreview:_,formattedFileSize:B,currentTheme:M,layoutChips:T,fetchNotebooks:w,triggerFileInput:R,clearFile:O,onFileSelected:N,onFileDrop:Z,onTextChange:S,reprocessCurrentInput:z,handleConfirmImport:k}=X0(n);un(async()=>{await w()});async function A(){const E=await k();E&&(i("success",{docId:E}),i("close"))}function F(){i("close")}return(E,D)=>(J(),te("div",{class:"spm-modal-overlay",onClick:Lt(F,["self"])},[f("div",Q0,[f("div",{class:"spm-dialog-header"},[D[18]||(D[18]=f("div",{class:"spm-dialog-title"},[f("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[f("use",{"xlink:href":"#iconSlidev"})]),f("span",null,"导入 Slidev 演示文档")],-1)),f("button",{class:"spm-close-btn",title:"关闭",onClick:F},"✕")]),f("div",ek,[f("button",{class:_e(["spm-tab-btn",{active:ye(s)==="file"}]),onClick:D[0]||(D[0]=P=>s.value="file")},[re(de,{name:"package"}),D[19]||(D[19]=f("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),f("button",{class:_e(["spm-tab-btn",{active:ye(s)==="text"}]),onClick:D[1]||(D[1]=P=>s.value="text")},[re(de,{name:"notes"}),D[20]||(D[20]=f("span",null,"粘贴 Markdown 源码",-1))],2)]),f("div",tk,[ye(s)==="file"?(J(),te("div",ik,[f("div",{class:_e(["spm-dropzone",{dragover:ye(o),"has-file":!!ye(c)}]),onDragover:D[4]||(D[4]=Lt(P=>o.value=!0,["prevent"])),onDragleave:D[5]||(D[5]=Lt(P=>o.value=!1,["prevent"])),onDrop:D[6]||(D[6]=Lt((...P)=>ye(Z)&&ye(Z)(...P),["prevent"])),onClick:D[7]||(D[7]=(...P)=>ye(R)&&ye(R)(...P))},[f("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:D[2]||(D[2]=(...P)=>ye(N)&&ye(N)(...P))},null,544),ye(c)?(J(),te("div",ok,[f("span",rk,[re(de,{name:"notes"}),_t(" "+ke(ye(c)),1)]),f("span",lk,"("+ke(ye(B))+")",1),f("button",{class:"spm-btn-text",onClick:D[3]||(D[3]=Lt((...P)=>ye(O)&&ye(O)(...P),["stop"]))},"更换文件")])):(J(),te("div",nk,[f("span",sk,[re(de,{name:"folder",style:{"font-size":"32px"}})]),D[21]||(D[21]=f("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),D[22]||(D[22]=f("p",{class:"spm-dropzone-hint"},[_t(" 支持 Slidev 完整工程 "),f("strong",null,".zip"),_t("（自动解包 public/ 静态素材）或单文件 "),f("strong",null,".md")],-1))]))],34)])):(J(),te("div",ak,[Et(f("textarea",{"onUpdate:modelValue":D[8]||(D[8]=P=>Je(d)?d.value=P:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:D[9]||(D[9]=(...P)=>ye(S)&&ye(S)(...P))},null,544),[[Cs,ye(d)]])])),ye(r)?(J(),te("div",ck," ⚠️ "+ke(ye(r)),1)):De("",!0),ye(g)?(J(),te("div",dk,[f("div",uk,[f("span",fk,[re(de,{name:"sparkles"}),D[23]||(D[23]=_t(" 演示解析摘要",-1))]),D[24]||(D[24]=f("span",{class:"spm-badge-success"},"预检就绪",-1))]),f("div",pk,[f("div",hk,[D[25]||(D[25]=f("label",{class:"spm-form-label"},"笔记文档标题",-1)),Et(f("input",{"onUpdate:modelValue":D[10]||(D[10]=P=>Je(u)?u.value=P:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[Cs,ye(u)]])]),f("div",mk,[D[26]||(D[26]=f("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Et(f("select",{"onUpdate:modelValue":D[11]||(D[11]=P=>Je(h)?h.value=P:null),class:"spm-select"},[(J(!0),te(Ue,null,ht(ye(m),P=>(J(),te("option",{key:P.id,value:P.id},ke(P.name),9,gk))),128))],512),[[ff,ye(h)]])])]),f("div",vk,[f("div",bk,[f("span",yk,ke(ye(g).totalSlides),1),D[27]||(D[27]=f("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),f("div",kk,[f("span",wk,ke(ye(M)),1),D[28]||(D[28]=f("span",{class:"spm-stat-label"},"演示主题",-1))]),f("div",xk,[f("span",Sk,ke(ye(g).stats.totalNotes),1),D[29]||(D[29]=f("span",{class:"spm-stat-label"},"演讲者提词",-1))]),f("div",_k,[f("span",Ck,ke(ye(p)),1),D[30]||(D[30]=f("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),ye(T).length>0?(J(),te("div",$k,[D[31]||(D[31]=f("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(J(!0),te(Ue,null,ht(ye(T),P=>(J(),te("span",{key:P.name,class:"spm-chip-badge"},ke(P.name)+": "+ke(P.count),1))),128))])):De("",!0),f("div",Ik,[f("label",Tk,[Et(f("input",{"onUpdate:modelValue":D[12]||(D[12]=P=>Je(b)?b.value=P:null),type:"checkbox",onChange:D[13]||(D[13]=(...P)=>ye(z)&&ye(z)(...P))},null,544),[[Xn,ye(b)]]),D[32]||(D[32]=f("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),f("label",Ek,[Et(f("input",{"onUpdate:modelValue":D[14]||(D[14]=P=>Je(y)?y.value=P:null),type:"checkbox",onChange:D[15]||(D[15]=(...P)=>ye(z)&&ye(z)(...P))},null,544),[[Xn,ye(y)]]),D[33]||(D[33]=f("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),f("label",Ak,[Et(f("input",{"onUpdate:modelValue":D[16]||(D[16]=P=>Je(x)?x.value=P:null),type:"checkbox"},null,512),[[Xn,ye(x)]]),D[34]||(D[34]=f("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),f("label",Bk,[Et(f("input",{"onUpdate:modelValue":D[17]||(D[17]=P=>Je(_)?_.value=P:null),type:"checkbox"},null,512),[[Xn,ye(_)]]),D[35]||(D[35]=f("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):De("",!0)]),f("div",Mk,[f("button",{class:"spm-btn-secondary",disabled:ye(l),onClick:F}," 取消 ",8,Dk),f("button",{class:"spm-btn-primary",disabled:!ye(g)||ye(l),onClick:A},[ye(l)?(J(),te("span",Pk,[re(de,{name:"refresh"}),D[36]||(D[36]=_t(" 正在导入生成中...",-1))])):(J(),te("span",Ok,[re(de,{name:"rocket"}),D[37]||(D[37]=_t(" 确认导入思源笔记",-1))]))],8,Lk)])])]))}}),Nk=Mt(Rk,[["__scopeId","data-v-2eff6f1e"]]);function sr(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function zk(e,t){var r;if(!e||e.length===0)return null;const i=t.activeBlockId||"",n=t.currentTopBlockId||i,s=t.currentPageDividerId||"",o=t.activeBlockType||"";if(sr(o)&&i){let a=e.find(c=>c.startBlockId===i);if(a||(a=e.find(c=>{var d,p;return((p=(d=c.blocks)==null?void 0:d[0])==null?void 0:p.id)===i}),a)||(a=e.find(c=>{var d;return(d=c.allBlockIds)==null?void 0:d.includes(i)}),a))return a}if(s){let a=e.find(c=>c.startBlockId===s);if(a||(a=e.find(c=>{var d,p;return((p=(d=c.blocks)==null?void 0:d[0])==null?void 0:p.id)===s}),a))return a}if(i){let a=e.find(d=>d.startBlockId===i);if(a||(a=e.find(d=>{var p,g;return((p=d.blocks)==null?void 0:p.some(u=>u.id===i))||((g=d.allBlockIds)==null?void 0:g.includes(i))}),a)||n&&n!==i&&(a=e.find(d=>{var p,g;return((p=d.blocks)==null?void 0:p.some(u=>u.id===n))||((g=d.allBlockIds)==null?void 0:g.includes(n))}),a)||(a=e.find(d=>{var p;return(p=d.noteBlocks)==null?void 0:p.some(g=>g.id===i||g.id===n)}),a))return a;const c=(r=t.activeBlockAttrs)==null?void 0:r[$e];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=e.find(d=>{var p,g;return((p=d.frontmatter)==null?void 0:p.layout)==="three-cols-header"||((g=d.blocks)==null?void 0:g.some(u=>u.slot==="col-1"||u.slot==="col-2"||u.slot==="col-3"))}),a))return a}return e[0]||null}function Fk(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!i)return!1;const n=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===e}function Hk(e){let t=null;function i(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const d=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(d,1200):t=setTimeout(d,1200)}async function n(c){var u;const d=e.activeBlockId.value||e.currentDocId.value;if(!d)return;for(const[m,h]of Object.entries(c))e.activeBlockAttrs.value[m]=h;Pe.setBlockAttrOverride(d,c),et(d,c);const p=(u=e.parentContainerId)==null?void 0:u.value,g=!!(p&&Fk(d,p));if(Ye in c&&g&&p){const m=c[Ye];e.parentContainerClicks&&(e.parentContainerClicks.value=m),Pe.setBlockAttrOverride(p,{[Ye]:m}),et(p,{[Ye]:m}),He(p,{[Ye]:m}).catch(()=>{})}if(ge in c){const m=c[ge];e.currentPageDividerLayout.value=m,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=m)}if(kt in c){const m=c[kt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=m)}i("保存中...");try{await He(d,c),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}async function s(c,d){await n({[c]:d})}function o(){const c=e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak";return e.currentPageDividerId.value||(c?e.activeBlockId.value:"")||e.currentDocId.value}async function l(c,d){const p=o();if(p){p===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=d),Pe.setBlockAttrOverride(p,{[c]:d}),et(p,{[c]:d}),c===ge&&(e.currentPageDividerLayout.value=d,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=d)),c===kt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=d),i("保存中...");try{await He(p,{[c]:d}),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}}async function r(c,d){const p=o();if(!p)return;const g={[ge]:c,[kt]:d};p===e.activeBlockId.value&&(e.activeBlockAttrs.value[ge]=c,e.activeBlockAttrs.value[kt]=d),e.currentPageDividerLayout.value=c,Pe.setBlockAttrOverride(p,g),et(p,g),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=d),i("应用排版中...");try{await He(p,g),i("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("应用失败")}}async function a(c,d){var g;const p=e.currentDocId.value||e.activeBlockId.value;if(p){e.activeBlockAttrs.value[c]=d,Pe.setBlockAttrOverride(p,{[c]:d}),et(p,{[c]:d}),(g=e.latestDoc.value)!=null&&g.config&&(c===An&&(e.latestDoc.value.config.theme=d),c===Bn&&(e.latestDoc.value.config.aspectRatio=d),c===Mn&&(e.latestDoc.value.config.defaultTransition=d)),i("更新中...");try{await He(p,{[c]:d}),i("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(p)}catch{i("更新失败")}}}return{triggerSaveNotice:i,saveAttrs:n,saveAttr:s,getPageTargetBlockId:o,savePageAttr:l,applyPageLayoutAndRatio:r,saveDocAttr:a}}function Qr(e,t){const i=(e.blocks||[]).filter(l=>{const r=(l.content||l.rawMarkdown||"").trim();return r&&r!=="---"});if(i.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],s=[];for(const l of i){const r=(l.content||l.rawMarkdown||"").trim();r&&(l.type==="h"||r.startsWith("#")?n.push(r.replace(/^#+\s*/,"")):s.push(r.slice(0,50)))}const o=[];return n.length>0&&o.push(`【核心重点】：${n.join("、")}`),s.length>0&&(o.push("【口播要点】："),s.slice(0,3).forEach((l,r)=>{o.push(`${r+1}. 讲解 ${l}`)})),o.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),o.join(`
`)}async function Ha(e,t){const i=e.blocks&&e.blocks.length>0?e.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(t&&i){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const s=await t(n);if(s&&s.trim())return{notes:s.trim(),isAiGenerated:!0}}catch(s){return{notes:Qr(e),isAiGenerated:!1,error:(s==null?void 0:s.message)||"AI 调用异常"}}}return{notes:Qr(e),isAiGenerated:!1}}async function jk(e,t){return(await Ha(e,t)).notes}function Wk(e,t){const i=pe(!1),{triggerSaveNotice:n}=t;async function s(p){var B,M,T,w,R,O,N,Z;const m=`> [!NOTE] 💡 演讲备注
${(p||"在此输入本页讲稿提词...").split(/\r?\n/).map(S=>`> ${S}`).join(`
`)}
{: custom-slidev-note="true"}`,h=((B=e.latestDoc.value)==null?void 0:B.slides)||[],b=e.targetSlide.value,y=b?h.findIndex(S=>S===b):-1;let x=null;if(y!==-1&&y<h.length-1){const S=h[y+1];x=await Mi("markdown",m,S.startBlockId)}else{const S=((M=b==null?void 0:b.noteBlocks)==null?void 0:M.slice(-1)[0])||((T=b==null?void 0:b.blocks)==null?void 0:T.slice(-1)[0]),z=(S==null?void 0:S.id)||(b==null?void 0:b.startBlockId);z?x=await Mi("markdown",m,void 0,z):x=await uo("markdown",m,e.currentDocId.value)}const _=((O=(R=(w=x==null?void 0:x[0])==null?void 0:w.doOperations)==null?void 0:R[0])==null?void 0:O.id)||((N=x==null?void 0:x[0])==null?void 0:N.id);return _&&(await He(_,{[nt]:"true"}),Pe.setBlockAttrOverride(_,{[nt]:"true"}),Ri(_,(Z=e.plugin)==null?void 0:Z.app)),e.plugin&&await e.plugin.compileCurrentDocument(),_}async function o(){const p=e.activeBlockId.value;if(p)if(e.isNoteBlock.value){n("取消中...");try{await He(p,{[nt]:"","slidev-note":""}),Pe.setBlockAttrOverride(p,{[nt]:"","slidev-note":""}),et(p,{[nt]:"","slidev-note":""}),delete e.activeBlockAttrs.value[nt],delete e.activeBlockAttrs.value["slidev-note"],n("已取消备注"),me.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(g){console.error("[SiYuanSlidev] 取消讲稿备注失败:",g),n("取消失败"),me.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let g=e.rawSnippet.value;try{const b=await Fc(p);b!=null&&b.kramdown&&(g=b.kramdown)}catch{}const h=`> [!NOTE] 💡 演讲备注
${(xa(g)||g.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(b=>`> ${b}`).join(`
`)}
{: custom-slidev-note="true"}`;await dr("markdown",h,p),await He(p,{[nt]:"true"}),Pe.setBlockAttrOverride(p,{[nt]:"true"}),et(p,{[nt]:"true"}),e.activeBlockAttrs.value[nt]="true",e.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),me.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(g){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",g),n("设置失败"),me.showMessage("转为讲稿备注提示块失败")}}}async function l(){try{await s(),me.showMessage("已在正文末尾插入讲稿备注提示块")}catch(p){me.showMessage("插入讲稿备注块失败"),console.error(p)}}function r(){var u;const p=e.currentSlideNoteBlockId.value;if(!p){me.showMessage("未找到本页关联的讲稿备注块");return}Ri(p,(u=e.plugin)==null?void 0:u.app)?me.showMessage("已在编辑区定位讲稿备注块"):me.showMessage("定位讲稿备注块失败")}async function a(){var u;if(!e.currentDocId.value)return;const p=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};me.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const g=await Ha(p,ol);if(g.notes){const m=e.currentSlideNoteBlockId.value;if(m){const h=`> [!NOTE] 💡 演讲备注
${g.notes.split(/\r?\n/).map(b=>`> ${b}`).join(`
`)}
{: custom-slidev-note="true"}`;await dr("markdown",h,m),await He(m,{[nt]:"true"}),Pe.setBlockAttrOverride(m,{[nt]:"true"}),Ri(m,(u=e.plugin)==null?void 0:u.app)}else await s(g.notes);g.isAiGenerated?me.showMessage("思源 AI 演讲提词卡生成成功！"):me.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}async function c(){var m;if(i.value)return;const p=((m=e.latestDoc.value)==null?void 0:m.slides)||[];if(p.length===0){me.showMessage("当前文档无幻灯片页面");return}const g=p.map((h,b)=>({slide:h,idx:b})).filter(({slide:h})=>{var x;const b=Array.isArray(h.noteBlocks)&&h.noteBlocks.length>0,y=!!((x=h.notes)!=null&&x.trim());return!b&&!y});if(g.length===0){me.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const u=g.length;me.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${u} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var b,y,x,_,B,M;if(i.value)return;i.value=!0,me.showMessage("正在批量追加讲稿块...");let h=0;try{const R=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(O=>`> ${O}`).join(`
`)}
{: custom-slidev-note="true"}`;for(const{slide:O,idx:N}of g)try{let Z=null;if(N<p.length-1){const z=p[N+1];Z=await Mi("markdown",R,z.startBlockId)}else{const z=((b=O==null?void 0:O.noteBlocks)==null?void 0:b.slice(-1)[0])||((y=O==null?void 0:O.blocks)==null?void 0:y.slice(-1)[0]),k=(z==null?void 0:z.id)||(O==null?void 0:O.startBlockId);k?Z=await Mi("markdown",R,void 0,k):Z=await uo("markdown",R,e.currentDocId.value)}const S=((B=(_=(x=Z==null?void 0:Z[0])==null?void 0:x.doOperations)==null?void 0:_[0])==null?void 0:B.id)||((M=Z==null?void 0:Z[0])==null?void 0:M.id);S&&(await He(S,{[nt]:"true"}),Pe.setBlockAttrOverride(S,{[nt]:"true"})),h++}catch(Z){console.error(`[SiYuanSlidev] 为第 ${N+1} 页追加讲稿块失败:`,Z)}e.plugin&&await e.plugin.compileCurrentDocument(),me.showMessage(`已成功为 ${h} 页追加讲稿备注块`)}catch(T){console.error("[SiYuanSlidev] 批量追加讲稿块失败:",T),me.showMessage("批量追加讲稿块时出现异常")}finally{i.value=!1}})}async function d(){var h;if(i.value)return;const p=((h=e.latestDoc.value)==null?void 0:h.slides)||[];if(p.length===0){me.showMessage("当前文档无幻灯片页面");return}const g=[];for(const b of p)if(b.noteBlocks&&b.noteBlocks.length>0)for(const y of b.noteBlocks)y.id&&g.push({id:y.id,pageIndex:b.pageIndex});if(g.length===0){me.showMessage("当前文档中没有讲稿备注块，无需删除");return}const u=new Set(g.map(b=>b.pageIndex)).size,m=g.length;me.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${m} 个讲稿备注块（涉及 ${u} 页），删除后无法撤销。是否确认继续？`,async()=>{if(i.value)return;i.value=!0,me.showMessage("正在批量删除讲稿块...");let b=0;try{for(const y of g)try{await sl(y.id),Pe.clearBlockAttrOverride(y.id),b++}catch(x){console.error(`[SiYuanSlidev] 删除讲稿块 ${y.id} 失败:`,x)}e.activeBlockId.value&&g.some(y=>y.id===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[nt],delete e.activeBlockAttrs.value["slidev-note"]),e.plugin&&await e.plugin.compileCurrentDocument(),me.showMessage(`已成功删除全部 ${b} 个讲稿备注块`)}catch(y){console.error("[SiYuanSlidev] 批量删除讲稿块失败:",y),me.showMessage("批量删除讲稿块时出现异常")}finally{i.value=!1}})}return{isBatchProcessing:i,createNoteBlockOnCurrentSlide:s,onToggleNoteBlock:o,onAddNoteBlock:l,onLocateNoteBlock:r,onGenerateNotesWithAI:a,onBatchAppendNotes:c,onBatchDeleteNotes:d}}function Uk(e,t){const{saveAttr:i,saveAttrs:n,savePageAttr:s}=t;async function o(){(e.videoAutoplay.value?"false":"true")==="true"?(await n({[Bi]:"true",[Vi]:"true"}),e.activeBlockAttrs.value[Bi]="true",e.activeBlockAttrs.value[Vi]="true"):(await i(Bi,"false"),e.activeBlockAttrs.value[Bi]="false")}async function l(){const w=e.videoLoop.value?"false":"true";await i(fs,w)}async function r(){const w=e.videoMuted.value?"false":"true";await i(Vi,w)}async function a(){const w=e.videoControls.value?"false":"true";await i(ps,w)}async function c(w){var S;const R=e.activeBlockId.value;if(!R)return;const O=e.rawSnippet.value||"",N=wi(O)||"",Z=e.currentPageDividerId.value||e.currentDocId.value;if(w)if(w==="background"){const z={[Ze]:"background",[ge]:""};Z&&N&&(e.pageBackground.value=N,await He(Z,{[Ke]:N}).catch(()=>{}),Pe.setBlockAttrOverride(Z,{[Ke]:N}),et(Z,{[Ke]:N}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=N)),await n(z)}else(w===hs||w===ms)&&await n({[ge]:w,[Ze]:""});else{const z={[Ze]:"",[ge]:""};if(e.activeBlockAttrs.value[Ke]==="true"&&(z[Ke]=""),Z&&N&&e.pageBackground.value===N&&(e.pageBackground.value="",await He(Z,{[Ke]:""}).catch(()=>{}),Pe.setBlockAttrOverride(Z,{[Ke]:""}),et(Z,{[Ke]:""}),(S=e.targetSlide.value)!=null&&S.frontmatter&&delete e.targetSlide.value.frontmatter.background),await n(z),typeof document<"u"){const k=document.querySelector(`.protyle-wysiwyg [data-node-id="${R}"]`),A=k==null?void 0:k.closest('[data-type="NodeListItem"]'),F=A==null?void 0:A.getAttribute("data-node-id");if(F&&F!==R){const E={[ge]:"",[Ze]:""};et(F,E),Pe.setBlockAttrOverride(F,E),await He(F,E).catch(()=>{})}}}}function d(){e.elemClick.value?i(Ye,""):i(Ye,"+1")}function p(w){i(Ye,w)}function g(w){i(qt,w)}function u(w){(e.activeBlockAttrs.value[$e]||"")===w?i($e,""):i($e,w)}function m(w){e.elemShikiLines.value=w,i(Ni,w)}function h(w){e.elemMaxHeight.value=w,i(Dn,w)}async function b(){const w=e.currentSlideLayout.value==="three-cols-header";await i($e,w?"col-1":"left"),me.showMessage(w?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function y(){const w=e.activeBlockId.value;if(!w)return;const R={[Ye]:"",[qt]:"",[$e]:"",[Ni]:"",[Dn]:"",[nt]:"","slidev-note":"",[ge]:"",[kt]:"",[Ze]:"",[tt]:"",[Ke]:"",[Dt]:"",[Bi]:"",[fs]:"",[Vi]:"",[ps]:""};if(et(w,R),await He(w,R),Pe.clearBlockAttrOverride(w),typeof document<"u"){const O=document.querySelector(`.protyle-wysiwyg [data-node-id="${w}"]`),N=O==null?void 0:O.closest('[data-type="NodeListItem"]'),Z=N==null?void 0:N.getAttribute("data-node-id");Z&&Z!==w&&(et(Z,R),await He(Z,R).catch(()=>{}),Pe.clearBlockAttrOverride(Z))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground.value="",e.pageImage.value="",me.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()}async function x(){if(e.activeBlockId.value)try{await Mi("markdown","---",e.activeBlockId.value,void 0),me.showMessage("已在上方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{me.showMessage("插入分页符失败")}}async function _(){const w=e.activeBlockId.value||e.currentDocId.value;if(w)try{await Mi("markdown","---",void 0,w),me.showMessage("已在下方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{me.showMessage("插入分页符失败")}}async function B(){if(e.activeBlockId.value)try{await sl(e.activeBlockId.value),me.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{me.showMessage("删除失败")}}async function M(){var w,R;try{let O=null;if(typeof document<"u"){const Z=e.activeBlockId.value;if(Z){const S=document.querySelector(`.protyle-wysiwyg [data-node-id="${Z}"]`);S&&(O=S.getAttribute("data-type")==="NodeSuperBlock"?S:S.closest('[data-type="NodeSuperBlock"]'))}if(!O){const S=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(S){const z=document.querySelector(`.protyle-wysiwyg [data-node-id="${S}"]`);if(z){let k=z.nextElementSibling;for(;k&&!(k.getAttribute("data-type")==="NodeThematicBreak"||(w=k.classList)!=null&&w.contains("protyle-wysiwyg__block--hr"));){const A=k.getAttribute("data-type")==="NodeSuperBlock"?k:k.querySelector('[data-type="NodeSuperBlock"]');if(A){O=A;break}k=k.nextElementSibling}}}else{const z=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),k=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const A of k)if(!z||A.compareDocumentPosition(z)&Node.DOCUMENT_POSITION_FOLLOWING){O=A;break}}}}const N=[];if(O){const Z=Array.from(O.querySelectorAll(":scope > [data-node-id]"));for(const S of Z){const z=S.getAttribute("data-node-id");z&&(N.push(z),S.removeAttribute("style"))}}else if((R=e.targetSlide.value)!=null&&R.blocks){for(const Z of e.targetSlide.value.blocks)if(Z.children&&Z.children.length>=2){for(const S of Z.children)S.id&&N.push(S.id);break}}if(N.length>0)for(const Z of N)await He(Z,{style:""}).catch(()=>{});await s(kt,""),me.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(O){console.error("[layout-actions] resetSuperBlockWidth error:",O),me.showMessage("重置超级块比例失败")}}async function T(){var w,R,O;try{let N=null;if(typeof document<"u"){const S=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),z=e.activeBlockId.value;let k=[];if(S){const E=document.querySelector(`.protyle-wysiwyg [data-node-id="${S}"]`);if(E){let D=E.nextElementSibling;for(;D&&!(D.getAttribute("data-type")==="NodeThematicBreak"||(w=D.classList)!=null&&w.contains("protyle-wysiwyg__block--hr"));)k.push(D),D=D.nextElementSibling}}else{const E=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),D=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const P of D)if(!E||P.compareDocumentPosition(E)&Node.DOCUMENT_POSITION_FOLLOWING)k.push(P);else break}const A=[];let F;for(const E of k){const D=E.getAttribute("data-type");D==="NodeHeading"&&(F=E.getAttribute("data-node-id")||void 0);const P=[];D==="NodeSuperBlock"?P.push(E):P.push(...Array.from(E.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const X of P){if((X.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const W=X.getAttribute("data-node-id")||"";let se=[];const ae=Array.from(X.querySelectorAll('[data-type="NodeListItem"]'));if(ae.length===4&&(se=ae.map(ce=>ce.getAttribute("data-node-id")).filter(Boolean)),se.length!==4){const ce=Array.from(X.querySelectorAll(":scope > [data-node-id]"));ce.length===4&&(se=ce.map(ve=>ve.getAttribute("data-node-id")).filter(Boolean))}se.length===4&&A.push({sbId:W,itemIds:se,headerId:F})}}A.length>0&&(z&&(N=A.find(E=>{if(E.sbId===z||E.itemIds.includes(z))return!0;const D=document.querySelector(`.protyle-wysiwyg [data-node-id="${E.sbId}"]`),P=document.querySelector(`.protyle-wysiwyg [data-node-id="${z}"]`);return!!(D&&P&&D.contains(P))})||null),N||(N=A[0]))}if(!N&&((R=e.targetSlide.value)!=null&&R.blocks)){const S=e.targetSlide.value,z=[];for(const A of S.blocks)A.rawNode?z.push(A.rawNode):z.push({id:A.id,type:A.type,content:A.content,markdown:A.rawMarkdown,children:A.children,ial:A.attributes||A.ial||{}});const k=Tf(z,e.activeBlockId.value);k&&k.items.length===4&&(N={sbId:k.superBlockNode.id,itemIds:k.items.map(A=>A.id),headerId:(O=k.headerNode)==null?void 0:O.id})}if(!N||N.itemIds.length!==4)return me.showMessage("当前页面未找到包含 4 个组件的超级块（需包含 4 个列表项或 4 个子块）",4e3,"info"),!1;const Z=e.currentPageDividerId.value||e.currentDocId.value;Z&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Pe.setBlockAttrOverride(Z,{[ge]:"clover"}),et(Z,{[ge]:"clover"}),await He(Z,{[ge]:"clover"}).catch(()=>{})),N.headerId&&(Pe.setBlockAttrOverride(N.headerId,{[$e]:"header"}),et(N.headerId,{[$e]:"header"}),await He(N.headerId,{[$e]:"header"}).catch(()=>{}));for(let S=0;S<4;S++){const z=N.itemIds[S],k=`col-${S+1}`;Pe.setBlockAttrOverride(z,{[$e]:k}),et(z,{[$e]:k}),await He(z,{[$e]:k}).catch(()=>{})}return me.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(N){return console.error("[layout-actions] applyCloverLayout error:",N),me.showMessage("配置四叶草布局失败",4e3,"error"),!1}}return{onToggleVideoAutoplay:o,onToggleVideoLoop:l,onToggleVideoMuted:r,onToggleVideoControls:a,onImageRoleChange:c,toggleElemClick:d,onElemClickStepChange:p,onElemMotionChange:g,onElemSlotChange:u,onElemShikiLinesChange:m,onElemMaxHeightChange:h,onSetTwoColsContrast:b,onClearBlockAttrs:y,onInsertDividerBefore:x,onInsertDividerAfter:_,onDeleteCurrentBlock:B,resetSuperBlockWidth:M,applyCloverLayout:T}}function Vk(e){const{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:l}=Hk(e),r=Wk(e,{triggerSaveNotice:t}),a=Uk(e,{saveAttr:n,saveAttrs:i,savePageAttr:s});function c(){if(!e.latestDoc.value){me.showMessage("请先在主编辑区打开幻灯片文档");return}const p=La(e.latestDoc.value);Pa("presentation.html",p)&&me.showMessage("已开始下载单文件离线 HTML 演示包")}function d(){if(!e.latestDoc.value){me.showMessage("请先在主编辑区打开幻灯片文档");return}Oa(e.latestDoc.value)&&me.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:l,onToggleVideoAutoplay:a.onToggleVideoAutoplay,onToggleVideoLoop:a.onToggleVideoLoop,onToggleVideoMuted:a.onToggleVideoMuted,onToggleVideoControls:a.onToggleVideoControls,onImageRoleChange:a.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,toggleElemClick:a.toggleElemClick,onElemClickStepChange:a.onElemClickStepChange,onElemMotionChange:a.onElemMotionChange,onElemSlotChange:a.onElemSlotChange,onElemShikiLinesChange:a.onElemShikiLinesChange,onElemMaxHeightChange:a.onElemMaxHeightChange,onSetTwoColsContrast:a.onSetTwoColsContrast,onClearBlockAttrs:a.onClearBlockAttrs,onInsertDividerBefore:a.onInsertDividerBefore,onInsertDividerAfter:a.onInsertDividerAfter,onDeleteCurrentBlock:a.onDeleteCurrentBlock,resetSuperBlockWidth:a.resetSuperBlockWidth,applyCloverLayout:a.applyCloverLayout,onExportHtml:c,onExportPdf:d}}function Kk(e){const t=we(()=>sr(e.activeBlockType.value));function i(n){const{attrKey:s,fallback:o,mode:l="defined"}=n,r=a=>l==="truthy"?a:a!==void 0;return we(()=>{if(t.value){const c=e.activeBlockAttrs.value[s];if(r(c))return c}const a=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(a){const c=Pe.getBlockAttrOverride(a);if(r(c==null?void 0:c[s]))return c[s]}return o()})}return{isDivider:t,resolvePageAttr:i}}const Gk={class:"spm-slidev-inspector"},qk={class:"spm-inspector-topbar"},Zk={class:"spm-inspector-title"},Yk={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},Jk={class:"spm-inspector-topbar-actions"},Xk={class:"spm-target-banner"},Qk={class:"spm-target-info"},ew=["aria-label"],tw={key:0,class:"spm-save-status"},iw=["title"],nw={class:"spm-inspector-body"},sw=xt({__name:"SlidevInspectorDockView",setup(e,{expose:t}){const i=Rt("plugin"),n=pe(!1);function s(Q){n.value=!1,c.value=Q.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(Q.docId)}const o=pe(""),l=pe(""),r=pe({}),a=pe(""),c=pe(""),d=pe(""),p=pe(""),g=pe(""),u=pe(""),m=pe(""),h=pe(""),b=pe(null),y=pe(""),x=pe("");function _(){var be;const Q=o.value||c.value;Q&&typeof navigator<"u"&&(be=navigator==null?void 0:navigator.clipboard)!=null&&be.writeText&&navigator.clipboard.writeText(Q).then(()=>{x.value="已复制！",setTimeout(()=>{x.value=""},1500)}).catch(()=>{})}const B=we(()=>sr(l.value)),M=we(()=>l.value==="NodeCodeBlock"),T=pe(!1),w=we(()=>{if(T.value||Be.value)return!0;const Q=a.value||"";return!!wi(Q)}),R=we(()=>{const Q=l.value||"";if(Q==="NodeVideo"||Q==="video")return!0;const be=a.value||"";return!!(/<video\b/i.test(be)||/\.mp4\b/i.test(be))}),O=we(()=>!o.value||o.value===c.value||l.value==="doc"||l.value==="NodeDocument"),N=we(()=>{const Q=o.value||c.value||"";return Q.length>8?Q.slice(-8):Q||"无"}),Z=we(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),S=we(()=>{if(B.value)return"分页符 (---)";if(O.value)return"全局文档";if(R.value)return"视频块";let Q="内容块";switch(l.value){case"NodeHeading":Q="标题块";break;case"NodeParagraph":Q="段落块";break;case"NodeCodeBlock":Q="代码块";break;case"NodeVideo":Q="视频块";break;case"NodeList":case"NodeListItem":Q="列表项";break;case"NodeBlockquote":Q="引述块";break;case"NodeTable":Q="表格块";break;case"NodeSuperBlock":case"s":case"sb":Q="超级块";break;default:Q="内容块";break}return u.value?m.value?`${m.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${Q}`:`分栏容器 › ${Q}`:Q}),z=we(()=>B.value?"tag-divider":O.value?"tag-doc":"tag-block"),k=we(()=>r.value[ge]||"default"),A=we(()=>r.value[tt]||"slide-left"),F=pe(""),E=pe(""),D=we(()=>r.value[wn]||"inherit"),P=we(()=>{var Q;return zk((Q=b.value)==null?void 0:Q.slides,{activeBlockId:o.value,activeBlockType:l.value,currentTopBlockId:d.value,currentPageDividerId:p.value,activeBlockAttrs:r.value})}),X=we(()=>{var Q;return((Q=P.value)==null?void 0:Q.notes)||""}),G=we(()=>{var Q,be,Ee;return((Ee=(be=(Q=P.value)==null?void 0:Q.noteBlocks)==null?void 0:be[0])==null?void 0:Ee.id)||""}),W=we(()=>{var je,We,Oe,ut,Kn,ui;if(B.value){const Qe=r.value[ge]||r.value["custom-slidev-layout"];if(Qe)return Qe}const Q=r.value[$e]||r.value["custom-slidev-slot"];if(Q&&(["col-1","col-2","col-3"].includes(Q)||/^col-\d+$/.test(Q)))return"cols-header";if(g.value)return g.value;const be=p.value||(B.value?o.value:"");if(be){const Qe=Pe.getBlockAttrOverride(be);if(Qe!=null&&Qe[ge])return Qe[ge]}if(be&&((je=b.value)!=null&&je.slides)){const Qe=b.value.slides.find(ji=>ji.startBlockId===be);if((We=Qe==null?void 0:Qe.frontmatter)!=null&&We.layout)return Qe.frontmatter.layout}if((ut=(Oe=P.value)==null?void 0:Oe.frontmatter)!=null&&ut.layout)return P.value.frontmatter.layout;if((ui=(Kn=P.value)==null?void 0:Kn.blocks)!=null&&ui.some(Qe=>Qe.slot&&(["col-1","col-2","col-3"].includes(Qe.slot)||/^col-\d+$/.test(Qe.slot))))return"cols-header";const Ee=Pe.getBlockAttrOverride(c.value);return Ee!=null&&Ee[ge]?Ee[ge]:"default"}),se=Kk({activeBlockId:o,activeBlockType:l,activeBlockAttrs:r,currentPageDividerId:p}),ae=se.resolvePageAttr({attrKey:kt,mode:"truthy",fallback:()=>{var Q,be;return((be=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:be.layoutRatio)||""}}),ce=se.resolvePageAttr({attrKey:qi,fallback:()=>{var Q,be;return((be=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:be.mask)||""}}),ve=se.resolvePageAttr({attrKey:Zi,fallback:()=>{var Q,be;return((be=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:be.maskRatio)||""}}),Te=se.resolvePageAttr({attrKey:Yi,fallback:()=>{var Q,be;return((be=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:be.maskStyle)||"solid"}}),xe=se.resolvePageAttr({attrKey:Ji,fallback:()=>{var Q,be;return((be=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:be.maskInitial)||"hidden"}});function ue(Q){if(!Q||(Q.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Ee=Array.from(Q.querySelectorAll(":scope > [data-node-id]"));if(Ee.length<2)return null;const je=Ee.length,We=Ee.map(ui=>{const Qe=ui.getAttribute("style")||"",ji=Qe.match(/calc\(\s*([\d.]+)%/);if(ji)return parseFloat(ji[1]);const hn=Qe.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return hn?parseFloat(hn[1]):null});let Oe="",ut=!1;if(We.some(ui=>ui!==null)){ut=!0;const ui=We.reduce((Me,ft)=>Me+(ft||0),0),Qe=We.filter(Me=>Me===null).length,ji=Qe>0?Math.max(0,100-ui)/Qe:100/Ee.length,hn=We.map(Me=>Me!==null?Me:ji),Ac=hn.reduce((Me,ft)=>Me+ft,0)||1,mn=hn.map(Me=>Me/Ac*100);if(mn.length===2){const[Me]=mn;if(Me>=48&&Me<=52)Oe="1:1";else if(Me>=31&&Me<=35)Oe="1:2";else if(Me>=65&&Me<=69)Oe="2:1";else if(Me>=28&&Me<=32)Oe="3:7";else if(Me>=68&&Me<=72)Oe="7:3";else if(Me>=38&&Me<=42)Oe="4:6";else if(Me>=58&&Me<=62)Oe="6:4";else{const ft=Math.round(Me);Oe=`${ft}:${100-ft}`}}else if(mn.length===3){const[Me,ft,fi]=mn;if(Me>=31&&Me<=35&&ft>=31&&ft<=35&&fi>=31&&fi<=35)Oe="1:1:1";else if(Me>=23&&Me<=27&&ft>=48&&ft<=52&&fi>=23&&fi<=27)Oe="1:2:1";else if(Me>=48&&Me<=52&&ft>=23&&ft<=27&&fi>=23&&fi<=27)Oe="2:1:1";else if(Me>=23&&Me<=27&&ft>=23&&ft<=27&&fi>=48&&fi<=52)Oe="1:1:2";else{const ar=Math.round(Me),cr=Math.round(ft);Oe=`${ar}:${cr}:${100-ar-cr}`}}else Oe=mn.map(Me=>Math.round(Me)).join(":")}else ut=!1,Oe=Array.from({length:je},()=>1).join(":");const Kn=je>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:je,ratio:Oe,isCustomWidth:ut,recommendedLayout:Kn}}function Y(Q){if(!(Q!=null&&Q.blocks))return null;for(const be of Q.blocks){const Ee=be.rawNode;if(Ee&&ot(Ee)&&Yt(Ee)){const We=fn(Ee).length,Oe=Qo(Ee);return{hasSuperBlock:!0,colCount:We,ratio:Oe||Array.from({length:We},()=>1).join(":"),isCustomWidth:!!Oe,recommendedLayout:We>=2?"cols-header":"two-cols"}}}return null}const fe=we(()=>{var Q;if(typeof document<"u"){const be=o.value;if(be){const je=document.querySelector(`.protyle-wysiwyg [data-node-id="${be}"]`);if(je){const We=je.getAttribute("data-type")==="NodeSuperBlock"?je:je.closest('[data-type="NodeSuperBlock"]');if(We){const Oe=ue(We);if(Oe)return Oe}}}const Ee=p.value||(B.value?o.value:"");if(Ee){const je=document.querySelector(`.protyle-wysiwyg [data-node-id="${Ee}"]`);if(je){let We=je.nextElementSibling;for(;We&&!(We.getAttribute("data-type")==="NodeThematicBreak"||(Q=We.classList)!=null&&Q.contains("protyle-wysiwyg__block--hr"));){const Oe=We.getAttribute("data-type")==="NodeSuperBlock"?We:We.querySelector('[data-type="NodeSuperBlock"]');if(Oe){const ut=ue(Oe);if(ut)return ut}We=We.nextElementSibling}}}else{const je=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),We=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Oe of We)if(!je||Oe.compareDocumentPosition(je)&Node.DOCUMENT_POSITION_FOLLOWING){const ut=ue(Oe);if(ut)return ut}}}return Y(P.value)}),L=we(()=>{var Q;return((Q=fe.value)==null?void 0:Q.ratio)||""}),j=we(()=>{const Q=l.value||"";if(Q==="NodeSuperBlock"||Q==="s"||Q==="sb")return!0;if(typeof document<"u"&&o.value){const be=document.querySelector(`.protyle-wysiwyg [data-node-id="${o.value}"]`);if(be!=null&&be.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),v=we(()=>{var Q;return((Q=P.value)==null?void 0:Q.pageIndex)||1}),U=we(()=>!!(r.value[nt]||r.value["slidev-note"]));function H(){if(!u.value)return!1;if(o.value===u.value||typeof document>"u")return!0;const Q=document.querySelector(`.protyle-wysiwyg [data-node-id="${u.value}"]`)||document.querySelector(`[data-node-id="${u.value}"]`);if(!Q)return!1;const be=Q.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(be==null?void 0:be.getAttribute("data-node-id"))===o.value}const $=we(()=>{var be;if(r.value[Ye]!==void 0)return r.value[Ye]||"";if(u.value&&H())return h.value||"";if(u.value)return"";const Q=o.value;if(Q&&((be=P.value)!=null&&be.blocks)){const Ee=P.value.blocks.find(je=>je.id===Q);if(Ee!=null&&Ee.clicks)return Ee.clicks}return""}),I=we(()=>{var be;if(r.value[qt])return r.value[qt];const Q=o.value;if(Q&&((be=P.value)!=null&&be.blocks)){const Ee=P.value.blocks.find(je=>je.id===Q);if(Ee!=null&&Ee.motion)return typeof Ee.motion=="string"?Ee.motion:JSON.stringify(Ee.motion)}return""}),C=we(()=>{var be;if(r.value[$e])return r.value[$e];const Q=o.value;if(Q&&((be=P.value)!=null&&be.blocks)){const Ee=P.value.blocks.find(je=>je.id===Q);if(Ee!=null&&Ee.slot)return Ee.slot}return""}),V=pe(""),q=pe(""),K=we(()=>r.value[Bi]==="true"),ee=we(()=>r.value[fs]==="true"),le=we(()=>r.value[Vi]==="true"),oe=we(()=>r.value[ps]!=="false"),he=we(()=>{var Q,be;return((be=(Q=b.value)==null?void 0:Q.config)==null?void 0:be.theme)||r.value[An]||"default"}),ie=we(()=>{var Q,be;return((be=(Q=b.value)==null?void 0:Q.config)==null?void 0:be.aspectRatio)||r.value[Bn]||"16/9"}),ne=we(()=>{var Q,be;return((be=(Q=b.value)==null?void 0:Q.config)==null?void 0:be.defaultTransition)||r.value[Mn]||"slide-left"}),Ce=we(()=>{var Q,be;return((be=(Q=b.value)==null?void 0:Q.config)==null?void 0:be.spacing)||r.value[po]||"normal"}),Be=we(()=>{var We,Oe;if((r.value[Ze]||r.value["slidev-role"])===cl||r.value[Ke]==="true")return"background";const be=r.value[ge]||r.value["slidev-layout"];if(be==="image-left"||be==="image-right")return be;const Ee=a.value||"",je=wi(Ee);if(je&&((Oe=(We=P.value)==null?void 0:We.frontmatter)!=null&&Oe.background)){const ut=P.value.frontmatter.background;if(ut===je||ut.endsWith(je)||je.endsWith(ut))return"background"}return""}),Ne=we(()=>!!(r.value[Ye]||r.value[qt]||r.value[$e]||r.value[Ni]||r.value[nt]||r.value["slidev-note"]||r.value[Ze]||r.value[ge]||r.value[Bi]||r.value[fs]||r.value[Vi]||r.value[ps])),{saveAttr:Re,savePageAttr:Le,applyPageLayoutAndRatio:Jt,applyCloverLayout:rt,resetSuperBlockWidth:Xe,saveDocAttr:Ht,onToggleVideoAutoplay:Fi,onToggleVideoLoop:Ws,onToggleVideoMuted:Us,onToggleVideoControls:Vn,onImageRoleChange:Si,onToggleNoteBlock:Hi,onAddNoteBlock:qa,onLocateNoteBlock:Za,onGenerateNotesWithAI:Ya,isBatchProcessing:Ja,onBatchAppendNotes:Xa,onBatchDeleteNotes:Qa,toggleElemClick:ec,onElemClickStepChange:tc,onElemMotionChange:ic,onElemSlotChange:nc,onElemShikiLinesChange:sc,onElemMaxHeightChange:oc,onSetTwoColsContrast:rc,onClearBlockAttrs:lc,onInsertDividerBefore:ac,onInsertDividerAfter:or,onDeleteCurrentBlock:cc,onExportHtml:dc,onExportPdf:uc}=Vk({activeBlockId:o,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:p,currentPageDividerLayout:g,parentContainerId:u,parentContainerClicks:h,latestDoc:b,targetSlide:P,currentSlideNoteBlockId:G,currentSlideLayout:W,isNoteBlock:U,elemClick:$,videoAutoplay:K,videoLoop:ee,videoMuted:le,videoControls:oe,pageBackground:F,pageImage:E,elemShikiLines:V,elemMaxHeight:q,saveStatus:y,plugin:i});async function fc(Q){if(Q==="clover"){if(!await rt())return}else Re(ge,Q)}function pc(Q){Le(kt,Q)}function hc(Q){Le(qi,Q)}function mc(Q){Le(Zi,Q)}function gc(Q){Le(Yi,Q)}function vc(Q){Le(Ji,Q)}function rr(Q){if(!Q)return;const be=Q.recommendedLayout||(Q.colCount&&Q.colCount>=2?"cols-header":"two-cols"),Ee=Q.ratio||(Q.colCount?Array(Q.colCount).fill(1).join(":"):"1:1");Jt(be,Ee)}function bc(Q){Le(kt,Q)}async function yc(){await Xe()}function kc(Q){Re(tt,Q)}function wc(Q){F.value=Q,Re(Ke,Q)}function xc(Q){E.value=Q,Re(Dt,Q)}function Sc(Q){Re(wn,Q==="inherit"?"":Q)}function _c(Q){Ht(An,Q)}function Cc(Q){Ht(Bn,Q)}function $c(Q){Ht(Mn,Q)}function Ic(Q){Ht(po,Q)}function lr(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function Tc(){i!=null&&i.openPresenterTab&&i.openPresenterTab()}function Ec(){i!=null&&i.executeCommand&&i.executeCommand("slidevAiSplit")}return t({setActiveBlock(Q){o.value=Q.id,l.value=Q.type,r.value={...Q.attrs},a.value=Q.content||Q.markdown||"",d.value=Q.topBlockId||Q.id,p.value=Q.pageDividerId||"",g.value=Q.pageDividerLayout||"",u.value=Q.parentContainerId||"",m.value=Q.parentContainerSlot||"",h.value=Q.parentContainerClicks||"",Q.rootId?c.value=Q.rootId:(Q.type==="doc"||Q.type==="NodeDocument")&&Q.id&&(c.value=Q.id),F.value=Q.attrs[Ke]||"",E.value=Q.attrs[Dt]||"",V.value=Q.attrs[Ni]||"",q.value=Q.attrs[Dn]||"",T.value=!!Q.isImage},updateDocument(Q){b.value=Q,c.value=Q.docId},openImportDialog(){n.value=!0},setCurrentDocId(Q){c.value=Q}}),(Q,be)=>(J(),te("div",Gk,[f("div",qk,[f("div",Zk,[(J(),te("svg",Yk,[...be[2]||(be[2]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),be[3]||(be[3]=f("span",null,"演示配置",-1))]),f("div",Jk,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:be[0]||(be[0]=Ee=>n.value=!0)},[re(de,{name:"import"}),be[4]||(be[4]=f("span",null,"导入",-1))]),f("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:lr},[re(de,{name:"split-preview"}),be[5]||(be[5]=f("span",null,"分屏预览",-1))])])]),f("div",Xk,[f("div",Qk,[f("span",{class:_e(["spm-target-tag",z.value])},ke(S.value),3),f("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":x.value||"点击复制 ID: "+(o.value||c.value),onClick:_},[re(de,{name:"copy"}),f("span",null,"#"+ke(N.value),1)],8,ew)]),y.value?(J(),te("span",tw,"● "+ke(y.value),1)):De("",!0)]),Z.value?(J(),te("div",{key:0,class:"spm-context-quote",title:a.value},ke(Z.value),9,iw)):De("",!0),f("div",nw,[B.value?(J(),Pt(u1,{key:0,"page-layout":k.value,"page-layout-ratio":ye(ae),"page-mask":ye(ce),"page-mask-ratio":ye(ve),"page-mask-style":ye(Te),"page-mask-initial":ye(xe),"detected-sb-ratio":L.value,"detected-sb-info":fe.value,"page-transition":A.value,"page-background":F.value,"page-spacing":D.value,"page-image":E.value,"page-notes":X.value,"page-index":v.value,"onUpdate:pageLayout":fc,"onUpdate:pageLayoutRatio":pc,"onUpdate:pageMask":hc,"onUpdate:pageMaskRatio":mc,"onUpdate:pageMaskStyle":gc,"onUpdate:pageMaskInitial":vc,onApplySuperBlockLayout:rr,onResetSuperblockRatio:yc,"onUpdate:pageTransition":kc,"onUpdate:pageBackground":wc,"onUpdate:pageSpacing":Sc,"onUpdate:pageImage":xc,onAddNoteBlock:ye(qa),onLocateNoteBlock:ye(Za),onGenerateNotes:ye(Ya),onBatchAppendNotes:ye(Xa),onBatchDeleteNotes:ye(Qa),"is-batch-processing":ye(Ja),onInsertDividerAfter:ye(or),onDeleteDivider:ye(cc)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):o.value&&!O.value?(J(),Pt(Zy,{key:1,"elem-click":$.value,"elem-motion":I.value,"elem-slot":C.value,"elem-shiki-lines":V.value,"elem-max-height":q.value,"is-code-block":M.value,"is-image":w.value,"is-video":R.value,"is-super-block":j.value,"detected-sb-info":fe.value,"video-autoplay":K.value,"video-loop":ee.value,"video-muted":le.value,"video-controls":oe.value,"has-block-attrs":Ne.value,"is-note":U.value,"image-role":Be.value,"current-slide-layout":W.value,"parent-elem-click":h.value,"parent-container-slot":m.value,"parent-container-id":u.value,onToggleNote:ye(Hi),onToggleElemClick:ye(ec),onToggleVideoAutoplay:ye(Fi),onToggleVideoLoop:ye(Ws),onToggleVideoMuted:ye(Us),onToggleVideoControls:ye(Vn),"onUpdate:imageRole":ye(Si),"onUpdate:elemClick":ye(tc),"onUpdate:elemMotion":ye(ic),"onUpdate:elemSlot":ye(nc),"onUpdate:elemShikiLines":ye(sc),"onUpdate:elemMaxHeight":ye(oc),onApplySuperBlockLayout:rr,onApplySuperBlockRatio:bc,onInsertDividerBefore:ye(ac),onInsertDividerAfter:ye(or),onSetTwoColsContrast:ye(rc),onClearBlockAttrs:ye(lc)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(J(),Pt(D0,{key:2,"doc-theme":he.value,"doc-aspect-ratio":ie.value,"doc-default-transition":ne.value,"doc-spacing":Ce.value,"onUpdate:docTheme":_c,"onUpdate:docAspectRatio":Cc,"onUpdate:docDefaultTransition":$c,"onUpdate:docSpacing":Ic,onOpenBottomPreview:lr,onOpenPresenter:Tc,onAiAutoSplit:Ec,onExportHtml:ye(dc),onExportPdf:ye(uc)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf"]))]),n.value?(J(),Pt(Nk,{key:1,onClose:be[1]||(be[1]=Ee=>n.value=!1),onSuccess:s})):De("",!0)]))}}),ow=2e3,rw=600;function lw(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function lo(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(el(e))return!0;const t=e.firstElementChild;return!!(t&&el(t))}function el(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function aw(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class cw{constructor(){Se(this,"consumers",new Map);Se(this,"seq",0);Se(this,"verifyTimer",null)}register(t,i,n){if(!i)return()=>{};const s=++this.seq,o=aw(),l={kind:t,element:i,visible:!1,measureOnDemand:!o,observer:null,onVisible:n};return o?(l.observer=new o(r=>{var d;const a=r[r.length-1];if(!a)return;const c=a.isIntersecting&&!l.visible;l.visible=a.isIntersecting,c&&((d=l.onVisible)==null||d.call(l))}),l.observer.observe(i)):l.visible=lo(i),this.consumers.set(s,l),()=>{var r;(r=l.observer)==null||r.disconnect(),this.consumers.delete(s),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const i of this.consumers.values())(t=i.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?lo(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!lw(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const i of this.consumers.values())if(!i.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var i;this.verifyTimer=null;for(const n of this.consumers.values())if(!n.visible&&lo(n.element)){n.visible=!0,(i=n.onVisible)==null||i.call(n);return}},ow))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const ls=new cw,pn=new js;function ja(e,t,i){const n=()=>{var o;try{(o=i==null?void 0:i.flushDirtyCompile)==null||o.call(i)}catch{}},s=ls.register(e,t,n);return n(),s}let vi=null,At=null,as=null;function dw(){return At}function uw(e,t){vi&&Wa(),vi=Jo(zg),vi.provide("plugin",t),vi.provide("sandboxBridge",pn);const i=vi.mount(e);return At=i,as=ja("preview",e,t),i}function Wa(e){as&&(as(),as=null),vi&&(vi.unmount(),vi=null,At=null)}function fw(){return At!==null}let bi=null,Li=null;function pw(e,t){return bi&&Ua(),bi=Jo(Zv),bi.provide("plugin",t),bi.provide("sandboxBridge",pn),Li=bi.mount(e),Li}function Ua(e){bi&&(bi.unmount(),bi=null,Li=null)}function hw(e){try{const t=new BroadcastChannel("siyuan-slidev-sync");t.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(e.slides||[])),config:JSON.parse(JSON.stringify(e.config||{}))}),t.close()}catch{}}let yi=null,Ct=null,cs=null;function mw(e,t){yi&&Va(),yi=Jo(sw),yi.provide("plugin",t),yi.provide("sandboxBridge",pn);const i=yi.mount(e);return Ct=i,cs=ja("dock",e,t),i}function Va(e){cs&&(cs(),cs=null),yi&&(yi.unmount(),yi=null,Ct=null)}function gw(e,t){Ct!=null&&Ct.updateDocument&&Ct.updateDocument(e),At!=null&&At.updateDocument?At.updateDocument(e,t):(pn.updateSlides(e.slides,e.config,e.fullMarkdown),hw(e)),Li!=null&&Li.updateDocument&&Li.updateDocument(e)}function Bo(e){At!=null&&At.navigateToBlock?At.navigateToBlock(e):pn.highlightElement(e)}function ds(e){Ct!=null&&Ct.setActiveBlock&&Ct.setActiveBlock(e)}function vw(){return Ct!=null&&Ct.openImportDialog?(Ct.openImportDialog(),!0):!1}function bw(e,t){const i=[];let s=0;for(let o=0;o<e.length;o++){const l=e[o];if($s(l)){s=0;continue}const r=l.markdown||l.content||"";if(!(o===0)){if(l.type==="h"&&(l.subType==="h1"||r.startsWith("# "))){i.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),s=0;continue}if(l.type==="h"&&(l.subType==="h2"||r.startsWith("## "))){i.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),s=0;continue}}if(s++,s>=6&&o<e.length-1){const c=e[o+1];$s(c)||(i.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),s=0)}}return i}const yw=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Ai,value:"true"},{key:ge,value:"cover"},{key:tt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Ai,value:"true"},{key:ge,value:"two-cols"},{key:tt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Ai,value:"true"},{key:ge,value:"fact"},{key:tt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Ai,value:"true"},{key:ge,value:"intro"},{key:tt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Ai,value:"true"},{key:ge,value:"quote"},{key:tt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Ye,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Ye,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:$e,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Ni,value:"1-3"}]}];class ao{getPresetTemplates(){return yw}buildScanSlidevBlocksSql(t="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${tt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = '${tt}' AND value = '${t}'`,l=await n(o);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await s(c,{[tt]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${t}'`,l=await n(o);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await s(c,{"custom-slidev-layout":i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${t.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function kw(e){e.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),e.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{vw()||me.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await He(e.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),me.showMessage("已为当前文档初始化 Slidev 演示属性"),e.compileCurrentDocument(e.currentDocId))}}),e.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const o=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(o==null?void 0:o.getAttribute("data-doc-id"))||""}if(!e.currentDocId){me.showMessage("请先打开一篇思源笔记文档");return}const t=await us(e.currentDocId).catch(()=>[]);if(!t||t.length===0){me.showMessage("当前文档无内容，无需断页");return}const i=t.map(o=>({id:o.id,type:o.type,subType:o.subType,content:o.content||"",markdown:o.markdown||""})),n=bw(i);if(n.length===0){me.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}me.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let s=0;for(const o of n)try{await Mi("markdown","---",void 0,o.blockId),await He(o.blockId,{"custom-slidev-layout":o.recommendedLayout}),s++}catch(l){console.warn("Failed to insert divider:",l)}me.showMessage(`已成功在 ${s} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,d,p;if(!e.currentDocId){const g=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(g==null?void 0:g.getAttribute("data-doc-id"))||""}if(!e.currentDocId){me.showMessage("请先打开一篇思源笔记文档");return}me.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await us(e.currentDocId).catch(()=>[]),i={startBlockId:e.currentDocId,blocks:t.map(g=>({id:g.id,type:g.type,content:g.content||"",rawMarkdown:g.markdown||""})),rawMarkdown:""},o=`> [!NOTE] 💡 演讲备注
${(await jk(i,ol)).split(/\r?\n/).map(g=>`> ${g}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await uo("markdown",o,e.currentDocId).catch(()=>null),r=((d=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:d.id)||((p=l==null?void 0:l[0])==null?void 0:p.id);r&&(await He(r,{"custom-slidev-note":"true"}),Pe.setBlockAttrOverride(r,{"custom-slidev-note":"true"}),Ri(r,e.app)),me.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new ao,i=t.buildTransitionStatsSql(),n=await sn(i).catch(()=>[]),s=t.formatTransitionSummary(n||[]);me.showMessage(s)}}),e.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new ao().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),me.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):me.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),e.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new ao().batchUpdateTransitions("fade","slide-left",n=>sn(n).catch(()=>[]),(n,s)=>He(n,s));me.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),e.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),e.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){me.showMessage("请先打开并放映一篇思源笔记文档");return}e.cliBridge.downloadSlidesMd(e.latestCompiledDoc,`slides-${e.currentDocId||"demo"}.md`)&&me.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),e.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{me.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await e.cliBridge.probeServer(1500)?me.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):me.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),e.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){me.showMessage("请先打开并放映一篇思源笔记文档");return}const t=await e.cliBridge.syncToWorkspaceFile(e.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",fo);t.success?me.showMessage(`已成功同步最新 slides.md 至工作空间：${t.path}`):me.showMessage(`同步失败：${t.error}`)}})}function Ka(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function Ga(e,t){var i,n,s;if(!t)return"";if(typeof document<"u"){const o=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),l=((o==null?void 0:o.innerText)||(o==null?void 0:o.textContent)||"").trim();if(l)return l}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const o=(i=e.latestCompiledDoc.slides)==null?void 0:i[0],l=(n=o==null?void 0:o.blocks)==null?void 0:n.find(r=>r.type==="h"||r.type==="NodeHeading");if(l!=null&&l.content)return l.content.trim()}try{const o=await sn(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(o)&&o.length>0&&((s=o[0])!=null&&s.content))return String(o[0].content).trim()}catch{}return""}async function ww(e,t,i){var c,d,p;const n=dw(),s=!!((c=n==null?void 0:n.isPinned)!=null&&c.value),o=String(((d=n==null?void 0:n.pinnedDocId)==null?void 0:d.value)||"");if(s&&o&&i&&i!==o)return;const l=i||(s&&o?o:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&l&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(l):await Ga(e,l));const a=Ka(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(a),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",a);return}if(typeof document<"u"){const g=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const u of g){const m=u.querySelector(".item__text"),h=((p=m==null?void 0:m.textContent)==null?void 0:p.trim())||"";if(h.includes("Slidev 演示预览")||h.startsWith("即现")){m&&(m.textContent=a),u.setAttribute("title",a);break}}}}class xw{constructor(t=400){Se(this,"entries",new Map);this.ttlMs=t}get(t,i=Date.now()){if(!t)return;const n=this.entries.get(t);if(n){if(i-n.at>this.ttlMs){this.entries.delete(t);return}return n.attrs}}set(t,i,n=Date.now()){!t||!i||this.entries.set(t,{attrs:i,at:n})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function Sw(e){const t=new Map;if(!(e!=null&&e.slides))return t;const i=n=>{for(const s of n||[])s!=null&&s.id&&s.ial&&t.set(s.id,s.ial)};for(const n of e.slides)i(n.blocks),i(n.noteBlocks);return t}class _w{constructor(t=150){Se(this,"lastBlockId","");Se(this,"lastAt",0);this.windowMs=t}shouldSkip(t,i=Date.now()){return t&&t===this.lastBlockId&&i-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=i,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class Cw{constructor(){Se(this,"attrCache",new xw);Se(this,"compiledIalIndex",{doc:null,map:new Map})}async resolveBlockAttrs(t,i){if(!t)return{};const n=Pe.getBlockAttrOverride(t),s=this.getCompiledIal(i,t);if(n||s)return{...s||{},...n||{}};const o=this.attrCache.get(t);if(o)return o;const l=await Mo(t).catch(()=>({}))||{};return this.attrCache.set(t,l),l}getCompiledIal(t,i){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:Sw(t)}),this.compiledIalIndex.map.get(i)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=t==null?void 0:t.getAttribute("data-node-id");if(i)return i;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=document.querySelector("[data-doc-id]"),l=o==null?void 0:o.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(t,i=""){const n=t.closest(".protyle-title"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=t.closest(".protyle"),l=o==null?void 0:o.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=t.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||i}async switchToDocGlobalInspector(t,i){var o;if(!t)return;let n=i||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((o=l==null?void 0:l.innerText)==null?void 0:o.trim())||""}const s=await this.resolveBlockAttrs(t,null);ds({id:t,rootId:t,type:"doc",content:n,attrs:s,isDivider:!1,isCode:!1}),Bo(t)}handleBlockClickedFromSlide(t,i,n,s){var a;if(!t)return!1;const o=Ri(t,i),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`),r=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,t,r,n,s);else{let c="",d="";if(s!=null&&s.slides){const p=s.slides.find(g=>{var u,m,h;return g.startBlockId===t||((u=g.blocks)==null?void 0:u.some(b=>b.id===t))||((m=g.allBlockIds)==null?void 0:m.includes(t))||((h=g.noteBlocks)==null?void 0:h.some(b=>b.id===t))});p!=null&&p.startBlockId&&(c=p.startBlockId),(a=p==null?void 0:p.frontmatter)!=null&&a.layout&&(d=p.frontmatter.layout)}this.resolveBlockAttrs(t,s).then(async p=>{if(c&&!d){const g=Pe.getBlockAttrOverride(c);if(g!=null&&g[ge]||g!=null&&g["custom-slidev-layout"])d=g[ge]||g["custom-slidev-layout"]||"";else{const u=await this.resolveBlockAttrs(c,s);d=u[ge]||u["custom-slidev-layout"]||"",u&&Object.keys(u).length>0&&Pe.setBlockAttrOverride(c,u)}}ds({id:t,rootId:n,type:r||"NodeParagraph",attrs:p||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return o}async syncInspectorBlock(t,i,n,s,o){var A,F,E,D,P,X,G,W;let l=t,r=i,a=n;const c=t.closest('[data-type="NodeCallout"]');if(c&&c!==t){const se=c.getAttribute("data-node-id");if(se){const ae=await this.resolveBlockAttrs(se,o),ce=Pe.getBlockAttrOverride(se)||{},ve={...ae,...ce};(ve[nt]||ve["slidev-note"])&&(l=c,r=se,a="NodeCallout")}}const d=l.closest(".protyle-wysiwyg > [data-node-id]")||l,p=(d==null?void 0:d.getAttribute("data-node-id"))||r,g=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(d==null?void 0:d.getAttribute("data-type"))==="NodeThematicBreak"||(d==null?void 0:d.getAttribute("data-type"))==="tb"||!!((A=d==null?void 0:d.classList)!=null&&A.contains("hr")),u=a==="NodeCodeBlock",m=((F=l.innerText)==null?void 0:F.trim())||"",h=await this.resolveBlockAttrs(r,o),b=Pe.getBlockAttrOverride(r)||{},y={...h,...b};let x="",_="";if(g)x=r,_=y[ge]||y["custom-slidev-layout"]||"";else{let se=d.previousElementSibling;for(;se;){const ae=se.getAttribute("data-type");if(ae==="NodeThematicBreak"||ae==="tb"||(E=se.classList)!=null&&E.contains("hr")){x=se.getAttribute("data-node-id")||"";break}se=se.previousElementSibling}}if(o!=null&&o.slides){const se=[r,p];let ae=l.parentElement;for(;ae&&!ae.classList.contains("protyle-wysiwyg");){const ve=ae.getAttribute("data-node-id");ve&&!se.includes(ve)&&se.push(ve),ae=ae.parentElement}const ce=o.slides.find(ve=>{var Te,xe,ue;return se.includes(ve.startBlockId)||((Te=ve.blocks)==null?void 0:Te.some(Y=>se.includes(Y.id)))||((xe=ve.allBlockIds)==null?void 0:xe.some(Y=>se.includes(Y)))||((ue=ve.noteBlocks)==null?void 0:ue.some(Y=>se.includes(Y.id)))});ce&&(!x&&ce.startBlockId&&(x=ce.startBlockId),!_&&((D=ce.frontmatter)!=null&&D.layout)&&(_=ce.frontmatter.layout))}if(x){const se=Pe.getBlockAttrOverride(x);if(se&&(ge in se||"custom-slidev-layout"in se)&&(_=se[ge]||se["custom-slidev-layout"]||""),!_&&(o!=null&&o.slides)){const ae=o.slides.find(ce=>ce.startBlockId===x);(P=ae==null?void 0:ae.frontmatter)!=null&&P.layout&&(_=ae.frontmatter.layout)}if(!_){const ae=await this.resolveBlockAttrs(x,o);_=ae[ge]||ae["custom-slidev-layout"]||"",ae&&Object.keys(ae).length>0&&Pe.setBlockAttrOverride(x,ae)}et(x,{[ge]:_||""})}else if(s){const se=Pe.getBlockAttrOverride(s);se&&(ge in se||"custom-slidev-layout"in se)?_=se[ge]||se["custom-slidev-layout"]||"":!_&&((W=(G=(X=o==null?void 0:o.slides)==null?void 0:X[0])==null?void 0:G.frontmatter)!=null&&W.layout)&&(_=o.slides[0].frontmatter.layout)}const B=l.getAttribute(ge)||l.getAttribute("custom-slidev-layout"),M=y[ge]||y["custom-slidev-layout"]||"";B&&B!==M&&et(r,{[ge]:M});const T=l.getAttribute(Ze)||l.getAttribute("custom-slidev-role"),w=y[Ze]||y["custom-slidev-role"]||"";T&&T!==w&&et(r,{[Ze]:w});let R="",O="",N="";const Z=l.closest('[data-type="NodeListItem"]');if(Z&&Z!==l){const se=Z.getAttribute("data-node-id");if(se){R=se;const ae=await this.resolveBlockAttrs(se,o),ce=Pe.getBlockAttrOverride(se)||{},ve={...ae,...ce};O=ve[$e]||"",N=ve[Ye]||"";const Te=ve[ge]||ve["custom-slidev-layout"]||"",xe=Z.getAttribute(ge)||Z.getAttribute("custom-slidev-layout");xe&&xe!==Te&&et(se,{[ge]:Te});const ue=ve[Ze]||ve["custom-slidev-role"]||"",Y=Z.getAttribute(Ze)||Z.getAttribute("custom-slidev-role");Y&&Y!==ue&&et(se,{[Ze]:ue})}}const S=!!l.querySelector("img, span[data-type='img']"),z=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),k=S&&z.length<=50;ds({id:r,rootId:s,type:a,content:m,attrs:y,isDivider:g,isCode:u,isImage:k,topBlockId:p,pageDividerId:x,pageDividerLayout:_,parentContainerId:R,parentContainerSlot:O,parentContainerClicks:N})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const i of t.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const n of i.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const s=n.data.old||{},o=n.data.new||{},l={};for(const r of Object.keys(s))r in o||(l[r]="");for(const[r,a]of Object.entries(o))l[r]=String(a??"");et(n.id,l),Pe.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidevAttrs(t){var s,o,l;if(typeof document>"u"||!t)return;const i=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const a=i.get(r.startBlockId)||{};(s=r.frontmatter)!=null&&s.layout&&(a[ge]=r.frontmatter.layout),i.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=i.get(a.id)||{};(o=a.ial)!=null&&o[ge]&&(c[ge]=a.ial[ge]),(l=a.ial)!=null&&l[Ze]&&(c[Ze]=a.ial[Ze]),Object.keys(c).length>0&&i.set(a.id,c)}}}const n=Pe.getAllAttrOverrides();for(const[r,a]of n.entries()){const c=i.get(r)||{};a[ge]!==void 0&&(c[ge]=a[ge]),a[Ze]!==void 0&&(c[Ze]=a[Ze]),i.set(r,c)}Sh(i)}}const Ti=new Cw;class $w{constructor(){Se(this,"inFlightDocId",null);Se(this,"pendingDocId",null);Se(this,"generation",0)}get isRunning(){return this.inFlightDocId!==null}get runningDocId(){return this.inFlightDocId}get pending(){return this.pendingDocId}tryBegin(t){return this.inFlightDocId!==null?(this.pendingDocId=t,null):(this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finish(){this.inFlightDocId=null;const t=this.pendingDocId;return this.pendingDocId=null,t}reset(){this.inFlightDocId=null,this.pendingDocId=null,this.generation=0}}const Iw=150,Tw=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,Ew="slidev-dock",co="slidev-preview-tab",tl="slidev-presenter-tab",il=wf;class Aw extends me.Plugin{constructor(){super(...arguments);Se(this,"isMobile",!1);Se(this,"currentDocId","");Se(this,"previewTab",null);Se(this,"latestCompiledDoc",null);Se(this,"cliBridge",new er);Se(this,"debounceTimer",null);Se(this,"activeCursorBlockId","");Se(this,"compileScheduler",new $w);Se(this,"dirtyDocId",null);Se(this,"inspectorSyncThrottle",new _w);Se(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));Se(this,"onWsMainBound",this.onWsMain.bind(this));Se(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));Se(this,"onEditorClickBound",this.onEditorClick.bind(this));Se(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));Se(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));Se(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const i=me.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(Tw),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),kw(this);const n=this;if(this.addTab({type:co,init(s){var r;const o=this||s;n.previewTab=(o==null?void 0:o.tab)||null,uw(o.element,n);const l=(r=o==null?void 0:o.data)==null?void 0:r.docId;l&&!n.getActiveDocumentId()&&n.compileCurrentDocument(l,{reason:"explicit"}),n.updatePreviewTabHeader()},destroy(){n.previewTab===(this==null?void 0:this.tab)&&(n.previewTab=null),Wa(this.element)}}),this.addTab({type:tl,init(s){pw((this||s).element,n)},destroy(){Ua(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:Ew,init(){mw(this.element,n)},destroy(){Va(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(s,o)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${s}`,{detail:o}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const s=()=>{const o=this.getActiveDocumentId();o&&(o!==this.currentDocId&&(this.currentDocId=o,this.updatePreviewTabHeader("",o)),this.latestCompiledDoc||this.markCompileDirty(o))};setTimeout(s,300),setTimeout(s,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(il),n=xf(i);return Di(n),n}catch{return Di(an),an}}async saveGlobalSettings(i){const n=Hs(),s=Di({...n,...i||{}});try{await this.saveData(il,s)}catch(l){console.error("保存 Slidev 全局配置失败",l)}const o=this.currentDocId||this.getActiveDocumentId();return o&&this.markCompileDirty(o),s}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,ls.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),pn.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const i=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",n=this.buildPreviewTabTitle(i);await me.openTab({app:this.app,custom:{id:this.name+co,title:n,icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(i,this.currentDocId)}async openPresenterTab(){fw()||await this.openBottomPreviewTab(),await me.openTab({app:this.app,custom:{id:this.name+tl,title:"演讲者控制台",icon:"iconSlidev",data:{}},position:"right"})}async openStandalonePreviewWindow(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),this.currentDocId&&!this.latestCompiledDoc&&await this.compileCurrentDocument(this.currentDocId,{reason:"explicit"});const i=me.getFrontend();if(i==="browser-desktop"||i==="browser-mobile"){typeof window<"u"&&typeof window.open=="function"&&window.open("/plugins/siyuan-slidev/slidev-client/index.html","SlidevBigScreenWindow","width=1280,height=760,menubar=no,toolbar=no,location=no,status=no");return}let n=this.previewTab;if(!n){const s=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",o=this.buildPreviewTabTitle(s),l=await me.openTab({app:this.app,custom:{id:this.name+co,title:o,icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"});n=this.previewTab||l}n&&(this.currentDocId&&n.model&&(n.model.data={...n.model.data||{},docId:this.currentDocId}),me.openWindow({tab:n,width:1280,height:760}))}async onSwitchProtyle(i){var l,r,a,c,d;const n=(l=i.detail)==null?void 0:l.protyle,s=(r=n==null?void 0:n.block)==null?void 0:r.rootID,o=((d=(c=(a=n==null?void 0:n.title)==null?void 0:a.editElement)==null?void 0:c.textContent)==null?void 0:d.trim())||"";if(s&&s!==this.currentDocId){this.currentDocId=s,this.activeCursorBlockId=s;const p=await Mo(s).catch(()=>({}));ds({id:s,rootId:s,type:"doc",attrs:p}),this.markCompileDirty(s),this.updatePreviewTabHeader(o,s)}}onClickEditorContent(i){var o,l;const n=i==null?void 0:i.detail;if(!n)return;const s=(l=(o=n.protyle)==null?void 0:o.block)==null?void 0:l.rootID;s&&(!this.currentDocId||this.currentDocId!==s)&&(this.currentDocId=s),n.event&&this.onEditorClick(n.event)}buildPreviewTabTitle(i){return Ka(i)}async fetchDocumentTitle(i){return Ga(this,i)}async updatePreviewTabHeader(i,n){return ww(this,i,n)}getActiveDocumentId(){return Ti.getActiveDocumentId()}resolveDocIdFromElement(i){return Ti.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,n){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await Ti.switchToDocGlobalInspector(i,n))}onWsMain(i){const n=i.detail;n&&n.cmd==="transactions"&&(Ti.patchThematicBreakTransactions(n),this.markCompileDirty())}markCompileDirty(i){const n=i||this.currentDocId||this.getActiveDocumentId();n&&(this.currentDocId||(this.currentDocId=n),this.dirtyDocId=n,this.scheduleDirtyCompile())}scheduleDirtyCompile(i=Iw){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const n=ls.getVisibility();if(n==="none")return;const s=n==="visible"?i:Math.max(i,rw);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const o=this.dirtyDocId;this.dirtyDocId=null,o&&this.compileCurrentDocument(o,{reason:"auto"})},s)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(i,n){return i?(this.activeCursorBlockId=i,Ti.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(i){const n=(i==null?void 0:i.detail)||i;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(i){const n=i.target;if(!n)return;const s=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(s||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const p=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=p==null?void 0:p.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const a=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Bo(a)),this.syncInspectorBlock(r,a,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const n=i.anchorNode;if(!n)return;const s=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!s)return;const o=s.closest(".protyle-title");if(!!(o||s.closest(".protyle-content")&&!s.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(s);if(d&&this.activeCursorBlockId!==d){const p=o||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=p==null?void 0:p.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!s.closest(".protyle-wysiwyg"))return;const r=s.closest("[data-node-id]"),a=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";r&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(s)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Bo(a)),this.syncInspectorBlock(r,a,c))}async syncInspectorBlock(i,n,s){this.inspectorSyncThrottle.shouldSkip(n)||await Ti.syncInspectorBlock(i,n,s,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i,n){const s=(n==null?void 0:n.reason)??"explicit";let o=i||this.currentDocId;if(!o){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,o=r;else return}if(s==="auto"&&ls.getVisibility()==="none"){this.dirtyDocId=o;return}const l=this.compileScheduler.tryBegin(o);if(l!==null){this.dirtyDocId===o&&(this.dirtyDocId=null);try{const r=await Pe.compile(o),a=!!this.currentDocId&&o!==this.currentDocId;!this.compileScheduler.isStale(l)&&!a&&(this.currentDocId||(this.currentDocId=o),this.latestCompiledDoc=r,gw(r,o),this.updatePreviewTabHeader("",o),this.purgeStaleDomSlidevAttrs(r))}catch(r){console.error("[SiYuanSlidev] Failed to compile document:",r)}finally{const r=this.compileScheduler.finish();r&&this.markCompileDirty(r)}}}purgeStaleDomSlidevAttrs(i){Ti.purgeStaleDomSlidevAttrs(i)}}module.exports=Aw;
