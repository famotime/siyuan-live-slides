"use strict";var ia=Object.create;var vs=Object.defineProperty;var na=Object.getOwnPropertyDescriptor;var sa=Object.getOwnPropertyNames;var oa=Object.getPrototypeOf,ra=Object.prototype.hasOwnProperty;var la=(t,i,e)=>i in t?vs(t,i,{enumerable:!0,configurable:!0,writable:!0,value:e}):t[i]=e;var aa=(t,i,e,n)=>{if(i&&typeof i=="object"||typeof i=="function")for(let s of sa(i))!ra.call(t,s)&&s!==e&&vs(t,s,{get:()=>i[s],enumerable:!(n=na(i,s))||n.enumerable});return t};var In=(t,i,e)=>(e=t!=null?ia(oa(t)):{},aa(i||!t||!t.__esModule?vs(e,"default",{value:t,enumerable:!0}):e,t));var vt=(t,i,e)=>la(t,typeof i!="symbol"?i+"":i,e);const ht=require("siyuan");async function ve(t,i){const e=await ht.fetchSyncPost(t,i);return e.code===0?e.data:null}async function ca(){return ve("/api/notebook/lsNotebooks","")}async function da(t,i,e){return ve("/api/filetree/createDocWithMd",{notebook:t,path:i,markdown:e})}async function ua(t,i){const e=new FormData;e.append("assetsDirPath",t);for(const s of i)e.append("file[]",s);return ve("/api/asset/upload",e)}async function tn(t,i,e,n,s){return ve("/api/block/insertBlock",{dataType:t,data:i,nextID:e,previousID:n,parentID:s})}async function wr(t,i,e){return ve("/api/block/appendBlock",{dataType:t,data:i,parentID:e})}async function Do(t,i,e){return ve("/api/block/updateBlock",{dataType:t,data:i,id:e})}async function fa(t){return ve("/api/block/deleteBlock",{id:t})}async function pa(t){return ve("/api/block/getBlockKramdown",{id:t})}async function Vn(t){return ve("/api/block/getChildBlocks",{id:t})}async function zt(t,i){return ve("/api/attr/setBlockAttrs",{id:t,attrs:i})}async function Ge(t){return ve("/api/attr/getBlockAttrs",{id:t})}async function pn(t){return ve("/api/query/sql",{stmt:t})}async function Os(t,i,e){const n=new FormData;return n.append("path",t),n.append("isDir",i.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",e),ve("/api/file/putFile",n)}async function kr(t){const i="/api/ai/chatGPT";try{const e=await ve(i,{msg:t});return typeof e=="string"&&e.trim().length>0?e.trim():e&&typeof e.content=="string"&&e.content.trim().length>0?e.content.trim():null}catch{return null}}const sn="custom-slidev-theme",on="custom-slidev-aspect-ratio",xr="custom-slidev-highlighter",rn="custom-slidev-default-transition",_r="custom-slidev-color-schema",ki="custom-slidev-slide",ut="custom-slidev-layout",Xt="custom-slidev-transition",Ut="custom-slidev-background",Ae="custom-slidev-image",Li="custom-slidev-notes",Ri="custom-slidev-class",Se="custom-slidev-click",He="custom-slidev-motion",_i="custom-slidev-shiki-lines",Tt="custom-slidev-slot",ie="custom-slidev-note",qt="custom-slidev-role",ln="custom-slidev-max-height",An="custom-slidev-autoplay",Tn="custom-slidev-loop",En="custom-slidev-muted",Mn="custom-slidev-controls",Sr="background",Ps="image-left",Ls="image-right",Di={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto"};function ha(t){var i,e,n,s,r;return t?{theme:((i=t[sn])==null?void 0:i.trim())||Di.theme,aspectRatio:((e=t[on])==null?void 0:e.trim())||Di.aspectRatio,highlighter:((n=t[xr])==null?void 0:n.trim())||Di.highlighter,defaultTransition:((s=t[rn])==null?void 0:s.trim())||Di.defaultTransition,colorSchema:((r=t[_r])==null?void 0:r.trim())||Di.colorSchema}:{...Di}}function Kn(t){var e,n,s,r,l;const i=(e=t.ial)==null?void 0:e[ki];return!!(i&&(i==="true"||i==="page"||i==="cover"||i==="end")||t.type==="tb"||t.type==="thematic-break"||t.type==="NodeThematicBreak"||((n=t.markdown)==null?void 0:n.trim())==="---"||((s=t.markdown)==null?void 0:s.trim())==="***"||t.type==="b"&&(((r=t.markdown)==null?void 0:r.trim())==="---"||((l=t.content)==null?void 0:l.trim())==="---"))}function Oo(t){const i={};let e="";if(!t)return{frontmatter:i,notes:e};t[ut]&&(i.layout=t[ut].trim()),t[Xt]&&(i.transition=t[Xt].trim()),t[Ut]&&(i.background=t[Ut].trim()),t[Ae]&&(i.image=t[Ae].trim()),t[Ri]&&(i.class=t[Ri].trim()),t[Li]&&(e=t[Li].trim());for(const[n,s]of Object.entries(t))if(n.startsWith("custom-slidev-")&&![ut,Xt,Ut,Ae,Ri,Li,ki].includes(n)){const r=n.replace(/^custom-slidev-/,"");try{i[r]=JSON.parse(s)}catch{i[r]=s}}return{frontmatter:i,notes:e}}function ma(t){const i={};if(!t)return i;const e=t[ie]??t["slidev-note"];e!=null&&e!==""&&e!=="false"&&e!=="0"&&(i.isNote=!0);const n=t[qt]??t["slidev-role"],s=t[Ut]??t["slidev-background"];(n===Sr||s==="true"||s==="1")&&(i.isBackground=!0);const r=t[ut]??t["slidev-layout"];r===Ps||r===Ls?i.imageLayout=r:(n===Ps||n===Ls)&&(i.imageLayout=n);const l=t[Se]??t["custom-slidev-clicks"]??t["slidev-click"]??t["slidev-clicks"];if(l!=null&&(i.clicks=l.trim()),t[He])try{const o=JSON.parse(t[He]);typeof o=="object"&&o!==null?i.motion={preset:o.preset||o.type||"fade-in",...o}:i.motion={preset:String(o).trim()}}catch{i.motion={preset:t[He].trim()}}return t[_i]&&(i.shikiLines=t[_i].trim()),t[ln]&&(i.maxHeight=t[ln].trim()),t[Tt]&&(i.slot=t[Tt].trim()),i}function ga(t,i){const e=[];let s=0;for(let r=0;r<t.length;r++){const l=t[r];if(Kn(l)){s=0;continue}const o=l.markdown||l.content||"";if(!(r===0)){if(l.type==="h"&&(l.subType==="h1"||o.startsWith("# "))){e.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),s=0;continue}if(l.type==="h"&&(l.subType==="h2"||o.startsWith("## "))){e.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),s=0;continue}}if(s++,s>=6&&r<t.length-1){const c=t[r+1];Kn(c)||(e.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),s=0)}}return e}function Po(t,i){const e=(t.blocks||[]).filter(l=>{const o=(l.content||l.rawMarkdown||"").trim();return o&&o!=="---"});if(e.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],s=[];for(const l of e){const o=(l.content||l.rawMarkdown||"").trim();o&&(l.type==="h"||o.startsWith("#")?n.push(o.replace(/^#+\s*/,"")):s.push(o.slice(0,50)))}const r=[];return n.length>0&&r.push(`【核心重点】：${n.join("、")}`),s.length>0&&(r.push("【口播要点】："),s.slice(0,3).forEach((l,o)=>{r.push(`${o+1}. 讲解 ${l}`)})),r.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),r.join(`
`)}async function Cr(t,i){const e=t.blocks&&t.blocks.length>0?t.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(t.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(i&&e){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${e}`;try{const s=await i(n);if(s&&s.trim())return{notes:s.trim(),isAiGenerated:!0}}catch(s){return{notes:Po(t),isAiGenerated:!1,error:(s==null?void 0:s.message)||"AI 调用异常"}}}return{notes:Po(t),isAiGenerated:!1}}async function va(t,i){return(await Cr(t,i)).notes}const $r=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function ba(t){const i=[];if(!t)return i;const e=new RegExp($r.source,"g");let n;for(;(n=e.exec(t))!==null;){const s=n[2]??n[3]??n[4];i.push({fullMatch:n[0],blockId:n[1],anchorText:s?s.trim():void 0})}return i}function ya(t,i){if(!t)return"";const e=new RegExp($r.source,"g");return t.replace(e,(n,s,r,l,o)=>{const a=(r??l??o??"").trim();if(i&&i[s]){const d=i[s].trim();return`<div class="slidev-block-ref" data-ref-id="${s}">${d}</div>`}const c=a||`Ref(${s.slice(0,8)})`;return`<a href="siyuan://blocks/${s}" data-ref-id="${s}" class="slidev-ref-tag">🔗 ${c}</a>`})}function wa(t){return t.markdown&&t.markdown.trim()?t.markdown.trim():t.content&&t.content.trim()?t.content.trim():""}function ka(t){const i={};if(!t)return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(e))!==null;){const r=s[1],l=s[2]??s[3]??s[4]??"";i[r]=l}return i}function xa(t){if(!t)return!1;const i=t.trim();return i.startsWith("assets/")||i.startsWith("./assets/")||i.startsWith("/assets/")}function _a(t){const i=t.trim();return i.startsWith("./assets/")?i.slice(2):i.startsWith("/assets/")?i.slice(1):i}function _e(t,i){if(!xa(t))return t;const e=_a(t);return i!=null&&i.base64Map&&i.base64Map[e]?i.base64Map[e]:i!=null&&i.baseUrl?`${i.baseUrl.replace(/\/+$/,"")}/${e}`:`/${e}`}function Sa(t,i){if(!t)return"";let e=t;return e=e.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,s,r)=>{const l=_e(r,i);return`![${s}](${l})`}),e=e.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,s,r,l)=>{const o=_e(r,i);return`${s}${o}${l}`}),e=e.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,s,r,l)=>{const o=_e(r,i);return`${s}${o}${l}`}),e}function fi(t,i){const e=(t||i||"").trim();if(!e)return null;const n=e.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const s=e.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(s)return s[1].trim();const r=e.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(r)?r:null}function ce(t){if(!t)return!1;const i=(t.type||"").toLowerCase();return i==="s"||i==="sb"||i==="nodesuperblock"}function Ei(t){if(!ce(t))return!1;const i=(t.subType||"").toLowerCase();if(i==="col"||i==="h"||i==="horizontal")return!0;if(i==="row"||i==="v"||i==="vertical")return!1;if(t.ial){const n=(t.ial["data-sb-layout"]||t.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(t.children&&t.children.length>0){for(const n of t.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const s=(n.content||n.markdown||"").trim().toLowerCase();if(s==="col"||s==="h")return!0;if(s==="row"||s==="v")return!1}}const e=(t.markdown||t.content||"").trim();return/^\{\{\{col\b/i.test(e)?!0:!/^\{\{\{row\b/i.test(e)}function Wi(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="i"||i==="nodelistitem"||i==="l"||i==="nodelist")return!0;const e=(t.markdown||t.rawMarkdown||t.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(e)}function Rs(t){return!t||Wi(t)||ce(t)||!fi(t.markdown,t.content)?!1:(t.markdown||t.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function pi(t){if(!t||!ce(t)||!Ei(t))return null;const i=(t.children||[]).filter(s=>{const r=s.type||"";if(r==="NodeSuperBlockOpenMarker"||r==="NodeSuperBlockLayoutMarker"||r==="NodeSuperBlockCloseMarker"||r==="open-marker"||r==="layout-marker"||r==="close-marker")return!1;const l=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(l)||l==="}}}")});if(i.length<2)return null;const e=Rs(i[0]),n=Rs(i[i.length-1]);if(e&&!n){const s=fi(i[0].markdown,i[0].content);if(s)return{imageNode:i[0],imageUrl:s,layout:Ps,contentNodes:i.slice(1)}}if(!e&&n){const s=fi(i[i.length-1].markdown,i[i.length-1].content);if(s)return{imageNode:i[i.length-1],imageUrl:s,layout:Ls,contentNodes:i.slice(0,i.length-1)}}return null}function Ca(t,i){const e=[];function n(s){for(const r of s){const l=pi(r);if(l){const{imageNode:o,layout:a}=l;o.ial||(o.ial={});const c=o.ial[ut];if(c!==a){const d={blockId:o.id,layout:a,previousLayout:c};o.ial[ut]=a,e.push(d),i&&i(d)}}r.children&&r.children.length>0&&n(r.children)}}return n(t),e}function Xs(t){return(t.children||[]).filter(i=>{const e=i.type||"";if(e==="NodeSuperBlockOpenMarker"||e==="NodeSuperBlockLayoutMarker"||e==="NodeSuperBlockCloseMarker"||e==="open-marker"||e==="layout-marker"||e==="close-marker")return!1;const n=(i.markdown||i.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function $a(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="h"||i==="nodeheading"||/^h[1-6]$/i.test(t.subType||""))return!0;const e=(t.markdown||t.content||"").trim();return!!/^#{1,6}\s+/.test(e)}function zs(t){if(!t)return"";const i=t.split(/\r?\n/);if(i.length===0)return"";const e=i[0],n=e.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return t;const s=n[1].length,r=n[2].trim(),l=e.length-n[2].length;if(i.length===1)return r;const o=[r];for(let a=1;a<i.length;a++){const c=i[a];if(!c.trim()){o.push("");continue}const d=c.match(/^(\s*)/),h=d?d[1].length:0;h>=l?o.push(c.slice(l)):h>s?o.push(c.slice(h)):o.push(c)}return o.join(`
`)}function xi(t){if(!t)return[];if(ce(t)&&Ei(t)&&!pi(t)){const n=Xs(t),s=[];for(const r of n)s.push(...xi(r));return s}const i=(t.type||"").toLowerCase();if(i==="l"||i==="nodelist"||i==="list"){if(t.children&&t.children.length>0){const l=t.children.filter(Wi);if(l.length>0)return l}const s=(t.markdown||t.content||"").trim().split(/\r?\n/),r=[];for(let l=0;l<s.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(s[l])&&r.push(l);if(r.length>=2){const l=[];for(let o=0;o<r.length;o++){const a=r[o],c=o+1<r.length?r[o+1]:s.length,d=s.slice(a,c).join(`
`);l.push({id:`${t.id}-item-${o+1}`,type:"i",markdown:d,content:d,ial:{...t.ial||{}}})}return l}}return Wi(t)?[t]:[]}function Ir(t){var n;if(!t||!ce(t)||!Ei(t)||pi(t))return null;const i=Xs(t);if(i.length===0)return null;if(i.length===1&&ce(i[0])&&Ei(i[0])){const s=Ir(i[0]);return s?{items:s.items,nestedSuperBlocks:[i[0],...s.nestedSuperBlocks]}:null}const e=[];for(const s of i)if(ce(s)){e.push(s);const r=((n=s.children)==null?void 0:n.filter(ce))||[];e.push(...r)}if(i.length===3){const s=xi(i[0]),r=xi(i[1]),l=xi(i[2]);if(s.length===1&&r.length===1&&l.length===1)return{items:[s[0],r[0],l[0]],nestedSuperBlocks:e}}if(i.length===2){const s=xi(i[0]),r=xi(i[1]);if(s.length===2&&r.length===1)return{items:[s[0],s[1],r[0]],nestedSuperBlocks:e};if(s.length===1&&r.length===2)return{items:[s[0],r[0],r[1]],nestedSuperBlocks:e};if(s.length===1&&r.length===1)return{items:[s[0],r[0]],nestedSuperBlocks:e}}return null}function Ia(t){if(!t||!ce(t)||!Ei(t)||pi(t))return null;const i=Ir(t);if(!i)return null;const{items:e,nestedSuperBlocks:n}=i;return e.length!==2&&e.length!==3?null:e.length===2?{superBlockNode:t,nestedSuperBlocks:n,count:2,layout:"two-cols-header",items:e,slots:["left","right"]}:{superBlockNode:t,nestedSuperBlocks:n,count:3,layout:"three-cols-header",items:e,slots:["col-1","col-2","col-3"]}}function Aa(t){if(!t||!ce(t)||!Ei(t)||pi(t))return null;const i=Xs(t);if(i.length===0)return null;const e=[];for(const n of i){const s=xi(n);if(s.length===0)return null;e.push(...s)}return e}function Ta(t){if(!t||!ce(t)||!Ei(t)||pi(t))return null;const i=Aa(t);return!i||i.length===0||i.length===2||i.length===3?null:{superBlockNode:t,items:i}}function Ea(t,i,e){var d,h,p,f,w;const n=[],s=[],r=(e==null?void 0:e.tracked)||[],l=[];let o={pageTargetId:t,blocks:[]};l.push(o);for(let m=0;m<i.length;m++){const k=i[m];if(Kn(k)){if(l.length===1&&o.blocks.length===0){o.pageTargetId=k.id,o.blocks.push(k);continue}o={pageTargetId:k.id,blocks:[k]},l.push(o)}else o.blocks.push(k)}function a(m){const k=[];for(const v of m)ce(v)&&k.push(v),v.children&&v.children.length>0&&k.push(...a(v.children));return k}function c(m,k,v){const b={blockId:m,attrs:k,previousAttrs:v};n.push(b),e!=null&&e.onTagChange&&e.onTagChange(b)}for(const m of l){const k=m.pageTargetId,v=i.find(S=>S.id===k),b=r.find(S=>S.pageTargetId===k);if(m.blocks.some(S=>{var I,L;return!!(pi(S)||Rs(S)&&(((I=S.ial)==null?void 0:I[ut])==="image-left"||((L=S.ial)==null?void 0:L[ut])==="image-right"))})){if(b){const S=b.headerId;if(S){c(S,{[Tt]:""});const I=i.find(L=>L.id===S);I!=null&&I.ial&&(I.ial[Tt]="")}for(const I of b.itemIds){c(I,{[Tt]:""});const L=i.find(R=>R.id===I);L!=null&&L.ial&&(L.ial[Tt]="")}}continue}let C=null,A=-1;for(let S=0;S<m.blocks.length;S++){const I=m.blocks[S],L=ce(I)?[I,...a(I.children||[])]:I.children?a(I.children):[];for(const R of L){const N=Ia(R);if(N){C=N,A=S;break}}if(C)break}if(C){const{superBlockNode:S,layout:I,items:L,slots:R}=C,J=m.blocks.slice(0,A).find(U=>$a(U)),x=J==null?void 0:J.id,q=((d=v==null?void 0:v.ial)==null?void 0:d[ut])||"";if(q!==I&&(c(k,{[ut]:I},{[ut]:q}),v&&(v.ial||(v.ial={}),v.ial[ut]=I)),J){const U=((h=J.ial)==null?void 0:h[Tt])||"";U!=="header"&&(c(J.id,{[Tt]:"header"},{[Tt]:U}),J.ial||(J.ial={}),J.ial[Tt]="header")}if(b!=null&&b.headerId&&b.headerId!==x){c(b.headerId,{[Tt]:""});const U=i.find(et=>et.id===b.headerId);U&&(U.ial||(U.ial={}),U.ial[Tt]="")}const y=[];for(let U=0;U<L.length;U++){const et=L[U],j=R[U];y.push(et.id);const it=((p=et.ial)==null?void 0:p[Tt])||"";if(it!==j&&(c(et.id,{[Tt]:j},{[Tt]:it}),et.ial||(et.ial={}),et.ial[Tt]=j),et.children&&et.children.length>0)for(const V of et.children)V.ial||(V.ial={}),V.ial[Tt]!==j&&(V.ial[Tt]=j)}if(b!=null&&b.itemIds){for(const U of b.itemIds)if(!y.includes(U)){c(U,{[Tt]:""});const et=i.find(j=>j.id===U);et&&(et.ial||(et.ial={}),et.ial[Tt]="")}}s.push({superBlockId:S.id,nestedSuperBlockIds:(f=C.nestedSuperBlocks)==null?void 0:f.map(U=>U.id),pageTargetId:k,headerId:x,itemIds:y,layout:I})}else{let S=!1;const I=[];for(const N of m.blocks){const J=ce(N)?[N,...a(N.children||[])]:N.children?a(N.children):[];for(const x of J){const q=Ta(x);if(q){S=!0;for(const y of q.items)I.push(y.id)}}}const L=((w=v==null?void 0:v.ial)==null?void 0:w[ut])||"";if(b||S&&(L==="two-cols-header"||L==="three-cols-header")){c(k,{[ut]:""},{[ut]:L}),v&&(v.ial||(v.ial={}),v.ial[ut]="");const N=b==null?void 0:b.headerId;if(N){c(N,{[Tt]:""});const x=i.find(q=>q.id===N);x&&(x.ial||(x.ial={}),x.ial[Tt]="")}const J=new Set([...(b==null?void 0:b.itemIds)||[],...I]);for(const x of J){c(x,{[Tt]:""});const q=i.find(y=>y.id===x);q&&(q.ial||(q.ial={}),q.ial[Tt]="")}}}}return{changes:n,newTracked:s}}function Ma(t){const i=Object.entries(t).filter(([n,s])=>s!=null&&s!=="");return i.length===0?"":`---
${i.map(([n,s])=>typeof s=="string"?s.includes(":")||s.includes(`
`)||s.includes("#")?`${n}: "${s.replace(/"/g,'\\"')}"`:`${n}: ${s}`:`${n}: ${JSON.stringify(s)}`).join(`
`)}
---`}function Ba(t,i){if(!i||!t.startsWith("```"))return t;const e=t.indexOf(`
`);if(e===-1)return t;const n=t.slice(0,e).trim(),s=t.slice(e);return n.includes("{")?t:`${n} {${i}}${s}`}function Da(t,i){if(i==null)return t;const e=i.trim();return e===""||e==="+1"?`<v-click>

${t}

</v-click>`:e==="hide"?`<v-click hide>

${t}

</v-click>`:`<v-click at="${e}">

${t}

</v-click>`}function Oa(t){if(!t||!t.preset)return null;const i=t.preset.toLowerCase().trim();if(!i||i==="none")return null;let e={opacity:0},n={opacity:1};switch(i){case"slide-up":e={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":e={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":e={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":e={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":e={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":e={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:e={opacity:0},n={opacity:1};break}t.initial&&typeof t.initial=="object"&&(e={...e,...t.initial}),t.enter&&typeof t.enter=="object"&&(n={...n,...t.enter});const s={...n.transition||{}};return typeof t.duration=="number"&&t.duration>0&&(s.duration=t.duration),typeof t.delay=="number"&&t.delay>0&&(s.delay=t.delay),Object.keys(s).length>0&&(n.transition=s),{initial:e,enter:n}}function bs(t,i,e){const n=i!=null&&i.trim()!=="",s=Oa(e);if(!n&&!s)return t;if(n&&!s)return Da(t,i);const r=JSON.stringify(s.initial).replace(/"/g,"'"),l=JSON.stringify(s.enter).replace(/"/g,"'"),o=`v-motion :initial="${r}" :enter="${l}"`;if(!n)return`<div ${o}>

${t}

</div>`;const a=i.trim();let c="v-click";return a==="hide"?c="v-click.hide":a!==""&&a!=="+1"&&(c=`v-click="${a}"`),`<div ${c} ${o}>

${t}

</div>`}function Ar(t){if(!t)return"";let i=t.trim();i=i.replace(/\{:[^}]*\}/g,"").trim(),i=i.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),i=i.replace(/\r?\n?:::\s*$/g,"");let s=i.split(/\r?\n/).map(r=>r.trim().replace(/^>\s*/,"")).join(`
`).trim();return s=s.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),s=s.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),s=s.replace(/^[-*+]\s+/,""),s=s.replace(/^\d+\.\s+/,""),s.trim()}function Pa(t){var n;if(t.subType&&/^h([1-6])$/i.test(t.subType))return parseInt(t.subType.slice(1),10);const e=(t.markdown||t.content||"").trim().match(/^(#{1,6})\s+/);return e?e[1].length:t.type==="h"?(n=t.ial)!=null&&n.subType&&/^h([1-6])$/i.test(t.ial.subType)?parseInt(t.ial.subType.slice(1),10):1:null}function Tr(t){if(!t||t.length===0)return{col1:[],col2:[],col3:[]};if(t.length===1&&t[0].children&&t[0].children.length>=2){const l=t[0].children;if(l.length>=3){const o=Math.ceil(l.length/3),a=Math.ceil((l.length-o)/2);return{col1:l.slice(0,o),col2:l.slice(o,o+a),col3:l.slice(o+a)}}else return{col1:[l[0]],col2:[l[1]],col3:[]}}const i=l=>{const o=l.slot||"";return o==="col-1"||o==="left"?1:o==="col-2"||o==="center"?2:o==="col-3"||o==="right"?3:null},e=t.map(i);if(e.some(l=>l!==null)){const l=e.includes(2),o=e.includes(3);if(l||o){const d=[],h=[],p=[];let f=1;for(const w of t){const m=i(w);m!==null&&(f=m),f===1?d.push(w):f===2?h.push(w):p.push(w)}return{col1:d,col2:h,col3:p}}const a=t.filter(d=>i(d)===1),c=t.filter(d=>i(d)===null);if(c.length>=2){const d=Math.ceil(c.length/2);return{col1:a,col2:c.slice(0,d),col3:c.slice(d)}}else return c.length===1?{col1:a,col2:c,col3:[]}:{col1:a,col2:[],col3:[]}}const s=l=>{if(l.type==="h"||l.subType&&/^h[1-6]$/i.test(l.subType))return!0;const o=(l.rawMarkdown||l.content||"").trim();return/^#{1,6}\s+/.test(o)},r=t.map((l,o)=>s(l)?o:-1).filter(l=>l!==-1);if(r.length>=3)return{col1:t.slice(0,r[1]),col2:t.slice(r[1],r[2]),col3:t.slice(r[2])};if(t.length>=3){const l=Math.ceil(t.length/3),o=Math.ceil((t.length-l)/2);return{col1:t.slice(0,l),col2:t.slice(l,l+o),col3:t.slice(l+o)}}if(t.length===2)return{col1:[t[0]],col2:[t[1]],col3:[]};if(t.length===1){const l=t[0],o=(l.rawMarkdown||l.content||"").trim(),a=o.split(/\r?\n/),c=[];for(let p=0;p<a.length;p++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(a[p])&&c.push(p);if(c.length>=3){const p=Math.ceil(c.length/3),f=Math.ceil((c.length-p)/2),w=a.slice(c[0],c[p]).join(`
`),m=a.slice(c[p],c[p+f]).join(`
`),k=a.slice(c[p+f]).join(`
`);return{col1:[{...l,rawMarkdown:w,content:w}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:m,content:m}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:k,content:k}]}}const d=o.match(/<li[\s\S]*?<\/li>/gi);if(d&&d.length>=3){const p=Math.ceil(d.length/3),f=Math.ceil((d.length-p)/2),w=`<ul>
${d.slice(0,p).join(`
`)}
</ul>`,m=`<ul>
${d.slice(p,p+f).join(`
`)}
</ul>`,k=`<ul>
${d.slice(p+f).join(`
`)}
</ul>`;return{col1:[{...l,rawMarkdown:w,content:w}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:m,content:m}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:k,content:k}]}}const h=o.split(/\r?\n\s*\r?\n/).filter(p=>p.trim()!=="");if(h.length>=3){const p=Math.ceil(h.length/3),f=Math.ceil((h.length-p)/2);return{col1:[{...l,rawMarkdown:h.slice(0,p).join(`

`),content:h.slice(0,p).join(`

`)}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:h.slice(p,p+f).join(`

`),content:h.slice(p,p+f).join(`

`)}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:h.slice(p+f).join(`

`),content:h.slice(p+f).join(`

`)}]}}}return{col1:t,col2:[],col3:[]}}function Lo(t,i,e,n){const s=ha(i),r=[],l=Oo(i);let o={pageIndex:1,startBlockId:t,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[t]};o.frontmatter.background&&(o.frontmatter.background=_e(o.frontmatter.background,n)),o.frontmatter.image&&(o.frontmatter.image=_e(o.frontmatter.image,n)),r.push(o);let a=[];for(const d of e){if(Kn(d)){a=[];const p=Oo(d.ial);if(r.length===1&&o.blocks.length===0){o.startBlockId=d.id,o.allBlockIds||(o.allBlockIds=[]),o.allBlockIds.includes(d.id)||o.allBlockIds.push(d.id),p.frontmatter.layout&&(o.frontmatter.layout=p.frontmatter.layout),Object.assign(o.frontmatter,p.frontmatter),!p.frontmatter.image&&l.frontmatter.image&&(o.frontmatter.image=l.frontmatter.image),!p.frontmatter.background&&l.frontmatter.background&&(o.frontmatter.background=l.frontmatter.background),o.frontmatter.background&&(o.frontmatter.background=_e(o.frontmatter.background,n)),o.frontmatter.image&&(o.frontmatter.image=_e(o.frontmatter.image,n));continue}o={pageIndex:r.length+1,startBlockId:d.id,frontmatter:{layout:p.frontmatter.layout||"default",...p.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[d.id]},o.frontmatter.background&&(o.frontmatter.background=_e(o.frontmatter.background,n)),o.frontmatter.image&&(o.frontmatter.image=_e(o.frontmatter.image,n)),r.push(o);continue}const h=p=>{if(o.allBlockIds||(o.allBlockIds=[]),p.id&&!o.allBlockIds.includes(p.id)&&o.allBlockIds.push(p.id),p.children&&p.children.length>0){const x=q=>{for(const y of q)y.id&&!o.allBlockIds.includes(y.id)&&o.allBlockIds.push(y.id),y.children&&y.children.length>0&&x(y.children)};x(p.children)}let f=wa(p),w=p.ial?{...p.ial}:{};const m=f.match(/\{:\s*([^}]+)\s*\}\s*$/);m&&(w={...ka(m[0]),...w},f=f.slice(0,m.index).trim());let k=f.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(k)||k==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(k)&&/\r?\n\}\}\}$/.test(k)&&(f=k.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),k=f.trim());const v=ma(w);if(f=Sa(f,n),f=ya(f,n==null?void 0:n.refContentMap),p.children&&p.children.length>0){const x=y=>{var U,et,j,it;for(const V of y){if(V.type==="video"||V.type==="NodeVideo"||/<video\b/i.test(V.markdown||V.content||"")||(U=V.ial)!=null&&U["custom-slidev-autoplay"]||(et=V.ial)!=null&&et["custom-slidev-muted"]||(j=V.ial)!=null&&j["custom-slidev-loop"]||(it=V.ial)!=null&&it["custom-slidev-controls"])return V;if(V.children&&V.children.length>0){const Z=x(V.children);if(Z)return Z}}},q=x(p.children);if(q!=null&&q.ial)for(const[y,U]of Object.entries(q.ial))y.startsWith("custom-slidev-")&&!w[y]&&(w[y]=U)}const b=p.type==="video"||p.type==="NodeVideo"||/<video\b/i.test(f);if(b){const x=w["custom-slidev-autoplay"]==="true",q=w["custom-slidev-loop"]==="true",y=w["custom-slidev-muted"]==="true"||x,U=w["custom-slidev-controls"]==="false";f=f.replace(/<video\b([^>]*)>/gi,(et,j)=>{let it=j;return U?it=it.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(it)||(it+=" controls"),x&&!/autoplay/i.test(it)?it+=" autoplay playsinline":!x&&w["custom-slidev-autoplay"]==="false"&&(it=it.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),q&&!/loop/i.test(it)?it+=" loop":!q&&w["custom-slidev-loop"]==="false"&&(it=it.replace(/\bloop\b/gi,"").trim()),y&&!/muted/i.test(it)?it+=" muted":!y&&w["custom-slidev-muted"]==="false"&&(it=it.replace(/\bmuted\b/gi,"").trim()),`<video ${it.trim()}>`})}if(v.isBackground){const x=fi(f,p.content);if(x){o.frontmatter.background=_e(x,n);return}}const T=pi(p);if(T){o.frontmatter.layout=T.layout,o.frontmatter.image=_e(T.imageUrl,n);for(const x of T.contentNodes)h(x);return}if(v.imageLayout==="image-left"||v.imageLayout==="image-right"){const x=fi(f,p.content);if(x){o.frontmatter.layout=v.imageLayout,o.frontmatter.image=_e(x,n);return}}if(ce(p)&&p.children&&p.children.length>0){for(const x of p.children)h(x);return}if((p.type==="l"||p.type==="NodeList"||p.type==="list")&&p.children&&p.children.length>0&&(p.children.some(x=>{var q;return(q=x.ial)==null?void 0:q[Tt]})||v.slot)){for(const x of p.children)v.slot&&(!x.ial||!x.ial[Tt])&&(x.ial||(x.ial={}),x.ial[Tt]=v.slot),h(x);return}if(v.isNote){const x=Ar(f);x&&(o.notes?o.notes+=`

`+x:o.notes=x),o.noteBlocks||(o.noteBlocks=[]),o.noteBlocks.push({id:p.id,type:p.type,content:x||p.content||"",rawMarkdown:f,isNote:!0,attributes:p.ial});return}v.shikiLines&&(f=Ba(f,v.shikiLines)),k=f.trim();const C=(p.content||"").trim();if(k==="::right::"||C==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(k)||k.startsWith("::right::")){o.blocks.push({id:p.id,type:p.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:p.ial});return}const S=Pa(p);let I=v.slot,L=v.clicks,R=v.motion,N={...p.ial||{}};if(S!==null){for(;a.length>0&&a[a.length-1].level>=S;)a.pop();const x=a.length>0?a[a.length-1]:void 0;!I&&(x!=null&&x.slot)&&(I=x.slot),!L&&(x!=null&&x.clicks)&&(L=x.clicks),!R&&(x!=null&&x.motion)&&(R=x.motion);const q={...(x==null?void 0:x.customAttrs)||{}};if(p.ial)for(const[y,U]of Object.entries(p.ial))y.startsWith("custom-slidev-")&&!y.startsWith("custom-slidev-slide")&&(q[y]=U);a.push({level:S,slot:I,clicks:L,motion:R,customAttrs:q})}else{const x=a.length>0?a[a.length-1]:void 0;x&&(!I&&x.slot&&x.slot!=="header"&&(I=x.slot),!L&&x.clicks&&(L=x.clicks),!R&&x.motion&&(R=x.motion),x.customAttrs&&(N={...x.customAttrs,...N}))}!I&&o.blocks.some(x=>x.slot==="slot-divider-right")&&(I="right"),I&&(N[Tt]=I),L&&!N[Se]&&(N[Se]=L),R&&!N[He]&&(N[He]=JSON.stringify(R)),b&&(w["custom-slidev-autoplay"]&&(N["custom-slidev-autoplay"]=w["custom-slidev-autoplay"]),w["custom-slidev-loop"]&&(N["custom-slidev-loop"]=w["custom-slidev-loop"]),w["custom-slidev-muted"]&&(N["custom-slidev-muted"]=w["custom-slidev-muted"]),w["custom-slidev-controls"]&&(N["custom-slidev-controls"]=w["custom-slidev-controls"]));const J={id:p.id,type:p.type,content:p.content||"",rawMarkdown:f,clicks:L,motion:R,shikiLines:v.shikiLines,slot:I,attributes:N};o.blocks.push(J)};h(d)}for(let d=0;d<r.length;d++){const h=r[d],p=[],f={...h.frontmatter};d===0&&(f.theme=s.theme,f.aspectRatio=s.aspectRatio,f.highlighter=s.highlighter,f.transition=h.frontmatter.transition||s.defaultTransition);const w=Ma(f);w&&p.push(w);const m=h.blocks.filter(T=>T.slot!=="slot-divider-right"),k=T=>T.map(C=>bs(C.rawMarkdown,C.clicks,C.motion)).join(`

`),v=T=>{if(T.length===0)return"";if(T.length===1&&Wi(T[0])){const C=zs(T[0].rawMarkdown);return bs(C,T[0].clicks,T[0].motion)}return k(T)},b=h.frontmatter.layout||"default";if(b==="two-cols-header"){let T=[];const C=m.filter(J=>J.slot==="header");if(C.length>0)T=C;else if(m.length>0){const J=m.find(x=>x.type==="h"&&(!x.slot||x.slot==="default"));J&&(T=[J])}const A=m.filter(J=>!T.includes(J)),S=A.filter(J=>J.slot==="right"||J.slot==="col-2"),I=A.filter(J=>!S.includes(J)),L=k(T),R=v(I),N=v(S);L&&p.push(L),R&&p.push(`::left::

${R}`),N&&p.push(`::right::

${N}`)}else if(b==="three-cols-header"){let T=[];const C=m.filter(y=>y.slot==="header");if(C.length>0)T=C;else if(m.length>0){const y=m.find(U=>U.type==="h"&&(!U.slot||U.slot==="default"));y&&(T=[y])}const A=m.filter(y=>!T.includes(y)),S=Tr(A),I=S.col1,L=S.col2,R=S.col3;for(const y of I)y.slot||(y.slot="col-1");for(const y of L)y.slot||(y.slot="col-2");for(const y of R)y.slot||(y.slot="col-3");if(A.length===1&&(L.length>0||R.length>0)){const y=h.blocks.findIndex(U=>U.id===A[0].id);y!==-1&&h.blocks.splice(y,1,...I,...L,...R)}const N=k(T),J=v(I),x=v(L),q=v(R);N&&p.push(N),J&&p.push(`::col-1::

${J}`),x&&p.push(`::col-2::

${x}`),q&&p.push(`::col-3::

${q}`)}else if(b==="two-cols"){const T=m.filter(I=>I.slot==="left"),C=m.filter(I=>I.slot==="right"),A=k(T.length>0?T:m.filter(I=>I.slot!=="right")),S=k(C);p.push(A),S&&p.push(`::right::

${S}`)}else for(const T of m)p.push(bs(T.rawMarkdown,T.clicks,T.motion));h.notes&&p.push(`<!--
${h.notes}
-->`),h.rawMarkdown=p.join(`

`).trim()}const c=r.map(d=>d.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:t,config:s,slides:r,fullMarkdown:c}}function ys(t){const i={};if(!t||typeof t!="string")return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(e))!==null;){const r=s[1],l=s[2]??s[3]??s[4]??"";i[r]=l}return i}const La={getBlockAttrs:Ge,getChildBlocks:Vn,setBlockAttrs:zt,sql:pn,getBaseUrl:()=>typeof location<"u"?location.origin:""};class Ra{constructor(i){vt(this,"deps");vt(this,"attrOverrides",new Map);vt(this,"trackedListSuperBlocks",new Map);this.deps={...La,...i||{}}}setBlockAttrOverride(i,e){if(!i||!e)return;const s={...this.attrOverrides.get(i)||{}};for(const[r,l]of Object.entries(e))l===""||l===null||l===void 0?delete s[r]:s[r]=String(l);Object.keys(s).length===0?this.attrOverrides.delete(i):this.attrOverrides.set(i,s)}getBlockAttrOverride(i){return this.attrOverrides.get(i)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(i){return this.trackedListSuperBlocks.get(i)||[]}clearBlockAttrOverride(i,e){if(!i)return;if(!e){this.attrOverrides.delete(i);return}const n=this.attrOverrides.get(i);n&&(delete n[e],Object.keys(n).length===0&&this.attrOverrides.delete(i))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(i){try{const e=await this.deps.getBlockAttrs(i).catch(()=>({}))||{},n=this.attrOverrides.get(i);n&&Object.assign(e,n);let s=await this.deps.getChildBlocks(i).catch(()=>[]);const r=`SELECT id, ial FROM blocks WHERE root_id = '${i}' LIMIT 99999`,l=await this.deps.sql(r).catch(()=>[])||[],o=new Map;if(Array.isArray(l))for(const b of l)b.id&&b.ial&&o.set(b.id,ys(b.ial));const a=`SELECT block_id, name, value FROM attributes WHERE root_id = '${i}' LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[];if(Array.isArray(c)){for(const b of c)if(b.block_id&&b.name){let T=o.get(b.block_id);T||(T={},o.set(b.block_id,T)),T[b.name]=b.value||""}}if(!s||s.length===0){const b=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE root_id = '${i}' AND id != '${i}' ORDER BY created ASC LIMIT 99999`;s=await this.deps.sql(b).catch(()=>[])||[]}const d=(s||[]).map(b=>{const T=o.get(b.id)||(b.ial?ys(b.ial):{}),C=this.attrOverrides.get(b.id);return C&&Object.assign(T,C),{id:b.id,parent_id:b.parent_id,root_id:b.root_id||i,type:b.type,subType:b.subType,content:b.content||"",markdown:b.markdown||"",ial:T,children:b.children}}),h=async(b,T=0)=>{if(!(!b||b.length===0||T>8))for(const C of b){if((ce(C)||C.type==="l"||C.type==="NodeList")&&(!C.children||C.children.length===0)){let S=await this.deps.getChildBlocks(C.id).catch(()=>[]);if(!S||S.length===0){const I=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE parent_id = '${C.id}' ORDER BY sort ASC, created ASC`;S=await this.deps.sql(I).catch(()=>[])||[]}Array.isArray(S)&&S.length>0&&(C.children=S.map(I=>{const L=o.get(I.id)||(I.ial?ys(I.ial):{}),R=this.attrOverrides.get(I.id);return R&&Object.assign(L,R),{id:I.id,parent_id:I.parent_id||C.id,root_id:I.root_id||i,type:I.type,subType:I.subType,content:I.content||"",markdown:I.markdown||"",ial:L}}))}C.children&&C.children.length>0&&await h(C.children,T+1)}};await h(d),Ca(d,b=>{this.setBlockAttrOverride(b.blockId,{[ut]:b.layout}),(this.deps.setBlockAttrs||zt)(b.blockId,{[ut]:b.layout}).catch(C=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",C)})});const p=this.trackedListSuperBlocks.get(i)||[],f=Ea(i,d,{tracked:p,onTagChange:b=>{this.setBlockAttrOverride(b.blockId,b.attrs),b.blockId===i&&Object.assign(e,b.attrs);const T=A=>{for(const S of A)S.id===b.blockId&&(S.ial||(S.ial={}),Object.assign(S.ial,b.attrs)),S.children&&S.children.length>0&&T(S.children)};T(d),(this.deps.setBlockAttrs||zt)(b.blockId,b.attrs).catch(A=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",A)})}});this.trackedListSuperBlocks.set(i,f.newTracked);const w=new Set;for(const b of d){const T=b.markdown||b.content||"";if(T.includes("((")){const C=ba(T);for(const A of C)w.add(A.blockId)}}const m={};if(w.size>0){const b=Array.from(w).map(C=>`'${C}'`).join(","),T=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${b})`).catch(()=>[])||[];if(Array.isArray(T))for(const C of T)C.id&&(m[C.id]=C.markdown||C.content||"")}const k=this.deps.getBaseUrl?this.deps.getBaseUrl():"";return Lo(i,e,d,{baseUrl:k,refContentMap:m})}catch(e){return console.error("[DocumentCompilerService] Failed to compile document:",e),Lo(i,{},[],{})}}}const Ht=new Ra;class Qs{constructor(i){vt(this,"devServerUrl","http://localhost:3030");vt(this,"isConnected",!1);vt(this,"lastSyncTime",null);i&&(this.devServerUrl=i)}getUrl(){return this.devServerUrl}setUrl(i){this.devServerUrl=i.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(i=1500){try{const e=new AbortController,n=setTimeout(()=>e.abort(),i),s=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:e.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!s,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(i){const e=i.config,n=["---",`theme: ${e.theme||"default"}`,`aspectRatio: "${e.aspectRatio||"16/9"}"`,`highlighter: ${e.highlighter||"shiki"}`,`transition: ${e.defaultTransition||"slide-left"}`];e.colorSchema&&e.colorSchema!=="auto"&&n.push(`colorSchema: ${e.colorSchema}`),n.push("drawings:","  persist: false","---","");const s=n.join(`
`),r=i.slides.map((l,o)=>{const a=l.frontmatter||{},c=[],d=o===0;a.layout&&a.layout!=="default"&&c.push(`layout: ${a.layout}`),a.transition&&c.push(`transition: ${a.transition}`),a.background&&c.push(`background: ${a.background}`),a.class&&c.push(`class: "${a.class}"`);let h="";c.length>0?h=d?"":`---
${c.join(`
`)}
---

`:d||(h=`---

`);let p="";if(a.layout==="two-cols"){const w=l.blocks.filter(b=>b.slot!=="right"),m=l.blocks.filter(b=>b.slot==="right"),k=w.map(b=>b.rawMarkdown||b.content||"").join(`

`),v=m.map(b=>b.rawMarkdown||b.content||"").join(`

`);p=`${k}

::right::

${v}`}else p=l.blocks.map(w=>w.rawMarkdown||w.content||"").join(`

`);let f="";return l.notes&&l.notes.trim()&&(f=`

<!--
${l.notes.trim()}
-->`),`${h}${p}${f}`}).join(`

`);return`${s}${r}
`}async syncToWorkspaceFile(i,e="/data/storage/petal/siyuan-slidev/slides.md",n){const s=this.buildStandardSlidevMarkdown(i);if(this.lastSyncTime=Date.now(),n)try{const r=typeof Blob<"u"?new Blob([s],{type:"text/markdown;charset=utf-8"}):Buffer.from(s,"utf-8");return await n(e,!1,r),{success:!0,path:e}}catch(r){return{success:!1,path:e,error:String(r)}}return{success:!0,path:e}}downloadSlidesMd(i,e="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(i),s=new Blob([n],{type:"text/markdown;charset=utf-8"}),r=URL.createObjectURL(s),l=document.createElement("a");return l.href=r,l.download=e,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(r),!0}}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function to(t){const i=Object.create(null);for(const e of t.split(","))i[e]=1;return e=>e in i}const Wt={},zi=[],Ve=()=>{},Er=()=>!1,is=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&(t.charCodeAt(2)>122||t.charCodeAt(2)<97),ns=t=>t.startsWith("onUpdate:"),re=Object.assign,eo=(t,i)=>{const e=t.indexOf(i);e>-1&&t.splice(e,1)},za=Object.prototype.hasOwnProperty,Rt=(t,i)=>za.call(t,i),St=Array.isArray,Ni=t=>kn(t)==="[object Map]",Zi=t=>kn(t)==="[object Set]",Ro=t=>kn(t)==="[object Date]",It=t=>typeof t=="function",Qt=t=>typeof t=="string",De=t=>typeof t=="symbol",jt=t=>t!==null&&typeof t=="object",Mr=t=>(jt(t)||It(t))&&It(t.then)&&It(t.catch),Br=Object.prototype.toString,kn=t=>Br.call(t),Na=t=>kn(t).slice(8,-1),Dr=t=>kn(t)==="[object Object]",io=t=>Qt(t)&&t!=="NaN"&&t[0]!=="-"&&""+parseInt(t,10)===t,an=to(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),ss=t=>{const i=Object.create(null);return(e=>i[e]||(i[e]=t(e)))},Fa=/-\w/g,he=ss(t=>t.replace(Fa,i=>i.slice(1).toUpperCase())),ja=/\B([A-Z])/g,hi=ss(t=>t.replace(ja,"-$1").toLowerCase()),os=ss(t=>t.charAt(0).toUpperCase()+t.slice(1)),ws=ss(t=>t?`on${os(t)}`:""),Ue=(t,i)=>!Object.is(t,i),Fn=(t,...i)=>{for(let e=0;e<t.length;e++)t[e](...i)},Or=(t,i,e,n=!1)=>{Object.defineProperty(t,i,{configurable:!0,enumerable:!1,writable:n,value:e})},rs=t=>{const i=parseFloat(t);return isNaN(i)?t:i};let zo;const ls=()=>zo||(zo=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function no(t){if(St(t)){const i={};for(let e=0;e<t.length;e++){const n=t[e],s=Qt(n)?Va(n):no(n);if(s)for(const r in s)i[r]=s[r]}return i}else if(Qt(t)||jt(t))return t}const Ha=/;(?![^(]*\))/g,Ua=/:([^]+)/,Wa=/\/\*[^]*?\*\//g;function Va(t){const i={};return t.replace(Wa,"").split(Ha).forEach(e=>{if(e){const n=e.split(Ua);n.length>1&&(i[n[0].trim()]=n[1].trim())}}),i}function Et(t){let i="";if(Qt(t))i=t;else if(St(t))for(let e=0;e<t.length;e++){const n=Et(t[e]);n&&(i+=n+" ")}else if(jt(t))for(const e in t)t[e]&&(i+=e+" ");return i.trim()}const Ka="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",qa=to(Ka);function Pr(t){return!!t||t===""}function Ga(t,i){if(t.length!==i.length)return!1;let e=!0;for(let n=0;e&&n<t.length;n++)e=Yi(t[n],i[n]);return e}function Yi(t,i){if(t===i)return!0;let e=Ro(t),n=Ro(i);if(e||n)return e&&n?t.getTime()===i.getTime():!1;if(e=De(t),n=De(i),e||n)return t===i;if(e=St(t),n=St(i),e||n)return e&&n?Ga(t,i):!1;if(e=jt(t),n=jt(i),e||n){if(!e||!n)return!1;const s=Object.keys(t).length,r=Object.keys(i).length;if(s!==r)return!1;for(const l in t){const o=t.hasOwnProperty(l),a=i.hasOwnProperty(l);if(o&&!a||!o&&a||!Yi(t[l],i[l]))return!1}}return String(t)===String(i)}function so(t,i){return t.findIndex(e=>Yi(e,i))}const Lr=t=>!!(t&&t.__v_isRef===!0),_t=t=>Qt(t)?t:t==null?"":St(t)||jt(t)&&(t.toString===Br||!It(t.toString))?Lr(t)?_t(t.value):JSON.stringify(t,Rr,2):String(t),Rr=(t,i)=>Lr(i)?Rr(t,i.value):Ni(i)?{[`Map(${i.size})`]:[...i.entries()].reduce((e,[n,s],r)=>(e[ks(n,r)+" =>"]=s,e),{})}:Zi(i)?{[`Set(${i.size})`]:[...i.values()].map(e=>ks(e))}:De(i)?ks(i):jt(i)&&!St(i)&&!Dr(i)?String(i):i,ks=(t,i="")=>{var e;return De(t)?`Symbol(${(e=t.description)!=null?e:i})`:t};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let ne;class Za{constructor(i=!1){this.detached=i,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!i&&ne&&(ne.active?(this.parent=ne,this.index=(ne.scopes||(ne.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let i,e;if(this.scopes){const n=this.scopes.slice();for(i=0,e=n.length;i<e;i++)n[i].pause()}for(i=0,e=this.effects.length;i<e;i++)this.effects[i].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let i,e;if(this.scopes){const s=this.scopes.slice();for(i=0,e=s.length;i<e;i++)s[i].resume()}const n=this.effects.slice();for(i=0,e=n.length;i<e;i++)n[i].resume()}}run(i){if(this._active){const e=ne;try{return ne=this,i()}finally{ne=e}}}on(){++this._on===1&&(this.prevScope=ne,ne=this)}off(){if(this._on>0&&--this._on===0){if(ne===this)ne=this.prevScope;else{let i=ne;for(;i;){if(i.prevScope===this){i.prevScope=this.prevScope;break}i=i.prevScope}}this.prevScope=void 0}}stop(i){if(this._active){this._active=!1;let e,n;for(e=0,n=this.effects.length;e<n;e++)this.effects[e].stop();for(this.effects.length=0,e=0,n=this.cleanups.length;e<n;e++)this.cleanups[e]();if(this.cleanups.length=0,this.scopes){const s=this.scopes.slice();for(e=0,n=s.length;e<n;e++)s[e].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!i){const s=this.parent.scopes.pop();s&&s!==this&&(this.parent.scopes[this.index]=s,s.index=this.index)}this.parent=void 0}}}function Ya(){return ne}let Kt;const xs=new WeakSet;class zr{constructor(i){this.fn=i,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,ne&&(ne.active?ne.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,xs.has(this)&&(xs.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Fr(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,No(this),jr(this);const i=Kt,e=Be;Kt=this,Be=!0;try{return this.fn()}finally{Hr(this),Kt=i,Be=e,this.flags&=-3}}stop(){if(this.flags&1){for(let i=this.deps;i;i=i.nextDep)lo(i);this.deps=this.depsTail=void 0,No(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?xs.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){Ns(this)&&this.run()}get dirty(){return Ns(this)}}let Nr=0,cn,dn;function Fr(t,i=!1){if(t.flags|=8,i){t.next=dn,dn=t;return}t.next=cn,cn=t}function oo(){Nr++}function ro(){if(--Nr>0)return;if(dn){let i=dn;for(dn=void 0;i;){const e=i.next;i.next=void 0,i.flags&=-9,i=e}}let t;for(;cn;){let i=cn;for(cn=void 0;i;){const e=i.next;if(i.next=void 0,i.flags&=-9,i.flags&1)try{i.trigger()}catch(n){t||(t=n)}i=e}}if(t)throw t}function jr(t){for(let i=t.deps;i;i=i.nextDep)i.version=-1,i.prevActiveLink=i.dep.activeLink,i.dep.activeLink=i}function Hr(t){let i,e=t.depsTail,n=e;for(;n;){const s=n.prevDep;n.version===-1?(n===e&&(e=s),lo(n),Ja(n)):i=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=s}t.deps=i,t.depsTail=e}function Ns(t){for(let i=t.deps;i;i=i.nextDep)if(i.dep.version!==i.version||i.dep.computed&&(Ur(i.dep.computed)||i.dep.version!==i.version))return!0;return!!t._dirty}function Ur(t){if(t.flags&4&&!(t.flags&16)||(t.flags&=-17,t.globalVersion===hn)||(t.globalVersion=hn,!t.isSSR&&t.flags&128&&(!t.deps&&!t._dirty||!Ns(t))))return;t.flags|=2;const i=t.dep,e=Kt,n=Be;Kt=t,Be=!0;try{jr(t);const s=t.fn(t._value);(i.version===0||Ue(s,t._value))&&(t.flags|=128,t._value=s,i.version++)}catch(s){throw i.version++,s}finally{Kt=e,Be=n,Hr(t),t.flags&=-3}}function lo(t,i=!1){const{dep:e,prevSub:n,nextSub:s}=t;if(n&&(n.nextSub=s,t.prevSub=void 0),s&&(s.prevSub=n,t.nextSub=void 0),e.subs===t&&(e.subs=n,!n&&e.computed)){e.computed.flags&=-5;for(let r=e.computed.deps;r;r=r.nextDep)lo(r,!0)}!i&&!--e.sc&&e.map&&e.map.delete(e.key)}function Ja(t){const{prevDep:i,nextDep:e}=t;i&&(i.nextDep=e,t.prevDep=void 0),e&&(e.prevDep=i,t.nextDep=void 0)}let Be=!0;const Wr=[];function ii(){Wr.push(Be),Be=!1}function ni(){const t=Wr.pop();Be=t===void 0?!0:t}function No(t){const{cleanup:i}=t;if(t.cleanup=void 0,i){const e=Kt;Kt=void 0;try{i()}finally{Kt=e}}}let hn=0;class Xa{constructor(i,e){this.sub=i,this.dep=e,this.version=e.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class ao{constructor(i){this.computed=i,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(i){if(!Kt||!Be||Kt===this.computed)return;let e=this.activeLink;if(e===void 0||e.sub!==Kt)e=this.activeLink=new Xa(Kt,this),Kt.deps?(e.prevDep=Kt.depsTail,Kt.depsTail.nextDep=e,Kt.depsTail=e):Kt.deps=Kt.depsTail=e,Vr(e);else if(e.version===-1&&(e.version=this.version,e.nextDep)){const n=e.nextDep;n.prevDep=e.prevDep,e.prevDep&&(e.prevDep.nextDep=n),e.prevDep=Kt.depsTail,e.nextDep=void 0,Kt.depsTail.nextDep=e,Kt.depsTail=e,Kt.deps===e&&(Kt.deps=n)}return e}trigger(i){this.version++,hn++,this.notify(i)}notify(i){oo();try{for(let e=this.subs;e;e=e.prevSub)e.sub.notify()&&e.sub.dep.notify()}finally{ro()}}}function Vr(t){if(t.dep.sc++,t.sub.flags&4){const i=t.dep.computed;if(i&&!t.dep.subs){i.flags|=20;for(let n=i.deps;n;n=n.nextDep)Vr(n)}const e=t.dep.subs;e!==t&&(t.prevSub=e,e&&(e.nextSub=t)),t.dep.subs=t}}const Fs=new WeakMap,$i=Symbol(""),js=Symbol(""),mn=Symbol("");function le(t,i,e){if(Be&&Kt){let n=Fs.get(t);n||Fs.set(t,n=new Map);let s=n.get(e);s||(n.set(e,s=new ao),s.map=n,s.key=e),s.track()}}function Je(t,i,e,n,s,r){const l=Fs.get(t);if(!l){hn++;return}const o=a=>{a&&a.trigger()};if(oo(),i==="clear")l.forEach(o);else{const a=St(t),c=a&&io(e);if(a&&e==="length"){const d=Number(n);l.forEach((h,p)=>{(p==="length"||p===mn||!De(p)&&p>=d)&&o(h)})}else switch((e!==void 0||l.has(void 0))&&o(l.get(e)),c&&o(l.get(mn)),i){case"add":a?c&&o(l.get("length")):(o(l.get($i)),Ni(t)&&o(l.get(js)));break;case"delete":a||(o(l.get($i)),Ni(t)&&o(l.get(js)));break;case"set":Ni(t)&&o(l.get($i));break}}ro()}function Oi(t){const i=Lt(t);return i===t?i:(le(i,"iterate",mn),Ce(t)?i:i.map(Oe))}function as(t){return le(t=Lt(t),"iterate",mn),t}function Fe(t,i){return si(t)?Vi(Ii(t)?Oe(i):i):Oe(i)}const Qa={__proto__:null,[Symbol.iterator](){return _s(this,Symbol.iterator,t=>Fe(this,t))},concat(...t){return Oi(this).concat(...t.map(i=>St(i)?Oi(i):i))},entries(){return _s(this,"entries",t=>(t[1]=Fe(this,t[1]),t))},every(t,i){return qe(this,"every",t,i,void 0,arguments)},filter(t,i){return qe(this,"filter",t,i,e=>e.map(n=>Fe(this,n)),arguments)},find(t,i){return qe(this,"find",t,i,e=>Fe(this,e),arguments)},findIndex(t,i){return qe(this,"findIndex",t,i,void 0,arguments)},findLast(t,i){return qe(this,"findLast",t,i,e=>Fe(this,e),arguments)},findLastIndex(t,i){return qe(this,"findLastIndex",t,i,void 0,arguments)},forEach(t,i){return qe(this,"forEach",t,i,void 0,arguments)},includes(...t){return Ss(this,"includes",t)},indexOf(...t){return Ss(this,"indexOf",t)},join(t){return Oi(this).join(t)},lastIndexOf(...t){return Ss(this,"lastIndexOf",t)},map(t,i){return qe(this,"map",t,i,void 0,arguments)},pop(){return Ji(this,"pop")},push(...t){return Ji(this,"push",t)},reduce(t,...i){return Fo(this,"reduce",t,i)},reduceRight(t,...i){return Fo(this,"reduceRight",t,i)},shift(){return Ji(this,"shift")},some(t,i){return qe(this,"some",t,i,void 0,arguments)},splice(...t){return Ji(this,"splice",t)},toReversed(){return Oi(this).toReversed()},toSorted(t){return Oi(this).toSorted(t)},toSpliced(...t){return Oi(this).toSpliced(...t)},unshift(...t){return Ji(this,"unshift",t)},values(){return _s(this,"values",t=>Fe(this,t))}};function _s(t,i,e){const n=as(t),s=n[i]();return n!==t&&!Ce(t)&&(s._next=s.next,s.next=()=>{const r=s._next();return r.done||(r.value=e(r.value)),r}),s}const tc=Array.prototype;function qe(t,i,e,n,s,r){const l=as(t),o=l!==t&&!Ce(t),a=l[i];if(a!==tc[i]){const h=a.apply(t,r);return o?Oe(h):h}let c=e;l!==t&&(o?c=function(h,p){return e.call(this,Fe(t,h),p,t)}:e.length>2&&(c=function(h,p){return e.call(this,h,p,t)}));const d=a.call(l,c,n);return o&&s?s(d):d}function Fo(t,i,e,n){const s=as(t),r=s!==t&&!Ce(t);let l=e,o=!1;s!==t&&(r?(o=n.length===0,l=function(c,d,h){return o&&(o=!1,c=Fe(t,c)),e.call(this,c,Fe(t,d),h,t)}):e.length>3&&(l=function(c,d,h){return e.call(this,c,d,h,t)}));const a=s[i](l,...n);return o?Fe(t,a):a}function Ss(t,i,e){const n=Lt(t);le(n,"iterate",mn);const s=n[i](...e);return(s===-1||s===!1)&&fo(e[0])?(e[0]=Lt(e[0]),n[i](...e)):s}function Ji(t,i,e=[]){ii(),oo();const n=Lt(t)[i].apply(t,e);return ro(),ni(),n}const ec=to("__proto__,__v_isRef,__isVue"),Kr=new Set(Object.getOwnPropertyNames(Symbol).filter(t=>t!=="arguments"&&t!=="caller").map(t=>Symbol[t]).filter(De));function ic(t){De(t)||(t=String(t));const i=Lt(this);return le(i,"has",t),i.hasOwnProperty(t)}class qr{constructor(i=!1,e=!1){this._isReadonly=i,this._isShallow=e}get(i,e,n){if(e==="__v_skip")return i.__v_skip;const s=this._isReadonly,r=this._isShallow;if(e==="__v_isReactive")return!s;if(e==="__v_isReadonly")return s;if(e==="__v_isShallow")return r;if(e==="__v_raw")return n===(s?r?fc:Jr:r?Yr:Zr).get(i)||Object.getPrototypeOf(i)===Object.getPrototypeOf(n)?i:void 0;const l=St(i);if(!s){let a;if(l&&(a=Qa[e]))return a;if(e==="hasOwnProperty")return ic}const o=Reflect.get(i,e,de(i)?i:n);if((De(e)?Kr.has(e):ec(e))||(s||le(i,"get",e),r))return o;if(de(o)){const a=l&&io(e)?o:o.value;return s&&jt(a)?Us(a):a}return jt(o)?s?Us(o):cs(o):o}}class Gr extends qr{constructor(i=!1){super(!1,i)}set(i,e,n,s){let r=i[e];const l=St(i)&&io(e);if(!this._isShallow){const c=si(r);if(!Ce(n)&&!si(n)&&(r=Lt(r),n=Lt(n)),!l&&de(r)&&!de(n))return c||(r.value=n),!0}const o=l?Number(e)<i.length:Rt(i,e),a=Reflect.set(i,e,n,de(i)?i:s);return i===Lt(s)&&a&&(o?Ue(n,r)&&Je(i,"set",e,n):Je(i,"add",e,n)),a}deleteProperty(i,e){const n=Rt(i,e);i[e];const s=Reflect.deleteProperty(i,e);return s&&n&&Je(i,"delete",e,void 0),s}has(i,e){const n=Reflect.has(i,e);return(!De(e)||!Kr.has(e))&&le(i,"has",e),n}ownKeys(i){return le(i,"iterate",St(i)?"length":$i),Reflect.ownKeys(i)}}class nc extends qr{constructor(i=!1){super(!0,i)}set(i,e){return!0}deleteProperty(i,e){return!0}}const sc=new Gr,oc=new nc,rc=new Gr(!0);const Hs=t=>t,Bn=t=>Reflect.getPrototypeOf(t);function lc(t,i,e){return function(...n){const s=this.__v_raw,r=Lt(s),l=Ni(r),o=t==="entries"||t===Symbol.iterator&&l,a=t==="keys"&&l,c=s[t](...n),d=e?Hs:i?Vi:Oe;return!i&&le(r,"iterate",a?js:$i),re(Object.create(c),{next(){const{value:h,done:p}=c.next();return p?{value:h,done:p}:{value:o?[d(h[0]),d(h[1])]:d(h),done:p}}})}}function Dn(t){return function(...i){return t==="delete"?!1:t==="clear"?void 0:this}}function ac(t,i){const e={get(s){const r=this.__v_raw,l=Lt(r),o=Lt(s);t||(Ue(s,o)&&le(l,"get",s),le(l,"get",o));const{has:a}=Bn(l),c=i?Hs:t?Vi:Oe;if(a.call(l,s))return c(r.get(s));if(a.call(l,o))return c(r.get(o));r!==l&&r.get(s)},get size(){const s=this.__v_raw;return!t&&le(Lt(s),"iterate",$i),s.size},has(s){const r=this.__v_raw,l=Lt(r),o=Lt(s);return t||(Ue(s,o)&&le(l,"has",s),le(l,"has",o)),s===o?r.has(s):r.has(s)||r.has(o)},forEach(s,r){const l=this,o=l.__v_raw,a=Lt(o),c=i?Hs:t?Vi:Oe;return!t&&le(a,"iterate",$i),o.forEach((d,h)=>s.call(r,c(d),c(h),l))}};return re(e,t?{add:Dn("add"),set:Dn("set"),delete:Dn("delete"),clear:Dn("clear")}:{add(s){const r=Lt(this),l=Bn(r),o=Lt(s),a=!i&&!Ce(s)&&!si(s)?o:s;return l.has.call(r,a)||Ue(s,a)&&l.has.call(r,s)||Ue(o,a)&&l.has.call(r,o)||(r.add(a),Je(r,"add",a,a)),this},set(s,r){!i&&!Ce(r)&&!si(r)&&(r=Lt(r));const l=Lt(this),{has:o,get:a}=Bn(l);let c=o.call(l,s);c||(s=Lt(s),c=o.call(l,s));const d=a.call(l,s);return l.set(s,r),c?Ue(r,d)&&Je(l,"set",s,r):Je(l,"add",s,r),this},delete(s){const r=Lt(this),{has:l,get:o}=Bn(r);let a=l.call(r,s);a||(s=Lt(s),a=l.call(r,s)),o&&o.call(r,s);const c=r.delete(s);return a&&Je(r,"delete",s,void 0),c},clear(){const s=Lt(this),r=s.size!==0,l=s.clear();return r&&Je(s,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(s=>{e[s]=lc(s,t,i)}),e}function co(t,i){const e=ac(t,i);return(n,s,r)=>s==="__v_isReactive"?!t:s==="__v_isReadonly"?t:s==="__v_raw"?n:Reflect.get(Rt(e,s)&&s in n?e:n,s,r)}const cc={get:co(!1,!1)},dc={get:co(!1,!0)},uc={get:co(!0,!1)};const Zr=new WeakMap,Yr=new WeakMap,Jr=new WeakMap,fc=new WeakMap;function pc(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function cs(t){return si(t)?t:uo(t,!1,sc,cc,Zr)}function hc(t){return uo(t,!1,rc,dc,Yr)}function Us(t){return uo(t,!0,oc,uc,Jr)}function uo(t,i,e,n,s){if(!jt(t)||t.__v_raw&&!(i&&t.__v_isReactive)||t.__v_skip||!Object.isExtensible(t))return t;const r=s.get(t);if(r)return r;const l=pc(Na(t));if(l===0)return t;const o=new Proxy(t,l===2?n:e);return s.set(t,o),o}function Ii(t){return si(t)?Ii(t.__v_raw):!!(t&&t.__v_isReactive)}function si(t){return!!(t&&t.__v_isReadonly)}function Ce(t){return!!(t&&t.__v_isShallow)}function fo(t){return t?!!t.__v_raw:!1}function Lt(t){const i=t&&t.__v_raw;return i?Lt(i):t}function mc(t){return!Rt(t,"__v_skip")&&Object.isExtensible(t)&&Or(t,"__v_skip",!0),t}const Oe=t=>jt(t)?cs(t):t,Vi=t=>jt(t)?Us(t):t;function de(t){return t?t.__v_isRef===!0:!1}function pt(t){return gc(t,!1)}function gc(t,i){return de(t)?t:new vc(t,i)}class vc{constructor(i,e){this.dep=new ao,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=e?i:Lt(i),this._value=e?i:Oe(i),this.__v_isShallow=e}get value(){return this.dep.track(),this._value}set value(i){const e=this._rawValue,n=this.__v_isShallow||Ce(i)||si(i);i=n?i:Lt(i),Ue(i,e)&&(this._rawValue=i,this._value=n?i:Oe(i),this.dep.trigger())}}function Si(t){return de(t)?t.value:t}const bc={get:(t,i,e)=>i==="__v_raw"?t:Si(Reflect.get(t,i,e)),set:(t,i,e,n)=>{const s=t[i];return de(s)&&!de(e)?(s.value=e,!0):Reflect.set(t,i,e,n)}};function Xr(t){return Ii(t)?t:new Proxy(t,bc)}class yc{constructor(i,e,n){this.fn=i,this.setter=e,this._value=void 0,this.dep=new ao(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=hn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!e,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Kt!==this)return Fr(this,!0),!0}get value(){const i=this.dep.track();return Ur(this),i&&(i.version=this.dep.version),this._value}set value(i){this.setter&&this.setter(i)}}function wc(t,i,e=!1){let n,s;return It(t)?n=t:(n=t.get,s=t.set),new yc(n,s,e)}const On={},qn=new WeakMap;let wi;function kc(t,i=!1,e=wi){if(e){let n=qn.get(e);n||qn.set(e,n=[]),n.push(t)}}function xc(t,i,e=Wt){const{immediate:n,deep:s,once:r,scheduler:l,augmentJob:o,call:a}=e,c=C=>s?C:Ce(C)||s===!1||s===0?Xe(C,1):Xe(C);let d,h,p,f,w=!1,m=!1;if(de(t)?(h=()=>t.value,w=Ce(t)):Ii(t)?(h=()=>c(t),w=!0):St(t)?(m=!0,w=t.some(C=>Ii(C)||Ce(C)),h=()=>t.map(C=>{if(de(C))return C.value;if(Ii(C))return c(C);if(It(C))return a?a(C,2):C()})):It(t)?i?h=a?()=>a(t,2):t:h=()=>{if(p){ii();try{p()}finally{ni()}}const C=wi;wi=d;try{return a?a(t,3,[f]):t(f)}finally{wi=C}}:h=Ve,i&&s){const C=h,A=s===!0?1/0:s;h=()=>Xe(C(),A)}const k=Ya(),v=()=>{d.stop(),k&&k.active&&eo(k.effects,d)};if(r&&i){const C=i;i=(...A)=>{const S=C(...A);return v(),S}}let b=m?new Array(t.length).fill(On):On;const T=C=>{if(!(!(d.flags&1)||!d.dirty&&!C))if(i){const A=d.run();if(C||s||w||(m?A.some((S,I)=>Ue(S,b[I])):Ue(A,b))){p&&p();const S=wi;wi=d;try{const I=[A,b===On?void 0:m&&b[0]===On?[]:b,f];b=A,a?a(i,3,I):i(...I)}finally{wi=S}}}else d.run()};return o&&o(T),d=new zr(h),d.scheduler=l?()=>l(T,!1):T,f=C=>kc(C,!1,d),p=d.onStop=()=>{const C=qn.get(d);if(C){if(a)a(C,4);else for(const A of C)A();qn.delete(d)}},i?n?T(!0):b=d.run():l?l(T.bind(null,!0),!0):d.run(),v.pause=d.pause.bind(d),v.resume=d.resume.bind(d),v.stop=v,v}function Xe(t,i=1/0,e){if(i<=0||!jt(t)||t.__v_skip||(e=e||new Map,(e.get(t)||0)>=i))return t;if(e.set(t,i),i--,de(t))Xe(t.value,i,e);else if(St(t))for(let n=0;n<t.length;n++)Xe(t[n],i,e);else if(Zi(t)||Ni(t))t.forEach(n=>{Xe(n,i,e)});else if(Dr(t)){for(const n in t)Xe(t[n],i,e);for(const n of Object.getOwnPropertySymbols(t))Object.prototype.propertyIsEnumerable.call(t,n)&&Xe(t[n],i,e)}return t}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function xn(t,i,e,n){try{return n?t(...n):t()}catch(s){ds(s,i,e)}}function Pe(t,i,e,n){if(It(t)){const s=xn(t,i,e,n);return s&&Mr(s)&&s.catch(r=>{ds(r,i,e)}),s}if(St(t)){const s=[];for(let r=0;r<t.length;r++)s.push(Pe(t[r],i,e,n));return s}}function ds(t,i,e,n=!0){const s=i?i.vnode:null,{errorHandler:r,throwUnhandledErrorInProduction:l}=i&&i.appContext.config||Wt;if(i){let o=i.parent;const a=i.proxy,c=`https://vuejs.org/error-reference/#runtime-${e}`;for(;o;){const d=o.ec;if(d){for(let h=0;h<d.length;h++)if(d[h](t,a,c)===!1)return}o=o.parent}if(r){ii(),xn(r,null,10,[t,a,c]),ni();return}}_c(t,e,s,n,l)}function _c(t,i,e,n=!0,s=!1){if(s)throw t;console.error(t)}const pe=[];let Ne=-1;const Fi=[];let ai=null,Pi=0;const Qr=Promise.resolve();let Gn=null;function tl(t){const i=Gn||Qr;return t?i.then(this?t.bind(this):t):i}function Sc(t){let i=Ne+1,e=pe.length;for(;i<e;){const n=i+e>>>1,s=pe[n],r=gn(s);r<t||r===t&&s.flags&2?i=n+1:e=n}return i}function po(t){if(!(t.flags&1)){const i=gn(t),e=pe[pe.length-1];!e||!(t.flags&2)&&i>=gn(e)?pe.push(t):pe.splice(Sc(i),0,t),t.flags|=1,el()}}function el(){Gn||(Gn=Qr.then(nl))}function Cc(t){St(t)?Fi.push(...t):ai&&t.id===-1?ai.splice(Pi+1,0,t):t.flags&1||(Fi.push(t),t.flags|=1),el()}function jo(t,i,e=Ne+1){for(;e<pe.length;e++){const n=pe[e];if(n&&n.flags&2){if(t&&n.id!==t.uid)continue;pe.splice(e,1),e--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function il(t){if(Fi.length){const i=[...new Set(Fi)].sort((e,n)=>gn(e)-gn(n));if(Fi.length=0,ai){ai.push(...i);return}for(ai=i,Pi=0;Pi<ai.length;Pi++){const e=ai[Pi];e.flags&4&&(e.flags&=-2),e.flags&8||e(),e.flags&=-2}ai=null,Pi=0}}const gn=t=>t.id==null?t.flags&2?-1:1/0:t.id;function nl(t){try{for(Ne=0;Ne<pe.length;Ne++){const i=pe[Ne];i&&!(i.flags&8)&&(i.flags&4&&(i.flags&=-2),xn(i,i.i,i.i?15:14),i.flags&4||(i.flags&=-2))}}finally{for(;Ne<pe.length;Ne++){const i=pe[Ne];i&&(i.flags&=-2)}Ne=-1,pe.length=0,il(),Gn=null,(pe.length||Fi.length)&&nl()}}let oe=null,sl=null;function Zn(t){const i=oe;return oe=t,sl=t&&t.type.__scopeId||null,i}function ol(t,i=oe,e){if(!i||t._n)return t;const n=(...s)=>{n._d&&Qo(-1);const r=Zn(i),l=ti.length;let o;try{o=t(...s)}finally{for(let a=ti.length;a>l;a--)yo();Zn(r),n._d&&Qo(1)}return o};return n._n=!0,n._c=!0,n._d=!0,n}function Ie(t,i){if(oe===null)return t;const e=hs(oe),n=t.dirs||(t.dirs=[]);for(let s=0;s<i.length;s++){let[r,l,o,a=Wt]=i[s];r&&(It(r)&&(r={mounted:r,updated:r}),r.deep&&Xe(l),n.push({dir:r,instance:e,value:l,oldValue:void 0,arg:o,modifiers:a}))}return t}function vi(t,i,e,n){const s=t.dirs,r=i&&i.dirs;for(let l=0;l<s.length;l++){const o=s[l];r&&(o.oldValue=r[l].value);let a=o.dir[n];a&&(ii(),Pe(a,e,8,[t.el,o,t,i]),ni())}}function $c(t,i){if(ae){let e=ae.provides;const n=ae.parent&&ae.parent.provides;n===e&&(e=ae.provides=Object.create(n)),e[t]=i}}function Qe(t,i,e=!1){const n=Sd();if(n||Hi){let s=Hi?Hi._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(s&&t in s)return s[t];if(arguments.length>1)return e&&It(i)?i.call(n&&n.proxy):i}}const Ic=Symbol.for("v-scx"),Ac=()=>Qe(Ic);function Ai(t,i,e){return rl(t,i,e)}function rl(t,i,e=Wt){const{immediate:n,deep:s,flush:r,once:l}=e,o=re({},e),a=i&&n||!i&&r!=="post";let c;if(bn){if(r==="sync"){const f=Ac();c=f.__watcherHandles||(f.__watcherHandles=[])}else if(!a){const f=()=>{};return f.stop=Ve,f.resume=Ve,f.pause=Ve,f}}const d=ae;o.call=(f,w,m)=>Pe(f,d,w,m);let h=!1;r==="post"?o.scheduler=f=>{me(f,d&&d.suspense)}:r!=="sync"&&(h=!0,o.scheduler=(f,w)=>{w?f():po(f)}),o.augmentJob=f=>{i&&(f.flags|=4),h&&(f.flags|=2,d&&(f.id=d.uid,f.i=d))};const p=xc(t,i,o);return bn&&(c?c.push(p):a&&p()),p}function Tc(t,i,e){const n=this.proxy,s=Qt(t)?t.includes(".")?ll(n,t):()=>n[t]:t.bind(n,n);let r;It(i)?r=i:(r=i.handler,e=i);const l=Sn(this),o=rl(s,r.bind(n),e);return l(),o}function ll(t,i){const e=i.split(".");return()=>{let n=t;for(let s=0;s<e.length&&n;s++)n=n[e[s]];return n}}const Ec=Symbol("_vte"),Mc=t=>t.__isTeleport,Cs=Symbol("_leaveCb");function ho(t,i){t.shapeFlag&6&&t.component?(t.transition=i,ho(t.component.subTree,i)):t.shapeFlag&128?(t.ssContent.transition=i.clone(t.ssContent),t.ssFallback.transition=i.clone(t.ssFallback)):t.transition=i}function be(t,i){return It(t)?re({name:t.name},i,{setup:t}):t}function al(t){t.ids=[t.ids[0]+t.ids[2]+++"-",0,0]}function Ho(t,i){let e;return!!((e=Object.getOwnPropertyDescriptor(t,i))&&!e.configurable)}const Yn=new WeakMap;function un(t,i,e,n,s=!1){if(St(t)){t.forEach((m,k)=>un(m,i&&(St(i)?i[k]:i),e,n,s));return}if(ji(n)&&!s){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&un(t,i,e,n.component.subTree);return}const r=n.shapeFlag&4?hs(n.component):n.el,l=s?null:r,{i:o,r:a}=t,c=i&&i.r,d=o.refs===Wt?o.refs={}:o.refs,h=o.setupState,p=Lt(h),f=h===Wt?Er:m=>Ho(d,m)?!1:Rt(p,m),w=(m,k)=>!(k&&Ho(d,k));if(c!=null&&c!==a){if(Uo(i),Qt(c))d[c]=null,f(c)&&(h[c]=null);else if(de(c)){const m=i;w(c,m.k)&&(c.value=null),m.k&&(d[m.k]=null)}}if(It(a))xn(a,o,12,[l,d]);else{const m=Qt(a),k=de(a);if(m||k){const v=()=>{if(t.f){const b=m?f(a)?h[a]:d[a]:w()||!t.k?a.value:d[t.k];if(s)St(b)&&eo(b,r);else if(St(b))b.includes(r)||b.push(r);else if(m)d[a]=[r],f(a)&&(h[a]=d[a]);else{const T=[r];w(a,t.k)&&(a.value=T),t.k&&(d[t.k]=T)}}else m?(d[a]=l,f(a)&&(h[a]=l)):k&&(w(a,t.k)&&(a.value=l),t.k&&(d[t.k]=l))};if(l){const b=()=>{v(),Yn.delete(t)};b.id=-1,Yn.set(t,b),me(b,e)}else Uo(t),v()}}}function Uo(t){const i=Yn.get(t);i&&(i.flags|=8,Yn.delete(t))}ls().requestIdleCallback;ls().cancelIdleCallback;const ji=t=>!!t.type.__asyncLoader,cl=t=>t.type.__isKeepAlive;function Bc(t,i){dl(t,"a",i)}function Dc(t,i){dl(t,"da",i)}function dl(t,i,e=ae){const n=t.__wdc||(t.__wdc=()=>{let s=e;for(;s;){if(s.isDeactivated)return;s=s.parent}return t()});if(us(i,n,e),e){let s=e.parent;for(;s&&s.parent;)cl(s.parent.vnode)&&Oc(n,i,e,s),s=s.parent}}function Oc(t,i,e,n){const s=us(i,t,n,!0);go(()=>{eo(n[i],s)},e)}function us(t,i,e=ae,n=!1){if(e){const s=e[t]||(e[t]=[]),r=i.__weh||(i.__weh=(...l)=>{ii();const o=Sn(e),a=Pe(i,e,t,l);return o(),ni(),a});return n?s.unshift(r):s.push(r),r}}const ri=t=>(i,e=ae)=>{(!bn||t==="sp")&&us(t,(...n)=>i(...n),e)},Pc=ri("bm"),_n=ri("m"),Lc=ri("bu"),Rc=ri("u"),mo=ri("bum"),go=ri("um"),zc=ri("sp"),Nc=ri("rtg"),Fc=ri("rtc");function jc(t,i=ae){us("ec",t,i)}const Hc="components";function Uc(t,i){return Vc(Hc,t,!0,i)||t}const Wc=Symbol.for("v-ndc");function Vc(t,i,e=!0,n=!1){const s=oe||ae;if(s){const r=s.type;{const o=Td(r,!1);if(o&&(o===i||o===he(i)||o===os(he(i))))return r}const l=Wo(s[t]||r[t],i)||Wo(s.appContext[t],i);return!l&&n?r:l}}function Wo(t,i){return t&&(t[i]||t[he(i)]||t[os(he(i))])}function ye(t,i,e,n){let s;const r=e,l=St(t);if(l||Qt(t)){const o=l&&Ii(t);let a=!1,c=!1;o&&(a=!Ce(t),c=si(t),t=as(t)),s=new Array(t.length);for(let d=0,h=t.length;d<h;d++)s[d]=i(a?c?Vi(Oe(t[d])):Oe(t[d]):t[d],d,void 0,r)}else if(typeof t=="number"){s=new Array(t);for(let o=0;o<t;o++)s[o]=i(o+1,o,void 0,r)}else if(jt(t))if(t[Symbol.iterator])s=Array.from(t,(o,a)=>i(o,a,void 0,r));else{const o=Object.keys(t);s=new Array(o.length);for(let a=0,c=o.length;a<c;a++){const d=o[a];s[a]=i(t[d],d,a,r)}}else s=[];return s}function Pn(t,i,e={},n,s,r){if(oe.ce||oe.parent&&ji(oe.parent)&&oe.parent.ce){const c=e,d=Object.keys(c).length>0;return i!=="default"&&(c.name=i),Q(),Ee(Gt,null,[ft("slot",c,n&&n())],d?-2:64)}let l=t[i];l&&l._c&&(l._d=!1);const o=ti.length;Q();let a;try{const c=l&&ul(l(e)),d=e.key||r||c&&c.key;a=Ee(Gt,{key:(d&&!De(d)?d:`_${i}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&t._===1?64:-2)}catch(c){for(let d=ti.length;d>o;d--)yo();throw c}finally{l&&l._c&&(l._d=!0)}return a}function ul(t){return t.some(i=>wo(i)?!(i.type===oi||i.type===Gt&&!ul(i.children)):!0)?t:null}const Ws=t=>t?Ml(t)?hs(t):Ws(t.parent):null,fn=re(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>Ws(t.parent),$root:t=>Ws(t.root),$host:t=>t.ce,$emit:t=>t.emit,$options:t=>pl(t),$forceUpdate:t=>t.f||(t.f=()=>{po(t.update)}),$nextTick:t=>t.n||(t.n=tl.bind(t.proxy)),$watch:t=>Tc.bind(t)}),$s=(t,i)=>t!==Wt&&!t.__isScriptSetup&&Rt(t,i),Kc={get({_:t},i){if(i==="__v_skip")return!0;const{ctx:e,setupState:n,data:s,props:r,accessCache:l,type:o,appContext:a}=t;if(i[0]!=="$"){const p=l[i];if(p!==void 0)switch(p){case 1:return n[i];case 2:return s[i];case 4:return e[i];case 3:return r[i]}else{if($s(n,i))return l[i]=1,n[i];if(s!==Wt&&Rt(s,i))return l[i]=2,s[i];if(Rt(r,i))return l[i]=3,r[i];if(e!==Wt&&Rt(e,i))return l[i]=4,e[i];Vs&&(l[i]=0)}}const c=fn[i];let d,h;if(c)return i==="$attrs"&&le(t.attrs,"get",""),c(t);if((d=o.__cssModules)&&(d=d[i]))return d;if(e!==Wt&&Rt(e,i))return l[i]=4,e[i];if(h=a.config.globalProperties,Rt(h,i))return h[i]},set({_:t},i,e){const{data:n,setupState:s,ctx:r}=t;return $s(s,i)?(s[i]=e,!0):n!==Wt&&Rt(n,i)?(n[i]=e,!0):Rt(t.props,i)||i[0]==="$"&&i.slice(1)in t?!1:(r[i]=e,!0)},has({_:{data:t,setupState:i,accessCache:e,ctx:n,appContext:s,props:r,type:l}},o){let a;return!!(e[o]||t!==Wt&&o[0]!=="$"&&Rt(t,o)||$s(i,o)||Rt(r,o)||Rt(n,o)||Rt(fn,o)||Rt(s.config.globalProperties,o)||(a=l.__cssModules)&&a[o])},defineProperty(t,i,e){return e.get!=null?t._.accessCache[i]=0:Rt(e,"value")&&this.set(t,i,e.value,null),Reflect.defineProperty(t,i,e)}};function Vo(t){return St(t)?t.reduce((i,e)=>(i[e]=null,i),{}):t}let Vs=!0;function qc(t){const i=pl(t),e=t.proxy,n=t.ctx;Vs=!1,i.beforeCreate&&Ko(i.beforeCreate,t,"bc");const{data:s,computed:r,methods:l,watch:o,provide:a,inject:c,created:d,beforeMount:h,mounted:p,beforeUpdate:f,updated:w,activated:m,deactivated:k,beforeDestroy:v,beforeUnmount:b,destroyed:T,unmounted:C,render:A,renderTracked:S,renderTriggered:I,errorCaptured:L,serverPrefetch:R,expose:N,inheritAttrs:J,components:x,directives:q,filters:y}=i;if(c&&Gc(c,n,null),l)for(const j in l){const it=l[j];It(it)&&(n[j]=it.bind(e))}if(s){const j=s.call(e,e);jt(j)&&(t.data=cs(j))}if(Vs=!0,r)for(const j in r){const it=r[j],V=It(it)?it.bind(e,e):It(it.get)?it.get.bind(e,e):Ve,Z=!It(it)&&It(it.set)?it.set.bind(e):Ve,E=Ct({get:V,set:Z});Object.defineProperty(n,j,{enumerable:!0,configurable:!0,get:()=>E.value,set:D=>E.value=D})}if(o)for(const j in o)fl(o[j],n,e,j);if(a){const j=It(a)?a.call(e):a;Reflect.ownKeys(j).forEach(it=>{$c(it,j[it])})}d&&Ko(d,t,"c");function et(j,it){St(it)?it.forEach(V=>j(V.bind(e))):it&&j(it.bind(e))}if(et(Pc,h),et(_n,p),et(Lc,f),et(Rc,w),et(Bc,m),et(Dc,k),et(jc,L),et(Fc,S),et(Nc,I),et(mo,b),et(go,C),et(zc,R),St(N))if(N.length){const j=t.exposed||(t.exposed={});N.forEach(it=>{Object.defineProperty(j,it,{get:()=>e[it],set:V=>e[it]=V,enumerable:!0})})}else t.exposed||(t.exposed={});A&&t.render===Ve&&(t.render=A),J!=null&&(t.inheritAttrs=J),x&&(t.components=x),q&&(t.directives=q),R&&al(t)}function Gc(t,i,e=Ve){St(t)&&(t=Ks(t));for(const n in t){const s=t[n];let r;jt(s)?"default"in s?r=Qe(s.from||n,s.default,!0):r=Qe(s.from||n):r=Qe(s),de(r)?Object.defineProperty(i,n,{enumerable:!0,configurable:!0,get:()=>r.value,set:l=>r.value=l}):i[n]=r}}function Ko(t,i,e){Pe(St(t)?t.map(n=>n.bind(i.proxy)):t.bind(i.proxy),i,e)}function fl(t,i,e,n){let s=n.includes(".")?ll(e,n):()=>e[n];if(Qt(t)){const r=i[t];It(r)&&Ai(s,r)}else if(It(t))Ai(s,t.bind(e));else if(jt(t))if(St(t))t.forEach(r=>fl(r,i,e,n));else{const r=It(t.handler)?t.handler.bind(e):i[t.handler];It(r)&&Ai(s,r,t)}}function pl(t){const i=t.type,{mixins:e,extends:n}=i,{mixins:s,optionsCache:r,config:{optionMergeStrategies:l}}=t.appContext,o=r.get(i);let a;return o?a=o:!s.length&&!e&&!n?a=i:(a={},s.length&&s.forEach(c=>Jn(a,c,l,!0)),Jn(a,i,l)),jt(i)&&r.set(i,a),a}function Jn(t,i,e,n=!1){const{mixins:s,extends:r}=i;r&&Jn(t,r,e,!0),s&&s.forEach(l=>Jn(t,l,e,!0));for(const l in i)if(!(n&&l==="expose")){const o=Zc[l]||e&&e[l];t[l]=o?o(t[l],i[l]):i[l]}return t}const Zc={data:qo,props:Go,emits:Go,methods:en,computed:en,beforeCreate:ue,created:ue,beforeMount:ue,mounted:ue,beforeUpdate:ue,updated:ue,beforeDestroy:ue,beforeUnmount:ue,destroyed:ue,unmounted:ue,activated:ue,deactivated:ue,errorCaptured:ue,serverPrefetch:ue,components:en,directives:en,watch:Jc,provide:qo,inject:Yc};function qo(t,i){return i?t?function(){return re(It(t)?t.call(this,this):t,It(i)?i.call(this,this):i)}:i:t}function Yc(t,i){return en(Ks(t),Ks(i))}function Ks(t){if(St(t)){const i={};for(let e=0;e<t.length;e++)i[t[e]]=t[e];return i}return t}function ue(t,i){return t?[...new Set([].concat(t,i))]:i}function en(t,i){return t?re(Object.create(null),t,i):i}function Go(t,i){return t?St(t)&&St(i)?[...new Set([...t,...i])]:re(Object.create(null),Vo(t),Vo(i??{})):i}function Jc(t,i){if(!t)return i;if(!i)return t;const e=re(Object.create(null),t);for(const n in i)e[n]=ue(t[n],i[n]);return e}function hl(){return{app:null,config:{isNativeTag:Er,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Xc=0;function Qc(t,i){return function(n,s=null){It(n)||(n=re({},n)),s!=null&&!jt(s)&&(s=null);const r=hl(),l=new WeakSet,o=[];let a=!1;const c=r.app={_uid:Xc++,_component:n,_props:s,_container:null,_context:r,_instance:null,version:Md,get config(){return r.config},set config(d){},use(d,...h){return l.has(d)||(d&&It(d.install)?(l.add(d),d.install(c,...h)):It(d)&&(l.add(d),d(c,...h))),c},mixin(d){return r.mixins.includes(d)||r.mixins.push(d),c},component(d,h){return h?(r.components[d]=h,c):r.components[d]},directive(d,h){return h?(r.directives[d]=h,c):r.directives[d]},mount(d,h,p){if(!a){const f=c._ceVNode||ft(n,s);return f.appContext=r,p===!0?p="svg":p===!1&&(p=void 0),t(f,d,p),a=!0,c._container=d,d.__vue_app__=c,hs(f.component)}},onUnmount(d){o.push(d)},unmount(){a&&(Pe(o,c._instance,16),t(null,c._container),delete c._container.__vue_app__)},provide(d,h){return r.provides[d]=h,c},runWithContext(d){const h=Hi;Hi=c;try{return d()}finally{Hi=h}}};return c}}let Hi=null;const td=(t,i)=>i==="modelValue"||i==="model-value"?t.modelModifiers:t[`${i}Modifiers`]||t[`${he(i)}Modifiers`]||t[`${hi(i)}Modifiers`];function ed(t,i,...e){if(t.isUnmounted)return;const n=t.vnode.props||Wt;let s=e;const r=i.startsWith("update:"),l=r&&td(n,i.slice(7));l&&(l.trim&&(s=e.map(d=>Qt(d)?d.trim():d)),l.number&&(s=e.map(rs)));let o,a=n[o=ws(i)]||n[o=ws(he(i))];!a&&r&&(a=n[o=ws(hi(i))]),a&&Pe(a,t,6,s);const c=n[o+"Once"];if(c){if(!t.emitted)t.emitted={};else if(t.emitted[o])return;t.emitted[o]=!0,Pe(c,t,6,s)}}const id=new WeakMap;function ml(t,i,e=!1){const n=e?id:i.emitsCache,s=n.get(t);if(s!==void 0)return s;const r=t.emits;let l={},o=!1;if(!It(t)){const a=c=>{const d=ml(c,i,!0);d&&(o=!0,re(l,d))};!e&&i.mixins.length&&i.mixins.forEach(a),t.extends&&a(t.extends),t.mixins&&t.mixins.forEach(a)}return!r&&!o?(jt(t)&&n.set(t,null),null):(St(r)?r.forEach(a=>l[a]=null):re(l,r),jt(t)&&n.set(t,l),l)}function fs(t,i){return!t||!is(i)?!1:(i=i.slice(2),i=i==="Once"?i:i.replace(/Once$/,""),Rt(t,i[0].toLowerCase()+i.slice(1))||Rt(t,hi(i))||Rt(t,i))}function Zo(t){const{type:i,vnode:e,proxy:n,withProxy:s,propsOptions:[r],slots:l,attrs:o,emit:a,render:c,renderCache:d,props:h,data:p,setupState:f,ctx:w,inheritAttrs:m}=t,k=Zn(t);let v,b;try{if(e.shapeFlag&4){const C=s||n,A=C;v=je(c.call(A,C,d,h,f,p,w)),b=o}else{const C=i;v=je(C.length>1?C(h,{attrs:o,slots:l,emit:a}):C(h,null)),b=i.props?o:nd(o)}}catch(C){ti.length=0,ds(C,t,1),v=ft(oi)}let T=v;if(b&&m!==!1){const C=Object.keys(b),{shapeFlag:A}=T;C.length&&A&7&&(r&&C.some(ns)&&(b=sd(b,r)),T=Ki(T,b,!1,!0))}return e.dirs&&(T=Ki(T,null,!1,!0),T.dirs=T.dirs?T.dirs.concat(e.dirs):e.dirs),e.transition&&ho(T,e.transition),v=T,Zn(k),v}const nd=t=>{let i;for(const e in t)(e==="class"||e==="style"||is(e))&&((i||(i={}))[e]=t[e]);return i},sd=(t,i)=>{const e={};for(const n in t)(!ns(n)||!(n.slice(9)in i))&&(e[n]=t[n]);return e};function od(t,i,e){const{props:n,children:s,component:r}=t,{props:l,children:o,patchFlag:a}=i,c=r.emitsOptions;if(i.dirs||i.transition)return!0;if(e&&a>=0){if(a&1024)return!0;if(a&16)return n?Yo(n,l,c):!!l;if(a&8){const d=i.dynamicProps;for(let h=0;h<d.length;h++){const p=d[h];if(gl(l,n,p)&&!fs(c,p))return!0}}}else return(s||o)&&(!o||!o.$stable)?!0:n===l?!1:n?l?Yo(n,l,c):!0:!!l;return!1}function Yo(t,i,e){const n=Object.keys(i);if(n.length!==Object.keys(t).length)return!0;for(let s=0;s<n.length;s++){const r=n[s];if(gl(i,t,r)&&!fs(e,r))return!0}return!1}function gl(t,i,e){const n=t[e],s=i[e];return e==="style"&&jt(n)&&jt(s)?!Yi(n,s):n!==s}function rd({vnode:t,parent:i,suspense:e},n){for(;i;){const s=i.subTree;if(s.suspense&&s.suspense.activeBranch===t&&(s.suspense.vnode.el=s.el=n,t=s),s===t)(t=i.vnode).el=n,i=i.parent;else break}e&&e.activeBranch===t&&(e.vnode.el=n)}const vl={},bl=()=>Object.create(vl),yl=t=>Object.getPrototypeOf(t)===vl;function ld(t,i,e,n=!1){const s={},r=bl();t.propsDefaults=Object.create(null),wl(t,i,s,r);for(const l in t.propsOptions[0])l in s||(s[l]=void 0);e?t.props=n?s:hc(s):t.type.props?t.props=s:t.props=r,t.attrs=r}function ad(t,i,e,n){const{props:s,attrs:r,vnode:{patchFlag:l}}=t,o=Lt(s),[a]=t.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const d=t.vnode.dynamicProps;for(let h=0;h<d.length;h++){let p=d[h];if(fs(t.emitsOptions,p))continue;const f=i[p];if(a)if(Rt(r,p))f!==r[p]&&(r[p]=f,c=!0);else{const w=he(p);s[w]=qs(a,o,w,f,t,!1)}else f!==r[p]&&(r[p]=f,c=!0)}}}else{wl(t,i,s,r)&&(c=!0);let d;for(const h in o)(!i||!Rt(i,h)&&((d=hi(h))===h||!Rt(i,d)))&&(a?e&&(e[h]!==void 0||e[d]!==void 0)&&(s[h]=qs(a,o,h,void 0,t,!0)):delete s[h]);if(r!==o)for(const h in r)(!i||!Rt(i,h))&&(delete r[h],c=!0)}c&&Je(t.attrs,"set","")}function wl(t,i,e,n){const[s,r]=t.propsOptions;let l=!1,o;if(i)for(let a in i){if(an(a))continue;const c=i[a];let d;s&&Rt(s,d=he(a))?!r||!r.includes(d)?e[d]=c:(o||(o={}))[d]=c:fs(t.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(r){const a=Lt(e),c=o||Wt;for(let d=0;d<r.length;d++){const h=r[d];e[h]=qs(s,a,h,c[h],t,!Rt(c,h))}}return l}function qs(t,i,e,n,s,r){const l=t[e];if(l!=null){const o=Rt(l,"default");if(o&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&It(a)){const{propsDefaults:c}=s;if(e in c)n=c[e];else{const d=Sn(s);n=c[e]=a.call(null,i),d()}}else n=a;s.ce&&s.ce._setProp(e,n)}l[0]&&(r&&!o?n=!1:l[1]&&(n===""||n===hi(e))&&(n=!0))}return n}const cd=new WeakMap;function kl(t,i,e=!1){const n=e?cd:i.propsCache,s=n.get(t);if(s)return s;const r=t.props,l={},o=[];let a=!1;if(!It(t)){const d=h=>{a=!0;const[p,f]=kl(h,i,!0);re(l,p),f&&o.push(...f)};!e&&i.mixins.length&&i.mixins.forEach(d),t.extends&&d(t.extends),t.mixins&&t.mixins.forEach(d)}if(!r&&!a)return jt(t)&&n.set(t,zi),zi;if(St(r))for(let d=0;d<r.length;d++){const h=he(r[d]);Jo(h)&&(l[h]=Wt)}else if(r)for(const d in r){const h=he(d);if(Jo(h)){const p=r[d],f=l[h]=St(p)||It(p)?{type:p}:re({},p),w=f.type;let m=!1,k=!0;if(St(w))for(let v=0;v<w.length;++v){const b=w[v],T=It(b)&&b.name;if(T==="Boolean"){m=!0;break}else T==="String"&&(k=!1)}else m=It(w)&&w.name==="Boolean";f[0]=m,f[1]=k,(m||Rt(f,"default"))&&o.push(h)}}const c=[l,o];return jt(t)&&n.set(t,c),c}function Jo(t){return t[0]!=="$"&&!an(t)}const vo=t=>t==="_"||t==="_ctx"||t==="$stable",bo=t=>St(t)?t.map(je):[je(t)],dd=(t,i,e)=>{if(i._n)return i;const n=ol((...s)=>bo(i(...s)),e);return n._c=!1,n},xl=(t,i,e)=>{const n=t._ctx;for(const s in t){if(vo(s))continue;const r=t[s];if(It(r))i[s]=dd(s,r,n);else if(r!=null){const l=bo(r);i[s]=()=>l}}},_l=(t,i)=>{const e=bo(i);t.slots.default=()=>e},Sl=(t,i,e)=>{for(const n in i)(e||!vo(n))&&(t[n]=i[n])},ud=(t,i,e)=>{const n=t.slots=bl();if(t.vnode.shapeFlag&32){const s=i._;s?(Sl(n,i,e),e&&Or(n,"_",s,!0)):xl(i,n)}else i&&_l(t,i)},fd=(t,i,e)=>{const{vnode:n,slots:s}=t;let r=!0,l=Wt;if(n.shapeFlag&32){const o=i._;o?e&&o===1?r=!1:Sl(s,i,e):(r=!i.$stable,xl(i,s)),l=i}else i&&(_l(t,i),l={default:1});if(r)for(const o in s)!vo(o)&&l[o]==null&&delete s[o]},me=vd;function pd(t){return hd(t)}function hd(t,i){const e=ls();e.__VUE__=!0;const{insert:n,remove:s,patchProp:r,createElement:l,createText:o,createComment:a,setText:c,setElementText:d,parentNode:h,nextSibling:p,setScopeId:f=Ve,insertStaticContent:w}=t,m=(M,P,u,z=null,O=null,_=null,$=void 0,B=null,W=!!P.dynamicChildren)=>{if(M===P)return;M&&!Xi(M,P)&&(z=$t(M),D(M,O,_,!0),M=null),P.patchFlag===-2&&(W=!1,P.dynamicChildren=null);const{type:F,ref:H,shapeFlag:G}=P;switch(F){case ps:k(M,P,u,z);break;case oi:v(M,P,u,z);break;case jn:M==null&&b(P,u,z,$);break;case Gt:x(M,P,u,z,O,_,$,B,W);break;default:G&1?A(M,P,u,z,O,_,$,B,W):G&6?q(M,P,u,z,O,_,$,B,W):(G&64||G&128)&&F.process(M,P,u,z,O,_,$,B,W,lt)}H!=null&&O?un(H,M&&M.ref,_,P||M,!P):H==null&&M&&M.ref!=null&&un(M.ref,null,_,M,!0)},k=(M,P,u,z)=>{if(M==null)n(P.el=o(P.children),u,z);else{const O=P.el=M.el;P.children!==M.children&&c(O,P.children)}},v=(M,P,u,z)=>{M==null?n(P.el=a(P.children||""),u,z):P.el=M.el},b=(M,P,u,z)=>{[M.el,M.anchor]=w(M.children,P,u,z,M.el,M.anchor)},T=({el:M,anchor:P},u,z)=>{let O;for(;M&&M!==P;)O=p(M),n(M,u,z),M=O;n(P,u,z)},C=({el:M,anchor:P})=>{let u;for(;M&&M!==P;)u=p(M),s(M),M=u;s(P)},A=(M,P,u,z,O,_,$,B,W)=>{if(P.type==="svg"?$="svg":P.type==="math"&&($="mathml"),M==null)S(P,u,z,O,_,$,B,W);else{const F=M.el&&M.el._isVueCE?M.el:null;try{F&&F._beginPatch(),R(M,P,O,_,$,B,W)}finally{F&&F._endPatch()}}},S=(M,P,u,z,O,_,$,B)=>{let W,F;const{props:H,shapeFlag:G,transition:tt,dirs:X}=M;if(W=M.el=l(M.type,_,H&&H.is,H),G&8?d(W,M.children):G&16&&L(M.children,W,null,z,O,Is(M,_),$,B),X&&vi(M,null,z,"created"),I(W,M,M.scopeId,$,z),H){for(const wt in H)wt!=="value"&&!an(wt)&&r(W,wt,null,H[wt],_,z);"value"in H&&r(W,"value",null,H.value,_),(F=H.onVnodeBeforeMount)&&ze(F,z,M)}X&&vi(M,null,z,"beforeMount");const ct=md(O,tt);ct&&tt.beforeEnter(W),n(W,P,u),((F=H&&H.onVnodeMounted)||ct||X)&&me(()=>{try{F&&ze(F,z,M),ct&&tt.enter(W),X&&vi(M,null,z,"mounted")}finally{}},O)},I=(M,P,u,z,O)=>{if(u&&f(M,u),z)for(let _=0;_<z.length;_++)f(M,z[_]);if(O){let _=O.subTree;if(P===_||Al(_.type)&&(_.ssContent===P||_.ssFallback===P)){const $=O.vnode;I(M,$,$.scopeId,$.slotScopeIds,O.parent)}}},L=(M,P,u,z,O,_,$,B,W=0)=>{for(let F=W;F<M.length;F++){const H=M[F]=B?Ye(M[F]):je(M[F]);m(null,H,P,u,z,O,_,$,B)}},R=(M,P,u,z,O,_,$)=>{const B=P.el=M.el;let{patchFlag:W,dynamicChildren:F,dirs:H}=P;W|=M.patchFlag&16;const G=M.props||Wt,tt=P.props||Wt;let X;if(u&&bi(u,!1),(X=tt.onVnodeBeforeUpdate)&&ze(X,u,P,M),H&&vi(P,M,u,"beforeUpdate"),u&&bi(u,!0),F&&(!M.dynamicChildren||M.dynamicChildren.length!==F.length)&&(W=0,$=!1,F=null),(G.innerHTML&&tt.innerHTML==null||G.textContent&&tt.textContent==null)&&d(B,""),F?N(M.dynamicChildren,F,B,u,z,Is(P,O),_):$||it(M,P,B,null,u,z,Is(P,O),_,!1),W>0){if(W&16)J(B,G,tt,u,O);else if(W&2&&G.class!==tt.class&&r(B,"class",null,tt.class,O),W&4&&r(B,"style",G.style,tt.style,O),W&8){const ct=P.dynamicProps;for(let wt=0;wt<ct.length;wt++){const mt=ct[wt],Mt=G[mt],Vt=tt[mt];(Vt!==Mt||mt==="value")&&r(B,mt,Mt,Vt,O,u)}}W&1&&M.children!==P.children&&d(B,P.children)}else!$&&F==null&&J(B,G,tt,u,O);((X=tt.onVnodeUpdated)||H)&&me(()=>{X&&ze(X,u,P,M),H&&vi(P,M,u,"updated")},z)},N=(M,P,u,z,O,_,$)=>{for(let B=0;B<P.length;B++){const W=M[B],F=P[B],H=W.el&&(W.type===Gt||!Xi(W,F)||W.shapeFlag&198)?h(W.el):u;m(W,F,H,null,z,O,_,$,!0)}},J=(M,P,u,z,O)=>{if(P!==u){if(P!==Wt)for(const _ in P)!an(_)&&!(_ in u)&&r(M,_,P[_],null,O,z);for(const _ in u){if(an(_))continue;const $=u[_],B=P[_];$!==B&&_!=="value"&&r(M,_,B,$,O,z)}"value"in u&&r(M,"value",P.value,u.value,O)}},x=(M,P,u,z,O,_,$,B,W)=>{const F=P.el=M?M.el:o(""),H=P.anchor=M?M.anchor:o("");let{patchFlag:G,dynamicChildren:tt,slotScopeIds:X}=P;X&&(B=B?B.concat(X):X),M==null?(n(F,u,z),n(H,u,z),L(P.children||[],u,H,O,_,$,B,W)):G>0&&G&64&&tt&&M.dynamicChildren&&M.dynamicChildren.length===tt.length?(N(M.dynamicChildren,tt,u,O,_,$,B),(P.key!=null||O&&P===O.subTree)&&Cl(M,P,!0)):it(M,P,u,H,O,_,$,B,W)},q=(M,P,u,z,O,_,$,B,W)=>{P.slotScopeIds=B,M==null?P.shapeFlag&512?O.ctx.activate(P,u,z,$,W):y(P,u,z,O,_,$,W):U(M,P,W)},y=(M,P,u,z,O,_,$)=>{const B=M.component=_d(M,z,O);if(cl(M)&&(B.ctx.renderer=lt),Cd(B,!1,$),B.asyncDep){if(O&&O.registerDep(B,et,$),!M.el){const W=B.subTree=ft(oi);v(null,W,P,u),M.placeholder=W.el}}else et(B,M,P,u,O,_,$)},U=(M,P,u)=>{const z=P.component=M.component;if(od(M,P,u))if(z.asyncDep&&!z.asyncResolved){j(z,P,u);return}else z.next=P,z.update();else P.el=M.el,z.vnode=P},et=(M,P,u,z,O,_,$)=>{const B=()=>{if(M.isMounted){let{next:G,bu:tt,u:X,parent:ct,vnode:wt}=M;{const ee=$l(M);if(ee){G&&(G.el=wt.el,j(M,G,$)),ee.asyncDep.then(()=>{me(()=>{M.isUnmounted||F()},O)});return}}let mt=G,Mt;bi(M,!1),G?(G.el=wt.el,j(M,G,$)):G=wt,tt&&Fn(tt),(Mt=G.props&&G.props.onVnodeBeforeUpdate)&&ze(Mt,ct,G,wt),bi(M,!0);const Vt=Zo(M),Yt=M.subTree;M.subTree=Vt,m(Yt,Vt,h(Yt.el),$t(Yt),M,O,_),G.el=Vt.el,mt===null&&rd(M,Vt.el),X&&me(X,O),(Mt=G.props&&G.props.onVnodeUpdated)&&me(()=>ze(Mt,ct,G,wt),O)}else{let G;const{el:tt,props:X}=P,{bm:ct,m:wt,parent:mt,root:Mt,type:Vt}=M,Yt=ji(P);bi(M,!1),ct&&Fn(ct),!Yt&&(G=X&&X.onVnodeBeforeMount)&&ze(G,mt,P),bi(M,!0);{Mt.ce&&Mt.ce._hasShadowRoot()&&Mt.ce._injectChildStyle(Vt,M.parent?M.parent.type:void 0);const ee=M.subTree=Zo(M);m(null,ee,u,z,M,O,_),P.el=ee.el}if(wt&&me(wt,O),!Yt&&(G=X&&X.onVnodeMounted)){const ee=P;me(()=>ze(G,mt,ee),O)}(P.shapeFlag&256||mt&&ji(mt.vnode)&&mt.vnode.shapeFlag&256)&&M.a&&me(M.a,O),M.isMounted=!0,P=u=z=null}};M.scope.on();const W=M.effect=new zr(B);M.scope.off();const F=M.update=W.run.bind(W),H=M.job=W.runIfDirty.bind(W);H.i=M,H.id=M.uid,W.scheduler=()=>po(H),bi(M,!0),F()},j=(M,P,u)=>{P.component=M;const z=M.vnode.props;M.vnode=P,M.next=null,ad(M,P.props,z,u),fd(M,P.children,u),ii(),jo(M),ni()},it=(M,P,u,z,O,_,$,B,W=!1)=>{const F=M&&M.children,H=M?M.shapeFlag:0,G=P.children,{patchFlag:tt,shapeFlag:X}=P;if(tt>0){if(tt&128){Z(F,G,u,z,O,_,$,B,W);return}else if(tt&256){V(F,G,u,z,O,_,$,B,W);return}}X&8?(H&16&&kt(F,O,_),G!==F&&d(u,G)):H&16?X&16?Z(F,G,u,z,O,_,$,B,W):kt(F,O,_,!0):(H&8&&d(u,""),X&16&&L(G,u,z,O,_,$,B,W))},V=(M,P,u,z,O,_,$,B,W)=>{M=M||zi,P=P||zi;const F=M.length,H=P.length,G=Math.min(F,H);let tt;for(tt=0;tt<G;tt++){const X=P[tt]=W?Ye(P[tt]):je(P[tt]);m(M[tt],X,u,null,O,_,$,B,W)}F>H?kt(M,O,_,!0,!1,G):L(P,u,z,O,_,$,B,W,G)},Z=(M,P,u,z,O,_,$,B,W)=>{let F=0;const H=P.length;let G=M.length-1,tt=H-1;for(;F<=G&&F<=tt;){const X=M[F],ct=P[F]=W?Ye(P[F]):je(P[F]);if(Xi(X,ct))m(X,ct,u,null,O,_,$,B,W);else break;F++}for(;F<=G&&F<=tt;){const X=M[G],ct=P[tt]=W?Ye(P[tt]):je(P[tt]);if(Xi(X,ct))m(X,ct,u,null,O,_,$,B,W);else break;G--,tt--}if(F>G){if(F<=tt){const X=tt+1,ct=X<H?P[X].el:z;for(;F<=tt;)m(null,P[F]=W?Ye(P[F]):je(P[F]),u,ct,O,_,$,B,W),F++}}else if(F>tt)for(;F<=G;)D(M[F],O,_,!0),F++;else{const X=F,ct=F,wt=new Map;for(F=ct;F<=tt;F++){const te=P[F]=W?Ye(P[F]):je(P[F]);te.key!=null&&wt.set(te.key,F)}let mt,Mt=0;const Vt=tt-ct+1;let Yt=!1,ee=0;const Nt=new Array(Vt);for(F=0;F<Vt;F++)Nt[F]=0;for(F=X;F<=G;F++){const te=M[F];if(Mt>=Vt){D(te,O,_,!0);continue}let Jt;if(te.key!=null)Jt=wt.get(te.key);else for(mt=ct;mt<=tt;mt++)if(Nt[mt-ct]===0&&Xi(te,P[mt])){Jt=mt;break}Jt===void 0?D(te,O,_,!0):(Nt[Jt-ct]=F+1,Jt>=ee?ee=Jt:Yt=!0,m(te,P[Jt],u,null,O,_,$,B,W),Mt++)}const Ke=Yt?gd(Nt):zi;for(mt=Ke.length-1,F=Vt-1;F>=0;F--){const te=ct+F,Jt=P[te],mi=P[te+1],Mi=te+1<H?mi.el||Il(mi):z;Nt[F]===0?m(null,Jt,u,Mi,O,_,$,B,W):Yt&&(mt<0||F!==Ke[mt]?E(Jt,u,Mi,2):mt--)}}},E=(M,P,u,z,O=null)=>{const{el:_,type:$,transition:B,children:W,shapeFlag:F}=M;if(F&6){E(M.component.subTree,P,u,z);return}if(F&128){M.suspense.move(P,u,z);return}if(F&64){$.move(M,P,u,lt);return}if($===Gt){n(_,P,u);for(let G=0;G<W.length;G++)E(W[G],P,u,z);n(M.anchor,P,u);return}if($===jn){T(M,P,u);return}if(z!==2&&F&1&&B)if(z===0)B.persisted&&!_[Cs]?n(_,P,u):(B.beforeEnter(_),n(_,P,u),me(()=>B.enter(_),O));else{const{leave:G,delayLeave:tt,afterLeave:X}=B,ct=()=>{M.ctx.isUnmounted?s(_):n(_,P,u)},wt=()=>{const mt=_._isLeaving||!!_[Cs];_._isLeaving&&_[Cs](!0),B.persisted&&!mt?ct():G(_,()=>{ct(),X&&X()})};tt?tt(_,ct,wt):wt()}else n(_,P,u)},D=(M,P,u,z=!1,O=!1)=>{const{type:_,props:$,ref:B,children:W,dynamicChildren:F,shapeFlag:H,patchFlag:G,dirs:tt,cacheIndex:X,memo:ct}=M;if(G===-2&&(O=!1),B!=null&&(ii(),un(B,null,u,M,!0),ni()),X!=null&&(P.renderCache[X]=void 0),H&256){P.ctx.deactivate(M);return}const wt=H&1&&tt,mt=!ji(M);let Mt;if(mt&&(Mt=$&&$.onVnodeBeforeUnmount)&&ze(Mt,P,M),H&6)st(M.component,u,z);else{if(H&128){M.suspense.unmount(u,z);return}wt&&vi(M,null,P,"beforeUnmount"),H&64?M.type.remove(M,P,u,lt,z):F&&!F.hasOnce&&(_!==Gt||G>0&&G&64)?kt(F,P,u,!1,!0):(_===Gt&&G&384||!O&&H&16)&&kt(W,P,u),z&&ot(M)}const Vt=ct!=null&&X==null;(mt&&(Mt=$&&$.onVnodeUnmounted)||wt||Vt)&&me(()=>{Mt&&ze(Mt,P,M),wt&&vi(M,null,P,"unmounted"),Vt&&(M.el=null)},u)},ot=M=>{const{type:P,el:u,anchor:z,transition:O}=M;if(P===Gt){rt(u,z);return}if(P===jn){C(M);return}const _=()=>{s(u),O&&!O.persisted&&O.afterLeave&&O.afterLeave()};if(M.shapeFlag&1&&O&&!O.persisted){const{leave:$,delayLeave:B}=O,W=()=>$(u,_);B?B(M.el,_,W):W()}else _()},rt=(M,P)=>{let u;for(;M!==P;)u=p(M),s(M),M=u;s(P)},st=(M,P,u)=>{const{bum:z,scope:O,job:_,subTree:$,um:B,m:W,a:F}=M;Xo(W),Xo(F),z&&Fn(z),O.stop(),_&&(_.flags|=8,D($,M,P,u)),B&&me(B,P),me(()=>{M.isUnmounted=!0},P)},kt=(M,P,u,z=!1,O=!1,_=0)=>{for(let $=_;$<M.length;$++)D(M[$],P,u,z,O)},$t=M=>{if(M.shapeFlag&6)return $t(M.component.subTree);if(M.shapeFlag&128)return M.suspense.next();const P=p(M.anchor||M.el),u=P&&P[Ec];return u?p(u):P};let yt=!1;const Y=(M,P,u)=>{let z;M==null?P._vnode&&(D(P._vnode,null,null,!0),z=P._vnode.component):m(P._vnode||null,M,P,null,null,null,u),P._vnode=M,yt||(yt=!0,jo(z),il(),yt=!1)},lt={p:m,um:D,m:E,r:ot,mt:y,mc:L,pc:it,pbc:N,n:$t,o:t};return{render:Y,hydrate:void 0,createApp:Qc(Y)}}function Is({type:t,props:i},e){return e==="svg"&&t==="foreignObject"||e==="mathml"&&t==="annotation-xml"&&i&&i.encoding&&i.encoding.includes("html")?void 0:e}function bi({effect:t,job:i},e){e?(t.flags|=32,i.flags|=4):(t.flags&=-33,i.flags&=-5)}function md(t,i){return(!t||t&&!t.pendingBranch)&&i&&!i.persisted}function Cl(t,i,e=!1){const n=t.children,s=i.children;if(St(n)&&St(s))for(let r=0;r<n.length;r++){const l=n[r];let o=s[r];o.shapeFlag&1&&!o.dynamicChildren&&((o.patchFlag<=0||o.patchFlag===32)&&(o=s[r]=Ye(s[r]),o.el=l.el),!e&&o.patchFlag!==-2&&Cl(l,o)),o.type===ps&&(o.patchFlag===-1&&(o=s[r]=Ye(o)),o.el=l.el),o.type===oi&&!o.el&&(o.el=l.el)}}function gd(t){const i=t.slice(),e=[0];let n,s,r,l,o;const a=t.length;for(n=0;n<a;n++){const c=t[n];if(c!==0){if(s=e[e.length-1],t[s]<c){i[n]=s,e.push(n);continue}for(r=0,l=e.length-1;r<l;)o=r+l>>1,t[e[o]]<c?r=o+1:l=o;c<t[e[r]]&&(r>0&&(i[n]=e[r-1]),e[r]=n)}}for(r=e.length,l=e[r-1];r-- >0;)e[r]=l,l=i[l];return e}function $l(t){const i=t.subTree.component;if(i)return i.asyncDep&&!i.asyncResolved?i:$l(i)}function Xo(t){if(t)for(let i=0;i<t.length;i++)t[i].flags|=8}function Il(t){if(t.placeholder)return t.placeholder;const i=t.component;return i?Il(i.subTree):null}const Al=t=>t.__isSuspense;function vd(t,i){i&&i.pendingBranch?St(t)?i.effects.push(...t):i.effects.push(t):Cc(t)}const Gt=Symbol.for("v-fgt"),ps=Symbol.for("v-txt"),oi=Symbol.for("v-cmt"),jn=Symbol.for("v-stc"),ti=[];let we=null;function Q(t=!1){ti.push(we=t?null:[])}function yo(){ti.pop(),we=ti[ti.length-1]||null}let vn=1;function Qo(t,i=!1){vn+=t,t<0&&we&&i&&(we.hasOnce=!0)}function Tl(t){return t.dynamicChildren=vn>0?we||zi:null,yo(),vn>0&&we&&we.push(t),t}function nt(t,i,e,n,s,r){return Tl(g(t,i,e,n,s,r,!0))}function Ee(t,i,e,n,s){return Tl(ft(t,i,e,n,s,!0))}function wo(t){return t?t.__v_isVNode===!0:!1}function Xi(t,i){return t.type===i.type&&t.key===i.key}const El=({key:t})=>t??null,Hn=({ref:t,ref_key:i,ref_for:e})=>(typeof t=="number"&&(t=""+t),t!=null?Qt(t)||de(t)||It(t)?{i:oe,r:t,k:i,f:!!e}:t:null);function g(t,i=null,e=null,n=0,s=null,r=t===Gt?0:1,l=!1,o=!1){const a={__v_isVNode:!0,__v_skip:!0,type:t,props:i,key:i&&El(i),ref:i&&Hn(i),scopeId:sl,slotScopeIds:null,children:e,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:r,patchFlag:n,dynamicProps:s,dynamicChildren:null,appContext:null,ctx:oe};return o?(Xn(a,e),r&128&&t.normalize(a)):e&&(a.shapeFlag|=Qt(e)?8:16),vn>0&&!l&&we&&(a.patchFlag>0||r&6)&&a.patchFlag!==32&&we.push(a),a}const ft=bd;function bd(t,i=null,e=null,n=0,s=null,r=!1){if((!t||t===Wc)&&(t=oi),wo(t)){const o=Ki(t,i,!0);return e&&Xn(o,e),vn>0&&!r&&we&&(o.shapeFlag&6?we[we.indexOf(t)]=o:we.push(o)),o.patchFlag=-2,o}if(Ed(t)&&(t=t.__vccOpts),i){i=yd(i);let{class:o,style:a}=i;o&&!Qt(o)&&(i.class=Et(o)),jt(a)&&(fo(a)&&!St(a)&&(a=re({},a)),i.style=no(a))}const l=Qt(t)?1:Al(t)?128:Mc(t)?64:jt(t)?4:It(t)?2:0;return g(t,i,e,n,s,l,r,!0)}function yd(t){return t?fo(t)||yl(t)?re({},t):t:null}function Ki(t,i,e=!1,n=!1){const{props:s,ref:r,patchFlag:l,children:o,transition:a}=t,c=i?wd(s||{},i):s,d={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&El(c),ref:i&&i.ref?e&&r?St(r)?r.concat(Hn(i)):[r,Hn(i)]:Hn(i):r,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:o,target:t.target,targetStart:t.targetStart,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:i&&t.type!==Gt?l===-1?16:l|16:l,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:a,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&Ki(t.ssContent),ssFallback:t.ssFallback&&Ki(t.ssFallback),placeholder:t.placeholder,el:t.el,anchor:t.anchor,ctx:t.ctx,ce:t.ce};return a&&n&&ho(d,a.clone(d)),d}function Gs(t=" ",i=0){return ft(ps,null,t,i)}function $e(t,i){const e=ft(jn,null,t);return e.staticCount=i,e}function Ft(t="",i=!1){return i?(Q(),Ee(oi,null,t)):ft(oi,null,t)}function je(t){return t==null||typeof t=="boolean"?ft(oi):St(t)?ft(Gt,null,t.slice()):wo(t)?Ye(t):ft(ps,null,String(t))}function Ye(t){return t.el===null&&t.patchFlag!==-1||t.memo?t:Ki(t)}function Xn(t,i){let e=0;const{shapeFlag:n}=t;if(i==null)i=null;else if(St(i))e=16;else if(typeof i=="object")if(n&65){const s=i.default;s&&(s._c&&(s._d=!1),Xn(t,s()),s._c&&(s._d=!0));return}else{e=32;const s=i._;!s&&!yl(i)?i._ctx=oe:s===3&&oe&&(oe.slots._===1?i._=1:(i._=2,t.patchFlag|=1024))}else if(It(i)){if(n&65){Xn(t,{default:i});return}i={default:i,_ctx:oe},e=32}else i=String(i),n&64?(e=16,i=[Gs(i)]):e=8;t.children=i,t.shapeFlag|=e}function wd(...t){const i={};for(let e=0;e<t.length;e++){const n=t[e];for(const s in n)if(s==="class")i.class!==n.class&&(i.class=Et([i.class,n.class]));else if(s==="style")i.style=no([i.style,n.style]);else if(is(s)){const r=i[s],l=n[s];l&&r!==l&&!(St(r)&&r.includes(l))?i[s]=r?[].concat(r,l):l:l==null&&r==null&&!ns(s)&&(i[s]=l)}else s!==""&&(i[s]=n[s])}return i}function ze(t,i,e,n=null){Pe(t,i,7,[e,n])}const kd=hl();let xd=0;function _d(t,i,e){const n=t.type,s=(i?i.appContext:t.appContext)||kd,r={uid:xd++,vnode:t,type:n,parent:i,appContext:s,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Za(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:i?i.provides:Object.create(s.provides),ids:i?i.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:kl(n,s),emitsOptions:ml(n,s),emit:null,emitted:null,propsDefaults:Wt,inheritAttrs:n.inheritAttrs,ctx:Wt,data:Wt,props:Wt,attrs:Wt,slots:Wt,refs:Wt,setupState:Wt,setupContext:null,suspense:e,suspenseId:e?e.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return r.ctx={_:r},r.root=i?i.root:r,r.emit=ed.bind(null,r),t.ce&&t.ce(r),r}let ae=null;const Sd=()=>ae||oe;let Qn,Zs;{const t=ls(),i=(e,n)=>{let s;return(s=t[e])||(s=t[e]=[]),s.push(n),r=>{s.length>1?s.forEach(l=>l(r)):s[0](r)}};Qn=i("__VUE_INSTANCE_SETTERS__",e=>ae=e),Zs=i("__VUE_SSR_SETTERS__",e=>bn=e)}const Sn=t=>{const i=ae;return Qn(t),t.scope.on(),()=>{t.scope.off(),Qn(i)}},tr=()=>{ae&&ae.scope.off(),Qn(null)};function Ml(t){return t.vnode.shapeFlag&4}let bn=!1;function Cd(t,i=!1,e=!1){i&&Zs(i);const{props:n,children:s}=t.vnode,r=Ml(t);ld(t,n,r,i),ud(t,s,e||i);const l=r?$d(t,i):void 0;return i&&Zs(!1),l}function $d(t,i){const e=t.type;t.accessCache=Object.create(null),t.proxy=new Proxy(t.ctx,Kc);const{setup:n}=e;if(n){ii();const s=t.setupContext=n.length>1?Ad(t):null,r=Sn(t),l=xn(n,t,0,[t.props,s]),o=Mr(l);if(ni(),r(),(o||t.sp)&&!ji(t)&&al(t),o){if(l.then(tr,tr),i)return l.then(a=>{er(t,a)}).catch(a=>{ds(a,t,0)});t.asyncDep=l}else er(t,l)}else Bl(t)}function er(t,i,e){It(i)?t.type.__ssrInlineRender?t.ssrRender=i:t.render=i:jt(i)&&(t.setupState=Xr(i)),Bl(t)}function Bl(t,i,e){const n=t.type;t.render||(t.render=n.render||Ve);{const s=Sn(t);ii();try{qc(t)}finally{ni(),s()}}}const Id={get(t,i){return le(t,"get",""),t[i]}};function Ad(t){const i=e=>{t.exposed=e||{}};return{attrs:new Proxy(t.attrs,Id),slots:t.slots,emit:t.emit,expose:i}}function hs(t){return t.exposed?t.exposeProxy||(t.exposeProxy=new Proxy(Xr(mc(t.exposed)),{get(i,e){if(e in i)return i[e];if(e in fn)return fn[e](t)},has(i,e){return e in i||e in fn}})):t.proxy}function Td(t,i=!0){return It(t)?t.displayName||t.name:t.name||i&&t.__name}function Ed(t){return It(t)&&"__vccOpts"in t}const Ct=(t,i)=>wc(t,i,bn),Md="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Ys;const ir=typeof window<"u"&&window.trustedTypes;if(ir)try{Ys=ir.createPolicy("vue",{createHTML:t=>t})}catch{}const Dl=Ys?t=>Ys.createHTML(t):t=>t,Bd="http://www.w3.org/2000/svg",Dd="http://www.w3.org/1998/Math/MathML",Ze=typeof document<"u"?document:null,nr=Ze&&Ze.createElement("template"),Od={insert:(t,i,e)=>{i.insertBefore(t,e||null)},remove:t=>{const i=t.parentNode;i&&i.removeChild(t)},createElement:(t,i,e,n)=>{const s=i==="svg"?Ze.createElementNS(Bd,t):i==="mathml"?Ze.createElementNS(Dd,t):e?Ze.createElement(t,{is:e}):Ze.createElement(t);return t==="select"&&n&&n.multiple!=null&&s.setAttribute("multiple",n.multiple),s},createText:t=>Ze.createTextNode(t),createComment:t=>Ze.createComment(t),setText:(t,i)=>{t.nodeValue=i},setElementText:(t,i)=>{t.textContent=i},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>Ze.querySelector(t),setScopeId(t,i){t.setAttribute(i,"")},insertStaticContent(t,i,e,n,s,r){const l=e?e.previousSibling:i.lastChild;if(s&&(s===r||s.nextSibling))for(;i.insertBefore(s.cloneNode(!0),e),!(s===r||!(s=s.nextSibling)););else{nr.innerHTML=Dl(n==="svg"?`<svg>${t}</svg>`:n==="mathml"?`<math>${t}</math>`:t);const o=nr.content;if(n==="svg"||n==="mathml"){const a=o.firstChild;for(;a.firstChild;)o.appendChild(a.firstChild);o.removeChild(a)}i.insertBefore(o,e)}return[l?l.nextSibling:i.firstChild,e?e.previousSibling:i.lastChild]}},Pd=Symbol("_vtc");function Ld(t,i,e){const n=t[Pd];n&&(i=(i?[i,...n]:[...n]).join(" ")),i==null?t.removeAttribute("class"):e?t.setAttribute("class",i):t.className=i}const ts=Symbol("_vod"),Ol=Symbol("_vsh"),Pl={name:"show",beforeMount(t,{value:i},{transition:e}){t[ts]=t.style.display==="none"?"":t.style.display,e&&i?e.beforeEnter(t):Qi(t,i)},mounted(t,{value:i},{transition:e}){e&&i&&e.enter(t)},updated(t,{value:i,oldValue:e},{transition:n}){!i!=!e&&(n?i?(n.beforeEnter(t),Qi(t,!0),n.enter(t)):n.leave(t,()=>{Qi(t,!1)}):Qi(t,i))},beforeUnmount(t,{value:i}){Qi(t,i)}};function Qi(t,i){t.style.display=i?t[ts]:"none",t[Ol]=!i}const Rd=Symbol(""),zd=/(?:^|;)\s*display\s*:/;function Nd(t,i,e){const n=t.style,s=Qt(e);let r=!1;if(e&&!s){if(i)if(Qt(i))for(const l of i.split(";")){const o=l.slice(0,l.indexOf(":")).trim();e[o]==null&&nn(n,o,"")}else for(const l in i)e[l]==null&&nn(n,l,"");for(const l in e){l==="display"&&(r=!0);const o=e[l];o!=null?jd(t,l,!Qt(i)&&i?i[l]:void 0,o)||nn(n,l,o):nn(n,l,"")}}else if(s){if(i!==e){const l=n[Rd];l&&(e+=";"+l),n.cssText=e,r=zd.test(e)}}else i&&t.removeAttribute("style");ts in t&&(t[ts]=r?n.display:"",t[Ol]&&(n.display="none"))}const sr=/\s*!important$/;function nn(t,i,e){if(St(e))e.forEach(n=>nn(t,i,n));else if(e==null&&(e=""),i.startsWith("--"))t.setProperty(i,e);else{const n=Fd(t,i);sr.test(e)?t.setProperty(hi(n),e.replace(sr,""),"important"):t[n]=e}}const or=["Webkit","Moz","ms"],As={};function Fd(t,i){const e=As[i];if(e)return e;let n=he(i);if(n!=="filter"&&n in t)return As[i]=n;n=os(n);for(let s=0;s<or.length;s++){const r=or[s]+n;if(r in t)return As[i]=r}return i}function jd(t,i,e,n){return t.tagName==="TEXTAREA"&&(i==="width"||i==="height")&&Qt(n)&&e===n}const rr="http://www.w3.org/1999/xlink";function lr(t,i,e,n,s,r=qa(i)){n&&i.startsWith("xlink:")?e==null?t.removeAttributeNS(rr,i.slice(6,i.length)):t.setAttributeNS(rr,i,e):e==null||r&&!Pr(e)?t.removeAttribute(i):t.setAttribute(i,r?"":De(e)?String(e):e)}function ar(t,i,e,n,s){if(i==="innerHTML"||i==="textContent"){e!=null&&(t[i]=i==="innerHTML"?Dl(e):e);return}const r=t.tagName;if(i==="value"&&r!=="PROGRESS"&&!r.includes("-")){const o=r==="OPTION"?t.getAttribute("value")||"":t.value,a=e==null?t.type==="checkbox"?"on":"":String(e);(o!==a||!("_value"in t))&&(t.value=a),e==null&&t.removeAttribute(i),t._value=e;return}let l=!1;if(e===""||e==null){const o=typeof t[i];o==="boolean"?e=Pr(e):e==null&&o==="string"?(e="",l=!0):o==="number"&&(e=0,l=!0)}try{t[i]=e}catch{}l&&t.removeAttribute(s||i)}function ci(t,i,e,n){t.addEventListener(i,e,n)}function Hd(t,i,e,n){t.removeEventListener(i,e,n)}const cr=Symbol("_vei");function Ud(t,i,e,n,s=null){const r=t[cr]||(t[cr]={}),l=r[i];if(n&&l)l.value=n;else{const[o,a]=Kd(i);if(n){const c=r[i]=Zd(n,s);ci(t,o,c,a)}else l&&(Hd(t,o,l,a),r[i]=void 0)}}const Wd=/(Once|Passive|Capture)$/,Vd=/^on:?(?:Once|Passive|Capture)$/;function Kd(t){let i,e;for(;(e=t.match(Wd))&&!Vd.test(t);)i||(i={}),t=t.slice(0,t.length-e[1].length),i[e[1].toLowerCase()]=!0;return[t[2]===":"?t.slice(3):hi(t.slice(2)),i]}let Ts=0;const qd=Promise.resolve(),Gd=()=>Ts||(qd.then(()=>Ts=0),Ts=Date.now());function Zd(t,i){const e=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=e.attached)return;const s=e.value;if(St(s)){const r=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{r.call(n),n._stopped=!0};const l=s.slice(),o=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Pe(c,i,5,o)}}else Pe(s,i,5,[n])};return e.value=t,e.attached=Gd(),e}const dr=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&t.charCodeAt(2)>96&&t.charCodeAt(2)<123,Yd=(t,i,e,n,s,r)=>{const l=s==="svg";i==="class"?Ld(t,n,l):i==="style"?Nd(t,e,n):is(i)?ns(i)||Ud(t,i,e,n,r):(i[0]==="."?(i=i.slice(1),!0):i[0]==="^"?(i=i.slice(1),!1):Jd(t,i,n,l))?(ar(t,i,n),!t.tagName.includes("-")&&(i==="value"||i==="checked"||i==="selected")&&lr(t,i,n,l,r,i!=="value")):t._isVueCE&&(Xd(t,i)||t._def.__asyncLoader&&(/[A-Z]/.test(i)||!Qt(n)))?ar(t,he(i),n,r,i):(i==="true-value"?t._trueValue=n:i==="false-value"&&(t._falseValue=n),lr(t,i,n,l))};function Jd(t,i,e,n){if(n)return!!(i==="innerHTML"||i==="textContent"||i in t&&dr(i)&&It(e));if(i==="spellcheck"||i==="draggable"||i==="translate"||i==="autocorrect"||i==="sandbox"&&t.tagName==="IFRAME"||i==="form"||i==="list"&&t.tagName==="INPUT"||i==="type"&&t.tagName==="TEXTAREA")return!1;if(i==="width"||i==="height"){const s=t.tagName;if(s==="IMG"||s==="VIDEO"||s==="CANVAS"||s==="SOURCE")return!1}return dr(i)&&Qt(e)?!1:i in t}function Xd(t,i){const e=t._def.props;if(!e)return!1;const n=he(i);return Array.isArray(e)?e.some(s=>he(s)===n):Object.keys(e).some(s=>he(s)===n)}const qi=t=>{const i=t.props["onUpdate:modelValue"]||!1;return St(i)?e=>Fn(i,e):i};function Qd(t){t.target.composing=!0}function ur(t){const i=t.target;i.composing&&(i.composing=!1,i.dispatchEvent(new Event("input")))}const ei=Symbol("_assign");function fr(t,i,e){return i&&(t=t.trim()),e&&(t=rs(t)),t}const es={created(t,{modifiers:{lazy:i,trim:e,number:n}},s){t[ei]=qi(s);const r=n||s.props&&s.props.type==="number";ci(t,i?"change":"input",l=>{l.target.composing||t[ei](fr(t.value,e,r))}),(e||r)&&ci(t,"change",()=>{t.value=fr(t.value,e,r)}),i||(ci(t,"compositionstart",Qd),ci(t,"compositionend",ur),ci(t,"change",ur))},mounted(t,{value:i}){t.value=i??""},beforeUpdate(t,{value:i,oldValue:e,modifiers:{lazy:n,trim:s,number:r}},l){if(t[ei]=qi(l),t.composing)return;const o=(r||t.type==="number")&&!/^0\d/.test(t.value)?rs(t.value):t.value,a=i??"";if(o===a)return;const c=t.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===t&&t.type!=="range"&&(n&&i===e||s&&t.value.trim()===a)||(t.value=a)}},Ln={deep:!0,created(t,i,e){t[ei]=qi(e),ci(t,"change",()=>{const n=t._modelValue,s=yn(t),r=t.checked,l=t[ei];if(St(n)){const o=so(n,s),a=o!==-1;if(r&&!a)l(n.concat(s));else if(!r&&a){const c=[...n];c.splice(o,1),l(c)}}else if(Zi(n)){const o=new Set(n);r?o.add(s):o.delete(s),l(o)}else l(Ll(t,r))})},mounted:pr,beforeUpdate(t,i,e){t[ei]=qi(e),pr(t,i,e)}};function pr(t,{value:i,oldValue:e},n){t._modelValue=i;let s;if(St(i))s=so(i,n.props.value)>-1;else if(Zi(i))s=i.has(n.props.value);else{if(i===e)return;s=Yi(i,Ll(t,!0))}t.checked!==s&&(t.checked=s)}const tu={deep:!0,created(t,{value:i,modifiers:{number:e}},n){t._modelValue=i,ci(t,"change",()=>{const s=Array.prototype.filter.call(t.options,r=>r.selected).map(r=>e?rs(yn(r)):yn(r));t[ei](t.multiple?Zi(t._modelValue)?new Set(s):s:s[0]),t._assigning=!0,tl(()=>{t._assigning=!1})}),t[ei]=qi(n)},mounted(t,{value:i}){hr(t,i)},beforeUpdate(t,{value:i},e){t._modelValue=i,t[ei]=qi(e)},updated(t,{value:i}){t._assigning||hr(t,i)}};function hr(t,i){const e=t.multiple,n=St(i);if(!(e&&!n&&!Zi(i))){for(let s=0,r=t.options.length;s<r;s++){const l=t.options[s],o=yn(l);if(e)if(n){const a=typeof o;a==="string"||a==="number"?l.selected=i.some(c=>String(c)===String(o)):l.selected=so(i,o)>-1}else l.selected=i.has(o);else if(Yi(yn(l),i)){t.selectedIndex!==s&&(t.selectedIndex=s);return}}!e&&t.selectedIndex!==-1&&(t.selectedIndex=-1)}}function yn(t){return"_value"in t?t._value:t.value}function Ll(t,i){const e=i?"_trueValue":"_falseValue";return e in t?t[e]:i}const eu=["ctrl","shift","alt","meta"],iu={stop:t=>t.stopPropagation(),prevent:t=>t.preventDefault(),self:t=>t.target!==t.currentTarget,ctrl:t=>!t.ctrlKey,shift:t=>!t.shiftKey,alt:t=>!t.altKey,meta:t=>!t.metaKey,left:t=>"button"in t&&t.button!==0,middle:t=>"button"in t&&t.button!==1,right:t=>"button"in t&&t.button!==2,exact:(t,i)=>eu.some(e=>t[`${e}Key`]&&!i.includes(e))},Te=(t,i)=>{if(!t)return t;const e=t._withMods||(t._withMods={}),n=i.join(".");return e[n]||(e[n]=((s,...r)=>{for(let l=0;l<i.length;l++){const o=iu[i[l]];if(o&&o(s,i))return}return t(s,...r)}))},nu={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},su=(t,i)=>{const e=t._withKeys||(t._withKeys={}),n=i.join(".");return e[n]||(e[n]=(s=>{if(!("key"in s))return;const r=hi(s.key);if(i.some(l=>l===r||nu[l]===r))return t(s)}))},ou=re({patchProp:Yd},Od);let mr;function ru(){return mr||(mr=pd(ou))}const Rl=((...t)=>{const i=ru().createApp(...t),{mount:e}=i;return i.mount=n=>{const s=au(n);if(!s)return;const r=i._component;!It(r)&&!r.render&&!r.template&&(r.template=s.innerHTML),s.nodeType===1&&(s.textContent="");const l=e(s,!1,lu(s));return s instanceof Element&&(s.removeAttribute("v-cloak"),s.setAttribute("data-v-app","")),l},i});function lu(t){if(t instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&t instanceof MathMLElement)return"mathml"}function au(t){return Qt(t)?document.querySelector(t):t}function cu(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function ke(t){const i=cu();if(i)try{return i(t)}catch{try{const e=t.startsWith("node:")?t.slice(5):`node:${t}`;return i(e)}catch{}}}function ko(){var i;if(typeof window<"u"&&window.process)return window.process;const t=ke("process");return t&&t.versions?t:typeof process<"u"&&((i=process.versions)!=null&&i.node)?process:globalThis.process}function zl(){var i,e;const t=ko();if(t&&((i=t.versions)!=null&&i.node))return!0;if(typeof window<"u"&&window.siyuan){const n=ke("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((e=process.versions)!=null&&e.node))}function wn(){const t=ko();if(t!=null&&t.platform)return t.platform;if(typeof process<"u"&&process.platform)return process.platform;const i=ke("os");if(i&&typeof i.platform=="function")return i.platform();if(typeof navigator<"u"){const e=navigator.userAgent.toLowerCase();if(e.includes("win"))return"win32";if(e.includes("mac"))return"darwin";if(e.includes("linux"))return"linux"}return"web"}function Nl(){var n,s;const t=ko(),i={...(t==null?void 0:t.env)||{}};if(wn()==="win32"){const r=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=t==null?void 0:t.env)!=null&&n.APPDATA?`${t.env.APPDATA}\\npm`:"",(s=t==null?void 0:t.env)!=null&&s.USERPROFILE?`${t.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(i).find(c=>c.toLowerCase()==="path")||"PATH",a=(i[l]||"").split(";").filter(Boolean);for(const c of r)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);i[l]=a.join(";")}return i}function Js(t){var e,n,s;if(!t)return"";if(/^[a-zA-Z]:[/\\]/.test(t))return t.replace(/\\/g,"/");let i="";if(typeof window<"u"&&((s=(n=(e=window.siyuan)==null?void 0:e.config)==null?void 0:n.system)!=null&&s.dataDir)&&(i=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),i&&t.startsWith("/data/")){const r=t.slice(6);return`${i}/${r}`.replace(/\\/g,"/")}return t}function du(){const t=ke("os"),i=ke("path");if(t&&typeof t.tmpdir=="function"){const e=t.tmpdir();return i&&typeof i.join=="function"?i.join(e,"siyuan-slidev-pro").replace(/\\/g,"/"):`${e}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class xo{constructor(i){vt(this,"runner");this.runner=i||xo.defaultRunner}static async defaultRunner(i,e){var n;try{let s=(n=ke("child_process"))==null?void 0:n.execFile;if(!s){const a=await import("node:child_process").catch(()=>({}));s=a==null?void 0:a.execFile}if(!s)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=wn()==="win32",o=Nl();return await new Promise(a=>{s(i,e,{timeout:5e3,shell:l,env:o},(c,d,h)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:h?String(h).trim():""})})})}catch(s){return{code:-1,stdout:"",stderr:String(s)}}}async detect(){const i=zl(),e=wn();if(!i)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,s,r=!1,l;try{const o=await this.runner("node",["-v"]);o.code===0&&o.stdout.startsWith("v")&&(n=!0,s=o.stdout)}catch{}if(n){try{const o=e==="win32"?"slidev.cmd":"slidev",a=await this.runner(o,["--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}if(!r)try{const o=e==="win32"?"npx.cmd":"npx",a=await this.runner(o,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:s,hasSlidevCli:r,slidevVersion:l,platform:e,isDesktop:i}}}class uu{constructor(){vt(this,"iframe",null);vt(this,"isReady",!1);vt(this,"pageChangedHandlers",[]);vt(this,"readyHandlers",[]);vt(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(i,e){var s;if(!((s=this.iframe)!=null&&s.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:i,...e};try{this.iframe.contentWindow.postMessage(n,"*")}catch(r){console.warn("[NativeSlidevBridge] postMessage error:",r)}}navigateToPage(i){this.postMessage("navigate",{no:i})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(i){return this.pageChangedHandlers.push(i),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(e=>e!==i)}}onReady(i){return this.readyHandlers.push(i),()=>{this.readyHandlers=this.readyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){const e=i.data;if(!(!e||e.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(e.type==="update-state"&&e.navState){const n=e.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const s of this.pageChangedHandlers)s(this.currentState.no,this.currentState.total||1,this.currentState)}else if(e.type==="navigate"&&typeof e.no=="number"){this.currentState.no=e.no;for(const n of this.pageChangedHandlers)n(e.no,this.currentState.total||1,this.currentState)}}}}class fu{constructor(i){vt(this,"childProcess",null);vt(this,"activePort",null);vt(this,"isRunning",!1);vt(this,"defaultPort");vt(this,"maxPortRetries");vt(this,"probeTimeoutMs");vt(this,"customSpawner");vt(this,"customPortChecker");this.defaultPort=(i==null?void 0:i.defaultPort)||3030,this.maxPortRetries=(i==null?void 0:i.maxPortRetries)||20,this.probeTimeoutMs=(i==null?void 0:i.probeTimeoutMs)||1e4,this.customSpawner=i==null?void 0:i.customSpawner,this.customPortChecker=i==null?void 0:i.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(i){if(this.customPortChecker)return this.customPortChecker(i);try{let e=ke("net");return e||(e=await import("node:net").catch(()=>({}))),e!=null&&e.createServer?await new Promise(n=>{const s=e.createServer();s.once("error",()=>n(!1)),s.once("listening",()=>{s.close(()=>n(!0))}),s.listen(i,"127.0.0.1")}):!0}catch{return!0}}async allocPort(i){const e=i||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const s=e+n;if(await this.isPortAvailable(s))return s}return e}async pollServerReady(i,e=8e3,n=300){const s=Date.now();for(;Date.now()-s<e;){try{const r=new AbortController,l=setTimeout(()=>r.abort(),n),o=await fetch(i,{method:"HEAD",mode:"no-cors",signal:r.signal}).catch(()=>null);if(clearTimeout(l),o)return!0}catch{}await new Promise(r=>setTimeout(r,n))}return!1}async startServer(i,e){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(e);this.activePort=n;const r=wn()==="win32"?"npx.cmd":"npx",l=Js(i),o=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(r,o,{detached:!1});else{let h=(a=ke("child_process"))==null?void 0:a.spawn;if(!h){const w=await import("node:child_process").catch(()=>({}));h=w==null?void 0:w.spawn}if(!h)throw new Error("child_process spawn not available in current runtime");const p=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,f=Nl();this.childProcess=h(r,o,{cwd:p,detached:!1,shell:!0,env:{...f,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var i;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),wn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(i=ke("child_process"))==null?void 0:i.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:s})=>{var r;s(`taskkill /pid ${(r=this.childProcess)==null?void 0:r.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class _o{constructor(){vt(this,"iframe",null);vt(this,"isReady",!1);vt(this,"pendingMessages",[]);vt(this,"slideChangedHandlers",[]);vt(this,"blockClickedHandlers",[]);vt(this,"openInEditorHandlers",[]);vt(this,"clientReadyHandlers",[]);vt(this,"openPeekDrawerHandlers",[]);vt(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(i,e){var s;const n={source:"siyuan-slidev-host",action:i,payload:e};if(!((s=this.iframe)!=null&&s.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(r){console.warn("[WebSandboxBridge] postMessage error:",r)}}updateSlides(i,e,n){this.postMessage("UPDATE_SLIDES",{slides:i,config:e,fullMarkdown:n})}navigatePage(i){this.postMessage("NAVIGATE_PAGE",{pageIndex:i})}highlightElement(i){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:i})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(i){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:i})}onSlideChanged(i){return this.slideChangedHandlers.push(i),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(e=>e!==i)}}onBlockClicked(i){return this.blockClickedHandlers.push(i),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(e=>e!==i)}}onOpenInEditor(i){return this.openInEditorHandlers.push(i),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(e=>e!==i)}}onOpenPeekDrawer(i){return this.openPeekDrawerHandlers.push(i),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(e=>e!==i)}}onRequestToggleFullscreen(i){return this.toggleFullscreenHandlers.push(i),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(e=>e!==i)}}onClientReady(i){return this.clientReadyHandlers.push(i),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){var n;const e=i.data;if(!(!e||e.source!=="siyuan-slidev-client"))switch(e.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const s=this.pendingMessages.shift();s&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(s,"*")}for(const s of this.clientReadyHandlers)s();break;case"SLIDE_CHANGED":if(e.payload.currentPage!==void 0)for(const s of this.slideChangedHandlers)s(e.payload.currentPage,e.payload.totalPages||1,e.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(e.payload.clickedBlockId)for(const s of this.blockClickedHandlers)s(e.payload.clickedBlockId,e.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(e.payload.blockId||e.payload.clickedBlockId){const s=e.payload.blockId||e.payload.clickedBlockId||"";for(const r of this.openInEditorHandlers)r(s,e.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(e.payload.peekType){const s=e.payload.blockId||e.payload.url||"",r={peekType:e.payload.peekType,target:s,title:e.payload.title};for(const l of this.openPeekDrawerHandlers)l(r)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const s of this.toggleFullscreenHandlers)s();break}}}const Fl={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},pu=`<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-3 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,hu=`// Auto-generated by SiYuan Slidev Studio
export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,mu=`/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  max-height: min(100%, 340px, 44vh) !important;
  object-fit: contain !important;
}
.slide-list-media {
  display: flex !important;
  align-items: center !important;
  margin-top: 8px !important;
  margin-bottom: 6px !important;
  max-width: 100% !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  max-width: 100% !important;
  max-height: min(340px, 42vh) !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
}
.slide-video-container {
  display: flex !important;
  justify-content: center !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与三栏（超级块分栏）布局：去除列表圆点标记与缩进 */
.three-cols-header ul,
.three-cols-header ol,
.two-cols-header ul,
.two-cols-header ol,
.two-cols ul,
.two-cols ol,
.col-1 ul,
.col-1 ol,
.col-2 ul,
.col-2 ol,
.col-3 ul,
.col-3 ol,
.grid-cols-2 ul,
.grid-cols-2 ol,
.grid-cols-3 ul,
.grid-cols-3 ol {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
  margin-left: 0 !important;
}
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.grid-cols-2 li,
.grid-cols-3 li {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
  margin-left: 0 !important;
}
.three-cols-header li::marker,
.two-cols-header li::marker,
.two-cols li::marker,
.col-1 li::marker,
.col-2 li::marker,
.col-3 li::marker {
  content: none !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function gu(t){var s;const i=[],e=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=e.exec(t))!==null;){const r=(s=n[1])==null?void 0:s.trim();r&&!i.includes(r)&&i.push(r)}return i}class vu{constructor(i){vt(this,"workspacePath");vt(this,"slidesFileName");vt(this,"cliBridge",new Qs);const e=du();!(i!=null&&i.workspacePath)||i.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=e:this.workspacePath=i.workspacePath,this.slidesFileName=(i==null?void 0:i.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(i="default"){const e={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return i&&i!=="default"&&(e.dependencies[`@slidev/theme-${i}`]="latest"),JSON.stringify(e,null,2)}buildSlidesMarkdown(i){return this.cliBridge.buildStandardSlidevMarkdown(i)}async scaffold(i,e){const n=this.buildSlidesMarkdown(i),s=this.generatePackageJson(i.config.theme),r=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,o=Js(r),a=Js(l),c=gu(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const v of c){const b=Fl[v]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${v}
// #endregion snippet
`;d.set(v,b)}i.slides.some(v=>{var b;return((b=v.frontmatter)==null?void 0:b.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",pu),d.set("setup/root.ts",hu),d.set("styles/index.css",mu);const p=ke("fs"),f=ke("path");let w=!1;const m=f!=null&&f.dirname?f.dirname(o):"",k=/^[a-zA-Z]:[/\\]/.test(o)||o.includes("siyuan-slidev-pro");if(p&&f&&k)try{p.existsSync(m)||p.mkdirSync(m,{recursive:!0}),p.writeFileSync(a,s,"utf-8"),p.writeFileSync(o,n,"utf-8");for(const[v,b]of d.entries()){const T=f.join(m,v),C=f.dirname(T);p.existsSync(C)||p.mkdirSync(C,{recursive:!0}),p.existsSync(T)||p.writeFileSync(T,b,"utf-8")}w=!0}catch{}if(!w&&e)try{const v=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),b=typeof Blob<"u"?new Blob([s],{type:"application/json;charset=utf-8"}):Buffer.from(s,"utf-8");await e(l,!1,b),await e(r,!1,v);for(const[T,C]of d.entries()){const A=`${this.workspacePath}/${T}`,S=typeof Blob<"u"?new Blob([C],{type:"text/plain;charset=utf-8"}):Buffer.from(C,"utf-8");await e(A,!1,S).catch(()=>{})}return{success:!0,slidesPath:r,physicalSlidesPath:o,packageJsonPath:l}}catch(v){return{success:!1,slidesPath:r,physicalSlidesPath:o,packageJsonPath:l,error:String(v)}}return{success:!0,slidesPath:r,physicalSlidesPath:o,packageJsonPath:l}}}class bu{constructor(){vt(this,"mode","web-sandbox");vt(this,"webBridge");vt(this,"cliBridge");vt(this,"nativeBridge");vt(this,"processManager");vt(this,"scaffolder");vt(this,"envDetector");this.webBridge=new _o,this.cliBridge=new Qs,this.nativeBridge=new uu,this.processManager=new fu,this.scaffolder=new vu,this.envDetector=new xo}getMode(){return this.mode}setMode(i){this.mode=i}async startProMode(i,e){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const s=await this.scaffolder.scaffold(i,e);if(!s.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${s.error}`};const r=s.physicalSlidesPath||s.slidesPath,l=await this.processManager.startServer(r);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const yu={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},wu={key:0},ku={key:1},xu={key:2},_u={key:3},Su={key:4},Cu={key:5},$u={key:6},Iu={key:7},Au={key:8},Tu={key:9},Eu={key:10},Mu={key:11},Bu={key:12},Du={key:13},Ou={key:14},Pu={key:15},Lu={key:16},Ru={key:17},zu={key:18},Nu={key:19},Fu={key:20},ju={key:21},Hu={key:22},Uu={key:23},Wu={key:24},Vu={key:25},Ku={key:26},qu={key:27},Gu={key:28},Zu={key:29},Yu={key:30},Ju={key:31},Xu={key:32},Qu={key:33},tf={key:34},ef={key:35},nf={key:36},sf={key:37},of={key:38},rf={key:39},lf={key:40},af={key:41},cf={key:42},df={key:43},uf={key:44},ff={key:45},pf={key:46},hf={key:47},mf={key:48},gf={key:49},vf={key:50},bf=be({__name:"SlidevIcon",props:{name:{}},setup(t){return(i,e)=>(Q(),nt("svg",yu,[t.name==="fullscreen"||t.name==="maximize"?(Q(),nt("g",wu,[...e[0]||(e[0]=[g("polyline",{points:"15 3 21 3 21 9"},null,-1),g("polyline",{points:"9 21 3 21 3 15"},null,-1),g("polyline",{points:"21 15 21 21 15 21"},null,-1),g("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):t.name==="minimize"?(Q(),nt("g",ku,[...e[1]||(e[1]=[g("polyline",{points:"4 14 10 14 10 20"},null,-1),g("polyline",{points:"20 10 14 10 14 4"},null,-1),g("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),g("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):t.name==="close"||t.name==="x"?(Q(),nt("g",xu,[...e[2]||(e[2]=[g("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),g("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):t.name==="edit"?(Q(),nt("g",_u,[...e[3]||(e[3]=[g("path",{d:"M12 20h9"},null,-1),g("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):t.name==="eye"?(Q(),nt("g",Su,[...e[4]||(e[4]=[g("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),g("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):t.name==="external-link"||t.name==="window"?(Q(),nt("g",Cu,[...e[5]||(e[5]=[g("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),g("polyline",{points:"15 3 21 3 21 9"},null,-1),g("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):t.name==="arrow-left"?(Q(),nt("g",$u,[...e[6]||(e[6]=[g("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),g("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):t.name==="arrow-right"?(Q(),nt("g",Iu,[...e[7]||(e[7]=[g("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),g("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):t.name==="plus"?(Q(),nt("g",Au,[...e[8]||(e[8]=[g("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),g("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="minus"?(Q(),nt("g",Tu,[...e[9]||(e[9]=[g("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="split-preview"?(Q(),nt("g",Eu,[...e[10]||(e[10]=[g("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),g("path",{d:"M12 3v18"},null,-1)])])):t.name==="import"?(Q(),nt("g",Mu,[...e[11]||(e[11]=[g("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),g("polyline",{points:"7 9 12 14 17 9"},null,-1),g("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):t.name==="presenter"?(Q(),nt("g",Bu,[...e[12]||(e[12]=[g("path",{d:"M2 3h20"},null,-1),g("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),g("path",{d:"m7 21 5-5 5 5"},null,-1)])])):t.name==="video"?(Q(),nt("g",Du,[...e[13]||(e[13]=[g("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),g("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):t.name==="step"?(Q(),nt("g",Ou,[...e[14]||(e[14]=[g("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):t.name==="motion"?(Q(),nt("g",Pu,[...e[15]||(e[15]=[g("path",{d:"M5 12h14"},null,-1),g("path",{d:"m12 5 7 7-7 7"},null,-1),g("path",{d:"M5 6h4"},null,-1),g("path",{d:"M5 18h4"},null,-1)])])):t.name==="columns"?(Q(),nt("g",Lu,[...e[16]||(e[16]=[g("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),g("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):t.name==="code"?(Q(),nt("g",Ru,[...e[17]||(e[17]=[g("polyline",{points:"16 18 22 12 16 6"},null,-1),g("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):t.name==="insert-above"?(Q(),nt("g",zu,[...e[18]||(e[18]=[g("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),g("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),g("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):t.name==="insert-below"?(Q(),nt("g",Nu,[...e[19]||(e[19]=[g("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),g("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),g("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="broom"?(Q(),nt("g",Fu,[...e[20]||(e[20]=[g("path",{d:"m18 15-6-6"},null,-1),g("path",{d:"M4 20h16"},null,-1),g("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):t.name==="trash"?(Q(),nt("g",ju,[...e[21]||(e[21]=[g("path",{d:"M3 6h18"},null,-1),g("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),g("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):t.name==="ai"||t.name==="sparkles"?(Q(),nt("g",Hu,[...e[22]||(e[22]=[g("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):t.name==="palette"?(Q(),nt("g",Uu,[...e[23]||(e[23]=[$e('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-bd3acdae></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-bd3acdae></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-bd3acdae></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-bd3acdae></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-bd3acdae></path>',5)])])):t.name==="ratio"?(Q(),nt("g",Wu,[...e[24]||(e[24]=[g("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),g("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):t.name==="transition"?(Q(),nt("g",Vu,[...e[25]||(e[25]=[g("path",{d:"M8 3 4 7l4 4"},null,-1),g("path",{d:"M4 7h16"},null,-1),g("path",{d:"m16 21 4-4-4-4"},null,-1),g("path",{d:"M20 17H4"},null,-1)])])):t.name==="export-html"?(Q(),nt("g",Ku,[...e[26]||(e[26]=[g("polyline",{points:"16 16 12 12 8 16"},null,-1),g("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),g("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):t.name==="export-pdf"?(Q(),nt("g",qu,[...e[27]||(e[27]=[g("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),g("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),g("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):t.name==="pin"?(Q(),nt("g",Gu,[...e[28]||(e[28]=[g("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),g("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):t.name==="refresh"?(Q(),nt("g",Zu,[...e[29]||(e[29]=[g("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),g("path",{d:"M21 3v5h-5"},null,-1),g("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),g("path",{d:"M8 16H3v5"},null,-1)])])):t.name==="outline"?(Q(),nt("g",Yu,[...e[30]||(e[30]=[g("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),g("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),g("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):t.name==="chevron-left"?(Q(),nt("g",Ju,[...e[31]||(e[31]=[g("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):t.name==="chevron-right"?(Q(),nt("g",Xu,[...e[32]||(e[32]=[g("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):t.name==="copy"?(Q(),nt("g",Qu,[...e[33]||(e[33]=[g("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),g("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):t.name==="image"?(Q(),nt("g",tf,[...e[34]||(e[34]=[g("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),g("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),g("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):t.name==="search"?(Q(),nt("g",ef,[...e[35]||(e[35]=[g("circle",{cx:"11",cy:"11",r:"7"},null,-1),g("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):t.name==="settings"||t.name==="gear"?(Q(),nt("g",nf,[...e[36]||(e[36]=[g("circle",{cx:"12",cy:"12",r:"3"},null,-1),g("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):t.name==="notes"||t.name==="file-text"?(Q(),nt("g",sf,[...e[37]||(e[37]=[$e('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-bd3acdae></path><polyline points="14 2 14 8 20 8" data-v-bd3acdae></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-bd3acdae></line><line x1="16" y1="17" x2="8" y2="17" data-v-bd3acdae></line><line x1="10" y1="9" x2="8" y2="9" data-v-bd3acdae></line>',5)])])):t.name==="focus"||t.name==="target"?(Q(),nt("g",of,[...e[38]||(e[38]=[g("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),g("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),g("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):t.name==="layout-cover"||t.name==="cover"?(Q(),nt("g",rf,[...e[39]||(e[39]=[g("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),g("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),g("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),g("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):t.name==="layout-default"||t.name==="default"?(Q(),nt("g",lf,[...e[40]||(e[40]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-bd3acdae></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-bd3acdae></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-bd3acdae></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-bd3acdae></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-bd3acdae></line>',5)])])):t.name==="layout-two-cols"||t.name==="two-cols"?(Q(),nt("g",af,[...e[41]||(e[41]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-bd3acdae></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-bd3acdae></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-bd3acdae></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-bd3acdae></line><line x1="5" y1="15" x2="8" y2="15" data-v-bd3acdae></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-bd3acdae></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-bd3acdae></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-bd3acdae></line>',8)])])):t.name==="layout-two-cols-header"||t.name==="two-cols-header"?(Q(),nt("g",cf,[...e[42]||(e[42]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-bd3acdae></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-bd3acdae></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-bd3acdae></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-bd3acdae></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-bd3acdae></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-bd3acdae></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-bd3acdae></line>',7)])])):t.name==="layout-three-cols-header"||t.name==="three-cols-header"?(Q(),nt("g",df,[...e[43]||(e[43]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-bd3acdae></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-bd3acdae></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-bd3acdae></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-bd3acdae></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-bd3acdae></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-bd3acdae></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-bd3acdae></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-bd3acdae></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-bd3acdae></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-bd3acdae></line>',10)])])):t.name==="layout-image-right"||t.name==="image-right"?(Q(),nt("g",uf,[...e[44]||(e[44]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-bd3acdae></rect><line x1="12" y1="4" x2="12" y2="20" data-v-bd3acdae></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-bd3acdae></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-bd3acdae></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-bd3acdae></line><circle cx="15.5" cy="8.5" r="1.2" data-v-bd3acdae></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-bd3acdae></polyline>',7)])])):t.name==="layout-image-left"||t.name==="image-left"?(Q(),nt("g",ff,[...e[45]||(e[45]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-bd3acdae></rect><line x1="12" y1="4" x2="12" y2="20" data-v-bd3acdae></line><circle cx="6" cy="8.5" r="1.2" data-v-bd3acdae></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-bd3acdae></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-bd3acdae></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-bd3acdae></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-bd3acdae></line>',7)])])):t.name==="layout-center"||t.name==="center"?(Q(),nt("g",pf,[...e[46]||(e[46]=[g("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),g("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),g("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),g("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="layout-fact"||t.name==="fact"?(Q(),nt("g",hf,[...e[47]||(e[47]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-bd3acdae></rect><circle cx="8" cy="9" r="1.5" data-v-bd3acdae></circle><line x1="14" y1="8" x2="9" y2="14" data-v-bd3acdae></line><circle cx="15" cy="13" r="1.5" data-v-bd3acdae></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-bd3acdae></line>',5)])])):t.name==="layout-intro"||t.name==="intro"?(Q(),nt("g",mf,[...e[48]||(e[48]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-bd3acdae></rect><circle cx="7.5" cy="9.5" r="2" data-v-bd3acdae></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-bd3acdae></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-bd3acdae></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-bd3acdae></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-bd3acdae></line>',6)])])):t.name==="layout-quote"||t.name==="quote"?(Q(),nt("g",gf,[...e[49]||(e[49]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-bd3acdae></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-bd3acdae></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-bd3acdae></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-bd3acdae></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-bd3acdae></line>',5)])])):(Q(),nt("g",vf,[...e[50]||(e[50]=[g("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),g("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),g("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Le=(t,i)=>{const e=t.__vccOpts||t;for(const[n,s]of i)e[n]=s;return e},bt=Le(bf,[["__scopeId","data-v-bd3acdae"]]);function se(t,i){var s;if(typeof document>"u"||!t)return;const e=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${e}"]`);!n||n.length===0||n.forEach(r=>{for(const[l,o]of Object.entries(i))o!=null&&o!==""?r.setAttribute(l,String(o)):r.removeAttribute(l)})}function yf(t){if(typeof document>"u")return;const i=`.protyle-wysiwyg [${ut}], .protyle-wysiwyg [${qt}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,e=document.querySelectorAll(i);!e||e.length===0||e.forEach(n=>{const s=n.getAttribute("data-node-id");if(!s){n.removeAttribute(ut),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(qt),n.removeAttribute("custom-slidev-role");return}const r=t.get(s),l=(r==null?void 0:r[ut])||(r==null?void 0:r["custom-slidev-layout"])||"",o=n.getAttribute(ut)||n.getAttribute("custom-slidev-layout");o&&o!==l&&(l?n.setAttribute(ut,l):(n.removeAttribute(ut),n.removeAttribute("custom-slidev-layout")));const a=(r==null?void 0:r[qt])||(r==null?void 0:r["custom-slidev-role"])||"",c=n.getAttribute(qt)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(qt,a):(n.removeAttribute(qt),n.removeAttribute("custom-slidev-role")))})}const wf={class:"spm-layout-picker"},kf={class:"spm-layout-picker__grid"},xf=["title","onClick"],_f={class:"spm-layout-icon"},Sf={class:"spm-layout-label"},Cf=be({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,n=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"two-cols-header",label:"表头双栏",desc:"顶部通栏标题，下方左右双栏"},{name:"three-cols-header",label:"表头三栏",desc:"顶部通栏标题，下方等宽三栏"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function s(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(Q(),nt("div",wf,[l[0]||(l[0]=g("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),g("div",kf,[(Q(),nt(Gt,null,ye(n,o=>g("div",{key:o.name,class:Et(["spm-layout-item",{active:t.modelValue===o.name}]),title:o.desc,onClick:a=>s(o.name)},[g("div",_f,[ft(bt,{name:"layout-"+o.name},null,8,["name"])]),g("span",Sf,_t(o.label),1)],10,xf)),64))])]))}}),jl=Le(Cf,[["__scopeId","data-v-c57441d5"]]),$f={key:0,class:"spm-transition-selector__header"},If={class:"spm-transition-list"},Af=["onClick"],Tf={class:"spm-transition-meta"},Ef={class:"spm-transition-label"},Mf={class:"spm-transition-name"},Bf={class:"spm-transition-preview-box"},Df=be({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function s(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(Q(),nt("div",{class:Et(["spm-transition-selector",{"spm-transition-selector--no-header":t.hideHeader}])},[t.hideHeader?Ft("",!0):(Q(),nt("div",$f,_t(t.title||"转场动效"),1)),g("div",If,[(Q(),nt(Gt,null,ye(n,o=>g("div",{key:o.name,class:Et(["spm-transition-item",{active:t.modelValue===o.name}]),onClick:a=>s(o.name)},[g("div",Tf,[g("span",Ef,_t(o.label),1),g("span",Mf,"("+_t(o.name)+")",1)]),g("div",Bf,[g("div",{class:Et(["spm-anim-cube","anim-"+o.name])},null,2)])],10,Af)),64))])],2))}}),So=Le(Df,[["__scopeId","data-v-b0aa61ff"]]),Of={class:"spm-divider-popover"},Pf={class:"spm-divider-popover__title"},Lf={class:"spm-form-item"},Rf={class:"spm-popover-footer"},zf={class:"spm-save-hint"},Nf=be({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(t,{emit:i}){var p,f,w;const e=t,n=i,s=pt(((p=e.initialAttrs)==null?void 0:p[ut])||"default"),r=pt(((f=e.initialAttrs)==null?void 0:f[Xt])||"slide-left"),l=pt(((w=e.initialAttrs)==null?void 0:w[Ut])||""),o=pt("");Ai(()=>e.initialAttrs,m=>{s.value=(m==null?void 0:m[ut])||"default",r.value=(m==null?void 0:m[Xt])||"slide-left",l.value=(m==null?void 0:m[Ut])||""},{deep:!0});async function a(m,k){if(e.blockId){o.value="正在同步...",Ht.setBlockAttrOverride(e.blockId,{[m]:k}),se(e.blockId,{[m]:k});try{await zt(e.blockId,{[m]:k}),o.value="已同步至块属性",n("updated",{[m]:k}),setTimeout(()=>{o.value=""},1500)}catch{o.value="同步失败"}}}function c(m){a(ut,m)}function d(m){a(Xt,m)}function h(){a(Ut,l.value.trim())}return(m,k)=>(Q(),nt("div",Of,[g("div",Pf,[k[4]||(k[4]=g("span",null,"幻灯片页面设置",-1)),g("button",{class:"spm-close-btn",onClick:k[0]||(k[0]=v=>n("close"))},"✕")]),ft(jl,{modelValue:s.value,"onUpdate:modelValue":k[1]||(k[1]=v=>s.value=v),onChange:c},null,8,["modelValue"]),ft(So,{modelValue:r.value,"onUpdate:modelValue":k[2]||(k[2]=v=>r.value=v),onChange:d},null,8,["modelValue"]),g("div",Lf,[k[5]||(k[5]=g("label",{class:"spm-form-label"},"页面背景",-1)),Ie(g("input",{"onUpdate:modelValue":k[3]||(k[3]=v=>l.value=v),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:h},null,544),[[es,l.value]])]),g("div",Rf,[g("span",zf,_t(o.value),1)])]))}}),Ff=Le(Nf,[["__scopeId","data-v-e4871368"]]),jf={class:"spm-slide-inspector"},Hf={class:"spm-inspector-header"},Uf={class:"spm-inspector-list"},Wf=["onClick"],Vf={class:"spm-card-top"},Kf={class:"spm-card-badge"},qf={class:"spm-card-layout"},Gf=["onClick"],Zf={class:"spm-card-preview"},Yf={key:0,class:"spm-card-notes",title:"演讲备忘录"},Jf={class:"spm-inspector-modal-content"},Xf=be({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(t,{emit:i}){const e=i,n=pt(null);function s(c){n.value=c}function r(c){const d={};return c.frontmatter.layout&&(d[ut]=c.frontmatter.layout),c.frontmatter.transition&&(d[Xt]=c.frontmatter.transition),c.frontmatter.background&&(d[Ut]=c.frontmatter.background),c.notes&&(d[Li]=c.notes),d}function l(c){n.value&&(c[ut]&&(n.value.frontmatter.layout=c[ut]),c[Xt]&&(n.value.frontmatter.transition=c[Xt]),c[Ut]&&(n.value.frontmatter.background=c[Ut]),c[Li]&&(n.value.notes=c[Li]),e("refresh"))}function o(c){e("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const d=c.blocks[0],h=d.content||d.rawMarkdown||"";return h.slice(0,40)+(h.length>40?"...":"")}return(c,d)=>(Q(),nt("div",jf,[g("div",Hf,[g("span",null,"幻灯片大纲 ("+_t(t.slides.length)+" 页)",1)]),g("div",Uf,[(Q(!0),nt(Gt,null,ye(t.slides,h=>(Q(),nt("div",{key:h.pageIndex,class:Et(["spm-card",{active:t.currentActivePage===h.pageIndex}]),onClick:p=>o(h.pageIndex)},[g("div",Vf,[g("span",Kf,"P"+_t(h.pageIndex),1),g("span",qf,_t(h.frontmatter.layout||"default"),1),g("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Te(p=>s(h),["stop"])},[ft(bt,{name:"settings"})],8,Gf)]),g("div",Zf,_t(a(h)),1),h.notes?(Q(),nt("div",Yf,[ft(bt,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),g("span",null,_t(h.notes),1)])):Ft("",!0)],10,Wf))),128))]),n.value?(Q(),nt("div",{key:0,class:"spm-inspector-modal-mask",onClick:d[1]||(d[1]=Te(h=>n.value=null,["self"]))},[g("div",Jf,[ft(Ff,{"block-id":n.value.startBlockId,"initial-attrs":r(n.value),onClose:d[0]||(d[0]=h=>n.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Ft("",!0)]))}}),Qf=Le(Xf,[["__scopeId","data-v-68b25edd"]]),tp={class:"spm-immersion-header"},ep={class:"spm-immersion-header__left"},ip={class:"spm-immersion-title"},np={class:"spm-immersion-header__center"},sp={class:"spm-immersion-header__actions"},op=["aria-label"],rp={class:"spm-immersion-body"},lp=be({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(t,{emit:i}){const e=t,n=i;function s(){n("update:visible",!1),n("close")}function r(){e.closeOnClickMask&&s()}function l(){n("update:isMaximized",!e.isMaximized),n("toggle-maximize")}function o(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),s())}return(a,c)=>Ie((Q(),nt("div",{class:Et(["spm-immersion-container",{"is-maximized":t.isMaximized}]),onKeydown:Te(o,["stop"])},[g("div",{class:"spm-immersion-mask",onClick:r}),g("div",{class:Et(["spm-immersion-drawer",{"is-maximized":t.isMaximized}])},[g("div",tp,[g("div",ep,[Pn(a.$slots,"header-left",{},()=>[g("span",ip,_t(t.title),1)])]),g("div",np,[Pn(a.$slots,"header-center",{},void 0)]),g("div",sp,[Pn(a.$slots,"header-actions",{},void 0),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":t.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[ft(bt,{name:t.isMaximized?"minimize":"maximize"},null,8,["name"])],8,op),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:s},[ft(bt,{name:"close"})])])]),g("div",rp,[Pn(a.$slots,"default",{},void 0)])],2)],34)),[[Pl,t.visible]])}}),ap=Le(lp,[["__scopeId","data-v-3f1665db"]]),cp="slidev-config.json",Gi={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806"},Ci=cs({...Gi});function dp(t){if(!t||typeof t!="object")return{...Gi};const i=t;return{enableWebServeJump:!!i.enableWebServeJump,webServeUrl:typeof i.webServeUrl=="string"&&i.webServeUrl.trim()?i.webServeUrl.trim():Gi.webServeUrl}}function Ui(t){if(!t||typeof t!="object")return{...Ci};const i=t;return i.enableWebServeJump!==void 0&&(Ci.enableWebServeJump=!!i.enableWebServeJump),i.webServeUrl!==void 0&&(Ci.webServeUrl=String(i.webServeUrl)),{...Ci}}function Co(){return{...Ci}}function Hl(t,i,e){const n=(t||Gi.webServeUrl).trim(),s=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,r=(e==null?void 0:e.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(s);let o=l.pathname.replace(/\/+$/,"");return o.endsWith("/stage/build/desktop")||(o=o?`${o}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${o}/`,l.searchParams.set("id",i),e!=null&&e.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",r),l.toString()}catch{const l=e!=null&&e.focus?"&focus=1":"";return`${s.replace(/\/+$/,"")}/stage/build/desktop/?id=${i}${l}&r=${r}`}}const up={class:"spm-protyle-drawer"},fp={class:"spm-protyle-drawer__subbar"},pp={class:"spm-protyle-drawer__nav"},hp=["title"],mp={class:"spm-protyle-drawer__actions"},gp=["aria-label"],vp=["aria-label"],bp=be({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(t,{emit:i}){const e=i,n=t,s=pt(n.blockId),r=pt(n.title||""),l=pt(!1),o=pt(!0),a=pt(!1),c=pt(""),d=Ci,h=pt([]),p=pt(null);let f=null;Ai(()=>n.blockId,I=>{I&&I!==s.value&&(s.value=I,r.value=n.title||"",h.value=[],m(I))}),_n(()=>{s.value&&m(s.value)}),mo(()=>{k()});async function w(I){try{const L=await pn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${I}' LIMIT 1`);if(Array.isArray(L)&&L.length>0){const R=L[0];c.value=R.root_id||"";const N=R.id===R.root_id||R.type==="d";a.value=N,o.value=!N,!r.value&&R.content&&(r.value=R.content.trim().slice(0,30));return}}catch(L){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",L)}a.value=!1,o.value=!0}async function m(I,L){if(!p.value||!I)return;k(),await w(I),typeof L=="boolean"&&(o.value=!a.value&&L);let R,N;o.value&&!a.value?(R=["cb-get-all","cb-get-hl","cb-get-focus"],N={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(R=["cb-get-context","cb-get-hl"],N={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{f=new ht.Protyle(n.plugin.app,p.value,{blockId:I,action:R,render:N}),!l.value&&f&&typeof f.disable=="function"&&f.disable()}catch(J){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",J)}}function k(){if(f){try{typeof f.destroy=="function"&&f.destroy()}catch(I){console.warn("[ProtylePeekDrawer] Error destroying protyle:",I)}f=null}p.value&&(p.value.innerHTML="")}function v(){a.value||(o.value=!o.value,m(s.value,o.value))}function b(){l.value=!l.value,f&&(l.value?(typeof f.enable=="function"&&f.enable(),typeof f.focus=="function"&&f.focus()):typeof f.disable=="function"&&f.disable())}function T(){if(s.value)try{ht.openWindow({doc:{id:s.value},alwaysOnTop:!0})}catch(I){console.warn("[ProtylePeekDrawer] openWindow failed:",I)}}function C(){var R;if(!s.value)return;const I=Co(),L=Hl(I.webServeUrl,s.value,{focus:!a.value});if(typeof window<"u"){const N=ke("electron");(R=N==null?void 0:N.shell)!=null&&R.openExternal?N.shell.openExternal(L).catch(()=>{window.open(L,"_blank")}):window.open(L,"_blank")}e("external-jump",L)}function A(){if(h.value.length>0){const I=h.value.pop();I&&(s.value=I.blockId,r.value=I.title,o.value=I.isFocusMode,a.value=I.isDoc,m(I.blockId,I.isFocusMode))}}function S(I){const L=I.target;if(!L)return;const R=L.closest('[data-type="block-ref"]');if(R){const J=R.getAttribute("data-id");if(J&&J!==s.value){I.preventDefault(),I.stopPropagation(),h.value.push({blockId:s.value,title:r.value||s.value,isFocusMode:o.value,isDoc:a.value}),s.value=J,r.value=R.innerText.trim()||J,m(J);return}}const N=L.closest("a");if(N&&N.href&&N.href.startsWith("siyuan://blocks/")){I.preventDefault(),I.stopPropagation();const J=N.href.replace("siyuan://blocks/","").split("?")[0];J&&J!==s.value&&(h.value.push({blockId:s.value,title:r.value||s.value,isFocusMode:o.value,isDoc:a.value}),s.value=J,r.value=N.innerText.trim()||J,m(J))}}return(I,L)=>(Q(),nt("div",up,[g("div",fp,[g("div",pp,[h.value.length>0?(Q(),nt("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:A},[ft(bt,{name:"arrow-left"}),L[0]||(L[0]=g("span",null,"返回",-1))])):Ft("",!0),g("span",{class:Et(["spm-protyle-badge",{"is-focus":o.value&&!a.value}])},_t(o.value&&!a.value?"思源块聚焦":"思源文档速览"),3),g("span",{class:"spm-protyle-id",title:r.value||s.value},_t(r.value||s.value),9,hp)]),g("div",mp,[a.value?Ft("",!0):(Q(),nt("button",{key:0,class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":o.value}]),"aria-label":o.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:v},[ft(bt,{name:o.value?"focus":"file-text"},null,8,["name"]),g("span",null,_t(o.value?"块聚焦":"展开全文"),1)],10,gp)),g("button",{class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:b},[ft(bt,{name:l.value?"edit":"eye"},null,8,["name"]),g("span",null,_t(l.value?"编辑中":"只读"),1)],10,vp),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:T},[ft(bt,{name:"window"}),L[1]||(L[1]=g("span",null,"独立窗口",-1))]),Si(d).enableWebServeJump?(Q(),nt("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:C},[ft(bt,{name:"external-link"}),L[2]||(L[2]=g("span",null,"外跳",-1))])):Ft("",!0)])]),g("div",{ref_key:"mountEl",ref:p,class:Et(["spm-protyle-mount",{"is-focus-mode":o.value&&!a.value}]),onClick:S},null,2)]))}}),yp=Le(bp,[["__scopeId","data-v-7e586ef3"]]),wp={class:"spm-webview-drawer"},kp={class:"spm-webview-toolbar"},xp={class:"spm-webview-toolbar__nav"},_p=["disabled"],Sp=["disabled"],Cp=["aria-label"],$p={class:"spm-webview-toolbar__address"},Ip=["aria-label"],Ap={class:"spm-webview-toolbar__actions"},Tp={class:"spm-zoom-controller"},Ep=["disabled"],Mp=["disabled"],Bp={key:1,class:"spm-webview-fallback"},Dp=["src"],Op=be({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(t,{emit:i}){const e=i,n=t,s=pt(zl()),r=pt(n.url),l=pt(n.url),o=pt(!1),a=pt(!1),c=pt(!1),d=pt(1),h=pt(!1),p=pt(null),f=pt(null);let w=null,m=null,k=null;Ai(()=>n.url,E=>{E&&E!==r.value&&(r.value=E,l.value=E,p.value&&typeof p.value.loadURL=="function"&&p.value.loadURL(E))}),Ai(()=>n.visible,E=>{if(E)y();else if(p.value)try{typeof p.value.stop=="function"&&p.value.stop()}catch{}}),_n(()=>{v(),f.value&&typeof ResizeObserver<"u"&&(w=new ResizeObserver(()=>{const E=p.value;if(E&&typeof E.invalidate=="function")try{E.invalidate()}catch{}}),w.observe(f.value)),m=E=>{var ot;const D=E.message||((ot=E.error)==null?void 0:ot.message);if(typeof D=="string"&&D.includes("Invalid guestInstanceId"))return E.preventDefault(),E.stopImmediatePropagation(),!0},window.addEventListener("error",m,!0),k=E=>{const D=E.reason,ot=typeof D=="string"?D:D==null?void 0:D.message;typeof ot=="string"&&ot.includes("Invalid guestInstanceId")&&E.preventDefault()},window.addEventListener("unhandledrejection",k)}),mo(()=>{if(b(),w&&(w.disconnect(),w=null),m&&(window.removeEventListener("error",m,!0),m=null),k&&(window.removeEventListener("unhandledrejection",k),k=null),p.value)try{typeof p.value.stop=="function"&&p.value.stop()}catch{}});function v(){const E=p.value;E&&(E.addEventListener("dom-ready",T),E.addEventListener("did-start-loading",C),E.addEventListener("did-stop-loading",A),E.addEventListener("did-navigate",S),E.addEventListener("did-navigate-in-page",I),E.addEventListener("new-window",L))}function b(){const E=p.value;if(E)try{E.removeEventListener("dom-ready",T),E.removeEventListener("did-start-loading",C),E.removeEventListener("did-stop-loading",A),E.removeEventListener("did-navigate",S),E.removeEventListener("did-navigate-in-page",I),E.removeEventListener("new-window",L)}catch{}}function T(){y(),R()}function C(){o.value=!0}function A(){if(o.value=!1,R(),p.value&&typeof p.value.getURL=="function"){const E=p.value.getURL();E&&E!=="about:blank"&&(r.value=E,l.value=E)}}function S(E){E!=null&&E.url&&(r.value=E.url,l.value=E.url),R()}function I(E){E!=null&&E.url&&(r.value=E.url,l.value=E.url),R()}function L(E){E&&E.url&&(E.preventDefault(),p.value&&typeof p.value.loadURL=="function"&&p.value.loadURL(E.url))}function R(){const E=p.value;E&&(typeof E.canGoBack=="function"&&(a.value=E.canGoBack()),typeof E.canGoForward=="function"&&(c.value=E.canGoForward()))}function N(){p.value&&typeof p.value.goBack=="function"&&p.value.goBack()}function J(){p.value&&typeof p.value.goForward=="function"&&p.value.goForward()}function x(){p.value&&typeof p.value.reload=="function"&&p.value.reload()}function q(){let E=l.value.trim();E&&(/^https?:\/\//i.test(E)||(E=`https://${E}`),r.value=E,l.value=E,p.value&&typeof p.value.loadURL=="function"&&p.value.loadURL(E))}function y(){const E=p.value;if(E&&typeof E.setZoomFactor=="function")try{E.setZoomFactor(d.value)}catch(D){console.warn("[WebviewPeekDrawer] setZoomFactor error:",D)}}function U(){d.value=Math.min(2.5,Math.round((d.value+.1)*10)/10),y()}function et(){d.value=Math.max(.5,Math.round((d.value-.1)*10)/10),y()}function j(){d.value=1,y()}function it(E){E.preventDefault(),E.deltaY<0?U():E.deltaY>0&&et()}async function V(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(r.value),h.value=!0,setTimeout(()=>{h.value=!1},2e3)}catch(E){console.warn("Copy url failed:",E)}}function Z(){var D;const E=r.value;if(typeof window<"u"){const ot=ke("electron");(D=ot==null?void 0:ot.shell)!=null&&D.openExternal?ot.shell.openExternal(E).catch(()=>{window.open(E,"_blank")}):window.open(E,"_blank")}e("external-jump",E)}return(E,D)=>{const ot=Uc("webview");return Q(),nt("div",wp,[g("div",kp,[g("div",xp,[g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!a.value,"aria-label":"后退",onClick:N},[ft(bt,{name:"arrow-left"})],8,_p),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"前进",onClick:J},[ft(bt,{name:"arrow-right"})],8,Sp),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":o.value?"正在加载...":"刷新页面",onClick:x},[ft(bt,{name:"refresh"})],8,Cp)]),g("div",$p,[Ie(g("input",{"onUpdate:modelValue":D[0]||(D[0]=rt=>l.value=rt),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:su(q,["enter"])},null,544),[[es,l.value]]),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":h.value?"已复制地址！":"复制网址",onClick:V},[ft(bt,{name:"copy"})],8,Ip)]),g("div",Ap,[g("div",Tp,[g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:d.value<=.5,onClick:et},[ft(bt,{name:"minus"})],8,Ep),g("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:j},_t(Math.round(d.value*100))+"% ",1),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:d.value>=2.5,onClick:U},[ft(bt,{name:"plus"})],8,Mp)]),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:Z},[ft(bt,{name:"external-link"}),D[1]||(D[1]=g("span",null,"外跳",-1))])])]),g("div",{ref_key:"containerEl",ref:f,class:"spm-webview-body",onWheel:Te(it,["ctrl"])},[s.value?(Q(),Ee(ot,{key:0,ref_key:"webviewRef",ref:p,class:"spm-webview-frame",src:r.value,allowpopups:"true",partition:"persist:slidev-peek",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src"])):(Q(),nt("div",Bp,[g("iframe",{class:"spm-webview-fallback-frame",src:r.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Dp),g("div",{class:"spm-fallback-bar"},[D[2]||(D[2]=g("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),g("button",{class:"spm-icon-btn is-primary",onClick:Z}," 在新标签页中打开 ↗ ")])]))],544)])}}}),Pp=Le(Op,[["__scopeId","data-v-4d90ba01"]]);class Lp{constructor(){vt(this,"timers",new Map)}debounce(i,e,n=150){this.cancel(i);const s=setTimeout(()=>{this.timers.delete(i),e()},n);this.timers.set(i,s)}cancel(i){this.timers.has(i)&&(clearTimeout(this.timers.get(i)),this.timers.delete(i))}cancelAll(){for(const i of this.timers.values())clearTimeout(i);this.timers.clear()}hasPending(i){return this.timers.has(i)}}class Rp{constructor(i){vt(this,"blockToPageMap",new Map);vt(this,"debounceCtrl",new Lp);vt(this,"activeBlockId","");vt(this,"activePageIndex",1);vt(this,"currentDocId","");vt(this,"bridge",null);i&&(this.bridge=i)}setBridge(i){this.bridge=i}setDocId(i){this.currentDocId=i}updateSlidesIndex(i){this.blockToPageMap.clear();for(const e of i){e.startBlockId&&this.blockToPageMap.set(e.startBlockId,e.pageIndex);for(const n of e.blocks)this.blockToPageMap.set(n.id,e.pageIndex)}}getPageByBlockId(i){return this.blockToPageMap.get(i)??null}onCursorFocusBlock(i){if(!i||i===this.activeBlockId)return;this.activeBlockId=i;let e=this.getPageByBlockId(i);!e&&(i===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(e=1),e&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=e,this.bridge&&(this.bridge.navigatePage(e),this.bridge.highlightElement(i))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(i){this.activeBlockId=i;const e=this.getPageByBlockId(i);e&&(this.activePageIndex=e)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Ti(t,i){var r,l;if(!t||typeof document>"u")return!1;const e=(r=globalThis.CSS)!=null&&r.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`);if(!n){if(i)try{return ht.openTab({app:i,doc:{id:t,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(o){console.warn("[SelectionMirror] openTab fallback failed:",o)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const s=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=s},1200),!0}function fe(t){return t?t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function zp(t){if(!t||t.trim()===""||t.trim()==="all")return"all";const i=new Set,e=t.split("|");for(const n of e){const s=n.trim();if(s==="all")return"all";if(s.includes("-")){const[r,l]=s.split("-"),o=parseInt(r,10),a=parseInt(l,10);if(!isNaN(o)&&!isNaN(a))for(let c=Math.min(o,a);c<=Math.max(o,a);c++)i.add(c)}else{const r=parseInt(s,10);isNaN(r)||i.add(r)}}return i}const Np=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function Me(t){if(!t)return"";const i=[],e=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,r)=>{const l=r.toLowerCase();if(!Np.has(l)||/on\w+\s*=|javascript:/i.test(s))return s;if(l==="v-mark"){const o=s.match(/type=["']?([a-zA-Z-]+)["']?/),a=o?o[1]:"circle";return s.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${a}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(s),`%%SAFE_HTML_${i.length-1}%%`});let n=fe(e);return n=n.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,r,l,o,a,c,d)=>{const p=(l??o??a??c??d??"").trim()||`Ref(${r.slice(0,8)})`;return`<a href="siyuan://blocks/${r}" data-ref-id="${r}" class="slidev-ref-tag">🔗 ${p}</a>`}),n=n.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),n=n.replace(/!\[(.*?)\]\((.*?)\)/g,(s,r,l)=>{const a=/\.gif(?:\?|$)/i.test(l)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${r}" src="${l}" class="${a}" />`}),n=n.replace(/\[(.*?)\]\((.*?)\)/g,(s,r,l)=>{if(l.startsWith("siyuan://blocks/")){const o=l.replace("siyuan://blocks/","").split("?")[0];return`<a href="${l}" data-ref-id="${o}" class="slidev-ref-tag">🔗 ${r}</a>`}return`<a href="${l}" target="_blank" rel="noopener noreferrer" class="slidev-link">${r}</a>`}),n=n.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,r,l,o)=>`${r}<a href="${l}" data-ref-id="${o}" class="slidev-ref-tag">🔗 ${l}</a>`),n=n.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),n=n.replace(/\*(.*?)\*/g,"<em>$1</em>"),n=n.replace(/~~(.*?)~~/g,"<del>$1</del>"),n=n.replace(/`([^`]+)`/g,"<code>$1</code>"),n=n.replace(/%%SAFE_HTML_(\d+)%%/g,(s,r)=>{const l=parseInt(r,10);return i[l]||""}),n}function Fp(t,i="pdf-table"){if(t.length<2)return"";const e=t.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=e[0];let s=[],r=1;t.length>=2&&e[1].every(a=>/^:?-+:?$/.test(a))&&(s=e[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),r=2);const l=`<thead><tr>${n.map((a,c)=>`<th${s[c]?` style="text-align: ${s[c]}"`:""}>${Me(a)}</th>`).join("")}</tr></thead>`,o=e.slice(r).map(a=>`<tr>${a.map((c,d)=>`<td${s[d]?` style="text-align: ${s[d]}"`:""}>${Me(c)}</td>`).join("")}</tr>`).join("");return`<table class="${i}">${l}<tbody>${o}</tbody></table>`}function Es(t){return String(t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function jp(t,i="ts"){if(!t)return"";if(t.trim().startsWith("//"))return`<span class="token-comment">${Es(t)}</span>`;const e=[];function n(r,l){return e.push(`<span class="${r}">${Es(l)}</span>`),`__TOK_${e.length-1}__`}let s=t.replace(/(['"`])(.*?)\1/g,(r,l,o)=>n("token-string",`${l}${o}${l}`));return s=s.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,r=>n("token-keyword",r)),s=s.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,r=>n("token-type",r)),s=s.replace(/\b(\d+)\b/g,r=>n("token-number",r)),s=Es(s),s=s.replace(/__TOK_(\d+)__/g,(r,l)=>e[parseInt(l,10)]||""),s}function Hp(t,i){if(!t)return null;const e=t.frontmatter||{};if(e.hideInToc===!0||e.hideInToc==="true")return null;let n=(e.title||"").trim(),s=e.level?parseInt(e.level,10):0;if(!n){const r=t.blocks||[];for(const l of r){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){s||(s=a[1].length),n=a[2].trim();break}}}return n?((!s||isNaN(s))&&(s=1),{pageIndex:t.pageIndex||i,title:n,level:s}):null}function Up(t,i=1,e={}){const n=e.minDepth!==void 0?Number(e.minDepth):1,s=e.maxDepth!==void 0?Number(e.maxDepth):1/0,r=[];Array.isArray(t)&&t.forEach((c,d)=>{const h=Hp(c,d+1);h&&r.push(h)});const l=[];let o=null;for(const c of r){const d={...c,active:c.pageIndex===i,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),o=d):o?(d.active&&(o.hasActiveChild=!0),o.children.push(d)):l.push(d)}function a(c,d=1){if(d>s)return[];const h=[];for(const p of c){const f=a(p.children,d+1);d>=n?h.push({...p,children:f}):h.push(...f)}return h}return a(l,1)}function Wp(t,i=1,e={}){const n=Up(t,i,e),s=e.columns?Number(e.columns):1,r=s>1?` style="column-count: ${s};"`:"",l=e.textSm?" text-sm":"";function o(c,d=1){if(!c||c.length===0)return"";const h=`slidev-toc-list slidev-toc-list-level-${d}`,p=c.map(f=>{const w=f.active?" slidev-toc-item-active":f.hasActiveChild?" slidev-toc-item-parent-active":"",m=f.children&&f.children.length>0?o(f.children,d+1):"";let k=Me(f.title);return k.includes("LaTeX")&&(k=k.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${w}" data-page="${f.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${k}</span>
          </a>
          ${m}
        </li>
      `}).join("");return`<ol class="${h}">${p}</ol>`}const a=o(n,1);return`<div class="slidev-toc${l}"${r}>${a}</div>`}function Vp(t,i,e){var f,w,m,k;const n=t.split(`
`);if(!n.some(v=>/^(\s*)([-*+]|\d+\.)\s+/.test(v)))return null;const r=[],l=[];let o=!1;for(let v=0;v<n.length;v++){const b=n[v];if(!b.trim())continue;const T=b.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(T){l.push({type:"task",checked:T[2].toLowerCase()==="x",text:T[3],media:[]});continue}const C=b.match(/^(\s*)[-*+]\s+(.*)$/);if(C){l.push({type:"unordered",text:C[2],media:[]});continue}const A=b.match(/^(\s*)\d+\.\s+(.*)$/);if(A){l.length===0&&(o=!0),l.push({type:"ordered",text:A[2],media:[]});continue}const S=b.trim();if(l.length>0){const I=S.match(/^!\[(.*?)\]\((.*?)\)$/);if(I){const N=/\.gif(?:\?|$)/i.test(I[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${fe(I[1])}" src="${I[2]}" class="${N}" /></div>`);continue}if(S.match(/^<img\b[\s\S]*?\/?>$/i)){l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${S}</div>`);continue}if(/<video\b/i.test(S)){let R=S;if(!/<\/video>/i.test(R))for(;v+1<n.length&&!/<\/video>/i.test(R);)v++,R+=" "+n[v].trim();const N=((f=e==null?void 0:e.attributes)==null?void 0:f["custom-slidev-autoplay"])==="true"||/autoplay/i.test(R),J=((w=e==null?void 0:e.attributes)==null?void 0:w["custom-slidev-loop"])==="true"||/loop/i.test(R),x=((m=e==null?void 0:e.attributes)==null?void 0:m["custom-slidev-muted"])==="true"||N||/muted/i.test(R),q=((k=e==null?void 0:e.attributes)==null?void 0:k["custom-slidev-controls"])==="false",y=R.match(/\bsrc=["']([^"']+)["']/i),U=y?y[1]:"",et=['class="slide-video-player"'];q||et.push("controls"),N&&(et.push("autoplay"),et.push("playsinline")),J&&et.push("loop"),x&&et.push("muted"),et.push('preload="metadata"'),U&&et.push(`src="${U}"`);const j=R.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let it=j?j[1].trim():"";!it&&U&&(it=`<source src="${U}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${N?"true":"false"}" data-muted="${x?"true":"false"}"><video ${et.join(" ")}>${it}</video></div>`);continue}l[l.length-1].text+=`
`+S}else r.push(S)}if(l.length===0)return null;function a(v){if(!v)return"";const b=v.split(`
`).map(I=>I.trim()).filter(Boolean);if(b.length===0)return"";if(!b.some(I=>/^#{1,6}\s+/.test(I)))return Me(b.join(" "));const C=[];let A=[];const S=()=>{if(A.length>0){const I=A.join(" ");C.push(`<p class="slide-list-item-desc">${Me(I)}</p>`),A=[]}};for(const I of b){const L=I.match(/^(#{1,6})\s+(.*)$/);if(L){S();const R=L[1].length,N=L[2].trim();C.push(`<h${R} class="slide-list-item-title">${Me(N)}</h${R}>`)}else A.push(I)}return S(),C.join(`
`)}const c=o?"ol":"ul",d=o?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered",h=l.map(v=>{const b=a(v.text),T=v.media&&v.media.length>0?`
${v.media.join(`
`)}`:"";return v.type==="task"?`<li class="pdf-task-item"><label><input type="checkbox" disabled=""${v.checked?' checked=""':""}/> <span>${b}</span></label>${T}</li>`:`<li>${b}${T}</li>`}).join(`
`);return`${r.length>0?`<p>${Me(r.join(" "))}</p>
`:""}<${c} class="${d}">
${h}
</${c}>`}function xe(t,i){var p,f,w,m,k,v,b,T;let e="",n="";if((p=t.motion)!=null&&p.preset&&t.motion.preset!=="none"){e=` slidev-motion-${t.motion.preset.toLowerCase()}`;const C=[];typeof t.motion.duration=="number"&&t.motion.duration>0&&C.push(`--motion-duration:${t.motion.duration}ms`),typeof t.motion.delay=="number"&&t.motion.delay>0&&C.push(`--motion-delay:${t.motion.delay}ms`),C.length>0&&(n=` style="${C.join(";")}"`)}const r=`pdf-block${e}`,l=(t.rawMarkdown||t.content||"").trim();if(!l)return`<div class="${r}"${n}></div>`;if(l.includes('class="slidev-block-ref"')||l.includes('class="slidev-ref-tag"'))return`<div class="${r}"${n}>${l}</div>`;if(l.startsWith("$$")&&l.endsWith("$$")){const C=l.slice(2,-2).trim();return`<div class="${r} katex-display-container"${n}><div class="katex-display font-math"><em>${fe(C)}</em></div></div>`}const o=l.match(/^(#{1,6})\s+(.*)$/);if(o){const C=o[1].length,A=Me(o[2]);return`<div class="${r}"${n}><h${C}>${A}</h${C}></div>`}if(l.startsWith(":::")){const C=l.split(`
`),S=C[0].replace(/^:::\s*/,"").trim()||"info",I=C.slice(1,C[C.length-1].startsWith(":::")?-1:void 0).join(`
`),L="pdf-callout";return`<div class="${r}"${n}><div class="${L} ${L}--${S}"><div class="${L}-title">${S.toUpperCase()}</div><div class="${L}-body">${Me(I)}</div></div></div>`}if(l.startsWith("<<<")){const S=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((N,J)=>`<span class="code-line shiki-focus"><span class="line-no">${J+1}</span><span class="line-content">${jp(N,"ts")}</span></span>`).join(`
`),I="pdf-code shiki-container",L=((f=t.attrs)==null?void 0:f["custom-slidev-max-height"])||t.maxHeight||"",R=L?` style="max-height:${fe(L)};overflow-y:auto;"`:"";return`<div class="${r}"${n}><pre class="${I}"${R}><span class="lang-badge">TS</span><code>${S}</code></pre></div>`}if(l.startsWith("<style")||l.startsWith("<!-- Inline style -->")||l.startsWith(`<!--
Notes`))return"";if(l.startsWith("```")){const C=l.split(`
`),A=C[0].slice(3).trim(),S=A.match(/^([^\s{\[]+)/),I=S?S[1]:"",L=A.match(/\[([^\]]+)\]/),R=L?L[1]:"",N=A.includes("twoslash"),J=t.shikiLines||((w=A.match(/\{([^}]+)\}/))==null?void 0:w[1])||"",x=zp(J),q=C.length>2?C[C.length-1]==="```"?C.slice(1,-1):C.slice(1):[l.slice(3).replace(/```$/,"")],y="pdf-code shiki-container",U=R?`${y} has-filename`:y,et=x!=="all",j=q.map((D,ot)=>{const rt=ot+1,kt=x==="all"||x.has(rt)?"code-line shiki-focus":et?"code-line shiki-dimmed":"code-line";let $t=fe(D);return N&&D.includes("doubled.value = 2")?($t=$t.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${kt}"><span class="line-no">${rt}</span><span class="line-content">${$t}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${kt}"><span class="line-no">${rt}</span><span class="line-content">${$t}</span></span>`}).join(`
`),it=I?`<span class="lang-badge">${fe(I)}</span>`:"",V=R?`<span class="code-filename">${fe(R)}</span>`:"",Z=((m=t.attrs)==null?void 0:m["custom-slidev-max-height"])||t.maxHeight||"",E=Z?` style="max-height:${fe(Z)};overflow-y:auto;"`:"";return`<div class="${r}"${n}><pre class="${U}"${E}>${V}${it}<code>${j}</code></pre></div>`}if(l.includes("|")&&l.split(`
`).filter(C=>C.trim().startsWith("|")).length>=2){const C=l.split(`
`).filter(S=>S.trim().startsWith("|")),A=Fp(C,i==null?void 0:i.tableClassName);return`<div class="${r}"${n}>${A}</div>`}if(l.startsWith("> "))return`<div class="${r}"${n}><blockquote class="pdf-quote"><p>${Me(l.slice(2))}</p></blockquote></div>`;const a=/<video\b/i.test(l)||t.type==="video"||t.type==="NodeVideo",c=/^(\s*)([-*+]|\d+\.)\s+/m.test(l);if(a&&!c){const C=((k=t.attributes)==null?void 0:k["custom-slidev-autoplay"])==="true"||/autoplay/i.test(l),A=((v=t.attributes)==null?void 0:v["custom-slidev-loop"])==="true"||/loop/i.test(l),S=((b=t.attributes)==null?void 0:b["custom-slidev-muted"])==="true"||C||/muted/i.test(l),I=((T=t.attributes)==null?void 0:T["custom-slidev-controls"])==="false",L=l.match(/\bsrc=["']([^"']+)["']/i),R=L?L[1]:"",N=['class="slide-video-player"'];I||N.push("controls"),C&&(N.push("autoplay"),N.push("playsinline")),A&&N.push("loop"),S&&N.push("muted"),N.push('preload="metadata"'),R&&N.push(`src="${R}"`);const J=l.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let x=J?J[1].trim():"";return!x&&R&&(x=`<source src="${R}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${r} ${r}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${C?"true":"false"}" data-muted="${S?"true":"false"}"${n}><video ${N.join(" ")}>${x}</video></div>`}const d=l.match(/^!\[(.*?)\]\((.*?)\)$/);if(d)return`<div class="${r} ${r}--image slide-media-block slide-media-container"${n}><img alt="${fe(d[1])}" src="${d[2]}" class="pdf-image slide-media-img" /></div>`;const h=Vp(l,i,t);if(h)return`<div class="${r} pdf-list-item"${n}>${h}</div>`;if(/<(?:Toc|toc)\b/i.test(l)&&!l.startsWith("```")){const C=l.match(/minDepth=["']?(\d+)["']?/i),A=l.match(/maxDepth=["']?(\d+)["']?/i),S=l.match(/columns=["']?(\d+)["']?/i);return`<div class="${r}"${n}>${Wp([],1,{minDepth:C?parseInt(C[1],10):1,maxDepth:A?parseInt(A[1],10):1/0,columns:S?parseInt(S[1],10):1,textSm:l.includes("text-sm")})}</div>`}return`<div class="${r}"${n}><p>${Me(l)}</p></div>`}function Kp(t,i){var r,l,o,a;const e=((r=t.frontmatter)==null?void 0:r.layout)||"default",s=(t.blocks||[]).filter(c=>c.slot!=="slot-divider-right");if(e==="two-cols"){const c=s.some(b=>b.slot==="right");let d=[],h=[];if(c)d=s.filter(b=>b.slot!=="right"),h=s.filter(b=>b.slot==="right");else{const b=Math.ceil(s.length/2);d=s.slice(0,b),h=s.slice(b)}const p=d.map(b=>xe(b,i)).join(`
`),f=h.map(b=>xe(b,i)).join(`
`),w="pdf-two-cols-wrapper layout-two-cols-grid",m=(l=t.frontmatter)!=null&&l.layoutClass?` ${t.frontmatter.layoutClass}`:"";return`
      <div class="${w}${m}">
        <div class="pdf-col pdf-col--left">${p}</div>
        <div class="pdf-col pdf-col--right">${f}</div>
      </div>
    `}if(e==="two-cols-header"){let c=[];const d=s.filter(b=>b.slot==="header");if(d.length>0)c=d;else if(s.length>0){const b=s.find(T=>T.type==="h"&&(!T.slot||T.slot==="default"));b&&(c=[b])}const h=s.filter(b=>!c.includes(b)),p=h.filter(b=>b.slot==="right"||b.slot==="col-2"),f=h.filter(b=>!p.includes(b)),w=b=>{if(b.length===1&&Wi(b[0])){const T=zs(b[0].rawMarkdown);return xe({...b[0],rawMarkdown:T},i)}return b.map(T=>xe(T,i)).join(`
`)},m=c.map(b=>xe(b,i)).join(`
`),k=w(f),v=w(p);return`
      <div class="layout-two-cols-header-container">
        <div class="layout-header-section">${m}</div>
        <div class="pdf-two-cols-wrapper layout-two-cols-grid">
          <div class="pdf-col pdf-col--left">${k}</div>
          <div class="pdf-col pdf-col--right">${v}</div>
        </div>
      </div>
    `}if(e==="three-cols-header"){let c=[];const d=s.filter(C=>C.slot==="header");if(d.length>0)c=d;else if(s.length>0){const C=s.find(A=>A.type==="h"&&(!A.slot||A.slot==="default"));C&&(c=[C])}const h=s.filter(C=>!c.includes(C)),{col1:p,col2:f,col3:w}=Tr(h),m=C=>{if(C.length===1&&Wi(C[0])){const A=zs(C[0].rawMarkdown);return xe({...C[0],rawMarkdown:A},i)}return C.map(A=>xe(A,i)).join(`
`)},k=c.map(C=>xe(C,i)).join(`
`),v=m(p),b=m(f),T=m(w);return`
      <div class="layout-three-cols-header-container">
        <div class="layout-header-section">${k}</div>
        <div class="pdf-three-cols-wrapper layout-three-cols-grid">
          <div class="pdf-col pdf-col--1">${v}</div>
          <div class="pdf-col pdf-col--2">${b}</div>
          <div class="pdf-col pdf-col--3">${T}</div>
        </div>
      </div>
    `}if(e==="image-right"||e==="image-left"){const c=e==="image-right",d=s.map(m=>xe(m,i)).join(`
`),h=((o=t.frontmatter)==null?void 0:o.image)||((a=t.frontmatter)==null?void 0:a.background)||"",p=`<div class="pdf-image-col" style="background-image:url('${fe(h)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${fe(h)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,f=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${d}</div>`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:1fr 1fr;grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${c?`${f}
${p}`:`${p}
${f}`}
      </div>
    `}return e==="fact"?`<div class="layout-fact-container">${s.map(d=>xe(d,i)).join(`
`)}</div>`:e==="cover"?`<div class="layout-cover-container">${s.map(d=>xe(d,i)).join(`
`)}</div>`:s.map(c=>xe(c,i)).join(`
`)}function Ul(t,i){const e="Slidev 演示文稿";let n=t.slides;const s=JSON.stringify(n),r=JSON.stringify(t.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${fe(e)}</title>
  <style>
    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      gap: 32px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: 24px;
      flex-shrink: 0;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      gap: 24px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏（超级块分栏）布局：去除列表圆点标记与缩进 */
    .layout-two-cols ul,
    .layout-two-cols ol,
    .layout-two-cols-header ul,
    .layout-two-cols-header ol,
    .layout-three-cols ul,
    .layout-three-cols ol,
    .layout-three-cols-header ul,
    .layout-three-cols-header ol,
    .two-cols-left ul,
    .two-cols-left ol,
    .two-cols-right ul,
    .two-cols-right ol,
    .three-cols-col ul,
    .three-cols-col ol,
    .pdf-col ul,
    .pdf-col ol,
    .pdf-col .pdf-list,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }

    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }

    .layout-two-cols li::marker,
    .layout-two-cols-header li::marker,
    .layout-three-cols li::marker,
    .layout-three-cols-header li::marker,
    .two-cols-left li::marker,
    .two-cols-right li::marker,
    .pdf-col li::marker {
      content: none !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      display: block !important;
      margin: auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: #000;
      outline: none;
    }

    .slide-list-media {
      display: flex !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      margin-top: 8px !important;
      margin-bottom: 6px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: min(340px, 42vh) !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 auto;
      min-height: 0;
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow-y: auto;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container,
    .two-cols-left img,
    .two-cols-right img,
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .layout-three-cols-grid video {
      max-width: 100% !important;
      max-height: min(100%, 340px, 44vh) !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(t.docId)},
      slides: ${s},
      config: ${r}
    };
  <\/script>
</head>
<body>
  <div id="app">
    <div class="slide-viewport slidev-theme-${t.config.theme||"default"}" id="viewport" data-slidev-theme="${t.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">⛶ 全屏</button>
    </div>
  </div>

  <script>
    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function renderBlock(block) {
        const div = document.createElement("div");
        div.className = "slide-block";
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        if (md.startsWith("### ")) div.innerHTML = "<h3>" + md.slice(4) + "</h3>";
        else if (md.startsWith("## ")) div.innerHTML = "<h2>" + md.slice(3) + "</h2>";
        else if (md.startsWith("# ")) div.innerHTML = "<h1>" + md.slice(2) + "</h1>";
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md)) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md)) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) { items.push({ text: um[2], media: [] }); continue; }
            if (om) { if (items.length === 0) isOrdered = true; items.push({ text: om[2], media: [] }); continue; }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                items[items.length - 1].media.push('<div class="slide-list-media">' + tr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            }
          }
          const tag = isOrdered ? "ol" : "ul";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            if (!hasHeading) {
              let h = it.text.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return "<li>" + h + med + "</li>";
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.join(" ").replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const lvl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return "<li>" + parts.join("
") + med + "</li>";
          }).join("
");
          div.innerHTML = "<" + tag + " class="pdf-list">
" + liHtml + "
</" + tag + ">";
        }
        else {
          const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
          if (imgMatch) {
            div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
            div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
          } else {
            let html = md.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
            div.innerHTML = "<p>" + html + "</p>";
          }
        }
        return div;
      }

      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default");
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          for (const block of (slide.blocks || [])) {
            const el = renderBlock(block);
            if (block.slot === "right") rightCol.appendChild(el);
            else leftCol.appendChild(el);
          }
          container.appendChild(leftCol);
        } else if (slide.frontmatter?.layout === "two-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-two-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-two-cols-wrapper layout-two-cols-grid";
          const leftCol = document.createElement("div");
          leftCol.className = "pdf-col pdf-col--left";
          const rightCol = document.createElement("div");
          rightCol.className = "pdf-col pdf-col--right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of rem) {
            if (b.slot === "right" || b.slot === "col-2") rightCol.appendChild(renderBlock(b));
            else leftCol.appendChild(renderBlock(b));
          }
          gridDiv.appendChild(leftCol);
          gridDiv.appendChild(rightCol);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "three-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-three-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-three-cols-wrapper layout-three-cols-grid";
          const col1 = document.createElement("div");
          col1.className = "pdf-col pdf-col--1";
          const col2 = document.createElement("div");
          col2.className = "pdf-col pdf-col--2";
          const col3 = document.createElement("div");
          col3.className = "pdf-col pdf-col--3";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          let c1 = [], c2 = [], c3 = [];
          const hasExplicitCols = rem.some(b => b.slot === "col-1" || b.slot === "col-2" || b.slot === "col-3" || b.slot === "center" || b.slot === "left" || b.slot === "right");
          if (hasExplicitCols) {
            c2 = rem.filter(b => b.slot === "col-2" || b.slot === "center");
            c3 = rem.filter(b => b.slot === "col-3" || b.slot === "right");
            c1 = rem.filter(b => !c2.includes(b) && !c3.includes(b));
          } else if (rem.length >= 3) {
            const count1 = Math.ceil(rem.length / 3);
            const count2 = Math.ceil((rem.length - count1) / 2);
            c1 = rem.slice(0, count1);
            c2 = rem.slice(count1, count1 + count2);
            c3 = rem.slice(count1 + count2);
          } else if (rem.length === 2) {
            c1 = [rem[0]];
            c2 = [rem[1]];
            c3 = [];
          } else if (rem.length === 1) {
            const lines = (rem[0].rawMarkdown || rem[0].content || "").trim().split(/\r?
/);
            const itemStartIndices = [];
            for (let i = 0; i < lines.length; i++) {
              if (/^[ 	]*[-*+]s+|^[ 	]*d+.s+/.test(lines[i])) itemStartIndices.push(i);
            }
            if (itemStartIndices.length >= 3) {
              const count1 = Math.ceil(itemStartIndices.length / 3);
              const count2 = Math.ceil((itemStartIndices.length - count1) / 2);
              const items1 = lines.slice(itemStartIndices[0], itemStartIndices[count1]).join("
");
              const items2 = lines.slice(itemStartIndices[count1], itemStartIndices[count1 + count2]).join("
");
              const items3 = lines.slice(itemStartIndices[count1 + count2]).join("
");
              c1 = [{ ...rem[0], rawMarkdown: items1, content: items1 }];
              c2 = [{ ...rem[0], id: rem[0].id + "-col2", rawMarkdown: items2, content: items2 }];
              c3 = [{ ...rem[0], id: rem[0].id + "-col3", rawMarkdown: items3, content: items3 }];
            } else {
              c1 = rem;
            }
          } else {
            c1 = rem;
          }
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of c1) col1.appendChild(renderBlock(b));
          for (const b of c2) col2.appendChild(renderBlock(b));
          for (const b of c3) col3.appendChild(renderBlock(b));
          gridDiv.appendChild(col1);
          gridDiv.appendChild(col2);
          gridDiv.appendChild(col3);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of (slide.blocks || [])) {
            contentCol.appendChild(renderBlock(block));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          if (isImageRight) {
            container.appendChild(contentCol);
            container.appendChild(imgCol);
          } else {
            container.appendChild(imgCol);
            container.appendChild(contentCol);
          }
        } else {
          for (const block of (slide.blocks || [])) {
            container.appendChild(renderBlock(block));
          }
        }

        function syncAutoplayVideos() {
          setTimeout(() => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.playsInline = true;
                const p = v.play();
                if (p !== undefined) p.catch(() => {});
              }
            });
          }, 60);
        }
        syncAutoplayVideos();
      }

      btnPrev.addEventListener("click", () => renderSlide(currentIndex - 1));
      btnNext.addEventListener("click", () => renderSlide(currentIndex + 1));
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "ArrowRight" || e.key === " ") renderSlide(currentIndex + 1);
        if (e.key === "ArrowLeft") renderSlide(currentIndex - 1);
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      document.addEventListener("click", (e) => {
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          renderSlide(currentIndex - 1);
        } else {
          renderSlide(currentIndex + 1);
        }
      });

      renderSlide(0);
      updateScale();
    })();
  <\/script>
</body>
</html>`}function Wl(t,i){if(typeof document>"u")return!1;const e=new Blob([i],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(e),s=document.createElement("a");return s.href=n,s.download=t.endsWith(".html")?t:`${t}.html`,document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(n),!0}function qp(t){switch(t){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function Gp(t,i){const e="Slidev 演示讲义",n="16:9",s="light",r=qp(n),l=t.slides.map((o,a)=>{const c=o.frontmatter.layout||"default",d=Kp(o),h=`${a+1} / ${t.slides.length}`;return`
      <section class="pdf-slide-page layout-${c} theme-${s}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${fe(e)}</span>
          ${`<span class="pdf-page-badge">P. ${h}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${d}
        </div>
        ${o.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${fe(o.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${fe(e)} - 高保真讲义</title>
  <style>
    @page {
      ${r}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: 40px 60px;
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      align-items: center;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      gap: 36px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: 24px;
      flex-shrink: 0;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      gap: 24px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video {
      max-height: min(100%, 340px, 44vh) !important;
      width: auto !important;
      max-width: 100% !important;
      object-fit: contain !important;
      display: block !important;
      margin: auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏（超级块分栏）布局：去除列表圆点标记与缩进 */
    .layout-two-cols ul,
    .layout-two-cols ol,
    .layout-two-cols-header ul,
    .layout-two-cols-header ol,
    .layout-three-cols ul,
    .layout-three-cols ol,
    .layout-three-cols-header ul,
    .layout-three-cols-header ol,
    .pdf-two-cols-wrapper ul,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ul,
    .pdf-three-cols-wrapper ol,
    .pdf-col ul,
    .pdf-col ol,
    .pdf-col .pdf-list,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    .layout-two-cols li::marker,
    .layout-two-cols-header li::marker,
    .layout-three-cols li::marker,
    .layout-three-cols-header li::marker,
    .pdf-col li::marker {
      content: none !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
    }
  </style>
</head>
<body>
  ${l}
</body>
</html>`}function Vl(t,i){var s;if(typeof window>"u"||typeof document>"u")return!1;const e=Gp(t);try{const r=document.createElement("iframe");r.style.position="fixed",r.style.right="0",r.style.bottom="0",r.style.width="0",r.style.height="0",r.style.border="none",r.style.visibility="hidden",document.body.appendChild(r);const l=(s=r.contentWindow)==null?void 0:s.document;if(l)return l.open(),l.write(e),l.close(),setTimeout(()=>{var o,a;try{(o=r.contentWindow)==null||o.focus(),(a=r.contentWindow)==null||a.print()}finally{setTimeout(()=>{r.remove()},2e3)}},350),!0}catch(r){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",r)}const n=window.open("","_blank");return n?(n.document.write(e),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const Zp={class:"spm-slidev-preview-tab"},Yp={class:"spm-slidev-tab__toolbar"},Jp={class:"spm-slidev-tab__actions"},Xp=["disabled"],Qp={class:"spm-page-badge"},th=["disabled"],eh=["aria-label"],ih=["aria-label"],nh=["src"],sh=be({__name:"SlidevPreviewTab",setup(t,{expose:i}){const e=Qe("plugin"),n=Qe("sandboxBridge",new _o),s=new Rp(n),r=new bu,l=pt("web-sandbox"),o=pt(3030),a=pt(null),c=pt(!1),d=pt(null),h=pt(1),p=pt(1),f=pt([]),w=pt(!1),m=pt(!1),k=pt(!1),v=pt("siyuan"),b=pt(""),T=pt(""),C=pt(""),A=pt(!1),S=pt(!1),I=pt(""),L=pt("/plugins/siyuan-slidev/slidev-client/index.html");let R=null,N=null,J=null,x=null,q=null,y=null,U=null;_n(()=>{d.value&&(n.attach(d.value),r.nativeBridge.attach(d.value)),R=n.onSlideChanged((Y,lt)=>{h.value=Y,p.value=lt}),N=n.onBlockClicked((Y,lt)=>{h.value=lt,s.setActiveBlockId(Y),e&&typeof e.handleBlockClickedFromSlide=="function"?e.handleBlockClickedFromSlide(Y,lt):Ti(Y,e==null?void 0:e.app)}),J=n.onOpenInEditor((Y,lt)=>{h.value=lt,s.setActiveBlockId(Y),Ti(Y,e==null?void 0:e.app)}),x=r.nativeBridge.onPageChanged((Y,lt)=>{h.value=Y,p.value=lt}),q=n.onOpenPeekDrawer(async Y=>{const lt=Co();if(Y.peekType==="siyuan"&&lt.enableWebServeJump){let dt=!1;if(U&&U.docId===Y.target)dt=!0;else if(U&&U.slides&&U.slides.some(M=>{var P;return(P=M.blocks)==null?void 0:P.some(u=>u.id===Y.target)}))dt=!1;else try{const M=await pn(`SELECT id, root_id, type FROM blocks WHERE id = '${Y.target}' LIMIT 1`);M&&M.length>0&&(dt=M[0].type==="d"||M[0].id===M[0].root_id)}catch(M){console.warn("[SlidevPreviewTab] detect block type failed:",M)}v.value="web",A.value=!0,T.value=Hl(lt.webServeUrl,Y.target,{focus:!dt}),C.value=Y.title||`${dt?"思源文档":"思源块"}: ${Y.target.slice(0,8)}`,m.value=!0,n.freezeKeyboardNav(!0)}else v.value=Y.peekType,Y.peekType==="siyuan"?(b.value=Y.target,C.value=Y.title||`块速览: ${Y.target.slice(0,8)}`):(A.value=!0,T.value=Y.target,C.value=Y.title||Y.target),m.value=!0,n.freezeKeyboardNav(!0)}),y=n.onRequestToggleFullscreen(()=>{st()}),typeof document<"u"&&document.addEventListener("fullscreenchange",rt)}),go(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",rt),q&&q(),y&&y(),R&&R(),N&&N(),J&&J(),x&&x(),n.detach(),s.destroy(),r.destroy()});async function et(){if(l.value==="web-sandbox"){if(!U){ht.showMessage("请先在主编辑区打开演示文档");return}ht.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const Y=await r.startProMode(U,Os);if(!Y.success){ht.showMessage(`无法启动官方 Pro 模式：${Y.error}`);return}l.value="pro-cli",o.value=Y.port||3030,L.value=Y.url,d.value&&r.nativeBridge.attach(d.value),ht.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${o.value})`)}else r.stopProMode(),l.value="web-sandbox",L.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&n.attach(d.value),ht.showMessage("已切回内置高保真沙箱")}function j(){S.value=!S.value,S.value?I.value=(U==null?void 0:U.docId)||"":(I.value="",E())}function it(){h.value>1&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(h.value-1):n.navigatePage(h.value-1))}function V(){h.value<p.value&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(h.value+1):n.navigatePage(h.value+1))}function Z(Y){h.value=Y,l.value==="pro-cli"?r.nativeBridge.navigateToPage(Y):n.navigatePage(Y)}function E(){e&&typeof e.compileCurrentDocument=="function"?e.compileCurrentDocument():e!=null&&e.eventBus&&typeof e.eventBus.emit=="function"&&e.eventBus.emit("slidev:request-compile")}function D(){m.value=!1,n.freezeKeyboardNav(!1)}function ot(){D()}function rt(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function st(){const Y=a.value||d.value;Y&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):Y.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function kt(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function $t(){if(!U){ht.showMessage("请先在主编辑区打开幻灯片文档");return}const Y=Ul(U);Wl("presentation.html",Y)&&ht.showMessage("已开始下载单文件离线 HTML 演示包")}function yt(){if(!U){ht.showMessage("请先在主编辑区打开幻灯片文档");return}Vl(U)&&ht.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({updateDocument(Y,lt){S.value&&I.value&&lt&&lt!==I.value||(U=Y,S.value&&!I.value&&(I.value=Y.docId),f.value=Y.slides,p.value=Y.slides.length,s.setDocId(Y.docId),s.updateSlidesIndex(Y.slides),l.value==="pro-cli"?r.scaffolder.scaffold(Y,Os).catch(()=>{}):n.updateSlides(Y.slides,Y.config,Y.fullMarkdown))},navigateToBlock(Y){s.onCursorFocusBlock(Y)},isPinned:S,pinnedDocId:I,engineMode:l,toggleEngineMode:et}),(Y,lt)=>(Q(),nt("div",Zp,[g("div",Yp,[lt[4]||(lt[4]=g("div",{class:"spm-slidev-tab__title"},[g("svg",{class:"spm-slidev-tab__icon","aria-hidden":"true"},[g("use",{"xlink:href":"#iconSlidev"})]),g("span",null,"Slidev 演示预览")],-1)),g("div",Jp,[g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:h.value<=1,"aria-label":"上一页",onClick:it},[ft(bt,{name:"chevron-left"})],8,Xp),g("span",Qp,_t(h.value)+" / "+_t(p.value||1),1),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:h.value>=p.value,"aria-label":"下一页",onClick:V},[ft(bt,{name:"chevron-right"})],8,th),g("button",{class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":S.value}]),"aria-label":S.value?"已锁定当前文档（点击解除）："+I.value:"点击锁定当前文档（不随主编辑区切换）",onClick:j},[ft(bt,{name:"pin"}),g("span",null,_t(S.value?"已锁定":"跟随"),1)],10,eh),g("button",{class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+o.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:et},[ft(bt,{name:"step"}),g("span",null,_t(l.value==="pro-cli"?"Pro ("+o.value+")":"沙箱"),1)],10,ih),lt[3]||(lt[3]=g("span",{class:"spm-toolbar-divider"},null,-1)),g("button",{class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":w.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:lt[0]||(lt[0]=dt=>w.value=!w.value)},[ft(bt,{name:"outline"})],2),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:kt},[ft(bt,{name:"presenter"})]),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:$t},[ft(bt,{name:"export-html"})]),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:yt},[ft(bt,{name:"export-pdf"})]),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:E},[ft(bt,{name:"refresh"})]),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:st},[ft(bt,{name:"fullscreen"})])])]),g("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container"},[g("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:L.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,nh),ft(ap,{visible:m.value,"onUpdate:visible":lt[1]||(lt[1]=dt=>m.value=dt),"is-maximized":k.value,"onUpdate:isMaximized":lt[2]||(lt[2]=dt=>k.value=dt),title:C.value,onClose:D},{default:ol(()=>[v.value==="siyuan"&&b.value?(Q(),Ee(yp,{key:0,"block-id":b.value,title:C.value,plugin:Si(e),onExternalJump:ot},null,8,["block-id","title","plugin"])):Ft("",!0),A.value?Ie((Q(),Ee(Pp,{key:1,visible:m.value&&v.value==="web",url:T.value,title:C.value,onExternalJump:ot},null,8,["visible","url","title"])),[[Pl,v.value==="web"]]):Ft("",!0)]),_:1},8,["visible","is-maximized","title"])],512),w.value&&f.value.length>0?(Q(),Ee(Qf,{key:0,slides:f.value,"current-active-page":h.value,onNavigate:Z,onRefresh:E},null,8,["slides","current-active-page"])):Ft("",!0)]))}}),oh=Le(sh,[["__scopeId","data-v-3a32bc1a"]]),rh={class:"spm-section spm-section--page"},lh={class:"spm-section-header"},ah={class:"spm-card-control"},ch={class:"spm-control-header"},dh={class:"spm-control-title-group"},uh={class:"spm-control-title"},fh={class:"spm-quick-chips"},ph=["onClick"],hh=["value"],mh={key:0,class:"spm-card-control"},gh={class:"spm-control-header"},vh={class:"spm-control-title-group"},bh={class:"spm-control-title"},yh={class:"spm-quick-chips"},wh=["onClick"],kh=["value"],xh={class:"spm-card-control"},_h={class:"spm-control-header"},Sh={class:"spm-control-title-group"},Ch={class:"spm-control-title"},$h={key:0,class:"spm-note-status-box"},Ih=["title"],Ah={class:"spm-action-grid",style:{"margin-top":"6px"}},Th={key:1,class:"spm-note-empty-box"},Eh={class:"spm-card-control"},Mh={class:"spm-action-grid"},Bh=be({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageImage:{},pageNotes:{},pageIndex:{}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageImage","addNoteBlock","locateNoteBlock","generateNotes","insertDividerAfter","deleteDivider"],setup(t,{emit:i}){const e=t,n=Ct(()=>{if(!e.pageNotes)return"";const l=e.pageNotes.replace(/[\r\n]+/g," ").trim();return l.length>50?l.slice(0,50)+"...":l}),s=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],r=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(l,o)=>(Q(),nt("div",rh,[g("div",lh,[g("span",null,"幻灯片页面设置"+_t(t.pageIndex?` (第 ${t.pageIndex} 页)`:""),1)]),ft(jl,{"model-value":t.pageLayout,onChange:o[0]||(o[0]=a=>l.$emit("update:pageLayout",a))},null,8,["model-value"]),ft(So,{"model-value":t.pageTransition,onChange:o[1]||(o[1]=a=>l.$emit("update:pageTransition",a))},null,8,["model-value"]),g("div",ah,[g("div",ch,[g("div",dh,[g("div",uh,[ft(bt,{name:"palette"}),o[12]||(o[12]=g("span",null,"页面背景 (Background)",-1))]),o[13]||(o[13]=g("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),g("div",fh,[(Q(),nt(Gt,null,ye(s,a=>g("button",{key:a.value,class:Et(["spm-chip",{active:t.pageBackground===a.value}]),onClick:c=>l.$emit("update:pageBackground",a.value)},_t(a.label),11,ph)),64))]),g("input",{value:t.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:o[2]||(o[2]=a=>l.$emit("update:pageBackground",a.target.value)),onChange:o[3]||(o[3]=a=>l.$emit("update:pageBackground",a.target.value))},null,40,hh)]),t.pageLayout==="image-right"||t.pageLayout==="image-left"||t.pageImage?(Q(),nt("div",mh,[g("div",gh,[g("div",vh,[g("div",bh,[ft(bt,{name:"image"}),o[14]||(o[14]=g("span",null,"页面图片 (Image)",-1))]),o[15]||(o[15]=g("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),g("div",yh,[(Q(),nt(Gt,null,ye(r,a=>g("button",{key:a.value,class:Et(["spm-chip",{active:t.pageImage===a.value}]),onClick:c=>l.$emit("update:pageImage",a.value)},_t(a.label),11,wh)),64))]),g("input",{value:t.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:o[4]||(o[4]=a=>l.$emit("update:pageImage",a.target.value)),onChange:o[5]||(o[5]=a=>l.$emit("update:pageImage",a.target.value))},null,40,kh)])):Ft("",!0),g("div",xh,[g("div",_h,[g("div",Sh,[g("div",Ch,[ft(bt,{name:"presenter"}),o[16]||(o[16]=g("span",null,"演讲者提词 (Notes)",-1))]),o[17]||(o[17]=g("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),g("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:o[6]||(o[6]=a=>l.$emit("generateNotes"))},[ft(bt,{name:"sparkles"}),o[18]||(o[18]=g("span",null,"AI 讲稿",-1))])]),t.pageNotes?(Q(),nt("div",$h,[o[21]||(o[21]=g("div",{class:"spm-note-status-badge"},[g("span",{class:"spm-badge-dot"}),g("span",null,"已配置正文讲稿")],-1)),g("div",{class:"spm-note-preview-text",title:t.pageNotes},_t(n.value),9,Ih),g("div",Ah,[g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:o[7]||(o[7]=a=>l.$emit("locateNoteBlock"))},[ft(bt,{name:"search"}),o[19]||(o[19]=g("span",null,"定位讲稿块",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:o[8]||(o[8]=a=>l.$emit("addNoteBlock"))},[ft(bt,{name:"insert-below"}),o[20]||(o[20]=g("span",null,"追加讲稿块",-1))])])])):(Q(),nt("div",Th,[o[23]||(o[23]=g("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:o[9]||(o[9]=a=>l.$emit("addNoteBlock"))},[ft(bt,{name:"insert-below"}),o[22]||(o[22]=g("span",null,"添加讲稿备注块",-1))])]))]),g("div",Eh,[o[26]||(o[26]=g("div",{class:"spm-control-header"},[g("div",{class:"spm-control-title-group"},[g("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),g("div",Mh,[g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:o[10]||(o[10]=a=>l.$emit("insertDividerAfter"))},[ft(bt,{name:"insert-below"}),o[24]||(o[24]=g("span",null,"插入新页",-1))]),g("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:o[11]||(o[11]=a=>l.$emit("deleteDivider"))},[ft(bt,{name:"trash"}),o[25]||(o[25]=g("span",null,"删除此页",-1))])])])]))}}),Dh=Le(Bh,[["__scopeId","data-v-4916b87e"]]),Oh={class:"spm-section spm-section--block"},Ph={class:"spm-card-control"},Lh={class:"spm-control-header"},Rh={class:"spm-control-title-group"},zh={class:"spm-control-title"},Nh=["aria-label"],Fh=["checked"],jh={key:0,class:"spm-card-control"},Hh={class:"spm-control-header"},Uh={class:"spm-control-title-group"},Wh={class:"spm-control-title"},Vh={class:"spm-quick-chips"},Kh={key:1,class:"spm-card-control"},qh={class:"spm-control-header"},Gh={class:"spm-control-title-group"},Zh={class:"spm-control-title"},Yh={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},Jh={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Xh=["aria-label"],Qh=["checked"],tm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},em=["aria-label"],im=["checked"],nm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},sm=["aria-label"],om=["checked"],rm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},lm=["aria-label"],am=["checked"],cm={class:"spm-card-control"},dm={class:"spm-control-header"},um={class:"spm-control-title-group"},fm={class:"spm-control-title"},pm=["aria-label"],hm=["checked"],mm={key:0,class:"spm-quick-chips"},gm=["onClick"],vm={class:"spm-card-control"},bm={class:"spm-control-header"},ym={class:"spm-control-title-group"},wm={class:"spm-control-title"},km=["aria-label"],xm=["checked"],_m={key:0,class:"spm-quick-chips"},Sm=["onClick"],Cm={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},$m={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},Im={style:{display:"flex",gap:"6px"}},Am=["value"],Tm=["value"],Em={key:2,class:"spm-card-control"},Mm={class:"spm-control-header"},Bm={class:"spm-control-title-group"},Dm={class:"spm-control-title"},Om={class:"spm-control-desc"},Pm={class:"spm-segmented-group"},Lm=["onClick"],Rm={key:3,class:"spm-card-control"},zm={class:"spm-control-header"},Nm={class:"spm-control-title-group"},Fm={class:"spm-control-title"},jm={class:"spm-quick-chips"},Hm=["onClick"],Um=["value"],Wm={key:4,class:"spm-card-control"},Vm={class:"spm-control-header"},Km={class:"spm-control-title-group"},qm={class:"spm-control-title"},Gm={class:"spm-quick-chips"},Zm=["onClick"],Ym=["value"],Jm={class:"spm-card-control"},Xm={class:"spm-action-grid"},Qm=["aria-label"],tg=be({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(t,{emit:i}){const e=t,n=Ct(()=>{const A=e.currentSlideLayout||"";return["col-1","col-2","col-3"].includes(e.elemSlot)?"three-cols-header":A}),s=Ct(()=>{const A=n.value;return["two-cols","two-cols-header","three-cols-header"].includes(A)}),r=Ct(()=>{const A=n.value;return A==="three-cols-header"?"三栏插槽归属 (Slot)":A==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),l=Ct(()=>{const A=n.value;return A==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":A==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":A==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),o=Ct(()=>{const A=n.value;return A==="three-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}]:A==="two-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]:A==="two-cols"?[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}]:[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]});function a(A){const S=e.elemSlot||"";return A?S===A||A==="col-1"&&S==="left"||A==="col-2"&&S==="center"||A==="col-3"&&S==="right"||A==="left"&&S==="col-1"||A==="right"&&(S==="col-2"||S==="col-3"):!S||S==="default"}const c=i,d=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],h=Ct(()=>{if(!e.elemMotion||e.elemMotion.trim()===""||e.elemMotion.trim()==="none")return null;try{const A=JSON.parse(e.elemMotion);if(typeof A=="object"&&A!==null)return{preset:A.preset||A.type||"slide-up",duration:typeof A.duration=="number"?A.duration:0,delay:typeof A.delay=="number"?A.delay:0}}catch{}return{preset:e.elemMotion.trim(),duration:0,delay:0}}),p=Ct(()=>!!h.value),f=Ct(()=>{var A;return((A=h.value)==null?void 0:A.preset)||"slide-up"}),w=Ct(()=>{var A;return((A=h.value)==null?void 0:A.duration)||0}),m=Ct(()=>{var A;return((A=h.value)==null?void 0:A.delay)||0});function k(){p.value?c("update:elemMotion",""):c("update:elemMotion","slide-up")}function v(A){C(A,w.value,m.value)}function b(A){C(f.value,A,m.value)}function T(A){C(f.value,w.value,A)}function C(A,S,I){if(!A||A==="none"){c("update:elemMotion","");return}if(!S&&!I){c("update:elemMotion",A);return}const L={preset:A};S>0&&(L.duration=S),I>0&&(L.delay=I),c("update:elemMotion",JSON.stringify(L))}return(A,S)=>(Q(),nt("div",Oh,[S[53]||(S[53]=g("div",{class:"spm-section-header"},[g("span",null,"元素动效与排版")],-1)),g("div",Ph,[g("div",Lh,[g("div",Rh,[g("div",zh,[ft(bt,{name:"presenter"}),S[22]||(S[22]=g("span",null,"设为讲稿备注 (slidev-note)",-1))]),S[23]||(S[23]=g("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.isNote?"取消讲稿备注":"设为讲稿备注"},[g("input",{type:"checkbox",checked:!!t.isNote,onChange:S[0]||(S[0]=I=>A.$emit("toggleNote"))},null,40,Fh),S[24]||(S[24]=g("span",{class:"spm-switch-slider"},null,-1))],8,Nh)])]),t.isImage||t.imageRole?(Q(),nt("div",jh,[g("div",Hh,[g("div",Uh,[g("div",Wh,[ft(bt,{name:"image"}),S[25]||(S[25]=g("span",null,"图片角色与分栏 (Image & Layout)",-1))]),S[26]||(S[26]=g("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),g("div",Vh,[g("button",{class:Et(["spm-chip",{active:!t.imageRole}]),onClick:S[1]||(S[1]=I=>A.$emit("update:imageRole",""))}," 普通内容 ",2),g("button",{class:Et(["spm-chip",{active:t.imageRole==="background"}]),onClick:S[2]||(S[2]=I=>A.$emit("update:imageRole","background"))}," 🖼️ 背景图 ",2),g("button",{class:Et(["spm-chip",{active:t.imageRole==="image-left"}]),onClick:S[3]||(S[3]=I=>A.$emit("update:imageRole","image-left"))}," 🎨 图左 ",2),g("button",{class:Et(["spm-chip",{active:t.imageRole==="image-right"}]),onClick:S[4]||(S[4]=I=>A.$emit("update:imageRole","image-right"))}," 🖼️ 图右 ",2)])])):Ft("",!0),t.isVideo?(Q(),nt("div",Kh,[g("div",qh,[g("div",Gh,[g("div",Zh,[ft(bt,{name:"video"}),S[27]||(S[27]=g("span",null,"视频播放设置 (Video Playback)",-1))]),S[28]||(S[28]=g("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),g("div",Yh,[g("div",Jh,[S[30]||(S[30]=g("span",{style:{"font-size":"11px"}},"🎛️ 控制条",-1)),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoControls?"关闭控制条":"开启控制条"},[g("input",{type:"checkbox",checked:!!t.videoControls,onChange:S[5]||(S[5]=I=>A.$emit("toggleVideoControls"))},null,40,Qh),S[29]||(S[29]=g("span",{class:"spm-switch-slider"},null,-1))],8,Xh)]),g("div",tm,[S[32]||(S[32]=g("span",{style:{"font-size":"11px"}},"▶️ 自动播放",-1)),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoAutoplay?"关闭自动播放":"开启自动播放"},[g("input",{type:"checkbox",checked:!!t.videoAutoplay,onChange:S[6]||(S[6]=I=>A.$emit("toggleVideoAutoplay"))},null,40,im),S[31]||(S[31]=g("span",{class:"spm-switch-slider"},null,-1))],8,em)]),g("div",nm,[S[34]||(S[34]=g("span",{style:{"font-size":"11px"}},"🔁 循环播放",-1)),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoLoop?"关闭循环播放":"开启循环播放"},[g("input",{type:"checkbox",checked:!!t.videoLoop,onChange:S[7]||(S[7]=I=>A.$emit("toggleVideoLoop"))},null,40,om),S[33]||(S[33]=g("span",{class:"spm-switch-slider"},null,-1))],8,sm)]),g("div",rm,[S[36]||(S[36]=g("span",{style:{"font-size":"11px"}},"🔇 静音播放",-1)),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoMuted?"关闭静音":"开启静音"},[g("input",{type:"checkbox",checked:!!t.videoMuted,onChange:S[8]||(S[8]=I=>A.$emit("toggleVideoMuted"))},null,40,am),S[35]||(S[35]=g("span",{class:"spm-switch-slider"},null,-1))],8,lm)])])])):Ft("",!0),g("div",cm,[g("div",dm,[g("div",um,[g("div",fm,[ft(bt,{name:"step"}),S[37]||(S[37]=g("span",null,"逐步呈现 (v-click)",-1))]),S[38]||(S[38]=g("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[g("input",{type:"checkbox",checked:!!t.elemClick,onChange:S[9]||(S[9]=I=>A.$emit("toggleElemClick"))},null,40,hm),S[39]||(S[39]=g("span",{class:"spm-switch-slider"},null,-1))],8,pm)]),t.elemClick?(Q(),nt("div",mm,[(Q(),nt(Gt,null,ye(["+1","1","2","hide"],I=>g("button",{key:I,class:Et(["spm-chip",{active:t.elemClick===I}]),onClick:L=>A.$emit("update:elemClick",I)},_t(I==="+1"?"顺延 (+1)":I==="hide"?"隐藏 (hide)":"第 "+I+" 步"),11,gm)),64))])):Ft("",!0)]),g("div",vm,[g("div",bm,[g("div",ym,[g("div",wm,[ft(bt,{name:"motion"}),S[40]||(S[40]=g("span",null,"入场微动效 (v-motion)",-1))]),S[41]||(S[41]=g("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":p.value?"关闭微动效":"开启微动效 (slide-up)"},[g("input",{type:"checkbox",checked:p.value,onChange:k},null,40,xm),S[42]||(S[42]=g("span",{class:"spm-switch-slider"},null,-1))],8,km)]),p.value?(Q(),nt("div",_m,[(Q(),nt(Gt,null,ye(d,I=>g("button",{key:I.value,class:Et(["spm-chip",{active:f.value===I.value}]),onClick:L=>v(I.value)},_t(I.label),11,Sm)),64))])):Ft("",!0),p.value?(Q(),nt("div",Cm,[g("div",$m,[g("span",null,"时长: "+_t(w.value?w.value+"ms":"默认 (450ms)"),1),g("span",null,"延迟: "+_t(m.value?m.value+"ms":"0ms"),1)]),g("div",Im,[g("select",{class:"spm-select",style:{flex:"1"},value:w.value,onChange:S[10]||(S[10]=I=>b(Number(I.target.value)))},[...S[43]||(S[43]=[g("option",{value:0},"默认耗时",-1),g("option",{value:200},"极速 (200ms)",-1),g("option",{value:350},"较快 (350ms)",-1),g("option",{value:500},"平滑 (500ms)",-1),g("option",{value:800},"缓慢 (800ms)",-1)])],40,Am),g("select",{class:"spm-select",style:{flex:"1"},value:m.value,onChange:S[11]||(S[11]=I=>T(Number(I.target.value)))},[...S[44]||(S[44]=[g("option",{value:0},"无延迟",-1),g("option",{value:150},"延迟 150ms",-1),g("option",{value:300},"延迟 300ms",-1),g("option",{value:500},"延迟 500ms",-1)])],40,Tm)])])):Ft("",!0)]),s.value||t.elemSlot?(Q(),nt("div",Em,[g("div",Mm,[g("div",Bm,[g("div",Dm,[ft(bt,{name:"columns"}),g("span",null,_t(r.value),1)]),g("span",Om,_t(l.value),1)])]),g("div",Pm,[(Q(!0),nt(Gt,null,ye(o.value,I=>(Q(),nt("button",{key:I.value,class:Et(["spm-segmented-item",{active:a(I.value)}]),onClick:L=>A.$emit("update:elemSlot",I.value)},_t(I.label),11,Lm))),128))])])):Ft("",!0),t.isCodeBlock?(Q(),nt("div",Rm,[g("div",zm,[g("div",Nm,[g("div",Fm,[ft(bt,{name:"code"}),S[45]||(S[45]=g("span",null,"代码逐行聚光 (Shiki)",-1))]),S[46]||(S[46]=g("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),g("div",jm,[(Q(),nt(Gt,null,ye(["1-3","all","1|2|3","2-5"],I=>g("button",{key:I,class:Et(["spm-chip",{active:t.elemShikiLines===I}]),onClick:L=>A.$emit("update:elemShikiLines",I)},_t(I),11,Hm)),64)),t.elemShikiLines?(Q(),nt("button",{key:0,class:"spm-chip spm-chip-clear",onClick:S[12]||(S[12]=I=>A.$emit("update:elemShikiLines",""))}," 清空 ")):Ft("",!0)]),g("input",{value:t.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:S[13]||(S[13]=I=>A.$emit("update:elemShikiLines",I.target.value)),onChange:S[14]||(S[14]=I=>A.$emit("update:elemShikiLines",I.target.value))},null,40,Um)])):Ft("",!0),t.isCodeBlock?(Q(),nt("div",Wm,[g("div",Vm,[g("div",Km,[g("div",qm,[ft(bt,{name:"code"}),S[47]||(S[47]=g("span",null,"代码块限高 (Max Height)",-1))]),S[48]||(S[48]=g("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),g("div",Gm,[(Q(),nt(Gt,null,ye(["240px","320px","400px","50vh"],I=>g("button",{key:I,class:Et(["spm-chip",{active:t.elemMaxHeight===I}]),onClick:L=>A.$emit("update:elemMaxHeight",I)},_t(I),11,Zm)),64)),t.elemMaxHeight?(Q(),nt("button",{key:0,class:"spm-chip spm-chip-clear",onClick:S[15]||(S[15]=I=>A.$emit("update:elemMaxHeight",""))}," 自适应 ")):Ft("",!0)]),g("input",{value:t.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:S[16]||(S[16]=I=>A.$emit("update:elemMaxHeight",I.target.value)),onChange:S[17]||(S[17]=I=>A.$emit("update:elemMaxHeight",I.target.value))},null,40,Ym)])):Ft("",!0),g("div",Jm,[S[52]||(S[52]=g("div",{class:"spm-control-header"},[g("div",{class:"spm-control-title-group"},[g("span",{class:"spm-control-title"},"快捷操作")])],-1)),g("div",Xm,[g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:S[18]||(S[18]=I=>A.$emit("insertDividerBefore"))},[ft(bt,{name:"insert-above"}),S[49]||(S[49]=g("span",null,"上方分页",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:S[19]||(S[19]=I=>A.$emit("insertDividerAfter"))},[ft(bt,{name:"insert-below"}),S[50]||(S[50]=g("span",null,"下方分页",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:S[20]||(S[20]=I=>A.$emit("setTwoColsContrast"))},[ft(bt,{name:"columns"}),g("span",null,_t(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,Qm),t.hasBlockAttrs?(Q(),nt("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:S[21]||(S[21]=I=>A.$emit("clearBlockAttrs"))},[ft(bt,{name:"broom"}),S[51]||(S[51]=g("span",null,"清除属性",-1))])):Ft("",!0)])])]))}}),eg={class:"spm-section spm-section--doc"},ig={class:"spm-card-control"},ng={class:"spm-control-header"},sg={class:"spm-control-title-group"},og={class:"spm-control-title"},rg={class:"spm-segmented-group"},lg=["aria-label","onClick"],ag={class:"spm-card-control"},cg={class:"spm-control-header"},dg={class:"spm-control-title-group"},ug={class:"spm-control-title"},fg={class:"spm-segmented-group"},pg={class:"spm-card-control"},hg={class:"spm-control-header"},mg={class:"spm-control-title-group"},gg={class:"spm-control-title"},vg={class:"spm-card-control"},bg={class:"spm-control-header"},yg={class:"spm-control-title-group"},wg={class:"spm-control-title"},kg=["aria-label"],xg=["checked"],_g={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},Sg=["value"],Cg={class:"spm-card-control"},$g={class:"spm-action-grid"},Ig=be({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(t){const i=Qe("plugin"),e=Ci,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function s(o){Ui({enableWebServeJump:o}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({enableWebServeJump:o})}function r(o){Ui({webServeUrl:o})}function l(o){Ui({webServeUrl:o}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({webServeUrl:o})}return(o,a)=>(Q(),nt("div",eg,[a[30]||(a[30]=g("div",{class:"spm-section-header"},[g("span",null,"全局演示配置")],-1)),g("div",ig,[g("div",ng,[g("div",sg,[g("div",og,[ft(bt,{name:"palette"}),a[14]||(a[14]=g("span",null,"幻灯片主题 (Theme)",-1))]),a[15]||(a[15]=g("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),g("div",rg,[(Q(),nt(Gt,null,ye(n,c=>g("button",{key:c.value,class:Et(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:t.docTheme===c.value}]),"aria-label":c.desc,onClick:d=>o.$emit("update:docTheme",c.value)},_t(c.label),11,lg)),64))])]),g("div",ag,[g("div",cg,[g("div",dg,[g("div",ug,[ft(bt,{name:"ratio"}),a[16]||(a[16]=g("span",null,"画幅比例 (Aspect Ratio)",-1))]),a[17]||(a[17]=g("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),g("div",fg,[g("button",{class:Et(["spm-segmented-item",{active:t.docAspectRatio==="16/9"}]),onClick:a[0]||(a[0]=c=>o.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),g("button",{class:Et(["spm-segmented-item",{active:t.docAspectRatio==="4/3"}]),onClick:a[1]||(a[1]=c=>o.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),g("button",{class:Et(["spm-segmented-item",{active:t.docAspectRatio==="16/10"}]),onClick:a[2]||(a[2]=c=>o.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),g("div",pg,[g("div",hg,[g("div",mg,[g("div",gg,[ft(bt,{name:"transition"}),a[18]||(a[18]=g("span",null,"全局默认转场",-1))]),a[19]||(a[19]=g("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),ft(So,{"model-value":t.docDefaultTransition,"hide-header":!0,onChange:a[3]||(a[3]=c=>o.$emit("update:docDefaultTransition",c))},null,8,["model-value"])]),g("div",vg,[g("div",bg,[g("div",yg,[g("div",wg,[ft(bt,{name:"external-link"}),a[20]||(a[20]=g("span",null,"本地网络伺服预览 (Web Serve)",-1))]),a[21]||(a[21]=g("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":Si(e).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[g("input",{type:"checkbox",checked:Si(e).enableWebServeJump,onChange:a[4]||(a[4]=c=>s(c.target.checked))},null,40,xg),a[22]||(a[22]=g("span",{class:"spm-switch-slider"},null,-1))],8,kg)]),Si(e).enableWebServeJump?(Q(),nt("div",_g,[g("input",{value:Si(e).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:a[5]||(a[5]=Te(()=>{},["stop"])),onKeyup:a[6]||(a[6]=Te(()=>{},["stop"])),onInput:a[7]||(a[7]=c=>r(c.target.value)),onChange:a[8]||(a[8]=c=>l(c.target.value))},null,40,Sg),a[23]||(a[23]=g("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Ft("",!0)]),g("div",Cg,[a[29]||(a[29]=g("div",{class:"spm-control-header"},[g("div",{class:"spm-control-title-group"},[g("span",{class:"spm-control-title"},"演示全局操作")])],-1)),g("div",$g,[g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:a[9]||(a[9]=c=>o.$emit("openBottomPreview"))},[ft(bt,{name:"split-preview"}),a[24]||(a[24]=g("span",null,"分屏预览",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:a[10]||(a[10]=c=>o.$emit("openPresenter"))},[ft(bt,{name:"presenter"}),a[25]||(a[25]=g("span",null,"演讲者视图",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:a[11]||(a[11]=c=>o.$emit("aiAutoSplit"))},[ft(bt,{name:"sparkles"}),a[26]||(a[26]=g("span",null,"AI 智能分页",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:a[12]||(a[12]=c=>o.$emit("exportHtml"))},[ft(bt,{name:"export-html"}),a[27]||(a[27]=g("span",null,"导出 HTML",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:a[13]||(a[13]=c=>o.$emit("exportPdf"))},[ft(bt,{name:"export-pdf"}),a[28]||(a[28]=g("span",null,"导出 PDF",-1))])])])]))}});var Rn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function Ag(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}function zn(t){throw new Error('Could not dynamically require "'+t+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Ms={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var gr;function Tg(){return gr||(gr=1,(function(t,i){(function(e){t.exports=e()})(function(){return(function e(n,s,r){function l(c,d){if(!s[c]){if(!n[c]){var h=typeof zn=="function"&&zn;if(!d&&h)return h(c,!0);if(o)return o(c,!0);var p=new Error("Cannot find module '"+c+"'");throw p.code="MODULE_NOT_FOUND",p}var f=s[c]={exports:{}};n[c][0].call(f.exports,function(w){var m=n[c][1][w];return l(m||w)},f,f.exports,e,n,s,r)}return s[c].exports}for(var o=typeof zn=="function"&&zn,a=0;a<r.length;a++)l(r[a]);return l})({1:[function(e,n,s){var r=e("./utils"),l=e("./support"),o="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";s.encode=function(a){for(var c,d,h,p,f,w,m,k=[],v=0,b=a.length,T=b,C=r.getTypeOf(a)!=="string";v<a.length;)T=b-v,h=C?(c=a[v++],d=v<b?a[v++]:0,v<b?a[v++]:0):(c=a.charCodeAt(v++),d=v<b?a.charCodeAt(v++):0,v<b?a.charCodeAt(v++):0),p=c>>2,f=(3&c)<<4|d>>4,w=1<T?(15&d)<<2|h>>6:64,m=2<T?63&h:64,k.push(o.charAt(p)+o.charAt(f)+o.charAt(w)+o.charAt(m));return k.join("")},s.decode=function(a){var c,d,h,p,f,w,m=0,k=0,v="data:";if(a.substr(0,v.length)===v)throw new Error("Invalid base64 input, it looks like a data url.");var b,T=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===o.charAt(64)&&T--,a.charAt(a.length-2)===o.charAt(64)&&T--,T%1!=0)throw new Error("Invalid base64 input, bad content length.");for(b=l.uint8array?new Uint8Array(0|T):new Array(0|T);m<a.length;)c=o.indexOf(a.charAt(m++))<<2|(p=o.indexOf(a.charAt(m++)))>>4,d=(15&p)<<4|(f=o.indexOf(a.charAt(m++)))>>2,h=(3&f)<<6|(w=o.indexOf(a.charAt(m++))),b[k++]=c,f!==64&&(b[k++]=d),w!==64&&(b[k++]=h);return b}},{"./support":30,"./utils":32}],2:[function(e,n,s){var r=e("./external"),l=e("./stream/DataWorker"),o=e("./stream/Crc32Probe"),a=e("./stream/DataLengthProbe");function c(d,h,p,f,w){this.compressedSize=d,this.uncompressedSize=h,this.crc32=p,this.compression=f,this.compressedContent=w}c.prototype={getContentWorker:function(){var d=new l(r.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),h=this;return d.on("end",function(){if(this.streamInfo.data_length!==h.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(r.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,h,p){return d.pipe(new o).pipe(new a("uncompressedSize")).pipe(h.compressWorker(p)).pipe(new a("compressedSize")).withStreamInfo("compression",h)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(e,n,s){var r=e("./stream/GenericWorker");s.STORE={magic:"\0\0",compressWorker:function(){return new r("STORE compression")},uncompressWorker:function(){return new r("STORE decompression")}},s.DEFLATE=e("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(e,n,s){var r=e("./utils"),l=(function(){for(var o,a=[],c=0;c<256;c++){o=c;for(var d=0;d<8;d++)o=1&o?3988292384^o>>>1:o>>>1;a[c]=o}return a})();n.exports=function(o,a){return o!==void 0&&o.length?r.getTypeOf(o)!=="string"?(function(c,d,h,p){var f=l,w=p+h;c^=-1;for(var m=p;m<w;m++)c=c>>>8^f[255&(c^d[m])];return-1^c})(0|a,o,o.length,0):(function(c,d,h,p){var f=l,w=p+h;c^=-1;for(var m=p;m<w;m++)c=c>>>8^f[255&(c^d.charCodeAt(m))];return-1^c})(0|a,o,o.length,0):0}},{"./utils":32}],5:[function(e,n,s){s.base64=!1,s.binary=!1,s.dir=!1,s.createFolders=!0,s.date=null,s.compression=null,s.compressionOptions=null,s.comment=null,s.unixPermissions=null,s.dosPermissions=null},{}],6:[function(e,n,s){var r=null;r=typeof Promise<"u"?Promise:e("lie"),n.exports={Promise:r}},{lie:37}],7:[function(e,n,s){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=e("pako"),o=e("./utils"),a=e("./stream/GenericWorker"),c=r?"uint8array":"array";function d(h,p){a.call(this,"FlateWorker/"+h),this._pako=null,this._pakoAction=h,this._pakoOptions=p,this.meta={}}s.magic="\b\0",o.inherits(d,a),d.prototype.processChunk=function(h){this.meta=h.meta,this._pako===null&&this._createPako(),this._pako.push(o.transformTo(c,h.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var h=this;this._pako.onData=function(p){h.push({data:p,meta:h.meta})}},s.compressWorker=function(h){return new d("Deflate",h)},s.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(e,n,s){function r(f,w){var m,k="";for(m=0;m<w;m++)k+=String.fromCharCode(255&f),f>>>=8;return k}function l(f,w,m,k,v,b){var T,C,A=f.file,S=f.compression,I=b!==c.utf8encode,L=o.transformTo("string",b(A.name)),R=o.transformTo("string",c.utf8encode(A.name)),N=A.comment,J=o.transformTo("string",b(N)),x=o.transformTo("string",c.utf8encode(N)),q=R.length!==A.name.length,y=x.length!==N.length,U="",et="",j="",it=A.dir,V=A.date,Z={crc32:0,compressedSize:0,uncompressedSize:0};w&&!m||(Z.crc32=f.crc32,Z.compressedSize=f.compressedSize,Z.uncompressedSize=f.uncompressedSize);var E=0;w&&(E|=8),I||!q&&!y||(E|=2048);var D=0,ot=0;it&&(D|=16),v==="UNIX"?(ot=798,D|=(function(st,kt){var $t=st;return st||($t=kt?16893:33204),(65535&$t)<<16})(A.unixPermissions,it)):(ot=20,D|=(function(st){return 63&(st||0)})(A.dosPermissions)),T=V.getUTCHours(),T<<=6,T|=V.getUTCMinutes(),T<<=5,T|=V.getUTCSeconds()/2,C=V.getUTCFullYear()-1980,C<<=4,C|=V.getUTCMonth()+1,C<<=5,C|=V.getUTCDate(),q&&(et=r(1,1)+r(d(L),4)+R,U+="up"+r(et.length,2)+et),y&&(j=r(1,1)+r(d(J),4)+x,U+="uc"+r(j.length,2)+j);var rt="";return rt+=`
\0`,rt+=r(E,2),rt+=S.magic,rt+=r(T,2),rt+=r(C,2),rt+=r(Z.crc32,4),rt+=r(Z.compressedSize,4),rt+=r(Z.uncompressedSize,4),rt+=r(L.length,2),rt+=r(U.length,2),{fileRecord:h.LOCAL_FILE_HEADER+rt+L+U,dirRecord:h.CENTRAL_FILE_HEADER+r(ot,2)+rt+r(J.length,2)+"\0\0\0\0"+r(D,4)+r(k,4)+L+U+J}}var o=e("../utils"),a=e("../stream/GenericWorker"),c=e("../utf8"),d=e("../crc32"),h=e("../signature");function p(f,w,m,k){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=w,this.zipPlatform=m,this.encodeFileName=k,this.streamFiles=f,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}o.inherits(p,a),p.prototype.push=function(f){var w=f.meta.percent||0,m=this.entriesCount,k=this._sources.length;this.accumulate?this.contentBuffer.push(f):(this.bytesWritten+=f.data.length,a.prototype.push.call(this,{data:f.data,meta:{currentFile:this.currentFile,percent:m?(w+100*(m-k-1))/m:100}}))},p.prototype.openedSource=function(f){this.currentSourceOffset=this.bytesWritten,this.currentFile=f.file.name;var w=this.streamFiles&&!f.file.dir;if(w){var m=l(f,w,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:m.fileRecord,meta:{percent:0}})}else this.accumulate=!0},p.prototype.closedSource=function(f){this.accumulate=!1;var w=this.streamFiles&&!f.file.dir,m=l(f,w,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(m.dirRecord),w)this.push({data:(function(k){return h.DATA_DESCRIPTOR+r(k.crc32,4)+r(k.compressedSize,4)+r(k.uncompressedSize,4)})(f),meta:{percent:100}});else for(this.push({data:m.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},p.prototype.flush=function(){for(var f=this.bytesWritten,w=0;w<this.dirRecords.length;w++)this.push({data:this.dirRecords[w],meta:{percent:100}});var m=this.bytesWritten-f,k=(function(v,b,T,C,A){var S=o.transformTo("string",A(C));return h.CENTRAL_DIRECTORY_END+"\0\0\0\0"+r(v,2)+r(v,2)+r(b,4)+r(T,4)+r(S.length,2)+S})(this.dirRecords.length,m,f,this.zipComment,this.encodeFileName);this.push({data:k,meta:{percent:100}})},p.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},p.prototype.registerPrevious=function(f){this._sources.push(f);var w=this;return f.on("data",function(m){w.processChunk(m)}),f.on("end",function(){w.closedSource(w.previous.streamInfo),w._sources.length?w.prepareNextSource():w.end()}),f.on("error",function(m){w.error(m)}),this},p.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},p.prototype.error=function(f){var w=this._sources;if(!a.prototype.error.call(this,f))return!1;for(var m=0;m<w.length;m++)try{w[m].error(f)}catch{}return!0},p.prototype.lock=function(){a.prototype.lock.call(this);for(var f=this._sources,w=0;w<f.length;w++)f[w].lock()},n.exports=p},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(e,n,s){var r=e("../compressions"),l=e("./ZipFileWorker");s.generateWorker=function(o,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),h=0;try{o.forEach(function(p,f){h++;var w=(function(b,T){var C=b||T,A=r[C];if(!A)throw new Error(C+" is not a valid compression method !");return A})(f.options.compression,a.compression),m=f.options.compressionOptions||a.compressionOptions||{},k=f.dir,v=f.date;f._compressWorker(w,m).withStreamInfo("file",{name:p,dir:k,date:v,comment:f.comment||"",unixPermissions:f.unixPermissions,dosPermissions:f.dosPermissions}).pipe(d)}),d.entriesCount=h}catch(p){d.error(p)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(e,n,s){function r(){if(!(this instanceof r))return new r;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new r;for(var o in this)typeof this[o]!="function"&&(l[o]=this[o]);return l}}(r.prototype=e("./object")).loadAsync=e("./load"),r.support=e("./support"),r.defaults=e("./defaults"),r.version="3.10.1",r.loadAsync=function(l,o){return new r().loadAsync(l,o)},r.external=e("./external"),n.exports=r},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(e,n,s){var r=e("./utils"),l=e("./external"),o=e("./utf8"),a=e("./zipEntries"),c=e("./stream/Crc32Probe"),d=e("./nodejsUtils");function h(p){return new l.Promise(function(f,w){var m=p.decompressed.getContentWorker().pipe(new c);m.on("error",function(k){w(k)}).on("end",function(){m.streamInfo.crc32!==p.decompressed.crc32?w(new Error("Corrupted zip : CRC32 mismatch")):f()}).resume()})}n.exports=function(p,f){var w=this;return f=r.extend(f||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:o.utf8decode}),d.isNode&&d.isStream(p)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):r.prepareContent("the loaded zip file",p,!0,f.optimizedBinaryString,f.base64).then(function(m){var k=new a(f);return k.load(m),k}).then(function(m){var k=[l.Promise.resolve(m)],v=m.files;if(f.checkCRC32)for(var b=0;b<v.length;b++)k.push(h(v[b]));return l.Promise.all(k)}).then(function(m){for(var k=m.shift(),v=k.files,b=0;b<v.length;b++){var T=v[b],C=T.fileNameStr,A=r.resolve(T.fileNameStr);w.file(A,T.decompressed,{binary:!0,optimizedBinaryString:!0,date:T.date,dir:T.dir,comment:T.fileCommentStr.length?T.fileCommentStr:null,unixPermissions:T.unixPermissions,dosPermissions:T.dosPermissions,createFolders:f.createFolders}),T.dir||(w.file(A).unsafeOriginalName=C)}return k.zipComment.length&&(w.comment=k.zipComment),w})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(e,n,s){var r=e("../utils"),l=e("../stream/GenericWorker");function o(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}r.inherits(o,l),o.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},o.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},o.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=o},{"../stream/GenericWorker":28,"../utils":32}],13:[function(e,n,s){var r=e("readable-stream").Readable;function l(o,a,c){r.call(this,a),this._helper=o;var d=this;o.on("data",function(h,p){d.push(h)||d._helper.pause(),c&&c(p)}).on("error",function(h){d.emit("error",h)}).on("end",function(){d.push(null)})}e("../utils").inherits(l,r),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(e,n,s){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(r,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(r,l);if(typeof r=="number")throw new Error('The "data" argument must not be a number');return new Buffer(r,l)},allocBuffer:function(r){if(Buffer.alloc)return Buffer.alloc(r);var l=new Buffer(r);return l.fill(0),l},isBuffer:function(r){return Buffer.isBuffer(r)},isStream:function(r){return r&&typeof r.on=="function"&&typeof r.pause=="function"&&typeof r.resume=="function"}}},{}],15:[function(e,n,s){function r(A,S,I){var L,R=o.getTypeOf(S),N=o.extend(I||{},d);N.date=N.date||new Date,N.compression!==null&&(N.compression=N.compression.toUpperCase()),typeof N.unixPermissions=="string"&&(N.unixPermissions=parseInt(N.unixPermissions,8)),N.unixPermissions&&16384&N.unixPermissions&&(N.dir=!0),N.dosPermissions&&16&N.dosPermissions&&(N.dir=!0),N.dir&&(A=v(A)),N.createFolders&&(L=k(A))&&b.call(this,L,!0);var J=R==="string"&&N.binary===!1&&N.base64===!1;I&&I.binary!==void 0||(N.binary=!J),(S instanceof h&&S.uncompressedSize===0||N.dir||!S||S.length===0)&&(N.base64=!1,N.binary=!0,S="",N.compression="STORE",R="string");var x=null;x=S instanceof h||S instanceof a?S:w.isNode&&w.isStream(S)?new m(A,S):o.prepareContent(A,S,N.binary,N.optimizedBinaryString,N.base64);var q=new p(A,x,N);this.files[A]=q}var l=e("./utf8"),o=e("./utils"),a=e("./stream/GenericWorker"),c=e("./stream/StreamHelper"),d=e("./defaults"),h=e("./compressedObject"),p=e("./zipObject"),f=e("./generate"),w=e("./nodejsUtils"),m=e("./nodejs/NodejsStreamInputAdapter"),k=function(A){A.slice(-1)==="/"&&(A=A.substring(0,A.length-1));var S=A.lastIndexOf("/");return 0<S?A.substring(0,S):""},v=function(A){return A.slice(-1)!=="/"&&(A+="/"),A},b=function(A,S){return S=S!==void 0?S:d.createFolders,A=v(A),this.files[A]||r.call(this,A,null,{dir:!0,createFolders:S}),this.files[A]};function T(A){return Object.prototype.toString.call(A)==="[object RegExp]"}var C={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(A){var S,I,L;for(S in this.files)L=this.files[S],(I=S.slice(this.root.length,S.length))&&S.slice(0,this.root.length)===this.root&&A(I,L)},filter:function(A){var S=[];return this.forEach(function(I,L){A(I,L)&&S.push(L)}),S},file:function(A,S,I){if(arguments.length!==1)return A=this.root+A,r.call(this,A,S,I),this;if(T(A)){var L=A;return this.filter(function(N,J){return!J.dir&&L.test(N)})}var R=this.files[this.root+A];return R&&!R.dir?R:null},folder:function(A){if(!A)return this;if(T(A))return this.filter(function(R,N){return N.dir&&A.test(R)});var S=this.root+A,I=b.call(this,S),L=this.clone();return L.root=I.name,L},remove:function(A){A=this.root+A;var S=this.files[A];if(S||(A.slice(-1)!=="/"&&(A+="/"),S=this.files[A]),S&&!S.dir)delete this.files[A];else for(var I=this.filter(function(R,N){return N.name.slice(0,A.length)===A}),L=0;L<I.length;L++)delete this.files[I[L].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(A){var S,I={};try{if((I=o.extend(A||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=I.type.toLowerCase(),I.compression=I.compression.toUpperCase(),I.type==="binarystring"&&(I.type="string"),!I.type)throw new Error("No output type specified.");o.checkSupport(I.type),I.platform!=="darwin"&&I.platform!=="freebsd"&&I.platform!=="linux"&&I.platform!=="sunos"||(I.platform="UNIX"),I.platform==="win32"&&(I.platform="DOS");var L=I.comment||this.comment||"";S=f.generateWorker(this,I,L)}catch(R){(S=new a("error")).error(R)}return new c(S,I.type||"string",I.mimeType)},generateAsync:function(A,S){return this.generateInternalStream(A).accumulate(S)},generateNodeStream:function(A,S){return(A=A||{}).type||(A.type="nodebuffer"),this.generateInternalStream(A).toNodejsStream(S)}};n.exports=C},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(e,n,s){n.exports=e("stream")},{stream:void 0}],17:[function(e,n,s){var r=e("./DataReader");function l(o){r.call(this,o);for(var a=0;a<this.data.length;a++)o[a]=255&o[a]}e("../utils").inherits(l,r),l.prototype.byteAt=function(o){return this.data[this.zero+o]},l.prototype.lastIndexOfSignature=function(o){for(var a=o.charCodeAt(0),c=o.charCodeAt(1),d=o.charCodeAt(2),h=o.charCodeAt(3),p=this.length-4;0<=p;--p)if(this.data[p]===a&&this.data[p+1]===c&&this.data[p+2]===d&&this.data[p+3]===h)return p-this.zero;return-1},l.prototype.readAndCheckSignature=function(o){var a=o.charCodeAt(0),c=o.charCodeAt(1),d=o.charCodeAt(2),h=o.charCodeAt(3),p=this.readData(4);return a===p[0]&&c===p[1]&&d===p[2]&&h===p[3]},l.prototype.readData=function(o){if(this.checkOffset(o),o===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(e,n,s){var r=e("../utils");function l(o){this.data=o,this.length=o.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(o){this.checkIndex(this.index+o)},checkIndex:function(o){if(this.length<this.zero+o||o<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+o+"). Corrupted zip ?")},setIndex:function(o){this.checkIndex(o),this.index=o},skip:function(o){this.setIndex(this.index+o)},byteAt:function(){},readInt:function(o){var a,c=0;for(this.checkOffset(o),a=this.index+o-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=o,c},readString:function(o){return r.transformTo("string",this.readData(o))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var o=this.readInt(4);return new Date(Date.UTC(1980+(o>>25&127),(o>>21&15)-1,o>>16&31,o>>11&31,o>>5&63,(31&o)<<1))}},n.exports=l},{"../utils":32}],19:[function(e,n,s){var r=e("./Uint8ArrayReader");function l(o){r.call(this,o)}e("../utils").inherits(l,r),l.prototype.readData=function(o){this.checkOffset(o);var a=this.data.slice(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(e,n,s){var r=e("./DataReader");function l(o){r.call(this,o)}e("../utils").inherits(l,r),l.prototype.byteAt=function(o){return this.data.charCodeAt(this.zero+o)},l.prototype.lastIndexOfSignature=function(o){return this.data.lastIndexOf(o)-this.zero},l.prototype.readAndCheckSignature=function(o){return o===this.readData(4)},l.prototype.readData=function(o){this.checkOffset(o);var a=this.data.slice(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(e,n,s){var r=e("./ArrayReader");function l(o){r.call(this,o)}e("../utils").inherits(l,r),l.prototype.readData=function(o){if(this.checkOffset(o),o===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(e,n,s){var r=e("../utils"),l=e("../support"),o=e("./ArrayReader"),a=e("./StringReader"),c=e("./NodeBufferReader"),d=e("./Uint8ArrayReader");n.exports=function(h){var p=r.getTypeOf(h);return r.checkSupport(p),p!=="string"||l.uint8array?p==="nodebuffer"?new c(h):l.uint8array?new d(r.transformTo("uint8array",h)):new o(r.transformTo("array",h)):new a(h)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(e,n,s){s.LOCAL_FILE_HEADER="PK",s.CENTRAL_FILE_HEADER="PK",s.CENTRAL_DIRECTORY_END="PK",s.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",s.ZIP64_CENTRAL_DIRECTORY_END="PK",s.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(e,n,s){var r=e("./GenericWorker"),l=e("../utils");function o(a){r.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(o,r),o.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=o},{"../utils":32,"./GenericWorker":28}],25:[function(e,n,s){var r=e("./GenericWorker"),l=e("../crc32");function o(){r.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}e("../utils").inherits(o,r),o.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=o},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(e,n,s){var r=e("../utils"),l=e("./GenericWorker");function o(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}r.inherits(o,l),o.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=o},{"../utils":32,"./GenericWorker":28}],27:[function(e,n,s){var r=e("../utils"),l=e("./GenericWorker");function o(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=r.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}r.inherits(o,l),o.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},o.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,r.delay(this._tickAndRepeat,[],this)),!0)},o.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(r.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},o.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=o},{"../utils":32,"./GenericWorker":28}],28:[function(e,n,s){function r(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}r.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,o){return this._listeners[l].push(o),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,o){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,o)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var o=this;return l.on("data",function(a){o.processChunk(a)}),l.on("end",function(){o.end()}),l.on("error",function(a){o.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,o){return this.extraStreamInfo[l]=o,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=r},{}],29:[function(e,n,s){var r=e("../utils"),l=e("./ConvertWorker"),o=e("./GenericWorker"),a=e("../base64"),c=e("../support"),d=e("../external"),h=null;if(c.nodestream)try{h=e("../nodejs/NodejsStreamOutputAdapter")}catch{}function p(w,m){return new d.Promise(function(k,v){var b=[],T=w._internalType,C=w._outputType,A=w._mimeType;w.on("data",function(S,I){b.push(S),m&&m(I)}).on("error",function(S){b=[],v(S)}).on("end",function(){try{var S=(function(I,L,R){switch(I){case"blob":return r.newBlob(r.transformTo("arraybuffer",L),R);case"base64":return a.encode(L);default:return r.transformTo(I,L)}})(C,(function(I,L){var R,N=0,J=null,x=0;for(R=0;R<L.length;R++)x+=L[R].length;switch(I){case"string":return L.join("");case"array":return Array.prototype.concat.apply([],L);case"uint8array":for(J=new Uint8Array(x),R=0;R<L.length;R++)J.set(L[R],N),N+=L[R].length;return J;case"nodebuffer":return Buffer.concat(L);default:throw new Error("concat : unsupported type '"+I+"'")}})(T,b),A);k(S)}catch(I){v(I)}b=[]}).resume()})}function f(w,m,k){var v=m;switch(m){case"blob":case"arraybuffer":v="uint8array";break;case"base64":v="string"}try{this._internalType=v,this._outputType=m,this._mimeType=k,r.checkSupport(v),this._worker=w.pipe(new l(v)),w.lock()}catch(b){this._worker=new o("error"),this._worker.error(b)}}f.prototype={accumulate:function(w){return p(this,w)},on:function(w,m){var k=this;return w==="data"?this._worker.on(w,function(v){m.call(k,v.data,v.meta)}):this._worker.on(w,function(){r.delay(m,arguments,k)}),this},resume:function(){return r.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(w){if(r.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new h(this,{objectMode:this._outputType!=="nodebuffer"},w)}},n.exports=f},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(e,n,s){if(s.base64=!0,s.array=!0,s.string=!0,s.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",s.nodebuffer=typeof Buffer<"u",s.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")s.blob=!1;else{var r=new ArrayBuffer(0);try{s.blob=new Blob([r],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(r),s.blob=l.getBlob("application/zip").size===0}catch{s.blob=!1}}}try{s.nodestream=!!e("readable-stream").Readable}catch{s.nodestream=!1}},{"readable-stream":16}],31:[function(e,n,s){for(var r=e("./utils"),l=e("./support"),o=e("./nodejsUtils"),a=e("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function h(){a.call(this,"utf-8 decode"),this.leftOver=null}function p(){a.call(this,"utf-8 encode")}s.utf8encode=function(f){return l.nodebuffer?o.newBufferFrom(f,"utf-8"):(function(w){var m,k,v,b,T,C=w.length,A=0;for(b=0;b<C;b++)(64512&(k=w.charCodeAt(b)))==55296&&b+1<C&&(64512&(v=w.charCodeAt(b+1)))==56320&&(k=65536+(k-55296<<10)+(v-56320),b++),A+=k<128?1:k<2048?2:k<65536?3:4;for(m=l.uint8array?new Uint8Array(A):new Array(A),b=T=0;T<A;b++)(64512&(k=w.charCodeAt(b)))==55296&&b+1<C&&(64512&(v=w.charCodeAt(b+1)))==56320&&(k=65536+(k-55296<<10)+(v-56320),b++),k<128?m[T++]=k:(k<2048?m[T++]=192|k>>>6:(k<65536?m[T++]=224|k>>>12:(m[T++]=240|k>>>18,m[T++]=128|k>>>12&63),m[T++]=128|k>>>6&63),m[T++]=128|63&k);return m})(f)},s.utf8decode=function(f){return l.nodebuffer?r.transformTo("nodebuffer",f).toString("utf-8"):(function(w){var m,k,v,b,T=w.length,C=new Array(2*T);for(m=k=0;m<T;)if((v=w[m++])<128)C[k++]=v;else if(4<(b=c[v]))C[k++]=65533,m+=b-1;else{for(v&=b===2?31:b===3?15:7;1<b&&m<T;)v=v<<6|63&w[m++],b--;1<b?C[k++]=65533:v<65536?C[k++]=v:(v-=65536,C[k++]=55296|v>>10&1023,C[k++]=56320|1023&v)}return C.length!==k&&(C.subarray?C=C.subarray(0,k):C.length=k),r.applyFromCharCode(C)})(f=r.transformTo(l.uint8array?"uint8array":"array",f))},r.inherits(h,a),h.prototype.processChunk=function(f){var w=r.transformTo(l.uint8array?"uint8array":"array",f.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var m=w;(w=new Uint8Array(m.length+this.leftOver.length)).set(this.leftOver,0),w.set(m,this.leftOver.length)}else w=this.leftOver.concat(w);this.leftOver=null}var k=(function(b,T){var C;for((T=T||b.length)>b.length&&(T=b.length),C=T-1;0<=C&&(192&b[C])==128;)C--;return C<0||C===0?T:C+c[b[C]]>T?C:T})(w),v=w;k!==w.length&&(l.uint8array?(v=w.subarray(0,k),this.leftOver=w.subarray(k,w.length)):(v=w.slice(0,k),this.leftOver=w.slice(k,w.length))),this.push({data:s.utf8decode(v),meta:f.meta})},h.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:s.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},s.Utf8DecodeWorker=h,r.inherits(p,a),p.prototype.processChunk=function(f){this.push({data:s.utf8encode(f.data),meta:f.meta})},s.Utf8EncodeWorker=p},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(e,n,s){var r=e("./support"),l=e("./base64"),o=e("./nodejsUtils"),a=e("./external");function c(m){return m}function d(m,k){for(var v=0;v<m.length;++v)k[v]=255&m.charCodeAt(v);return k}e("setimmediate"),s.newBlob=function(m,k){s.checkSupport("blob");try{return new Blob([m],{type:k})}catch{try{var v=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return v.append(m),v.getBlob(k)}catch{throw new Error("Bug : can't construct the Blob.")}}};var h={stringifyByChunk:function(m,k,v){var b=[],T=0,C=m.length;if(C<=v)return String.fromCharCode.apply(null,m);for(;T<C;)k==="array"||k==="nodebuffer"?b.push(String.fromCharCode.apply(null,m.slice(T,Math.min(T+v,C)))):b.push(String.fromCharCode.apply(null,m.subarray(T,Math.min(T+v,C)))),T+=v;return b.join("")},stringifyByChar:function(m){for(var k="",v=0;v<m.length;v++)k+=String.fromCharCode(m[v]);return k},applyCanBeUsed:{uint8array:(function(){try{return r.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return r.nodebuffer&&String.fromCharCode.apply(null,o.allocBuffer(1)).length===1}catch{return!1}})()}};function p(m){var k=65536,v=s.getTypeOf(m),b=!0;if(v==="uint8array"?b=h.applyCanBeUsed.uint8array:v==="nodebuffer"&&(b=h.applyCanBeUsed.nodebuffer),b)for(;1<k;)try{return h.stringifyByChunk(m,v,k)}catch{k=Math.floor(k/2)}return h.stringifyByChar(m)}function f(m,k){for(var v=0;v<m.length;v++)k[v]=m[v];return k}s.applyFromCharCode=p;var w={};w.string={string:c,array:function(m){return d(m,new Array(m.length))},arraybuffer:function(m){return w.string.uint8array(m).buffer},uint8array:function(m){return d(m,new Uint8Array(m.length))},nodebuffer:function(m){return d(m,o.allocBuffer(m.length))}},w.array={string:p,array:c,arraybuffer:function(m){return new Uint8Array(m).buffer},uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return o.newBufferFrom(m)}},w.arraybuffer={string:function(m){return p(new Uint8Array(m))},array:function(m){return f(new Uint8Array(m),new Array(m.byteLength))},arraybuffer:c,uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return o.newBufferFrom(new Uint8Array(m))}},w.uint8array={string:p,array:function(m){return f(m,new Array(m.length))},arraybuffer:function(m){return m.buffer},uint8array:c,nodebuffer:function(m){return o.newBufferFrom(m)}},w.nodebuffer={string:p,array:function(m){return f(m,new Array(m.length))},arraybuffer:function(m){return w.nodebuffer.uint8array(m).buffer},uint8array:function(m){return f(m,new Uint8Array(m.length))},nodebuffer:c},s.transformTo=function(m,k){if(k=k||"",!m)return k;s.checkSupport(m);var v=s.getTypeOf(k);return w[v][m](k)},s.resolve=function(m){for(var k=m.split("/"),v=[],b=0;b<k.length;b++){var T=k[b];T==="."||T===""&&b!==0&&b!==k.length-1||(T===".."?v.pop():v.push(T))}return v.join("/")},s.getTypeOf=function(m){return typeof m=="string"?"string":Object.prototype.toString.call(m)==="[object Array]"?"array":r.nodebuffer&&o.isBuffer(m)?"nodebuffer":r.uint8array&&m instanceof Uint8Array?"uint8array":r.arraybuffer&&m instanceof ArrayBuffer?"arraybuffer":void 0},s.checkSupport=function(m){if(!r[m.toLowerCase()])throw new Error(m+" is not supported by this platform")},s.MAX_VALUE_16BITS=65535,s.MAX_VALUE_32BITS=-1,s.pretty=function(m){var k,v,b="";for(v=0;v<(m||"").length;v++)b+="\\x"+((k=m.charCodeAt(v))<16?"0":"")+k.toString(16).toUpperCase();return b},s.delay=function(m,k,v){setImmediate(function(){m.apply(v||null,k||[])})},s.inherits=function(m,k){function v(){}v.prototype=k.prototype,m.prototype=new v},s.extend=function(){var m,k,v={};for(m=0;m<arguments.length;m++)for(k in arguments[m])Object.prototype.hasOwnProperty.call(arguments[m],k)&&v[k]===void 0&&(v[k]=arguments[m][k]);return v},s.prepareContent=function(m,k,v,b,T){return a.Promise.resolve(k).then(function(C){return r.blob&&(C instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(C))!==-1)&&typeof FileReader<"u"?new a.Promise(function(A,S){var I=new FileReader;I.onload=function(L){A(L.target.result)},I.onerror=function(L){S(L.target.error)},I.readAsArrayBuffer(C)}):C}).then(function(C){var A=s.getTypeOf(C);return A?(A==="arraybuffer"?C=s.transformTo("uint8array",C):A==="string"&&(T?C=l.decode(C):v&&b!==!0&&(C=(function(S){return d(S,r.uint8array?new Uint8Array(S.length):new Array(S.length))})(C))),C):a.Promise.reject(new Error("Can't read the data of '"+m+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(e,n,s){var r=e("./reader/readerFor"),l=e("./utils"),o=e("./signature"),a=e("./zipEntry"),c=e("./support");function d(h){this.files=[],this.loadOptions=h}d.prototype={checkSignature:function(h){if(!this.reader.readAndCheckSignature(h)){this.reader.index-=4;var p=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(p)+", expected "+l.pretty(h)+")")}},isSignature:function(h,p){var f=this.reader.index;this.reader.setIndex(h);var w=this.reader.readString(4)===p;return this.reader.setIndex(f),w},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var h=this.reader.readData(this.zipCommentLength),p=c.uint8array?"uint8array":"array",f=l.transformTo(p,h);this.zipComment=this.loadOptions.decodeFileName(f)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var h,p,f,w=this.zip64EndOfCentralSize-44;0<w;)h=this.reader.readInt(2),p=this.reader.readInt(4),f=this.reader.readData(p),this.zip64ExtensibleData[h]={id:h,length:p,value:f}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var h,p;for(h=0;h<this.files.length;h++)p=this.files[h],this.reader.setIndex(p.localHeaderOffset),this.checkSignature(o.LOCAL_FILE_HEADER),p.readLocalPart(this.reader),p.handleUTF8(),p.processAttributes()},readCentralDir:function(){var h;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(o.CENTRAL_FILE_HEADER);)(h=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(h);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var h=this.reader.lastIndexOfSignature(o.CENTRAL_DIRECTORY_END);if(h<0)throw this.isSignature(0,o.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(h);var p=h;if(this.checkSignature(o.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(h=this.reader.lastIndexOfSignature(o.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(h),this.checkSignature(o.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,o.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(o.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(o.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var f=this.centralDirOffset+this.centralDirSize;this.zip64&&(f+=20,f+=12+this.zip64EndOfCentralSize);var w=p-f;if(0<w)this.isSignature(p,o.CENTRAL_FILE_HEADER)||(this.reader.zero=w);else if(w<0)throw new Error("Corrupted zip: missing "+Math.abs(w)+" bytes.")},prepareReader:function(h){this.reader=r(h)},load:function(h){this.prepareReader(h),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(e,n,s){var r=e("./reader/readerFor"),l=e("./utils"),o=e("./compressedObject"),a=e("./crc32"),c=e("./utf8"),d=e("./compressions"),h=e("./support");function p(f,w){this.options=f,this.loadOptions=w}p.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(f){var w,m;if(f.skip(22),this.fileNameLength=f.readInt(2),m=f.readInt(2),this.fileName=f.readData(this.fileNameLength),f.skip(m),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((w=(function(k){for(var v in d)if(Object.prototype.hasOwnProperty.call(d,v)&&d[v].magic===k)return d[v];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new o(this.compressedSize,this.uncompressedSize,this.crc32,w,f.readData(this.compressedSize))},readCentralPart:function(f){this.versionMadeBy=f.readInt(2),f.skip(2),this.bitFlag=f.readInt(2),this.compressionMethod=f.readString(2),this.date=f.readDate(),this.crc32=f.readInt(4),this.compressedSize=f.readInt(4),this.uncompressedSize=f.readInt(4);var w=f.readInt(2);if(this.extraFieldsLength=f.readInt(2),this.fileCommentLength=f.readInt(2),this.diskNumberStart=f.readInt(2),this.internalFileAttributes=f.readInt(2),this.externalFileAttributes=f.readInt(4),this.localHeaderOffset=f.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");f.skip(w),this.readExtraFields(f),this.parseZIP64ExtraField(f),this.fileComment=f.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var f=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),f==0&&(this.dosPermissions=63&this.externalFileAttributes),f==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var f=r(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=f.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=f.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=f.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=f.readInt(4))}},readExtraFields:function(f){var w,m,k,v=f.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});f.index+4<v;)w=f.readInt(2),m=f.readInt(2),k=f.readData(m),this.extraFields[w]={id:w,length:m,value:k};f.setIndex(v)},handleUTF8:function(){var f=h.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var w=this.findExtraFieldUnicodePath();if(w!==null)this.fileNameStr=w;else{var m=l.transformTo(f,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(m)}var k=this.findExtraFieldUnicodeComment();if(k!==null)this.fileCommentStr=k;else{var v=l.transformTo(f,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(v)}}},findExtraFieldUnicodePath:function(){var f=this.extraFields[28789];if(f){var w=r(f.value);return w.readInt(1)!==1||a(this.fileName)!==w.readInt(4)?null:c.utf8decode(w.readData(f.length-5))}return null},findExtraFieldUnicodeComment:function(){var f=this.extraFields[25461];if(f){var w=r(f.value);return w.readInt(1)!==1||a(this.fileComment)!==w.readInt(4)?null:c.utf8decode(w.readData(f.length-5))}return null}},n.exports=p},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(e,n,s){function r(w,m,k){this.name=w,this.dir=k.dir,this.date=k.date,this.comment=k.comment,this.unixPermissions=k.unixPermissions,this.dosPermissions=k.dosPermissions,this._data=m,this._dataBinary=k.binary,this.options={compression:k.compression,compressionOptions:k.compressionOptions}}var l=e("./stream/StreamHelper"),o=e("./stream/DataWorker"),a=e("./utf8"),c=e("./compressedObject"),d=e("./stream/GenericWorker");r.prototype={internalStream:function(w){var m=null,k="string";try{if(!w)throw new Error("No output type specified.");var v=(k=w.toLowerCase())==="string"||k==="text";k!=="binarystring"&&k!=="text"||(k="string"),m=this._decompressWorker();var b=!this._dataBinary;b&&!v&&(m=m.pipe(new a.Utf8EncodeWorker)),!b&&v&&(m=m.pipe(new a.Utf8DecodeWorker))}catch(T){(m=new d("error")).error(T)}return new l(m,k,"")},async:function(w,m){return this.internalStream(w).accumulate(m)},nodeStream:function(w,m){return this.internalStream(w||"nodebuffer").toNodejsStream(m)},_compressWorker:function(w,m){if(this._data instanceof c&&this._data.compression.magic===w.magic)return this._data.getCompressedWorker();var k=this._decompressWorker();return this._dataBinary||(k=k.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(k,w,m)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new o(this._data)}};for(var h=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],p=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},f=0;f<h.length;f++)r.prototype[h[f]]=p;n.exports=r},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(e,n,s){(function(r){var l,o,a=r.MutationObserver||r.WebKitMutationObserver;if(a){var c=0,d=new a(w),h=r.document.createTextNode("");d.observe(h,{characterData:!0}),l=function(){h.data=c=++c%2}}else if(r.setImmediate||r.MessageChannel===void 0)l="document"in r&&"onreadystatechange"in r.document.createElement("script")?function(){var m=r.document.createElement("script");m.onreadystatechange=function(){w(),m.onreadystatechange=null,m.parentNode.removeChild(m),m=null},r.document.documentElement.appendChild(m)}:function(){setTimeout(w,0)};else{var p=new r.MessageChannel;p.port1.onmessage=w,l=function(){p.port2.postMessage(0)}}var f=[];function w(){var m,k;o=!0;for(var v=f.length;v;){for(k=f,f=[],m=-1;++m<v;)k[m]();v=f.length}o=!1}n.exports=function(m){f.push(m)!==1||o||l()}}).call(this,typeof Rn<"u"?Rn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(e,n,s){var r=e("immediate");function l(){}var o={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function h(v){if(typeof v!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,v!==l&&m(this,v)}function p(v,b,T){this.promise=v,typeof b=="function"&&(this.onFulfilled=b,this.callFulfilled=this.otherCallFulfilled),typeof T=="function"&&(this.onRejected=T,this.callRejected=this.otherCallRejected)}function f(v,b,T){r(function(){var C;try{C=b(T)}catch(A){return o.reject(v,A)}C===v?o.reject(v,new TypeError("Cannot resolve promise with itself")):o.resolve(v,C)})}function w(v){var b=v&&v.then;if(v&&(typeof v=="object"||typeof v=="function")&&typeof b=="function")return function(){b.apply(v,arguments)}}function m(v,b){var T=!1;function C(I){T||(T=!0,o.reject(v,I))}function A(I){T||(T=!0,o.resolve(v,I))}var S=k(function(){b(A,C)});S.status==="error"&&C(S.value)}function k(v,b){var T={};try{T.value=v(b),T.status="success"}catch(C){T.status="error",T.value=C}return T}(n.exports=h).prototype.finally=function(v){if(typeof v!="function")return this;var b=this.constructor;return this.then(function(T){return b.resolve(v()).then(function(){return T})},function(T){return b.resolve(v()).then(function(){throw T})})},h.prototype.catch=function(v){return this.then(null,v)},h.prototype.then=function(v,b){if(typeof v!="function"&&this.state===c||typeof b!="function"&&this.state===a)return this;var T=new this.constructor(l);return this.state!==d?f(T,this.state===c?v:b,this.outcome):this.queue.push(new p(T,v,b)),T},p.prototype.callFulfilled=function(v){o.resolve(this.promise,v)},p.prototype.otherCallFulfilled=function(v){f(this.promise,this.onFulfilled,v)},p.prototype.callRejected=function(v){o.reject(this.promise,v)},p.prototype.otherCallRejected=function(v){f(this.promise,this.onRejected,v)},o.resolve=function(v,b){var T=k(w,b);if(T.status==="error")return o.reject(v,T.value);var C=T.value;if(C)m(v,C);else{v.state=c,v.outcome=b;for(var A=-1,S=v.queue.length;++A<S;)v.queue[A].callFulfilled(b)}return v},o.reject=function(v,b){v.state=a,v.outcome=b;for(var T=-1,C=v.queue.length;++T<C;)v.queue[T].callRejected(b);return v},h.resolve=function(v){return v instanceof this?v:o.resolve(new this(l),v)},h.reject=function(v){var b=new this(l);return o.reject(b,v)},h.all=function(v){var b=this;if(Object.prototype.toString.call(v)!=="[object Array]")return this.reject(new TypeError("must be an array"));var T=v.length,C=!1;if(!T)return this.resolve([]);for(var A=new Array(T),S=0,I=-1,L=new this(l);++I<T;)R(v[I],I);return L;function R(N,J){b.resolve(N).then(function(x){A[J]=x,++S!==T||C||(C=!0,o.resolve(L,A))},function(x){C||(C=!0,o.reject(L,x))})}},h.race=function(v){var b=this;if(Object.prototype.toString.call(v)!=="[object Array]")return this.reject(new TypeError("must be an array"));var T=v.length,C=!1;if(!T)return this.resolve([]);for(var A=-1,S=new this(l);++A<T;)I=v[A],b.resolve(I).then(function(L){C||(C=!0,o.resolve(S,L))},function(L){C||(C=!0,o.reject(S,L))});var I;return S}},{immediate:36}],38:[function(e,n,s){var r={};(0,e("./lib/utils/common").assign)(r,e("./lib/deflate"),e("./lib/inflate"),e("./lib/zlib/constants")),n.exports=r},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(e,n,s){var r=e("./zlib/deflate"),l=e("./utils/common"),o=e("./utils/strings"),a=e("./zlib/messages"),c=e("./zlib/zstream"),d=Object.prototype.toString,h=0,p=-1,f=0,w=8;function m(v){if(!(this instanceof m))return new m(v);this.options=l.assign({level:p,method:w,chunkSize:16384,windowBits:15,memLevel:8,strategy:f,to:""},v||{});var b=this.options;b.raw&&0<b.windowBits?b.windowBits=-b.windowBits:b.gzip&&0<b.windowBits&&b.windowBits<16&&(b.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var T=r.deflateInit2(this.strm,b.level,b.method,b.windowBits,b.memLevel,b.strategy);if(T!==h)throw new Error(a[T]);if(b.header&&r.deflateSetHeader(this.strm,b.header),b.dictionary){var C;if(C=typeof b.dictionary=="string"?o.string2buf(b.dictionary):d.call(b.dictionary)==="[object ArrayBuffer]"?new Uint8Array(b.dictionary):b.dictionary,(T=r.deflateSetDictionary(this.strm,C))!==h)throw new Error(a[T]);this._dict_set=!0}}function k(v,b){var T=new m(b);if(T.push(v,!0),T.err)throw T.msg||a[T.err];return T.result}m.prototype.push=function(v,b){var T,C,A=this.strm,S=this.options.chunkSize;if(this.ended)return!1;C=b===~~b?b:b===!0?4:0,typeof v=="string"?A.input=o.string2buf(v):d.call(v)==="[object ArrayBuffer]"?A.input=new Uint8Array(v):A.input=v,A.next_in=0,A.avail_in=A.input.length;do{if(A.avail_out===0&&(A.output=new l.Buf8(S),A.next_out=0,A.avail_out=S),(T=r.deflate(A,C))!==1&&T!==h)return this.onEnd(T),!(this.ended=!0);A.avail_out!==0&&(A.avail_in!==0||C!==4&&C!==2)||(this.options.to==="string"?this.onData(o.buf2binstring(l.shrinkBuf(A.output,A.next_out))):this.onData(l.shrinkBuf(A.output,A.next_out)))}while((0<A.avail_in||A.avail_out===0)&&T!==1);return C===4?(T=r.deflateEnd(this.strm),this.onEnd(T),this.ended=!0,T===h):C!==2||(this.onEnd(h),!(A.avail_out=0))},m.prototype.onData=function(v){this.chunks.push(v)},m.prototype.onEnd=function(v){v===h&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=v,this.msg=this.strm.msg},s.Deflate=m,s.deflate=k,s.deflateRaw=function(v,b){return(b=b||{}).raw=!0,k(v,b)},s.gzip=function(v,b){return(b=b||{}).gzip=!0,k(v,b)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(e,n,s){var r=e("./zlib/inflate"),l=e("./utils/common"),o=e("./utils/strings"),a=e("./zlib/constants"),c=e("./zlib/messages"),d=e("./zlib/zstream"),h=e("./zlib/gzheader"),p=Object.prototype.toString;function f(m){if(!(this instanceof f))return new f(m);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},m||{});var k=this.options;k.raw&&0<=k.windowBits&&k.windowBits<16&&(k.windowBits=-k.windowBits,k.windowBits===0&&(k.windowBits=-15)),!(0<=k.windowBits&&k.windowBits<16)||m&&m.windowBits||(k.windowBits+=32),15<k.windowBits&&k.windowBits<48&&(15&k.windowBits)==0&&(k.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var v=r.inflateInit2(this.strm,k.windowBits);if(v!==a.Z_OK)throw new Error(c[v]);this.header=new h,r.inflateGetHeader(this.strm,this.header)}function w(m,k){var v=new f(k);if(v.push(m,!0),v.err)throw v.msg||c[v.err];return v.result}f.prototype.push=function(m,k){var v,b,T,C,A,S,I=this.strm,L=this.options.chunkSize,R=this.options.dictionary,N=!1;if(this.ended)return!1;b=k===~~k?k:k===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof m=="string"?I.input=o.binstring2buf(m):p.call(m)==="[object ArrayBuffer]"?I.input=new Uint8Array(m):I.input=m,I.next_in=0,I.avail_in=I.input.length;do{if(I.avail_out===0&&(I.output=new l.Buf8(L),I.next_out=0,I.avail_out=L),(v=r.inflate(I,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&R&&(S=typeof R=="string"?o.string2buf(R):p.call(R)==="[object ArrayBuffer]"?new Uint8Array(R):R,v=r.inflateSetDictionary(this.strm,S)),v===a.Z_BUF_ERROR&&N===!0&&(v=a.Z_OK,N=!1),v!==a.Z_STREAM_END&&v!==a.Z_OK)return this.onEnd(v),!(this.ended=!0);I.next_out&&(I.avail_out!==0&&v!==a.Z_STREAM_END&&(I.avail_in!==0||b!==a.Z_FINISH&&b!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(T=o.utf8border(I.output,I.next_out),C=I.next_out-T,A=o.buf2string(I.output,T),I.next_out=C,I.avail_out=L-C,C&&l.arraySet(I.output,I.output,T,C,0),this.onData(A)):this.onData(l.shrinkBuf(I.output,I.next_out)))),I.avail_in===0&&I.avail_out===0&&(N=!0)}while((0<I.avail_in||I.avail_out===0)&&v!==a.Z_STREAM_END);return v===a.Z_STREAM_END&&(b=a.Z_FINISH),b===a.Z_FINISH?(v=r.inflateEnd(this.strm),this.onEnd(v),this.ended=!0,v===a.Z_OK):b!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(I.avail_out=0))},f.prototype.onData=function(m){this.chunks.push(m)},f.prototype.onEnd=function(m){m===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=m,this.msg=this.strm.msg},s.Inflate=f,s.inflate=w,s.inflateRaw=function(m,k){return(k=k||{}).raw=!0,w(m,k)},s.ungzip=w},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(e,n,s){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";s.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var h in d)d.hasOwnProperty(h)&&(a[h]=d[h])}}return a},s.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,h,p){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+h),p);else for(var f=0;f<h;f++)a[p+f]=c[d+f]},flattenChunks:function(a){var c,d,h,p,f,w;for(c=h=0,d=a.length;c<d;c++)h+=a[c].length;for(w=new Uint8Array(h),c=p=0,d=a.length;c<d;c++)f=a[c],w.set(f,p),p+=f.length;return w}},o={arraySet:function(a,c,d,h,p){for(var f=0;f<h;f++)a[p+f]=c[d+f]},flattenChunks:function(a){return[].concat.apply([],a)}};s.setTyped=function(a){a?(s.Buf8=Uint8Array,s.Buf16=Uint16Array,s.Buf32=Int32Array,s.assign(s,l)):(s.Buf8=Array,s.Buf16=Array,s.Buf32=Array,s.assign(s,o))},s.setTyped(r)},{}],42:[function(e,n,s){var r=e("./common"),l=!0,o=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{o=!1}for(var a=new r.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(h,p){if(p<65537&&(h.subarray&&o||!h.subarray&&l))return String.fromCharCode.apply(null,r.shrinkBuf(h,p));for(var f="",w=0;w<p;w++)f+=String.fromCharCode(h[w]);return f}a[254]=a[254]=1,s.string2buf=function(h){var p,f,w,m,k,v=h.length,b=0;for(m=0;m<v;m++)(64512&(f=h.charCodeAt(m)))==55296&&m+1<v&&(64512&(w=h.charCodeAt(m+1)))==56320&&(f=65536+(f-55296<<10)+(w-56320),m++),b+=f<128?1:f<2048?2:f<65536?3:4;for(p=new r.Buf8(b),m=k=0;k<b;m++)(64512&(f=h.charCodeAt(m)))==55296&&m+1<v&&(64512&(w=h.charCodeAt(m+1)))==56320&&(f=65536+(f-55296<<10)+(w-56320),m++),f<128?p[k++]=f:(f<2048?p[k++]=192|f>>>6:(f<65536?p[k++]=224|f>>>12:(p[k++]=240|f>>>18,p[k++]=128|f>>>12&63),p[k++]=128|f>>>6&63),p[k++]=128|63&f);return p},s.buf2binstring=function(h){return d(h,h.length)},s.binstring2buf=function(h){for(var p=new r.Buf8(h.length),f=0,w=p.length;f<w;f++)p[f]=h.charCodeAt(f);return p},s.buf2string=function(h,p){var f,w,m,k,v=p||h.length,b=new Array(2*v);for(f=w=0;f<v;)if((m=h[f++])<128)b[w++]=m;else if(4<(k=a[m]))b[w++]=65533,f+=k-1;else{for(m&=k===2?31:k===3?15:7;1<k&&f<v;)m=m<<6|63&h[f++],k--;1<k?b[w++]=65533:m<65536?b[w++]=m:(m-=65536,b[w++]=55296|m>>10&1023,b[w++]=56320|1023&m)}return d(b,w)},s.utf8border=function(h,p){var f;for((p=p||h.length)>h.length&&(p=h.length),f=p-1;0<=f&&(192&h[f])==128;)f--;return f<0||f===0?p:f+a[h[f]]>p?f:p}},{"./common":41}],43:[function(e,n,s){n.exports=function(r,l,o,a){for(var c=65535&r|0,d=r>>>16&65535|0,h=0;o!==0;){for(o-=h=2e3<o?2e3:o;d=d+(c=c+l[a++]|0)|0,--h;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(e,n,s){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(e,n,s){var r=(function(){for(var l,o=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;o[a]=l}return o})();n.exports=function(l,o,a,c){var d=r,h=c+a;l^=-1;for(var p=c;p<h;p++)l=l>>>8^d[255&(l^o[p])];return-1^l}},{}],46:[function(e,n,s){var r,l=e("../utils/common"),o=e("./trees"),a=e("./adler32"),c=e("./crc32"),d=e("./messages"),h=0,p=4,f=0,w=-2,m=-1,k=4,v=2,b=8,T=9,C=286,A=30,S=19,I=2*C+1,L=15,R=3,N=258,J=N+R+1,x=42,q=113,y=1,U=2,et=3,j=4;function it(u,z){return u.msg=d[z],z}function V(u){return(u<<1)-(4<u?9:0)}function Z(u){for(var z=u.length;0<=--z;)u[z]=0}function E(u){var z=u.state,O=z.pending;O>u.avail_out&&(O=u.avail_out),O!==0&&(l.arraySet(u.output,z.pending_buf,z.pending_out,O,u.next_out),u.next_out+=O,z.pending_out+=O,u.total_out+=O,u.avail_out-=O,z.pending-=O,z.pending===0&&(z.pending_out=0))}function D(u,z){o._tr_flush_block(u,0<=u.block_start?u.block_start:-1,u.strstart-u.block_start,z),u.block_start=u.strstart,E(u.strm)}function ot(u,z){u.pending_buf[u.pending++]=z}function rt(u,z){u.pending_buf[u.pending++]=z>>>8&255,u.pending_buf[u.pending++]=255&z}function st(u,z){var O,_,$=u.max_chain_length,B=u.strstart,W=u.prev_length,F=u.nice_match,H=u.strstart>u.w_size-J?u.strstart-(u.w_size-J):0,G=u.window,tt=u.w_mask,X=u.prev,ct=u.strstart+N,wt=G[B+W-1],mt=G[B+W];u.prev_length>=u.good_match&&($>>=2),F>u.lookahead&&(F=u.lookahead);do if(G[(O=z)+W]===mt&&G[O+W-1]===wt&&G[O]===G[B]&&G[++O]===G[B+1]){B+=2,O++;do;while(G[++B]===G[++O]&&G[++B]===G[++O]&&G[++B]===G[++O]&&G[++B]===G[++O]&&G[++B]===G[++O]&&G[++B]===G[++O]&&G[++B]===G[++O]&&G[++B]===G[++O]&&B<ct);if(_=N-(ct-B),B=ct-N,W<_){if(u.match_start=z,F<=(W=_))break;wt=G[B+W-1],mt=G[B+W]}}while((z=X[z&tt])>H&&--$!=0);return W<=u.lookahead?W:u.lookahead}function kt(u){var z,O,_,$,B,W,F,H,G,tt,X=u.w_size;do{if($=u.window_size-u.lookahead-u.strstart,u.strstart>=X+(X-J)){for(l.arraySet(u.window,u.window,X,X,0),u.match_start-=X,u.strstart-=X,u.block_start-=X,z=O=u.hash_size;_=u.head[--z],u.head[z]=X<=_?_-X:0,--O;);for(z=O=X;_=u.prev[--z],u.prev[z]=X<=_?_-X:0,--O;);$+=X}if(u.strm.avail_in===0)break;if(W=u.strm,F=u.window,H=u.strstart+u.lookahead,G=$,tt=void 0,tt=W.avail_in,G<tt&&(tt=G),O=tt===0?0:(W.avail_in-=tt,l.arraySet(F,W.input,W.next_in,tt,H),W.state.wrap===1?W.adler=a(W.adler,F,tt,H):W.state.wrap===2&&(W.adler=c(W.adler,F,tt,H)),W.next_in+=tt,W.total_in+=tt,tt),u.lookahead+=O,u.lookahead+u.insert>=R)for(B=u.strstart-u.insert,u.ins_h=u.window[B],u.ins_h=(u.ins_h<<u.hash_shift^u.window[B+1])&u.hash_mask;u.insert&&(u.ins_h=(u.ins_h<<u.hash_shift^u.window[B+R-1])&u.hash_mask,u.prev[B&u.w_mask]=u.head[u.ins_h],u.head[u.ins_h]=B,B++,u.insert--,!(u.lookahead+u.insert<R)););}while(u.lookahead<J&&u.strm.avail_in!==0)}function $t(u,z){for(var O,_;;){if(u.lookahead<J){if(kt(u),u.lookahead<J&&z===h)return y;if(u.lookahead===0)break}if(O=0,u.lookahead>=R&&(u.ins_h=(u.ins_h<<u.hash_shift^u.window[u.strstart+R-1])&u.hash_mask,O=u.prev[u.strstart&u.w_mask]=u.head[u.ins_h],u.head[u.ins_h]=u.strstart),O!==0&&u.strstart-O<=u.w_size-J&&(u.match_length=st(u,O)),u.match_length>=R)if(_=o._tr_tally(u,u.strstart-u.match_start,u.match_length-R),u.lookahead-=u.match_length,u.match_length<=u.max_lazy_match&&u.lookahead>=R){for(u.match_length--;u.strstart++,u.ins_h=(u.ins_h<<u.hash_shift^u.window[u.strstart+R-1])&u.hash_mask,O=u.prev[u.strstart&u.w_mask]=u.head[u.ins_h],u.head[u.ins_h]=u.strstart,--u.match_length!=0;);u.strstart++}else u.strstart+=u.match_length,u.match_length=0,u.ins_h=u.window[u.strstart],u.ins_h=(u.ins_h<<u.hash_shift^u.window[u.strstart+1])&u.hash_mask;else _=o._tr_tally(u,0,u.window[u.strstart]),u.lookahead--,u.strstart++;if(_&&(D(u,!1),u.strm.avail_out===0))return y}return u.insert=u.strstart<R-1?u.strstart:R-1,z===p?(D(u,!0),u.strm.avail_out===0?et:j):u.last_lit&&(D(u,!1),u.strm.avail_out===0)?y:U}function yt(u,z){for(var O,_,$;;){if(u.lookahead<J){if(kt(u),u.lookahead<J&&z===h)return y;if(u.lookahead===0)break}if(O=0,u.lookahead>=R&&(u.ins_h=(u.ins_h<<u.hash_shift^u.window[u.strstart+R-1])&u.hash_mask,O=u.prev[u.strstart&u.w_mask]=u.head[u.ins_h],u.head[u.ins_h]=u.strstart),u.prev_length=u.match_length,u.prev_match=u.match_start,u.match_length=R-1,O!==0&&u.prev_length<u.max_lazy_match&&u.strstart-O<=u.w_size-J&&(u.match_length=st(u,O),u.match_length<=5&&(u.strategy===1||u.match_length===R&&4096<u.strstart-u.match_start)&&(u.match_length=R-1)),u.prev_length>=R&&u.match_length<=u.prev_length){for($=u.strstart+u.lookahead-R,_=o._tr_tally(u,u.strstart-1-u.prev_match,u.prev_length-R),u.lookahead-=u.prev_length-1,u.prev_length-=2;++u.strstart<=$&&(u.ins_h=(u.ins_h<<u.hash_shift^u.window[u.strstart+R-1])&u.hash_mask,O=u.prev[u.strstart&u.w_mask]=u.head[u.ins_h],u.head[u.ins_h]=u.strstart),--u.prev_length!=0;);if(u.match_available=0,u.match_length=R-1,u.strstart++,_&&(D(u,!1),u.strm.avail_out===0))return y}else if(u.match_available){if((_=o._tr_tally(u,0,u.window[u.strstart-1]))&&D(u,!1),u.strstart++,u.lookahead--,u.strm.avail_out===0)return y}else u.match_available=1,u.strstart++,u.lookahead--}return u.match_available&&(_=o._tr_tally(u,0,u.window[u.strstart-1]),u.match_available=0),u.insert=u.strstart<R-1?u.strstart:R-1,z===p?(D(u,!0),u.strm.avail_out===0?et:j):u.last_lit&&(D(u,!1),u.strm.avail_out===0)?y:U}function Y(u,z,O,_,$){this.good_length=u,this.max_lazy=z,this.nice_length=O,this.max_chain=_,this.func=$}function lt(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=b,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*I),this.dyn_dtree=new l.Buf16(2*(2*A+1)),this.bl_tree=new l.Buf16(2*(2*S+1)),Z(this.dyn_ltree),Z(this.dyn_dtree),Z(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(L+1),this.heap=new l.Buf16(2*C+1),Z(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*C+1),Z(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function dt(u){var z;return u&&u.state?(u.total_in=u.total_out=0,u.data_type=v,(z=u.state).pending=0,z.pending_out=0,z.wrap<0&&(z.wrap=-z.wrap),z.status=z.wrap?x:q,u.adler=z.wrap===2?0:1,z.last_flush=h,o._tr_init(z),f):it(u,w)}function M(u){var z=dt(u);return z===f&&(function(O){O.window_size=2*O.w_size,Z(O.head),O.max_lazy_match=r[O.level].max_lazy,O.good_match=r[O.level].good_length,O.nice_match=r[O.level].nice_length,O.max_chain_length=r[O.level].max_chain,O.strstart=0,O.block_start=0,O.lookahead=0,O.insert=0,O.match_length=O.prev_length=R-1,O.match_available=0,O.ins_h=0})(u.state),z}function P(u,z,O,_,$,B){if(!u)return w;var W=1;if(z===m&&(z=6),_<0?(W=0,_=-_):15<_&&(W=2,_-=16),$<1||T<$||O!==b||_<8||15<_||z<0||9<z||B<0||k<B)return it(u,w);_===8&&(_=9);var F=new lt;return(u.state=F).strm=u,F.wrap=W,F.gzhead=null,F.w_bits=_,F.w_size=1<<F.w_bits,F.w_mask=F.w_size-1,F.hash_bits=$+7,F.hash_size=1<<F.hash_bits,F.hash_mask=F.hash_size-1,F.hash_shift=~~((F.hash_bits+R-1)/R),F.window=new l.Buf8(2*F.w_size),F.head=new l.Buf16(F.hash_size),F.prev=new l.Buf16(F.w_size),F.lit_bufsize=1<<$+6,F.pending_buf_size=4*F.lit_bufsize,F.pending_buf=new l.Buf8(F.pending_buf_size),F.d_buf=1*F.lit_bufsize,F.l_buf=3*F.lit_bufsize,F.level=z,F.strategy=B,F.method=O,M(u)}r=[new Y(0,0,0,0,function(u,z){var O=65535;for(O>u.pending_buf_size-5&&(O=u.pending_buf_size-5);;){if(u.lookahead<=1){if(kt(u),u.lookahead===0&&z===h)return y;if(u.lookahead===0)break}u.strstart+=u.lookahead,u.lookahead=0;var _=u.block_start+O;if((u.strstart===0||u.strstart>=_)&&(u.lookahead=u.strstart-_,u.strstart=_,D(u,!1),u.strm.avail_out===0)||u.strstart-u.block_start>=u.w_size-J&&(D(u,!1),u.strm.avail_out===0))return y}return u.insert=0,z===p?(D(u,!0),u.strm.avail_out===0?et:j):(u.strstart>u.block_start&&(D(u,!1),u.strm.avail_out),y)}),new Y(4,4,8,4,$t),new Y(4,5,16,8,$t),new Y(4,6,32,32,$t),new Y(4,4,16,16,yt),new Y(8,16,32,32,yt),new Y(8,16,128,128,yt),new Y(8,32,128,256,yt),new Y(32,128,258,1024,yt),new Y(32,258,258,4096,yt)],s.deflateInit=function(u,z){return P(u,z,b,15,8,0)},s.deflateInit2=P,s.deflateReset=M,s.deflateResetKeep=dt,s.deflateSetHeader=function(u,z){return u&&u.state?u.state.wrap!==2?w:(u.state.gzhead=z,f):w},s.deflate=function(u,z){var O,_,$,B;if(!u||!u.state||5<z||z<0)return u?it(u,w):w;if(_=u.state,!u.output||!u.input&&u.avail_in!==0||_.status===666&&z!==p)return it(u,u.avail_out===0?-5:w);if(_.strm=u,O=_.last_flush,_.last_flush=z,_.status===x)if(_.wrap===2)u.adler=0,ot(_,31),ot(_,139),ot(_,8),_.gzhead?(ot(_,(_.gzhead.text?1:0)+(_.gzhead.hcrc?2:0)+(_.gzhead.extra?4:0)+(_.gzhead.name?8:0)+(_.gzhead.comment?16:0)),ot(_,255&_.gzhead.time),ot(_,_.gzhead.time>>8&255),ot(_,_.gzhead.time>>16&255),ot(_,_.gzhead.time>>24&255),ot(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),ot(_,255&_.gzhead.os),_.gzhead.extra&&_.gzhead.extra.length&&(ot(_,255&_.gzhead.extra.length),ot(_,_.gzhead.extra.length>>8&255)),_.gzhead.hcrc&&(u.adler=c(u.adler,_.pending_buf,_.pending,0)),_.gzindex=0,_.status=69):(ot(_,0),ot(_,0),ot(_,0),ot(_,0),ot(_,0),ot(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),ot(_,3),_.status=q);else{var W=b+(_.w_bits-8<<4)<<8;W|=(2<=_.strategy||_.level<2?0:_.level<6?1:_.level===6?2:3)<<6,_.strstart!==0&&(W|=32),W+=31-W%31,_.status=q,rt(_,W),_.strstart!==0&&(rt(_,u.adler>>>16),rt(_,65535&u.adler)),u.adler=1}if(_.status===69)if(_.gzhead.extra){for($=_.pending;_.gzindex<(65535&_.gzhead.extra.length)&&(_.pending!==_.pending_buf_size||(_.gzhead.hcrc&&_.pending>$&&(u.adler=c(u.adler,_.pending_buf,_.pending-$,$)),E(u),$=_.pending,_.pending!==_.pending_buf_size));)ot(_,255&_.gzhead.extra[_.gzindex]),_.gzindex++;_.gzhead.hcrc&&_.pending>$&&(u.adler=c(u.adler,_.pending_buf,_.pending-$,$)),_.gzindex===_.gzhead.extra.length&&(_.gzindex=0,_.status=73)}else _.status=73;if(_.status===73)if(_.gzhead.name){$=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>$&&(u.adler=c(u.adler,_.pending_buf,_.pending-$,$)),E(u),$=_.pending,_.pending===_.pending_buf_size)){B=1;break}B=_.gzindex<_.gzhead.name.length?255&_.gzhead.name.charCodeAt(_.gzindex++):0,ot(_,B)}while(B!==0);_.gzhead.hcrc&&_.pending>$&&(u.adler=c(u.adler,_.pending_buf,_.pending-$,$)),B===0&&(_.gzindex=0,_.status=91)}else _.status=91;if(_.status===91)if(_.gzhead.comment){$=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>$&&(u.adler=c(u.adler,_.pending_buf,_.pending-$,$)),E(u),$=_.pending,_.pending===_.pending_buf_size)){B=1;break}B=_.gzindex<_.gzhead.comment.length?255&_.gzhead.comment.charCodeAt(_.gzindex++):0,ot(_,B)}while(B!==0);_.gzhead.hcrc&&_.pending>$&&(u.adler=c(u.adler,_.pending_buf,_.pending-$,$)),B===0&&(_.status=103)}else _.status=103;if(_.status===103&&(_.gzhead.hcrc?(_.pending+2>_.pending_buf_size&&E(u),_.pending+2<=_.pending_buf_size&&(ot(_,255&u.adler),ot(_,u.adler>>8&255),u.adler=0,_.status=q)):_.status=q),_.pending!==0){if(E(u),u.avail_out===0)return _.last_flush=-1,f}else if(u.avail_in===0&&V(z)<=V(O)&&z!==p)return it(u,-5);if(_.status===666&&u.avail_in!==0)return it(u,-5);if(u.avail_in!==0||_.lookahead!==0||z!==h&&_.status!==666){var F=_.strategy===2?(function(H,G){for(var tt;;){if(H.lookahead===0&&(kt(H),H.lookahead===0)){if(G===h)return y;break}if(H.match_length=0,tt=o._tr_tally(H,0,H.window[H.strstart]),H.lookahead--,H.strstart++,tt&&(D(H,!1),H.strm.avail_out===0))return y}return H.insert=0,G===p?(D(H,!0),H.strm.avail_out===0?et:j):H.last_lit&&(D(H,!1),H.strm.avail_out===0)?y:U})(_,z):_.strategy===3?(function(H,G){for(var tt,X,ct,wt,mt=H.window;;){if(H.lookahead<=N){if(kt(H),H.lookahead<=N&&G===h)return y;if(H.lookahead===0)break}if(H.match_length=0,H.lookahead>=R&&0<H.strstart&&(X=mt[ct=H.strstart-1])===mt[++ct]&&X===mt[++ct]&&X===mt[++ct]){wt=H.strstart+N;do;while(X===mt[++ct]&&X===mt[++ct]&&X===mt[++ct]&&X===mt[++ct]&&X===mt[++ct]&&X===mt[++ct]&&X===mt[++ct]&&X===mt[++ct]&&ct<wt);H.match_length=N-(wt-ct),H.match_length>H.lookahead&&(H.match_length=H.lookahead)}if(H.match_length>=R?(tt=o._tr_tally(H,1,H.match_length-R),H.lookahead-=H.match_length,H.strstart+=H.match_length,H.match_length=0):(tt=o._tr_tally(H,0,H.window[H.strstart]),H.lookahead--,H.strstart++),tt&&(D(H,!1),H.strm.avail_out===0))return y}return H.insert=0,G===p?(D(H,!0),H.strm.avail_out===0?et:j):H.last_lit&&(D(H,!1),H.strm.avail_out===0)?y:U})(_,z):r[_.level].func(_,z);if(F!==et&&F!==j||(_.status=666),F===y||F===et)return u.avail_out===0&&(_.last_flush=-1),f;if(F===U&&(z===1?o._tr_align(_):z!==5&&(o._tr_stored_block(_,0,0,!1),z===3&&(Z(_.head),_.lookahead===0&&(_.strstart=0,_.block_start=0,_.insert=0))),E(u),u.avail_out===0))return _.last_flush=-1,f}return z!==p?f:_.wrap<=0?1:(_.wrap===2?(ot(_,255&u.adler),ot(_,u.adler>>8&255),ot(_,u.adler>>16&255),ot(_,u.adler>>24&255),ot(_,255&u.total_in),ot(_,u.total_in>>8&255),ot(_,u.total_in>>16&255),ot(_,u.total_in>>24&255)):(rt(_,u.adler>>>16),rt(_,65535&u.adler)),E(u),0<_.wrap&&(_.wrap=-_.wrap),_.pending!==0?f:1)},s.deflateEnd=function(u){var z;return u&&u.state?(z=u.state.status)!==x&&z!==69&&z!==73&&z!==91&&z!==103&&z!==q&&z!==666?it(u,w):(u.state=null,z===q?it(u,-3):f):w},s.deflateSetDictionary=function(u,z){var O,_,$,B,W,F,H,G,tt=z.length;if(!u||!u.state||(B=(O=u.state).wrap)===2||B===1&&O.status!==x||O.lookahead)return w;for(B===1&&(u.adler=a(u.adler,z,tt,0)),O.wrap=0,tt>=O.w_size&&(B===0&&(Z(O.head),O.strstart=0,O.block_start=0,O.insert=0),G=new l.Buf8(O.w_size),l.arraySet(G,z,tt-O.w_size,O.w_size,0),z=G,tt=O.w_size),W=u.avail_in,F=u.next_in,H=u.input,u.avail_in=tt,u.next_in=0,u.input=z,kt(O);O.lookahead>=R;){for(_=O.strstart,$=O.lookahead-(R-1);O.ins_h=(O.ins_h<<O.hash_shift^O.window[_+R-1])&O.hash_mask,O.prev[_&O.w_mask]=O.head[O.ins_h],O.head[O.ins_h]=_,_++,--$;);O.strstart=_,O.lookahead=R-1,kt(O)}return O.strstart+=O.lookahead,O.block_start=O.strstart,O.insert=O.lookahead,O.lookahead=0,O.match_length=O.prev_length=R-1,O.match_available=0,u.next_in=F,u.input=H,u.avail_in=W,O.wrap=B,f},s.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(e,n,s){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(e,n,s){n.exports=function(r,l){var o,a,c,d,h,p,f,w,m,k,v,b,T,C,A,S,I,L,R,N,J,x,q,y,U;o=r.state,a=r.next_in,y=r.input,c=a+(r.avail_in-5),d=r.next_out,U=r.output,h=d-(l-r.avail_out),p=d+(r.avail_out-257),f=o.dmax,w=o.wsize,m=o.whave,k=o.wnext,v=o.window,b=o.hold,T=o.bits,C=o.lencode,A=o.distcode,S=(1<<o.lenbits)-1,I=(1<<o.distbits)-1;t:do{T<15&&(b+=y[a++]<<T,T+=8,b+=y[a++]<<T,T+=8),L=C[b&S];e:for(;;){if(b>>>=R=L>>>24,T-=R,(R=L>>>16&255)===0)U[d++]=65535&L;else{if(!(16&R)){if((64&R)==0){L=C[(65535&L)+(b&(1<<R)-1)];continue e}if(32&R){o.mode=12;break t}r.msg="invalid literal/length code",o.mode=30;break t}N=65535&L,(R&=15)&&(T<R&&(b+=y[a++]<<T,T+=8),N+=b&(1<<R)-1,b>>>=R,T-=R),T<15&&(b+=y[a++]<<T,T+=8,b+=y[a++]<<T,T+=8),L=A[b&I];i:for(;;){if(b>>>=R=L>>>24,T-=R,!(16&(R=L>>>16&255))){if((64&R)==0){L=A[(65535&L)+(b&(1<<R)-1)];continue i}r.msg="invalid distance code",o.mode=30;break t}if(J=65535&L,T<(R&=15)&&(b+=y[a++]<<T,(T+=8)<R&&(b+=y[a++]<<T,T+=8)),f<(J+=b&(1<<R)-1)){r.msg="invalid distance too far back",o.mode=30;break t}if(b>>>=R,T-=R,(R=d-h)<J){if(m<(R=J-R)&&o.sane){r.msg="invalid distance too far back",o.mode=30;break t}if(q=v,(x=0)===k){if(x+=w-R,R<N){for(N-=R;U[d++]=v[x++],--R;);x=d-J,q=U}}else if(k<R){if(x+=w+k-R,(R-=k)<N){for(N-=R;U[d++]=v[x++],--R;);if(x=0,k<N){for(N-=R=k;U[d++]=v[x++],--R;);x=d-J,q=U}}}else if(x+=k-R,R<N){for(N-=R;U[d++]=v[x++],--R;);x=d-J,q=U}for(;2<N;)U[d++]=q[x++],U[d++]=q[x++],U[d++]=q[x++],N-=3;N&&(U[d++]=q[x++],1<N&&(U[d++]=q[x++]))}else{for(x=d-J;U[d++]=U[x++],U[d++]=U[x++],U[d++]=U[x++],2<(N-=3););N&&(U[d++]=U[x++],1<N&&(U[d++]=U[x++]))}break}}break}}while(a<c&&d<p);a-=N=T>>3,b&=(1<<(T-=N<<3))-1,r.next_in=a,r.next_out=d,r.avail_in=a<c?c-a+5:5-(a-c),r.avail_out=d<p?p-d+257:257-(d-p),o.hold=b,o.bits=T}},{}],49:[function(e,n,s){var r=e("../utils/common"),l=e("./adler32"),o=e("./crc32"),a=e("./inffast"),c=e("./inftrees"),d=1,h=2,p=0,f=-2,w=1,m=852,k=592;function v(x){return(x>>>24&255)+(x>>>8&65280)+((65280&x)<<8)+((255&x)<<24)}function b(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new r.Buf16(320),this.work=new r.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function T(x){var q;return x&&x.state?(q=x.state,x.total_in=x.total_out=q.total=0,x.msg="",q.wrap&&(x.adler=1&q.wrap),q.mode=w,q.last=0,q.havedict=0,q.dmax=32768,q.head=null,q.hold=0,q.bits=0,q.lencode=q.lendyn=new r.Buf32(m),q.distcode=q.distdyn=new r.Buf32(k),q.sane=1,q.back=-1,p):f}function C(x){var q;return x&&x.state?((q=x.state).wsize=0,q.whave=0,q.wnext=0,T(x)):f}function A(x,q){var y,U;return x&&x.state?(U=x.state,q<0?(y=0,q=-q):(y=1+(q>>4),q<48&&(q&=15)),q&&(q<8||15<q)?f:(U.window!==null&&U.wbits!==q&&(U.window=null),U.wrap=y,U.wbits=q,C(x))):f}function S(x,q){var y,U;return x?(U=new b,(x.state=U).window=null,(y=A(x,q))!==p&&(x.state=null),y):f}var I,L,R=!0;function N(x){if(R){var q;for(I=new r.Buf32(512),L=new r.Buf32(32),q=0;q<144;)x.lens[q++]=8;for(;q<256;)x.lens[q++]=9;for(;q<280;)x.lens[q++]=7;for(;q<288;)x.lens[q++]=8;for(c(d,x.lens,0,288,I,0,x.work,{bits:9}),q=0;q<32;)x.lens[q++]=5;c(h,x.lens,0,32,L,0,x.work,{bits:5}),R=!1}x.lencode=I,x.lenbits=9,x.distcode=L,x.distbits=5}function J(x,q,y,U){var et,j=x.state;return j.window===null&&(j.wsize=1<<j.wbits,j.wnext=0,j.whave=0,j.window=new r.Buf8(j.wsize)),U>=j.wsize?(r.arraySet(j.window,q,y-j.wsize,j.wsize,0),j.wnext=0,j.whave=j.wsize):(U<(et=j.wsize-j.wnext)&&(et=U),r.arraySet(j.window,q,y-U,et,j.wnext),(U-=et)?(r.arraySet(j.window,q,y-U,U,0),j.wnext=U,j.whave=j.wsize):(j.wnext+=et,j.wnext===j.wsize&&(j.wnext=0),j.whave<j.wsize&&(j.whave+=et))),0}s.inflateReset=C,s.inflateReset2=A,s.inflateResetKeep=T,s.inflateInit=function(x){return S(x,15)},s.inflateInit2=S,s.inflate=function(x,q){var y,U,et,j,it,V,Z,E,D,ot,rt,st,kt,$t,yt,Y,lt,dt,M,P,u,z,O,_,$=0,B=new r.Buf8(4),W=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!x||!x.state||!x.output||!x.input&&x.avail_in!==0)return f;(y=x.state).mode===12&&(y.mode=13),it=x.next_out,et=x.output,Z=x.avail_out,j=x.next_in,U=x.input,V=x.avail_in,E=y.hold,D=y.bits,ot=V,rt=Z,z=p;t:for(;;)switch(y.mode){case w:if(y.wrap===0){y.mode=13;break}for(;D<16;){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}if(2&y.wrap&&E===35615){B[y.check=0]=255&E,B[1]=E>>>8&255,y.check=o(y.check,B,2,0),D=E=0,y.mode=2;break}if(y.flags=0,y.head&&(y.head.done=!1),!(1&y.wrap)||(((255&E)<<8)+(E>>8))%31){x.msg="incorrect header check",y.mode=30;break}if((15&E)!=8){x.msg="unknown compression method",y.mode=30;break}if(D-=4,u=8+(15&(E>>>=4)),y.wbits===0)y.wbits=u;else if(u>y.wbits){x.msg="invalid window size",y.mode=30;break}y.dmax=1<<u,x.adler=y.check=1,y.mode=512&E?10:12,D=E=0;break;case 2:for(;D<16;){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}if(y.flags=E,(255&y.flags)!=8){x.msg="unknown compression method",y.mode=30;break}if(57344&y.flags){x.msg="unknown header flags set",y.mode=30;break}y.head&&(y.head.text=E>>8&1),512&y.flags&&(B[0]=255&E,B[1]=E>>>8&255,y.check=o(y.check,B,2,0)),D=E=0,y.mode=3;case 3:for(;D<32;){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}y.head&&(y.head.time=E),512&y.flags&&(B[0]=255&E,B[1]=E>>>8&255,B[2]=E>>>16&255,B[3]=E>>>24&255,y.check=o(y.check,B,4,0)),D=E=0,y.mode=4;case 4:for(;D<16;){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}y.head&&(y.head.xflags=255&E,y.head.os=E>>8),512&y.flags&&(B[0]=255&E,B[1]=E>>>8&255,y.check=o(y.check,B,2,0)),D=E=0,y.mode=5;case 5:if(1024&y.flags){for(;D<16;){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}y.length=E,y.head&&(y.head.extra_len=E),512&y.flags&&(B[0]=255&E,B[1]=E>>>8&255,y.check=o(y.check,B,2,0)),D=E=0}else y.head&&(y.head.extra=null);y.mode=6;case 6:if(1024&y.flags&&(V<(st=y.length)&&(st=V),st&&(y.head&&(u=y.head.extra_len-y.length,y.head.extra||(y.head.extra=new Array(y.head.extra_len)),r.arraySet(y.head.extra,U,j,st,u)),512&y.flags&&(y.check=o(y.check,U,st,j)),V-=st,j+=st,y.length-=st),y.length))break t;y.length=0,y.mode=7;case 7:if(2048&y.flags){if(V===0)break t;for(st=0;u=U[j+st++],y.head&&u&&y.length<65536&&(y.head.name+=String.fromCharCode(u)),u&&st<V;);if(512&y.flags&&(y.check=o(y.check,U,st,j)),V-=st,j+=st,u)break t}else y.head&&(y.head.name=null);y.length=0,y.mode=8;case 8:if(4096&y.flags){if(V===0)break t;for(st=0;u=U[j+st++],y.head&&u&&y.length<65536&&(y.head.comment+=String.fromCharCode(u)),u&&st<V;);if(512&y.flags&&(y.check=o(y.check,U,st,j)),V-=st,j+=st,u)break t}else y.head&&(y.head.comment=null);y.mode=9;case 9:if(512&y.flags){for(;D<16;){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}if(E!==(65535&y.check)){x.msg="header crc mismatch",y.mode=30;break}D=E=0}y.head&&(y.head.hcrc=y.flags>>9&1,y.head.done=!0),x.adler=y.check=0,y.mode=12;break;case 10:for(;D<32;){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}x.adler=y.check=v(E),D=E=0,y.mode=11;case 11:if(y.havedict===0)return x.next_out=it,x.avail_out=Z,x.next_in=j,x.avail_in=V,y.hold=E,y.bits=D,2;x.adler=y.check=1,y.mode=12;case 12:if(q===5||q===6)break t;case 13:if(y.last){E>>>=7&D,D-=7&D,y.mode=27;break}for(;D<3;){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}switch(y.last=1&E,D-=1,3&(E>>>=1)){case 0:y.mode=14;break;case 1:if(N(y),y.mode=20,q!==6)break;E>>>=2,D-=2;break t;case 2:y.mode=17;break;case 3:x.msg="invalid block type",y.mode=30}E>>>=2,D-=2;break;case 14:for(E>>>=7&D,D-=7&D;D<32;){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}if((65535&E)!=(E>>>16^65535)){x.msg="invalid stored block lengths",y.mode=30;break}if(y.length=65535&E,D=E=0,y.mode=15,q===6)break t;case 15:y.mode=16;case 16:if(st=y.length){if(V<st&&(st=V),Z<st&&(st=Z),st===0)break t;r.arraySet(et,U,j,st,it),V-=st,j+=st,Z-=st,it+=st,y.length-=st;break}y.mode=12;break;case 17:for(;D<14;){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}if(y.nlen=257+(31&E),E>>>=5,D-=5,y.ndist=1+(31&E),E>>>=5,D-=5,y.ncode=4+(15&E),E>>>=4,D-=4,286<y.nlen||30<y.ndist){x.msg="too many length or distance symbols",y.mode=30;break}y.have=0,y.mode=18;case 18:for(;y.have<y.ncode;){for(;D<3;){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}y.lens[W[y.have++]]=7&E,E>>>=3,D-=3}for(;y.have<19;)y.lens[W[y.have++]]=0;if(y.lencode=y.lendyn,y.lenbits=7,O={bits:y.lenbits},z=c(0,y.lens,0,19,y.lencode,0,y.work,O),y.lenbits=O.bits,z){x.msg="invalid code lengths set",y.mode=30;break}y.have=0,y.mode=19;case 19:for(;y.have<y.nlen+y.ndist;){for(;Y=($=y.lencode[E&(1<<y.lenbits)-1])>>>16&255,lt=65535&$,!((yt=$>>>24)<=D);){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}if(lt<16)E>>>=yt,D-=yt,y.lens[y.have++]=lt;else{if(lt===16){for(_=yt+2;D<_;){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}if(E>>>=yt,D-=yt,y.have===0){x.msg="invalid bit length repeat",y.mode=30;break}u=y.lens[y.have-1],st=3+(3&E),E>>>=2,D-=2}else if(lt===17){for(_=yt+3;D<_;){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}D-=yt,u=0,st=3+(7&(E>>>=yt)),E>>>=3,D-=3}else{for(_=yt+7;D<_;){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}D-=yt,u=0,st=11+(127&(E>>>=yt)),E>>>=7,D-=7}if(y.have+st>y.nlen+y.ndist){x.msg="invalid bit length repeat",y.mode=30;break}for(;st--;)y.lens[y.have++]=u}}if(y.mode===30)break;if(y.lens[256]===0){x.msg="invalid code -- missing end-of-block",y.mode=30;break}if(y.lenbits=9,O={bits:y.lenbits},z=c(d,y.lens,0,y.nlen,y.lencode,0,y.work,O),y.lenbits=O.bits,z){x.msg="invalid literal/lengths set",y.mode=30;break}if(y.distbits=6,y.distcode=y.distdyn,O={bits:y.distbits},z=c(h,y.lens,y.nlen,y.ndist,y.distcode,0,y.work,O),y.distbits=O.bits,z){x.msg="invalid distances set",y.mode=30;break}if(y.mode=20,q===6)break t;case 20:y.mode=21;case 21:if(6<=V&&258<=Z){x.next_out=it,x.avail_out=Z,x.next_in=j,x.avail_in=V,y.hold=E,y.bits=D,a(x,rt),it=x.next_out,et=x.output,Z=x.avail_out,j=x.next_in,U=x.input,V=x.avail_in,E=y.hold,D=y.bits,y.mode===12&&(y.back=-1);break}for(y.back=0;Y=($=y.lencode[E&(1<<y.lenbits)-1])>>>16&255,lt=65535&$,!((yt=$>>>24)<=D);){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}if(Y&&(240&Y)==0){for(dt=yt,M=Y,P=lt;Y=($=y.lencode[P+((E&(1<<dt+M)-1)>>dt)])>>>16&255,lt=65535&$,!(dt+(yt=$>>>24)<=D);){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}E>>>=dt,D-=dt,y.back+=dt}if(E>>>=yt,D-=yt,y.back+=yt,y.length=lt,Y===0){y.mode=26;break}if(32&Y){y.back=-1,y.mode=12;break}if(64&Y){x.msg="invalid literal/length code",y.mode=30;break}y.extra=15&Y,y.mode=22;case 22:if(y.extra){for(_=y.extra;D<_;){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}y.length+=E&(1<<y.extra)-1,E>>>=y.extra,D-=y.extra,y.back+=y.extra}y.was=y.length,y.mode=23;case 23:for(;Y=($=y.distcode[E&(1<<y.distbits)-1])>>>16&255,lt=65535&$,!((yt=$>>>24)<=D);){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}if((240&Y)==0){for(dt=yt,M=Y,P=lt;Y=($=y.distcode[P+((E&(1<<dt+M)-1)>>dt)])>>>16&255,lt=65535&$,!(dt+(yt=$>>>24)<=D);){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}E>>>=dt,D-=dt,y.back+=dt}if(E>>>=yt,D-=yt,y.back+=yt,64&Y){x.msg="invalid distance code",y.mode=30;break}y.offset=lt,y.extra=15&Y,y.mode=24;case 24:if(y.extra){for(_=y.extra;D<_;){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}y.offset+=E&(1<<y.extra)-1,E>>>=y.extra,D-=y.extra,y.back+=y.extra}if(y.offset>y.dmax){x.msg="invalid distance too far back",y.mode=30;break}y.mode=25;case 25:if(Z===0)break t;if(st=rt-Z,y.offset>st){if((st=y.offset-st)>y.whave&&y.sane){x.msg="invalid distance too far back",y.mode=30;break}kt=st>y.wnext?(st-=y.wnext,y.wsize-st):y.wnext-st,st>y.length&&(st=y.length),$t=y.window}else $t=et,kt=it-y.offset,st=y.length;for(Z<st&&(st=Z),Z-=st,y.length-=st;et[it++]=$t[kt++],--st;);y.length===0&&(y.mode=21);break;case 26:if(Z===0)break t;et[it++]=y.length,Z--,y.mode=21;break;case 27:if(y.wrap){for(;D<32;){if(V===0)break t;V--,E|=U[j++]<<D,D+=8}if(rt-=Z,x.total_out+=rt,y.total+=rt,rt&&(x.adler=y.check=y.flags?o(y.check,et,rt,it-rt):l(y.check,et,rt,it-rt)),rt=Z,(y.flags?E:v(E))!==y.check){x.msg="incorrect data check",y.mode=30;break}D=E=0}y.mode=28;case 28:if(y.wrap&&y.flags){for(;D<32;){if(V===0)break t;V--,E+=U[j++]<<D,D+=8}if(E!==(4294967295&y.total)){x.msg="incorrect length check",y.mode=30;break}D=E=0}y.mode=29;case 29:z=1;break t;case 30:z=-3;break t;case 31:return-4;case 32:default:return f}return x.next_out=it,x.avail_out=Z,x.next_in=j,x.avail_in=V,y.hold=E,y.bits=D,(y.wsize||rt!==x.avail_out&&y.mode<30&&(y.mode<27||q!==4))&&J(x,x.output,x.next_out,rt-x.avail_out)?(y.mode=31,-4):(ot-=x.avail_in,rt-=x.avail_out,x.total_in+=ot,x.total_out+=rt,y.total+=rt,y.wrap&&rt&&(x.adler=y.check=y.flags?o(y.check,et,rt,x.next_out-rt):l(y.check,et,rt,x.next_out-rt)),x.data_type=y.bits+(y.last?64:0)+(y.mode===12?128:0)+(y.mode===20||y.mode===15?256:0),(ot==0&&rt===0||q===4)&&z===p&&(z=-5),z)},s.inflateEnd=function(x){if(!x||!x.state)return f;var q=x.state;return q.window&&(q.window=null),x.state=null,p},s.inflateGetHeader=function(x,q){var y;return x&&x.state?(2&(y=x.state).wrap)==0?f:((y.head=q).done=!1,p):f},s.inflateSetDictionary=function(x,q){var y,U=q.length;return x&&x.state?(y=x.state).wrap!==0&&y.mode!==11?f:y.mode===11&&l(1,q,U,0)!==y.check?-3:J(x,q,U,U)?(y.mode=31,-4):(y.havedict=1,p):f},s.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(e,n,s){var r=e("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],o=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(d,h,p,f,w,m,k,v){var b,T,C,A,S,I,L,R,N,J=v.bits,x=0,q=0,y=0,U=0,et=0,j=0,it=0,V=0,Z=0,E=0,D=null,ot=0,rt=new r.Buf16(16),st=new r.Buf16(16),kt=null,$t=0;for(x=0;x<=15;x++)rt[x]=0;for(q=0;q<f;q++)rt[h[p+q]]++;for(et=J,U=15;1<=U&&rt[U]===0;U--);if(U<et&&(et=U),U===0)return w[m++]=20971520,w[m++]=20971520,v.bits=1,0;for(y=1;y<U&&rt[y]===0;y++);for(et<y&&(et=y),x=V=1;x<=15;x++)if(V<<=1,(V-=rt[x])<0)return-1;if(0<V&&(d===0||U!==1))return-1;for(st[1]=0,x=1;x<15;x++)st[x+1]=st[x]+rt[x];for(q=0;q<f;q++)h[p+q]!==0&&(k[st[h[p+q]]++]=q);if(I=d===0?(D=kt=k,19):d===1?(D=l,ot-=257,kt=o,$t-=257,256):(D=a,kt=c,-1),x=y,S=m,it=q=E=0,C=-1,A=(Z=1<<(j=et))-1,d===1&&852<Z||d===2&&592<Z)return 1;for(;;){for(L=x-it,N=k[q]<I?(R=0,k[q]):k[q]>I?(R=kt[$t+k[q]],D[ot+k[q]]):(R=96,0),b=1<<x-it,y=T=1<<j;w[S+(E>>it)+(T-=b)]=L<<24|R<<16|N|0,T!==0;);for(b=1<<x-1;E&b;)b>>=1;if(b!==0?(E&=b-1,E+=b):E=0,q++,--rt[x]==0){if(x===U)break;x=h[p+k[q]]}if(et<x&&(E&A)!==C){for(it===0&&(it=et),S+=y,V=1<<(j=x-it);j+it<U&&!((V-=rt[j+it])<=0);)j++,V<<=1;if(Z+=1<<j,d===1&&852<Z||d===2&&592<Z)return 1;w[C=E&A]=et<<24|j<<16|S-m|0}}return E!==0&&(w[S+E]=x-it<<24|64<<16|0),v.bits=et,0}},{"../utils/common":41}],51:[function(e,n,s){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(e,n,s){var r=e("../utils/common"),l=0,o=1;function a($){for(var B=$.length;0<=--B;)$[B]=0}var c=0,d=29,h=256,p=h+1+d,f=30,w=19,m=2*p+1,k=15,v=16,b=7,T=256,C=16,A=17,S=18,I=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],L=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],R=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],N=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],J=new Array(2*(p+2));a(J);var x=new Array(2*f);a(x);var q=new Array(512);a(q);var y=new Array(256);a(y);var U=new Array(d);a(U);var et,j,it,V=new Array(f);function Z($,B,W,F,H){this.static_tree=$,this.extra_bits=B,this.extra_base=W,this.elems=F,this.max_length=H,this.has_stree=$&&$.length}function E($,B){this.dyn_tree=$,this.max_code=0,this.stat_desc=B}function D($){return $<256?q[$]:q[256+($>>>7)]}function ot($,B){$.pending_buf[$.pending++]=255&B,$.pending_buf[$.pending++]=B>>>8&255}function rt($,B,W){$.bi_valid>v-W?($.bi_buf|=B<<$.bi_valid&65535,ot($,$.bi_buf),$.bi_buf=B>>v-$.bi_valid,$.bi_valid+=W-v):($.bi_buf|=B<<$.bi_valid&65535,$.bi_valid+=W)}function st($,B,W){rt($,W[2*B],W[2*B+1])}function kt($,B){for(var W=0;W|=1&$,$>>>=1,W<<=1,0<--B;);return W>>>1}function $t($,B,W){var F,H,G=new Array(k+1),tt=0;for(F=1;F<=k;F++)G[F]=tt=tt+W[F-1]<<1;for(H=0;H<=B;H++){var X=$[2*H+1];X!==0&&($[2*H]=kt(G[X]++,X))}}function yt($){var B;for(B=0;B<p;B++)$.dyn_ltree[2*B]=0;for(B=0;B<f;B++)$.dyn_dtree[2*B]=0;for(B=0;B<w;B++)$.bl_tree[2*B]=0;$.dyn_ltree[2*T]=1,$.opt_len=$.static_len=0,$.last_lit=$.matches=0}function Y($){8<$.bi_valid?ot($,$.bi_buf):0<$.bi_valid&&($.pending_buf[$.pending++]=$.bi_buf),$.bi_buf=0,$.bi_valid=0}function lt($,B,W,F){var H=2*B,G=2*W;return $[H]<$[G]||$[H]===$[G]&&F[B]<=F[W]}function dt($,B,W){for(var F=$.heap[W],H=W<<1;H<=$.heap_len&&(H<$.heap_len&&lt(B,$.heap[H+1],$.heap[H],$.depth)&&H++,!lt(B,F,$.heap[H],$.depth));)$.heap[W]=$.heap[H],W=H,H<<=1;$.heap[W]=F}function M($,B,W){var F,H,G,tt,X=0;if($.last_lit!==0)for(;F=$.pending_buf[$.d_buf+2*X]<<8|$.pending_buf[$.d_buf+2*X+1],H=$.pending_buf[$.l_buf+X],X++,F===0?st($,H,B):(st($,(G=y[H])+h+1,B),(tt=I[G])!==0&&rt($,H-=U[G],tt),st($,G=D(--F),W),(tt=L[G])!==0&&rt($,F-=V[G],tt)),X<$.last_lit;);st($,T,B)}function P($,B){var W,F,H,G=B.dyn_tree,tt=B.stat_desc.static_tree,X=B.stat_desc.has_stree,ct=B.stat_desc.elems,wt=-1;for($.heap_len=0,$.heap_max=m,W=0;W<ct;W++)G[2*W]!==0?($.heap[++$.heap_len]=wt=W,$.depth[W]=0):G[2*W+1]=0;for(;$.heap_len<2;)G[2*(H=$.heap[++$.heap_len]=wt<2?++wt:0)]=1,$.depth[H]=0,$.opt_len--,X&&($.static_len-=tt[2*H+1]);for(B.max_code=wt,W=$.heap_len>>1;1<=W;W--)dt($,G,W);for(H=ct;W=$.heap[1],$.heap[1]=$.heap[$.heap_len--],dt($,G,1),F=$.heap[1],$.heap[--$.heap_max]=W,$.heap[--$.heap_max]=F,G[2*H]=G[2*W]+G[2*F],$.depth[H]=($.depth[W]>=$.depth[F]?$.depth[W]:$.depth[F])+1,G[2*W+1]=G[2*F+1]=H,$.heap[1]=H++,dt($,G,1),2<=$.heap_len;);$.heap[--$.heap_max]=$.heap[1],(function(mt,Mt){var Vt,Yt,ee,Nt,Ke,te,Jt=Mt.dyn_tree,mi=Mt.max_code,Mi=Mt.stat_desc.static_tree,ms=Mt.stat_desc.has_stree,gs=Mt.stat_desc.extra_bits,$n=Mt.stat_desc.extra_base,gi=Mt.stat_desc.max_length,Bi=0;for(Nt=0;Nt<=k;Nt++)mt.bl_count[Nt]=0;for(Jt[2*mt.heap[mt.heap_max]+1]=0,Vt=mt.heap_max+1;Vt<m;Vt++)gi<(Nt=Jt[2*Jt[2*(Yt=mt.heap[Vt])+1]+1]+1)&&(Nt=gi,Bi++),Jt[2*Yt+1]=Nt,mi<Yt||(mt.bl_count[Nt]++,Ke=0,$n<=Yt&&(Ke=gs[Yt-$n]),te=Jt[2*Yt],mt.opt_len+=te*(Nt+Ke),ms&&(mt.static_len+=te*(Mi[2*Yt+1]+Ke)));if(Bi!==0){do{for(Nt=gi-1;mt.bl_count[Nt]===0;)Nt--;mt.bl_count[Nt]--,mt.bl_count[Nt+1]+=2,mt.bl_count[gi]--,Bi-=2}while(0<Bi);for(Nt=gi;Nt!==0;Nt--)for(Yt=mt.bl_count[Nt];Yt!==0;)mi<(ee=mt.heap[--Vt])||(Jt[2*ee+1]!==Nt&&(mt.opt_len+=(Nt-Jt[2*ee+1])*Jt[2*ee],Jt[2*ee+1]=Nt),Yt--)}})($,B),$t(G,wt,$.bl_count)}function u($,B,W){var F,H,G=-1,tt=B[1],X=0,ct=7,wt=4;for(tt===0&&(ct=138,wt=3),B[2*(W+1)+1]=65535,F=0;F<=W;F++)H=tt,tt=B[2*(F+1)+1],++X<ct&&H===tt||(X<wt?$.bl_tree[2*H]+=X:H!==0?(H!==G&&$.bl_tree[2*H]++,$.bl_tree[2*C]++):X<=10?$.bl_tree[2*A]++:$.bl_tree[2*S]++,G=H,wt=(X=0)===tt?(ct=138,3):H===tt?(ct=6,3):(ct=7,4))}function z($,B,W){var F,H,G=-1,tt=B[1],X=0,ct=7,wt=4;for(tt===0&&(ct=138,wt=3),F=0;F<=W;F++)if(H=tt,tt=B[2*(F+1)+1],!(++X<ct&&H===tt)){if(X<wt)for(;st($,H,$.bl_tree),--X!=0;);else H!==0?(H!==G&&(st($,H,$.bl_tree),X--),st($,C,$.bl_tree),rt($,X-3,2)):X<=10?(st($,A,$.bl_tree),rt($,X-3,3)):(st($,S,$.bl_tree),rt($,X-11,7));G=H,wt=(X=0)===tt?(ct=138,3):H===tt?(ct=6,3):(ct=7,4)}}a(V);var O=!1;function _($,B,W,F){rt($,(c<<1)+(F?1:0),3),(function(H,G,tt,X){Y(H),ot(H,tt),ot(H,~tt),r.arraySet(H.pending_buf,H.window,G,tt,H.pending),H.pending+=tt})($,B,W)}s._tr_init=function($){O||((function(){var B,W,F,H,G,tt=new Array(k+1);for(H=F=0;H<d-1;H++)for(U[H]=F,B=0;B<1<<I[H];B++)y[F++]=H;for(y[F-1]=H,H=G=0;H<16;H++)for(V[H]=G,B=0;B<1<<L[H];B++)q[G++]=H;for(G>>=7;H<f;H++)for(V[H]=G<<7,B=0;B<1<<L[H]-7;B++)q[256+G++]=H;for(W=0;W<=k;W++)tt[W]=0;for(B=0;B<=143;)J[2*B+1]=8,B++,tt[8]++;for(;B<=255;)J[2*B+1]=9,B++,tt[9]++;for(;B<=279;)J[2*B+1]=7,B++,tt[7]++;for(;B<=287;)J[2*B+1]=8,B++,tt[8]++;for($t(J,p+1,tt),B=0;B<f;B++)x[2*B+1]=5,x[2*B]=kt(B,5);et=new Z(J,I,h+1,p,k),j=new Z(x,L,0,f,k),it=new Z(new Array(0),R,0,w,b)})(),O=!0),$.l_desc=new E($.dyn_ltree,et),$.d_desc=new E($.dyn_dtree,j),$.bl_desc=new E($.bl_tree,it),$.bi_buf=0,$.bi_valid=0,yt($)},s._tr_stored_block=_,s._tr_flush_block=function($,B,W,F){var H,G,tt=0;0<$.level?($.strm.data_type===2&&($.strm.data_type=(function(X){var ct,wt=4093624447;for(ct=0;ct<=31;ct++,wt>>>=1)if(1&wt&&X.dyn_ltree[2*ct]!==0)return l;if(X.dyn_ltree[18]!==0||X.dyn_ltree[20]!==0||X.dyn_ltree[26]!==0)return o;for(ct=32;ct<h;ct++)if(X.dyn_ltree[2*ct]!==0)return o;return l})($)),P($,$.l_desc),P($,$.d_desc),tt=(function(X){var ct;for(u(X,X.dyn_ltree,X.l_desc.max_code),u(X,X.dyn_dtree,X.d_desc.max_code),P(X,X.bl_desc),ct=w-1;3<=ct&&X.bl_tree[2*N[ct]+1]===0;ct--);return X.opt_len+=3*(ct+1)+5+5+4,ct})($),H=$.opt_len+3+7>>>3,(G=$.static_len+3+7>>>3)<=H&&(H=G)):H=G=W+5,W+4<=H&&B!==-1?_($,B,W,F):$.strategy===4||G===H?(rt($,2+(F?1:0),3),M($,J,x)):(rt($,4+(F?1:0),3),(function(X,ct,wt,mt){var Mt;for(rt(X,ct-257,5),rt(X,wt-1,5),rt(X,mt-4,4),Mt=0;Mt<mt;Mt++)rt(X,X.bl_tree[2*N[Mt]+1],3);z(X,X.dyn_ltree,ct-1),z(X,X.dyn_dtree,wt-1)})($,$.l_desc.max_code+1,$.d_desc.max_code+1,tt+1),M($,$.dyn_ltree,$.dyn_dtree)),yt($),F&&Y($)},s._tr_tally=function($,B,W){return $.pending_buf[$.d_buf+2*$.last_lit]=B>>>8&255,$.pending_buf[$.d_buf+2*$.last_lit+1]=255&B,$.pending_buf[$.l_buf+$.last_lit]=255&W,$.last_lit++,B===0?$.dyn_ltree[2*W]++:($.matches++,B--,$.dyn_ltree[2*(y[W]+h+1)]++,$.dyn_dtree[2*D(B)]++),$.last_lit===$.lit_bufsize-1},s._tr_align=function($){rt($,2,3),st($,T,J),(function(B){B.bi_valid===16?(ot(B,B.bi_buf),B.bi_buf=0,B.bi_valid=0):8<=B.bi_valid&&(B.pending_buf[B.pending++]=255&B.bi_buf,B.bi_buf>>=8,B.bi_valid-=8)})($)}},{"../utils/common":41}],53:[function(e,n,s){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(e,n,s){(function(r){(function(l,o){if(!l.setImmediate){var a,c,d,h,p=1,f={},w=!1,m=l.document,k=Object.getPrototypeOf&&Object.getPrototypeOf(l);k=k&&k.setTimeout?k:l,a={}.toString.call(l.process)==="[object process]"?function(C){process.nextTick(function(){b(C)})}:(function(){if(l.postMessage&&!l.importScripts){var C=!0,A=l.onmessage;return l.onmessage=function(){C=!1},l.postMessage("","*"),l.onmessage=A,C}})()?(h="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",T,!1):l.attachEvent("onmessage",T),function(C){l.postMessage(h+C,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(C){b(C.data)},function(C){d.port2.postMessage(C)}):m&&"onreadystatechange"in m.createElement("script")?(c=m.documentElement,function(C){var A=m.createElement("script");A.onreadystatechange=function(){b(C),A.onreadystatechange=null,c.removeChild(A),A=null},c.appendChild(A)}):function(C){setTimeout(b,0,C)},k.setImmediate=function(C){typeof C!="function"&&(C=new Function(""+C));for(var A=new Array(arguments.length-1),S=0;S<A.length;S++)A[S]=arguments[S+1];var I={callback:C,args:A};return f[p]=I,a(p),p++},k.clearImmediate=v}function v(C){delete f[C]}function b(C){if(w)setTimeout(b,0,C);else{var A=f[C];if(A){w=!0;try{(function(S){var I=S.callback,L=S.args;switch(L.length){case 0:I();break;case 1:I(L[0]);break;case 2:I(L[0],L[1]);break;case 3:I(L[0],L[1],L[2]);break;default:I.apply(o,L)}})(A)}finally{v(C),w=!1}}}}function T(C){C.source===l&&typeof C.data=="string"&&C.data.indexOf(h)===0&&b(+C.data.slice(h.length))}})(typeof self>"u"?r===void 0?this:r:self)}).call(this,typeof Rn<"u"?Rn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Ms)),Ms.exports}var Eg=Tg();const Mg=Ag(Eg),Bg=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,Dg=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function Og(t){const i=await Mg.loadAsync(t),e={},n=[];let s="",r="";const l=[];i.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let o=l.find(a=>a.path.toLowerCase()==="slides.md");o||(o=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),o||(o=l.find(a=>a.path.toLowerCase().endsWith(".md"))),o&&(s=await o.file.async("string"),r=o.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||Dg.test(c)||c.includes("snippets/")){const d=await a.file.async("string");e[c]=d;const h=c.split("/");h.length>1&&(e[h.slice(1).join("/")]=d)}else if(Bg.test(c)){const d=await a.file.async("uint8array"),h=c.split("/").pop()||c,p=typeof Blob<"u"?new Blob([d]):void 0;n.push({zipPath:c,fileName:h,data:d,blob:p})}}return{entryMarkdown:s,entryMarkdownPath:r,virtualFiles:e,assets:n}}function Pg(t,i){if(Object.keys(i).length===0)return t;function e(s){const r=s.trim().replace(/^['"]|['"]$/g,""),l=r.split("/").pop()||r;if(i[r])return i[r];const o=r.replace(/^\.?\//,"");return i[o]?i[o]:i[l]?i[l]:null}function n(s){let r=s;return r=r.replace(/!\[(.*?)\]\((.*?)\)/g,(l,o,a)=>{const c=e(a);return c?`![${o}](${c})`:l}),r=r.replace(/\bsrc=["'](.*?)["']/gi,(l,o)=>{const a=e(o);return a?`src="${a}"`:l}),r}for(const s of t.slides)if(s.rawMarkdown=n(s.rawMarkdown),s.pageAttrs["custom-slidev-background"]){const r=s.pageAttrs["custom-slidev-background"],l=e(r);l&&(s.pageAttrs["custom-slidev-background"]=l)}if(t.flattenedMarkdown=n(t.flattenedMarkdown),t.docRootAttrs["custom-slidev-background"]){const s=t.docRootAttrs["custom-slidev-background"],r=e(s);r&&(t.docRootAttrs["custom-slidev-background"]=r)}return t}function yi(t,i,e){let n="",s=0;const r=/<div\b([^>]*)>/gi;for(;s<t.length;){r.lastIndex=s;let l,o=!1,a=-1,c=0;for(;(l=r.exec(t))!==null;){const v=l[1].match(/\bclass=["']([^"']*)["']/i);if(v){const b=v[1];if(typeof i=="string"?b.split(/\s+/).includes(i):i.test(b)){o=!0,a=l.index,c=l[0].length;break}}}if(!o){n+=t.slice(s);break}n+=t.slice(s,a);const d=a+c;let h=1,p=-1,f=-1;const w=/<\/?div\b[^>]*>/gi;w.lastIndex=d;let m;for(;(m=w.exec(t))!==null;)if(m[0].startsWith("</")){if(h--,h===0){p=m.index,f=m.index+m[0].length;break}}else h++;if(p!==-1&&f!==-1){const k=t.slice(d,p);n+=e(k),s=f}else n+=t.slice(a,d),s=d}return n}function Lg(t){const i=[];let e="",n=0;const s=/<div\b([^>]*)>/gi;for(;n<t.length;){s.lastIndex=n;let r,l=!1,o=-1,a=0;for(;(r=s.exec(t))!==null;){const m=r[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(m)){l=!0,o=r.index,a=r[0].length;break}}if(!l){e+=t.slice(n);break}e+=t.slice(n,o);const c=o+a;let d=1,h=-1,p=-1;const f=/<\/?div\b[^>]*>/gi;f.lastIndex=c;let w;for(;(w=f.exec(t))!==null;)if(w[0].startsWith("</")){if(d--,d===0){h=w.index,p=w.index+w[0].length;break}}else d++;if(h!==-1&&p!==-1){const m=t.slice(o,p),k=`__VUE_DIV_TOKEN_${i.length}__`;i.push(m),e+=k,n=p}else e+=t.slice(o,c),n=c}return{text:e,tokens:i}}function Rg(t){const i=[];let e=t.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,o=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(o),a});e=e.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,o=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(o),a});const n=[];e=e.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,o=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(o),a});const{text:s,tokens:r}=Lg(e);e=s;const l=[];e=e.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),e=e.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),e=e.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),e=e.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),e=e.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),e=e.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),e=e.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),e=e.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(o,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),e=e.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(o,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),e=e.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(o,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),e=e.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(o,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=yi(e,"diff-grid",o=>{const a=Array.from(o.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),h=c[3].trim();return`**${d}:**
\`\`\`yaml
${h}
\`\`\``}).join(`

`)+`
`:o}),e=yi(e,"before-after",o=>{const a=o.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=o.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:o}),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(o,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),e=yi(e,"timeline",o=>{const a=Array.from(o.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let h="-";return d.includes("warn")?h="- ⚠️":d.includes("bad")?h="- ❌":d.includes("ok")&&(h="- ✅"),`${h} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:o}),e=yi(e,"pipeline",o=>{const a=Array.from(o.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const p=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${p}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:o}),e=yi(e,"check-grid",o=>{const a=Array.from(o.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:o}),e=yi(e,"manifesto",o=>{const a=Array.from(o.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:o}),e=yi(e,"split-note",o=>{const a=Array.from(o.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:o}),e=e.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(o,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),e=e.replace(/<pre>([\s\S]*?)<\/pre>/gi,(o,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=e.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),e=e.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),e=e.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),e=e.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),e=e.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),e=e.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),e=e.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),e=e.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),e=e.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(o,a,c)=>/@|v-|:|class=/i.test(a)?o:`
${c.trim()}

`),e=e.replace(/<br\s*\/?>/gi,`
`),e=e.replace(/<hr\s*\/?>/gi,`
---
`),e=e.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),e=e.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),e=e.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),e=e.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(o,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((h,p)=>Math.max(h,p.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),e=e.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),e=e.replace(/\*{4}/g,"** **"),e=e.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),e=e.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),e=e.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(o,a,c,d,h)=>{const p=h.trim();return p.includes("<")||p.includes(`
`)?o:`[${p}](${c})`}),e=e.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(o,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),e=e.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(o,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),e=e.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(o,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),e=e.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),e=e.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),e=e.replace(/<\/?span\b[^>]*>/gi,"");for(let o=0;o<l.length;o++)e=e.replace(`__VUE_COMP_TOKEN_${o}__`,l[o]);for(let o=0;o<r.length;o++)e=e.replace(`__VUE_DIV_TOKEN_${o}__`,r[o]);for(let o=0;o<n.length;o++)e=e.replace(`__SCRIPT_TOKEN_${o}__`,n[o]);for(let o=0;o<i.length;o++)e=e.replace(`__CODE_TOKEN_${o}__`,i[o]);return e=e.replace(/\n{3,}/g,`

`).trim(),e}function Kl(t){try{if(typeof process<"u"&&typeof require<"u"){const i=require("fs");if(i.existsSync(t))return i.readFileSync(t,"utf-8")}}catch{}return null}function zg(t,i){const e=t.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!e)return null;const n=e[1].trim(),s=n.indexOf("#"),r=s!==-1?n.slice(0,s):n,l=s!==-1?n.slice(s+1):"",o=r.replace(/^@\//,"").replace(/^\.\//,""),a=(i==null?void 0:i.virtualFiles)||{};let c=a[r]||a[o]||a[`./${o}`]||a[`@/${o}`];if(!c&&Object.keys(a).length>0){const f=o.split("/").pop();for(const[w,m]of Object.entries(a))if(w.endsWith(`/${o}`)||f&&w.endsWith(`/${f}`)){c=m;break}}if(!c){const f=[];if(i!=null&&i.baseDir)try{const w=require("path");f.push(w.resolve(i.baseDir,o)),f.push(w.resolve(i.baseDir,r))}catch{}try{const w=require("path");f.push(w.resolve(process.cwd(),o))}catch{}for(const w of f){const m=Kl(w);if(m!==null){c=m;break}}}if(!c){const f=Fl||{};if(c=f[r]||f[o]||f[`snippets/${o}`],!c){const w=o.split("/").pop();for(const[m,k]of Object.entries(f))if(m.endsWith(`/${o}`)||w&&m.endsWith(`/${w}`)){c=k;break}}}if(!c)return null;let d=c;if(l){const f=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),w=c.match(f);if(w){const m=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(m?m[1]:"")+w[1].trimEnd()}}const h=o.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${h?h[1]:""}
${d}
\`\`\``}function Ng(t){let i=!1,e=!1;for(let n=0;n<t.length;n++){const s=t[n];if(s==="'"&&!e)i=!i;else if(s==='"'&&!i)e=!e;else if(s==="#"&&!i&&!e)return t.slice(0,n).trim()}return t.trim()}function Un(t){const i={},e=t.split(/\r?\n/);let n=0;for(;n<e.length;){const s=e[n],r=s.trim();if(!r||r.startsWith("#")){n++;continue}const l=s.indexOf(":");if(l>0){const o=s.slice(0,l).trim();let a=s.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let d=-1;for(;n<e.length;){const h=e[n];if(!h.trim()){c.push(""),n++;continue}const f=h.match(/^(\s+)/),w=f?f[1].length:0;if(d===-1&&(d=w),w<d)break;c.push(h.slice(d)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();i[o]=a===">"?c.join(" "):c.join(`
`);continue}if(a=Ng(a),!a){let c=n+1;const d=[];let h=-1;for(;c<e.length;){const p=e[c],f=p.trim();if(!f||f.startsWith("#")){h!==-1&&d.push(""),c++;continue}const w=p.match(/^(\s+)/),m=w?w[1].length:0;if(h===-1)if(m>0)h=m;else break;if(m<h)break;d.push(p.slice(h)),c++}if(d.length>0){i[o]=Un(d.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),i[o]=a}n++}return i}const Fg=/^\s*```ya?ml([\s\S]*?)```/;function vr(t){let i={},e=t.trim();const n=e.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const r=Un(n[1]);if(Object.keys(r).length>0||!n[1].trim())return i=r,e=e.slice(n[0].length).trim(),{frontmatter:i,content:e}}if(e.startsWith("---")){const r=e.match(/^---[^\n\r]*(?:\r?\n|$)/);r&&(e=e.slice(r[0].length).trim())}const s=e.match(Fg);if(s)i=Un(s[1]),e=e.slice(s[0].length).trim();else{const r=e.split(/\r?\n/),l=[];let o=0;for(let a=0;a<r.length;a++){const c=r[a].trim();if(!c){if(l.length>0){o=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{o=a;break}}l.length>0&&(i=Un(l.join(`
`)),e=r.slice(o).join(`
`).trim())}return{frontmatter:i,content:e}}function jg(t){const i=t.split(/\r?\n/),e=[];let n=0,s=!1;function r(l){if(n>=l)return;const o=i.slice(n,l).join(`
`).trim();o&&e.push(o),n=l+1}for(let l=0;l<i.length;l++){const a=i[l].trimEnd();if(s){a.includes("-->")&&(s=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(s=!0);continue}if(a.startsWith("---")){r(l);const c=i[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<i.length&&i[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let h=l+1;for(;h<i.length&&!i[h].trimStart().startsWith(d);h++);h<i.length&&(l=h)}}return n<i.length&&r(i.length),e}function Wn(t,i={}){const{stripNotesFromMarkdown:e=!0,cleanVClicks:n=!0,cleanShikiLines:s=!0,cleanSlots:r=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:o=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=i;let d=t;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const h=jg(d),p={};let f="",w="",m=0;if(h.length>0){const N=h[0],J=vr(N),x=Object.keys(J.frontmatter).length>0,q=J.content.length>0;x&&!q&&h.length>1?(m=1,k(J.frontmatter)):x&&k(J.frontmatter)}function k(N){f=N.title||"",N.theme&&(p[sn]=String(N.theme)),N.aspectRatio&&(p[on]=String(N.aspectRatio)),N.highlighter&&(p[xr]=String(N.highlighter)),N.transition&&(p[rn]=String(N.transition)),N.colorSchema&&(p[_r]=String(N.colorSchema)),N.layout&&(p[ut]=String(N.layout)),N.background&&(p[Ut]=String(N.background)),N.image&&(p[Ae]=String(N.image)),N.class&&(p[Ri]=String(N.class));for(const[J,x]of Object.entries(N))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(J)||(p[`custom-slidev-${J}`]=typeof x=="object"?JSON.stringify(x):String(x))}const v=[];let b=0,T=0,C=0,A=0;const S=new Set,I={};let L=1;for(let N=m;N<h.length;N++){const J=h[N],{frontmatter:x,content:q}=vr(J),y=J.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),U=x.src||(y?y[1]:void 0);if(U){const Y=String(U).trim().replace(/^['"]|['"]$/g,"");let lt=c[Y]||c[Y.replace(/^\.\//,"")]||c[`pages/${Y.replace(/^.*pages\//,"")}`];if(!lt){const M=Y.replace(/^\.\//,""),P=[];if(i.baseDir)try{const u=require("path");P.push(u.resolve(i.baseDir,M)),P.push(u.resolve(i.baseDir,Y))}catch{}try{const u=require("path");P.push(u.resolve(process.cwd(),M)),P.push(u.resolve(process.cwd(),Y))}catch{}for(const u of P){const z=Kl(u);if(z!==null){lt=z;break}}}const dt={};x.layout&&(dt[ut]=String(x.layout)),x.transition&&(dt[Xt]=String(x.transition)),x.background&&(dt[Ut]=String(x.background)),x.image&&(dt[Ae]=String(x.image)),x.class&&(dt[Ri]=String(x.class));for(const[M,P]of Object.entries(x))["src","layout","transition","background","image","class"].includes(M)||(dt[`custom-slidev-${M}`]=typeof P=="object"?JSON.stringify(P):String(P));if(lt){const M=Wn(lt,{...i,virtualFiles:c});for(const P of M.slides){P.pageIndex=L++,P.pageAttrs={...dt,...P.pageAttrs},v.push(P);const u=P.pageAttrs[ut]||"default";I[u]=(I[u]||0)+1}continue}else{v.push({pageIndex:L++,pageAttrs:{...dt,"custom-slidev-src":Y},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${Y}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const M=dt[ut]||"default";I[M]=(I[M]||0)+1;continue}}const et={};x.layout&&(et[ut]=String(x.layout)),x.transition&&(et[Xt]=String(x.transition)),x.background&&(et[Ut]=String(x.background)),x.image&&(et[Ae]=String(x.image)),x.class&&(et[Ri]=String(x.class));for(const[Y,lt]of Object.entries(x))["layout","transition","background","image","class"].includes(Y)||(et[`custom-slidev-${Y}`]=typeof lt=="object"?JSON.stringify(lt):String(lt));let j=q;const it=[];let V=j.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,Y=>{const lt=`__CODE_TOKEN_NOTE_${it.length}__`;return it.push(Y),lt});V=V.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,Y=>{const lt=`__CODE_TOKEN_NOTE_${it.length}__`;return it.push(Y),lt});let Z="";const E=Array.from(V.matchAll(/<!--([\s\S]*?)-->/g));if(E.length>0){const Y=E[E.length-1],lt=V.slice(Y.index+Y[0].length).trim();if(!lt||!lt.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const M=Y[1].trim();M.startsWith("TODO:")||(Z=M,b++),e&&(V=V.slice(0,Y.index).trimEnd()+V.slice(Y.index+Y[0].length))}}e&&(V=V.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let Y=0;Y<it.length;Y++)V=V.replace(`__CODE_TOKEN_NOTE_${Y}__`,it[Y]);if(j=V,Z){for(let dt=0;dt<it.length;dt++)Z=Z.replace(`__CODE_TOKEN_NOTE_${dt}__`,it[dt]);const lt=`> [!NOTE] 💡 演讲备注
${Z.split(/\r?\n/).map(dt=>`> ${dt}`).join(`
`)}
{: custom-slidev-note="true"}`;j=j?`${j}

${lt}`:lt}let D=!1;if(/<style\b/i.test(j)){D=!0;const Y=j.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(Y){for(const lt of Y){const dt=lt.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();w=w?`${w}

${dt}`:dt}l&&(j=j.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const ot=j.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);ot&&(T+=ot.length);const rt=j.match(/```\w+\s+\{[^}]+\}/g);rt&&(C+=rt.length);const st=j.match(/::\w+::|<template\s+#[^>]+>/g);if(st&&(A+=st.length),j=j.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,Y=>zg(Y,{...i,virtualFiles:c})||Y),n&&(j=j.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),s&&(j=j.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),j=j.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),r&&(j=j.replace(/^::\w+::\s*$/gm,"")),o&&(j=Rg(j)),a){let Y=j.trim(),lt="";const dt=Y.lastIndexOf("> [!NOTE] 💡 演讲备注");if(dt!==-1&&(lt=Y.slice(dt),Y=Y.slice(0,dt).trim()),(x.layout==="image-left"||x.layout==="image-right")&&x.image){const M=String(x.image).trim(),P=x.layout==="image-left"?"image-left":"image-right",u=`![配图](${M})
{: custom-slidev-layout="${P}" }`;x.layout==="image-left"?Y=`{{{col

${u}

${Y}

}}}`:Y=`{{{col

${Y}

${u}

}}}`}if(x.background){const P=`![背景图](${String(x.background).trim()})
{: custom-slidev-role="background" }`;Y=Y?`${P}

${Y}`:P}j=lt?`${Y}

${lt}`:Y}const kt=Hg(j);et[Ut]&&kt.push(et[Ut]),et[Ae]&&kt.push(et[Ae]);for(const Y of kt)S.add(Y);const $t=/<[A-Z][a-zA-Z0-9]+/.test(j),yt=et[ut]||(L===1?p[ut]||"cover":"default");I[yt]=(I[yt]||0)+1,v.push({pageIndex:L++,pageAttrs:et,notes:Z,rawMarkdown:j,hasVueComponent:$t,hasStyleTag:D,assetReferences:kt})}if(!f&&v.length>0){const N=v[0].rawMarkdown.match(/^#\s+(.+)$/m);N&&(f=N[1].trim())}w&&(p["custom-slidev-custom-css"]=w);let R=v.map(N=>`---

${N.rawMarkdown}`).join(`

`);return R.trimStart().startsWith("---")||(R=`---

${R.trimStart()}`),{docTitle:f||"Slidev 演示文稿",docRootAttrs:p,slides:v,totalSlides:v.length,stats:{totalNotes:b,totalVClicks:T,totalShikiHighlights:C,totalSlots:A,discoveredAssets:Array.from(S),layoutDistribution:I},flattenedMarkdown:R,customCss:w}}function Hg(t){const i=[],e=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=e.exec(t))!==null;){const r=n[1].split(/\s+/)[0].trim();r&&i.push(r)}const s=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=s.exec(t))!==null;){const r=n[1].trim();r&&i.push(r)}return i}const Ug={class:"spm-import-dialog"},Wg={class:"spm-tabs-header"},Vg={class:"spm-dialog-body"},Kg={key:0,class:"spm-file-section"},qg={key:0,class:"spm-dropzone-prompt"},Gg={key:1,class:"spm-dropzone-active"},Zg={class:"spm-file-badge"},Yg={class:"spm-file-size"},Jg={key:1,class:"spm-text-section"},Xg={key:2,class:"spm-error-banner"},Qg={key:3,class:"spm-preview-card"},tv={class:"spm-config-grid"},ev={class:"spm-form-item"},iv={class:"spm-form-item"},nv=["value"],sv={class:"spm-stats-grid"},ov={class:"spm-stat-box"},rv={class:"spm-stat-value"},lv={class:"spm-stat-box"},av={class:"spm-stat-value"},cv={class:"spm-stat-box"},dv={class:"spm-stat-value"},uv={class:"spm-stat-box"},fv={class:"spm-stat-value"},pv={key:0,class:"spm-chips-row"},hv={class:"spm-options-group"},mv={class:"spm-checkbox-label"},gv={class:"spm-checkbox-label"},vv={class:"spm-checkbox-label"},bv={class:"spm-checkbox-label"},yv={class:"spm-dialog-footer"},wv=["disabled"],kv=["disabled"],xv={key:0},_v={key:1},Sv=be({__name:"SlidevImportDialog",emits:["close","success"],setup(t,{emit:i}){const e=i,n=Qe("plugin"),s=pt("file"),r=pt(!1),l=pt(!1),o=pt(""),a=pt(null),c=pt(null),d=pt(""),h=pt(0),p=pt(""),f=pt([]),w=pt(null),m=pt(""),k=pt([]),v=pt(""),b=pt(!0),T=pt(!0),C=pt(!0),A=pt(!0);async function S(){c.value?await U(c.value):p.value&&et()}const I=Ct(()=>{const V=h.value;if(V===0)return"0 B";const Z=1024,E=["B","KB","MB","GB"],D=Math.floor(Math.log(V)/Math.log(Z));return`${(V/Z**D).toFixed(1)} ${E[D]}`}),L=Ct(()=>{var V;return((V=w.value)==null?void 0:V.docRootAttrs["custom-slidev-theme"])||"default"}),R=Ct(()=>{var V;return f.value.length>0?f.value.length:((V=w.value)==null?void 0:V.stats.discoveredAssets.length)||0}),N=Ct(()=>{var Z;const V=((Z=w.value)==null?void 0:Z.stats.layoutDistribution)||{};return Object.entries(V).map(([E,D])=>({name:E,count:D}))});_n(async()=>{try{const V=await ca();V!=null&&V.notebooks&&Array.isArray(V.notebooks)&&(k.value=V.notebooks.filter(Z=>!Z.closed),k.value.length>0&&(v.value=k.value[0].id))}catch(V){console.warn("获取笔记本列表失败:",V)}});function J(){var V;(V=a.value)==null||V.click()}function x(){c.value=null,d.value="",h.value=0,w.value=null,f.value=[],o.value=""}async function q(V){const Z=V.target;Z.files&&Z.files[0]&&await U(Z.files[0])}async function y(V){var Z;r.value=!1,(Z=V.dataTransfer)!=null&&Z.files&&V.dataTransfer.files[0]&&await U(V.dataTransfer.files[0])}async function U(V){o.value="",c.value=V,d.value=V.name,h.value=V.size;try{if(V.name.toLowerCase().endsWith(".zip")){const E=await V.arrayBuffer(),D=await Og(E);if(!D.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}f.value=D.assets;const ot=Wn(D.entryMarkdown,{stripNotesFromMarkdown:T.value,cleanHtmlToMarkdown:b.value,cleanSlots:!1,virtualFiles:D.virtualFiles});w.value=ot,m.value=ot.docTitle||V.name.replace(/\.zip$/i,"")}else{const E=await V.text();f.value=[];const D=V.path||"",ot=D?D.replace(/[\\/][^\\/]+$/,""):"",rt=Wn(E,{stripNotesFromMarkdown:T.value,cleanHtmlToMarkdown:b.value,cleanSlots:!1,baseDir:ot||void 0});w.value=rt,m.value=rt.docTitle||V.name.replace(/\.md$/i,"")}}catch(Z){console.error("解析文件失败:",Z),o.value=`解析文件失败: ${Z.message||String(Z)}`}}function et(){if(o.value="",!p.value.trim()){w.value=null;return}try{const V=Wn(p.value,{stripNotesFromMarkdown:T.value,cleanHtmlToMarkdown:b.value,cleanSlots:!1});w.value=V,m.value=V.docTitle||"Slidev 演示文稿"}catch(V){o.value=`解析 Markdown 源码失败: ${V.message||String(V)}`}}async function j(){var V;if(w.value){if(!v.value&&k.value.length>0&&(v.value=k.value[0].id),!v.value){o.value="请先选择目标笔记本";return}l.value=!0,o.value="";try{const Z=w.value,E={};if(C.value&&f.value.length>0){const lt=[];for(const dt of f.value){const M=new File([dt.data],dt.fileName,{type:"application/octet-stream"});lt.push(M)}try{const dt=await ua("/data/assets",lt);if(dt!=null&&dt.succMap)for(const[M,P]of Object.entries(dt.succMap))E[M]=String(P)}catch(dt){console.warn("上传本地静态资产失败，保留原路径:",dt)}}Object.keys(E).length>0&&Pg(Z,E);const D=(m.value.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_"),ot=`/${D}`,rt=await da(v.value,ot,Z.flattenedMarkdown);if(!rt)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const st=((V=Z.slides[0])==null?void 0:V.pageAttrs)||{};await zt(rt,{...st,...Z.docRootAttrs});const kt=await Vn(rt).catch(()=>[]),$t=lt=>{if(!lt)return!1;const dt=String(lt.type||"").toLowerCase(),M=String(lt.markdown||"").trim(),P=String(lt.content||"").trim();return dt==="tb"||dt==="thematic-break"||dt==="nodethematicbreak"||M==="---"||M==="***"||P==="---"||P==="***"},yt=kt.filter($t);if(yt.length>=Z.slides.length)for(let lt=0;lt<Z.slides.length;lt++){const dt=Z.slides[lt],M=yt[lt];M&&M.id&&Object.keys(dt.pageAttrs).length>0&&await zt(M.id,dt.pageAttrs)}else for(let lt=1;lt<Z.slides.length;lt++){const dt=Z.slides[lt],M=yt[lt-1];M&&M.id&&Object.keys(dt.pageAttrs).length>0&&await zt(M.id,dt.pageAttrs)}let Y=!1;for(const lt of kt){if($t(lt)){Y=!1;continue}const dt=(lt.markdown||lt.content||"").trim();if(dt==="::right::"||dt.startsWith("::right::")){Y=!0;continue}Y&&lt.id&&await zt(lt.id,{[Tt]:"right"}).catch(()=>{})}ht.showMessage(`🎉 成功导入 Slidev 演示文档《${D}》！`),e("success",{docId:rt}),e("close"),A.value&&n&&(n.currentDocId=rt,await ht.openTab({app:n.app,doc:{id:rt}}),n.openBottomPreviewTab&&n.openBottomPreviewTab())}catch(Z){console.error("导入 Slidev 演示失败:",Z),o.value=`导入执行失败: ${Z.message||String(Z)}`}finally{l.value=!1}}}function it(){e("close")}return(V,Z)=>(Q(),nt("div",{class:"spm-modal-overlay",onClick:Te(it,["self"])},[g("div",Ug,[g("div",{class:"spm-dialog-header"},[Z[11]||(Z[11]=g("div",{class:"spm-dialog-title"},[g("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[g("use",{"xlink:href":"#iconSlidev"})]),g("span",null,"导入 Slidev 演示文档")],-1)),g("button",{class:"spm-close-btn",title:"关闭",onClick:it},"✕")]),g("div",Wg,[g("button",{class:Et(["spm-tab-btn",{active:s.value==="file"}]),onClick:Z[0]||(Z[0]=E=>s.value="file")}," 📦 文件 / 压缩包导入 (.zip / .md) ",2),g("button",{class:Et(["spm-tab-btn",{active:s.value==="text"}]),onClick:Z[1]||(Z[1]=E=>s.value="text")}," 📝 粘贴 Markdown 源码 ",2)]),g("div",Vg,[s.value==="file"?(Q(),nt("div",Kg,[g("div",{class:Et(["spm-dropzone",{dragover:r.value,"has-file":!!d.value}]),onDragover:Z[2]||(Z[2]=Te(E=>r.value=!0,["prevent"])),onDragleave:Z[3]||(Z[3]=Te(E=>r.value=!1,["prevent"])),onDrop:Te(y,["prevent"]),onClick:J},[g("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:q},null,544),d.value?(Q(),nt("div",Gg,[g("span",Zg,"📄 "+_t(d.value),1),g("span",Yg,"("+_t(I.value)+")",1),g("button",{class:"spm-btn-text",onClick:Te(x,["stop"])},"更换文件")])):(Q(),nt("div",qg,[...Z[12]||(Z[12]=[g("span",{class:"spm-dropzone-icon"},"📁",-1),g("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1),g("p",{class:"spm-dropzone-hint"},[Gs(" 支持 Slidev 完整工程 "),g("strong",null,".zip"),Gs("（自动解包 public/ 静态素材）或单文件 "),g("strong",null,".md")],-1)])]))],34)])):(Q(),nt("div",Jg,[Ie(g("textarea",{"onUpdate:modelValue":Z[4]||(Z[4]=E=>p.value=E),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:et},null,544),[[es,p.value]])])),o.value?(Q(),nt("div",Xg," ⚠️ "+_t(o.value),1)):Ft("",!0),w.value?(Q(),nt("div",Qg,[Z[24]||(Z[24]=g("div",{class:"spm-preview-card__header"},[g("span",null,"✨ 演示解析摘要"),g("span",{class:"spm-badge-success"},"预检就绪")],-1)),g("div",tv,[g("div",ev,[Z[13]||(Z[13]=g("label",{class:"spm-form-label"},"笔记文档标题",-1)),Ie(g("input",{"onUpdate:modelValue":Z[5]||(Z[5]=E=>m.value=E),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[es,m.value]])]),g("div",iv,[Z[14]||(Z[14]=g("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Ie(g("select",{"onUpdate:modelValue":Z[6]||(Z[6]=E=>v.value=E),class:"spm-select"},[(Q(!0),nt(Gt,null,ye(k.value,E=>(Q(),nt("option",{key:E.id,value:E.id},_t(E.name),9,nv))),128))],512),[[tu,v.value]])])]),g("div",sv,[g("div",ov,[g("span",rv,_t(w.value.totalSlides),1),Z[15]||(Z[15]=g("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),g("div",lv,[g("span",av,_t(L.value),1),Z[16]||(Z[16]=g("span",{class:"spm-stat-label"},"演示主题",-1))]),g("div",cv,[g("span",dv,_t(w.value.stats.totalNotes),1),Z[17]||(Z[17]=g("span",{class:"spm-stat-label"},"演讲者提词",-1))]),g("div",uv,[g("span",fv,_t(R.value),1),Z[18]||(Z[18]=g("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),N.value.length>0?(Q(),nt("div",pv,[Z[19]||(Z[19]=g("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(Q(!0),nt(Gt,null,ye(N.value,E=>(Q(),nt("span",{key:E.name,class:"spm-chip-badge"},_t(E.name)+": "+_t(E.count),1))),128))])):Ft("",!0),g("div",hv,[g("label",mv,[Ie(g("input",{"onUpdate:modelValue":Z[7]||(Z[7]=E=>b.value=E),type:"checkbox",onChange:S},null,544),[[Ln,b.value]]),Z[20]||(Z[20]=g("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),g("label",gv,[Ie(g("input",{"onUpdate:modelValue":Z[8]||(Z[8]=E=>T.value=E),type:"checkbox",onChange:S},null,544),[[Ln,T.value]]),Z[21]||(Z[21]=g("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),g("label",vv,[Ie(g("input",{"onUpdate:modelValue":Z[9]||(Z[9]=E=>C.value=E),type:"checkbox"},null,512),[[Ln,C.value]]),Z[22]||(Z[22]=g("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),g("label",bv,[Ie(g("input",{"onUpdate:modelValue":Z[10]||(Z[10]=E=>A.value=E),type:"checkbox"},null,512),[[Ln,A.value]]),Z[23]||(Z[23]=g("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Ft("",!0)]),g("div",yv,[g("button",{class:"spm-btn-secondary",disabled:l.value,onClick:it}," 取消 ",8,wv),g("button",{class:"spm-btn-primary",disabled:!w.value||l.value,onClick:j},[l.value?(Q(),nt("span",xv,"⏳ 正在导入生成中...")):(Q(),nt("span",_v,"🚀 确认导入思源笔记"))],8,kv)])])]))}}),Cv=Le(Sv,[["__scopeId","data-v-8771dc8a"]]),$v={class:"spm-slidev-inspector"},Iv={class:"spm-inspector-topbar"},Av={class:"spm-inspector-title"},Tv={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},Ev={class:"spm-inspector-topbar-actions"},Mv={class:"spm-target-banner"},Bv={class:"spm-target-info"},Dv=["aria-label"],Ov={key:0,class:"spm-save-status"},Pv=["title"],Lv={class:"spm-inspector-body"},Rv=be({__name:"SlidevInspectorDockView",setup(t,{expose:i}){const e=Qe("plugin"),n=pt(!1);function s(K){n.value=!1,c.value=K.docId,e!=null&&e.compileCurrentDocument&&e.compileCurrentDocument(K.docId)}const r=pt(""),l=pt(""),o=pt({}),a=pt(""),c=pt(""),d=pt(""),h=pt(""),p=pt(""),f=pt(null),w=pt(""),m=pt("");let k=null;function v(K="已同步"){w.value=K,k&&window.clearTimeout(k),k=window.setTimeout(()=>{w.value=""},1200)}function b(){var at;const K=r.value||c.value;K&&(at=navigator==null?void 0:navigator.clipboard)!=null&&at.writeText&&navigator.clipboard.writeText(K).then(()=>{m.value="已复制！",setTimeout(()=>{m.value=""},1500)}).catch(()=>{})}const T=Ct(()=>l.value==="NodeThematicBreak"),C=Ct(()=>l.value==="NodeCodeBlock"),A=pt(!1),S=Ct(()=>{if(A.value||B.value)return!0;const K=a.value||"";return!!fi(K)}),I=Ct(()=>{const K=l.value||"";if(K==="NodeVideo"||K==="video")return!0;const at=a.value||"";return!!(/<video\b/i.test(at)||/\.mp4\b/i.test(at))}),L=Ct(()=>!r.value||r.value===c.value||l.value==="doc"||l.value==="NodeDocument"),R=Ct(()=>{const K=r.value||c.value||"";return K.length>8?K.slice(-8):K||"无"}),N=Ct(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),J=Ct(()=>{if(T.value)return"分页符 (---)";if(L.value)return"全局文档";if(I.value)return"视频块";switch(l.value){case"NodeHeading":return"标题块";case"NodeParagraph":return"段落块";case"NodeCodeBlock":return"代码块";case"NodeVideo":return"视频块";case"NodeList":case"NodeListItem":return"列表项";case"NodeBlockquote":return"引述块";case"NodeTable":return"表格块";case"NodeSuperBlock":case"s":case"sb":return"超级块";default:return"内容块"}}),x=Ct(()=>T.value?"tag-divider":L.value?"tag-doc":"tag-block"),q=Ct(()=>o.value[ut]||"default"),y=Ct(()=>o.value[Xt]||"slide-left"),U=pt(""),et=pt(""),j=Ct(()=>{var At;if(!((At=f.value)!=null&&At.slides)||f.value.slides.length===0)return null;const K=r.value,at=d.value,gt=h.value;if(gt){let xt=f.value.slides.find(Dt=>Dt.startBlockId===gt);if(xt||(xt=f.value.slides.find(Dt=>{var Ot,Pt;return((Pt=(Ot=Dt.blocks)==null?void 0:Ot[0])==null?void 0:Pt.id)===gt}),xt))return xt}if(K){let xt=f.value.slides.find(Ot=>Ot.startBlockId===K);if(xt||(xt=f.value.slides.find(Ot=>{var Pt,Zt;return((Pt=Ot.blocks)==null?void 0:Pt.some(Bt=>Bt.id===K))||((Zt=Ot.allBlockIds)==null?void 0:Zt.includes(K))}),xt)||at&&at!==K&&(xt=f.value.slides.find(Ot=>{var Pt,Zt;return((Pt=Ot.blocks)==null?void 0:Pt.some(Bt=>Bt.id===at))||((Zt=Ot.allBlockIds)==null?void 0:Zt.includes(at))}),xt)||(xt=f.value.slides.find(Ot=>{var Pt;return(Pt=Ot.noteBlocks)==null?void 0:Pt.some(Zt=>Zt.id===K||Zt.id===at)}),xt))return xt;const Dt=o.value[Tt];if(Dt&&["col-1","col-2","col-3"].includes(Dt)&&(xt=f.value.slides.find(Ot=>{var Pt,Zt;return((Pt=Ot.frontmatter)==null?void 0:Pt.layout)==="three-cols-header"||((Zt=Ot.blocks)==null?void 0:Zt.some(Bt=>Bt.slot==="col-1"||Bt.slot==="col-2"||Bt.slot==="col-3"))}),xt))return xt}return f.value.slides[0]||null}),it=Ct(()=>{var K;return((K=j.value)==null?void 0:K.notes)||""}),V=Ct(()=>{var K,at,gt;return((gt=(at=(K=j.value)==null?void 0:K.noteBlocks)==null?void 0:at[0])==null?void 0:gt.id)||""}),Z=Ct(()=>{var At,xt,Dt,Ot,Pt,Zt;if(T.value){const Bt=o.value[ut]||o.value["custom-slidev-layout"];if(Bt)return Bt}const K=o.value[Tt]||o.value["custom-slidev-slot"];if(K&&["col-1","col-2","col-3"].includes(K))return"three-cols-header";if(p.value)return p.value;const at=h.value||(T.value?r.value:"");if(at){const Bt=Ht.getBlockAttrOverride(at);if(Bt!=null&&Bt[ut])return Bt[ut]}if(at&&((At=f.value)!=null&&At.slides)){const Bt=f.value.slides.find(li=>li.startBlockId===at);if((xt=Bt==null?void 0:Bt.frontmatter)!=null&&xt.layout)return Bt.frontmatter.layout}if((Ot=(Dt=j.value)==null?void 0:Dt.frontmatter)!=null&&Ot.layout)return j.value.frontmatter.layout;if((Zt=(Pt=j.value)==null?void 0:Pt.blocks)!=null&&Zt.some(Bt=>Bt.slot==="col-1"||Bt.slot==="col-2"||Bt.slot==="col-3"))return"three-cols-header";const gt=Ht.getBlockAttrOverride(c.value);return gt!=null&&gt[ut]?gt[ut]:"default"}),E=Ct(()=>{var K;return((K=j.value)==null?void 0:K.pageIndex)||1}),D=Ct(()=>!!(o.value[ie]||o.value["slidev-note"])),ot=Ct(()=>{var at;if(o.value[Se])return o.value[Se];const K=r.value;if(K&&((at=j.value)!=null&&at.blocks)){const gt=j.value.blocks.find(At=>At.id===K);if(gt!=null&&gt.clicks)return gt.clicks}return""}),rt=Ct(()=>{var at;if(o.value[He])return o.value[He];const K=r.value;if(K&&((at=j.value)!=null&&at.blocks)){const gt=j.value.blocks.find(At=>At.id===K);if(gt!=null&&gt.motion)return typeof gt.motion=="string"?gt.motion:JSON.stringify(gt.motion)}return""}),st=Ct(()=>{var at;if(o.value[Tt])return o.value[Tt];const K=r.value;if(K&&((at=j.value)!=null&&at.blocks)){const gt=j.value.blocks.find(At=>At.id===K);if(gt!=null&&gt.slot)return gt.slot}return""}),kt=pt(""),$t=pt(""),yt=Ct(()=>o.value[An]==="true"),Y=Ct(()=>o.value[Tn]==="true"),lt=Ct(()=>o.value[En]==="true"),dt=Ct(()=>o.value[Mn]!=="false");async function M(){const K=yt.value?"false":"true";await G(An,K)}async function P(){const K=Y.value?"false":"true";await G(Tn,K)}async function u(){const K=lt.value?"false":"true";await G(En,K)}async function z(){const K=dt.value?"false":"true";await G(Mn,K)}const O=Ct(()=>{var K,at;return((at=(K=f.value)==null?void 0:K.config)==null?void 0:at.theme)||o.value[sn]||"default"}),_=Ct(()=>{var K,at;return((at=(K=f.value)==null?void 0:K.config)==null?void 0:at.aspectRatio)||o.value[on]||"16/9"}),$=Ct(()=>{var K,at;return((at=(K=f.value)==null?void 0:K.config)==null?void 0:at.defaultTransition)||o.value[rn]||"slide-left"}),B=Ct(()=>{var xt,Dt;if((o.value[qt]||o.value["slidev-role"])===Sr||o.value[Ut]==="true")return"background";const at=o.value[ut]||o.value["slidev-layout"];if(at==="image-left"||at==="image-right")return at;const gt=a.value||"",At=fi(gt);if(At&&((Dt=(xt=j.value)==null?void 0:xt.frontmatter)!=null&&Dt.background)){const Ot=j.value.frontmatter.background;if(Ot===At||Ot.endsWith(At)||At.endsWith(Ot))return"background"}return""});async function W(K){var Dt;const at=r.value;if(!at)return;const gt=a.value||"",At=fi(gt)||"",xt=h.value||c.value;if(K)if(K==="background"){const Ot={[qt]:"background",[ut]:""};xt&&At&&(U.value=At,await zt(xt,{[Ut]:At}).catch(()=>{}),Ht.setBlockAttrOverride(xt,{[Ut]:At}),se(xt,{[Ut]:At}),j.value&&(j.value.frontmatter||(j.value.frontmatter={}),j.value.frontmatter.background=At)),await F(Ot)}else(K==="image-left"||K==="image-right")&&await F({[ut]:K,[qt]:""});else{const Ot={[qt]:"",[ut]:""};if(o.value[Ut]==="true"&&(Ot[Ut]=""),xt&&At&&U.value===At&&(U.value="",await zt(xt,{[Ut]:""}).catch(()=>{}),Ht.setBlockAttrOverride(xt,{[Ut]:""}),se(xt,{[Ut]:""}),(Dt=j.value)!=null&&Dt.frontmatter&&delete j.value.frontmatter.background),await F(Ot),typeof document<"u"){const Pt=document.querySelector(`.protyle-wysiwyg [data-node-id="${at}"]`),Zt=Pt==null?void 0:Pt.closest('[data-type="NodeListItem"]'),Bt=Zt==null?void 0:Zt.getAttribute("data-node-id");if(Bt&&Bt!==at){const li={[ut]:"",[qt]:""};se(Bt,li),Ht.setBlockAttrOverride(Bt,li),await zt(Bt,li).catch(()=>{})}}}}async function F(K){const at=r.value||c.value;if(at){for(const[gt,At]of Object.entries(K))o.value[gt]=At;if(Ht.setBlockAttrOverride(at,K),se(at,K),ut in K){const gt=K[ut];p.value=gt,j.value&&(j.value.frontmatter||(j.value.frontmatter={}),j.value.frontmatter.layout=gt)}v("保存中...");try{await zt(at,K),v("已同步"),e&&await e.compileCurrentDocument()}catch{v("同步失败")}}}const H=Ct(()=>!!(o.value[Se]||o.value[He]||o.value[Tt]||o.value[_i]||o.value[ie]||o.value["slidev-note"]||o.value[qt]||o.value[ut]||o.value[An]||o.value[Tn]||o.value[En]||o.value[Mn]));async function G(K,at){const gt=r.value||c.value;if(gt){o.value[K]=at,Ht.setBlockAttrOverride(gt,{[K]:at}),se(gt,{[K]:at}),K===ut&&(p.value=at,j.value&&(j.value.frontmatter||(j.value.frontmatter={}),j.value.frontmatter.layout=at)),v("保存中...");try{await zt(gt,{[K]:at}),v("已同步"),e&&await e.compileCurrentDocument()}catch{v("同步失败")}}}async function tt(K,at){var At;const gt=c.value||r.value;if(gt){o.value[K]=at,Ht.setBlockAttrOverride(gt,{[K]:at}),se(gt,{[K]:at}),(At=f.value)!=null&&At.config&&(K===sn&&(f.value.config.theme=at),K===on&&(f.value.config.aspectRatio=at),K===rn&&(f.value.config.defaultTransition=at)),v("更新中...");try{await zt(gt,{[K]:at}),v("已更新"),e&&await e.compileCurrentDocument(gt)}catch{v("更新失败")}}}function X(K){G(ut,K)}function ct(K){G(Xt,K)}function wt(K){U.value=K,G(Ut,K)}function mt(K){et.value=K,G(Ae,K)}async function Mt(){const K=r.value;if(K)if(D.value){v("取消中...");try{await zt(K,{[ie]:"","slidev-note":""}),Ht.setBlockAttrOverride(K,{[ie]:"","slidev-note":""}),se(K,{[ie]:"","slidev-note":""}),delete o.value[ie],delete o.value["slidev-note"],v("已取消备注"),ht.showMessage("已取消讲稿备注"),e&&await e.compileCurrentDocument()}catch(at){console.error("[SiYuanSlidev] 取消讲稿备注失败:",at),v("取消失败"),ht.showMessage("取消讲稿备注失败")}}else{v("转换中...");try{let at=a.value;try{const Dt=await pa(K);Dt!=null&&Dt.kramdown&&(at=Dt.kramdown)}catch{}const xt=`> [!NOTE] 💡 演讲备注
${(Ar(at)||at.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(Dt=>`> ${Dt}`).join(`
`)}
{: custom-slidev-note="true"}`;await Do("markdown",xt,K),await zt(K,{[ie]:"true"}),Ht.setBlockAttrOverride(K,{[ie]:"true"}),se(K,{[ie]:"true"}),o.value[ie]="true",l.value="NodeCallout",v("已设为讲稿备注"),ht.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e&&await e.compileCurrentDocument()}catch(at){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",at),v("设置失败"),ht.showMessage("转为讲稿备注提示块失败")}}}async function Vt(K){var Bt,li,Ao,To,Eo,Mo,Bo;const At=`> [!NOTE] 💡 演讲备注
${(K||"在此输入本页讲稿提词...").split(/\r?\n/).map(Re=>`> ${Re}`).join(`
`)}
{: custom-slidev-note="true"}`,xt=((Bt=f.value)==null?void 0:Bt.slides)||[],Dt=j.value,Ot=Dt?xt.findIndex(Re=>Re===Dt):-1;let Pt=null;if(Ot!==-1&&Ot<xt.length-1){const Re=xt[Ot+1];Pt=await tn("markdown",At,Re.startBlockId)}else{const Re=((li=Dt==null?void 0:Dt.noteBlocks)==null?void 0:li.slice(-1)[0])||((Ao=Dt==null?void 0:Dt.blocks)==null?void 0:Ao.slice(-1)[0]);Re!=null&&Re.id?Pt=await tn("markdown",At,void 0,Re.id):Pt=await wr("markdown",At,c.value)}const Zt=((Mo=(Eo=(To=Pt==null?void 0:Pt[0])==null?void 0:To.doOperations)==null?void 0:Eo[0])==null?void 0:Mo.id)||((Bo=Pt==null?void 0:Pt[0])==null?void 0:Bo.id);return Zt&&(await zt(Zt,{[ie]:"true"}),Ht.setBlockAttrOverride(Zt,{[ie]:"true"}),Ti(Zt,e==null?void 0:e.app)),e&&await e.compileCurrentDocument(),Zt}async function Yt(){try{await Vt(),ht.showMessage("已在正文末尾插入讲稿备注提示块")}catch(K){ht.showMessage("插入讲稿备注块失败"),console.error(K)}}function ee(){const K=V.value;if(!K){ht.showMessage("未找到本页关联的讲稿备注块");return}Ti(K,e==null?void 0:e.app)?ht.showMessage("已在编辑区定位讲稿备注块"):ht.showMessage("定位讲稿备注块失败")}async function Nt(){if(!c.value)return;const K=j.value||{startBlockId:r.value||c.value,blocks:a.value&&a.value!=="---"?[{id:r.value,type:l.value,content:a.value,rawMarkdown:""}]:[],rawMarkdown:a.value&&a.value!=="---"?a.value:""};ht.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const at=await Cr(K,kr);if(at.notes){const gt=V.value;if(gt){const At=`> [!NOTE] 💡 演讲备注
${at.notes.split(/\r?\n/).map(xt=>`> ${xt}`).join(`
`)}
{: custom-slidev-note="true"}`;await Do("markdown",At,gt),await zt(gt,{[ie]:"true"}),Ht.setBlockAttrOverride(gt,{[ie]:"true"}),Ti(gt,e==null?void 0:e.app)}else await Vt(at.notes);at.isAiGenerated?ht.showMessage("思源 AI 演讲提词卡生成成功！"):ht.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e&&await e.compileCurrentDocument()}}function Ke(){ot.value?G(Se,""):G(Se,"+1")}function te(K){G(Se,K)}function Jt(K){G(He,K)}function mi(K){(o.value[Tt]||"")===K?G(Tt,""):G(Tt,K)}function Mi(K){kt.value=K,G(_i,K)}function ms(K){$t.value=K,G(ln,K)}async function gs(){const K=Z.value==="three-cols-header";await G(Tt,K?"col-1":"left"),ht.showMessage(K?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function $n(){const K=r.value;if(!K)return;const at={[Se]:"",[He]:"",[Tt]:"",[_i]:"",[ln]:"",[ie]:"","slidev-note":"",[ut]:"",[qt]:"",[Xt]:"",[Ut]:"",[Ae]:"",[An]:"",[Tn]:"",[En]:"",[Mn]:""};if(se(K,at),await zt(K,at),Ht.clearBlockAttrOverride(K),typeof document<"u"){const gt=document.querySelector(`.protyle-wysiwyg [data-node-id="${K}"]`),At=gt==null?void 0:gt.closest('[data-type="NodeListItem"]'),xt=At==null?void 0:At.getAttribute("data-node-id");xt&&xt!==K&&(se(xt,at),await zt(xt,at).catch(()=>{}),Ht.clearBlockAttrOverride(xt))}o.value={},kt.value="",$t.value="",U.value="",et.value="",ht.showMessage("已清除本块演示属性"),e&&await e.compileCurrentDocument()}function gi(K){tt(sn,K)}function Bi(K){tt(on,K)}function Zl(K){tt(rn,K)}async function Yl(){if(r.value)try{await tn("markdown","---",r.value,void 0),ht.showMessage("已在上方插入分页符 (---)"),e&&e.compileCurrentDocument()}catch{ht.showMessage("插入分页符失败")}}async function $o(){const K=r.value||c.value;if(K)try{await tn("markdown","---",void 0,K),ht.showMessage("已在下方插入分页符 (---)"),e&&e.compileCurrentDocument()}catch{ht.showMessage("插入分页符失败")}}async function Jl(){if(r.value)try{await fa(r.value),ht.showMessage("已删除该分页符"),r.value="",l.value="",e&&e.compileCurrentDocument()}catch{ht.showMessage("删除失败")}}function Io(){e!=null&&e.openBottomPreviewTab&&e.openBottomPreviewTab()}function Xl(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function Ql(){e!=null&&e.executeCommand&&e.executeCommand("slidevAiSplit")}function ta(){if(!f.value){ht.showMessage("请先在主编辑区打开幻灯片文档");return}const K=Ul(f.value);Wl("presentation.html",K)&&ht.showMessage("已开始下载单文件离线 HTML 演示包")}function ea(){if(!f.value){ht.showMessage("请先在主编辑区打开幻灯片文档");return}Vl(f.value)&&ht.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({setActiveBlock(K){r.value=K.id,l.value=K.type,o.value={...K.attrs},a.value=K.content||K.markdown||"",d.value=K.topBlockId||K.id,h.value=K.pageDividerId||"",p.value=K.pageDividerLayout||"",K.rootId?c.value=K.rootId:(K.type==="doc"||K.type==="NodeDocument")&&K.id&&(c.value=K.id),U.value=K.attrs[Ut]||"",et.value=K.attrs[Ae]||"",kt.value=K.attrs[_i]||"",$t.value=K.attrs[ln]||"",A.value=!!K.isImage},updateDocument(K){f.value=K,c.value=K.docId},openImportDialog(){n.value=!0},setCurrentDocId(K){c.value=K}}),(K,at)=>(Q(),nt("div",$v,[g("div",Iv,[g("div",Av,[(Q(),nt("svg",Tv,[...at[2]||(at[2]=[g("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),g("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),g("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),at[3]||(at[3]=g("span",null,"演示配置",-1))]),g("div",Ev,[g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:at[0]||(at[0]=gt=>n.value=!0)},[ft(bt,{name:"import"}),at[4]||(at[4]=g("span",null,"导入",-1))]),g("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:Io},[ft(bt,{name:"split-preview"}),at[5]||(at[5]=g("span",null,"分屏预览",-1))])])]),g("div",Mv,[g("div",Bv,[g("span",{class:Et(["spm-target-tag",x.value])},_t(J.value),3),g("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":m.value||"点击复制 ID: "+(r.value||c.value),onClick:b},[ft(bt,{name:"copy"}),g("span",null,"#"+_t(R.value),1)],8,Dv)]),w.value?(Q(),nt("span",Ov,"● "+_t(w.value),1)):Ft("",!0)]),N.value?(Q(),nt("div",{key:0,class:"spm-context-quote",title:a.value},_t(N.value),9,Pv)):Ft("",!0),g("div",Lv,[T.value?(Q(),Ee(Dh,{key:0,"page-layout":q.value,"page-transition":y.value,"page-background":U.value,"page-image":et.value,"page-notes":it.value,"page-index":E.value,"onUpdate:pageLayout":X,"onUpdate:pageTransition":ct,"onUpdate:pageBackground":wt,"onUpdate:pageImage":mt,onAddNoteBlock:Yt,onLocateNoteBlock:ee,onGenerateNotes:Nt,onInsertDividerAfter:$o,onDeleteDivider:Jl},null,8,["page-layout","page-transition","page-background","page-image","page-notes","page-index"])):r.value&&!L.value?(Q(),Ee(tg,{key:1,"elem-click":ot.value,"elem-motion":rt.value,"elem-slot":st.value,"elem-shiki-lines":kt.value,"elem-max-height":$t.value,"is-code-block":C.value,"is-image":S.value,"is-video":I.value,"video-autoplay":yt.value,"video-loop":Y.value,"video-muted":lt.value,"video-controls":dt.value,"has-block-attrs":H.value,"is-note":D.value,"image-role":B.value,"current-slide-layout":Z.value,onToggleNote:Mt,onToggleElemClick:Ke,onToggleVideoAutoplay:M,onToggleVideoLoop:P,onToggleVideoMuted:u,onToggleVideoControls:z,"onUpdate:imageRole":W,"onUpdate:elemClick":te,"onUpdate:elemMotion":Jt,"onUpdate:elemSlot":mi,"onUpdate:elemShikiLines":Mi,"onUpdate:elemMaxHeight":ms,onInsertDividerBefore:Yl,onInsertDividerAfter:$o,onSetTwoColsContrast:gs,onClearBlockAttrs:$n},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout"])):(Q(),Ee(Ig,{key:2,"doc-theme":O.value,"doc-aspect-ratio":_.value,"doc-default-transition":$.value,"onUpdate:docTheme":gi,"onUpdate:docAspectRatio":Bi,"onUpdate:docDefaultTransition":Zl,onOpenBottomPreview:Io,onOpenPresenter:Xl,onAiAutoSplit:Ql,onExportHtml:ta,onExportPdf:ea},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition"]))]),n.value?(Q(),Ee(Cv,{key:1,onClose:at[1]||(at[1]=gt=>n.value=!1),onSuccess:s})):Ft("",!0)]))}}),Cn=new _o;let di=null,We=null;function zv(t,i){di&&ql(),di=Rl(oh),di.provide("plugin",i),di.provide("sandboxBridge",Cn);const e=di.mount(t);return We=e,e}function ql(t){di&&(di.unmount(),di=null,We=null)}let ui=null,ge=null;function Nv(t,i){ui&&Gl(),ui=Rl(Rv),ui.provide("plugin",i),ui.provide("sandboxBridge",Cn);const e=ui.mount(t);return ge=e,e}function Gl(t){ui&&(ui.unmount(),ui=null,ge=null)}function Fv(t,i){ge!=null&&ge.updateDocument&&ge.updateDocument(t),We!=null&&We.updateDocument?We.updateDocument(t,i):Cn.updateSlides(t.slides,t.config,t.fullMarkdown)}function Bs(t){We!=null&&We.navigateToBlock?We.navigateToBlock(t):Cn.highlightElement(t)}function Nn(t){ge!=null&&ge.setActiveBlock&&ge.setActiveBlock(t)}function jv(){return ge!=null&&ge.openImportDialog?(ge.openImportDialog(),!0):!1}const Hv=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:ki,value:"true"},{key:ut,value:"cover"},{key:Xt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:ki,value:"true"},{key:ut,value:"two-cols"},{key:Xt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:ki,value:"true"},{key:ut,value:"fact"},{key:Xt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:ki,value:"true"},{key:ut,value:"intro"},{key:Xt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:ki,value:"true"},{key:ut,value:"quote"},{key:Xt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Se,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Se,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Tt,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:_i,value:"1-3"}]}];class Ds{getPresetTemplates(){return Hv}buildScanSlidevBlocksSql(i="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${i}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${Xt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(i,e,n,s){const r=`SELECT block_id FROM attributes WHERE name = '${Xt}' AND value = '${i}'`,l=await n(r);let o=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await s(c,{[Xt]:e}),o++)}return{updatedCount:o}}async batchUpdateLayout(i,e,n,s){const r=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${i}'`,l=await n(r);let o=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await s(c,{"custom-slidev-layout":e}),o++)}return{updatedCount:o}}exportTemplatesJson(){const i=this.getPresetTemplates();return JSON.stringify({templates:i,counter:i.length},null,2)}formatTransitionSummary(i){return!i||i.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${i.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}const Uv=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,Wv="slidev-dock",br="slidev-preview-tab",yr=cp;class Vv extends ht.Plugin{constructor(){super(...arguments);vt(this,"isMobile",!1);vt(this,"currentDocId","");vt(this,"latestCompiledDoc",null);vt(this,"cliBridge",new Qs);vt(this,"debounceTimer",null);vt(this,"activeCursorBlockId","");vt(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));vt(this,"onWsMainBound",this.onWsMain.bind(this));vt(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));vt(this,"onClickEditorTitleIconBound",this.onClickEditorTitleIcon.bind(this));vt(this,"onEditorClickBound",this.onEditorClick.bind(this));vt(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));vt(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this))}async onload(){const e=ht.getFrontend();this.isMobile=e==="mobile"||e==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(Uv),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"Slidev 演示 (下方分屏)",position:"right",callback:()=>{this.openBottomPreviewTab()}}),this.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{this.openBottomPreviewTab()}}),this.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{jv()||ht.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),this.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!this.currentDocId){const s=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}this.currentDocId&&(await zt(this.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),ht.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(this.currentDocId))}}),this.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!this.currentDocId){const a=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(a==null?void 0:a.getAttribute("data-doc-id"))||""}if(!this.currentDocId){ht.showMessage("请先打开一篇思源笔记文档");return}const s=await Vn(this.currentDocId).catch(()=>[]);if(!s||s.length===0){ht.showMessage("当前文档无内容，无需断页");return}const r=s.map(a=>({id:a.id,type:a.type,subType:a.subType,content:a.content||"",markdown:a.markdown||""})),l=ga(r);if(l.length===0){ht.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}ht.showMessage(`AI 分析完毕：发现 ${l.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const a of l)try{await tn("markdown","---",void 0,a.blockId),await zt(a.blockId,{"custom-slidev-layout":a.recommendedLayout}),o++}catch(c){console.warn("Failed to insert divider:",c)}ht.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),this.compileCurrentDocument(this.currentDocId)}}),this.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var h,p,f,w;if(!this.currentDocId){const m=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(m==null?void 0:m.getAttribute("data-doc-id"))||""}if(!this.currentDocId){ht.showMessage("请先打开一篇思源笔记文档");return}ht.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const s=await Vn(this.currentDocId).catch(()=>[]),r={startBlockId:this.currentDocId,blocks:s.map(m=>({id:m.id,type:m.type,content:m.content||"",rawMarkdown:m.markdown||""})),rawMarkdown:""},a=`> [!NOTE] 💡 演讲备注
${(await va(r,kr)).split(/\r?\n/).map(m=>`> ${m}`).join(`
`)}
{: custom-slidev-note="true"}`,c=await wr("markdown",a,this.currentDocId).catch(()=>null),d=((f=(p=(h=c==null?void 0:c[0])==null?void 0:h.doOperations)==null?void 0:p[0])==null?void 0:f.id)||((w=c==null?void 0:c[0])==null?void 0:w.id);d&&(await zt(d,{"custom-slidev-note":"true"}),Ht.setBlockAttrOverride(d,{"custom-slidev-note":"true"}),Ti(d,this.app)),ht.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),this.compileCurrentDocument(this.currentDocId)}}),this.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const s=new Ds,r=s.buildTransitionStatsSql(),l=await pn(r).catch(()=>[]),o=s.formatTransitionSummary(l||[]);ht.showMessage(o)}}),this.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const r=new Ds().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(r),ht.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ht.showMessage(`已生成模板数据（请在控制台查看）：
`+r)}}),this.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const r=await new Ds().batchUpdateTransitions("fade","slide-left",l=>pn(l).catch(()=>[]),(l,o)=>zt(l,o));ht.showMessage(`全库批量替换完成：已将 ${r.updatedCount} 处 fade 转场更新为 slide-left`),this.compileCurrentDocument()}}),this.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),this.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(this.latestCompiledDoc||await this.compileCurrentDocument(),!this.latestCompiledDoc){ht.showMessage("请先打开并放映一篇思源笔记文档");return}this.cliBridge.downloadSlidesMd(this.latestCompiledDoc,`slides-${this.currentDocId||"demo"}.md`)&&ht.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),this.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{ht.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await this.cliBridge.probeServer(1500)?ht.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):ht.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),this.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(this.latestCompiledDoc||await this.compileCurrentDocument(),!this.latestCompiledDoc){ht.showMessage("请先打开并放映一篇思源笔记文档");return}const s=await this.cliBridge.syncToWorkspaceFile(this.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",Os);s.success?ht.showMessage(`已成功同步最新 slides.md 至工作空间：${s.path}`):ht.showMessage(`同步失败：${s.error}`)}});const n=this;if(this.addTab({type:br,init(){zv(this.element,n)},destroy(){ql(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:Wv,init(){Nv(this.element,n)},destroy(){Gl(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(s,r)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${s}`,{detail:r}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound)),typeof document<"u"){const s=()=>{const r=this.getActiveDocumentId();r&&(r!==this.currentDocId&&(this.currentDocId=r),this.latestCompiledDoc||this.compileCurrentDocument(r))};setTimeout(s,300),setTimeout(s,1e3)}}async onDataChanged(e){await this.loadGlobalSettings(),this.currentDocId&&await this.compileCurrentDocument(this.currentDocId)}async loadGlobalSettings(){try{const e=await this.loadData(yr),n=dp(e);return Ui(n),n}catch{return Ui(Gi),Gi}}async saveGlobalSettings(e){const n=Co(),s=Ui({...n,...e||{}});try{await this.saveData(yr,s)}catch(r){console.error("保存 Slidev 全局配置失败",r)}return s}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound)),Cn.detach()}async openBottomPreviewTab(){if(!this.currentDocId){const e=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(e==null?void 0:e.getAttribute("data-doc-id"))||""}await ht.openTab({app:this.app,custom:{id:this.name+br,title:"Slidev 演示预览",icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId)}onClickEditorTitleIcon(e){var l;const n=e.detail,s=n==null?void 0:n.menu,r=((l=n==null?void 0:n.data)==null?void 0:l.id)||this.currentDocId;!s||!r||s.addItem({icon:"iconSlidev",label:"Slidev 全局演示配置",submenu:[{label:"初始化演示属性 (custom-slidev-*)",click:async()=>{await zt(r,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),ht.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"主题: 默认 (default)",click:async()=>{await zt(r,{"custom-slidev-theme":"default"}),ht.showMessage("已切换为 default 主题"),this.compileCurrentDocument(r)}},{label:"主题: 优雅衬线 (seriph)",click:async()=>{await zt(r,{"custom-slidev-theme":"seriph"}),ht.showMessage("已切换为 seriph 主题"),this.compileCurrentDocument(r)}},{label:"主题: 苹果极简 (apple-basic)",click:async()=>{await zt(r,{"custom-slidev-theme":"apple-basic"}),ht.showMessage("已切换为 apple-basic 主题"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"画幅: 16 / 9 (宽屏)",click:async()=>{await zt(r,{"custom-slidev-aspect-ratio":"16/9"}),ht.showMessage("已切换画幅为 16/9"),this.compileCurrentDocument(r)}},{label:"画幅: 4 / 3 (标屏)",click:async()=>{await zt(r,{"custom-slidev-aspect-ratio":"4/3"}),ht.showMessage("已切换画幅为 4/3"),this.compileCurrentDocument(r)}}]})}async onSwitchProtyle(e){var r,l;const n=(r=e.detail)==null?void 0:r.protyle,s=(l=n==null?void 0:n.block)==null?void 0:l.rootID;if(s&&s!==this.currentDocId){this.currentDocId=s,this.activeCursorBlockId=s;const o=await Ge(s).catch(()=>({}));Nn({id:s,rootId:s,type:"doc",attrs:o}),this.compileCurrentDocument(s)}}onClickEditorContent(e){var r,l;const n=e==null?void 0:e.detail;if(!n)return;const s=(l=(r=n.protyle)==null?void 0:r.block)==null?void 0:l.rootID;s&&(!this.currentDocId||this.currentDocId!==s)&&(this.currentDocId=s),n.event&&this.onEditorClick(n.event)}getActiveDocumentId(){if(typeof document>"u")return"";const e=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),n=e==null?void 0:e.getAttribute("data-node-id");if(n)return n;const s=document.querySelector(".protyle .protyle-title[data-node-id]"),r=s==null?void 0:s.getAttribute("data-node-id");if(r)return r;const l=document.querySelector("[data-doc-id]"),o=l==null?void 0:l.getAttribute("data-doc-id");return o||""}resolveDocIdFromElement(e){const n=e.closest(".protyle-title"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const r=e.closest(".protyle"),l=r==null?void 0:r.querySelector(".protyle-title"),o=l==null?void 0:l.getAttribute("data-node-id");if(o)return o;const a=e.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||this.currentDocId}async switchToDocGlobalInspector(e,n){var l;if(!e)return;this.activeCursorBlockId=e,this.currentDocId=e;let s=n||"";if(!s&&typeof document<"u"){const o=document.querySelector(`.protyle-title[data-node-id="${e}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${e}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");s=((l=o==null?void 0:o.innerText)==null?void 0:l.trim())||""}const r=await Ge(e).catch(()=>({}));Nn({id:e,rootId:e,type:"doc",content:s,attrs:r,isDivider:!1,isCode:!1}),Bs(e)}onWsMain(e){const n=e.detail;if(n){if(n.cmd==="transactions"&&Array.isArray(n.data)){for(const s of n.data)if(Array.isArray(s==null?void 0:s.doOperations)){for(const r of s.doOperations)if((r==null?void 0:r.action)==="updateAttrs"&&r.id&&r.data){const l=r.data.old||{},o=r.data.new||{},a={};for(const c of Object.keys(l))c in o||(a[c]="");for(const[c,d]of Object.entries(o))a[c]=String(d??"");se(r.id,a),Ht.setBlockAttrOverride(r.id,a)}}}this.debounceTimer&&window.clearTimeout(this.debounceTimer),this.debounceTimer=window.setTimeout(()=>{this.compileCurrentDocument()},150)}}handleBlockClickedFromSlide(e,n){var o,a;if(!e)return!1;this.activeCursorBlockId=e;const s=Ti(e,this.app),r=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`),l=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,e,l);else{let c="",d="";if((o=this.latestCompiledDoc)!=null&&o.slides){const h=this.latestCompiledDoc.slides.find(p=>{var f,w,m;return p.startBlockId===e||((f=p.blocks)==null?void 0:f.some(k=>k.id===e))||((w=p.allBlockIds)==null?void 0:w.includes(e))||((m=p.noteBlocks)==null?void 0:m.some(k=>k.id===e))});h!=null&&h.startBlockId&&(c=h.startBlockId),(a=h==null?void 0:h.frontmatter)!=null&&a.layout&&(d=h.frontmatter.layout)}Ge(e).then(async h=>{if(c&&!d){const p=Ht.getBlockAttrOverride(c);if(p!=null&&p[ut]||p!=null&&p["custom-slidev-layout"])d=p[ut]||p["custom-slidev-layout"]||"";else{const f=await Ge(c).catch(()=>({}))||{};d=f[ut]||f["custom-slidev-layout"]||"",f&&Object.keys(f).length>0&&Ht.setBlockAttrOverride(c,f)}}Nn({id:e,rootId:this.currentDocId,type:l||"NodeParagraph",attrs:h||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return s}onBlockClickedFromSlide(e){const n=(e==null?void 0:e.detail)||e;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(e){const n=e.target;if(!n)return;const s=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(s||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const h=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),p=h==null?void 0:h.querySelector(".protyle-title__input"),f=((p==null?void 0:p.innerText)||(h==null?void 0:h.innerText)||"").trim();this.switchToDocGlobalInspector(d,f)}return}if(!n.closest(".protyle-wysiwyg"))return;const o=n.closest("[data-node-id]");if(!o)return;const a=o.getAttribute("data-node-id"),c=o.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Bs(a)),this.syncInspectorBlock(o,a,c))}onSelectionChange(){if(typeof window>"u")return;const e=window.getSelection();if(!e||e.rangeCount===0)return;const n=e.anchorNode;if(!n)return;const s=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!s)return;const r=s.closest(".protyle-title");if(!!(r||s.closest(".protyle-content")&&!s.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(s);if(d&&this.activeCursorBlockId!==d){const h=r||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),p=h==null?void 0:h.querySelector(".protyle-title__input"),f=((p==null?void 0:p.innerText)||(h==null?void 0:h.innerText)||"").trim();this.switchToDocGlobalInspector(d,f)}return}if(!s.closest(".protyle-wysiwyg"))return;const o=s.closest("[data-node-id]"),a=o==null?void 0:o.getAttribute("data-node-id"),c=(o==null?void 0:o.getAttribute("data-type"))||"";o&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(s)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Bs(a)),this.syncInspectorBlock(o,a,c))}async syncInspectorBlock(e,n,s){var x,q,y,U,et,j,it,V,Z,E;let r=e,l=n,o=s;const a=e.closest('[data-type="NodeCallout"]');if(a&&a!==e){const D=a.getAttribute("data-node-id");if(D){const ot=await Ge(D).catch(()=>({}))||{},rt=Ht.getBlockAttrOverride(D)||{},st={...ot,...rt};(st[ie]||st["slidev-note"])&&(r=a,l=D,o="NodeCallout")}}const c=o==="NodeThematicBreak",d=o==="NodeCodeBlock",h=((x=r.innerText)==null?void 0:x.trim())||"",p=await Ge(l).catch(()=>({}))||{},f=Ht.getBlockAttrOverride(l)||{},w={...p,...f},m=r.closest(".protyle-wysiwyg > [data-node-id]")||r,k=(m==null?void 0:m.getAttribute("data-node-id"))||l;let v="",b="",T=m.previousElementSibling;for(;T;){const D=T.getAttribute("data-type");if(D==="NodeThematicBreak"||D==="tb"||(q=T.classList)!=null&&q.contains("hr")){v=T.getAttribute("data-node-id")||"";break}T=T.previousElementSibling}if((y=this.latestCompiledDoc)!=null&&y.slides){const D=[l,k];let ot=r.parentElement;for(;ot&&!ot.classList.contains("protyle-wysiwyg");){const st=ot.getAttribute("data-node-id");st&&!D.includes(st)&&D.push(st),ot=ot.parentElement}const rt=this.latestCompiledDoc.slides.find(st=>{var kt,$t,yt;return D.includes(st.startBlockId)||((kt=st.blocks)==null?void 0:kt.some(Y=>D.includes(Y.id)))||(($t=st.allBlockIds)==null?void 0:$t.some(Y=>D.includes(Y)))||((yt=st.noteBlocks)==null?void 0:yt.some(Y=>D.includes(Y.id)))});rt&&(!v&&rt.startBlockId&&(v=rt.startBlockId),!b&&((U=rt.frontmatter)!=null&&U.layout)&&(b=rt.frontmatter.layout))}if(v){const D=Ht.getBlockAttrOverride(v);if(D&&(ut in D||"custom-slidev-layout"in D)&&(b=D[ut]||D["custom-slidev-layout"]||""),!b&&((et=this.latestCompiledDoc)!=null&&et.slides)){const ot=this.latestCompiledDoc.slides.find(rt=>rt.startBlockId===v);(j=ot==null?void 0:ot.frontmatter)!=null&&j.layout&&(b=ot.frontmatter.layout)}if(!b){const ot=await Ge(v).catch(()=>({}))||{};b=ot[ut]||ot["custom-slidev-layout"]||"",ot&&Object.keys(ot).length>0&&Ht.setBlockAttrOverride(v,ot)}se(v,{[ut]:b||""})}else if(this.currentDocId){const D=Ht.getBlockAttrOverride(this.currentDocId);D&&(ut in D||"custom-slidev-layout"in D)?b=D[ut]||D["custom-slidev-layout"]||"":!b&&((E=(Z=(V=(it=this.latestCompiledDoc)==null?void 0:it.slides)==null?void 0:V[0])==null?void 0:Z.frontmatter)!=null&&E.layout)&&(b=this.latestCompiledDoc.slides[0].frontmatter.layout)}const C=r.getAttribute(ut)||r.getAttribute("custom-slidev-layout"),A=w[ut]||w["custom-slidev-layout"]||"";C&&C!==A&&se(l,{[ut]:A});const S=r.getAttribute(qt)||r.getAttribute("custom-slidev-role"),I=w[qt]||w["custom-slidev-role"]||"";S&&S!==I&&se(l,{[qt]:I});const L=r.closest('[data-type="NodeListItem"]');if(L&&L!==r){const D=L.getAttribute("data-node-id");if(D){const ot=await Ge(D).catch(()=>({}))||{},rt=Ht.getBlockAttrOverride(D)||{},st={...ot,...rt},kt=st[ut]||st["custom-slidev-layout"]||"",$t=L.getAttribute(ut)||L.getAttribute("custom-slidev-layout");$t&&$t!==kt&&se(D,{[ut]:kt});const yt=st[qt]||st["custom-slidev-role"]||"",Y=L.getAttribute(qt)||L.getAttribute("custom-slidev-role");Y&&Y!==yt&&se(D,{[qt]:yt})}}const R=!!r.querySelector("img, span[data-type='img']"),N=(r.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),J=R&&N.length<=50;Nn({id:l,rootId:this.currentDocId,type:o,content:h,attrs:w,isDivider:c,isCode:d,isImage:J,topBlockId:k,pageDividerId:v,pageDividerLayout:b})}async compileCurrentDocument(e){var s,r,l,o;let n=e||this.currentDocId;if(!n){const a=document.querySelector(".protyle.layout__wnd--active, .layout__wnd--active .protyle, .protyle"),c=(a==null?void 0:a.getAttribute("data-doc-id"))||((s=a==null?void 0:a.querySelector(".protyle-wysiwyg"))==null?void 0:s.getAttribute("data-doc-id"))||((r=a==null?void 0:a.querySelector(".protyle-title"))==null?void 0:r.getAttribute("data-node-id"))||((l=document.querySelector(".protyle-content[data-doc-id]"))==null?void 0:l.getAttribute("data-doc-id"))||((o=document.querySelector("[data-doc-id]"))==null?void 0:o.getAttribute("data-doc-id"));if(c)this.currentDocId=c,n=c;else return}try{const a=await Ht.compile(n);this.latestCompiledDoc=a,Fv(a,n),this.purgeStaleDomSlidevAttrs(a)}catch(a){console.error("[SiYuanSlidev] Failed to compile document:",a)}}purgeStaleDomSlidevAttrs(e){var r,l,o;if(typeof document>"u"||!e)return;const n=new Map;if(Array.isArray(e.slides))for(const a of e.slides){if(a.startBlockId){const c=n.get(a.startBlockId)||{};(r=a.frontmatter)!=null&&r.layout&&(c[ut]=a.frontmatter.layout),n.set(a.startBlockId,c)}if(Array.isArray(a.blocks)){for(const c of a.blocks)if(c.id){const d=n.get(c.id)||{};(l=c.ial)!=null&&l[ut]&&(d[ut]=c.ial[ut]),(o=c.ial)!=null&&o[qt]&&(d[qt]=c.ial[qt]),Object.keys(d).length>0&&n.set(c.id,d)}}}const s=Ht.getAllAttrOverrides();for(const[a,c]of s.entries()){const d=n.get(a)||{};c[ut]!==void 0&&(d[ut]=c[ut]),c[qt]!==void 0&&(d[qt]=c[qt]),n.set(a,d)}yf(n)}}module.exports=Vv;
