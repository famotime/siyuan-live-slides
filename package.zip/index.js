"use strict";var Ma=Object.create;var Bo=Object.defineProperty;var Da=Object.getOwnPropertyDescriptor;var La=Object.getOwnPropertyNames;var Ra=Object.getPrototypeOf,Pa=Object.prototype.hasOwnProperty;var Oa=(t,i,e)=>i in t?Bo(t,i,{enumerable:!0,configurable:!0,writable:!0,value:e}):t[i]=e;var za=(t,i,e,n)=>{if(i&&typeof i=="object"||typeof i=="function")for(let o of La(i))!Pa.call(t,o)&&o!==e&&Bo(t,o,{get:()=>i[o],enumerable:!(n=Da(i,o))||n.enumerable});return t};var zn=(t,i,e)=>(e=t!=null?Ma(Ra(t)):{},za(i||!t||!t.__esModule?Bo(e,"default",{value:t,enumerable:!0}):e,t));var wt=(t,i,e)=>Oa(t,typeof i!="symbol"?i+"":i,e);const mt=require("siyuan");async function ve(t,i){const e=await mt.fetchSyncPost(t,i);return e.code===0?e.data:null}async function Na(){return ve("/api/notebook/lsNotebooks","")}async function Fa(t,i,e){return ve("/api/filetree/createDocWithMd",{notebook:t,path:i,markdown:e})}async function Er(t,i){const e=new FormData;e.append("assetsDirPath",t);for(const o of i)e.append("file[]",o);return ve("/api/asset/upload",e)}async function rn(t,i,e,n,o){return ve("/api/block/insertBlock",{dataType:t,data:i,nextID:e,previousID:n,parentID:o})}async function Mr(t,i,e){return ve("/api/block/appendBlock",{dataType:t,data:i,parentID:e})}async function Hs(t,i,e){return ve("/api/block/updateBlock",{dataType:t,data:i,id:e})}async function ja(t){return ve("/api/block/deleteBlock",{id:t})}async function Ha(t){return ve("/api/block/getBlockKramdown",{id:t})}async function Xn(t){return ve("/api/block/getChildBlocks",{id:t})}async function Rt(t,i){return ve("/api/attr/setBlockAttrs",{id:t,attrs:i})}async function Ge(t){return ve("/api/attr/getBlockAttrs",{id:t})}async function vn(t){return ve("/api/query/sql",{stmt:t})}async function Ko(t,i,e){const n=new FormData;return n.append("path",t),n.append("isDir",i.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",e),ve("/api/file/putFile",n)}async function Dr(t){const i="/api/ai/chatGPT";try{const e=await ve(i,{msg:t});return typeof e=="string"&&e.trim().length>0?e.trim():e&&typeof e.content=="string"&&e.content.trim().length>0?e.content.trim():null}catch{return null}}async function Ua(){return ve("/api/storage/getInlineStyles","")}const Lr=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function Wa(t){const i=[];if(!t)return i;const e=new RegExp(Lr.source,"g");let n;for(;(n=e.exec(t))!==null;){const o=n[2]??n[3]??n[4];i.push({fullMatch:n[0],blockId:n[1],anchorText:o?o.trim():void 0})}return i}function Va(t,i){if(!t)return"";const e=new RegExp(Lr.source,"g");return t.replace(e,(n,o,s,l,r)=>{const a=(s??l??r??"").trim();if(i&&i[o]){const d=i[o].trim();return`<div class="slidev-block-ref" data-ref-id="${o}">${d}</div>`}const c=a||`Ref(${o.slice(0,8)})`;return`<a href="siyuan://blocks/${o}" data-ref-id="${o}" class="slidev-ref-tag">🔗 ${c}</a>`})}const bn="custom-slidev-theme",yn="custom-slidev-aspect-ratio",Rr="custom-slidev-highlighter",kn="custom-slidev-default-transition",Pr="custom-slidev-color-schema",qo="custom-slidev-spacing",$i="custom-slidev-slide",dt="custom-slidev-layout",Qt="custom-slidev-transition",Ht="custom-slidev-background",Be="custom-slidev-image",Fi="custom-slidev-notes",ji="custom-slidev-class",cn="custom-slidev-spacing",Zt="custom-slidev-layout-ratio",$e="custom-slidev-click",We="custom-slidev-motion",Di="custom-slidev-shiki-lines",Tt="custom-slidev-slot",se="custom-slidev-note",Vt="custom-slidev-role",wn="custom-slidev-max-height",Ii="custom-slidev-autoplay",Qn="custom-slidev-loop",Ni="custom-slidev-muted",to="custom-slidev-controls",Or="background",eo="image-left",io="image-right";function cs(t){return t==="cols-header"||t==="two-cols-header"||t==="three-cols-header"}function Ka(t){return t.markdown&&t.markdown.trim()?t.markdown.trim():t.content&&t.content.trim()?t.content.trim():""}function qa(t){const i={};if(!t)return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(e))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";i[s]=l}return i}function Ga(t){if(!t)return!1;const i=t.trim();return i.startsWith("assets/")||i.startsWith("./assets/")||i.startsWith("/assets/")}function Za(t){const i=t.trim();return i.startsWith("./assets/")?i.slice(2):i.startsWith("/assets/")?i.slice(1):i}function Ce(t,i){if(!Ga(t))return t;const e=Za(t);return i!=null&&i.base64Map&&i.base64Map[e]?i.base64Map[e]:i!=null&&i.baseUrl?`${i.baseUrl.replace(/\/+$/,"")}/${e}`:`/${e}`}function Ya(t,i){if(!t)return"";let e=t;return e=e.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,o,s)=>{const l=Ce(s,i);return`![${o}](${l})`}),e=e.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,o,s,l)=>{const r=Ce(s,i);return`${o}${r}${l}`}),e=e.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,o,s,l)=>{const r=Ce(s,i);return`${o}${r}${l}`}),e}const ki={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal"};function Ja(t){var i,e,n,o,s,l;return t?{theme:((i=t[bn])==null?void 0:i.trim())||ki.theme,aspectRatio:((e=t[yn])==null?void 0:e.trim())||ki.aspectRatio,highlighter:((n=t[Rr])==null?void 0:n.trim())||ki.highlighter,defaultTransition:((o=t[kn])==null?void 0:o.trim())||ki.defaultTransition,colorSchema:((s=t[Pr])==null?void 0:s.trim())||ki.colorSchema,spacing:((l=t[qo])==null?void 0:l.trim())||ki.spacing}:{...ki}}function no(t){var e,n,o,s,l;const i=(e=t.ial)==null?void 0:e[$i];return!!(i&&(i==="true"||i==="page"||i==="cover"||i==="end")||t.type==="tb"||t.type==="thematic-break"||t.type==="NodeThematicBreak"||((n=t.markdown)==null?void 0:n.trim())==="---"||((o=t.markdown)==null?void 0:o.trim())==="***"||t.type==="b"&&(((s=t.markdown)==null?void 0:s.trim())==="---"||((l=t.content)==null?void 0:l.trim())==="---"))}function Us(t){const i={};let e="";if(!t)return{frontmatter:i,notes:e};t[dt]&&(i.layout=t[dt].trim()),t[Qt]&&(i.transition=t[Qt].trim()),t[Ht]&&(i.background=t[Ht].trim()),t[Be]&&(i.image=t[Be].trim()),t[ji]&&(i.class=t[ji].trim()),t[cn]&&(i.spacing=t[cn].trim()),t[Zt]&&(i.layoutRatio=t[Zt].trim()),t[Fi]&&(e=t[Fi].trim());for(const[n,o]of Object.entries(t))if(n.startsWith("custom-slidev-")&&![dt,Zt,Qt,Ht,Be,ji,cn,Fi,$i].includes(n)){const s=n.replace(/^custom-slidev-/,"");try{i[s]=JSON.parse(o)}catch{i[s]=o}}return{frontmatter:i,notes:e}}function Xa(t){const i={};if(!t)return i;const e=t[se]??t["slidev-note"];e!=null&&e!==""&&e!=="false"&&e!=="0"&&(i.isNote=!0);const n=t[Vt]??t["slidev-role"],o=t[Ht]??t["slidev-background"];(n===Or||o==="true"||o==="1")&&(i.isBackground=!0);const s=t[dt]??t["slidev-layout"];s===eo||s===io?i.imageLayout=s:(n===eo||n===io)&&(i.imageLayout=n);const l=t[$e]??t["custom-slidev-clicks"]??t["slidev-click"]??t["slidev-clicks"];if(l!=null&&(i.clicks=l.trim()),t[We])try{const r=JSON.parse(t[We]);typeof r=="object"&&r!==null?i.motion={preset:r.preset||r.type||"fade-in",...r}:i.motion={preset:String(r).trim()}}catch{i.motion={preset:t[We].trim()}}return t[Di]&&(i.shikiLines=t[Di].trim()),t[wn]&&(i.maxHeight=t[wn].trim()),t[Tt]&&(i.slot=t[Tt].trim()),t.style&&t.style.trim()&&(i.style=t.style.trim()),i}function mi(t,i){const e=(t||i||"").trim();if(!e)return null;const n=e.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const o=e.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(o)return o[1].trim();const s=e.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(s)?s:null}function zr(t){if(!t)return"";const i=t.split(/\r?\n/);if(i.length===0)return"";const e=i[0],n=e.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return t;const o=n[1].length,s=n[2].trim(),l=e.length-n[2].length;if(i.length===1)return s;const r=[s];for(let a=1;a<i.length;a++){const c=i[a];if(!c.trim()){r.push("");continue}const d=c.match(/^(\s*)/),u=d?d[1].length:0;u>=l?r.push(c.slice(l)):u>o?r.push(c.slice(u)):r.push(c)}return r.join(`
`)}function xn(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="i"||i==="nodelistitem"||i==="l"||i==="nodelist")return!0;const e=(t.markdown||t.rawMarkdown||t.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(e)}function Eo(t,i=2){if(!t||typeof t!="string")return`repeat(${i}, 1fr)`;const e=t.trim();if(!e)return`repeat(${i}, 1fr)`;if(e.includes(":")){const o=e.split(":").map(s=>parseFloat(s.trim())).filter(s=>!isNaN(s)&&s>0);if(o.length>=2)return o.map(s=>`${s}fr`).join(" ")}const n=e.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${i}, 1fr)`}function dn(t){if(!t)return[];if(oe(t)&&ii(t)&&!gi(t)){const n=Bn(t),o=[];for(const s of n)o.push(...dn(s));return o}const i=(t.type||"").toLowerCase();if(i==="l"||i==="nodelist"||i==="list"){if(t.children&&t.children.length>0){const l=t.children.filter(xn);if(l.length>0)return l}const o=(t.markdown||t.content||"").trim().split(/\r?\n/),s=[];for(let l=0;l<o.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(o[l])&&s.push(l);if(s.length>=2){const l=[];for(let r=0;r<s.length;r++){const a=s[r],c=r+1<s.length?s[r+1]:o.length,d=o.slice(a,c).join(`
`);l.push({id:`${t.id}-item-${r+1}`,type:"i",markdown:d,content:d,ial:{...t.ial||{}}})}return l}}return xn(t)?[t]:[]}function Nr(t){var o;if(!t||!oe(t)||!ii(t)||gi(t))return null;const i=Bn(t);if(i.length===0)return null;if(i.length===1&&oe(i[0])&&ii(i[0])){const s=Nr(i[0]);return s?{items:s.items,nestedSuperBlocks:[i[0],...s.nestedSuperBlocks]}:null}const e=[];for(const s of i)if(oe(s)){e.push(s);const l=((o=s.children)==null?void 0:o.filter(oe))||[];e.push(...l)}const n=i.map(dn);if(n.length>=2&&n.every(s=>s.length>0)){const s=n.flat();if(s.length>=2&&s.length<=6)return{items:s,nestedSuperBlocks:e}}if(i.length===2){const s=dn(i[0]),l=dn(i[1]);if(s.length+l.length>=2&&s.length+l.length<=6&&(s.length>0||l.length>0))return{items:[...s,...l],nestedSuperBlocks:e}}return null}function Qa(t){if(!t||!oe(t)||!ii(t)||gi(t))return null;const i=Nr(t);if(!i)return null;const{items:e,nestedSuperBlocks:n}=i;if(e.length<2||e.length>6)return null;const o=ds(t)||void 0,s=e.length;return{superBlockNode:t,nestedSuperBlocks:n,count:s,layout:"cols-header",items:e,slots:e.map((l,r)=>`col-${r+1}`),ratio:o}}function tc(t){if(!t||!oe(t)||!ii(t)||gi(t))return null;const i=Bn(t);if(i.length===0)return null;const e=[];for(const n of i){const o=dn(n);if(o.length===0)return null;e.push(...o)}return e}function ec(t){if(!t||!oe(t)||!ii(t)||gi(t))return null;const i=tc(t);return!i||i.length===0||i.length>=2&&i.length<=6?null:{superBlockNode:t,items:i}}function ic(t,i,e){var d,u,v,f,k,p;const n=[],o=[],s=(e==null?void 0:e.tracked)||[],l=[];let r={pageTargetId:t,blocks:[]};l.push(r);for(let b=0;b<i.length;b++){const y=i[b];if(no(y)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=y.id,r.blocks.push(y);continue}r={pageTargetId:y.id,blocks:[y]},l.push(r)}else r.blocks.push(y)}function a(b){const y=[];for(const x of b)oe(x)&&y.push(x),x.children&&x.children.length>0&&y.push(...a(x.children));return y}function c(b,y,x){const _={blockId:b,attrs:y,previousAttrs:x};n.push(_),e!=null&&e.onTagChange&&e.onTagChange(_)}for(const b of l){const y=b.pageTargetId,x=i.find(w=>w.id===y),_=s.find(w=>w.pageTargetId===y);if(b.blocks.some(w=>{var L,B;return!!(gi(w)||Go(w)&&(((L=w.ial)==null?void 0:L[dt])==="image-left"||((B=w.ial)==null?void 0:B[dt])==="image-right"))})){if(_){const w=_.headerId;if(w){c(w,{[Tt]:""});const L=i.find(B=>B.id===w);L!=null&&L.ial&&(L.ial[Tt]="")}for(const L of _.itemIds){c(L,{[Tt]:""});const B=i.find(N=>N.id===L);B!=null&&B.ial&&(B.ial[Tt]="")}}continue}let I=null,T=-1;for(let w=0;w<b.blocks.length;w++){const L=b.blocks[w],B=oe(L)?[L,...a(L.children||[])]:L.children?a(L.children):[];for(const N of B){const Z=Qa(N);if(Z){I=Z,T=w;break}}if(I)break}if(I){const{superBlockNode:w,layout:L,items:B,slots:N}=I,$=b.blocks.slice(0,T).find(F=>oc(F)),U=$==null?void 0:$.id,m=((d=x==null?void 0:x.ial)==null?void 0:d[dt])||"";m!==L&&(c(y,{[dt]:L},{[dt]:m}),x&&(x.ial||(x.ial={}),x.ial[dt]=L));const K=((u=x==null?void 0:x.ial)==null?void 0:u[Zt])||"",E=I.ratio;if(!K&&E&&(c(y,{[Zt]:E}),x&&(x.ial||(x.ial={}),x.ial[Zt]=E)),$){const F=((v=$.ial)==null?void 0:v[Tt])||"";F!=="header"&&(c($.id,{[Tt]:"header"},{[Tt]:F}),$.ial||($.ial={}),$.ial[Tt]="header")}if(_!=null&&_.headerId&&_.headerId!==U){c(_.headerId,{[Tt]:""});const F=i.find(O=>O.id===_.headerId);F&&(F.ial||(F.ial={}),F.ial[Tt]="")}const M=[];for(let F=0;F<B.length;F++){const O=B[F],J=N[F];M.push(O.id);const j=((f=O.ial)==null?void 0:f[Tt])||"";if(j!==J&&(c(O.id,{[Tt]:J},{[Tt]:j}),O.ial||(O.ial={}),O.ial[Tt]=J),O.children&&O.children.length>0)for(const q of O.children)q.ial||(q.ial={}),q.ial[Tt]!==J&&(q.ial[Tt]=J)}if(_!=null&&_.itemIds){for(const F of _.itemIds)if(!M.includes(F)){c(F,{[Tt]:""});const O=i.find(J=>J.id===F);O&&(O.ial||(O.ial={}),O.ial[Tt]="")}}o.push({superBlockId:w.id,nestedSuperBlockIds:(k=I.nestedSuperBlocks)==null?void 0:k.map(F=>F.id),pageTargetId:y,headerId:U,itemIds:M,layout:L})}else{let w=!1;const L=[];for(const Z of b.blocks){const $=oe(Z)?[Z,...a(Z.children||[])]:Z.children?a(Z.children):[];for(const U of $){const m=ec(U);if(m){w=!0;for(const K of m.items)L.push(K.id)}}}const B=((p=x==null?void 0:x.ial)==null?void 0:p[dt])||"",N=cs(B);if(_||w&&N){c(y,{[dt]:""},{[dt]:B}),x&&(x.ial||(x.ial={}),x.ial[dt]="");const Z=_==null?void 0:_.headerId;if(Z){c(Z,{[Tt]:""});const U=i.find(m=>m.id===Z);U&&(U.ial||(U.ial={}),U.ial[Tt]="")}const $=new Set([...(_==null?void 0:_.itemIds)||[],...L]);for(const U of $){c(U,{[Tt]:""});const m=i.find(K=>K.id===U);m&&(m.ial||(m.ial={}),m.ial[Tt]="")}}}}return{changes:n,newTracked:o}}function oe(t){if(!t)return!1;const i=(t.type||"").toLowerCase();return i==="s"||i==="sb"||i==="nodesuperblock"}function ii(t){if(!oe(t))return!1;const i=(t.subType||"").toLowerCase();if(i==="col"||i==="h"||i==="horizontal")return!0;if(i==="row"||i==="v"||i==="vertical")return!1;if(t.ial){const n=(t.ial["data-sb-layout"]||t.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(t.children&&t.children.length>0){for(const n of t.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const o=(n.content||n.markdown||"").trim().toLowerCase();if(o==="col"||o==="h")return!0;if(o==="row"||o==="v")return!1}}const e=(t.markdown||t.content||"").trim();return/^\{\{\{col\b/i.test(e)?!0:!/^\{\{\{row\b/i.test(e)}function Go(t){return!t||xn(t)||oe(t)||!mi(t.markdown,t.content)?!1:(t.markdown||t.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function ds(t){var v;if(!t||!oe(t)||!ii(t))return null;const i=Bn(t);if(!i||i.length<2)return null;const e=[];let n=!1;for(const f of i){const k=(((v=f.ial)==null?void 0:v.style)||f.style||"").trim();let p=null;if(k){const b=k.match(/calc\(\s*([\d.]+)%/i);if(b)p=parseFloat(b[1]);else{const y=k.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);y&&(p=parseFloat(y[1]))}}p!==null&&!isNaN(p)&&p>0?(e.push(p),n=!0):e.push(null)}if(!n)return null;const o=i.length,s=e.reduce((f,k)=>f+(k||0),0),l=e.filter(f=>f===null).length,r=Math.max(0,100-s),a=l>0?r/l:100/o,c=e.map(f=>f!==null?f:a),d=c.reduce((f,k)=>f+k,0);if(d<=0)return null;const u=c.map(f=>f/d*100);if(u.length===2){const[f]=u;if(f>=48&&f<=52)return"1:1";if(f>=31&&f<=35)return"1:2";if(f>=65&&f<=69)return"2:1";if(f>=28&&f<=32)return"3:7";if(f>=68&&f<=72)return"7:3";if(f>=38&&f<=42)return"4:6";if(f>=58&&f<=62)return"6:4";if(f>=23&&f<=27)return"1:3";if(f>=73&&f<=77)return"3:1";const k=Math.round(f),p=100-k;return`${k}:${p}`}if(u.length===3){const[f,k,p]=u;if(f>=31&&f<=35&&k>=31&&k<=35&&p>=31&&p<=35)return"1:1:1";if(f>=23&&f<=27&&k>=48&&k<=52&&p>=23&&p<=27)return"1:2:1";if(f>=48&&f<=52&&k>=23&&k<=27&&p>=23&&p<=27)return"2:1:1";if(f>=23&&f<=27&&k>=23&&k<=27&&p>=48&&p<=52)return"1:1:2";if(f>=18&&f<=22&&k>=58&&k<=62&&p>=18&&p<=22)return"1:3:1";const b=Math.round(f),y=Math.round(k),x=100-b-y;return`${b}:${y}:${x}`}return u.map(f=>Math.round(f)).join(":")}function gi(t){if(!t||!oe(t)||!ii(t))return null;const i=(t.children||[]).filter(s=>{const l=s.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(i.length<2)return null;const e=Go(i[0]),n=Go(i[i.length-1]),o=ds(t)||void 0;if(e&&!n){const s=mi(i[0].markdown,i[0].content);if(s)return{imageNode:i[0],imageUrl:s,layout:eo,contentNodes:i.slice(1),ratio:o}}if(!e&&n){const s=mi(i[i.length-1].markdown,i[i.length-1].content);if(s)return{imageNode:i[i.length-1],imageUrl:s,layout:io,contentNodes:i.slice(0,i.length-1),ratio:o}}return null}function nc(t,i){const e=[];function n(o){for(const s of o){const l=gi(s);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const d=r.ial[dt],u=r.ial[Zt],v=d!==a,f=!u&&!!c;if(v||f){const k={blockId:r.id,layout:a,previousLayout:d,ratio:c||u};r.ial[dt]=a,f&&c&&(r.ial[Zt]=c),e.push(k),i&&i(k)}}s.children&&s.children.length>0&&n(s.children)}}return n(t),e}function Bn(t){return(t.children||[]).filter(i=>{const e=i.type||"";if(e==="NodeSuperBlockOpenMarker"||e==="NodeSuperBlockLayoutMarker"||e==="NodeSuperBlockCloseMarker"||e==="open-marker"||e==="layout-marker"||e==="close-marker")return!1;const n=(i.markdown||i.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function oc(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="h"||i==="nodeheading"||/^h[1-6]$/i.test(t.subType||""))return!0;const e=(t.markdown||t.content||"").trim();return!!/^#{1,6}\s+/.test(e)}function wi(t,i,e){let n="",o=0;const s=/<div\b([^>]*)>/gi;for(;o<t.length;){s.lastIndex=o;let l,r=!1,a=-1,c=0;for(;(l=s.exec(t))!==null;){const y=l[1].match(/\bclass=["']([^"']*)["']/i);if(y){const x=y[1];if(typeof i=="string"?x.split(/\s+/).includes(i):i.test(x)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){n+=t.slice(o);break}n+=t.slice(o,a);const d=a+c;let u=1,v=-1,f=-1;const k=/<\/?div\b[^>]*>/gi;k.lastIndex=d;let p;for(;(p=k.exec(t))!==null;)if(p[0].startsWith("</")){if(u--,u===0){v=p.index,f=p.index+p[0].length;break}}else u++;if(v!==-1&&f!==-1){const b=t.slice(d,v);n+=e(b),o=f}else n+=t.slice(a,d),o=d}return n}function sc(t){const i=[];let e="",n=0;const o=/<div\b([^>]*)>/gi;for(;n<t.length;){o.lastIndex=n;let s,l=!1,r=-1,a=0;for(;(s=o.exec(t))!==null;){const p=s[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(p)){l=!0,r=s.index,a=s[0].length;break}}if(!l){e+=t.slice(n);break}e+=t.slice(n,r);const c=r+a;let d=1,u=-1,v=-1;const f=/<\/?div\b[^>]*>/gi;f.lastIndex=c;let k;for(;(k=f.exec(t))!==null;)if(k[0].startsWith("</")){if(d--,d===0){u=k.index,v=k.index+k[0].length;break}}else d++;if(u!==-1&&v!==-1){const p=t.slice(r,v),b=`__VUE_DIV_TOKEN_${i.length}__`;i.push(p),e+=b,n=v}else e+=t.slice(r,c),n=c}return{text:e,tokens:i}}function rc(t){const i=[];let e=t.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(r),a});e=e.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(r),a});const n=[];e=e.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),a});const{text:o,tokens:s}=sc(e);e=o;const l=[];e=e.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),e=e.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),e=e.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),e=e.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),e=e.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),e=e.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),e=e.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),e=e.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),e=e.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),e=e.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),e=e.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),e=e.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),e=e.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),e=e.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),e=e.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=wi(e,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),u=c[3].trim();return`**${d}:**
\`\`\`yaml
${u}
\`\`\``}).join(`

`)+`
`:r}),e=wi(e,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:r}),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),e=wi(e,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let u="-";return d.includes("warn")?u="- ⚠️":d.includes("bad")?u="- ❌":d.includes("ok")&&(u="- ✅"),`${u} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),e=wi(e,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const v=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${v}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),e=wi(e,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),e=wi(e,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),e=wi(e,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),e=e.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),e=e.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=e.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),e=e.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),e=e.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),e=e.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),e=e.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),e=e.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),e=e.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),e=e.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),e=e.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),e=e.replace(/<br\s*\/?>/gi,`
`),e=e.replace(/<hr\s*\/?>/gi,`
---
`),e=e.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),e=e.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),e=e.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),e=e.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((u,v)=>Math.max(u,v.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),e=e.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),e=e.replace(/\*{4}/g,"** **"),e=e.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),e=e.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),e=e.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,d,u)=>{const v=u.trim();return v.includes("<")||v.includes(`
`)?r:`[${v}](${c})`}),e=e.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),e=e.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),e=e.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),e=e.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),e=e.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),e=e.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)e=e.replace(`__VUE_COMP_TOKEN_${r}__`,l[r]);for(let r=0;r<s.length;r++)e=e.replace(`__VUE_DIV_TOKEN_${r}__`,s[r]);for(let r=0;r<n.length;r++)e=e.replace(`__SCRIPT_TOKEN_${r}__`,n[r]);for(let r=0;r<i.length;r++)e=e.replace(`__CODE_TOKEN_${r}__`,i[r]);return e=e.replace(/\n{3,}/g,`

`).trim(),e}function Fr(t){if(!t||typeof t!="string")return"";const i=[];let e=t.replace(/`([^`]+)`/g,n=>(i.push(n),`%%INLINE_CODE_${i.length-1}%%`));return e=e.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),e=e.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),e=e.replace(/\{:[^}]*\}/g,""),e=e.replace(/%%INLINE_CODE_(\d+)%%/g,(n,o)=>i[parseInt(o,10)]||""),e}function lc(t){const i=Object.entries(t).filter(([n,o])=>o!=null&&o!=="");return i.length===0?"":`---
${i.map(([n,o])=>typeof o=="string"?o.includes(":")||o.includes(`
`)||o.includes("#")?`${n}: "${o.replace(/"/g,'\\"')}"`:`${n}: ${o}`:`${n}: ${JSON.stringify(o)}`).join(`
`)}
---`}function ac(t,i){if(!i||!t.startsWith("```"))return t;const e=t.indexOf(`
`);if(e===-1)return t;const n=t.slice(0,e).trim(),o=t.slice(e);return n.includes("{")?t:`${n} {${i}}${o}`}function cc(t,i){if(i==null)return t;const e=i.trim();return e===""||e==="+1"?`<v-click>

${t}

</v-click>`:e==="hide"?`<v-click hide>

${t}

</v-click>`:`<v-click at="${e}">

${t}

</v-click>`}function dc(t){if(!t||!t.preset)return null;const i=t.preset.toLowerCase().trim();if(!i||i==="none")return null;let e={opacity:0},n={opacity:1};switch(i){case"slide-up":e={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":e={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":e={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":e={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":e={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":e={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:e={opacity:0},n={opacity:1};break}t.initial&&typeof t.initial=="object"&&(e={...e,...t.initial}),t.enter&&typeof t.enter=="object"&&(n={...n,...t.enter});const o={...n.transition||{}};return typeof t.duration=="number"&&t.duration>0&&(o.duration=t.duration),typeof t.delay=="number"&&t.delay>0&&(o.delay=t.delay),Object.keys(o).length>0&&(n.transition=o),{initial:e,enter:n}}function Ws(t,i,e,n){const o=i!=null&&i.trim()!=="",s=dc(e),l=n==null?void 0:n.trim(),r=l!==void 0&&l!=="",a=r?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!s)return r?`<div${a}>

${t}

</div>`:t;if(o&&!s){if(r){const k=i.trim();let p="v-click";return k==="hide"?p="v-click.hide":k!==""&&k!=="+1"&&(p=`v-click="${k}"`),`<div ${p}${a}>

${t}

</div>`}return cc(t,i)}const c=JSON.stringify(s.initial).replace(/"/g,"'"),d=JSON.stringify(s.enter).replace(/"/g,"'"),u=`v-motion :initial="${c}" :enter="${d}"`;if(!o)return`<div ${u}${a}>

${t}

</div>`;const v=i.trim();let f="v-click";return v==="hide"?f="v-click.hide":v!==""&&v!=="+1"&&(f=`v-click="${v}"`),`<div ${f} ${u}${a}>

${t}

</div>`}function jr(t){if(!t)return"";let i=t.trim();i=i.replace(/\{:[^}]*\}/g,"").trim(),i=i.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),i=i.replace(/\r?\n?:::\s*$/g,"");let o=i.split(/\r?\n/).map(s=>s.trim().replace(/^>\s*/,"")).join(`
`).trim();return o=o.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),o=o.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),o=o.replace(/^[-*+]\s+/,""),o=o.replace(/^\d+\.\s+/,""),o.trim()}function uc(t){var n;if(t.subType&&/^h([1-6])$/i.test(t.subType))return parseInt(t.subType.slice(1),10);const e=(t.markdown||t.content||"").trim().match(/^(#{1,6})\s+/);return e?e[1].length:t.type==="h"?(n=t.ial)!=null&&n.subType&&/^h([1-6])$/i.test(t.ial.subType)?parseInt(t.ial.subType.slice(1),10):1:null}function Hr(t,i=2){const e=Math.max(2,i);if(!t||t.length===0)return Array.from({length:e},()=>[]);if(t.length===1&&t[0].children&&t[0].children.length>=2){const c=t[0].children,d=Array.from({length:e},()=>[]),u=Math.min(e,c.length),v=Math.floor(c.length/u),f=c.length%u;let k=0;for(let p=0;p<u;p++){const b=v+(p<f?1:0);d[p]=c.slice(k,k+b),k+=b}return d}const n=c=>{const d=(c.slot||"").trim();if(!d)return null;if(d==="left")return 1;if(d==="center")return 2;if(d==="right")return e===2?2:e;const u=d.match(/^col-(\d+)$/i);if(u){const v=parseInt(u[1],10);if(v>=1&&v<=e)return v}return null},o=t.map(n);if(o.some(c=>c!==null)){if(o.some(f=>f!==null&&f>=2)){const f=Array.from({length:e},()=>[]);let k=1;for(const p of t){const b=n(p);b!==null&&(k=b),f[k-1].push(p)}return f}const d=t.filter(f=>n(f)===1),u=t.filter(f=>n(f)===null),v=e-1;if(u.length>=v){const f=Math.floor(u.length/v),k=u.length%v,p=[d];let b=0;for(let y=0;y<v;y++){const x=f+(y<k?1:0);p.push(u.slice(b,b+x)),b+=x}return p}else if(u.length>0){const f=[d];for(let k=0;k<v;k++)f.push(k<u.length?[u[k]]:[]);return f}else return[d,...Array.from({length:v},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const d=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(d)},r=t.map((c,d)=>l(c)?d:-1).filter(c=>c!==-1);if(r.length>=e){const c=Array.from({length:e},()=>[]);for(let d=0;d<e;d++){const u=r[d],v=d+1<e?r[d+1]:t.length;c[d]=t.slice(u,v)}return c}if(t.length>=e){const c=Array.from({length:e},()=>[]);let d=0;for(let u=0;u<e;u++){const v=e-u,f=t.length-d,k=Math.ceil(f/v);c[u]=t.slice(d,d+k),d+=k}return c}if(t.length>1&&t.length<e){const c=Array.from({length:e},()=>[]);for(let d=0;d<t.length;d++)c[d]=[t[d]];return c}if(t.length===1){const c=t[0],d=(c.rawMarkdown||c.content||"").trim(),u=d.split(/\r?\n/),v=[];for(let p=0;p<u.length;p++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(u[p])&&v.push(p);if(v.length>=e){const p=Array.from({length:e},()=>[]);let b=0;for(let y=0;y<e;y++){const x=e-y,_=v.length-b,A=Math.ceil(_/x),I=v[b],T=b+A<v.length?v[b+A]:u.length,w=u.slice(I,T).join(`
`);p[y]=[{...c,id:y===0?c.id:`${c.id}-col${y+1}`,rawMarkdown:w,content:w}],b+=A}return p}const f=d.match(/<li[\s\S]*?<\/li>/gi);if(f&&f.length>=e){const p=Array.from({length:e},()=>[]);let b=0;for(let y=0;y<e;y++){const x=e-y,_=f.length-b,A=Math.ceil(_/x),I=`<ul>
${f.slice(b,b+A).join(`
`)}
</ul>`;p[y]=[{...c,id:y===0?c.id:`${c.id}-col${y+1}`,rawMarkdown:I,content:I}],b+=A}return p}const k=d.split(/\r?\n\s*\r?\n/).filter(p=>p.trim()!=="");if(k.length>=e){const p=Array.from({length:e},()=>[]);let b=0;for(let y=0;y<e;y++){const x=e-y,_=k.length-b,A=Math.ceil(_/x),I=k.slice(b,b+A).join(`

`);p[y]=[{...c,id:y===0?c.id:`${c.id}-col${y+1}`,rawMarkdown:I,content:I}],b+=A}return p}}const a=Array.from({length:e},()=>[]);return a[0]=t,a}function Vs(t,i,e,n){var d;const o=Ja(i),s=[],l=Us(i);let r={pageIndex:1,startBlockId:t,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[t]};r.frontmatter.background&&(r.frontmatter.background=Ce(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ce(r.frontmatter.image,n)),s.push(r);let a=[];for(const u of e){if(no(u)){a=[];const f=Us(u.ial);if(s.length===1&&r.blocks.length===0){r.startBlockId=u.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(u.id)||r.allBlockIds.push(u.id),f.frontmatter.layout&&(r.frontmatter.layout=f.frontmatter.layout),Object.assign(r.frontmatter,f.frontmatter),!f.frontmatter.image&&l.frontmatter.image&&(r.frontmatter.image=l.frontmatter.image),!f.frontmatter.background&&l.frontmatter.background&&(r.frontmatter.background=l.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=Ce(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ce(r.frontmatter.image,n));continue}r={pageIndex:s.length+1,startBlockId:u.id,frontmatter:{layout:f.frontmatter.layout||"default",...f.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[u.id]},r.frontmatter.background&&(r.frontmatter.background=Ce(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ce(r.frontmatter.image,n)),s.push(r);continue}const v=f=>{var U;if(r.allBlockIds||(r.allBlockIds=[]),f.id&&!r.allBlockIds.includes(f.id)&&r.allBlockIds.push(f.id),f.children&&f.children.length>0){const m=K=>{for(const E of K)E.id&&!r.allBlockIds.includes(E.id)&&r.allBlockIds.push(E.id),E.children&&E.children.length>0&&m(E.children)};m(f.children)}let k=Ka(f),p=f.ial?{...f.ial}:{};const b=k.match(/\{:\s*([^}]+)\s*\}\s*$/);b&&(p={...qa(b[0]),...p},k=k.slice(0,b.index).trim()),f.type!=="c"&&!k.startsWith("```")&&(k=Fr(k));let y=k.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(y)||y==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(y)&&/\r?\n\}\}\}$/.test(y)&&(k=y.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),y=k.trim());const x=Xa(p);if(k=Ya(k,n),k=Va(k,n==null?void 0:n.refContentMap),f.children&&f.children.length>0){const m=K=>{for(const E of K){if(E.ial)for(const[M,F]of Object.entries(E.ial))M.startsWith("custom-slidev-")&&!p[M]&&(p[M]=F);E.children&&E.children.length>0&&m(E.children)}};m(f.children)}const _=f.type==="video"||f.type==="NodeVideo"||/<video\b/i.test(k);if(_){const m=p["custom-slidev-autoplay"]==="true",K=p["custom-slidev-loop"]==="true",E=p["custom-slidev-muted"]==="true"||m,M=p["custom-slidev-controls"]==="false";k=k.replace(/<video\b([^>]*)>/gi,(F,O)=>{let J=O;return M?J=J.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(J)||(J+=" controls"),m&&!/autoplay/i.test(J)?J+=" autoplay playsinline":!m&&p["custom-slidev-autoplay"]==="false"&&(J=J.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),K&&!/loop/i.test(J)?J+=" loop":!K&&p["custom-slidev-loop"]==="false"&&(J=J.replace(/\bloop\b/gi,"").trim()),E&&!/muted/i.test(J)?J+=" muted":!E&&p["custom-slidev-muted"]==="false"&&(J=J.replace(/\bmuted\b/gi,"").trim()),`<video ${J.trim()}>`})}if(x.isBackground){const m=mi(k,f.content);if(m){r.frontmatter.background=Ce(m,n);return}}const A=gi(f);if(A){r.frontmatter.layout=A.layout,r.frontmatter.image=Ce(A.imageUrl,n),!r.frontmatter.layoutRatio&&A.ratio&&(r.frontmatter.layoutRatio=A.ratio);for(const m of A.contentNodes)v(m);return}if(x.imageLayout==="image-left"||x.imageLayout==="image-right"){const m=mi(k,f.content);if(m){r.frontmatter.layout=x.imageLayout,r.frontmatter.image=Ce(m,n),!r.frontmatter.layoutRatio&&((U=f.ial)!=null&&U[Zt])&&(r.frontmatter.layoutRatio=f.ial[Zt]);return}}if(oe(f)&&f.children&&f.children.length>0){for(const m of f.children)v(m);return}if((f.type==="l"||f.type==="NodeList"||f.type==="list")&&f.children&&f.children.length>0&&(f.children.some(m=>{var K;return(K=m.ial)==null?void 0:K[Tt]})||x.slot)){for(const m of f.children)x.slot&&(!m.ial||!m.ial[Tt])&&(m.ial||(m.ial={}),m.ial[Tt]=x.slot),v(m);return}if(x.isNote){const m=jr(k);m&&(r.notes?r.notes+=`

`+m:r.notes=m),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:f.id,type:f.type,content:m||f.content||"",rawMarkdown:k,isNote:!0,attributes:f.ial});return}x.shikiLines&&(k=ac(k,x.shikiLines)),y=k.trim();const I=(f.content||"").trim();if(y==="::right::"||I==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(y)||y.startsWith("::right::")){r.blocks.push({id:f.id,type:f.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:f.ial});return}const w=uc(f);let L=x.slot,B=x.clicks,N=x.motion,Z={...f.ial||{}};if(w!==null){for(;a.length>0&&a[a.length-1].level>=w;)a.pop();const m=a.length>0?a[a.length-1]:void 0;!L&&(m!=null&&m.slot)&&(L=m.slot),!B&&(m!=null&&m.clicks)&&(B=m.clicks),!N&&(m!=null&&m.motion)&&(N=m.motion);const K={...(m==null?void 0:m.customAttrs)||{}};if(f.ial)for(const[E,M]of Object.entries(f.ial))E.startsWith("custom-slidev-")&&!E.startsWith("custom-slidev-slide")&&(K[E]=M);a.push({level:w,slot:L,clicks:B,motion:N,customAttrs:K})}else{const m=a.length>0?a[a.length-1]:void 0;m&&(!L&&m.slot&&m.slot!=="header"&&(L=m.slot),!B&&m.clicks&&(B=m.clicks),!N&&m.motion&&(N=m.motion),m.customAttrs&&(Z={...m.customAttrs,...Z}))}!L&&r.blocks.some(m=>m.slot==="slot-divider-right")&&(L="right"),L&&(Z[Tt]=L),B&&!Z[$e]&&(Z[$e]=B),N&&!Z[We]&&(Z[We]=JSON.stringify(N)),(_||p["custom-slidev-autoplay"]||p["custom-slidev-muted"])&&(p["custom-slidev-autoplay"]&&(Z["custom-slidev-autoplay"]=p["custom-slidev-autoplay"],p["custom-slidev-autoplay"]==="true"&&!p["custom-slidev-muted"]&&(Z["custom-slidev-muted"]="true")),p["custom-slidev-loop"]&&(Z["custom-slidev-loop"]=p["custom-slidev-loop"]),p["custom-slidev-muted"]&&(Z["custom-slidev-muted"]=p["custom-slidev-muted"]),p["custom-slidev-controls"]&&(Z["custom-slidev-controls"]=p["custom-slidev-controls"]));const $={id:f.id,type:f.type,content:f.content||"",rawMarkdown:k,clicks:B,motion:N,shikiLines:x.shikiLines,slot:L,attributes:Z};r.blocks.push($)};v(u)}for(let u=0;u<s.length;u++){const v=s[u],f=[],k={...v.frontmatter};u===0&&(k.theme=o.theme,k.aspectRatio=o.aspectRatio,k.highlighter=o.highlighter,k.transition=v.frontmatter.transition||o.defaultTransition);const p=lc(k);p&&f.push(p);const b=v.blocks.filter(I=>I.slot!=="slot-divider-right"),y=I=>I.filter(T=>!!(T.rawMarkdown||T.content||"").trim()).map(T=>{var w;return Ws(T.rawMarkdown,T.clicks,T.motion,(w=T.attributes)==null?void 0:w.style)}).join(`

`),x=I=>{const T=I.filter(N=>!!(N.rawMarkdown||N.content||"").trim());if(T.length===0)return;const w=T[0],L=(w.rawMarkdown||w.content||"").trim();(xn(w)||/^(?:[-*+]|\d+\.)\s+/.test(L))&&(w.rawMarkdown=zr(w.rawMarkdown||w.content||""),w.content=w.rawMarkdown)},_=I=>I.length===0?"":(x(I),y(I)),A=v.frontmatter.layout||"default";if(cs(A)){let I=[];const T=b.filter($=>$.slot==="header");if(T.length>0)I=T;else if(b.length>0){const $=b.find(U=>U.type==="h"&&(!U.slot||U.slot==="default"));$&&(I=[$])}const w=b.filter($=>!I.includes($));let L=2;if(A==="three-cols-header")L=3;else if(A==="two-cols-header")L=2;else{let $=0;for(const U of w){const m=(U.slot||"").match(/^col-(\d+)$/i);m&&($=Math.max($,parseInt(m[1],10)))}if($>=2)L=$;else if(v.frontmatter.layoutRatio){const U=v.frontmatter.layoutRatio.trim();if(U.includes(":")){const m=U.split(":").map(K=>parseFloat(K.trim())).filter(K=>!isNaN(K)&&K>0);m.length>=2&&(L=m.length)}else{const m=U.split(/\s+/).filter(Boolean);m.length>=2&&(L=m.length)}}else w.length===1&&w[0].children&&w[0].children.length>=2&&(L=Math.min(6,w[0].children.length))}const B=Hr(w,L);B.forEach(($,U)=>{const m=`col-${U+1}`;for(const K of $)(!K.slot||K.slot==="default")&&(K.slot=m);x($)});const N=B.flat();if(w.length===1&&N.length>1){const $=v.blocks.findIndex(U=>U.id===w[0].id);$!==-1&&v.blocks.splice($,1,...N)}const Z=y(I);if(Z&&f.push(Z),A==="two-cols-header"&&L===2){const $=_(B[0]||[]),U=_(B[1]||[]);$&&f.push(`::left::

${$}`),U&&f.push(`::right::

${U}`)}else B.forEach(($,U)=>{const m=_($);m&&f.push(`::col-${U+1}::

${m}`)})}else if(A==="two-cols"){const I=b.filter(B=>B.slot==="left"),T=b.filter(B=>B.slot==="right");x(I),x(T);const w=y(I.length>0?I:b.filter(B=>B.slot!=="right")),L=y(T);f.push(w),L&&f.push(`::right::

${L}`)}else for(const I of b)f.push(Ws(I.rawMarkdown,I.clicks,I.motion,(d=I.attributes)==null?void 0:d.style));v.notes&&f.push(`<!--
${v.notes}
-->`),v.rawMarkdown=f.join(`

`).trim()}const c=s.map(u=>u.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:t,config:o,slides:s,fullMarkdown:c}}const Zo=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function fc(t){var o,s,l,r,a,c,d,u,v,f,k,p;if(!t||typeof t!="object")return"";const i=[],e=[];if(Array.isArray(t.styles))for(const b of t.styles){if(!b||!b.id)continue;const y=`--b3-inline-style-${b.id}`;(o=b.light)!=null&&o.color&&i.push(`  ${y}-color: ${b.light.color};`),(s=b.light)!=null&&s.backgroundColor&&i.push(`  ${y}-background-color: ${b.light.backgroundColor};`),(l=b.dark)!=null&&l.color&&e.push(`  ${y}-color: ${b.dark.color};`),(r=b.dark)!=null&&r.backgroundColor&&e.push(`  ${y}-background-color: ${b.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.colors))for(const b of t.builtin.colors){if(!b||typeof b.index!="number")continue;const y=b.index;(a=b.light)!=null&&a.color&&i.push(`  --b3-font-color${y}: ${b.light.color};`),(c=b.light)!=null&&c.backgroundColor&&i.push(`  --b3-font-background${y}: ${b.light.backgroundColor};`),(d=b.dark)!=null&&d.color&&e.push(`  --b3-font-color${y}: ${b.dark.color};`),(u=b.dark)!=null&&u.backgroundColor&&e.push(`  --b3-font-background${y}: ${b.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.styles))for(const b of t.builtin.styles){if(!b||!b.id)continue;const y=b.id;(v=b.light)!=null&&v.color&&i.push(`  --b3-card-${y}-color: ${b.light.color};`),(f=b.light)!=null&&f.backgroundColor&&i.push(`  --b3-card-${y}-background: ${b.light.backgroundColor};`),(k=b.dark)!=null&&k.color&&e.push(`  --b3-card-${y}-color: ${b.dark.color};`),(p=b.dark)!=null&&p.backgroundColor&&e.push(`  --b3-card-${y}-background: ${b.dark.backgroundColor};`)}if(i.length===0&&e.length===0)return"";const n=[];return i.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${i.join(`
`)}
}`),e.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${e.join(`
`)}
}`),n.join(`

`)}function un(t){const i=fc(t);return i?`${Zo}

/* Custom Workspace Inline Styles */
${i}`:Zo}function Mo(t){const i={};if(!t||typeof t!="string")return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(e))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";i[s]=l}return i}const pc={getBlockAttrs:Ge,getChildBlocks:Xn,setBlockAttrs:Rt,sql:vn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:Ua};class hc{constructor(i){wt(this,"deps");wt(this,"attrOverrides",new Map);wt(this,"trackedListSuperBlocks",new Map);this.deps={...pc,...i||{}}}setBlockAttrOverride(i,e){if(!i||!e)return;const o={...this.attrOverrides.get(i)||{}};for(const[s,l]of Object.entries(e))l===""||l===null||l===void 0?delete o[s]:o[s]=String(l);Object.keys(o).length===0?this.attrOverrides.delete(i):this.attrOverrides.set(i,o)}getBlockAttrOverride(i){return this.attrOverrides.get(i)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(i){return this.trackedListSuperBlocks.get(i)||[]}clearBlockAttrOverride(i,e){if(!i)return;if(!e){this.attrOverrides.delete(i);return}const n=this.attrOverrides.get(i);n&&(delete n[e],Object.keys(n).length===0&&this.attrOverrides.delete(i))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(i){try{const e=await this.deps.getBlockAttrs(i).catch(()=>({}))||{},n=this.attrOverrides.get(i);n&&Object.assign(e,n);let o=await this.deps.getChildBlocks(i).catch(()=>[]);const s=`SELECT id, ial FROM blocks WHERE root_id = '${i}' LIMIT 99999`,l=await this.deps.sql(s).catch(()=>[])||[],r=new Map;if(Array.isArray(l))for(const _ of l)_.id&&_.ial&&r.set(_.id,Mo(_.ial));const a=`SELECT block_id, name, value FROM attributes WHERE root_id = '${i}' AND type = 'b' LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[];if(Array.isArray(c)){for(const _ of c)if(_.block_id&&_.name){let A=r.get(_.block_id);A||(A={},r.set(_.block_id,A)),A[_.name]=_.value||""}}if(!o||o.length===0){const _=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE root_id = '${i}' AND id != '${i}' ORDER BY created ASC LIMIT 99999`;o=await this.deps.sql(_).catch(()=>[])||[]}const d=(o||[]).map(_=>{const A=r.get(_.id)||(_.ial?Mo(_.ial):{}),I=this.attrOverrides.get(_.id);return I&&Object.assign(A,I),{id:_.id,parent_id:_.parent_id,root_id:_.root_id||i,type:_.type,subType:_.subType,content:_.content||"",markdown:_.markdown||"",ial:A,children:_.children}}),u=async(_,A=0)=>{if(!(!_||_.length===0||A>8))for(const I of _){if((oe(I)||I.type==="l"||I.type==="NodeList"||I.type==="i"||I.type==="NodeListItem"||I.type==="b"||I.type==="NodeBlockquote")&&(!I.children||I.children.length===0)){let w=await this.deps.getChildBlocks(I.id).catch(()=>[]);if(!w||w.length===0){const L=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE parent_id = '${I.id}' ORDER BY sort ASC, created ASC`;w=await this.deps.sql(L).catch(()=>[])||[]}Array.isArray(w)&&w.length>0&&(I.children=w.map(L=>{const B=r.get(L.id)||(L.ial?Mo(L.ial):{}),N=this.attrOverrides.get(L.id);return N&&Object.assign(B,N),{id:L.id,parent_id:L.parent_id||I.id,root_id:L.root_id||i,type:L.type,subType:L.subType,content:L.content||"",markdown:L.markdown||"",ial:B}}))}I.children&&I.children.length>0&&await u(I.children,A+1)}};await u(d);const v=_=>{var A,I;for(const T of _)if(T.children&&T.children.length>0){v(T.children);for(const w of T.children)if(w.ial)for(const[L,B]of Object.entries(w.ial))L.startsWith("custom-slidev-")&&!((A=T.ial)!=null&&A[L])&&(T.ial||(T.ial={}),T.ial[L]=B);if(T.ial){for(const[w,L]of Object.entries(T.ial))if(w.startsWith("custom-slidev-"))for(const B of T.children)(B.type==="video"||B.type==="NodeVideo"||/<video\b/i.test(B.markdown||B.content||""))&&!((I=B.ial)!=null&&I[w])&&(B.ial||(B.ial={}),B.ial[w]=L)}}};v(d),nc(d,_=>{const A={[dt]:_.layout};_.ratio&&(A[Zt]=_.ratio),this.setBlockAttrOverride(_.blockId,A),(this.deps.setBlockAttrs||Rt)(_.blockId,A).catch(T=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",T)})});const f=this.trackedListSuperBlocks.get(i)||[],k=ic(i,d,{tracked:f,onTagChange:_=>{this.setBlockAttrOverride(_.blockId,_.attrs),_.blockId===i&&Object.assign(e,_.attrs);const A=T=>{for(const w of T)w.id===_.blockId&&(w.ial||(w.ial={}),Object.assign(w.ial,_.attrs)),w.children&&w.children.length>0&&A(w.children)};A(d),(this.deps.setBlockAttrs||Rt)(_.blockId,_.attrs).catch(T=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",T)})}});this.trackedListSuperBlocks.set(i,k.newTracked);const p=new Set;for(const _ of d){const A=_.markdown||_.content||"";if(A.includes("((")){const I=Wa(A);for(const T of I)p.add(T.blockId)}}const b={};if(p.size>0){const _=Array.from(p).map(I=>`'${I}'`).join(","),A=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${_})`).catch(()=>[])||[];if(Array.isArray(A))for(const I of A)I.id&&(b[I.id]=I.markdown||I.content||"")}const y=this.deps.getBaseUrl?this.deps.getBaseUrl():"",x=Vs(i,e,d,{baseUrl:y,refContentMap:b});try{const _=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;x.customThemeCss=un(_)}catch{x.customThemeCss=un(null)}return x}catch(e){console.error("[DocumentCompilerService] Failed to compile document:",e);const n=Vs(i,{},[],{});return n.customThemeCss=un(null),n}}}const Pt=new hc;class us{constructor(i){wt(this,"devServerUrl","http://localhost:3030");wt(this,"isConnected",!1);wt(this,"lastSyncTime",null);i&&(this.devServerUrl=i)}getUrl(){return this.devServerUrl}setUrl(i){this.devServerUrl=i.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(i=1500){try{const e=new AbortController,n=setTimeout(()=>e.abort(),i),o=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:e.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!o,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(i){const e=i.config,n=["---",`theme: ${e.theme||"default"}`,`aspectRatio: "${e.aspectRatio||"16/9"}"`,`highlighter: ${e.highlighter||"shiki"}`,`transition: ${e.defaultTransition||"slide-left"}`];e.colorSchema&&e.colorSchema!=="auto"&&n.push(`colorSchema: ${e.colorSchema}`),n.push("drawings:","  persist: false","---","");const o=n.join(`
`),s=i.slides.map((l,r)=>{const a=l.frontmatter||{},c=[],d=r===0;a.layout&&a.layout!=="default"&&c.push(`layout: ${a.layout}`),a.transition&&c.push(`transition: ${a.transition}`),a.background&&c.push(`background: ${a.background}`),a.class&&c.push(`class: "${a.class}"`);let u="";c.length>0?u=d?"":`---
${c.join(`
`)}
---

`:d||(u=`---

`);let v="";if(a.layout==="two-cols"){const k=l.blocks.filter(x=>x.slot!=="right"),p=l.blocks.filter(x=>x.slot==="right"),b=k.map(x=>x.rawMarkdown||x.content||"").join(`

`),y=p.map(x=>x.rawMarkdown||x.content||"").join(`

`);v=`${b}

::right::

${y}`}else v=l.blocks.map(k=>k.rawMarkdown||k.content||"").join(`

`);let f="";return l.notes&&l.notes.trim()&&(f=`

<!--
${l.notes.trim()}
-->`),`${u}${v}${f}`}).join(`

`);return`${o}${s}
`}async syncToWorkspaceFile(i,e="/data/storage/petal/siyuan-slidev/slides.md",n){const o=this.buildStandardSlidevMarkdown(i);if(this.lastSyncTime=Date.now(),n)try{const s=typeof Blob<"u"?new Blob([o],{type:"text/markdown;charset=utf-8"}):Buffer.from(o,"utf-8");return await n(e,!1,s),{success:!0,path:e}}catch(s){return{success:!1,path:e,error:String(s)}}return{success:!0,path:e}}downloadSlidesMd(i,e="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(i),o=new Blob([n],{type:"text/markdown;charset=utf-8"}),s=URL.createObjectURL(o),l=document.createElement("a");return l.href=s,l.download=e,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(s),!0}}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function fs(t){const i=Object.create(null);for(const e of t.split(","))i[e]=1;return e=>e in i}const Ut={},Hi=[],Ve=()=>{},Ur=()=>!1,mo=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&(t.charCodeAt(2)>122||t.charCodeAt(2)<97),go=t=>t.startsWith("onUpdate:"),ce=Object.assign,ps=(t,i)=>{const e=t.indexOf(i);e>-1&&t.splice(e,1)},mc=Object.prototype.hasOwnProperty,zt=(t,i)=>mc.call(t,i),Ct=Array.isArray,Ui=t=>En(t)==="[object Map]",Xi=t=>En(t)==="[object Set]",Ks=t=>En(t)==="[object Date]",At=t=>typeof t=="function",te=t=>typeof t=="string",Le=t=>typeof t=="symbol",jt=t=>t!==null&&typeof t=="object",Wr=t=>(jt(t)||At(t))&&At(t.then)&&At(t.catch),Vr=Object.prototype.toString,En=t=>Vr.call(t),gc=t=>En(t).slice(8,-1),Kr=t=>En(t)==="[object Object]",hs=t=>te(t)&&t!=="NaN"&&t[0]!=="-"&&""+parseInt(t,10)===t,fn=fs(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),vo=t=>{const i=Object.create(null);return(e=>i[e]||(i[e]=t(e)))},vc=/-\w/g,ge=vo(t=>t.replace(vc,i=>i.slice(1).toUpperCase())),bc=/\B([A-Z])/g,vi=vo(t=>t.replace(bc,"-$1").toLowerCase()),bo=vo(t=>t.charAt(0).toUpperCase()+t.slice(1)),Do=vo(t=>t?`on${bo(t)}`:""),He=(t,i)=>!Object.is(t,i),Kn=(t,...i)=>{for(let e=0;e<t.length;e++)t[e](...i)},qr=(t,i,e,n=!1)=>{Object.defineProperty(t,i,{configurable:!0,enumerable:!1,writable:n,value:e})},yo=t=>{const i=parseFloat(t);return isNaN(i)?t:i};let qs;const ko=()=>qs||(qs=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function ms(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++){const n=t[e],o=te(n)?xc(n):ms(n);if(o)for(const s in o)i[s]=o[s]}return i}else if(te(t)||jt(t))return t}const yc=/;(?![^(]*\))/g,kc=/:([^]+)/,wc=/\/\*[^]*?\*\//g;function xc(t){const i={};return t.replace(wc,"").split(yc).forEach(e=>{if(e){const n=e.split(kc);n.length>1&&(i[n[0].trim()]=n[1].trim())}}),i}function It(t){let i="";if(te(t))i=t;else if(Ct(t))for(let e=0;e<t.length;e++){const n=It(t[e]);n&&(i+=n+" ")}else if(jt(t))for(const e in t)t[e]&&(i+=e+" ");return i.trim()}const _c="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",Sc=fs(_c);function Gr(t){return!!t||t===""}function Cc(t,i){if(t.length!==i.length)return!1;let e=!0;for(let n=0;e&&n<t.length;n++)e=Qi(t[n],i[n]);return e}function Qi(t,i){if(t===i)return!0;let e=Ks(t),n=Ks(i);if(e||n)return e&&n?t.getTime()===i.getTime():!1;if(e=Le(t),n=Le(i),e||n)return t===i;if(e=Ct(t),n=Ct(i),e||n)return e&&n?Cc(t,i):!1;if(e=jt(t),n=jt(i),e||n){if(!e||!n)return!1;const o=Object.keys(t).length,s=Object.keys(i).length;if(o!==s)return!1;for(const l in t){const r=t.hasOwnProperty(l),a=i.hasOwnProperty(l);if(r&&!a||!r&&a||!Qi(t[l],i[l]))return!1}}return String(t)===String(i)}function gs(t,i){return t.findIndex(e=>Qi(e,i))}const Zr=t=>!!(t&&t.__v_isRef===!0),xt=t=>te(t)?t:t==null?"":Ct(t)||jt(t)&&(t.toString===Vr||!At(t.toString))?Zr(t)?xt(t.value):JSON.stringify(t,Yr,2):String(t),Yr=(t,i)=>Zr(i)?Yr(t,i.value):Ui(i)?{[`Map(${i.size})`]:[...i.entries()].reduce((e,[n,o],s)=>(e[Lo(n,s)+" =>"]=o,e),{})}:Xi(i)?{[`Set(${i.size})`]:[...i.values()].map(e=>Lo(e))}:Le(i)?Lo(i):jt(i)&&!Ct(i)&&!Kr(i)?String(i):i,Lo=(t,i="")=>{var e;return Le(t)?`Symbol(${(e=t.description)!=null?e:i})`:t};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let re;class $c{constructor(i=!1){this.detached=i,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!i&&re&&(re.active?(this.parent=re,this.index=(re.scopes||(re.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let i,e;if(this.scopes){const n=this.scopes.slice();for(i=0,e=n.length;i<e;i++)n[i].pause()}for(i=0,e=this.effects.length;i<e;i++)this.effects[i].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let i,e;if(this.scopes){const o=this.scopes.slice();for(i=0,e=o.length;i<e;i++)o[i].resume()}const n=this.effects.slice();for(i=0,e=n.length;i<e;i++)n[i].resume()}}run(i){if(this._active){const e=re;try{return re=this,i()}finally{re=e}}}on(){++this._on===1&&(this.prevScope=re,re=this)}off(){if(this._on>0&&--this._on===0){if(re===this)re=this.prevScope;else{let i=re;for(;i;){if(i.prevScope===this){i.prevScope=this.prevScope;break}i=i.prevScope}}this.prevScope=void 0}}stop(i){if(this._active){this._active=!1;let e,n;for(e=0,n=this.effects.length;e<n;e++)this.effects[e].stop();for(this.effects.length=0,e=0,n=this.cleanups.length;e<n;e++)this.cleanups[e]();if(this.cleanups.length=0,this.scopes){const o=this.scopes.slice();for(e=0,n=o.length;e<n;e++)o[e].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!i){const o=this.parent.scopes.pop();o&&o!==this&&(this.parent.scopes[this.index]=o,o.index=this.index)}this.parent=void 0}}}function Ic(){return re}let Wt;const Ro=new WeakSet;class Jr{constructor(i){this.fn=i,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,re&&(re.active?re.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,Ro.has(this)&&(Ro.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Qr(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Gs(this),tl(this);const i=Wt,e=De;Wt=this,De=!0;try{return this.fn()}finally{el(this),Wt=i,De=e,this.flags&=-3}}stop(){if(this.flags&1){for(let i=this.deps;i;i=i.nextDep)ys(i);this.deps=this.depsTail=void 0,Gs(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?Ro.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){Yo(this)&&this.run()}get dirty(){return Yo(this)}}let Xr=0,pn,hn;function Qr(t,i=!1){if(t.flags|=8,i){t.next=hn,hn=t;return}t.next=pn,pn=t}function vs(){Xr++}function bs(){if(--Xr>0)return;if(hn){let i=hn;for(hn=void 0;i;){const e=i.next;i.next=void 0,i.flags&=-9,i=e}}let t;for(;pn;){let i=pn;for(pn=void 0;i;){const e=i.next;if(i.next=void 0,i.flags&=-9,i.flags&1)try{i.trigger()}catch(n){t||(t=n)}i=e}}if(t)throw t}function tl(t){for(let i=t.deps;i;i=i.nextDep)i.version=-1,i.prevActiveLink=i.dep.activeLink,i.dep.activeLink=i}function el(t){let i,e=t.depsTail,n=e;for(;n;){const o=n.prevDep;n.version===-1?(n===e&&(e=o),ys(n),Ac(n)):i=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=o}t.deps=i,t.depsTail=e}function Yo(t){for(let i=t.deps;i;i=i.nextDep)if(i.dep.version!==i.version||i.dep.computed&&(il(i.dep.computed)||i.dep.version!==i.version))return!0;return!!t._dirty}function il(t){if(t.flags&4&&!(t.flags&16)||(t.flags&=-17,t.globalVersion===_n)||(t.globalVersion=_n,!t.isSSR&&t.flags&128&&(!t.deps&&!t._dirty||!Yo(t))))return;t.flags|=2;const i=t.dep,e=Wt,n=De;Wt=t,De=!0;try{tl(t);const o=t.fn(t._value);(i.version===0||He(o,t._value))&&(t.flags|=128,t._value=o,i.version++)}catch(o){throw i.version++,o}finally{Wt=e,De=n,el(t),t.flags&=-3}}function ys(t,i=!1){const{dep:e,prevSub:n,nextSub:o}=t;if(n&&(n.nextSub=o,t.prevSub=void 0),o&&(o.prevSub=n,t.nextSub=void 0),e.subs===t&&(e.subs=n,!n&&e.computed)){e.computed.flags&=-5;for(let s=e.computed.deps;s;s=s.nextDep)ys(s,!0)}!i&&!--e.sc&&e.map&&e.map.delete(e.key)}function Ac(t){const{prevDep:i,nextDep:e}=t;i&&(i.nextDep=e,t.prevDep=void 0),e&&(e.prevDep=i,t.nextDep=void 0)}let De=!0;const nl=[];function ni(){nl.push(De),De=!1}function oi(){const t=nl.pop();De=t===void 0?!0:t}function Gs(t){const{cleanup:i}=t;if(t.cleanup=void 0,i){const e=Wt;Wt=void 0;try{i()}finally{Wt=e}}}let _n=0;class Tc{constructor(i,e){this.sub=i,this.dep=e,this.version=e.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class ks{constructor(i){this.computed=i,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(i){if(!Wt||!De||Wt===this.computed)return;let e=this.activeLink;if(e===void 0||e.sub!==Wt)e=this.activeLink=new Tc(Wt,this),Wt.deps?(e.prevDep=Wt.depsTail,Wt.depsTail.nextDep=e,Wt.depsTail=e):Wt.deps=Wt.depsTail=e,ol(e);else if(e.version===-1&&(e.version=this.version,e.nextDep)){const n=e.nextDep;n.prevDep=e.prevDep,e.prevDep&&(e.prevDep.nextDep=n),e.prevDep=Wt.depsTail,e.nextDep=void 0,Wt.depsTail.nextDep=e,Wt.depsTail=e,Wt.deps===e&&(Wt.deps=n)}return e}trigger(i){this.version++,_n++,this.notify(i)}notify(i){vs();try{for(let e=this.subs;e;e=e.prevSub)e.sub.notify()&&e.sub.dep.notify()}finally{bs()}}}function ol(t){if(t.dep.sc++,t.sub.flags&4){const i=t.dep.computed;if(i&&!t.dep.subs){i.flags|=20;for(let n=i.deps;n;n=n.nextDep)ol(n)}const e=t.dep.subs;e!==t&&(t.prevSub=e,e&&(e.nextSub=t)),t.dep.subs=t}}const Jo=new WeakMap,Ti=Symbol(""),Xo=Symbol(""),Sn=Symbol("");function fe(t,i,e){if(De&&Wt){let n=Jo.get(t);n||Jo.set(t,n=new Map);let o=n.get(e);o||(n.set(e,o=new ks),o.map=n,o.key=e),o.track()}}function Je(t,i,e,n,o,s){const l=Jo.get(t);if(!l){_n++;return}const r=a=>{a&&a.trigger()};if(vs(),i==="clear")l.forEach(r);else{const a=Ct(t),c=a&&hs(e);if(a&&e==="length"){const d=Number(n);l.forEach((u,v)=>{(v==="length"||v===Sn||!Le(v)&&v>=d)&&r(u)})}else switch((e!==void 0||l.has(void 0))&&r(l.get(e)),c&&r(l.get(Sn)),i){case"add":a?c&&r(l.get("length")):(r(l.get(Ti)),Ui(t)&&r(l.get(Xo)));break;case"delete":a||(r(l.get(Ti)),Ui(t)&&r(l.get(Xo)));break;case"set":Ui(t)&&r(l.get(Ti));break}}bs()}function Oi(t){const i=Ot(t);return i===t?i:(fe(i,"iterate",Sn),Ie(t)?i:i.map(Re))}function wo(t){return fe(t=Ot(t),"iterate",Sn),t}function Fe(t,i){return si(t)?Gi(Bi(t)?Re(i):i):Re(i)}const Bc={__proto__:null,[Symbol.iterator](){return Po(this,Symbol.iterator,t=>Fe(this,t))},concat(...t){return Oi(this).concat(...t.map(i=>Ct(i)?Oi(i):i))},entries(){return Po(this,"entries",t=>(t[1]=Fe(this,t[1]),t))},every(t,i){return qe(this,"every",t,i,void 0,arguments)},filter(t,i){return qe(this,"filter",t,i,e=>e.map(n=>Fe(this,n)),arguments)},find(t,i){return qe(this,"find",t,i,e=>Fe(this,e),arguments)},findIndex(t,i){return qe(this,"findIndex",t,i,void 0,arguments)},findLast(t,i){return qe(this,"findLast",t,i,e=>Fe(this,e),arguments)},findLastIndex(t,i){return qe(this,"findLastIndex",t,i,void 0,arguments)},forEach(t,i){return qe(this,"forEach",t,i,void 0,arguments)},includes(...t){return Oo(this,"includes",t)},indexOf(...t){return Oo(this,"indexOf",t)},join(t){return Oi(this).join(t)},lastIndexOf(...t){return Oo(this,"lastIndexOf",t)},map(t,i){return qe(this,"map",t,i,void 0,arguments)},pop(){return nn(this,"pop")},push(...t){return nn(this,"push",t)},reduce(t,...i){return Zs(this,"reduce",t,i)},reduceRight(t,...i){return Zs(this,"reduceRight",t,i)},shift(){return nn(this,"shift")},some(t,i){return qe(this,"some",t,i,void 0,arguments)},splice(...t){return nn(this,"splice",t)},toReversed(){return Oi(this).toReversed()},toSorted(t){return Oi(this).toSorted(t)},toSpliced(...t){return Oi(this).toSpliced(...t)},unshift(...t){return nn(this,"unshift",t)},values(){return Po(this,"values",t=>Fe(this,t))}};function Po(t,i,e){const n=wo(t),o=n[i]();return n!==t&&!Ie(t)&&(o._next=o.next,o.next=()=>{const s=o._next();return s.done||(s.value=e(s.value)),s}),o}const Ec=Array.prototype;function qe(t,i,e,n,o,s){const l=wo(t),r=l!==t&&!Ie(t),a=l[i];if(a!==Ec[i]){const u=a.apply(t,s);return r?Re(u):u}let c=e;l!==t&&(r?c=function(u,v){return e.call(this,Fe(t,u),v,t)}:e.length>2&&(c=function(u,v){return e.call(this,u,v,t)}));const d=a.call(l,c,n);return r&&o?o(d):d}function Zs(t,i,e,n){const o=wo(t),s=o!==t&&!Ie(t);let l=e,r=!1;o!==t&&(s?(r=n.length===0,l=function(c,d,u){return r&&(r=!1,c=Fe(t,c)),e.call(this,c,Fe(t,d),u,t)}):e.length>3&&(l=function(c,d,u){return e.call(this,c,d,u,t)}));const a=o[i](l,...n);return r?Fe(t,a):a}function Oo(t,i,e){const n=Ot(t);fe(n,"iterate",Sn);const o=n[i](...e);return(o===-1||o===!1)&&_s(e[0])?(e[0]=Ot(e[0]),n[i](...e)):o}function nn(t,i,e=[]){ni(),vs();const n=Ot(t)[i].apply(t,e);return bs(),oi(),n}const Mc=fs("__proto__,__v_isRef,__isVue"),sl=new Set(Object.getOwnPropertyNames(Symbol).filter(t=>t!=="arguments"&&t!=="caller").map(t=>Symbol[t]).filter(Le));function Dc(t){Le(t)||(t=String(t));const i=Ot(this);return fe(i,"has",t),i.hasOwnProperty(t)}class rl{constructor(i=!1,e=!1){this._isReadonly=i,this._isShallow=e}get(i,e,n){if(e==="__v_skip")return i.__v_skip;const o=this._isReadonly,s=this._isShallow;if(e==="__v_isReactive")return!o;if(e==="__v_isReadonly")return o;if(e==="__v_isShallow")return s;if(e==="__v_raw")return n===(o?s?Uc:dl:s?cl:al).get(i)||Object.getPrototypeOf(i)===Object.getPrototypeOf(n)?i:void 0;const l=Ct(i);if(!o){let a;if(l&&(a=Bc[e]))return a;if(e==="hasOwnProperty")return Dc}const r=Reflect.get(i,e,Yt(i)?i:n);if((Le(e)?sl.has(e):Mc(e))||(o||fe(i,"get",e),s))return r;if(Yt(r)){const a=l&&hs(e)?r:r.value;return o&&jt(a)?ts(a):a}return jt(r)?o?ts(r):xo(r):r}}class ll extends rl{constructor(i=!1){super(!1,i)}set(i,e,n,o){let s=i[e];const l=Ct(i)&&hs(e);if(!this._isShallow){const c=si(s);if(!Ie(n)&&!si(n)&&(s=Ot(s),n=Ot(n)),!l&&Yt(s)&&!Yt(n))return c||(s.value=n),!0}const r=l?Number(e)<i.length:zt(i,e),a=Reflect.set(i,e,n,Yt(i)?i:o);return i===Ot(o)&&a&&(r?He(n,s)&&Je(i,"set",e,n):Je(i,"add",e,n)),a}deleteProperty(i,e){const n=zt(i,e);i[e];const o=Reflect.deleteProperty(i,e);return o&&n&&Je(i,"delete",e,void 0),o}has(i,e){const n=Reflect.has(i,e);return(!Le(e)||!sl.has(e))&&fe(i,"has",e),n}ownKeys(i){return fe(i,"iterate",Ct(i)?"length":Ti),Reflect.ownKeys(i)}}class Lc extends rl{constructor(i=!1){super(!0,i)}set(i,e){return!0}deleteProperty(i,e){return!0}}const Rc=new ll,Pc=new Lc,Oc=new ll(!0);const Qo=t=>t,Nn=t=>Reflect.getPrototypeOf(t);function zc(t,i,e){return function(...n){const o=this.__v_raw,s=Ot(o),l=Ui(s),r=t==="entries"||t===Symbol.iterator&&l,a=t==="keys"&&l,c=o[t](...n),d=e?Qo:i?Gi:Re;return!i&&fe(s,"iterate",a?Xo:Ti),ce(Object.create(c),{next(){const{value:u,done:v}=c.next();return v?{value:u,done:v}:{value:r?[d(u[0]),d(u[1])]:d(u),done:v}}})}}function Fn(t){return function(...i){return t==="delete"?!1:t==="clear"?void 0:this}}function Nc(t,i){const e={get(o){const s=this.__v_raw,l=Ot(s),r=Ot(o);t||(He(o,r)&&fe(l,"get",o),fe(l,"get",r));const{has:a}=Nn(l),c=i?Qo:t?Gi:Re;if(a.call(l,o))return c(s.get(o));if(a.call(l,r))return c(s.get(r));s!==l&&s.get(o)},get size(){const o=this.__v_raw;return!t&&fe(Ot(o),"iterate",Ti),o.size},has(o){const s=this.__v_raw,l=Ot(s),r=Ot(o);return t||(He(o,r)&&fe(l,"has",o),fe(l,"has",r)),o===r?s.has(o):s.has(o)||s.has(r)},forEach(o,s){const l=this,r=l.__v_raw,a=Ot(r),c=i?Qo:t?Gi:Re;return!t&&fe(a,"iterate",Ti),r.forEach((d,u)=>o.call(s,c(d),c(u),l))}};return ce(e,t?{add:Fn("add"),set:Fn("set"),delete:Fn("delete"),clear:Fn("clear")}:{add(o){const s=Ot(this),l=Nn(s),r=Ot(o),a=!i&&!Ie(o)&&!si(o)?r:o;return l.has.call(s,a)||He(o,a)&&l.has.call(s,o)||He(r,a)&&l.has.call(s,r)||(s.add(a),Je(s,"add",a,a)),this},set(o,s){!i&&!Ie(s)&&!si(s)&&(s=Ot(s));const l=Ot(this),{has:r,get:a}=Nn(l);let c=r.call(l,o);c||(o=Ot(o),c=r.call(l,o));const d=a.call(l,o);return l.set(o,s),c?He(s,d)&&Je(l,"set",o,s):Je(l,"add",o,s),this},delete(o){const s=Ot(this),{has:l,get:r}=Nn(s);let a=l.call(s,o);a||(o=Ot(o),a=l.call(s,o)),r&&r.call(s,o);const c=s.delete(o);return a&&Je(s,"delete",o,void 0),c},clear(){const o=Ot(this),s=o.size!==0,l=o.clear();return s&&Je(o,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(o=>{e[o]=zc(o,t,i)}),e}function ws(t,i){const e=Nc(t,i);return(n,o,s)=>o==="__v_isReactive"?!t:o==="__v_isReadonly"?t:o==="__v_raw"?n:Reflect.get(zt(e,o)&&o in n?e:n,o,s)}const Fc={get:ws(!1,!1)},jc={get:ws(!1,!0)},Hc={get:ws(!0,!1)};const al=new WeakMap,cl=new WeakMap,dl=new WeakMap,Uc=new WeakMap;function Wc(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function xo(t){return si(t)?t:xs(t,!1,Rc,Fc,al)}function Vc(t){return xs(t,!1,Oc,jc,cl)}function ts(t){return xs(t,!0,Pc,Hc,dl)}function xs(t,i,e,n,o){if(!jt(t)||t.__v_raw&&!(i&&t.__v_isReactive)||t.__v_skip||!Object.isExtensible(t))return t;const s=o.get(t);if(s)return s;const l=Wc(gc(t));if(l===0)return t;const r=new Proxy(t,l===2?n:e);return o.set(t,r),r}function Bi(t){return si(t)?Bi(t.__v_raw):!!(t&&t.__v_isReactive)}function si(t){return!!(t&&t.__v_isReadonly)}function Ie(t){return!!(t&&t.__v_isShallow)}function _s(t){return t?!!t.__v_raw:!1}function Ot(t){const i=t&&t.__v_raw;return i?Ot(i):t}function Kc(t){return!zt(t,"__v_skip")&&Object.isExtensible(t)&&qr(t,"__v_skip",!0),t}const Re=t=>jt(t)?xo(t):t,Gi=t=>jt(t)?ts(t):t;function Yt(t){return t?t.__v_isRef===!0:!1}function ft(t){return qc(t,!1)}function qc(t,i){return Yt(t)?t:new Gc(t,i)}class Gc{constructor(i,e){this.dep=new ks,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=e?i:Ot(i),this._value=e?i:Re(i),this.__v_isShallow=e}get value(){return this.dep.track(),this._value}set value(i){const e=this._rawValue,n=this.__v_isShallow||Ie(i)||si(i);i=n?i:Ot(i),He(i,e)&&(this._rawValue=i,this._value=n?i:Re(i),this.dep.trigger())}}function ht(t){return Yt(t)?t.value:t}const Zc={get:(t,i,e)=>i==="__v_raw"?t:ht(Reflect.get(t,i,e)),set:(t,i,e,n)=>{const o=t[i];return Yt(o)&&!Yt(e)?(o.value=e,!0):Reflect.set(t,i,e,n)}};function ul(t){return Bi(t)?t:new Proxy(t,Zc)}class Yc{constructor(i,e,n){this.fn=i,this.setter=e,this._value=void 0,this.dep=new ks(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=_n-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!e,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Wt!==this)return Qr(this,!0),!0}get value(){const i=this.dep.track();return il(this),i&&(i.version=this.dep.version),this._value}set value(i){this.setter&&this.setter(i)}}function Jc(t,i,e=!1){let n,o;return At(t)?n=t:(n=t.get,o=t.set),new Yc(n,o,e)}const jn={},oo=new WeakMap;let Ci;function Xc(t,i=!1,e=Ci){if(e){let n=oo.get(e);n||oo.set(e,n=[]),n.push(t)}}function Qc(t,i,e=Ut){const{immediate:n,deep:o,once:s,scheduler:l,augmentJob:r,call:a}=e,c=A=>o?A:Ie(A)||o===!1||o===0?Xe(A,1):Xe(A);let d,u,v,f,k=!1,p=!1;if(Yt(t)?(u=()=>t.value,k=Ie(t)):Bi(t)?(u=()=>c(t),k=!0):Ct(t)?(p=!0,k=t.some(A=>Bi(A)||Ie(A)),u=()=>t.map(A=>{if(Yt(A))return A.value;if(Bi(A))return c(A);if(At(A))return a?a(A,2):A()})):At(t)?i?u=a?()=>a(t,2):t:u=()=>{if(v){ni();try{v()}finally{oi()}}const A=Ci;Ci=d;try{return a?a(t,3,[f]):t(f)}finally{Ci=A}}:u=Ve,i&&o){const A=u,I=o===!0?1/0:o;u=()=>Xe(A(),I)}const b=Ic(),y=()=>{d.stop(),b&&b.active&&ps(b.effects,d)};if(s&&i){const A=i;i=(...I)=>{const T=A(...I);return y(),T}}let x=p?new Array(t.length).fill(jn):jn;const _=A=>{if(!(!(d.flags&1)||!d.dirty&&!A))if(i){const I=d.run();if(A||o||k||(p?I.some((T,w)=>He(T,x[w])):He(I,x))){v&&v();const T=Ci;Ci=d;try{const w=[I,x===jn?void 0:p&&x[0]===jn?[]:x,f];x=I,a?a(i,3,w):i(...w)}finally{Ci=T}}}else d.run()};return r&&r(_),d=new Jr(u),d.scheduler=l?()=>l(_,!1):_,f=A=>Xc(A,!1,d),v=d.onStop=()=>{const A=oo.get(d);if(A){if(a)a(A,4);else for(const I of A)I();oo.delete(d)}},i?n?_(!0):x=d.run():l?l(_.bind(null,!0),!0):d.run(),y.pause=d.pause.bind(d),y.resume=d.resume.bind(d),y.stop=y,y}function Xe(t,i=1/0,e){if(i<=0||!jt(t)||t.__v_skip||(e=e||new Map,(e.get(t)||0)>=i))return t;if(e.set(t,i),i--,Yt(t))Xe(t.value,i,e);else if(Ct(t))for(let n=0;n<t.length;n++)Xe(t[n],i,e);else if(Xi(t)||Ui(t))t.forEach(n=>{Xe(n,i,e)});else if(Kr(t)){for(const n in t)Xe(t[n],i,e);for(const n of Object.getOwnPropertySymbols(t))Object.prototype.propertyIsEnumerable.call(t,n)&&Xe(t[n],i,e)}return t}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Mn(t,i,e,n){try{return n?t(...n):t()}catch(o){_o(o,i,e)}}function Pe(t,i,e,n){if(At(t)){const o=Mn(t,i,e,n);return o&&Wr(o)&&o.catch(s=>{_o(s,i,e)}),o}if(Ct(t)){const o=[];for(let s=0;s<t.length;s++)o.push(Pe(t[s],i,e,n));return o}}function _o(t,i,e,n=!0){const o=i?i.vnode:null,{errorHandler:s,throwUnhandledErrorInProduction:l}=i&&i.appContext.config||Ut;if(i){let r=i.parent;const a=i.proxy,c=`https://vuejs.org/error-reference/#runtime-${e}`;for(;r;){const d=r.ec;if(d){for(let u=0;u<d.length;u++)if(d[u](t,a,c)===!1)return}r=r.parent}if(s){ni(),Mn(s,null,10,[t,a,c]),oi();return}}td(t,e,o,n,l)}function td(t,i,e,n=!0,o=!1){if(o)throw t;console.error(t)}const me=[];let Ne=-1;const Wi=[];let ui=null,zi=0;const fl=Promise.resolve();let so=null;function pl(t){const i=so||fl;return t?i.then(this?t.bind(this):t):i}function ed(t){let i=Ne+1,e=me.length;for(;i<e;){const n=i+e>>>1,o=me[n],s=Cn(o);s<t||s===t&&o.flags&2?i=n+1:e=n}return i}function Ss(t){if(!(t.flags&1)){const i=Cn(t),e=me[me.length-1];!e||!(t.flags&2)&&i>=Cn(e)?me.push(t):me.splice(ed(i),0,t),t.flags|=1,hl()}}function hl(){so||(so=fl.then(gl))}function id(t){Ct(t)?Wi.push(...t):ui&&t.id===-1?ui.splice(zi+1,0,t):t.flags&1||(Wi.push(t),t.flags|=1),hl()}function Ys(t,i,e=Ne+1){for(;e<me.length;e++){const n=me[e];if(n&&n.flags&2){if(t&&n.id!==t.uid)continue;me.splice(e,1),e--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function ml(t){if(Wi.length){const i=[...new Set(Wi)].sort((e,n)=>Cn(e)-Cn(n));if(Wi.length=0,ui){ui.push(...i);return}for(ui=i,zi=0;zi<ui.length;zi++){const e=ui[zi];e.flags&4&&(e.flags&=-2),e.flags&8||e(),e.flags&=-2}ui=null,zi=0}}const Cn=t=>t.id==null?t.flags&2?-1:1/0:t.id;function gl(t){try{for(Ne=0;Ne<me.length;Ne++){const i=me[Ne];i&&!(i.flags&8)&&(i.flags&4&&(i.flags&=-2),Mn(i,i.i,i.i?15:14),i.flags&4||(i.flags&=-2))}}finally{for(;Ne<me.length;Ne++){const i=me[Ne];i&&(i.flags&=-2)}Ne=-1,me.length=0,ml(),so=null,(me.length||Wi.length)&&gl()}}let ae=null,vl=null;function ro(t){const i=ae;return ae=t,vl=t&&t.type.__scopeId||null,i}function bl(t,i=ae,e){if(!i||t._n)return t;const n=(...o)=>{n._d&&ar(-1);const s=ro(i),l=ti.length;let r;try{r=t(...o)}finally{for(let a=ti.length;a>l;a--)Bs();ro(s),n._d&&ar(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Te(t,i){if(ae===null)return t;const e=Io(ae),n=t.dirs||(t.dirs=[]);for(let o=0;o<i.length;o++){let[s,l,r,a=Ut]=i[o];s&&(At(s)&&(s={mounted:s,updated:s}),s.deep&&Xe(l),n.push({dir:s,instance:e,value:l,oldValue:void 0,arg:r,modifiers:a}))}return t}function xi(t,i,e,n){const o=t.dirs,s=i&&i.dirs;for(let l=0;l<o.length;l++){const r=o[l];s&&(r.oldValue=s[l].value);let a=r.dir[n];a&&(ni(),Pe(a,e,8,[t.el,r,t,i]),oi())}}function nd(t,i){if(pe){let e=pe.provides;const n=pe.parent&&pe.parent.provides;n===e&&(e=pe.provides=Object.create(n)),e[t]=i}}function Qe(t,i,e=!1){const n=eu();if(n||Ki){let o=Ki?Ki._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(o&&t in o)return o[t];if(arguments.length>1)return e&&At(i)?i.call(n&&n.proxy):i}}const od=Symbol.for("v-scx"),sd=()=>Qe(od);function Ei(t,i,e){return yl(t,i,e)}function yl(t,i,e=Ut){const{immediate:n,deep:o,flush:s,once:l}=e,r=ce({},e),a=i&&n||!i&&s!=="post";let c;if(In){if(s==="sync"){const f=sd();c=f.__watcherHandles||(f.__watcherHandles=[])}else if(!a){const f=()=>{};return f.stop=Ve,f.resume=Ve,f.pause=Ve,f}}const d=pe;r.call=(f,k,p)=>Pe(f,d,k,p);let u=!1;s==="post"?r.scheduler=f=>{be(f,d&&d.suspense)}:s!=="sync"&&(u=!0,r.scheduler=(f,k)=>{k?f():Ss(f)}),r.augmentJob=f=>{i&&(f.flags|=4),u&&(f.flags|=2,d&&(f.id=d.uid,f.i=d))};const v=Qc(t,i,r);return In&&(c?c.push(v):a&&v()),v}function rd(t,i,e){const n=this.proxy,o=te(t)?t.includes(".")?kl(n,t):()=>n[t]:t.bind(n,n);let s;At(i)?s=i:(s=i.handler,e=i);const l=Ln(this),r=yl(o,s.bind(n),e);return l(),r}function kl(t,i){const e=i.split(".");return()=>{let n=t;for(let o=0;o<e.length&&n;o++)n=n[e[o]];return n}}const ld=Symbol("_vte"),ad=t=>t.__isTeleport,zo=Symbol("_leaveCb");function Cs(t,i){t.shapeFlag&6&&t.component?(t.transition=i,Cs(t.component.subTree,i)):t.shapeFlag&128?(t.ssContent.transition=i.clone(t.ssContent),t.ssFallback.transition=i.clone(t.ssFallback)):t.transition=i}function xe(t,i){return At(t)?ce({name:t.name},i,{setup:t}):t}function wl(t){t.ids=[t.ids[0]+t.ids[2]+++"-",0,0]}function Js(t,i){let e;return!!((e=Object.getOwnPropertyDescriptor(t,i))&&!e.configurable)}const lo=new WeakMap;function mn(t,i,e,n,o=!1){if(Ct(t)){t.forEach((p,b)=>mn(p,i&&(Ct(i)?i[b]:i),e,n,o));return}if(Vi(n)&&!o){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&mn(t,i,e,n.component.subTree);return}const s=n.shapeFlag&4?Io(n.component):n.el,l=o?null:s,{i:r,r:a}=t,c=i&&i.r,d=r.refs===Ut?r.refs={}:r.refs,u=r.setupState,v=Ot(u),f=u===Ut?Ur:p=>Js(d,p)?!1:zt(v,p),k=(p,b)=>!(b&&Js(d,b));if(c!=null&&c!==a){if(Xs(i),te(c))d[c]=null,f(c)&&(u[c]=null);else if(Yt(c)){const p=i;k(c,p.k)&&(c.value=null),p.k&&(d[p.k]=null)}}if(At(a))Mn(a,r,12,[l,d]);else{const p=te(a),b=Yt(a);if(p||b){const y=()=>{if(t.f){const x=p?f(a)?u[a]:d[a]:k()||!t.k?a.value:d[t.k];if(o)Ct(x)&&ps(x,s);else if(Ct(x))x.includes(s)||x.push(s);else if(p)d[a]=[s],f(a)&&(u[a]=d[a]);else{const _=[s];k(a,t.k)&&(a.value=_),t.k&&(d[t.k]=_)}}else p?(d[a]=l,f(a)&&(u[a]=l)):b&&(k(a,t.k)&&(a.value=l),t.k&&(d[t.k]=l))};if(l){const x=()=>{y(),lo.delete(t)};x.id=-1,lo.set(t,x),be(x,e)}else Xs(t),y()}}}function Xs(t){const i=lo.get(t);i&&(i.flags|=8,lo.delete(t))}ko().requestIdleCallback;ko().cancelIdleCallback;const Vi=t=>!!t.type.__asyncLoader,xl=t=>t.type.__isKeepAlive;function cd(t,i){_l(t,"a",i)}function dd(t,i){_l(t,"da",i)}function _l(t,i,e=pe){const n=t.__wdc||(t.__wdc=()=>{let o=e;for(;o;){if(o.isDeactivated)return;o=o.parent}return t()});if(So(i,n,e),e){let o=e.parent;for(;o&&o.parent;)xl(o.parent.vnode)&&ud(n,i,e,o),o=o.parent}}function ud(t,i,e,n){const o=So(i,t,n,!0);Is(()=>{ps(n[i],o)},e)}function So(t,i,e=pe,n=!1){if(e){const o=e[t]||(e[t]=[]),s=i.__weh||(i.__weh=(...l)=>{ni();const r=Ln(e),a=Pe(i,e,t,l);return r(),oi(),a});return n?o.unshift(s):o.push(s),s}}const li=t=>(i,e=pe)=>{(!In||t==="sp")&&So(t,(...n)=>i(...n),e)},fd=li("bm"),Dn=li("m"),pd=li("bu"),hd=li("u"),$s=li("bum"),Is=li("um"),md=li("sp"),gd=li("rtg"),vd=li("rtc");function bd(t,i=pe){So("ec",t,i)}const yd="components";function kd(t,i){return xd(yd,t,!0,i)||t}const wd=Symbol.for("v-ndc");function xd(t,i,e=!0,n=!1){const o=ae||pe;if(o){const s=o.type;{const r=ru(s,!1);if(r&&(r===i||r===ge(i)||r===bo(ge(i))))return s}const l=Qs(o[t]||s[t],i)||Qs(o.appContext[t],i);return!l&&n?s:l}}function Qs(t,i){return t&&(t[i]||t[ge(i)]||t[bo(ge(i))])}function ye(t,i,e,n){let o;const s=e,l=Ct(t);if(l||te(t)){const r=l&&Bi(t);let a=!1,c=!1;r&&(a=!Ie(t),c=si(t),t=wo(t)),o=new Array(t.length);for(let d=0,u=t.length;d<u;d++)o[d]=i(a?c?Gi(Re(t[d])):Re(t[d]):t[d],d,void 0,s)}else if(typeof t=="number"){o=new Array(t);for(let r=0;r<t;r++)o[r]=i(r+1,r,void 0,s)}else if(jt(t))if(t[Symbol.iterator])o=Array.from(t,(r,a)=>i(r,a,void 0,s));else{const r=Object.keys(t);o=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const d=r[a];o[a]=i(t[d],d,a,s)}}else o=[];return o}function Hn(t,i,e={},n,o,s){if(ae.ce||ae.parent&&Vi(ae.parent)&&ae.parent.ce){const c=e,d=Object.keys(c).length>0;return i!=="default"&&(c.name=i),tt(),Me(Kt,null,[ct("slot",c,n&&n())],d?-2:64)}let l=t[i];l&&l._c&&(l._d=!1);const r=ti.length;tt();let a;try{const c=l&&Sl(l(e)),d=e.key||s||c&&c.key;a=Me(Kt,{key:(d&&!Le(d)?d:`_${i}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&t._===1?64:-2)}catch(c){for(let d=ti.length;d>r;d--)Bs();throw c}finally{l&&l._c&&(l._d=!0)}return a}function Sl(t){return t.some(i=>Es(i)?!(i.type===ri||i.type===Kt&&!Sl(i.children)):!0)?t:null}const es=t=>t?Wl(t)?Io(t):es(t.parent):null,gn=ce(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>es(t.parent),$root:t=>es(t.root),$host:t=>t.ce,$emit:t=>t.emit,$options:t=>$l(t),$forceUpdate:t=>t.f||(t.f=()=>{Ss(t.update)}),$nextTick:t=>t.n||(t.n=pl.bind(t.proxy)),$watch:t=>rd.bind(t)}),No=(t,i)=>t!==Ut&&!t.__isScriptSetup&&zt(t,i),_d={get({_:t},i){if(i==="__v_skip")return!0;const{ctx:e,setupState:n,data:o,props:s,accessCache:l,type:r,appContext:a}=t;if(i[0]!=="$"){const v=l[i];if(v!==void 0)switch(v){case 1:return n[i];case 2:return o[i];case 4:return e[i];case 3:return s[i]}else{if(No(n,i))return l[i]=1,n[i];if(o!==Ut&&zt(o,i))return l[i]=2,o[i];if(zt(s,i))return l[i]=3,s[i];if(e!==Ut&&zt(e,i))return l[i]=4,e[i];is&&(l[i]=0)}}const c=gn[i];let d,u;if(c)return i==="$attrs"&&fe(t.attrs,"get",""),c(t);if((d=r.__cssModules)&&(d=d[i]))return d;if(e!==Ut&&zt(e,i))return l[i]=4,e[i];if(u=a.config.globalProperties,zt(u,i))return u[i]},set({_:t},i,e){const{data:n,setupState:o,ctx:s}=t;return No(o,i)?(o[i]=e,!0):n!==Ut&&zt(n,i)?(n[i]=e,!0):zt(t.props,i)||i[0]==="$"&&i.slice(1)in t?!1:(s[i]=e,!0)},has({_:{data:t,setupState:i,accessCache:e,ctx:n,appContext:o,props:s,type:l}},r){let a;return!!(e[r]||t!==Ut&&r[0]!=="$"&&zt(t,r)||No(i,r)||zt(s,r)||zt(n,r)||zt(gn,r)||zt(o.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(t,i,e){return e.get!=null?t._.accessCache[i]=0:zt(e,"value")&&this.set(t,i,e.value,null),Reflect.defineProperty(t,i,e)}};function tr(t){return Ct(t)?t.reduce((i,e)=>(i[e]=null,i),{}):t}let is=!0;function Sd(t){const i=$l(t),e=t.proxy,n=t.ctx;is=!1,i.beforeCreate&&er(i.beforeCreate,t,"bc");const{data:o,computed:s,methods:l,watch:r,provide:a,inject:c,created:d,beforeMount:u,mounted:v,beforeUpdate:f,updated:k,activated:p,deactivated:b,beforeDestroy:y,beforeUnmount:x,destroyed:_,unmounted:A,render:I,renderTracked:T,renderTriggered:w,errorCaptured:L,serverPrefetch:B,expose:N,inheritAttrs:Z,components:$,directives:U,filters:m}=i;if(c&&Cd(c,n,null),l)for(const M in l){const F=l[M];At(F)&&(n[M]=F.bind(e))}if(o){const M=o.call(e,e);jt(M)&&(t.data=xo(M))}if(is=!0,s)for(const M in s){const F=s[M],O=At(F)?F.bind(e,e):At(F.get)?F.get.bind(e,e):Ve,J=!At(F)&&At(F.set)?F.set.bind(e):Ve,j=_t({get:O,set:J});Object.defineProperty(n,M,{enumerable:!0,configurable:!0,get:()=>j.value,set:q=>j.value=q})}if(r)for(const M in r)Cl(r[M],n,e,M);if(a){const M=At(a)?a.call(e):a;Reflect.ownKeys(M).forEach(F=>{nd(F,M[F])})}d&&er(d,t,"c");function E(M,F){Ct(F)?F.forEach(O=>M(O.bind(e))):F&&M(F.bind(e))}if(E(fd,u),E(Dn,v),E(pd,f),E(hd,k),E(cd,p),E(dd,b),E(bd,L),E(vd,T),E(gd,w),E($s,x),E(Is,A),E(md,B),Ct(N))if(N.length){const M=t.exposed||(t.exposed={});N.forEach(F=>{Object.defineProperty(M,F,{get:()=>e[F],set:O=>e[F]=O,enumerable:!0})})}else t.exposed||(t.exposed={});I&&t.render===Ve&&(t.render=I),Z!=null&&(t.inheritAttrs=Z),$&&(t.components=$),U&&(t.directives=U),B&&wl(t)}function Cd(t,i,e=Ve){Ct(t)&&(t=ns(t));for(const n in t){const o=t[n];let s;jt(o)?"default"in o?s=Qe(o.from||n,o.default,!0):s=Qe(o.from||n):s=Qe(o),Yt(s)?Object.defineProperty(i,n,{enumerable:!0,configurable:!0,get:()=>s.value,set:l=>s.value=l}):i[n]=s}}function er(t,i,e){Pe(Ct(t)?t.map(n=>n.bind(i.proxy)):t.bind(i.proxy),i,e)}function Cl(t,i,e,n){let o=n.includes(".")?kl(e,n):()=>e[n];if(te(t)){const s=i[t];At(s)&&Ei(o,s)}else if(At(t))Ei(o,t.bind(e));else if(jt(t))if(Ct(t))t.forEach(s=>Cl(s,i,e,n));else{const s=At(t.handler)?t.handler.bind(e):i[t.handler];At(s)&&Ei(o,s,t)}}function $l(t){const i=t.type,{mixins:e,extends:n}=i,{mixins:o,optionsCache:s,config:{optionMergeStrategies:l}}=t.appContext,r=s.get(i);let a;return r?a=r:!o.length&&!e&&!n?a=i:(a={},o.length&&o.forEach(c=>ao(a,c,l,!0)),ao(a,i,l)),jt(i)&&s.set(i,a),a}function ao(t,i,e,n=!1){const{mixins:o,extends:s}=i;s&&ao(t,s,e,!0),o&&o.forEach(l=>ao(t,l,e,!0));for(const l in i)if(!(n&&l==="expose")){const r=$d[l]||e&&e[l];t[l]=r?r(t[l],i[l]):i[l]}return t}const $d={data:ir,props:nr,emits:nr,methods:ln,computed:ln,beforeCreate:he,created:he,beforeMount:he,mounted:he,beforeUpdate:he,updated:he,beforeDestroy:he,beforeUnmount:he,destroyed:he,unmounted:he,activated:he,deactivated:he,errorCaptured:he,serverPrefetch:he,components:ln,directives:ln,watch:Ad,provide:ir,inject:Id};function ir(t,i){return i?t?function(){return ce(At(t)?t.call(this,this):t,At(i)?i.call(this,this):i)}:i:t}function Id(t,i){return ln(ns(t),ns(i))}function ns(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++)i[t[e]]=t[e];return i}return t}function he(t,i){return t?[...new Set([].concat(t,i))]:i}function ln(t,i){return t?ce(Object.create(null),t,i):i}function nr(t,i){return t?Ct(t)&&Ct(i)?[...new Set([...t,...i])]:ce(Object.create(null),tr(t),tr(i??{})):i}function Ad(t,i){if(!t)return i;if(!i)return t;const e=ce(Object.create(null),t);for(const n in i)e[n]=he(t[n],i[n]);return e}function Il(){return{app:null,config:{isNativeTag:Ur,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Td=0;function Bd(t,i){return function(n,o=null){At(n)||(n=ce({},n)),o!=null&&!jt(o)&&(o=null);const s=Il(),l=new WeakSet,r=[];let a=!1;const c=s.app={_uid:Td++,_component:n,_props:o,_container:null,_context:s,_instance:null,version:au,get config(){return s.config},set config(d){},use(d,...u){return l.has(d)||(d&&At(d.install)?(l.add(d),d.install(c,...u)):At(d)&&(l.add(d),d(c,...u))),c},mixin(d){return s.mixins.includes(d)||s.mixins.push(d),c},component(d,u){return u?(s.components[d]=u,c):s.components[d]},directive(d,u){return u?(s.directives[d]=u,c):s.directives[d]},mount(d,u,v){if(!a){const f=c._ceVNode||ct(n,o);return f.appContext=s,v===!0?v="svg":v===!1&&(v=void 0),t(f,d,v),a=!0,c._container=d,d.__vue_app__=c,Io(f.component)}},onUnmount(d){r.push(d)},unmount(){a&&(Pe(r,c._instance,16),t(null,c._container),delete c._container.__vue_app__)},provide(d,u){return s.provides[d]=u,c},runWithContext(d){const u=Ki;Ki=c;try{return d()}finally{Ki=u}}};return c}}let Ki=null;const Ed=(t,i)=>i==="modelValue"||i==="model-value"?t.modelModifiers:t[`${i}Modifiers`]||t[`${ge(i)}Modifiers`]||t[`${vi(i)}Modifiers`];function Md(t,i,...e){if(t.isUnmounted)return;const n=t.vnode.props||Ut;let o=e;const s=i.startsWith("update:"),l=s&&Ed(n,i.slice(7));l&&(l.trim&&(o=e.map(d=>te(d)?d.trim():d)),l.number&&(o=e.map(yo)));let r,a=n[r=Do(i)]||n[r=Do(ge(i))];!a&&s&&(a=n[r=Do(vi(i))]),a&&Pe(a,t,6,o);const c=n[r+"Once"];if(c){if(!t.emitted)t.emitted={};else if(t.emitted[r])return;t.emitted[r]=!0,Pe(c,t,6,o)}}const Dd=new WeakMap;function Al(t,i,e=!1){const n=e?Dd:i.emitsCache,o=n.get(t);if(o!==void 0)return o;const s=t.emits;let l={},r=!1;if(!At(t)){const a=c=>{const d=Al(c,i,!0);d&&(r=!0,ce(l,d))};!e&&i.mixins.length&&i.mixins.forEach(a),t.extends&&a(t.extends),t.mixins&&t.mixins.forEach(a)}return!s&&!r?(jt(t)&&n.set(t,null),null):(Ct(s)?s.forEach(a=>l[a]=null):ce(l,s),jt(t)&&n.set(t,l),l)}function Co(t,i){return!t||!mo(i)?!1:(i=i.slice(2),i=i==="Once"?i:i.replace(/Once$/,""),zt(t,i[0].toLowerCase()+i.slice(1))||zt(t,vi(i))||zt(t,i))}function or(t){const{type:i,vnode:e,proxy:n,withProxy:o,propsOptions:[s],slots:l,attrs:r,emit:a,render:c,renderCache:d,props:u,data:v,setupState:f,ctx:k,inheritAttrs:p}=t,b=ro(t);let y,x;try{if(e.shapeFlag&4){const A=o||n,I=A;y=je(c.call(I,A,d,u,f,v,k)),x=r}else{const A=i;y=je(A.length>1?A(u,{attrs:r,slots:l,emit:a}):A(u,null)),x=i.props?r:Ld(r)}}catch(A){ti.length=0,_o(A,t,1),y=ct(ri)}let _=y;if(x&&p!==!1){const A=Object.keys(x),{shapeFlag:I}=_;A.length&&I&7&&(s&&A.some(go)&&(x=Rd(x,s)),_=Zi(_,x,!1,!0))}return e.dirs&&(_=Zi(_,null,!1,!0),_.dirs=_.dirs?_.dirs.concat(e.dirs):e.dirs),e.transition&&Cs(_,e.transition),y=_,ro(b),y}const Ld=t=>{let i;for(const e in t)(e==="class"||e==="style"||mo(e))&&((i||(i={}))[e]=t[e]);return i},Rd=(t,i)=>{const e={};for(const n in t)(!go(n)||!(n.slice(9)in i))&&(e[n]=t[n]);return e};function Pd(t,i,e){const{props:n,children:o,component:s}=t,{props:l,children:r,patchFlag:a}=i,c=s.emitsOptions;if(i.dirs||i.transition)return!0;if(e&&a>=0){if(a&1024)return!0;if(a&16)return n?sr(n,l,c):!!l;if(a&8){const d=i.dynamicProps;for(let u=0;u<d.length;u++){const v=d[u];if(Tl(l,n,v)&&!Co(c,v))return!0}}}else return(o||r)&&(!r||!r.$stable)?!0:n===l?!1:n?l?sr(n,l,c):!0:!!l;return!1}function sr(t,i,e){const n=Object.keys(i);if(n.length!==Object.keys(t).length)return!0;for(let o=0;o<n.length;o++){const s=n[o];if(Tl(i,t,s)&&!Co(e,s))return!0}return!1}function Tl(t,i,e){const n=t[e],o=i[e];return e==="style"&&jt(n)&&jt(o)?!Qi(n,o):n!==o}function Od({vnode:t,parent:i,suspense:e},n){for(;i;){const o=i.subTree;if(o.suspense&&o.suspense.activeBranch===t&&(o.suspense.vnode.el=o.el=n,t=o),o===t)(t=i.vnode).el=n,i=i.parent;else break}e&&e.activeBranch===t&&(e.vnode.el=n)}const Bl={},El=()=>Object.create(Bl),Ml=t=>Object.getPrototypeOf(t)===Bl;function zd(t,i,e,n=!1){const o={},s=El();t.propsDefaults=Object.create(null),Dl(t,i,o,s);for(const l in t.propsOptions[0])l in o||(o[l]=void 0);e?t.props=n?o:Vc(o):t.type.props?t.props=o:t.props=s,t.attrs=s}function Nd(t,i,e,n){const{props:o,attrs:s,vnode:{patchFlag:l}}=t,r=Ot(o),[a]=t.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const d=t.vnode.dynamicProps;for(let u=0;u<d.length;u++){let v=d[u];if(Co(t.emitsOptions,v))continue;const f=i[v];if(a)if(zt(s,v))f!==s[v]&&(s[v]=f,c=!0);else{const k=ge(v);o[k]=os(a,r,k,f,t,!1)}else f!==s[v]&&(s[v]=f,c=!0)}}}else{Dl(t,i,o,s)&&(c=!0);let d;for(const u in r)(!i||!zt(i,u)&&((d=vi(u))===u||!zt(i,d)))&&(a?e&&(e[u]!==void 0||e[d]!==void 0)&&(o[u]=os(a,r,u,void 0,t,!0)):delete o[u]);if(s!==r)for(const u in s)(!i||!zt(i,u))&&(delete s[u],c=!0)}c&&Je(t.attrs,"set","")}function Dl(t,i,e,n){const[o,s]=t.propsOptions;let l=!1,r;if(i)for(let a in i){if(fn(a))continue;const c=i[a];let d;o&&zt(o,d=ge(a))?!s||!s.includes(d)?e[d]=c:(r||(r={}))[d]=c:Co(t.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(s){const a=Ot(e),c=r||Ut;for(let d=0;d<s.length;d++){const u=s[d];e[u]=os(o,a,u,c[u],t,!zt(c,u))}}return l}function os(t,i,e,n,o,s){const l=t[e];if(l!=null){const r=zt(l,"default");if(r&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&At(a)){const{propsDefaults:c}=o;if(e in c)n=c[e];else{const d=Ln(o);n=c[e]=a.call(null,i),d()}}else n=a;o.ce&&o.ce._setProp(e,n)}l[0]&&(s&&!r?n=!1:l[1]&&(n===""||n===vi(e))&&(n=!0))}return n}const Fd=new WeakMap;function Ll(t,i,e=!1){const n=e?Fd:i.propsCache,o=n.get(t);if(o)return o;const s=t.props,l={},r=[];let a=!1;if(!At(t)){const d=u=>{a=!0;const[v,f]=Ll(u,i,!0);ce(l,v),f&&r.push(...f)};!e&&i.mixins.length&&i.mixins.forEach(d),t.extends&&d(t.extends),t.mixins&&t.mixins.forEach(d)}if(!s&&!a)return jt(t)&&n.set(t,Hi),Hi;if(Ct(s))for(let d=0;d<s.length;d++){const u=ge(s[d]);rr(u)&&(l[u]=Ut)}else if(s)for(const d in s){const u=ge(d);if(rr(u)){const v=s[d],f=l[u]=Ct(v)||At(v)?{type:v}:ce({},v),k=f.type;let p=!1,b=!0;if(Ct(k))for(let y=0;y<k.length;++y){const x=k[y],_=At(x)&&x.name;if(_==="Boolean"){p=!0;break}else _==="String"&&(b=!1)}else p=At(k)&&k.name==="Boolean";f[0]=p,f[1]=b,(p||zt(f,"default"))&&r.push(u)}}const c=[l,r];return jt(t)&&n.set(t,c),c}function rr(t){return t[0]!=="$"&&!fn(t)}const As=t=>t==="_"||t==="_ctx"||t==="$stable",Ts=t=>Ct(t)?t.map(je):[je(t)],jd=(t,i,e)=>{if(i._n)return i;const n=bl((...o)=>Ts(i(...o)),e);return n._c=!1,n},Rl=(t,i,e)=>{const n=t._ctx;for(const o in t){if(As(o))continue;const s=t[o];if(At(s))i[o]=jd(o,s,n);else if(s!=null){const l=Ts(s);i[o]=()=>l}}},Pl=(t,i)=>{const e=Ts(i);t.slots.default=()=>e},Ol=(t,i,e)=>{for(const n in i)(e||!As(n))&&(t[n]=i[n])},Hd=(t,i,e)=>{const n=t.slots=El();if(t.vnode.shapeFlag&32){const o=i._;o?(Ol(n,i,e),e&&qr(n,"_",o,!0)):Rl(i,n)}else i&&Pl(t,i)},Ud=(t,i,e)=>{const{vnode:n,slots:o}=t;let s=!0,l=Ut;if(n.shapeFlag&32){const r=i._;r?e&&r===1?s=!1:Ol(o,i,e):(s=!i.$stable,Rl(i,o)),l=i}else i&&(Pl(t,i),l={default:1});if(s)for(const r in o)!As(r)&&l[r]==null&&delete o[r]},be=Gd;function Wd(t){return Vd(t)}function Vd(t,i){const e=ko();e.__VUE__=!0;const{insert:n,remove:o,patchProp:s,createElement:l,createText:r,createComment:a,setText:c,setElementText:d,parentNode:u,nextSibling:v,setScopeId:f=Ve,insertStaticContent:k}=t,p=(D,z,h,H=null,P=null,S=null,C=void 0,R=null,G=!!z.dynamicChildren)=>{if(D===z)return;D&&!on(D,z)&&(H=pt(D),q(D,P,S,!0),D=null),z.patchFlag===-2&&(G=!1,z.dynamicChildren=null);const{type:W,ref:V,shapeFlag:Y}=z;switch(W){case $o:b(D,z,h,H);break;case ri:y(D,z,h,H);break;case qn:D==null&&x(z,h,H,C);break;case Kt:$(D,z,h,H,P,S,C,R,G);break;default:Y&1?I(D,z,h,H,P,S,C,R,G):Y&6?U(D,z,h,H,P,S,C,R,G):(Y&64||Y&128)&&W.process(D,z,h,H,P,S,C,R,G,ut)}V!=null&&P?mn(V,D&&D.ref,S,z||D,!z):V==null&&D&&D.ref!=null&&mn(D.ref,null,S,D,!0)},b=(D,z,h,H)=>{if(D==null)n(z.el=r(z.children),h,H);else{const P=z.el=D.el;z.children!==D.children&&c(P,z.children)}},y=(D,z,h,H)=>{D==null?n(z.el=a(z.children||""),h,H):z.el=D.el},x=(D,z,h,H)=>{[D.el,D.anchor]=k(D.children,z,h,H,D.el,D.anchor)},_=({el:D,anchor:z},h,H)=>{let P;for(;D&&D!==z;)P=v(D),n(D,h,H),D=P;n(z,h,H)},A=({el:D,anchor:z})=>{let h;for(;D&&D!==z;)h=v(D),o(D),D=h;o(z)},I=(D,z,h,H,P,S,C,R,G)=>{if(z.type==="svg"?C="svg":z.type==="math"&&(C="mathml"),D==null)T(z,h,H,P,S,C,R,G);else{const W=D.el&&D.el._isVueCE?D.el:null;try{W&&W._beginPatch(),B(D,z,P,S,C,R,G)}finally{W&&W._endPatch()}}},T=(D,z,h,H,P,S,C,R)=>{let G,W;const{props:V,shapeFlag:Y,transition:ot,dirs:it}=D;if(G=D.el=l(D.type,S,V&&V.is,V),Y&8?d(G,D.children):Y&16&&L(D.children,G,null,H,P,Fo(D,S),C,R),it&&xi(D,null,H,"created"),w(G,D,D.scopeId,C,H),V){for(const St in V)St!=="value"&&!fn(St)&&s(G,St,null,V[St],S,H);"value"in V&&s(G,"value",null,V.value,S),(W=V.onVnodeBeforeMount)&&ze(W,H,D)}it&&xi(D,null,H,"beforeMount");const at=Kd(P,ot);at&&ot.beforeEnter(G),n(G,z,h),((W=V&&V.onVnodeMounted)||at||it)&&be(()=>{try{W&&ze(W,H,D),at&&ot.enter(G),it&&xi(D,null,H,"mounted")}finally{}},P)},w=(D,z,h,H,P)=>{if(h&&f(D,h),H)for(let S=0;S<H.length;S++)f(D,H[S]);if(P){let S=P.subTree;if(z===S||jl(S.type)&&(S.ssContent===z||S.ssFallback===z)){const C=P.vnode;w(D,C,C.scopeId,C.slotScopeIds,P.parent)}}},L=(D,z,h,H,P,S,C,R,G=0)=>{for(let W=G;W<D.length;W++){const V=D[W]=R?Ye(D[W]):je(D[W]);p(null,V,z,h,H,P,S,C,R)}},B=(D,z,h,H,P,S,C)=>{const R=z.el=D.el;let{patchFlag:G,dynamicChildren:W,dirs:V}=z;G|=D.patchFlag&16;const Y=D.props||Ut,ot=z.props||Ut;let it;if(h&&_i(h,!1),(it=ot.onVnodeBeforeUpdate)&&ze(it,h,z,D),V&&xi(z,D,h,"beforeUpdate"),h&&_i(h,!0),W&&(!D.dynamicChildren||D.dynamicChildren.length!==W.length)&&(G=0,C=!1,W=null),(Y.innerHTML&&ot.innerHTML==null||Y.textContent&&ot.textContent==null)&&d(R,""),W?N(D.dynamicChildren,W,R,h,H,Fo(z,P),S):C||F(D,z,R,null,h,H,Fo(z,P),S,!1),G>0){if(G&16)Z(R,Y,ot,h,P);else if(G&2&&Y.class!==ot.class&&s(R,"class",null,ot.class,P),G&4&&s(R,"style",Y.style,ot.style,P),G&8){const at=z.dynamicProps;for(let St=0;St<at.length;St++){const kt=at[St],Mt=Y[kt],qt=ot[kt];(qt!==Mt||kt==="value")&&s(R,kt,Mt,qt,P,h)}}G&1&&D.children!==z.children&&d(R,z.children)}else!C&&W==null&&Z(R,Y,ot,h,P);((it=ot.onVnodeUpdated)||V)&&be(()=>{it&&ze(it,h,z,D),V&&xi(z,D,h,"updated")},H)},N=(D,z,h,H,P,S,C)=>{for(let R=0;R<z.length;R++){const G=D[R],W=z[R],V=G.el&&(G.type===Kt||!on(G,W)||G.shapeFlag&198)?u(G.el):h;p(G,W,V,null,H,P,S,C,!0)}},Z=(D,z,h,H,P)=>{if(z!==h){if(z!==Ut)for(const S in z)!fn(S)&&!(S in h)&&s(D,S,z[S],null,P,H);for(const S in h){if(fn(S))continue;const C=h[S],R=z[S];C!==R&&S!=="value"&&s(D,S,R,C,P,H)}"value"in h&&s(D,"value",z.value,h.value,P)}},$=(D,z,h,H,P,S,C,R,G)=>{const W=z.el=D?D.el:r(""),V=z.anchor=D?D.anchor:r("");let{patchFlag:Y,dynamicChildren:ot,slotScopeIds:it}=z;it&&(R=R?R.concat(it):it),D==null?(n(W,h,H),n(V,h,H),L(z.children||[],h,V,P,S,C,R,G)):Y>0&&Y&64&&ot&&D.dynamicChildren&&D.dynamicChildren.length===ot.length?(N(D.dynamicChildren,ot,h,P,S,C,R),(z.key!=null||P&&z===P.subTree)&&zl(D,z,!0)):F(D,z,h,V,P,S,C,R,G)},U=(D,z,h,H,P,S,C,R,G)=>{z.slotScopeIds=R,D==null?z.shapeFlag&512?P.ctx.activate(z,h,H,C,G):m(z,h,H,P,S,C,G):K(D,z,G)},m=(D,z,h,H,P,S,C)=>{const R=D.component=tu(D,H,P);if(xl(D)&&(R.ctx.renderer=ut),iu(R,!1,C),R.asyncDep){if(P&&P.registerDep(R,E,C),!D.el){const G=R.subTree=ct(ri);y(null,G,z,h),D.placeholder=G.el}}else E(R,D,z,h,P,S,C)},K=(D,z,h)=>{const H=z.component=D.component;if(Pd(D,z,h))if(H.asyncDep&&!H.asyncResolved){M(H,z,h);return}else H.next=z,H.update();else z.el=D.el,H.vnode=z},E=(D,z,h,H,P,S,C)=>{const R=()=>{if(D.isMounted){let{next:Y,bu:ot,u:it,parent:at,vnode:St}=D;{const ne=Nl(D);if(ne){Y&&(Y.el=St.el,M(D,Y,C)),ne.asyncDep.then(()=>{be(()=>{D.isUnmounted||W()},P)});return}}let kt=Y,Mt;_i(D,!1),Y?(Y.el=St.el,M(D,Y,C)):Y=St,ot&&Kn(ot),(Mt=Y.props&&Y.props.onVnodeBeforeUpdate)&&ze(Mt,at,Y,St),_i(D,!0);const qt=or(D),Gt=D.subTree;D.subTree=qt,p(Gt,qt,u(Gt.el),pt(Gt),D,P,S),Y.el=qt.el,kt===null&&Od(D,qt.el),it&&be(it,P),(Mt=Y.props&&Y.props.onVnodeUpdated)&&be(()=>ze(Mt,at,Y,St),P)}else{let Y;const{el:ot,props:it}=z,{bm:at,m:St,parent:kt,root:Mt,type:qt}=D,Gt=Vi(z);_i(D,!1),at&&Kn(at),!Gt&&(Y=it&&it.onVnodeBeforeMount)&&ze(Y,kt,z),_i(D,!0);{Mt.ce&&Mt.ce._hasShadowRoot()&&Mt.ce._injectChildStyle(qt,D.parent?D.parent.type:void 0);const ne=D.subTree=or(D);p(null,ne,h,H,D,P,S),z.el=ne.el}if(St&&be(St,P),!Gt&&(Y=it&&it.onVnodeMounted)){const ne=z;be(()=>ze(Y,kt,ne),P)}(z.shapeFlag&256||kt&&Vi(kt.vnode)&&kt.vnode.shapeFlag&256)&&D.a&&be(D.a,P),D.isMounted=!0,z=h=H=null}};D.scope.on();const G=D.effect=new Jr(R);D.scope.off();const W=D.update=G.run.bind(G),V=D.job=G.runIfDirty.bind(G);V.i=D,V.id=D.uid,G.scheduler=()=>Ss(V),_i(D,!0),W()},M=(D,z,h)=>{z.component=D;const H=D.vnode.props;D.vnode=z,D.next=null,Nd(D,z.props,H,h),Ud(D,z.children,h),ni(),Ys(D),oi()},F=(D,z,h,H,P,S,C,R,G=!1)=>{const W=D&&D.children,V=D?D.shapeFlag:0,Y=z.children,{patchFlag:ot,shapeFlag:it}=z;if(ot>0){if(ot&128){J(W,Y,h,H,P,S,C,R,G);return}else if(ot&256){O(W,Y,h,H,P,S,C,R,G);return}}it&8?(V&16&&Q(W,P,S),Y!==W&&d(h,Y)):V&16?it&16?J(W,Y,h,H,P,S,C,R,G):Q(W,P,S,!0):(V&8&&d(h,""),it&16&&L(Y,h,H,P,S,C,R,G))},O=(D,z,h,H,P,S,C,R,G)=>{D=D||Hi,z=z||Hi;const W=D.length,V=z.length,Y=Math.min(W,V);let ot;for(ot=0;ot<Y;ot++){const it=z[ot]=G?Ye(z[ot]):je(z[ot]);p(D[ot],it,h,null,P,S,C,R,G)}W>V?Q(D,P,S,!0,!1,Y):L(z,h,H,P,S,C,R,G,Y)},J=(D,z,h,H,P,S,C,R,G)=>{let W=0;const V=z.length;let Y=D.length-1,ot=V-1;for(;W<=Y&&W<=ot;){const it=D[W],at=z[W]=G?Ye(z[W]):je(z[W]);if(on(it,at))p(it,at,h,null,P,S,C,R,G);else break;W++}for(;W<=Y&&W<=ot;){const it=D[Y],at=z[ot]=G?Ye(z[ot]):je(z[ot]);if(on(it,at))p(it,at,h,null,P,S,C,R,G);else break;Y--,ot--}if(W>Y){if(W<=ot){const it=ot+1,at=it<V?z[it].el:H;for(;W<=ot;)p(null,z[W]=G?Ye(z[W]):je(z[W]),h,at,P,S,C,R,G),W++}}else if(W>ot)for(;W<=Y;)q(D[W],P,S,!0),W++;else{const it=W,at=W,St=new Map;for(W=at;W<=ot;W++){const ee=z[W]=G?Ye(z[W]):je(z[W]);ee.key!=null&&St.set(ee.key,W)}let kt,Mt=0;const qt=ot-at+1;let Gt=!1,ne=0;const Nt=new Array(qt);for(W=0;W<qt;W++)Nt[W]=0;for(W=it;W<=Y;W++){const ee=D[W];if(Mt>=qt){q(ee,P,S,!0);continue}let Jt;if(ee.key!=null)Jt=St.get(ee.key);else for(kt=at;kt<=ot;kt++)if(Nt[kt-at]===0&&on(ee,z[kt])){Jt=kt;break}Jt===void 0?q(ee,P,S,!0):(Nt[Jt-at]=W+1,Jt>=ne?ne=Jt:Gt=!0,p(ee,z[Jt],h,null,P,S,C,R,G),Mt++)}const Ke=Gt?qd(Nt):Hi;for(kt=Ke.length-1,W=qt-1;W>=0;W--){const ee=at+W,Jt=z[ee],bi=z[ee+1],Li=ee+1<V?bi.el||Fl(bi):H;Nt[W]===0?p(null,Jt,h,Li,P,S,C,R,G):Gt&&(kt<0||W!==Ke[kt]?j(Jt,h,Li,2):kt--)}}},j=(D,z,h,H,P=null)=>{const{el:S,type:C,transition:R,children:G,shapeFlag:W}=D;if(W&6){j(D.component.subTree,z,h,H);return}if(W&128){D.suspense.move(z,h,H);return}if(W&64){C.move(D,z,h,ut);return}if(C===Kt){n(S,z,h);for(let Y=0;Y<G.length;Y++)j(G[Y],z,h,H);n(D.anchor,z,h);return}if(C===qn){_(D,z,h);return}if(H!==2&&W&1&&R)if(H===0)R.persisted&&!S[zo]?n(S,z,h):(R.beforeEnter(S),n(S,z,h),be(()=>R.enter(S),P));else{const{leave:Y,delayLeave:ot,afterLeave:it}=R,at=()=>{D.ctx.isUnmounted?o(S):n(S,z,h)},St=()=>{const kt=S._isLeaving||!!S[zo];S._isLeaving&&S[zo](!0),R.persisted&&!kt?at():Y(S,()=>{at(),it&&it()})};ot?ot(S,at,St):St()}else n(S,z,h)},q=(D,z,h,H=!1,P=!1)=>{const{type:S,props:C,ref:R,children:G,dynamicChildren:W,shapeFlag:V,patchFlag:Y,dirs:ot,cacheIndex:it,memo:at}=D;if(Y===-2&&(P=!1),R!=null&&(ni(),mn(R,null,h,D,!0),oi()),it!=null&&(z.renderCache[it]=void 0),V&256){z.ctx.deactivate(D);return}const St=V&1&&ot,kt=!Vi(D);let Mt;if(kt&&(Mt=C&&C.onVnodeBeforeUnmount)&&ze(Mt,z,D),V&6)st(D.component,h,H);else{if(V&128){D.suspense.unmount(h,H);return}St&&xi(D,null,z,"beforeUnmount"),V&64?D.type.remove(D,z,h,ut,H):W&&!W.hasOnce&&(S!==Kt||Y>0&&Y&64)?Q(W,z,h,!1,!0):(S===Kt&&Y&384||!P&&V&16)&&Q(G,z,h),H&&rt(D)}const qt=at!=null&&it==null;(kt&&(Mt=C&&C.onVnodeUnmounted)||St||qt)&&be(()=>{Mt&&ze(Mt,z,D),St&&xi(D,null,z,"unmounted"),qt&&(D.el=null)},h)},rt=D=>{const{type:z,el:h,anchor:H,transition:P}=D;if(z===Kt){lt(h,H);return}if(z===qn){A(D);return}const S=()=>{o(h),P&&!P.persisted&&P.afterLeave&&P.afterLeave()};if(D.shapeFlag&1&&P&&!P.persisted){const{leave:C,delayLeave:R}=P,G=()=>C(h,S);R?R(D.el,S,G):G()}else S()},lt=(D,z)=>{let h;for(;D!==z;)h=v(D),o(D),D=h;o(z)},st=(D,z,h)=>{const{bum:H,scope:P,job:S,subTree:C,um:R,m:G,a:W}=D;lr(G),lr(W),H&&Kn(H),P.stop(),S&&(S.flags|=8,q(C,D,z,h)),R&&be(R,z),be(()=>{D.isUnmounted=!0},z)},Q=(D,z,h,H=!1,P=!1,S=0)=>{for(let C=S;C<D.length;C++)q(D[C],z,h,H,P)},pt=D=>{if(D.shapeFlag&6)return pt(D.component.subTree);if(D.shapeFlag&128)return D.suspense.next();const z=v(D.anchor||D.el),h=z&&z[ld];return h?v(h):z};let bt=!1;const X=(D,z,h)=>{let H;D==null?z._vnode&&(q(z._vnode,null,null,!0),H=z._vnode.component):p(z._vnode||null,D,z,null,null,null,h),z._vnode=D,bt||(bt=!0,Ys(H),ml(),bt=!1)},ut={p,um:q,m:j,r:rt,mt:m,mc:L,pc:F,pbc:N,n:pt,o:t};return{render:X,hydrate:void 0,createApp:Bd(X)}}function Fo({type:t,props:i},e){return e==="svg"&&t==="foreignObject"||e==="mathml"&&t==="annotation-xml"&&i&&i.encoding&&i.encoding.includes("html")?void 0:e}function _i({effect:t,job:i},e){e?(t.flags|=32,i.flags|=4):(t.flags&=-33,i.flags&=-5)}function Kd(t,i){return(!t||t&&!t.pendingBranch)&&i&&!i.persisted}function zl(t,i,e=!1){const n=t.children,o=i.children;if(Ct(n)&&Ct(o))for(let s=0;s<n.length;s++){const l=n[s];let r=o[s];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=o[s]=Ye(o[s]),r.el=l.el),!e&&r.patchFlag!==-2&&zl(l,r)),r.type===$o&&(r.patchFlag===-1&&(r=o[s]=Ye(r)),r.el=l.el),r.type===ri&&!r.el&&(r.el=l.el)}}function qd(t){const i=t.slice(),e=[0];let n,o,s,l,r;const a=t.length;for(n=0;n<a;n++){const c=t[n];if(c!==0){if(o=e[e.length-1],t[o]<c){i[n]=o,e.push(n);continue}for(s=0,l=e.length-1;s<l;)r=s+l>>1,t[e[r]]<c?s=r+1:l=r;c<t[e[s]]&&(s>0&&(i[n]=e[s-1]),e[s]=n)}}for(s=e.length,l=e[s-1];s-- >0;)e[s]=l,l=i[l];return e}function Nl(t){const i=t.subTree.component;if(i)return i.asyncDep&&!i.asyncResolved?i:Nl(i)}function lr(t){if(t)for(let i=0;i<t.length;i++)t[i].flags|=8}function Fl(t){if(t.placeholder)return t.placeholder;const i=t.component;return i?Fl(i.subTree):null}const jl=t=>t.__isSuspense;function Gd(t,i){i&&i.pendingBranch?Ct(t)?i.effects.push(...t):i.effects.push(t):id(t)}const Kt=Symbol.for("v-fgt"),$o=Symbol.for("v-txt"),ri=Symbol.for("v-cmt"),qn=Symbol.for("v-stc"),ti=[];let _e=null;function tt(t=!1){ti.push(_e=t?null:[])}function Bs(){ti.pop(),_e=ti[ti.length-1]||null}let $n=1;function ar(t,i=!1){$n+=t,t<0&&_e&&i&&(_e.hasOnce=!0)}function Hl(t){return t.dynamicChildren=$n>0?_e||Hi:null,Bs(),$n>0&&_e&&_e.push(t),t}function nt(t,i,e,n,o,s){return Hl(g(t,i,e,n,o,s,!0))}function Me(t,i,e,n,o){return Hl(ct(t,i,e,n,o,!0))}function Es(t){return t?t.__v_isVNode===!0:!1}function on(t,i){return t.type===i.type&&t.key===i.key}const Ul=({key:t})=>t??null,Gn=({ref:t,ref_key:i,ref_for:e})=>(typeof t=="number"&&(t=""+t),t!=null?te(t)||Yt(t)||At(t)?{i:ae,r:t,k:i,f:!!e}:t:null);function g(t,i=null,e=null,n=0,o=null,s=t===Kt?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:t,props:i,key:i&&Ul(i),ref:i&&Gn(i),scopeId:vl,slotScopeIds:null,children:e,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:n,dynamicProps:o,dynamicChildren:null,appContext:null,ctx:ae};return r?(uo(a,e),s&128&&t.normalize(a)):e&&(a.shapeFlag|=te(e)?8:16),$n>0&&!l&&_e&&(a.patchFlag>0||s&6)&&a.patchFlag!==32&&_e.push(a),a}const ct=Zd;function Zd(t,i=null,e=null,n=0,o=null,s=!1){if((!t||t===wd)&&(t=ri),Es(t)){const r=Zi(t,i,!0);return e&&uo(r,e),$n>0&&!s&&_e&&(r.shapeFlag&6?_e[_e.indexOf(t)]=r:_e.push(r)),r.patchFlag=-2,r}if(lu(t)&&(t=t.__vccOpts),i){i=Yd(i);let{class:r,style:a}=i;r&&!te(r)&&(i.class=It(r)),jt(a)&&(_s(a)&&!Ct(a)&&(a=ce({},a)),i.style=ms(a))}const l=te(t)?1:jl(t)?128:ad(t)?64:jt(t)?4:At(t)?2:0;return g(t,i,e,n,o,l,s,!0)}function Yd(t){return t?_s(t)||Ml(t)?ce({},t):t:null}function Zi(t,i,e=!1,n=!1){const{props:o,ref:s,patchFlag:l,children:r,transition:a}=t,c=i?Jd(o||{},i):o,d={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&Ul(c),ref:i&&i.ref?e&&s?Ct(s)?s.concat(Gn(i)):[s,Gn(i)]:Gn(i):s,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:r,target:t.target,targetStart:t.targetStart,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:i&&t.type!==Kt?l===-1?16:l|16:l,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:a,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&Zi(t.ssContent),ssFallback:t.ssFallback&&Zi(t.ssFallback),placeholder:t.placeholder,el:t.el,anchor:t.anchor,ctx:t.ctx,ce:t.ce};return a&&n&&Cs(d,a.clone(d)),d}function co(t=" ",i=0){return ct($o,null,t,i)}function Ae(t,i){const e=ct(qn,null,t);return e.staticCount=i,e}function Lt(t="",i=!1){return i?(tt(),Me(ri,null,t)):ct(ri,null,t)}function je(t){return t==null||typeof t=="boolean"?ct(ri):Ct(t)?ct(Kt,null,t.slice()):Es(t)?Ye(t):ct($o,null,String(t))}function Ye(t){return t.el===null&&t.patchFlag!==-1||t.memo?t:Zi(t)}function uo(t,i){let e=0;const{shapeFlag:n}=t;if(i==null)i=null;else if(Ct(i))e=16;else if(typeof i=="object")if(n&65){const o=i.default;o&&(o._c&&(o._d=!1),uo(t,o()),o._c&&(o._d=!0));return}else{e=32;const o=i._;!o&&!Ml(i)?i._ctx=ae:o===3&&ae&&(ae.slots._===1?i._=1:(i._=2,t.patchFlag|=1024))}else if(At(i)){if(n&65){uo(t,{default:i});return}i={default:i,_ctx:ae},e=32}else i=String(i),n&64?(e=16,i=[co(i)]):e=8;t.children=i,t.shapeFlag|=e}function Jd(...t){const i={};for(let e=0;e<t.length;e++){const n=t[e];for(const o in n)if(o==="class")i.class!==n.class&&(i.class=It([i.class,n.class]));else if(o==="style")i.style=ms([i.style,n.style]);else if(mo(o)){const s=i[o],l=n[o];l&&s!==l&&!(Ct(s)&&s.includes(l))?i[o]=s?[].concat(s,l):l:l==null&&s==null&&!go(o)&&(i[o]=l)}else o!==""&&(i[o]=n[o])}return i}function ze(t,i,e,n=null){Pe(t,i,7,[e,n])}const Xd=Il();let Qd=0;function tu(t,i,e){const n=t.type,o=(i?i.appContext:t.appContext)||Xd,s={uid:Qd++,vnode:t,type:n,parent:i,appContext:o,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new $c(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:i?i.provides:Object.create(o.provides),ids:i?i.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Ll(n,o),emitsOptions:Al(n,o),emit:null,emitted:null,propsDefaults:Ut,inheritAttrs:n.inheritAttrs,ctx:Ut,data:Ut,props:Ut,attrs:Ut,slots:Ut,refs:Ut,setupState:Ut,setupContext:null,suspense:e,suspenseId:e?e.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return s.ctx={_:s},s.root=i?i.root:s,s.emit=Md.bind(null,s),t.ce&&t.ce(s),s}let pe=null;const eu=()=>pe||ae;let fo,ss;{const t=ko(),i=(e,n)=>{let o;return(o=t[e])||(o=t[e]=[]),o.push(n),s=>{o.length>1?o.forEach(l=>l(s)):o[0](s)}};fo=i("__VUE_INSTANCE_SETTERS__",e=>pe=e),ss=i("__VUE_SSR_SETTERS__",e=>In=e)}const Ln=t=>{const i=pe;return fo(t),t.scope.on(),()=>{t.scope.off(),fo(i)}},cr=()=>{pe&&pe.scope.off(),fo(null)};function Wl(t){return t.vnode.shapeFlag&4}let In=!1;function iu(t,i=!1,e=!1){i&&ss(i);const{props:n,children:o}=t.vnode,s=Wl(t);zd(t,n,s,i),Hd(t,o,e||i);const l=s?nu(t,i):void 0;return i&&ss(!1),l}function nu(t,i){const e=t.type;t.accessCache=Object.create(null),t.proxy=new Proxy(t.ctx,_d);const{setup:n}=e;if(n){ni();const o=t.setupContext=n.length>1?su(t):null,s=Ln(t),l=Mn(n,t,0,[t.props,o]),r=Wr(l);if(oi(),s(),(r||t.sp)&&!Vi(t)&&wl(t),r){if(l.then(cr,cr),i)return l.then(a=>{dr(t,a)}).catch(a=>{_o(a,t,0)});t.asyncDep=l}else dr(t,l)}else Vl(t)}function dr(t,i,e){At(i)?t.type.__ssrInlineRender?t.ssrRender=i:t.render=i:jt(i)&&(t.setupState=ul(i)),Vl(t)}function Vl(t,i,e){const n=t.type;t.render||(t.render=n.render||Ve);{const o=Ln(t);ni();try{Sd(t)}finally{oi(),o()}}}const ou={get(t,i){return fe(t,"get",""),t[i]}};function su(t){const i=e=>{t.exposed=e||{}};return{attrs:new Proxy(t.attrs,ou),slots:t.slots,emit:t.emit,expose:i}}function Io(t){return t.exposed?t.exposeProxy||(t.exposeProxy=new Proxy(ul(Kc(t.exposed)),{get(i,e){if(e in i)return i[e];if(e in gn)return gn[e](t)},has(i,e){return e in i||e in gn}})):t.proxy}function ru(t,i=!0){return At(t)?t.displayName||t.name:t.name||i&&t.__name}function lu(t){return At(t)&&"__vccOpts"in t}const _t=(t,i)=>Jc(t,i,In),au="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let rs;const ur=typeof window<"u"&&window.trustedTypes;if(ur)try{rs=ur.createPolicy("vue",{createHTML:t=>t})}catch{}const Kl=rs?t=>rs.createHTML(t):t=>t,cu="http://www.w3.org/2000/svg",du="http://www.w3.org/1998/Math/MathML",Ze=typeof document<"u"?document:null,fr=Ze&&Ze.createElement("template"),uu={insert:(t,i,e)=>{i.insertBefore(t,e||null)},remove:t=>{const i=t.parentNode;i&&i.removeChild(t)},createElement:(t,i,e,n)=>{const o=i==="svg"?Ze.createElementNS(cu,t):i==="mathml"?Ze.createElementNS(du,t):e?Ze.createElement(t,{is:e}):Ze.createElement(t);return t==="select"&&n&&n.multiple!=null&&o.setAttribute("multiple",n.multiple),o},createText:t=>Ze.createTextNode(t),createComment:t=>Ze.createComment(t),setText:(t,i)=>{t.nodeValue=i},setElementText:(t,i)=>{t.textContent=i},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>Ze.querySelector(t),setScopeId(t,i){t.setAttribute(i,"")},insertStaticContent(t,i,e,n,o,s){const l=e?e.previousSibling:i.lastChild;if(o&&(o===s||o.nextSibling))for(;i.insertBefore(o.cloneNode(!0),e),!(o===s||!(o=o.nextSibling)););else{fr.innerHTML=Kl(n==="svg"?`<svg>${t}</svg>`:n==="mathml"?`<math>${t}</math>`:t);const r=fr.content;if(n==="svg"||n==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}i.insertBefore(r,e)}return[l?l.nextSibling:i.firstChild,e?e.previousSibling:i.lastChild]}},fu=Symbol("_vtc");function pu(t,i,e){const n=t[fu];n&&(i=(i?[i,...n]:[...n]).join(" ")),i==null?t.removeAttribute("class"):e?t.setAttribute("class",i):t.className=i}const po=Symbol("_vod"),ql=Symbol("_vsh"),Gl={name:"show",beforeMount(t,{value:i},{transition:e}){t[po]=t.style.display==="none"?"":t.style.display,e&&i?e.beforeEnter(t):sn(t,i)},mounted(t,{value:i},{transition:e}){e&&i&&e.enter(t)},updated(t,{value:i,oldValue:e},{transition:n}){!i!=!e&&(n?i?(n.beforeEnter(t),sn(t,!0),n.enter(t)):n.leave(t,()=>{sn(t,!1)}):sn(t,i))},beforeUnmount(t,{value:i}){sn(t,i)}};function sn(t,i){t.style.display=i?t[po]:"none",t[ql]=!i}const hu=Symbol(""),mu=/(?:^|;)\s*display\s*:/;function gu(t,i,e){const n=t.style,o=te(e);let s=!1;if(e&&!o){if(i)if(te(i))for(const l of i.split(";")){const r=l.slice(0,l.indexOf(":")).trim();e[r]==null&&an(n,r,"")}else for(const l in i)e[l]==null&&an(n,l,"");for(const l in e){l==="display"&&(s=!0);const r=e[l];r!=null?bu(t,l,!te(i)&&i?i[l]:void 0,r)||an(n,l,r):an(n,l,"")}}else if(o){if(i!==e){const l=n[hu];l&&(e+=";"+l),n.cssText=e,s=mu.test(e)}}else i&&t.removeAttribute("style");po in t&&(t[po]=s?n.display:"",t[ql]&&(n.display="none"))}const pr=/\s*!important$/;function an(t,i,e){if(Ct(e))e.forEach(n=>an(t,i,n));else if(e==null&&(e=""),i.startsWith("--"))t.setProperty(i,e);else{const n=vu(t,i);pr.test(e)?t.setProperty(vi(n),e.replace(pr,""),"important"):t[n]=e}}const hr=["Webkit","Moz","ms"],jo={};function vu(t,i){const e=jo[i];if(e)return e;let n=ge(i);if(n!=="filter"&&n in t)return jo[i]=n;n=bo(n);for(let o=0;o<hr.length;o++){const s=hr[o]+n;if(s in t)return jo[i]=s}return i}function bu(t,i,e,n){return t.tagName==="TEXTAREA"&&(i==="width"||i==="height")&&te(n)&&e===n}const mr="http://www.w3.org/1999/xlink";function gr(t,i,e,n,o,s=Sc(i)){n&&i.startsWith("xlink:")?e==null?t.removeAttributeNS(mr,i.slice(6,i.length)):t.setAttributeNS(mr,i,e):e==null||s&&!Gr(e)?t.removeAttribute(i):t.setAttribute(i,s?"":Le(e)?String(e):e)}function vr(t,i,e,n,o){if(i==="innerHTML"||i==="textContent"){e!=null&&(t[i]=i==="innerHTML"?Kl(e):e);return}const s=t.tagName;if(i==="value"&&s!=="PROGRESS"&&!s.includes("-")){const r=s==="OPTION"?t.getAttribute("value")||"":t.value,a=e==null?t.type==="checkbox"?"on":"":String(e);(r!==a||!("_value"in t))&&(t.value=a),e==null&&t.removeAttribute(i),t._value=e;return}let l=!1;if(e===""||e==null){const r=typeof t[i];r==="boolean"?e=Gr(e):e==null&&r==="string"?(e="",l=!0):r==="number"&&(e=0,l=!0)}try{t[i]=e}catch{}l&&t.removeAttribute(o||i)}function fi(t,i,e,n){t.addEventListener(i,e,n)}function yu(t,i,e,n){t.removeEventListener(i,e,n)}const br=Symbol("_vei");function ku(t,i,e,n,o=null){const s=t[br]||(t[br]={}),l=s[i];if(n&&l)l.value=n;else{const[r,a]=_u(i);if(n){const c=s[i]=$u(n,o);fi(t,r,c,a)}else l&&(yu(t,r,l,a),s[i]=void 0)}}const wu=/(Once|Passive|Capture)$/,xu=/^on:?(?:Once|Passive|Capture)$/;function _u(t){let i,e;for(;(e=t.match(wu))&&!xu.test(t);)i||(i={}),t=t.slice(0,t.length-e[1].length),i[e[1].toLowerCase()]=!0;return[t[2]===":"?t.slice(3):vi(t.slice(2)),i]}let Ho=0;const Su=Promise.resolve(),Cu=()=>Ho||(Su.then(()=>Ho=0),Ho=Date.now());function $u(t,i){const e=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=e.attached)return;const o=e.value;if(Ct(o)){const s=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{s.call(n),n._stopped=!0};const l=o.slice(),r=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Pe(c,i,5,r)}}else Pe(o,i,5,[n])};return e.value=t,e.attached=Cu(),e}const yr=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&t.charCodeAt(2)>96&&t.charCodeAt(2)<123,Iu=(t,i,e,n,o,s)=>{const l=o==="svg";i==="class"?pu(t,n,l):i==="style"?gu(t,e,n):mo(i)?go(i)||ku(t,i,e,n,s):(i[0]==="."?(i=i.slice(1),!0):i[0]==="^"?(i=i.slice(1),!1):Au(t,i,n,l))?(vr(t,i,n),!t.tagName.includes("-")&&(i==="value"||i==="checked"||i==="selected")&&gr(t,i,n,l,s,i!=="value")):t._isVueCE&&(Tu(t,i)||t._def.__asyncLoader&&(/[A-Z]/.test(i)||!te(n)))?vr(t,ge(i),n,s,i):(i==="true-value"?t._trueValue=n:i==="false-value"&&(t._falseValue=n),gr(t,i,n,l))};function Au(t,i,e,n){if(n)return!!(i==="innerHTML"||i==="textContent"||i in t&&yr(i)&&At(e));if(i==="spellcheck"||i==="draggable"||i==="translate"||i==="autocorrect"||i==="sandbox"&&t.tagName==="IFRAME"||i==="form"||i==="list"&&t.tagName==="INPUT"||i==="type"&&t.tagName==="TEXTAREA")return!1;if(i==="width"||i==="height"){const o=t.tagName;if(o==="IMG"||o==="VIDEO"||o==="CANVAS"||o==="SOURCE")return!1}return yr(i)&&te(e)?!1:i in t}function Tu(t,i){const e=t._def.props;if(!e)return!1;const n=ge(i);return Array.isArray(e)?e.some(o=>ge(o)===n):Object.keys(e).some(o=>ge(o)===n)}const Yi=t=>{const i=t.props["onUpdate:modelValue"]||!1;return Ct(i)?e=>Kn(i,e):i};function Bu(t){t.target.composing=!0}function kr(t){const i=t.target;i.composing&&(i.composing=!1,i.dispatchEvent(new Event("input")))}const ei=Symbol("_assign");function wr(t,i,e){return i&&(t=t.trim()),e&&(t=yo(t)),t}const ho={created(t,{modifiers:{lazy:i,trim:e,number:n}},o){t[ei]=Yi(o);const s=n||o.props&&o.props.type==="number";fi(t,i?"change":"input",l=>{l.target.composing||t[ei](wr(t.value,e,s))}),(e||s)&&fi(t,"change",()=>{t.value=wr(t.value,e,s)}),i||(fi(t,"compositionstart",Bu),fi(t,"compositionend",kr),fi(t,"change",kr))},mounted(t,{value:i}){t.value=i??""},beforeUpdate(t,{value:i,oldValue:e,modifiers:{lazy:n,trim:o,number:s}},l){if(t[ei]=Yi(l),t.composing)return;const r=(s||t.type==="number")&&!/^0\d/.test(t.value)?yo(t.value):t.value,a=i??"";if(r===a)return;const c=t.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===t&&t.type!=="range"&&(n&&i===e||o&&t.value.trim()===a)||(t.value=a)}},Un={deep:!0,created(t,i,e){t[ei]=Yi(e),fi(t,"change",()=>{const n=t._modelValue,o=An(t),s=t.checked,l=t[ei];if(Ct(n)){const r=gs(n,o),a=r!==-1;if(s&&!a)l(n.concat(o));else if(!s&&a){const c=[...n];c.splice(r,1),l(c)}}else if(Xi(n)){const r=new Set(n);s?r.add(o):r.delete(o),l(r)}else l(Zl(t,s))})},mounted:xr,beforeUpdate(t,i,e){t[ei]=Yi(e),xr(t,i,e)}};function xr(t,{value:i,oldValue:e},n){t._modelValue=i;let o;if(Ct(i))o=gs(i,n.props.value)>-1;else if(Xi(i))o=i.has(n.props.value);else{if(i===e)return;o=Qi(i,Zl(t,!0))}t.checked!==o&&(t.checked=o)}const Eu={deep:!0,created(t,{value:i,modifiers:{number:e}},n){t._modelValue=i,fi(t,"change",()=>{const o=Array.prototype.filter.call(t.options,s=>s.selected).map(s=>e?yo(An(s)):An(s));t[ei](t.multiple?Xi(t._modelValue)?new Set(o):o:o[0]),t._assigning=!0,pl(()=>{t._assigning=!1})}),t[ei]=Yi(n)},mounted(t,{value:i}){_r(t,i)},beforeUpdate(t,{value:i},e){t._modelValue=i,t[ei]=Yi(e)},updated(t,{value:i}){t._assigning||_r(t,i)}};function _r(t,i){const e=t.multiple,n=Ct(i);if(!(e&&!n&&!Xi(i))){for(let o=0,s=t.options.length;o<s;o++){const l=t.options[o],r=An(l);if(e)if(n){const a=typeof r;a==="string"||a==="number"?l.selected=i.some(c=>String(c)===String(r)):l.selected=gs(i,r)>-1}else l.selected=i.has(r);else if(Qi(An(l),i)){t.selectedIndex!==o&&(t.selectedIndex=o);return}}!e&&t.selectedIndex!==-1&&(t.selectedIndex=-1)}}function An(t){return"_value"in t?t._value:t.value}function Zl(t,i){const e=i?"_trueValue":"_falseValue";return e in t?t[e]:i}const Mu=["ctrl","shift","alt","meta"],Du={stop:t=>t.stopPropagation(),prevent:t=>t.preventDefault(),self:t=>t.target!==t.currentTarget,ctrl:t=>!t.ctrlKey,shift:t=>!t.shiftKey,alt:t=>!t.altKey,meta:t=>!t.metaKey,left:t=>"button"in t&&t.button!==0,middle:t=>"button"in t&&t.button!==1,right:t=>"button"in t&&t.button!==2,exact:(t,i)=>Mu.some(e=>t[`${e}Key`]&&!i.includes(e))},Ee=(t,i)=>{if(!t)return t;const e=t._withMods||(t._withMods={}),n=i.join(".");return e[n]||(e[n]=((o,...s)=>{for(let l=0;l<i.length;l++){const r=Du[i[l]];if(r&&r(o,i))return}return t(o,...s)}))},Lu={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},Ru=(t,i)=>{const e=t._withKeys||(t._withKeys={}),n=i.join(".");return e[n]||(e[n]=(o=>{if(!("key"in o))return;const s=vi(o.key);if(i.some(l=>l===s||Lu[l]===s))return t(o)}))},Pu=ce({patchProp:Iu},uu);let Sr;function Ou(){return Sr||(Sr=Wd(Pu))}const Yl=((...t)=>{const i=Ou().createApp(...t),{mount:e}=i;return i.mount=n=>{const o=Nu(n);if(!o)return;const s=i._component;!At(s)&&!s.render&&!s.template&&(s.template=o.innerHTML),o.nodeType===1&&(o.textContent="");const l=e(o,!1,zu(o));return o instanceof Element&&(o.removeAttribute("v-cloak"),o.setAttribute("data-v-app","")),l},i});function zu(t){if(t instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&t instanceof MathMLElement)return"mathml"}function Nu(t){return te(t)?document.querySelector(t):t}function Fu(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function Se(t){const i=Fu();if(i)try{return i(t)}catch{try{const e=t.startsWith("node:")?t.slice(5):`node:${t}`;return i(e)}catch{}}}function Ms(){var i;if(typeof window<"u"&&window.process)return window.process;const t=Se("process");return t&&t.versions?t:typeof process<"u"&&((i=process.versions)!=null&&i.node)?process:globalThis.process}function Jl(){var i,e;const t=Ms();if(t&&((i=t.versions)!=null&&i.node))return!0;if(typeof window<"u"&&window.siyuan){const n=Se("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((e=process.versions)!=null&&e.node))}function Tn(){const t=Ms();if(t!=null&&t.platform)return t.platform;if(typeof process<"u"&&process.platform)return process.platform;const i=Se("os");if(i&&typeof i.platform=="function")return i.platform();if(typeof navigator<"u"){const e=navigator.userAgent.toLowerCase();if(e.includes("win"))return"win32";if(e.includes("mac"))return"darwin";if(e.includes("linux"))return"linux"}return"web"}function Xl(){var n,o;const t=Ms(),i={...(t==null?void 0:t.env)||{}};if(Tn()==="win32"){const s=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=t==null?void 0:t.env)!=null&&n.APPDATA?`${t.env.APPDATA}\\npm`:"",(o=t==null?void 0:t.env)!=null&&o.USERPROFILE?`${t.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(i).find(c=>c.toLowerCase()==="path")||"PATH",a=(i[l]||"").split(";").filter(Boolean);for(const c of s)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);i[l]=a.join(";")}return i}function ls(t){var e,n,o;if(!t)return"";if(/^[a-zA-Z]:[/\\]/.test(t))return t.replace(/\\/g,"/");let i="";if(typeof window<"u"&&((o=(n=(e=window.siyuan)==null?void 0:e.config)==null?void 0:n.system)!=null&&o.dataDir)&&(i=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),i&&t.startsWith("/data/")){const s=t.slice(6);return`${i}/${s}`.replace(/\\/g,"/")}return t}function ju(){const t=Se("os"),i=Se("path");if(t&&typeof t.tmpdir=="function"){const e=t.tmpdir();return i&&typeof i.join=="function"?i.join(e,"siyuan-slidev-pro").replace(/\\/g,"/"):`${e}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class Ds{constructor(i){wt(this,"runner");this.runner=i||Ds.defaultRunner}static async defaultRunner(i,e){var n;try{let o=(n=Se("child_process"))==null?void 0:n.execFile;if(!o){const a=await import("node:child_process").catch(()=>({}));o=a==null?void 0:a.execFile}if(!o)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=Tn()==="win32",r=Xl();return await new Promise(a=>{o(i,e,{timeout:5e3,shell:l,env:r},(c,d,u)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:u?String(u).trim():""})})})}catch(o){return{code:-1,stdout:"",stderr:String(o)}}}async detect(){const i=Jl(),e=Tn();if(!i)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,o,s=!1,l;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,o=r.stdout)}catch{}if(n){try{const r=e==="win32"?"slidev.cmd":"slidev",a=await this.runner(r,["--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}if(!s)try{const r=e==="win32"?"npx.cmd":"npx",a=await this.runner(r,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:o,hasSlidevCli:s,slidevVersion:l,platform:e,isDesktop:i}}}class Hu{constructor(){wt(this,"iframe",null);wt(this,"isReady",!1);wt(this,"pageChangedHandlers",[]);wt(this,"readyHandlers",[]);wt(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(i,e){var o;if(!((o=this.iframe)!=null&&o.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:i,...e};try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[NativeSlidevBridge] postMessage error:",s)}}navigateToPage(i){this.postMessage("navigate",{no:i})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(i){return this.pageChangedHandlers.push(i),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(e=>e!==i)}}onReady(i){return this.readyHandlers.push(i),()=>{this.readyHandlers=this.readyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){const e=i.data;if(!(!e||e.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(e.type==="update-state"&&e.navState){const n=e.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const o of this.pageChangedHandlers)o(this.currentState.no,this.currentState.total||1,this.currentState)}else if(e.type==="navigate"&&typeof e.no=="number"){this.currentState.no=e.no;for(const n of this.pageChangedHandlers)n(e.no,this.currentState.total||1,this.currentState)}}}}class Uu{constructor(i){wt(this,"childProcess",null);wt(this,"activePort",null);wt(this,"isRunning",!1);wt(this,"defaultPort");wt(this,"maxPortRetries");wt(this,"probeTimeoutMs");wt(this,"customSpawner");wt(this,"customPortChecker");this.defaultPort=(i==null?void 0:i.defaultPort)||3030,this.maxPortRetries=(i==null?void 0:i.maxPortRetries)||20,this.probeTimeoutMs=(i==null?void 0:i.probeTimeoutMs)||1e4,this.customSpawner=i==null?void 0:i.customSpawner,this.customPortChecker=i==null?void 0:i.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(i){if(this.customPortChecker)return this.customPortChecker(i);try{let e=Se("net");return e||(e=await import("node:net").catch(()=>({}))),e!=null&&e.createServer?await new Promise(n=>{const o=e.createServer();o.once("error",()=>n(!1)),o.once("listening",()=>{o.close(()=>n(!0))}),o.listen(i,"127.0.0.1")}):!0}catch{return!0}}async allocPort(i){const e=i||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const o=e+n;if(await this.isPortAvailable(o))return o}return e}async pollServerReady(i,e=8e3,n=300){const o=Date.now();for(;Date.now()-o<e;){try{const s=new AbortController,l=setTimeout(()=>s.abort(),n),r=await fetch(i,{method:"HEAD",mode:"no-cors",signal:s.signal}).catch(()=>null);if(clearTimeout(l),r)return!0}catch{}await new Promise(s=>setTimeout(s,n))}return!1}async startServer(i,e){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(e);this.activePort=n;const s=Tn()==="win32"?"npx.cmd":"npx",l=ls(i),r=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(s,r,{detached:!1});else{let u=(a=Se("child_process"))==null?void 0:a.spawn;if(!u){const k=await import("node:child_process").catch(()=>({}));u=k==null?void 0:k.spawn}if(!u)throw new Error("child_process spawn not available in current runtime");const v=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,f=Xl();this.childProcess=u(s,r,{cwd:v,detached:!1,shell:!0,env:{...f,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var i;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),Tn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(i=Se("child_process"))==null?void 0:i.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:o})=>{var s;o(`taskkill /pid ${(s=this.childProcess)==null?void 0:s.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Ls{constructor(){wt(this,"iframe",null);wt(this,"isReady",!1);wt(this,"pendingMessages",[]);wt(this,"slideChangedHandlers",[]);wt(this,"blockClickedHandlers",[]);wt(this,"openInEditorHandlers",[]);wt(this,"clientReadyHandlers",[]);wt(this,"openPeekDrawerHandlers",[]);wt(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(i,e){var o;const n={source:"siyuan-slidev-host",action:i,payload:e};if(!((o=this.iframe)!=null&&o.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[WebSandboxBridge] postMessage error:",s)}}updateSlides(i,e,n,o){this.postMessage("UPDATE_SLIDES",{slides:i,config:e,fullMarkdown:n,customThemeCss:o})}navigatePage(i){this.postMessage("NAVIGATE_PAGE",{pageIndex:i})}highlightElement(i){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:i})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(i){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:i})}onSlideChanged(i){return this.slideChangedHandlers.push(i),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(e=>e!==i)}}onBlockClicked(i){return this.blockClickedHandlers.push(i),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(e=>e!==i)}}onOpenInEditor(i){return this.openInEditorHandlers.push(i),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(e=>e!==i)}}onOpenPeekDrawer(i){return this.openPeekDrawerHandlers.push(i),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(e=>e!==i)}}onRequestToggleFullscreen(i){return this.toggleFullscreenHandlers.push(i),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(e=>e!==i)}}onClientReady(i){return this.clientReadyHandlers.push(i),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){var n;const e=i.data;if(!(!e||e.source!=="siyuan-slidev-client"))switch(e.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(e.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)o(e.payload.currentPage,e.payload.totalPages||1,e.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(e.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(e.payload.clickedBlockId,e.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(e.payload.blockId||e.payload.clickedBlockId){const o=e.payload.blockId||e.payload.clickedBlockId||"";for(const s of this.openInEditorHandlers)s(o,e.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(e.payload.peekType){const o=e.payload.blockId||e.payload.url||"",s={peekType:e.payload.peekType,target:o,title:e.payload.title};for(const l of this.openPeekDrawerHandlers)l(s)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break}}}const Ql={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},Wu=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,Vu=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,Ku=`// Auto-generated by SiYuan Slidev Studio
export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,qu=`${Zo}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function Gu(t){var o;const i=[],e=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=e.exec(t))!==null;){const s=(o=n[1])==null?void 0:o.trim();s&&!i.includes(s)&&i.push(s)}return i}class Zu{constructor(i){wt(this,"workspacePath");wt(this,"slidesFileName");wt(this,"cliBridge",new us);const e=ju();!(i!=null&&i.workspacePath)||i.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=e:this.workspacePath=i.workspacePath,this.slidesFileName=(i==null?void 0:i.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(i="default"){const e={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return i&&i!=="default"&&(e.dependencies[`@slidev/theme-${i}`]="latest"),JSON.stringify(e,null,2)}buildSlidesMarkdown(i){return this.cliBridge.buildStandardSlidevMarkdown(i)}async scaffold(i,e){const n=this.buildSlidesMarkdown(i),o=this.generatePackageJson(i.config.theme),s=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,r=ls(s),a=ls(l),c=Gu(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const x of c){const _=Ql[x]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${x}
// #endregion snippet
`;d.set(x,_)}i.slides.some(x=>{var _;return((_=x.frontmatter)==null?void 0:_.layout)==="cols-header"})&&d.set("layouts/cols-header.vue",Wu),i.slides.some(x=>{var _;return((_=x.frontmatter)==null?void 0:_.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",Vu),d.set("setup/root.ts",Ku),d.set("styles/index.css",qu);const f=Se("fs"),k=Se("path");let p=!1;const b=k!=null&&k.dirname?k.dirname(r):"",y=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-slidev-pro");if(f&&k&&y)try{f.existsSync(b)||f.mkdirSync(b,{recursive:!0}),f.writeFileSync(a,o,"utf-8"),f.writeFileSync(r,n,"utf-8");for(const[x,_]of d.entries()){const A=k.join(b,x),I=k.dirname(A);f.existsSync(I)||f.mkdirSync(I,{recursive:!0}),f.existsSync(A)||f.writeFileSync(A,_,"utf-8")}p=!0}catch{}if(!p&&e)try{const x=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),_=typeof Blob<"u"?new Blob([o],{type:"application/json;charset=utf-8"}):Buffer.from(o,"utf-8");await e(l,!1,_),await e(s,!1,x);for(const[A,I]of d.entries()){const T=`${this.workspacePath}/${A}`,w=typeof Blob<"u"?new Blob([I],{type:"text/plain;charset=utf-8"}):Buffer.from(I,"utf-8");await e(T,!1,w).catch(()=>{})}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}catch(x){return{success:!1,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l,error:String(x)}}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}}class Yu{constructor(){wt(this,"mode","web-sandbox");wt(this,"webBridge");wt(this,"cliBridge");wt(this,"nativeBridge");wt(this,"processManager");wt(this,"scaffolder");wt(this,"envDetector");this.webBridge=new Ls,this.cliBridge=new us,this.nativeBridge=new Hu,this.processManager=new Uu,this.scaffolder=new Zu,this.envDetector=new Ds}getMode(){return this.mode}setMode(i){this.mode=i}async startProMode(i,e){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const o=await this.scaffolder.scaffold(i,e);if(!o.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${o.error}`};const s=o.physicalSlidesPath||o.slidesPath,l=await this.processManager.startServer(s);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const Ju={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Xu={key:0},Qu={key:1},tf={key:2},ef={key:3},nf={key:4},of={key:5},sf={key:6},rf={key:7},lf={key:8},af={key:9},cf={key:10},df={key:11},uf={key:12},ff={key:13},pf={key:14},hf={key:15},mf={key:16},gf={key:17},vf={key:18},bf={key:19},yf={key:20},kf={key:21},wf={key:22},xf={key:23},_f={key:24},Sf={key:25},Cf={key:26},$f={key:27},If={key:28},Af={key:29},Tf={key:30},Bf={key:31},Ef={key:32},Mf={key:33},Df={key:34},Lf={key:35},Rf={key:36},Pf={key:37},Of={key:38},zf={key:39},Nf={key:40},Ff={key:41},jf={key:42},Hf={key:43},Uf={key:44},Wf={key:45},Vf={key:46},Kf={key:47},qf={key:48},Gf={key:49},Zf={key:50},Yf={key:51},Jf={key:52},Xf=xe({__name:"SlidevIcon",props:{name:{}},setup(t){return(i,e)=>(tt(),nt("svg",Ju,[t.name==="fullscreen"||t.name==="maximize"?(tt(),nt("g",Xu,[...e[0]||(e[0]=[g("polyline",{points:"15 3 21 3 21 9"},null,-1),g("polyline",{points:"9 21 3 21 3 15"},null,-1),g("polyline",{points:"21 15 21 21 15 21"},null,-1),g("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):t.name==="minimize"?(tt(),nt("g",Qu,[...e[1]||(e[1]=[g("polyline",{points:"4 14 10 14 10 20"},null,-1),g("polyline",{points:"20 10 14 10 14 4"},null,-1),g("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),g("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):t.name==="close"||t.name==="x"?(tt(),nt("g",tf,[...e[2]||(e[2]=[g("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),g("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):t.name==="edit"?(tt(),nt("g",ef,[...e[3]||(e[3]=[g("path",{d:"M12 20h9"},null,-1),g("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):t.name==="eye"?(tt(),nt("g",nf,[...e[4]||(e[4]=[g("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),g("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):t.name==="external-link"||t.name==="window"?(tt(),nt("g",of,[...e[5]||(e[5]=[g("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),g("polyline",{points:"15 3 21 3 21 9"},null,-1),g("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):t.name==="arrow-left"?(tt(),nt("g",sf,[...e[6]||(e[6]=[g("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),g("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):t.name==="arrow-right"?(tt(),nt("g",rf,[...e[7]||(e[7]=[g("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),g("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):t.name==="plus"?(tt(),nt("g",lf,[...e[8]||(e[8]=[g("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),g("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="minus"?(tt(),nt("g",af,[...e[9]||(e[9]=[g("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="split-preview"?(tt(),nt("g",cf,[...e[10]||(e[10]=[g("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),g("path",{d:"M12 3v18"},null,-1)])])):t.name==="import"?(tt(),nt("g",df,[...e[11]||(e[11]=[g("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),g("polyline",{points:"7 9 12 14 17 9"},null,-1),g("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):t.name==="presenter"?(tt(),nt("g",uf,[...e[12]||(e[12]=[g("path",{d:"M2 3h20"},null,-1),g("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),g("path",{d:"m7 21 5-5 5 5"},null,-1)])])):t.name==="video"?(tt(),nt("g",ff,[...e[13]||(e[13]=[g("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),g("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):t.name==="step"?(tt(),nt("g",pf,[...e[14]||(e[14]=[g("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):t.name==="motion"?(tt(),nt("g",hf,[...e[15]||(e[15]=[g("path",{d:"M5 12h14"},null,-1),g("path",{d:"m12 5 7 7-7 7"},null,-1),g("path",{d:"M5 6h4"},null,-1),g("path",{d:"M5 18h4"},null,-1)])])):t.name==="columns"?(tt(),nt("g",mf,[...e[16]||(e[16]=[g("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),g("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):t.name==="code"?(tt(),nt("g",gf,[...e[17]||(e[17]=[g("polyline",{points:"16 18 22 12 16 6"},null,-1),g("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):t.name==="insert-above"?(tt(),nt("g",vf,[...e[18]||(e[18]=[g("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),g("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),g("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):t.name==="insert-below"?(tt(),nt("g",bf,[...e[19]||(e[19]=[g("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),g("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),g("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="broom"?(tt(),nt("g",yf,[...e[20]||(e[20]=[g("path",{d:"m18 15-6-6"},null,-1),g("path",{d:"M4 20h16"},null,-1),g("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):t.name==="trash"?(tt(),nt("g",kf,[...e[21]||(e[21]=[g("path",{d:"M3 6h18"},null,-1),g("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),g("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):t.name==="ai"||t.name==="sparkles"?(tt(),nt("g",wf,[...e[22]||(e[22]=[g("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):t.name==="palette"?(tt(),nt("g",xf,[...e[23]||(e[23]=[Ae('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-0b78e3ba></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-0b78e3ba></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-0b78e3ba></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-0b78e3ba></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-0b78e3ba></path>',5)])])):t.name==="ratio"?(tt(),nt("g",_f,[...e[24]||(e[24]=[g("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),g("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):t.name==="transition"?(tt(),nt("g",Sf,[...e[25]||(e[25]=[g("path",{d:"M8 3 4 7l4 4"},null,-1),g("path",{d:"M4 7h16"},null,-1),g("path",{d:"m16 21 4-4-4-4"},null,-1),g("path",{d:"M20 17H4"},null,-1)])])):t.name==="export-html"?(tt(),nt("g",Cf,[...e[26]||(e[26]=[g("polyline",{points:"16 16 12 12 8 16"},null,-1),g("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),g("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):t.name==="export-pdf"?(tt(),nt("g",$f,[...e[27]||(e[27]=[g("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),g("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),g("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):t.name==="pin"?(tt(),nt("g",If,[...e[28]||(e[28]=[g("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),g("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):t.name==="refresh"?(tt(),nt("g",Af,[...e[29]||(e[29]=[g("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),g("path",{d:"M21 3v5h-5"},null,-1),g("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),g("path",{d:"M8 16H3v5"},null,-1)])])):t.name==="outline"?(tt(),nt("g",Tf,[...e[30]||(e[30]=[g("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),g("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),g("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):t.name==="chevron-left"?(tt(),nt("g",Bf,[...e[31]||(e[31]=[g("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):t.name==="chevron-right"?(tt(),nt("g",Ef,[...e[32]||(e[32]=[g("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):t.name==="copy"?(tt(),nt("g",Mf,[...e[33]||(e[33]=[g("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),g("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):t.name==="image"?(tt(),nt("g",Df,[...e[34]||(e[34]=[g("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),g("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),g("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):t.name==="search"?(tt(),nt("g",Lf,[...e[35]||(e[35]=[g("circle",{cx:"11",cy:"11",r:"7"},null,-1),g("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):t.name==="settings"||t.name==="gear"?(tt(),nt("g",Rf,[...e[36]||(e[36]=[g("circle",{cx:"12",cy:"12",r:"3"},null,-1),g("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):t.name==="notes"||t.name==="file-text"?(tt(),nt("g",Pf,[...e[37]||(e[37]=[Ae('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-0b78e3ba></path><polyline points="14 2 14 8 20 8" data-v-0b78e3ba></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-0b78e3ba></line><line x1="16" y1="17" x2="8" y2="17" data-v-0b78e3ba></line><line x1="10" y1="9" x2="8" y2="9" data-v-0b78e3ba></line>',5)])])):t.name==="focus"||t.name==="target"?(tt(),nt("g",Of,[...e[38]||(e[38]=[g("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),g("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),g("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):t.name==="layout-cover"||t.name==="cover"?(tt(),nt("g",zf,[...e[39]||(e[39]=[g("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),g("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),g("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),g("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):t.name==="layout-default"||t.name==="default"?(tt(),nt("g",Nf,[...e[40]||(e[40]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-0b78e3ba></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-0b78e3ba></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-0b78e3ba></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-0b78e3ba></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-0b78e3ba></line>',5)])])):t.name==="layout-two-cols"||t.name==="two-cols"?(tt(),nt("g",Ff,[...e[41]||(e[41]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-0b78e3ba></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-0b78e3ba></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-0b78e3ba></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-0b78e3ba></line><line x1="5" y1="15" x2="8" y2="15" data-v-0b78e3ba></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-0b78e3ba></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-0b78e3ba></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-0b78e3ba></line>',8)])])):t.name==="layout-two-cols-header"||t.name==="two-cols-header"?(tt(),nt("g",jf,[...e[42]||(e[42]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-0b78e3ba></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-0b78e3ba></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-0b78e3ba></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-0b78e3ba></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-0b78e3ba></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-0b78e3ba></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-0b78e3ba></line>',7)])])):t.name==="layout-cols-header"||t.name==="cols-header"||t.name==="layout-three-cols-header"||t.name==="three-cols-header"?(tt(),nt("g",Hf,[...e[43]||(e[43]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-0b78e3ba></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-0b78e3ba></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-0b78e3ba></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-0b78e3ba></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-0b78e3ba></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-0b78e3ba></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-0b78e3ba></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-0b78e3ba></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-0b78e3ba></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-0b78e3ba></line>',10)])])):t.name==="layout-image-right"||t.name==="image-right"?(tt(),nt("g",Uf,[...e[44]||(e[44]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-0b78e3ba></rect><line x1="12" y1="4" x2="12" y2="20" data-v-0b78e3ba></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-0b78e3ba></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-0b78e3ba></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-0b78e3ba></line><circle cx="15.5" cy="8.5" r="1.2" data-v-0b78e3ba></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-0b78e3ba></polyline>',7)])])):t.name==="layout-image-left"||t.name==="image-left"?(tt(),nt("g",Wf,[...e[45]||(e[45]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-0b78e3ba></rect><line x1="12" y1="4" x2="12" y2="20" data-v-0b78e3ba></line><circle cx="6" cy="8.5" r="1.2" data-v-0b78e3ba></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-0b78e3ba></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-0b78e3ba></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-0b78e3ba></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-0b78e3ba></line>',7)])])):t.name==="layout-center"||t.name==="center"?(tt(),nt("g",Vf,[...e[46]||(e[46]=[g("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),g("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),g("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),g("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="layout-fact"||t.name==="fact"?(tt(),nt("g",Kf,[...e[47]||(e[47]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-0b78e3ba></rect><circle cx="8" cy="9" r="1.5" data-v-0b78e3ba></circle><line x1="14" y1="8" x2="9" y2="14" data-v-0b78e3ba></line><circle cx="15" cy="13" r="1.5" data-v-0b78e3ba></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-0b78e3ba></line>',5)])])):t.name==="layout-intro"||t.name==="intro"?(tt(),nt("g",qf,[...e[48]||(e[48]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-0b78e3ba></rect><circle cx="7.5" cy="9.5" r="2" data-v-0b78e3ba></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-0b78e3ba></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-0b78e3ba></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-0b78e3ba></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-0b78e3ba></line>',6)])])):t.name==="layout-quote"||t.name==="quote"?(tt(),nt("g",Gf,[...e[49]||(e[49]=[Ae('<rect x="2" y="4" width="20" height="16" rx="2" data-v-0b78e3ba></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-0b78e3ba></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-0b78e3ba></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-0b78e3ba></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-0b78e3ba></line>',5)])])):t.name==="desktop"||t.name==="monitor"?(tt(),nt("g",Zf,[...e[50]||(e[50]=[g("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),g("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),g("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):t.name==="mobile"||t.name==="smartphone"||t.name==="phone"?(tt(),nt("g",Yf,[...e[51]||(e[51]=[g("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),g("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):(tt(),nt("g",Jf,[...e[52]||(e[52]=[g("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),g("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),g("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Oe=(t,i)=>{const e=t.__vccOpts||t;for(const[n,o]of i)e[n]=o;return e},gt=Oe(Xf,[["__scopeId","data-v-0b78e3ba"]]);function ie(t,i){var o;if(typeof document>"u"||!t)return;const e=(o=globalThis.CSS)!=null&&o.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${e}"]`);!n||n.length===0||n.forEach(s=>{for(const[l,r]of Object.entries(i))r!=null&&r!==""?s.setAttribute(l,String(r)):s.removeAttribute(l)})}function Qf(t){if(typeof document>"u")return;const i=`.protyle-wysiwyg [${dt}], .protyle-wysiwyg [${Vt}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,e=document.querySelectorAll(i);!e||e.length===0||e.forEach(n=>{const o=n.getAttribute("data-node-id");if(!o){n.removeAttribute(dt),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(Vt),n.removeAttribute("custom-slidev-role");return}const s=t.get(o),l=(s==null?void 0:s[dt])||(s==null?void 0:s["custom-slidev-layout"])||"",r=n.getAttribute(dt)||n.getAttribute("custom-slidev-layout");r&&r!==l&&(l?n.setAttribute(dt,l):(n.removeAttribute(dt),n.removeAttribute("custom-slidev-layout")));const a=(s==null?void 0:s[Vt])||(s==null?void 0:s["custom-slidev-role"])||"",c=n.getAttribute(Vt)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(Vt,a):(n.removeAttribute(Vt),n.removeAttribute("custom-slidev-role")))})}const tp={class:"spm-layout-picker"},ep={class:"spm-layout-picker__grid"},ip=["title","onClick"],np={class:"spm-layout-icon"},op={class:"spm-layout-label"},sp=xe({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=t,n=i,o=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function s(r){return e.modelValue===r||r==="cols-header"&&(e.modelValue==="two-cols-header"||e.modelValue==="three-cols-header")}function l(r){n("update:modelValue",r),n("change",r)}return(r,a)=>(tt(),nt("div",tp,[a[0]||(a[0]=g("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),g("div",ep,[(tt(),nt(Kt,null,ye(o,c=>g("div",{key:c.name,class:It(["spm-layout-item",{active:s(c.name)}]),title:c.desc,onClick:d=>l(c.name)},[g("div",np,[ct(gt,{name:"layout-"+c.name},null,8,["name"])]),g("span",op,xt(c.label),1)],10,ip)),64))])]))}}),ta=Oe(sp,[["__scopeId","data-v-d041f1ed"]]),rp={key:0,class:"spm-transition-selector__header"},lp={class:"spm-transition-list"},ap=["onClick"],cp={class:"spm-transition-meta"},dp={class:"spm-transition-label"},up={class:"spm-transition-name"},fp={class:"spm-transition-preview-box"},pp=xe({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function o(s){e("update:modelValue",s),e("change",s)}return(s,l)=>(tt(),nt("div",{class:It(["spm-transition-selector",{"spm-transition-selector--no-header":t.hideHeader}])},[t.hideHeader?Lt("",!0):(tt(),nt("div",rp,xt(t.title||"转场动效"),1)),g("div",lp,[(tt(),nt(Kt,null,ye(n,r=>g("div",{key:r.name,class:It(["spm-transition-item",{active:t.modelValue===r.name}]),onClick:a=>o(r.name)},[g("div",cp,[g("span",dp,xt(r.label),1),g("span",up,"("+xt(r.name)+")",1)]),g("div",fp,[g("div",{class:It(["spm-anim-cube","anim-"+r.name])},null,2)])],10,ap)),64))])],2))}}),Rs=Oe(pp,[["__scopeId","data-v-b0aa61ff"]]),hp={class:"spm-divider-popover"},mp={class:"spm-divider-popover__title"},gp={class:"spm-form-item"},vp={class:"spm-popover-footer"},bp={class:"spm-save-hint"},yp=xe({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(t,{emit:i}){var v,f,k;const e=t,n=i,o=ft(((v=e.initialAttrs)==null?void 0:v[dt])||"default"),s=ft(((f=e.initialAttrs)==null?void 0:f[Qt])||"slide-left"),l=ft(((k=e.initialAttrs)==null?void 0:k[Ht])||""),r=ft("");Ei(()=>e.initialAttrs,p=>{o.value=(p==null?void 0:p[dt])||"default",s.value=(p==null?void 0:p[Qt])||"slide-left",l.value=(p==null?void 0:p[Ht])||""},{deep:!0});async function a(p,b){if(e.blockId){r.value="正在同步...",Pt.setBlockAttrOverride(e.blockId,{[p]:b}),ie(e.blockId,{[p]:b});try{await Rt(e.blockId,{[p]:b}),r.value="已同步至块属性",n("updated",{[p]:b}),setTimeout(()=>{r.value=""},1500)}catch{r.value="同步失败"}}}function c(p){a(dt,p)}function d(p){a(Qt,p)}function u(){a(Ht,l.value.trim())}return(p,b)=>(tt(),nt("div",hp,[g("div",mp,[b[4]||(b[4]=g("span",null,"幻灯片页面设置",-1)),g("button",{class:"spm-close-btn",onClick:b[0]||(b[0]=y=>n("close"))},"✕")]),ct(ta,{modelValue:o.value,"onUpdate:modelValue":b[1]||(b[1]=y=>o.value=y),onChange:c},null,8,["modelValue"]),ct(Rs,{modelValue:s.value,"onUpdate:modelValue":b[2]||(b[2]=y=>s.value=y),onChange:d},null,8,["modelValue"]),g("div",gp,[b[5]||(b[5]=g("label",{class:"spm-form-label"},"页面背景",-1)),Te(g("input",{"onUpdate:modelValue":b[3]||(b[3]=y=>l.value=y),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:u},null,544),[[ho,l.value]])]),g("div",vp,[g("span",bp,xt(r.value),1)])]))}}),kp=Oe(yp,[["__scopeId","data-v-e4871368"]]),wp={class:"spm-slide-inspector"},xp={class:"spm-inspector-header"},_p={class:"spm-inspector-list"},Sp=["onClick"],Cp={class:"spm-card-top"},$p={class:"spm-card-badge"},Ip={class:"spm-card-layout"},Ap=["onClick"],Tp={class:"spm-card-preview"},Bp={key:0,class:"spm-card-notes",title:"演讲备忘录"},Ep={class:"spm-inspector-modal-content"},Mp=xe({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(t,{emit:i}){const e=i,n=ft(null);function o(c){n.value=c}function s(c){const d={};return c.frontmatter.layout&&(d[dt]=c.frontmatter.layout),c.frontmatter.transition&&(d[Qt]=c.frontmatter.transition),c.frontmatter.background&&(d[Ht]=c.frontmatter.background),c.notes&&(d[Fi]=c.notes),d}function l(c){n.value&&(c[dt]&&(n.value.frontmatter.layout=c[dt]),c[Qt]&&(n.value.frontmatter.transition=c[Qt]),c[Ht]&&(n.value.frontmatter.background=c[Ht]),c[Fi]&&(n.value.notes=c[Fi]),e("refresh"))}function r(c){e("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const d=c.blocks[0],u=d.content||d.rawMarkdown||"";return u.slice(0,40)+(u.length>40?"...":"")}return(c,d)=>(tt(),nt("div",wp,[g("div",xp,[g("span",null,"幻灯片大纲 ("+xt(t.slides.length)+" 页)",1)]),g("div",_p,[(tt(!0),nt(Kt,null,ye(t.slides,u=>(tt(),nt("div",{key:u.pageIndex,class:It(["spm-card",{active:t.currentActivePage===u.pageIndex}]),onClick:v=>r(u.pageIndex)},[g("div",Cp,[g("span",$p,"P"+xt(u.pageIndex),1),g("span",Ip,xt(u.frontmatter.layout||"default"),1),g("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Ee(v=>o(u),["stop"])},[ct(gt,{name:"settings"})],8,Ap)]),g("div",Tp,xt(a(u)),1),u.notes?(tt(),nt("div",Bp,[ct(gt,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),g("span",null,xt(u.notes),1)])):Lt("",!0)],10,Sp))),128))]),n.value?(tt(),nt("div",{key:0,class:"spm-inspector-modal-mask",onClick:d[1]||(d[1]=Ee(u=>n.value=null,["self"]))},[g("div",Ep,[ct(kp,{"block-id":n.value.startBlockId,"initial-attrs":s(n.value),onClose:d[0]||(d[0]=u=>n.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Lt("",!0)]))}}),Dp=Oe(Mp,[["__scopeId","data-v-68b25edd"]]),Lp={class:"spm-immersion-header"},Rp={class:"spm-immersion-header__left"},Pp={class:"spm-immersion-title"},Op={class:"spm-immersion-header__center"},zp={class:"spm-immersion-header__actions"},Np=["aria-label"],Fp={class:"spm-immersion-body"},jp=xe({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(t,{emit:i}){const e=t,n=i;function o(){n("update:visible",!1),n("close")}function s(){e.closeOnClickMask&&o()}function l(){n("update:isMaximized",!e.isMaximized),n("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),o())}return(a,c)=>Te((tt(),nt("div",{class:It(["spm-immersion-container",{"is-maximized":t.isMaximized}]),onKeydown:Ee(r,["stop"])},[g("div",{class:"spm-immersion-mask",onClick:s}),g("div",{class:It(["spm-immersion-drawer",{"is-maximized":t.isMaximized}])},[g("div",Lp,[g("div",Rp,[Hn(a.$slots,"header-left",{},()=>[g("span",Pp,xt(t.title),1)])]),g("div",Op,[Hn(a.$slots,"header-center",{},void 0)]),g("div",zp,[Hn(a.$slots,"header-actions",{},void 0),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":t.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[ct(gt,{name:t.isMaximized?"minimize":"maximize"},null,8,["name"])],8,Np),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:o},[ct(gt,{name:"close"})])])]),g("div",Fp,[Hn(a.$slots,"default",{},void 0)])],2)],34)),[[Gl,t.visible]])}}),Hp=Oe(jp,[["__scopeId","data-v-3f1665db"]]),Up="slidev-config.json",Ji={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806"},Ai=xo({...Ji});function Wp(t){if(!t||typeof t!="object")return{...Ji};const i=t;return{enableWebServeJump:!!i.enableWebServeJump,webServeUrl:typeof i.webServeUrl=="string"&&i.webServeUrl.trim()?i.webServeUrl.trim():Ji.webServeUrl}}function qi(t){if(!t||typeof t!="object")return{...Ai};const i=t;return i.enableWebServeJump!==void 0&&(Ai.enableWebServeJump=!!i.enableWebServeJump),i.webServeUrl!==void 0&&(Ai.webServeUrl=String(i.webServeUrl)),{...Ai}}function Ps(){return{...Ai}}function ea(t,i,e){const n=(t||Ji.webServeUrl).trim(),o=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,s=(e==null?void 0:e.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(o);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",i),e!=null&&e.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",s),l.toString()}catch{const l=e!=null&&e.focus?"&focus=1":"";return`${o.replace(/\/+$/,"")}/stage/build/desktop/?id=${i}${l}&r=${s}`}}const Vp={class:"spm-protyle-drawer"},Kp={class:"spm-protyle-drawer__subbar"},qp={class:"spm-protyle-drawer__nav"},Gp=["title"],Zp={class:"spm-protyle-drawer__actions"},Yp=["aria-label"],Jp=["aria-label"],Xp=xe({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(t,{emit:i}){const e=i,n=t,o=ft(n.blockId),s=ft(n.title||""),l=ft(!1),r=ft(!0),a=ft(!1),c=ft(""),d=Ai,u=ft([]),v=ft(null);let f=null;Ei(()=>n.blockId,w=>{w&&w!==o.value&&(o.value=w,s.value=n.title||"",u.value=[],p(w))}),Dn(()=>{o.value&&p(o.value)}),$s(()=>{b()});async function k(w){try{const L=await vn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${w}' LIMIT 1`);if(Array.isArray(L)&&L.length>0){const B=L[0];c.value=B.root_id||"";const N=B.id===B.root_id||B.type==="d";a.value=N,r.value=!N,!s.value&&B.content&&(s.value=B.content.trim().slice(0,30));return}}catch(L){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",L)}a.value=!1,r.value=!0}async function p(w,L){if(!v.value||!w)return;b(),await k(w),typeof L=="boolean"&&(r.value=!a.value&&L);let B,N;r.value&&!a.value?(B=["cb-get-all","cb-get-hl","cb-get-focus"],N={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(B=["cb-get-context","cb-get-hl"],N={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{f=new mt.Protyle(n.plugin.app,v.value,{blockId:w,action:B,render:N}),!l.value&&f&&typeof f.disable=="function"&&f.disable()}catch(Z){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",Z)}}function b(){if(f){try{typeof f.destroy=="function"&&f.destroy()}catch(w){console.warn("[ProtylePeekDrawer] Error destroying protyle:",w)}f=null}v.value&&(v.value.innerHTML="")}function y(){a.value||(r.value=!r.value,p(o.value,r.value))}function x(){l.value=!l.value,f&&(l.value?(typeof f.enable=="function"&&f.enable(),typeof f.focus=="function"&&f.focus()):typeof f.disable=="function"&&f.disable())}function _(){if(o.value)try{mt.openWindow({doc:{id:o.value},alwaysOnTop:!0})}catch(w){console.warn("[ProtylePeekDrawer] openWindow failed:",w)}}function A(){var B;if(!o.value)return;const w=Ps(),L=ea(w.webServeUrl,o.value,{focus:!a.value});if(typeof window<"u"){const N=Se("electron");(B=N==null?void 0:N.shell)!=null&&B.openExternal?N.shell.openExternal(L).catch(()=>{window.open(L,"_blank")}):window.open(L,"_blank")}e("external-jump",L)}function I(){if(u.value.length>0){const w=u.value.pop();w&&(o.value=w.blockId,s.value=w.title,r.value=w.isFocusMode,a.value=w.isDoc,p(w.blockId,w.isFocusMode))}}function T(w){const L=w.target;if(!L)return;const B=L.closest('[data-type="block-ref"]');if(B){const Z=B.getAttribute("data-id");if(Z&&Z!==o.value){w.preventDefault(),w.stopPropagation(),u.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=Z,s.value=B.innerText.trim()||Z,p(Z);return}}const N=L.closest("a");if(N&&N.href&&N.href.startsWith("siyuan://blocks/")){w.preventDefault(),w.stopPropagation();const Z=N.href.replace("siyuan://blocks/","").split("?")[0];Z&&Z!==o.value&&(u.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=Z,s.value=N.innerText.trim()||Z,p(Z))}}return(w,L)=>(tt(),nt("div",Vp,[g("div",Kp,[g("div",qp,[u.value.length>0?(tt(),nt("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:I},[ct(gt,{name:"arrow-left"}),L[0]||(L[0]=g("span",null,"返回",-1))])):Lt("",!0),g("span",{class:It(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},xt(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),g("span",{class:"spm-protyle-id",title:s.value||o.value},xt(s.value||o.value),9,Gp)]),g("div",Zp,[a.value?Lt("",!0):(tt(),nt("button",{key:0,class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:y},[ct(gt,{name:r.value?"focus":"file-text"},null,8,["name"]),g("span",null,xt(r.value?"块聚焦":"展开全文"),1)],10,Yp)),g("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:x},[ct(gt,{name:l.value?"edit":"eye"},null,8,["name"]),g("span",null,xt(l.value?"编辑中":"只读"),1)],10,Jp),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:_},[ct(gt,{name:"window"}),L[1]||(L[1]=g("span",null,"独立窗口",-1))]),ht(d).enableWebServeJump?(tt(),nt("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:A},[ct(gt,{name:"external-link"}),L[2]||(L[2]=g("span",null,"外跳",-1))])):Lt("",!0)])]),g("div",{ref_key:"mountEl",ref:v,class:It(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:T},null,2)]))}}),Qp=Oe(Xp,[["__scopeId","data-v-7e586ef3"]]),th={class:"spm-webview-drawer"},eh={class:"spm-webview-toolbar"},ih={class:"spm-webview-toolbar__nav"},nh=["disabled"],oh=["disabled"],sh=["aria-label"],rh={class:"spm-webview-toolbar__address"},lh=["aria-label"],ah={class:"spm-webview-toolbar__actions"},ch=["aria-label"],dh={class:"spm-zoom-controller"},uh=["disabled"],fh=["disabled"],ph={key:1,class:"spm-webview-fallback"},hh=["src"],Cr="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",ia="siyuan-slidev-peek-view-mode";let na="desktop";function mh(){if(typeof window<"u"&&window.localStorage)try{const t=window.localStorage.getItem(ia);if(t==="mobile"||t==="desktop")return t}catch{}return na}function gh(t){if(na=t,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(ia,t)}catch{}}const vh=xe({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(t,{emit:i}){const e=i,n=t,o=ft(Jl()),s=ft(n.url),l=ft(n.url),r=ft(!1),a=ft(!1),c=ft(!1),d=ft(1),u=ft(!1),v=ft(mh());let f=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const k=_t(()=>v.value==="mobile"?Cr:f||void 0),p=ft(null),b=ft(null);let y=null,x=null,_=null;Ei(()=>n.url,Q=>{Q&&Q!==s.value&&(s.value=Q,l.value=Q,v.value==="mobile"&&L(!1),p.value&&typeof p.value.loadURL=="function"&&p.value.loadURL(Q))}),Ei(()=>n.visible,Q=>{if(Q)O(),v.value==="mobile"&&L(!1);else if(p.value)try{typeof p.value.stop=="function"&&p.value.stop()}catch{}}),Dn(()=>{A(),b.value&&typeof ResizeObserver<"u"&&(y=new ResizeObserver(()=>{const Q=p.value;if(Q&&typeof Q.invalidate=="function")try{Q.invalidate()}catch{}}),y.observe(b.value)),x=Q=>{var bt;const pt=Q.message||((bt=Q.error)==null?void 0:bt.message);if(typeof pt=="string"&&pt.includes("Invalid guestInstanceId"))return Q.preventDefault(),Q.stopImmediatePropagation(),!0},window.addEventListener("error",x,!0),_=Q=>{const pt=Q.reason,bt=typeof pt=="string"?pt:pt==null?void 0:pt.message;typeof bt=="string"&&bt.includes("Invalid guestInstanceId")&&Q.preventDefault()},window.addEventListener("unhandledrejection",_)}),$s(()=>{if(I(),y&&(y.disconnect(),y=null),x&&(window.removeEventListener("error",x,!0),x=null),_&&(window.removeEventListener("unhandledrejection",_),_=null),p.value)try{typeof p.value.stop=="function"&&p.value.stop()}catch{}});function A(){const Q=p.value;Q&&(Q.addEventListener("dom-ready",T),Q.addEventListener("did-start-loading",B),Q.addEventListener("did-stop-loading",N),Q.addEventListener("did-navigate",Z),Q.addEventListener("did-navigate-in-page",$),Q.addEventListener("new-window",U))}function I(){const Q=p.value;if(Q)try{Q.removeEventListener("dom-ready",T),Q.removeEventListener("did-start-loading",B),Q.removeEventListener("did-stop-loading",N),Q.removeEventListener("did-navigate",Z),Q.removeEventListener("did-navigate-in-page",$),Q.removeEventListener("new-window",U)}catch{}}function T(){const Q=p.value;if(Q&&typeof Q.getUserAgent=="function"&&!f)try{const pt=Q.getUserAgent();pt&&!pt.includes("iPhone")&&(f=pt)}catch{}v.value==="mobile"&&L(!1),O(),m()}function w(){const Q=v.value==="mobile"?"desktop":"mobile";v.value=Q,gh(Q),L(!0)}function L(Q=!1){const pt=p.value;if(!pt)return;const bt=v.value==="mobile"?Cr:f;if(typeof pt.setUserAgent=="function"&&bt)try{pt.setUserAgent(bt)}catch(X){console.warn("[WebviewPeekDrawer] setUserAgent error:",X)}if(Q&&typeof pt.reload=="function")try{pt.reload()}catch(X){console.warn("[WebviewPeekDrawer] reload error:",X)}}function B(){r.value=!0}function N(){if(r.value=!1,m(),p.value&&typeof p.value.getURL=="function"){const Q=p.value.getURL();Q&&Q!=="about:blank"&&(s.value=Q,l.value=Q)}}function Z(Q){Q!=null&&Q.url&&(s.value=Q.url,l.value=Q.url),m()}function $(Q){Q!=null&&Q.url&&(s.value=Q.url,l.value=Q.url),m()}function U(Q){Q&&Q.url&&(Q.preventDefault(),p.value&&typeof p.value.loadURL=="function"&&p.value.loadURL(Q.url))}function m(){const Q=p.value;Q&&(typeof Q.canGoBack=="function"&&(a.value=Q.canGoBack()),typeof Q.canGoForward=="function"&&(c.value=Q.canGoForward()))}function K(){p.value&&typeof p.value.goBack=="function"&&p.value.goBack()}function E(){p.value&&typeof p.value.goForward=="function"&&p.value.goForward()}function M(){p.value&&typeof p.value.reload=="function"&&p.value.reload()}function F(){let Q=l.value.trim();Q&&(/^https?:\/\//i.test(Q)||(Q=`https://${Q}`),s.value=Q,l.value=Q,p.value&&typeof p.value.loadURL=="function"&&p.value.loadURL(Q))}function O(){const Q=p.value;if(Q&&typeof Q.setZoomFactor=="function")try{Q.setZoomFactor(d.value)}catch(pt){console.warn("[WebviewPeekDrawer] setZoomFactor error:",pt)}}function J(){d.value=Math.min(2.5,Math.round((d.value+.1)*10)/10),O()}function j(){d.value=Math.max(.5,Math.round((d.value-.1)*10)/10),O()}function q(){d.value=1,O()}function rt(Q){Q.preventDefault(),Q.deltaY<0?J():Q.deltaY>0&&j()}async function lt(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(s.value),u.value=!0,setTimeout(()=>{u.value=!1},2e3)}catch(Q){console.warn("Copy url failed:",Q)}}function st(){var pt;const Q=s.value;if(typeof window<"u"){const bt=Se("electron");(pt=bt==null?void 0:bt.shell)!=null&&pt.openExternal?bt.shell.openExternal(Q).catch(()=>{window.open(Q,"_blank")}):window.open(Q,"_blank")}e("external-jump",Q)}return(Q,pt)=>{const bt=kd("webview");return tt(),nt("div",th,[g("div",eh,[g("div",ih,[g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!a.value,"aria-label":"后退",onClick:K},[ct(gt,{name:"arrow-left"})],8,nh),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"前进",onClick:E},[ct(gt,{name:"arrow-right"})],8,oh),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":r.value?"正在加载...":"刷新页面",onClick:M},[ct(gt,{name:"refresh"})],8,sh)]),g("div",rh,[Te(g("input",{"onUpdate:modelValue":pt[0]||(pt[0]=X=>l.value=X),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:Ru(F,["enter"])},null,544),[[ho,l.value]]),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":u.value?"已复制地址！":"复制网址",onClick:lt},[ct(gt,{name:"copy"})],8,lh)]),g("div",ah,[g("button",{class:It(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":v.value==="mobile"}]),"aria-label":v.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:w},[ct(gt,{name:v.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,ch),g("div",dh,[g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:d.value<=.5,onClick:j},[ct(gt,{name:"minus"})],8,uh),g("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:q},xt(Math.round(d.value*100))+"% ",1),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:d.value>=2.5,onClick:J},[ct(gt,{name:"plus"})],8,fh)]),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:st},[ct(gt,{name:"external-link"}),pt[1]||(pt[1]=g("span",null,"外跳",-1))])])]),g("div",{ref_key:"containerEl",ref:b,class:It(["spm-webview-body",{"is-mobile":v.value==="mobile"}]),onWheel:Ee(rt,["ctrl"])},[g("div",{class:It(["spm-webview-viewport",{"is-mobile":v.value==="mobile"}])},[o.value?(tt(),Me(bt,{key:0,ref_key:"webviewRef",ref:p,class:"spm-webview-frame",src:s.value,useragent:k.value,allowpopups:"true",partition:"persist:slidev-peek",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(tt(),nt("div",ph,[g("iframe",{class:"spm-webview-fallback-frame",src:s.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,hh),g("div",{class:"spm-fallback-bar"},[pt[2]||(pt[2]=g("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),g("button",{class:"spm-icon-btn is-primary",onClick:st}," 在新标签页中打开 ↗ ")])]))],2)],34)])}}}),bh=Oe(vh,[["__scopeId","data-v-40e35375"]]);class yh{constructor(){wt(this,"timers",new Map)}debounce(i,e,n=150){this.cancel(i);const o=setTimeout(()=>{this.timers.delete(i),e()},n);this.timers.set(i,o)}cancel(i){this.timers.has(i)&&(clearTimeout(this.timers.get(i)),this.timers.delete(i))}cancelAll(){for(const i of this.timers.values())clearTimeout(i);this.timers.clear()}hasPending(i){return this.timers.has(i)}}class kh{constructor(i){wt(this,"blockToPageMap",new Map);wt(this,"debounceCtrl",new yh);wt(this,"activeBlockId","");wt(this,"activePageIndex",1);wt(this,"currentDocId","");wt(this,"bridge",null);i&&(this.bridge=i)}setBridge(i){this.bridge=i}setDocId(i){this.currentDocId=i}updateSlidesIndex(i){this.blockToPageMap.clear();for(const e of i){e.startBlockId&&this.blockToPageMap.set(e.startBlockId,e.pageIndex);for(const n of e.blocks)this.blockToPageMap.set(n.id,e.pageIndex)}}getPageByBlockId(i){return this.blockToPageMap.get(i)??null}onCursorFocusBlock(i){if(!i||i===this.activeBlockId)return;this.activeBlockId=i;let e=this.getPageByBlockId(i);!e&&(i===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(e=1),e&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=e,this.bridge&&(this.bridge.navigatePage(e),this.bridge.highlightElement(i))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(i){this.activeBlockId=i;const e=this.getPageByBlockId(i);e&&(this.activePageIndex=e)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Mi(t,i){var s,l;if(!t||typeof document>"u")return!1;const e=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`);if(!n){if(i)try{return mt.openTab({app:i,doc:{id:t,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(r){console.warn("[SelectionMirror] openTab fallback failed:",r)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const o=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=o},1200),!0}function wh(t){if(!t)return"";const i=t.split(`
`).map(l=>l.trim()).filter(Boolean);if(i.length===0)return"";if(!i.some(l=>/^#{1,6}\s+/.test(l)))return ke(i.join(" "));const n=[];let o=[];const s=()=>{if(o.length>0){const l=o.join(" ");n.push(`<p class="slide-list-item-desc">${ke(l)}</p>`),o=[]}};for(const l of i){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){s();const a=r[1].length,c=r[2].trim();n.push(`<h${a} class="slide-list-item-title">${ke(c)}</h${a}>`)}else o.push(l)}return s(),n.join(`
`)}function xh(t){if(t.length===0)return"";const i=[];let e=[];const n=s=>{if(e.length>0){const l=e.join(" "),r=s?"slide-list-item-title":"slide-list-item-desc";i.push(`<p class="${r}">${ke(l)}</p>`),e=[]}};let o=!0;for(const s of t){const l=s.match(/^(#{1,6})\s+(.*)$/);if(l){n(o);const r=l[1].length,a=l[2].trim();i.push(`<h${r} class="slide-list-item-title">${ke(a)}</h${r}>`),o=!1}else e.push(s)}return n(o),i.join(`
`)+(i.length>0?`
`:"")}function oa(t,i,e){var v,f,k,p;const n=t.split(`
`);if(!n.some(b=>/^(\s*)([-*+]|\d+\.)\s+/.test(b)))return null;const s=[],l=[];let r=!1;for(let b=0;b<n.length;b++){const y=n[b];if(!y.trim())continue;const x=y.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(x){const T=x[1].length,w=Math.floor(T/2);l.push({type:"task",level:w,checked:x[2].toLowerCase()==="x",text:x[3],media:[]});continue}const _=y.match(/^(\s*)[-*+]\s+(.*)$/);if(_){const T=_[1].length,w=Math.floor(T/2);l.push({type:"unordered",level:w,text:_[2],media:[]});continue}const A=y.match(/^(\s*)\d+\.\s+(.*)$/);if(A){l.length===0&&(r=!0);const T=A[1].length,w=Math.floor(T/2);l.push({type:"ordered",level:w,text:A[2],media:[]});continue}const I=y.trim();if(!(!I||/^\{:.*?\}$/.test(I)))if(l.length>0){const T=I.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(T){const B=/\.gif(?:\?|$)/i.test(T[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${le(T[1])}" src="${T[2]}" class="${B}" /></div>`);continue}if(I.match(/^<img\b[\s\S]*?\/?>$/i)){const L=I.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${L}</div>`);continue}if(/<video\b/i.test(I)){let L=I;if(!/<\/video>/i.test(L))for(;b+1<n.length&&!/<\/video>/i.test(L);)b++,L+=" "+n[b].trim();const B=((v=e==null?void 0:e.attributes)==null?void 0:v["custom-slidev-autoplay"])==="true"||/autoplay/i.test(L),N=((f=e==null?void 0:e.attributes)==null?void 0:f["custom-slidev-loop"])==="true"||/loop/i.test(L),Z=((k=e==null?void 0:e.attributes)==null?void 0:k["custom-slidev-muted"])==="true"||B||/muted/i.test(L),$=((p=e==null?void 0:e.attributes)==null?void 0:p["custom-slidev-controls"])==="false",U=L.match(/\bsrc=["']([^"']+)["']/i),m=U?U[1]:"",K=['class="slide-video-player"'];$||K.push("controls"),B&&(K.push("autoplay"),K.push("playsinline")),N&&K.push("loop"),Z&&K.push("muted"),K.push('preload="metadata"'),m&&K.push(`src="${m}"`);const E=L.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let M=E?E[1].trim():"";!M&&m&&(M=`<source src="${m}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${B?"true":"false"}" data-muted="${Z?"true":"false"}"><video ${K.join(" ")}>${M}</video></div>`);continue}l[l.length-1].text+=`
`+I}else s.push(I)}if(l.length===0)return null;const a=r?"ol":"ul",c=r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered",d=l.map(b=>{const y=wh(b.text),x=b.media&&b.media.length>0?`
${b.media.join(`
`)}`:"",_=b.level||0,A=_>0?` style="margin-left:${(_*1.25).toFixed(2)}em;${b.type==="unordered"?`list-style-type:${_%2===1?"circle":"square"} !important;`:""}"`:"",I=_>0?" slide-list-item--nested":"";if(b.type==="task"){const w=b.checked?' checked=""':"";return`<li class="pdf-task-item${I}"${A}><label><input type="checkbox" disabled=""${w}/> <span>${y}</span></label>${x}</li>`}return`<li${I?` class="${I.trim()}"`:""}${A}>${y}${x}</li>`}).join(`
`);return`${xh(s)}<${a} class="${c}">
${d}
</${a}>`}function _h(t,i,e){const n="pdf-block",o=t.split(/\r?\n/),s=[];let l=[];for(let a=0;a<o.length;a++){const c=o[a],d=c.trim();if(/^#{1,6}\s+/.test(d)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(d);continue}if(!d){l.length>0&&(s.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(d)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(d);continue}if(/<video\b/i.test(d)){l.length>0&&(s.push(l.join(`
`)),l=[]);let u=d;if(!/<\/video>/i.test(u))for(;a+1<o.length&&!/<\/video>/i.test(u);)a++,u+=`
`+o[a];s.push(u);continue}l.push(c)}return l.length>0&&s.push(l.join(`
`)),s.map(a=>{var f,k,p,b;const c=a.trim();if(!c)return"";const d=c.match(/^(#{1,6})\s+(.*)$/);if(d){const y=d[1].length;return`<h${y} class="slide-list-item-title">${ke(d[2].trim())}</h${y}>`}const u=c.match(/^!\[(.*?)\]\((.*?)\)$/);if(u){const x=/\.gif(?:\?|$)/i.test(u[2])?"list-item-gif":"pdf-image slide-media-img";return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${le(u[1])}" src="${u[2]}" class="${x}" /></div>`}if(/<video\b/i.test(c)){const y=((f=e==null?void 0:e.attributes)==null?void 0:f["custom-slidev-autoplay"])==="true"||/autoplay/i.test(c),x=((k=e==null?void 0:e.attributes)==null?void 0:k["custom-slidev-loop"])==="true"||/loop/i.test(c),_=((p=e==null?void 0:e.attributes)==null?void 0:p["custom-slidev-muted"])==="true"||y||/muted/i.test(c),A=((b=e==null?void 0:e.attributes)==null?void 0:b["custom-slidev-controls"])==="false",I=c.match(/\bsrc=["']([^"']+)["']/i),T=I?I[1]:"",w=['class="slide-video-player"'];A||w.push("controls"),y&&w.push("autoplay playsinline"),x&&w.push("loop"),_&&w.push("muted"),w.push('preload="metadata"'),T&&w.push(`src="${T}"`);const L=c.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let B=L?L[1].trim():"";return!B&&T&&(B=`<source src="${T}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${y?"true":"false"}" data-muted="${_?"true":"false"}"><video ${w.join(" ")}>${B}</video></div>`}const v=oa(c,i,e);return v||`<p class="slide-list-item-desc">${ke(c)}</p>`}).filter(Boolean).join(`
`)}function Sh(t,i){var s,l,r,a,c,d,u,v;const e=((s=t.frontmatter)==null?void 0:s.layout)||"default",o=(t.blocks||[]).filter(f=>f.slot!=="slot-divider-right");if(e==="two-cols"){const f=o.some(L=>L.slot==="right");let k=[],p=[];if(f)k=o.filter(L=>L.slot!=="right"),p=o.filter(L=>L.slot==="right");else{const L=Math.ceil(o.length/2);k=o.slice(0,L),p=o.slice(L)}const b=k.map(L=>di(L,i)).join(`
`),y=p.map(L=>di(L,i)).join(`
`),x="pdf-two-cols-wrapper layout-two-cols-grid",_=(l=t.frontmatter)!=null&&l.layoutClass?` ${t.frontmatter.layoutClass}`:"",A="pdf-col pdf-col--left",I="pdf-col pdf-col--right",w=`style="grid-template-columns: ${Eo((r=t.frontmatter)==null?void 0:r.layoutRatio,2)};"`;return`
      <div class="${x}${_}" ${w}>
        <div class="${A}">${b}</div>
        <div class="${I}">${y}</div>
      </div>
    `}if(cs(e)){let f=[];const k=o.filter(B=>B.slot==="header");if(k.length>0)f=k;else if(o.length>0){const B=o.find(N=>N.type==="h"&&(!N.slot||N.slot==="default"));B&&(f=[B])}const p=o.filter(B=>!f.includes(B));let b=2;if(e==="three-cols-header")b=3;else if(e==="two-cols-header")b=2;else{let B=0;for(const N of p){const Z=(N.slot||"").match(/^col-(\d+)$/i);Z&&(B=Math.max(B,parseInt(Z[1],10)))}if(B>=2)b=B;else if((a=t.frontmatter)!=null&&a.layoutRatio){const N=t.frontmatter.layoutRatio.trim();if(N.includes(":")){const Z=N.split(":").map($=>parseFloat($.trim())).filter($=>!isNaN($)&&$>0);Z.length>=2&&(b=Z.length)}else{const Z=N.split(/\s+/).filter(Boolean);Z.length>=2&&(b=Z.length)}}else p.length===1&&p[0].children&&p[0].children.length>=2&&(b=Math.min(6,p[0].children.length))}const y=Hr(p,b),x=B=>{const N=B.filter(Z=>!!(Z.rawMarkdown||Z.content||"").trim());if(N.length>0){const Z=N[0],$=(Z.rawMarkdown||Z.content||"").trim();(xn(Z)||/^(?:[-*+]|\d+\.)\s+/.test($))&&(Z.rawMarkdown=zr(Z.rawMarkdown||Z.content||""),Z.content=Z.rawMarkdown)}return N.map(Z=>di(Z,i)).join(`
`)},_=f.map(B=>di(B,i)).join(`
`),I=`style="grid-template-columns: ${Eo((c=t.frontmatter)==null?void 0:c.layoutRatio,b)};"`,T=["layout-cols-header-container",b===2?"layout-two-cols-header-container":"",b===3?"layout-three-cols-header-container":"",`layout-${e}-container`].filter(Boolean).join(" "),w=["layout-cols-wrapper","layout-cols-grid",b===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",b===3?"pdf-three-cols-wrapper layout-three-cols-grid":""].filter(Boolean).join(" "),L=y.map((B,N)=>{const Z=N+1;return`<div class="${["pdf-col",b===2&&Z===1?"pdf-col--left":"",b===2&&Z===2?"pdf-col--right":"",`pdf-col--${Z}`,`col-${Z}`].filter(Boolean).join(" ")}">${x(B)}</div>`}).join(`
`);return`
      <div class="${T}">
        <div class="layout-header-section">${_}</div>
        <div class="${w}" ${I}>
          ${L}
        </div>
      </div>
    `}if(e==="image-right"||e==="image-left"){const f=e==="image-right",k=o.map(A=>di(A,i)).join(`
`),p=((d=t.frontmatter)==null?void 0:d.image)||((u=t.frontmatter)==null?void 0:u.background)||"",b=`<div class="pdf-image-col" style="background-image:url('${le(p)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${le(p)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,y=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${k}</div>`,x=f?`${y}
${b}`:`${b}
${y}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${Eo((v=t.frontmatter)==null?void 0:v.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${x}
      </div>
    `}return e==="fact"?`<div class="layout-fact-container">${o.map(k=>di(k,i)).join(`
`)}</div>`:e==="cover"?`<div class="layout-cover-container">${o.map(k=>di(k,i)).join(`
`)}</div>`:o.map(f=>di(f,i)).join(`
`)}function le(t){return t?t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Ch(t){if(!t||t.trim()===""||t.trim()==="all")return"all";const i=new Set,e=t.split("|");for(const n of e){const o=n.trim();if(o==="all")return"all";if(o.includes("-")){const[s,l]=o.split("-"),r=parseInt(s,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)i.add(c)}else{const s=parseInt(o,10);isNaN(s)||i.add(s)}}return i}const $h=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function ke(t){if(!t)return"";const i=Fr(t),e=[],n=i.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,l)=>{const r=l.toLowerCase();if(!$h.has(r)||/on\w+\s*=|javascript:/i.test(s))return s;if(r==="v-mark"){const a=s.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return s.startsWith("</")?e.push("</mark>"):e.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${e.length-1}%%`}return e.push(s),`%%SAFE_HTML_${e.length-1}%%`});let o=le(n);return o=o.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,l,r,a,c,d,u)=>{const f=(r??a??c??d??u??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${f}</a>`}),o=o.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),o=o.replace(/\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),o=o.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${r}</a>`),o=o.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),o=o.replace(/\*(.*?)\*/g,"<em>$1</em>"),o=o.replace(/~~(.*?)~~/g,"<del>$1</del>"),o=o.replace(/`([^`]+)`/g,"<code>$1</code>"),o=o.replace(/%%SAFE_HTML_(\d+)%%/g,(s,l)=>{const r=parseInt(l,10);return e[r]||""}),o}function Ih(t,i="pdf-table"){if(t.length<2)return"";const e=t.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=e[0];let o=[],s=1;t.length>=2&&e[1].every(a=>/^:?-+:?$/.test(a))&&(o=e[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),s=2);const l=`<thead><tr>${n.map((a,c)=>`<th${o[c]?` style="text-align: ${o[c]}"`:""}>${ke(a)}</th>`).join("")}</tr></thead>`,r=e.slice(s).map(a=>`<tr>${a.map((c,d)=>`<td${o[d]?` style="text-align: ${o[d]}"`:""}>${ke(c)}</td>`).join("")}</tr>`).join("");return`<table class="${i}">${l}<tbody>${r}</tbody></table>`}function Uo(t){return String(t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Ah(t,i="ts"){if(!t)return"";if(t.trim().startsWith("//"))return`<span class="token-comment">${Uo(t)}</span>`;const e=[];function n(s,l){return e.push(`<span class="${s}">${Uo(l)}</span>`),`__TOK_${e.length-1}__`}let o=t.replace(/(['"`])(.*?)\1/g,(s,l,r)=>n("token-string",`${l}${r}${l}`));return o=o.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,s=>n("token-keyword",s)),o=o.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,s=>n("token-type",s)),o=o.replace(/\b(\d+)\b/g,s=>n("token-number",s)),o=Uo(o),o=o.replace(/__TOK_(\d+)__/g,(s,l)=>e[parseInt(l,10)]||""),o}function Th(t,i){if(!t)return null;const e=t.frontmatter||{};if(e.hideInToc===!0||e.hideInToc==="true")return null;let n=(e.title||"").trim(),o=e.level?parseInt(e.level,10):0;if(!n){const s=t.blocks||[];for(const l of s){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){o||(o=a[1].length),n=a[2].trim();break}}}return n?((!o||isNaN(o))&&(o=1),{pageIndex:t.pageIndex||i,title:n,level:o}):null}function Bh(t,i=1,e={}){const n=e.minDepth!==void 0?Number(e.minDepth):1,o=e.maxDepth!==void 0?Number(e.maxDepth):1/0,s=[];Array.isArray(t)&&t.forEach((c,d)=>{const u=Th(c,d+1);u&&s.push(u)});const l=[];let r=null;for(const c of s){const d={...c,active:c.pageIndex===i,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),r=d):r?(d.active&&(r.hasActiveChild=!0),r.children.push(d)):l.push(d)}function a(c,d=1){if(d>o)return[];const u=[];for(const v of c){const f=a(v.children,d+1);d>=n?u.push({...v,children:f}):u.push(...f)}return u}return a(l,1)}function Eh(t,i=1,e={}){const n=Bh(t,i,e),o=e.columns?Number(e.columns):1,s=o>1?` style="column-count: ${o};"`:"",l=e.textSm?" text-sm":"";function r(c,d=1){if(!c||c.length===0)return"";const u=`slidev-toc-list slidev-toc-list-level-${d}`,v=c.map(f=>{const k=f.active?" slidev-toc-item-active":f.hasActiveChild?" slidev-toc-item-parent-active":"",p=f.children&&f.children.length>0?r(f.children,d+1):"";let b=ke(f.title);return b.includes("LaTeX")&&(b=b.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${k}" data-page="${f.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${b}</span>
          </a>
          ${p}
        </li>
      `}).join("");return`<ol class="${u}">${v}</ol>`}const a=r(n,1);return`<div class="slidev-toc${l}"${s}>${a}</div>`}function di(t,i){var b,y,x,_,A,I,T,w,L;let e="",n="",o="";const s=[];(b=t.motion)!=null&&b.preset&&t.motion.preset!=="none"&&(e=` slidev-motion-${t.motion.preset.toLowerCase()}`,typeof t.motion.duration=="number"&&t.motion.duration>0&&s.push(`--motion-duration:${t.motion.duration}ms`),typeof t.motion.delay=="number"&&t.motion.delay>0&&s.push(`--motion-delay:${t.motion.delay}ms`));const l=((y=t.attributes)==null?void 0:y.style)||"";l&&(s.push(l),o=" slide-styled-block"),s.length>0&&(n=` style="${le(s.join(";"))}"`);const a=`pdf-block${e}${o}`,c=(t.rawMarkdown||t.content||"").trim();if(!c)return`<div class="${a}"${n}></div>`;if(c.includes('class="slidev-block-ref"')||c.includes('class="slidev-ref-tag"'))return`<div class="${a}"${n}>${c}</div>`;if(c.startsWith("$$")&&c.endsWith("$$")){const B=c.slice(2,-2).trim();return`<div class="${a} katex-display-container"${n}><div class="katex-display font-math"><em>${le(B)}</em></div></div>`}const d=c.match(/^(#{1,6})\s+(.*)$/);if(d){const B=d[1].length,N=ke(d[2]);return`<div class="${a}"${n}><h${B}>${N}</h${B}></div>`}if(c.startsWith(":::")){const B=c.split(`
`),Z=B[0].replace(/^:::\s*/,"").trim()||"info",$=B.slice(1,B[B.length-1].startsWith(":::")?-1:void 0).join(`
`),U="pdf-callout";return`<div class="${a}"${n}><div class="${U} ${U}--${Z}"><div class="${U}-title">${Z.toUpperCase()}</div><div class="${U}-body">${ke($)}</div></div></div>`}if(c.startsWith("<<<")){const Z=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((K,E)=>`<span class="code-line shiki-focus"><span class="line-no">${E+1}</span><span class="line-content">${Ah(K,"ts")}</span></span>`).join(`
`),$="pdf-code shiki-container",U=((x=t.attrs)==null?void 0:x["custom-slidev-max-height"])||t.maxHeight||"",m=U?` style="max-height:${le(U)};overflow-y:auto;"`:"";return`<div class="${a}"${n}><pre class="${$}"${m}><span class="lang-badge">TS</span><code>${Z}</code></pre></div>`}if(c.startsWith("<style")||c.startsWith("<!-- Inline style -->")||c.startsWith(`<!--
Notes`))return"";if(c.startsWith("```")){const B=c.split(`
`),N=B[0].slice(3).trim(),Z=N.match(/^([^\s{\[]+)/),$=Z?Z[1]:"",U=N.match(/\[([^\]]+)\]/),m=U?U[1]:"",K=N.includes("twoslash"),E=t.shikiLines||((_=N.match(/\{([^}]+)\}/))==null?void 0:_[1])||"",M=Ch(E),F=B.length>2?B[B.length-1]==="```"?B.slice(1,-1):B.slice(1):[c.slice(3).replace(/```$/,"")],O="pdf-code shiki-container",J=m?`${O} has-filename`:O,j=M!=="all",q=F.map((pt,bt)=>{const X=bt+1,vt=M==="all"||M.has(X)?"code-line shiki-focus":j?"code-line shiki-dimmed":"code-line";let D=le(pt);return K&&pt.includes("doubled.value = 2")?(D=D.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${vt}"><span class="line-no">${X}</span><span class="line-content">${D}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${vt}"><span class="line-no">${X}</span><span class="line-content">${D}</span></span>`}).join(`
`),rt=$?`<span class="lang-badge">${le($)}</span>`:"",lt=m?`<span class="code-filename">${le(m)}</span>`:"",st=((A=t.attrs)==null?void 0:A["custom-slidev-max-height"])||t.maxHeight||"",Q=st?` style="max-height:${le(st)};overflow-y:auto;"`:"";return`<div class="${a}"${n}><pre class="${J}"${Q}>${lt}${rt}<code>${q}</code></pre></div>`}if(c.includes("|")&&c.split(`
`).filter(B=>B.trim().startsWith("|")).length>=2){const B=c.split(`
`).filter(Z=>Z.trim().startsWith("|")),N=Ih(B,i==null?void 0:i.tableClassName);return`<div class="${a}"${n}>${N}</div>`}if(c.startsWith("> "))return`<div class="${a}"${n}><blockquote class="pdf-quote"><p>${ke(c.slice(2))}</p></blockquote></div>`;const u=/<video\b/i.test(c)||t.type==="video"||t.type==="NodeVideo",v=/^(\s*)([-*+]|\d+\.)\s+/m.test(c),f=/(?:^|\n)\s*#{1,6}\s+/.test(c);if(u&&!v&&!f&&!c.includes(`
`)){const B=((I=t.attributes)==null?void 0:I["custom-slidev-autoplay"])==="true"||/autoplay/i.test(c),N=((T=t.attributes)==null?void 0:T["custom-slidev-loop"])==="true"||/loop/i.test(c),Z=((w=t.attributes)==null?void 0:w["custom-slidev-muted"])==="true"||B||/muted/i.test(c),$=((L=t.attributes)==null?void 0:L["custom-slidev-controls"])==="false",U=c.match(/\bsrc=["']([^"']+)["']/i),m=U?U[1]:"",K=['class="slide-video-player"'];$||K.push("controls"),B&&(K.push("autoplay"),K.push("playsinline")),N&&K.push("loop"),Z&&K.push("muted"),K.push('preload="metadata"'),m&&K.push(`src="${m}"`);const E=c.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let M=E?E[1].trim():"";return!M&&m&&(M=`<source src="${m}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${a} ${a}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${B?"true":"false"}" data-muted="${Z?"true":"false"}"${n}><video ${K.join(" ")}>${M}</video></div>`}const k=c.match(/^!\[(.*?)\]\((.*?)\)$/);if(k)return`<div class="${a} ${a}--image slide-media-block slide-media-container"${n}><img alt="${le(k[1])}" src="${k[2]}" class="pdf-image slide-media-img" /></div>`;const p=oa(c,i,t);if(p)return`<div class="${a} pdf-list-item"${n}>${p}</div>`;if(/<(?:Toc|toc)\b/i.test(c)&&!c.startsWith("```")){const B=c.match(/minDepth=["']?(\d+)["']?/i),N=c.match(/maxDepth=["']?(\d+)["']?/i),Z=c.match(/columns=["']?(\d+)["']?/i);return`<div class="${a}"${n}>${Eh([],1,{minDepth:B?parseInt(B[1],10):1,maxDepth:N?parseInt(N[1],10):1/0,columns:Z?parseInt(Z[1],10):1,textSm:c.includes("text-sm")})}</div>`}if(c.includes(`
`)||f){const B=_h(c,i,t);if(B)return`<div class="${a}"${n}>${B}</div>`}return`<div class="${a}"${n}><p>${ke(c)}</p></div>`}function Mh(t){return`
    ${un(t)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      overflow-y: hidden !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }`}function Dh(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block) {
        const div = document.createElement("div");
        div.className = "slide-block";
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);

        if (md.startsWith("### ")) div.innerHTML = "<h3>" + md.slice(4) + "</h3>";
        else if (md.startsWith("## ")) div.innerHTML = "<h2>" + md.slice(3) + "</h2>";
        else if (md.startsWith("# ")) div.innerHTML = "<h1>" + md.slice(2) + "</h1>";
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            let pL = [];
            const flushLeadP = (isF) => {
              if (pL.length > 0) {
                let txt = pL.join(" ").replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                lParts.push('<p class="' + (isF ? "slide-list-item-title" : "slide-list-item-desc") + '">' + txt + '</p>');
                pL = [];
              }
            };
            let isF = true;
            for (const l of leadLines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushLeadP(isF);
                const lvl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                isF = false;
              } else {
                pL.push(l);
              }
            }
            flushLeadP(isF);
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = it.text.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.join(" ").replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              div.innerHTML = "<p>" + html + "</p>";
            }
          }
        }
        return div;
      }

      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          for (const b of leftList) leftCol.appendChild(renderBlock(b));
          for (const b of rightList) rightCol.appendChild(renderBlock(b));
          container.appendChild(leftCol);
          container.appendChild(rightCol);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header") {
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = 2;
          if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : ""));
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : ""));

          const gridCols = parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of (slide.blocks || [])) {
            contentCol.appendChild(renderBlock(block));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          if (isImageRight) {
            container.appendChild(contentCol);
            container.appendChild(imgCol);
          } else {
            container.appendChild(imgCol);
            container.appendChild(contentCol);
          }
        } else {
          for (const block of (slide.blocks || [])) {
            container.appendChild(renderBlock(block));
          }
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => renderSlide(currentIndex - 1));
      btnNext.addEventListener("click", () => renderSlide(currentIndex + 1));
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        if (e.key === "ArrowRight" || e.key === " ") renderSlide(currentIndex + 1);
        if (e.key === "ArrowLeft") renderSlide(currentIndex - 1);
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          renderSlide(currentIndex - 1);
        } else {
          renderSlide(currentIndex + 1);
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function sa(t,i){const e="Slidev 演示文稿";let n=t.slides;const o=JSON.stringify(n),s=JSON.stringify(t.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${le(e)}</title>
  <style>
${Mh(i==null?void 0:i.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(t.docId)},
      slides: ${o},
      config: ${s}
    };
  <\/script>
</head>
<body>
  <div id="app">
    <div class="slide-viewport slidev-theme-${t.config.theme||"default"}" id="viewport" data-slidev-theme="${t.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">⛶ 全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${Dh()}
  <\/script>
</body>
</html>`}function ra(t,i){if(typeof document>"u")return!1;const e=new Blob([i],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(e),o=document.createElement("a");return o.href=n,o.download=t.endsWith(".html")?t:`${t}.html`,document.body.appendChild(o),o.click(),document.body.removeChild(o),URL.revokeObjectURL(n),!0}function Lh(t){switch(t){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function Rh(t){const i=Lh(t==null?void 0:t.pageRatio);return`
    ${un(t==null?void 0:t.customInlineStyles)}

    @page {
      ${i}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
    }
  `}function Ph(t,i){const e="Slidev 演示讲义",n="16:9",o="light",s=t.slides.map((l,r)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,d=c&&c!=="inherit"?c:t.config.spacing||"normal",u=Sh(l),v=`${r+1} / ${t.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${o} spacing-${d}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${le(e)}</span>
          ${`<span class="pdf-page-badge">P. ${v}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${u}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${le(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${le(e)} - 高保真讲义</title>
  <style>
    ${Rh({pageRatio:n,customInlineStyles:i==null?void 0:i.customInlineStyles})}
  </style>
</head>
<body>
  ${s}
</body>
</html>`}function la(t,i){var o;if(typeof window>"u"||typeof document>"u")return!1;const e=Ph(t,i);try{const s=document.createElement("iframe");s.style.position="fixed",s.style.right="0",s.style.bottom="0",s.style.width="0",s.style.height="0",s.style.border="none",s.style.visibility="hidden",document.body.appendChild(s);const l=(o=s.contentWindow)==null?void 0:o.document;if(l)return l.open(),l.write(e),l.close(),setTimeout(()=>{var r,a;try{(r=s.contentWindow)==null||r.focus(),(a=s.contentWindow)==null||a.print()}finally{setTimeout(()=>{s.remove()},2e3)}},350),!0}catch(s){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",s)}const n=window.open("","_blank");return n?(n.document.write(e),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const Oh={class:"spm-slidev-preview-tab"},zh={class:"spm-slidev-tab__toolbar"},Nh={class:"spm-slidev-tab__actions"},Fh=["disabled"],jh={class:"spm-page-badge"},Hh=["disabled"],Uh=["aria-label"],Wh=["aria-label"],Vh=["src"],Kh=xe({__name:"SlidevPreviewTab",setup(t,{expose:i}){const e=Qe("plugin"),n=Qe("sandboxBridge",new Ls),o=new kh(n),s=new Yu,l=ft("web-sandbox"),r=ft(3030),a=ft(null),c=ft(!1),d=ft(null),u=ft(1),v=ft(1),f=ft([]),k=ft(!1),p=ft(!1),b=ft(!1),y=ft("siyuan"),x=ft(""),_=ft(""),A=ft(""),I=ft(!1),T=ft(!1),w=ft(""),L=ft("/plugins/siyuan-slidev/slidev-client/index.html");let B=null,N=null,Z=null,$=null,U=null,m=null,K=null;Dn(()=>{d.value&&(n.attach(d.value),s.nativeBridge.attach(d.value)),B=n.onSlideChanged((X,ut)=>{u.value=X,v.value=ut}),N=n.onBlockClicked((X,ut)=>{u.value=ut,o.setActiveBlockId(X),e&&typeof e.handleBlockClickedFromSlide=="function"?e.handleBlockClickedFromSlide(X,ut):Mi(X,e==null?void 0:e.app)}),Z=n.onOpenInEditor((X,ut)=>{u.value=ut,o.setActiveBlockId(X),Mi(X,e==null?void 0:e.app)}),$=s.nativeBridge.onPageChanged((X,ut)=>{u.value=X,v.value=ut}),U=n.onOpenPeekDrawer(async X=>{const ut=Ps();if(X.peekType==="siyuan"&&ut.enableWebServeJump){let vt=!1;if(K&&K.docId===X.target)vt=!0;else if(K&&K.slides&&K.slides.some(D=>{var z;return(z=D.blocks)==null?void 0:z.some(h=>h.id===X.target)}))vt=!1;else try{const D=await vn(`SELECT id, root_id, type FROM blocks WHERE id = '${X.target}' LIMIT 1`);D&&D.length>0&&(vt=D[0].type==="d"||D[0].id===D[0].root_id)}catch(D){console.warn("[SlidevPreviewTab] detect block type failed:",D)}y.value="web",I.value=!0,_.value=ea(ut.webServeUrl,X.target,{focus:!vt}),A.value=X.title||`${vt?"思源文档":"思源块"}: ${X.target.slice(0,8)}`,p.value=!0,n.freezeKeyboardNav(!0)}else y.value=X.peekType,X.peekType==="siyuan"?(x.value=X.target,A.value=X.title||`块速览: ${X.target.slice(0,8)}`):(I.value=!0,_.value=X.target,A.value=X.title||X.target),p.value=!0,n.freezeKeyboardNav(!0)}),m=n.onRequestToggleFullscreen(()=>{st()}),typeof document<"u"&&document.addEventListener("fullscreenchange",lt)}),Is(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",lt),U&&U(),m&&m(),B&&B(),N&&N(),Z&&Z(),$&&$(),n.detach(),o.destroy(),s.destroy()});async function E(){if(l.value==="web-sandbox"){if(!K){mt.showMessage("请先在主编辑区打开演示文档");return}mt.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const X=await s.startProMode(K,Ko);if(!X.success){mt.showMessage(`无法启动官方 Pro 模式：${X.error}`);return}l.value="pro-cli",r.value=X.port||3030,L.value=X.url,d.value&&s.nativeBridge.attach(d.value),mt.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else s.stopProMode(),l.value="web-sandbox",L.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&n.attach(d.value),mt.showMessage("已切回内置高保真沙箱")}function M(){T.value=!T.value,T.value?w.value=(K==null?void 0:K.docId)||"":(w.value="",j())}function F(){u.value>1&&(l.value==="pro-cli"?s.nativeBridge.navigateToPage(u.value-1):n.navigatePage(u.value-1))}function O(){u.value<v.value&&(l.value==="pro-cli"?s.nativeBridge.navigateToPage(u.value+1):n.navigatePage(u.value+1))}function J(X){u.value=X,l.value==="pro-cli"?s.nativeBridge.navigateToPage(X):n.navigatePage(X)}function j(){e&&typeof e.compileCurrentDocument=="function"?e.compileCurrentDocument():e!=null&&e.eventBus&&typeof e.eventBus.emit=="function"&&e.eventBus.emit("slidev:request-compile")}function q(){p.value=!1,n.freezeKeyboardNav(!1)}function rt(){q()}function lt(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function st(){const X=a.value||d.value;X&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):X.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function Q(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function pt(){if(!K){mt.showMessage("请先在主编辑区打开幻灯片文档");return}const X=sa(K);ra("presentation.html",X)&&mt.showMessage("已开始下载单文件离线 HTML 演示包")}function bt(){if(!K){mt.showMessage("请先在主编辑区打开幻灯片文档");return}la(K)&&mt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({updateDocument(X,ut){T.value&&w.value&&ut&&ut!==w.value||(K=X,T.value&&!w.value&&(w.value=X.docId),f.value=X.slides,v.value=X.slides.length,o.setDocId(X.docId),o.updateSlidesIndex(X.slides),l.value==="pro-cli"?s.scaffolder.scaffold(X,Ko).catch(()=>{}):n.updateSlides(X.slides,X.config,X.fullMarkdown,X.customThemeCss))},navigateToBlock(X){o.onCursorFocusBlock(X)},isPinned:T,pinnedDocId:w,engineMode:l,toggleEngineMode:E}),(X,ut)=>(tt(),nt("div",Oh,[g("div",zh,[ut[4]||(ut[4]=g("div",{class:"spm-slidev-tab__title"},[g("svg",{class:"spm-slidev-tab__icon","aria-hidden":"true"},[g("use",{"xlink:href":"#iconSlidev"})]),g("span",null,"Slidev 演示预览")],-1)),g("div",Nh,[g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:u.value<=1,"aria-label":"上一页",onClick:F},[ct(gt,{name:"chevron-left"})],8,Fh),g("span",jh,xt(u.value)+" / "+xt(v.value||1),1),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:u.value>=v.value,"aria-label":"下一页",onClick:O},[ct(gt,{name:"chevron-right"})],8,Hh),g("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":T.value}]),"aria-label":T.value?"已锁定当前文档（点击解除）："+w.value:"点击锁定当前文档（不随主编辑区切换）",onClick:M},[ct(gt,{name:"pin"}),g("span",null,xt(T.value?"已锁定":"跟随"),1)],10,Uh),g("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:E},[ct(gt,{name:"step"}),g("span",null,xt(l.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,Wh),ut[3]||(ut[3]=g("span",{class:"spm-toolbar-divider"},null,-1)),g("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":k.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:ut[0]||(ut[0]=vt=>k.value=!k.value)},[ct(gt,{name:"outline"})],2),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:Q},[ct(gt,{name:"presenter"})]),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:pt},[ct(gt,{name:"export-html"})]),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:bt},[ct(gt,{name:"export-pdf"})]),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:j},[ct(gt,{name:"refresh"})]),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:st},[ct(gt,{name:"fullscreen"})])])]),g("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container"},[g("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:L.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Vh),ct(Hp,{visible:p.value,"onUpdate:visible":ut[1]||(ut[1]=vt=>p.value=vt),"is-maximized":b.value,"onUpdate:isMaximized":ut[2]||(ut[2]=vt=>b.value=vt),title:A.value,onClose:q},{default:bl(()=>[y.value==="siyuan"&&x.value?(tt(),Me(Qp,{key:0,"block-id":x.value,title:A.value,plugin:ht(e),onExternalJump:rt},null,8,["block-id","title","plugin"])):Lt("",!0),I.value?Te((tt(),Me(bh,{key:1,visible:p.value&&y.value==="web",url:_.value,title:A.value,onExternalJump:rt},null,8,["visible","url","title"])),[[Gl,y.value==="web"]]):Lt("",!0)]),_:1},8,["visible","is-maximized","title"])],512),k.value&&f.value.length>0?(tt(),Me(Dp,{key:0,slides:f.value,"current-active-page":u.value,onNavigate:J,onRefresh:j},null,8,["slides","current-active-page"])):Lt("",!0)]))}}),qh=Oe(Kh,[["__scopeId","data-v-2622f6d8"]]),Gh={class:"spm-section spm-section--page"},Zh={class:"spm-section-header"},Yh={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},Jh={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Xh={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},Qh={key:1,class:"spm-card-control"},tm={class:"spm-control-header"},em={class:"spm-control-title-group"},im={class:"spm-control-title"},nm=["aria-label"],om={key:1,class:"spm-btn-text b3-tooltips b3-tooltips__w",disabled:"",style:{opacity:"0.45",cursor:"not-allowed"},"aria-label":"当前页未检测到调整过列宽的横向超级块（默认各列平均分配）"},sm={class:"spm-quick-chips"},rm=["onClick"],lm={style:{display:"flex",gap:"8px","align-items":"center","margin-top":"6px"}},am=["value"],cm={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center","justify-content":"space-between"}},dm={style:{display:"flex","align-items":"center",gap:"4px"}},um={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},fm={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6"}},pm={class:"spm-card-control"},hm={class:"spm-control-header"},mm={class:"spm-control-title-group"},gm={class:"spm-control-title"},vm={class:"spm-segmented-group"},bm={class:"spm-card-control"},ym={class:"spm-control-header"},km={class:"spm-control-title-group"},wm={class:"spm-control-title"},xm={class:"spm-quick-chips"},_m=["onClick"],Sm=["value"],Cm={key:2,class:"spm-card-control"},$m={class:"spm-control-header"},Im={class:"spm-control-title-group"},Am={class:"spm-control-title"},Tm={class:"spm-quick-chips"},Bm=["onClick"],Em=["value"],Mm={class:"spm-card-control"},Dm={class:"spm-control-header"},Lm={class:"spm-control-title-group"},Rm={class:"spm-control-title"},Pm={key:0,class:"spm-note-status-box"},Om=["title"],zm={class:"spm-action-grid",style:{"margin-top":"6px"}},Nm={key:1,class:"spm-note-empty-box"},Fm={class:"spm-card-control"},jm={class:"spm-action-grid"},Hm=xe({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},detectedSbRatio:{},detectedSbInfo:{}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","applySuperBlockLayout","addNoteBlock","locateNoteBlock","generateNotes","insertDividerAfter","deleteDivider"],setup(t,{emit:i}){const e=t,n=_t(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(e.pageLayout)),o=_t(()=>{var v,f;if(e.pageLayout==="two-cols-header"||e.pageLayout==="two-cols"||e.pageLayout==="image-left"||e.pageLayout==="image-right")return 2;if(e.pageLayout==="three-cols-header")return 3;const d=(e.pageLayoutRatio||"").trim();if(d.includes(":")){const k=d.split(":").filter(Boolean).length;if(k>=2&&k<=6)return k}const u=(e.detectedSbRatio||"").trim();if(u.includes(":")){const k=u.split(":").filter(Boolean).length;if(k>=2&&k<=6)return k}if((v=e.detectedSbInfo)!=null&&v.colCount&&e.detectedSbInfo.colCount>=2)return Math.min(e.detectedSbInfo.colCount,6);if((f=e.detectedSbInfo)!=null&&f.slots&&Array.isArray(e.detectedSbInfo.slots)){const k=e.detectedSbInfo.slots.length;if(k>=2&&k<=6)return k}return 2}),s=_t(()=>{const d=o.value;return d===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:d===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:d===5?[{label:"默认 1:1:1:1:1",value:""}]:d===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),l=_t(()=>e.pageLayoutRatio||""),r=_t(()=>{if(!e.pageNotes)return"";const d=e.pageNotes.replace(/[\r\n]+/g," ").trim();return d.length>50?d.slice(0,50)+"...":d}),a=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],c=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(d,u)=>(tt(),nt("div",Gh,[g("div",Zh,[g("span",null,"幻灯片页面设置"+xt(t.pageIndex?` (第 ${t.pageIndex} 页)`:""),1)]),ct(ta,{"model-value":t.pageLayout,onChange:u[0]||(u[0]=v=>d.$emit("update:pageLayout",v))},null,8,["model-value"]),!n.value&&t.detectedSbRatio?(tt(),nt("div",Yh,[g("div",Jh,[g("div",Xh,[ct(gt,{name:"sparkles"}),g("span",null,[u[22]||(u[22]=co("检测到本页横向超级块列宽比例：",-1)),g("b",null,xt(t.detectedSbRatio),1)])]),g("button",{class:"spm-btn-action",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff"},onClick:u[1]||(u[1]=v=>d.$emit("applySuperBlockLayout",t.detectedSbInfo||{recommendedLayout:"two-cols",ratio:t.detectedSbRatio}))}," 一键设为分栏并应用 ")])])):Lt("",!0),n.value?(tt(),nt("div",Qh,[g("div",tm,[g("div",em,[g("div",im,[ct(gt,{name:"ratio"}),u[23]||(u[23]=g("span",null,"分栏比例 (Ratio)",-1))]),u[24]||(u[24]=g("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))]),t.detectedSbRatio?(tt(),nt("button",{key:0,class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":`从当前页思源超级块读取实际宽度比例 (${t.detectedSbRatio})`,onClick:u[2]||(u[2]=v=>d.$emit("update:pageLayoutRatio",t.detectedSbRatio))},[ct(gt,{name:"sparkles"}),g("span",null,"从超级块读取 ("+xt(t.detectedSbRatio)+")",1)],8,nm)):(tt(),nt("button",om,[ct(gt,{name:"sparkles"}),u[25]||(u[25]=g("span",null,"从超级块读取 (未检测到)",-1))]))]),g("div",sm,[(tt(!0),nt(Kt,null,ye(s.value,v=>(tt(),nt("button",{key:v.value,class:It(["spm-chip",{active:l.value===v.value}]),onClick:f=>d.$emit("update:pageLayoutRatio",v.value)},xt(v.label),11,rm))),128))]),g("div",lm,[g("input",{value:t.pageLayoutRatio||"",class:"spm-input",style:{flex:"1"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:u[3]||(u[3]=v=>d.$emit("update:pageLayoutRatio",v.target.value)),onChange:u[4]||(u[4]=v=>d.$emit("update:pageLayoutRatio",v.target.value))},null,40,am),t.pageLayoutRatio?(tt(),nt("button",{key:0,class:"spm-btn-action b3-tooltips b3-tooltips__w","aria-label":"重置为默认平均分配",style:{"flex-shrink":"0",padding:"0 10px",height:"28px"},onClick:u[5]||(u[5]=v=>d.$emit("update:pageLayoutRatio",""))}," 重置 ")):Lt("",!0)]),t.detectedSbRatio?(tt(),nt("div",cm,[g("div",dm,[u[26]||(u[26]=g("span",null,"📐 检测到思源超级块宽度：",-1)),g("code",um,xt(t.detectedSbRatio),1)]),t.pageLayoutRatio!==t.detectedSbRatio?(tt(),nt("button",{key:0,class:"spm-btn-text",style:{"font-size":"11px",padding:"0 4px"},onClick:u[6]||(u[6]=v=>d.$emit("update:pageLayoutRatio",t.detectedSbRatio))}," 点击应用 ")):Lt("",!0)])):(tt(),nt("div",fm,[...u[27]||(u[27]=[g("span",null,"📐 未检测到调宽超级块（默认各列平均分配）",-1)])]))])):Lt("",!0),ct(Rs,{"model-value":t.pageTransition,onChange:u[7]||(u[7]=v=>d.$emit("update:pageTransition",v))},null,8,["model-value"]),g("div",pm,[g("div",hm,[g("div",mm,[g("div",gm,[ct(gt,{name:"ratio"}),u[28]||(u[28]=g("span",null,"页面间距 (Spacing)",-1))]),u[29]||(u[29]=g("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),g("div",vm,[g("button",{class:It(["spm-segmented-item",{active:!t.pageSpacing||t.pageSpacing==="inherit"}]),onClick:u[8]||(u[8]=v=>d.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),g("button",{class:It(["spm-segmented-item",{active:t.pageSpacing==="compact"}]),onClick:u[9]||(u[9]=v=>d.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),g("button",{class:It(["spm-segmented-item",{active:t.pageSpacing==="normal"}]),onClick:u[10]||(u[10]=v=>d.$emit("update:pageSpacing","normal"))}," 标准 ",2),g("button",{class:It(["spm-segmented-item",{active:t.pageSpacing==="loose"}]),onClick:u[11]||(u[11]=v=>d.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),g("div",bm,[g("div",ym,[g("div",km,[g("div",wm,[ct(gt,{name:"palette"}),u[30]||(u[30]=g("span",null,"页面背景 (Background)",-1))]),u[31]||(u[31]=g("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),g("div",xm,[(tt(),nt(Kt,null,ye(a,v=>g("button",{key:v.value,class:It(["spm-chip",{active:t.pageBackground===v.value}]),onClick:f=>d.$emit("update:pageBackground",v.value)},xt(v.label),11,_m)),64))]),g("input",{value:t.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:u[12]||(u[12]=v=>d.$emit("update:pageBackground",v.target.value)),onChange:u[13]||(u[13]=v=>d.$emit("update:pageBackground",v.target.value))},null,40,Sm)]),t.pageLayout==="image-right"||t.pageLayout==="image-left"||t.pageImage?(tt(),nt("div",Cm,[g("div",$m,[g("div",Im,[g("div",Am,[ct(gt,{name:"image"}),u[32]||(u[32]=g("span",null,"页面图片 (Image)",-1))]),u[33]||(u[33]=g("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),g("div",Tm,[(tt(),nt(Kt,null,ye(c,v=>g("button",{key:v.value,class:It(["spm-chip",{active:t.pageImage===v.value}]),onClick:f=>d.$emit("update:pageImage",v.value)},xt(v.label),11,Bm)),64))]),g("input",{value:t.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:u[14]||(u[14]=v=>d.$emit("update:pageImage",v.target.value)),onChange:u[15]||(u[15]=v=>d.$emit("update:pageImage",v.target.value))},null,40,Em)])):Lt("",!0),g("div",Mm,[g("div",Dm,[g("div",Lm,[g("div",Rm,[ct(gt,{name:"presenter"}),u[34]||(u[34]=g("span",null,"演讲者提词 (Notes)",-1))]),u[35]||(u[35]=g("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),g("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:u[16]||(u[16]=v=>d.$emit("generateNotes"))},[ct(gt,{name:"sparkles"}),u[36]||(u[36]=g("span",null,"AI 讲稿",-1))])]),t.pageNotes?(tt(),nt("div",Pm,[u[39]||(u[39]=g("div",{class:"spm-note-status-badge"},[g("span",{class:"spm-badge-dot"}),g("span",null,"已配置正文讲稿")],-1)),g("div",{class:"spm-note-preview-text",title:t.pageNotes},xt(r.value),9,Om),g("div",zm,[g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:u[17]||(u[17]=v=>d.$emit("locateNoteBlock"))},[ct(gt,{name:"search"}),u[37]||(u[37]=g("span",null,"定位讲稿块",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:u[18]||(u[18]=v=>d.$emit("addNoteBlock"))},[ct(gt,{name:"insert-below"}),u[38]||(u[38]=g("span",null,"追加讲稿块",-1))])])])):(tt(),nt("div",Nm,[u[41]||(u[41]=g("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:u[19]||(u[19]=v=>d.$emit("addNoteBlock"))},[ct(gt,{name:"insert-below"}),u[40]||(u[40]=g("span",null,"添加讲稿备注块",-1))])]))]),g("div",Fm,[u[44]||(u[44]=g("div",{class:"spm-control-header"},[g("div",{class:"spm-control-title-group"},[g("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),g("div",jm,[g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:u[20]||(u[20]=v=>d.$emit("insertDividerAfter"))},[ct(gt,{name:"insert-below"}),u[42]||(u[42]=g("span",null,"插入新页",-1))]),g("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:u[21]||(u[21]=v=>d.$emit("deleteDivider"))},[ct(gt,{name:"trash"}),u[43]||(u[43]=g("span",null,"删除此页",-1))])])])]))}}),Um=Oe(Hm,[["__scopeId","data-v-23e1c1e9"]]),Wm={class:"spm-section spm-section--block"},Vm={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},Km={class:"spm-control-header"},qm={class:"spm-control-title-group"},Gm={class:"spm-control-title"},Zm={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},Ym={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},Jm={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},Xm={key:0},Qm={key:1},tg={style:{background:"var(--b3-theme-primary-lightest)",color:"var(--b3-theme-primary)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},eg={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},ig={class:"spm-action-grid"},ng={class:"spm-card-control"},og={class:"spm-control-header"},sg={class:"spm-control-title-group"},rg={class:"spm-control-title"},lg=["aria-label"],ag=["checked"],cg={key:1,class:"spm-card-control"},dg={class:"spm-control-header"},ug={class:"spm-control-title-group"},fg={class:"spm-control-title"},pg={class:"spm-quick-chips"},hg={key:2,class:"spm-card-control"},mg={class:"spm-control-header"},gg={class:"spm-control-title-group"},vg={class:"spm-control-title"},bg={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},yg={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},kg=["aria-label"],wg=["checked"],xg={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},_g=["aria-label"],Sg=["checked"],Cg={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},$g=["aria-label"],Ig=["checked"],Ag={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Tg=["aria-label"],Bg=["checked"],Eg={class:"spm-card-control"},Mg={class:"spm-control-header"},Dg={class:"spm-control-title-group"},Lg={class:"spm-control-title"},Rg=["aria-label"],Pg=["checked"],Og={key:0,class:"spm-quick-chips"},zg=["onClick"],Ng={class:"spm-card-control"},Fg={class:"spm-control-header"},jg={class:"spm-control-title-group"},Hg={class:"spm-control-title"},Ug=["aria-label"],Wg=["checked"],Vg={key:0,class:"spm-quick-chips"},Kg=["onClick"],qg={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},Gg={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},Zg={style:{display:"flex",gap:"6px"}},Yg=["value"],Jg=["value"],Xg={key:3,class:"spm-card-control"},Qg={class:"spm-control-header"},tv={class:"spm-control-title-group"},ev={class:"spm-control-title"},iv={class:"spm-control-desc"},nv={class:"spm-segmented-group"},ov=["onClick"],sv={key:4,class:"spm-card-control"},rv={class:"spm-control-header"},lv={class:"spm-control-title-group"},av={class:"spm-control-title"},cv={class:"spm-quick-chips"},dv=["onClick"],uv=["value"],fv={key:5,class:"spm-card-control"},pv={class:"spm-control-header"},hv={class:"spm-control-title-group"},mv={class:"spm-control-title"},gv={class:"spm-quick-chips"},vv=["onClick"],bv=["value"],yv={class:"spm-card-control"},kv={class:"spm-action-grid"},wv=["aria-label"],xv=xe({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(t,{emit:i}){const e=t,n=_t(()=>{const T=e.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(e.elemSlot)?"cols-header":T}),o=_t(()=>{const T=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(T)}),s=_t(()=>{var w,L,B,N;if((w=e.detectedSbInfo)!=null&&w.colCount&&e.detectedSbInfo.colCount>=2)return Math.min(e.detectedSbInfo.colCount,6);const T=(L=e.elemSlot)==null?void 0:L.match(/^col-(\d+)$/);if(T){const Z=parseInt(T[1],10);if(Z>=2&&Z<=6)return Math.max(Z,3)}if(e.currentSlideLayout==="three-cols-header")return 3;if(e.currentSlideLayout==="two-cols-header"||e.currentSlideLayout==="two-cols")return 2;if((N=(B=e.detectedSbInfo)==null?void 0:B.ratio)!=null&&N.includes(":")){const Z=e.detectedSbInfo.ratio.split(":").filter(Boolean);if(Z.length>=2)return Math.min(Z.length,6)}return 3}),l=_t(()=>{const T=n.value;return T==="cols-header"?"多栏插槽归属 (Slot)":T==="three-cols-header"?"三栏插槽归属 (Slot)":T==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),r=_t(()=>{const T=n.value;return T==="cols-header"?`在 cols-header 表头多栏（${s.value} 栏）中的内容块位置`:T==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":T==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":T==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=_t(()=>{const T=n.value;if(T==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(T==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(T==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const w=s.value,L=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let B=1;B<=w;B++)L.push({value:`col-${B}`,label:`第 ${B} 栏`});return L});function c(T){const w=e.elemSlot||"";return T?w===T||T==="col-1"&&w==="left"||T==="col-2"&&w==="center"||T==="col-3"&&w==="right"&&s.value===3||T==="col-2"&&w==="right"&&s.value===2||T==="left"&&w==="col-1"||T==="right"&&(w==="col-2"||w==="col-3"):!w||w==="default"}const d=i,u=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],v=_t(()=>{if(!e.elemMotion||e.elemMotion.trim()===""||e.elemMotion.trim()==="none")return null;try{const T=JSON.parse(e.elemMotion);if(typeof T=="object"&&T!==null)return{preset:T.preset||T.type||"slide-up",duration:typeof T.duration=="number"?T.duration:0,delay:typeof T.delay=="number"?T.delay:0}}catch{}return{preset:e.elemMotion.trim(),duration:0,delay:0}}),f=_t(()=>!!v.value),k=_t(()=>{var T;return((T=v.value)==null?void 0:T.preset)||"slide-up"}),p=_t(()=>{var T;return((T=v.value)==null?void 0:T.duration)||0}),b=_t(()=>{var T;return((T=v.value)==null?void 0:T.delay)||0});function y(){f.value?d("update:elemMotion",""):d("update:elemMotion","slide-up")}function x(T){I(T,p.value,b.value)}function _(T){I(k.value,T,b.value)}function A(T){I(k.value,p.value,T)}function I(T,w,L){if(!T||T==="none"){d("update:elemMotion","");return}if(!w&&!L){d("update:elemMotion",T);return}const B={preset:T};w>0&&(B.duration=w),L>0&&(B.delay=L),d("update:elemMotion",JSON.stringify(B))}return(T,w)=>{var L,B,N,Z,$,U;return tt(),nt("div",Wm,[w[58]||(w[58]=g("div",{class:"spm-section-header"},[g("span",null,"元素动效与排版")],-1)),t.isSuperBlock||(L=t.detectedSbInfo)!=null&&L.hasSuperBlock?(tt(),nt("div",Vm,[g("div",Km,[g("div",qm,[g("div",Gm,[ct(gt,{name:"ratio"}),w[24]||(w[24]=g("span",null,"超级块列宽与布局",-1))]),w[25]||(w[25]=g("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),g("div",Zm,[g("div",Ym,[g("div",Jm,[(B=t.detectedSbInfo)!=null&&B.isCustomWidth?(tt(),nt("span",Xm,"📐 已识别自定义列宽比例")):(tt(),nt("span",Qm,"📐 识别到 "+xt(((N=t.detectedSbInfo)==null?void 0:N.colCount)||2)+" 列超级块分栏",1))]),g("code",tg,xt(((Z=t.detectedSbInfo)==null?void 0:Z.ratio)||"1:1"),1)]),g("div",eg,xt(($=t.detectedSbInfo)!=null&&$.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),g("div",ig,[g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"var(--b3-theme-primary-lightest)",color:"var(--b3-theme-primary)","font-weight":"500"},onClick:w[0]||(w[0]=m=>T.$emit("applySuperBlockLayout",t.detectedSbInfo))},[ct(gt,{name:"sparkles"}),w[26]||(w[26]=g("span",null,"设为本页排版与比例",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:w[1]||(w[1]=m=>{var K;return T.$emit("applySuperBlockRatio",((K=t.detectedSbInfo)==null?void 0:K.ratio)||"1:1")})},[ct(gt,{name:"check"}),g("span",null,"仅应用比例 ("+xt(((U=t.detectedSbInfo)==null?void 0:U.ratio)||"1:1")+")",1)])])])):Lt("",!0),g("div",ng,[g("div",og,[g("div",sg,[g("div",rg,[ct(gt,{name:"presenter"}),w[27]||(w[27]=g("span",null,"设为讲稿备注 (slidev-note)",-1))]),w[28]||(w[28]=g("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.isNote?"取消讲稿备注":"设为讲稿备注"},[g("input",{type:"checkbox",checked:!!t.isNote,onChange:w[2]||(w[2]=m=>T.$emit("toggleNote"))},null,40,ag),w[29]||(w[29]=g("span",{class:"spm-switch-slider"},null,-1))],8,lg)])]),t.isImage||t.imageRole?(tt(),nt("div",cg,[g("div",dg,[g("div",ug,[g("div",fg,[ct(gt,{name:"image"}),w[30]||(w[30]=g("span",null,"图片角色与分栏 (Image & Layout)",-1))]),w[31]||(w[31]=g("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),g("div",pg,[g("button",{class:It(["spm-chip",{active:!t.imageRole}]),onClick:w[3]||(w[3]=m=>T.$emit("update:imageRole",""))}," 普通内容 ",2),g("button",{class:It(["spm-chip",{active:t.imageRole==="background"}]),onClick:w[4]||(w[4]=m=>T.$emit("update:imageRole","background"))}," 🖼️ 背景图 ",2),g("button",{class:It(["spm-chip",{active:t.imageRole==="image-left"}]),onClick:w[5]||(w[5]=m=>T.$emit("update:imageRole","image-left"))}," 🎨 图左 ",2),g("button",{class:It(["spm-chip",{active:t.imageRole==="image-right"}]),onClick:w[6]||(w[6]=m=>T.$emit("update:imageRole","image-right"))}," 🖼️ 图右 ",2)])])):Lt("",!0),t.isVideo?(tt(),nt("div",hg,[g("div",mg,[g("div",gg,[g("div",vg,[ct(gt,{name:"video"}),w[32]||(w[32]=g("span",null,"视频播放设置 (Video Playback)",-1))]),w[33]||(w[33]=g("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),g("div",bg,[g("div",yg,[w[35]||(w[35]=g("span",{style:{"font-size":"11px"}},"🎛️ 控制条",-1)),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoControls?"关闭控制条":"开启控制条"},[g("input",{type:"checkbox",checked:!!t.videoControls,onChange:w[7]||(w[7]=m=>T.$emit("toggleVideoControls"))},null,40,wg),w[34]||(w[34]=g("span",{class:"spm-switch-slider"},null,-1))],8,kg)]),g("div",xg,[w[37]||(w[37]=g("span",{style:{"font-size":"11px"}},"▶️ 自动播放",-1)),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoAutoplay?"关闭自动播放":"开启自动播放"},[g("input",{type:"checkbox",checked:!!t.videoAutoplay,onChange:w[8]||(w[8]=m=>T.$emit("toggleVideoAutoplay"))},null,40,Sg),w[36]||(w[36]=g("span",{class:"spm-switch-slider"},null,-1))],8,_g)]),g("div",Cg,[w[39]||(w[39]=g("span",{style:{"font-size":"11px"}},"🔁 循环播放",-1)),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoLoop?"关闭循环播放":"开启循环播放"},[g("input",{type:"checkbox",checked:!!t.videoLoop,onChange:w[9]||(w[9]=m=>T.$emit("toggleVideoLoop"))},null,40,Ig),w[38]||(w[38]=g("span",{class:"spm-switch-slider"},null,-1))],8,$g)]),g("div",Ag,[w[41]||(w[41]=g("span",{style:{"font-size":"11px"}},"🔇 静音播放",-1)),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoMuted?"关闭静音":"开启静音"},[g("input",{type:"checkbox",checked:!!t.videoMuted,onChange:w[10]||(w[10]=m=>T.$emit("toggleVideoMuted"))},null,40,Bg),w[40]||(w[40]=g("span",{class:"spm-switch-slider"},null,-1))],8,Tg)])])])):Lt("",!0),g("div",Eg,[g("div",Mg,[g("div",Dg,[g("div",Lg,[ct(gt,{name:"step"}),w[42]||(w[42]=g("span",null,"逐步呈现 (v-click)",-1))]),w[43]||(w[43]=g("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[g("input",{type:"checkbox",checked:!!t.elemClick,onChange:w[11]||(w[11]=m=>T.$emit("toggleElemClick"))},null,40,Pg),w[44]||(w[44]=g("span",{class:"spm-switch-slider"},null,-1))],8,Rg)]),t.elemClick?(tt(),nt("div",Og,[(tt(),nt(Kt,null,ye(["+1","1","2","hide"],m=>g("button",{key:m,class:It(["spm-chip",{active:t.elemClick===m}]),onClick:K=>T.$emit("update:elemClick",m)},xt(m==="+1"?"顺延 (+1)":m==="hide"?"隐藏 (hide)":"第 "+m+" 步"),11,zg)),64))])):Lt("",!0)]),g("div",Ng,[g("div",Fg,[g("div",jg,[g("div",Hg,[ct(gt,{name:"motion"}),w[45]||(w[45]=g("span",null,"入场微动效 (v-motion)",-1))]),w[46]||(w[46]=g("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":f.value?"关闭微动效":"开启微动效 (slide-up)"},[g("input",{type:"checkbox",checked:f.value,onChange:y},null,40,Wg),w[47]||(w[47]=g("span",{class:"spm-switch-slider"},null,-1))],8,Ug)]),f.value?(tt(),nt("div",Vg,[(tt(),nt(Kt,null,ye(u,m=>g("button",{key:m.value,class:It(["spm-chip",{active:k.value===m.value}]),onClick:K=>x(m.value)},xt(m.label),11,Kg)),64))])):Lt("",!0),f.value?(tt(),nt("div",qg,[g("div",Gg,[g("span",null,"时长: "+xt(p.value?p.value+"ms":"默认 (450ms)"),1),g("span",null,"延迟: "+xt(b.value?b.value+"ms":"0ms"),1)]),g("div",Zg,[g("select",{class:"spm-select",style:{flex:"1"},value:p.value,onChange:w[12]||(w[12]=m=>_(Number(m.target.value)))},[...w[48]||(w[48]=[g("option",{value:0},"默认耗时",-1),g("option",{value:200},"极速 (200ms)",-1),g("option",{value:350},"较快 (350ms)",-1),g("option",{value:500},"平滑 (500ms)",-1),g("option",{value:800},"缓慢 (800ms)",-1)])],40,Yg),g("select",{class:"spm-select",style:{flex:"1"},value:b.value,onChange:w[13]||(w[13]=m=>A(Number(m.target.value)))},[...w[49]||(w[49]=[g("option",{value:0},"无延迟",-1),g("option",{value:150},"延迟 150ms",-1),g("option",{value:300},"延迟 300ms",-1),g("option",{value:500},"延迟 500ms",-1)])],40,Jg)])])):Lt("",!0)]),o.value||t.elemSlot?(tt(),nt("div",Xg,[g("div",Qg,[g("div",tv,[g("div",ev,[ct(gt,{name:"columns"}),g("span",null,xt(l.value),1)]),g("span",iv,xt(r.value),1)])]),g("div",nv,[(tt(!0),nt(Kt,null,ye(a.value,m=>(tt(),nt("button",{key:m.value,class:It(["spm-segmented-item",{active:c(m.value)}]),onClick:K=>T.$emit("update:elemSlot",m.value)},xt(m.label),11,ov))),128))])])):Lt("",!0),t.isCodeBlock?(tt(),nt("div",sv,[g("div",rv,[g("div",lv,[g("div",av,[ct(gt,{name:"code"}),w[50]||(w[50]=g("span",null,"代码逐行聚光 (Shiki)",-1))]),w[51]||(w[51]=g("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),g("div",cv,[(tt(),nt(Kt,null,ye(["1-3","all","1|2|3","2-5"],m=>g("button",{key:m,class:It(["spm-chip",{active:t.elemShikiLines===m}]),onClick:K=>T.$emit("update:elemShikiLines",m)},xt(m),11,dv)),64)),t.elemShikiLines?(tt(),nt("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[14]||(w[14]=m=>T.$emit("update:elemShikiLines",""))}," 清空 ")):Lt("",!0)]),g("input",{value:t.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:w[15]||(w[15]=m=>T.$emit("update:elemShikiLines",m.target.value)),onChange:w[16]||(w[16]=m=>T.$emit("update:elemShikiLines",m.target.value))},null,40,uv)])):Lt("",!0),t.isCodeBlock?(tt(),nt("div",fv,[g("div",pv,[g("div",hv,[g("div",mv,[ct(gt,{name:"code"}),w[52]||(w[52]=g("span",null,"代码块限高 (Max Height)",-1))]),w[53]||(w[53]=g("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),g("div",gv,[(tt(),nt(Kt,null,ye(["240px","320px","400px","50vh"],m=>g("button",{key:m,class:It(["spm-chip",{active:t.elemMaxHeight===m}]),onClick:K=>T.$emit("update:elemMaxHeight",m)},xt(m),11,vv)),64)),t.elemMaxHeight?(tt(),nt("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[17]||(w[17]=m=>T.$emit("update:elemMaxHeight",""))}," 自适应 ")):Lt("",!0)]),g("input",{value:t.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:w[18]||(w[18]=m=>T.$emit("update:elemMaxHeight",m.target.value)),onChange:w[19]||(w[19]=m=>T.$emit("update:elemMaxHeight",m.target.value))},null,40,bv)])):Lt("",!0),g("div",yv,[w[57]||(w[57]=g("div",{class:"spm-control-header"},[g("div",{class:"spm-control-title-group"},[g("span",{class:"spm-control-title"},"快捷操作")])],-1)),g("div",kv,[g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:w[20]||(w[20]=m=>T.$emit("insertDividerBefore"))},[ct(gt,{name:"insert-above"}),w[54]||(w[54]=g("span",null,"上方分页",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:w[21]||(w[21]=m=>T.$emit("insertDividerAfter"))},[ct(gt,{name:"insert-below"}),w[55]||(w[55]=g("span",null,"下方分页",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:w[22]||(w[22]=m=>T.$emit("setTwoColsContrast"))},[ct(gt,{name:"columns"}),g("span",null,xt(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,wv),t.hasBlockAttrs?(tt(),nt("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:w[23]||(w[23]=m=>T.$emit("clearBlockAttrs"))},[ct(gt,{name:"broom"}),w[56]||(w[56]=g("span",null,"清除属性",-1))])):Lt("",!0)])])])}}}),_v={class:"spm-section spm-section--doc"},Sv={class:"spm-card-control"},Cv={class:"spm-control-header"},$v={class:"spm-control-title-group"},Iv={class:"spm-control-title"},Av={class:"spm-segmented-group"},Tv=["aria-label","onClick"],Bv={class:"spm-card-control"},Ev={class:"spm-control-header"},Mv={class:"spm-control-title-group"},Dv={class:"spm-control-title"},Lv={class:"spm-segmented-group"},Rv={class:"spm-card-control"},Pv={class:"spm-control-header"},Ov={class:"spm-control-title-group"},zv={class:"spm-control-title"},Nv={class:"spm-segmented-group"},Fv={class:"spm-card-control"},jv={class:"spm-control-header"},Hv={class:"spm-control-title-group"},Uv={class:"spm-control-title"},Wv={class:"spm-card-control"},Vv={class:"spm-control-header"},Kv={class:"spm-control-title-group"},qv={class:"spm-control-title"},Gv=["aria-label"],Zv=["checked"],Yv={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},Jv=["value"],Xv={class:"spm-card-control"},Qv={class:"spm-action-grid"},tb=xe({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(t){const i=Qe("plugin"),e=Ai,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function o(r){qi({enableWebServeJump:r}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({enableWebServeJump:r})}function s(r){qi({webServeUrl:r})}function l(r){qi({webServeUrl:r}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({webServeUrl:r})}return(r,a)=>(tt(),nt("div",_v,[a[35]||(a[35]=g("div",{class:"spm-section-header"},[g("span",null,"全局演示配置")],-1)),g("div",Sv,[g("div",Cv,[g("div",$v,[g("div",Iv,[ct(gt,{name:"palette"}),a[17]||(a[17]=g("span",null,"幻灯片主题 (Theme)",-1))]),a[18]||(a[18]=g("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),g("div",Av,[(tt(),nt(Kt,null,ye(n,c=>g("button",{key:c.value,class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:t.docTheme===c.value}]),"aria-label":c.desc,onClick:d=>r.$emit("update:docTheme",c.value)},xt(c.label),11,Tv)),64))])]),g("div",Bv,[g("div",Ev,[g("div",Mv,[g("div",Dv,[ct(gt,{name:"ratio"}),a[19]||(a[19]=g("span",null,"画幅比例 (Aspect Ratio)",-1))]),a[20]||(a[20]=g("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),g("div",Lv,[g("button",{class:It(["spm-segmented-item",{active:t.docAspectRatio==="16/9"}]),onClick:a[0]||(a[0]=c=>r.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),g("button",{class:It(["spm-segmented-item",{active:t.docAspectRatio==="4/3"}]),onClick:a[1]||(a[1]=c=>r.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),g("button",{class:It(["spm-segmented-item",{active:t.docAspectRatio==="16/10"}]),onClick:a[2]||(a[2]=c=>r.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),g("div",Rv,[g("div",Pv,[g("div",Ov,[g("div",zv,[ct(gt,{name:"ratio"}),a[21]||(a[21]=g("span",null,"间距风格 (Spacing)",-1))]),a[22]||(a[22]=g("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),g("div",Nv,[g("button",{class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:a[3]||(a[3]=c=>r.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),g("button",{class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:a[4]||(a[4]=c=>r.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),g("button",{class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:a[5]||(a[5]=c=>r.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),g("div",Fv,[g("div",jv,[g("div",Hv,[g("div",Uv,[ct(gt,{name:"transition"}),a[23]||(a[23]=g("span",null,"全局默认转场",-1))]),a[24]||(a[24]=g("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),ct(Rs,{"model-value":t.docDefaultTransition,"hide-header":!0,onChange:a[6]||(a[6]=c=>r.$emit("update:docDefaultTransition",c))},null,8,["model-value"])]),g("div",Wv,[g("div",Vv,[g("div",Kv,[g("div",qv,[ct(gt,{name:"external-link"}),a[25]||(a[25]=g("span",null,"本地网络伺服预览 (Web Serve)",-1))]),a[26]||(a[26]=g("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ht(e).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[g("input",{type:"checkbox",checked:ht(e).enableWebServeJump,onChange:a[7]||(a[7]=c=>o(c.target.checked))},null,40,Zv),a[27]||(a[27]=g("span",{class:"spm-switch-slider"},null,-1))],8,Gv)]),ht(e).enableWebServeJump?(tt(),nt("div",Yv,[g("input",{value:ht(e).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:a[8]||(a[8]=Ee(()=>{},["stop"])),onKeyup:a[9]||(a[9]=Ee(()=>{},["stop"])),onInput:a[10]||(a[10]=c=>s(c.target.value)),onChange:a[11]||(a[11]=c=>l(c.target.value))},null,40,Jv),a[28]||(a[28]=g("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Lt("",!0)]),g("div",Xv,[a[34]||(a[34]=g("div",{class:"spm-control-header"},[g("div",{class:"spm-control-title-group"},[g("span",{class:"spm-control-title"},"演示全局操作")])],-1)),g("div",Qv,[g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:a[12]||(a[12]=c=>r.$emit("openBottomPreview"))},[ct(gt,{name:"split-preview"}),a[29]||(a[29]=g("span",null,"分屏预览",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:a[13]||(a[13]=c=>r.$emit("openPresenter"))},[ct(gt,{name:"presenter"}),a[30]||(a[30]=g("span",null,"演讲者视图",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:a[14]||(a[14]=c=>r.$emit("aiAutoSplit"))},[ct(gt,{name:"sparkles"}),a[31]||(a[31]=g("span",null,"AI 智能分页",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:a[15]||(a[15]=c=>r.$emit("exportHtml"))},[ct(gt,{name:"export-html"}),a[32]||(a[32]=g("span",null,"导出 HTML",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:a[16]||(a[16]=c=>r.$emit("exportPdf"))},[ct(gt,{name:"export-pdf"}),a[33]||(a[33]=g("span",null,"导出 PDF",-1))])])])]))}});var Wn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function eb(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}function Vn(t){throw new Error('Could not dynamically require "'+t+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Wo={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var $r;function ib(){return $r||($r=1,(function(t,i){(function(e){t.exports=e()})(function(){return(function e(n,o,s){function l(c,d){if(!o[c]){if(!n[c]){var u=typeof Vn=="function"&&Vn;if(!d&&u)return u(c,!0);if(r)return r(c,!0);var v=new Error("Cannot find module '"+c+"'");throw v.code="MODULE_NOT_FOUND",v}var f=o[c]={exports:{}};n[c][0].call(f.exports,function(k){var p=n[c][1][k];return l(p||k)},f,f.exports,e,n,o,s)}return o[c].exports}for(var r=typeof Vn=="function"&&Vn,a=0;a<s.length;a++)l(s[a]);return l})({1:[function(e,n,o){var s=e("./utils"),l=e("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";o.encode=function(a){for(var c,d,u,v,f,k,p,b=[],y=0,x=a.length,_=x,A=s.getTypeOf(a)!=="string";y<a.length;)_=x-y,u=A?(c=a[y++],d=y<x?a[y++]:0,y<x?a[y++]:0):(c=a.charCodeAt(y++),d=y<x?a.charCodeAt(y++):0,y<x?a.charCodeAt(y++):0),v=c>>2,f=(3&c)<<4|d>>4,k=1<_?(15&d)<<2|u>>6:64,p=2<_?63&u:64,b.push(r.charAt(v)+r.charAt(f)+r.charAt(k)+r.charAt(p));return b.join("")},o.decode=function(a){var c,d,u,v,f,k,p=0,b=0,y="data:";if(a.substr(0,y.length)===y)throw new Error("Invalid base64 input, it looks like a data url.");var x,_=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&_--,a.charAt(a.length-2)===r.charAt(64)&&_--,_%1!=0)throw new Error("Invalid base64 input, bad content length.");for(x=l.uint8array?new Uint8Array(0|_):new Array(0|_);p<a.length;)c=r.indexOf(a.charAt(p++))<<2|(v=r.indexOf(a.charAt(p++)))>>4,d=(15&v)<<4|(f=r.indexOf(a.charAt(p++)))>>2,u=(3&f)<<6|(k=r.indexOf(a.charAt(p++))),x[b++]=c,f!==64&&(x[b++]=d),k!==64&&(x[b++]=u);return x}},{"./support":30,"./utils":32}],2:[function(e,n,o){var s=e("./external"),l=e("./stream/DataWorker"),r=e("./stream/Crc32Probe"),a=e("./stream/DataLengthProbe");function c(d,u,v,f,k){this.compressedSize=d,this.uncompressedSize=u,this.crc32=v,this.compression=f,this.compressedContent=k}c.prototype={getContentWorker:function(){var d=new l(s.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),u=this;return d.on("end",function(){if(this.streamInfo.data_length!==u.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(s.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,u,v){return d.pipe(new r).pipe(new a("uncompressedSize")).pipe(u.compressWorker(v)).pipe(new a("compressedSize")).withStreamInfo("compression",u)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(e,n,o){var s=e("./stream/GenericWorker");o.STORE={magic:"\0\0",compressWorker:function(){return new s("STORE compression")},uncompressWorker:function(){return new s("STORE decompression")}},o.DEFLATE=e("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(e,n,o){var s=e("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var d=0;d<8;d++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();n.exports=function(r,a){return r!==void 0&&r.length?s.getTypeOf(r)!=="string"?(function(c,d,u,v){var f=l,k=v+u;c^=-1;for(var p=v;p<k;p++)c=c>>>8^f[255&(c^d[p])];return-1^c})(0|a,r,r.length,0):(function(c,d,u,v){var f=l,k=v+u;c^=-1;for(var p=v;p<k;p++)c=c>>>8^f[255&(c^d.charCodeAt(p))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(e,n,o){o.base64=!1,o.binary=!1,o.dir=!1,o.createFolders=!0,o.date=null,o.compression=null,o.compressionOptions=null,o.comment=null,o.unixPermissions=null,o.dosPermissions=null},{}],6:[function(e,n,o){var s=null;s=typeof Promise<"u"?Promise:e("lie"),n.exports={Promise:s}},{lie:37}],7:[function(e,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=e("pako"),r=e("./utils"),a=e("./stream/GenericWorker"),c=s?"uint8array":"array";function d(u,v){a.call(this,"FlateWorker/"+u),this._pako=null,this._pakoAction=u,this._pakoOptions=v,this.meta={}}o.magic="\b\0",r.inherits(d,a),d.prototype.processChunk=function(u){this.meta=u.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,u.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var u=this;this._pako.onData=function(v){u.push({data:v,meta:u.meta})}},o.compressWorker=function(u){return new d("Deflate",u)},o.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(e,n,o){function s(f,k){var p,b="";for(p=0;p<k;p++)b+=String.fromCharCode(255&f),f>>>=8;return b}function l(f,k,p,b,y,x){var _,A,I=f.file,T=f.compression,w=x!==c.utf8encode,L=r.transformTo("string",x(I.name)),B=r.transformTo("string",c.utf8encode(I.name)),N=I.comment,Z=r.transformTo("string",x(N)),$=r.transformTo("string",c.utf8encode(N)),U=B.length!==I.name.length,m=$.length!==N.length,K="",E="",M="",F=I.dir,O=I.date,J={crc32:0,compressedSize:0,uncompressedSize:0};k&&!p||(J.crc32=f.crc32,J.compressedSize=f.compressedSize,J.uncompressedSize=f.uncompressedSize);var j=0;k&&(j|=8),w||!U&&!m||(j|=2048);var q=0,rt=0;F&&(q|=16),y==="UNIX"?(rt=798,q|=(function(st,Q){var pt=st;return st||(pt=Q?16893:33204),(65535&pt)<<16})(I.unixPermissions,F)):(rt=20,q|=(function(st){return 63&(st||0)})(I.dosPermissions)),_=O.getUTCHours(),_<<=6,_|=O.getUTCMinutes(),_<<=5,_|=O.getUTCSeconds()/2,A=O.getUTCFullYear()-1980,A<<=4,A|=O.getUTCMonth()+1,A<<=5,A|=O.getUTCDate(),U&&(E=s(1,1)+s(d(L),4)+B,K+="up"+s(E.length,2)+E),m&&(M=s(1,1)+s(d(Z),4)+$,K+="uc"+s(M.length,2)+M);var lt="";return lt+=`
\0`,lt+=s(j,2),lt+=T.magic,lt+=s(_,2),lt+=s(A,2),lt+=s(J.crc32,4),lt+=s(J.compressedSize,4),lt+=s(J.uncompressedSize,4),lt+=s(L.length,2),lt+=s(K.length,2),{fileRecord:u.LOCAL_FILE_HEADER+lt+L+K,dirRecord:u.CENTRAL_FILE_HEADER+s(rt,2)+lt+s(Z.length,2)+"\0\0\0\0"+s(q,4)+s(b,4)+L+K+Z}}var r=e("../utils"),a=e("../stream/GenericWorker"),c=e("../utf8"),d=e("../crc32"),u=e("../signature");function v(f,k,p,b){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=k,this.zipPlatform=p,this.encodeFileName=b,this.streamFiles=f,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(v,a),v.prototype.push=function(f){var k=f.meta.percent||0,p=this.entriesCount,b=this._sources.length;this.accumulate?this.contentBuffer.push(f):(this.bytesWritten+=f.data.length,a.prototype.push.call(this,{data:f.data,meta:{currentFile:this.currentFile,percent:p?(k+100*(p-b-1))/p:100}}))},v.prototype.openedSource=function(f){this.currentSourceOffset=this.bytesWritten,this.currentFile=f.file.name;var k=this.streamFiles&&!f.file.dir;if(k){var p=l(f,k,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:p.fileRecord,meta:{percent:0}})}else this.accumulate=!0},v.prototype.closedSource=function(f){this.accumulate=!1;var k=this.streamFiles&&!f.file.dir,p=l(f,k,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(p.dirRecord),k)this.push({data:(function(b){return u.DATA_DESCRIPTOR+s(b.crc32,4)+s(b.compressedSize,4)+s(b.uncompressedSize,4)})(f),meta:{percent:100}});else for(this.push({data:p.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},v.prototype.flush=function(){for(var f=this.bytesWritten,k=0;k<this.dirRecords.length;k++)this.push({data:this.dirRecords[k],meta:{percent:100}});var p=this.bytesWritten-f,b=(function(y,x,_,A,I){var T=r.transformTo("string",I(A));return u.CENTRAL_DIRECTORY_END+"\0\0\0\0"+s(y,2)+s(y,2)+s(x,4)+s(_,4)+s(T.length,2)+T})(this.dirRecords.length,p,f,this.zipComment,this.encodeFileName);this.push({data:b,meta:{percent:100}})},v.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},v.prototype.registerPrevious=function(f){this._sources.push(f);var k=this;return f.on("data",function(p){k.processChunk(p)}),f.on("end",function(){k.closedSource(k.previous.streamInfo),k._sources.length?k.prepareNextSource():k.end()}),f.on("error",function(p){k.error(p)}),this},v.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},v.prototype.error=function(f){var k=this._sources;if(!a.prototype.error.call(this,f))return!1;for(var p=0;p<k.length;p++)try{k[p].error(f)}catch{}return!0},v.prototype.lock=function(){a.prototype.lock.call(this);for(var f=this._sources,k=0;k<f.length;k++)f[k].lock()},n.exports=v},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(e,n,o){var s=e("../compressions"),l=e("./ZipFileWorker");o.generateWorker=function(r,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),u=0;try{r.forEach(function(v,f){u++;var k=(function(x,_){var A=x||_,I=s[A];if(!I)throw new Error(A+" is not a valid compression method !");return I})(f.options.compression,a.compression),p=f.options.compressionOptions||a.compressionOptions||{},b=f.dir,y=f.date;f._compressWorker(k,p).withStreamInfo("file",{name:v,dir:b,date:y,comment:f.comment||"",unixPermissions:f.unixPermissions,dosPermissions:f.dosPermissions}).pipe(d)}),d.entriesCount=u}catch(v){d.error(v)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(e,n,o){function s(){if(!(this instanceof s))return new s;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new s;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(s.prototype=e("./object")).loadAsync=e("./load"),s.support=e("./support"),s.defaults=e("./defaults"),s.version="3.10.1",s.loadAsync=function(l,r){return new s().loadAsync(l,r)},s.external=e("./external"),n.exports=s},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(e,n,o){var s=e("./utils"),l=e("./external"),r=e("./utf8"),a=e("./zipEntries"),c=e("./stream/Crc32Probe"),d=e("./nodejsUtils");function u(v){return new l.Promise(function(f,k){var p=v.decompressed.getContentWorker().pipe(new c);p.on("error",function(b){k(b)}).on("end",function(){p.streamInfo.crc32!==v.decompressed.crc32?k(new Error("Corrupted zip : CRC32 mismatch")):f()}).resume()})}n.exports=function(v,f){var k=this;return f=s.extend(f||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),d.isNode&&d.isStream(v)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):s.prepareContent("the loaded zip file",v,!0,f.optimizedBinaryString,f.base64).then(function(p){var b=new a(f);return b.load(p),b}).then(function(p){var b=[l.Promise.resolve(p)],y=p.files;if(f.checkCRC32)for(var x=0;x<y.length;x++)b.push(u(y[x]));return l.Promise.all(b)}).then(function(p){for(var b=p.shift(),y=b.files,x=0;x<y.length;x++){var _=y[x],A=_.fileNameStr,I=s.resolve(_.fileNameStr);k.file(I,_.decompressed,{binary:!0,optimizedBinaryString:!0,date:_.date,dir:_.dir,comment:_.fileCommentStr.length?_.fileCommentStr:null,unixPermissions:_.unixPermissions,dosPermissions:_.dosPermissions,createFolders:f.createFolders}),_.dir||(k.file(I).unsafeOriginalName=A)}return b.zipComment.length&&(k.comment=b.zipComment),k})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(e,n,o){var s=e("../utils"),l=e("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}s.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(e,n,o){var s=e("readable-stream").Readable;function l(r,a,c){s.call(this,a),this._helper=r;var d=this;r.on("data",function(u,v){d.push(u)||d._helper.pause(),c&&c(v)}).on("error",function(u){d.emit("error",u)}).on("end",function(){d.push(null)})}e("../utils").inherits(l,s),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(e,n,o){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(s,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(s,l);if(typeof s=="number")throw new Error('The "data" argument must not be a number');return new Buffer(s,l)},allocBuffer:function(s){if(Buffer.alloc)return Buffer.alloc(s);var l=new Buffer(s);return l.fill(0),l},isBuffer:function(s){return Buffer.isBuffer(s)},isStream:function(s){return s&&typeof s.on=="function"&&typeof s.pause=="function"&&typeof s.resume=="function"}}},{}],15:[function(e,n,o){function s(I,T,w){var L,B=r.getTypeOf(T),N=r.extend(w||{},d);N.date=N.date||new Date,N.compression!==null&&(N.compression=N.compression.toUpperCase()),typeof N.unixPermissions=="string"&&(N.unixPermissions=parseInt(N.unixPermissions,8)),N.unixPermissions&&16384&N.unixPermissions&&(N.dir=!0),N.dosPermissions&&16&N.dosPermissions&&(N.dir=!0),N.dir&&(I=y(I)),N.createFolders&&(L=b(I))&&x.call(this,L,!0);var Z=B==="string"&&N.binary===!1&&N.base64===!1;w&&w.binary!==void 0||(N.binary=!Z),(T instanceof u&&T.uncompressedSize===0||N.dir||!T||T.length===0)&&(N.base64=!1,N.binary=!0,T="",N.compression="STORE",B="string");var $=null;$=T instanceof u||T instanceof a?T:k.isNode&&k.isStream(T)?new p(I,T):r.prepareContent(I,T,N.binary,N.optimizedBinaryString,N.base64);var U=new v(I,$,N);this.files[I]=U}var l=e("./utf8"),r=e("./utils"),a=e("./stream/GenericWorker"),c=e("./stream/StreamHelper"),d=e("./defaults"),u=e("./compressedObject"),v=e("./zipObject"),f=e("./generate"),k=e("./nodejsUtils"),p=e("./nodejs/NodejsStreamInputAdapter"),b=function(I){I.slice(-1)==="/"&&(I=I.substring(0,I.length-1));var T=I.lastIndexOf("/");return 0<T?I.substring(0,T):""},y=function(I){return I.slice(-1)!=="/"&&(I+="/"),I},x=function(I,T){return T=T!==void 0?T:d.createFolders,I=y(I),this.files[I]||s.call(this,I,null,{dir:!0,createFolders:T}),this.files[I]};function _(I){return Object.prototype.toString.call(I)==="[object RegExp]"}var A={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(I){var T,w,L;for(T in this.files)L=this.files[T],(w=T.slice(this.root.length,T.length))&&T.slice(0,this.root.length)===this.root&&I(w,L)},filter:function(I){var T=[];return this.forEach(function(w,L){I(w,L)&&T.push(L)}),T},file:function(I,T,w){if(arguments.length!==1)return I=this.root+I,s.call(this,I,T,w),this;if(_(I)){var L=I;return this.filter(function(N,Z){return!Z.dir&&L.test(N)})}var B=this.files[this.root+I];return B&&!B.dir?B:null},folder:function(I){if(!I)return this;if(_(I))return this.filter(function(B,N){return N.dir&&I.test(B)});var T=this.root+I,w=x.call(this,T),L=this.clone();return L.root=w.name,L},remove:function(I){I=this.root+I;var T=this.files[I];if(T||(I.slice(-1)!=="/"&&(I+="/"),T=this.files[I]),T&&!T.dir)delete this.files[I];else for(var w=this.filter(function(B,N){return N.name.slice(0,I.length)===I}),L=0;L<w.length;L++)delete this.files[w[L].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(I){var T,w={};try{if((w=r.extend(I||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=w.type.toLowerCase(),w.compression=w.compression.toUpperCase(),w.type==="binarystring"&&(w.type="string"),!w.type)throw new Error("No output type specified.");r.checkSupport(w.type),w.platform!=="darwin"&&w.platform!=="freebsd"&&w.platform!=="linux"&&w.platform!=="sunos"||(w.platform="UNIX"),w.platform==="win32"&&(w.platform="DOS");var L=w.comment||this.comment||"";T=f.generateWorker(this,w,L)}catch(B){(T=new a("error")).error(B)}return new c(T,w.type||"string",w.mimeType)},generateAsync:function(I,T){return this.generateInternalStream(I).accumulate(T)},generateNodeStream:function(I,T){return(I=I||{}).type||(I.type="nodebuffer"),this.generateInternalStream(I).toNodejsStream(T)}};n.exports=A},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(e,n,o){n.exports=e("stream")},{stream:void 0}],17:[function(e,n,o){var s=e("./DataReader");function l(r){s.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}e("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),u=r.charCodeAt(3),v=this.length-4;0<=v;--v)if(this.data[v]===a&&this.data[v+1]===c&&this.data[v+2]===d&&this.data[v+3]===u)return v-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),u=r.charCodeAt(3),v=this.readData(4);return a===v[0]&&c===v[1]&&d===v[2]&&u===v[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(e,n,o){var s=e("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return s.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=l},{"../utils":32}],19:[function(e,n,o){var s=e("./Uint8ArrayReader");function l(r){s.call(this,r)}e("../utils").inherits(l,s),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(e,n,o){var s=e("./DataReader");function l(r){s.call(this,r)}e("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(e,n,o){var s=e("./ArrayReader");function l(r){s.call(this,r)}e("../utils").inherits(l,s),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(e,n,o){var s=e("../utils"),l=e("../support"),r=e("./ArrayReader"),a=e("./StringReader"),c=e("./NodeBufferReader"),d=e("./Uint8ArrayReader");n.exports=function(u){var v=s.getTypeOf(u);return s.checkSupport(v),v!=="string"||l.uint8array?v==="nodebuffer"?new c(u):l.uint8array?new d(s.transformTo("uint8array",u)):new r(s.transformTo("array",u)):new a(u)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(e,n,o){o.LOCAL_FILE_HEADER="PK",o.CENTRAL_FILE_HEADER="PK",o.CENTRAL_DIRECTORY_END="PK",o.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",o.ZIP64_CENTRAL_DIRECTORY_END="PK",o.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(e,n,o){var s=e("./GenericWorker"),l=e("../utils");function r(a){s.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,s),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(e,n,o){var s=e("./GenericWorker"),l=e("../crc32");function r(){s.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}e("../utils").inherits(r,s),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(e,n,o){var s=e("../utils"),l=e("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}s.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(e,n,o){var s=e("../utils"),l=e("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=s.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}s.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,s.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(s.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(e,n,o){function s(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}s.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=s},{}],29:[function(e,n,o){var s=e("../utils"),l=e("./ConvertWorker"),r=e("./GenericWorker"),a=e("../base64"),c=e("../support"),d=e("../external"),u=null;if(c.nodestream)try{u=e("../nodejs/NodejsStreamOutputAdapter")}catch{}function v(k,p){return new d.Promise(function(b,y){var x=[],_=k._internalType,A=k._outputType,I=k._mimeType;k.on("data",function(T,w){x.push(T),p&&p(w)}).on("error",function(T){x=[],y(T)}).on("end",function(){try{var T=(function(w,L,B){switch(w){case"blob":return s.newBlob(s.transformTo("arraybuffer",L),B);case"base64":return a.encode(L);default:return s.transformTo(w,L)}})(A,(function(w,L){var B,N=0,Z=null,$=0;for(B=0;B<L.length;B++)$+=L[B].length;switch(w){case"string":return L.join("");case"array":return Array.prototype.concat.apply([],L);case"uint8array":for(Z=new Uint8Array($),B=0;B<L.length;B++)Z.set(L[B],N),N+=L[B].length;return Z;case"nodebuffer":return Buffer.concat(L);default:throw new Error("concat : unsupported type '"+w+"'")}})(_,x),I);b(T)}catch(w){y(w)}x=[]}).resume()})}function f(k,p,b){var y=p;switch(p){case"blob":case"arraybuffer":y="uint8array";break;case"base64":y="string"}try{this._internalType=y,this._outputType=p,this._mimeType=b,s.checkSupport(y),this._worker=k.pipe(new l(y)),k.lock()}catch(x){this._worker=new r("error"),this._worker.error(x)}}f.prototype={accumulate:function(k){return v(this,k)},on:function(k,p){var b=this;return k==="data"?this._worker.on(k,function(y){p.call(b,y.data,y.meta)}):this._worker.on(k,function(){s.delay(p,arguments,b)}),this},resume:function(){return s.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(k){if(s.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new u(this,{objectMode:this._outputType!=="nodebuffer"},k)}},n.exports=f},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(e,n,o){if(o.base64=!0,o.array=!0,o.string=!0,o.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",o.nodebuffer=typeof Buffer<"u",o.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")o.blob=!1;else{var s=new ArrayBuffer(0);try{o.blob=new Blob([s],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(s),o.blob=l.getBlob("application/zip").size===0}catch{o.blob=!1}}}try{o.nodestream=!!e("readable-stream").Readable}catch{o.nodestream=!1}},{"readable-stream":16}],31:[function(e,n,o){for(var s=e("./utils"),l=e("./support"),r=e("./nodejsUtils"),a=e("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function u(){a.call(this,"utf-8 decode"),this.leftOver=null}function v(){a.call(this,"utf-8 encode")}o.utf8encode=function(f){return l.nodebuffer?r.newBufferFrom(f,"utf-8"):(function(k){var p,b,y,x,_,A=k.length,I=0;for(x=0;x<A;x++)(64512&(b=k.charCodeAt(x)))==55296&&x+1<A&&(64512&(y=k.charCodeAt(x+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),x++),I+=b<128?1:b<2048?2:b<65536?3:4;for(p=l.uint8array?new Uint8Array(I):new Array(I),x=_=0;_<I;x++)(64512&(b=k.charCodeAt(x)))==55296&&x+1<A&&(64512&(y=k.charCodeAt(x+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),x++),b<128?p[_++]=b:(b<2048?p[_++]=192|b>>>6:(b<65536?p[_++]=224|b>>>12:(p[_++]=240|b>>>18,p[_++]=128|b>>>12&63),p[_++]=128|b>>>6&63),p[_++]=128|63&b);return p})(f)},o.utf8decode=function(f){return l.nodebuffer?s.transformTo("nodebuffer",f).toString("utf-8"):(function(k){var p,b,y,x,_=k.length,A=new Array(2*_);for(p=b=0;p<_;)if((y=k[p++])<128)A[b++]=y;else if(4<(x=c[y]))A[b++]=65533,p+=x-1;else{for(y&=x===2?31:x===3?15:7;1<x&&p<_;)y=y<<6|63&k[p++],x--;1<x?A[b++]=65533:y<65536?A[b++]=y:(y-=65536,A[b++]=55296|y>>10&1023,A[b++]=56320|1023&y)}return A.length!==b&&(A.subarray?A=A.subarray(0,b):A.length=b),s.applyFromCharCode(A)})(f=s.transformTo(l.uint8array?"uint8array":"array",f))},s.inherits(u,a),u.prototype.processChunk=function(f){var k=s.transformTo(l.uint8array?"uint8array":"array",f.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var p=k;(k=new Uint8Array(p.length+this.leftOver.length)).set(this.leftOver,0),k.set(p,this.leftOver.length)}else k=this.leftOver.concat(k);this.leftOver=null}var b=(function(x,_){var A;for((_=_||x.length)>x.length&&(_=x.length),A=_-1;0<=A&&(192&x[A])==128;)A--;return A<0||A===0?_:A+c[x[A]]>_?A:_})(k),y=k;b!==k.length&&(l.uint8array?(y=k.subarray(0,b),this.leftOver=k.subarray(b,k.length)):(y=k.slice(0,b),this.leftOver=k.slice(b,k.length))),this.push({data:o.utf8decode(y),meta:f.meta})},u.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:o.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},o.Utf8DecodeWorker=u,s.inherits(v,a),v.prototype.processChunk=function(f){this.push({data:o.utf8encode(f.data),meta:f.meta})},o.Utf8EncodeWorker=v},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(e,n,o){var s=e("./support"),l=e("./base64"),r=e("./nodejsUtils"),a=e("./external");function c(p){return p}function d(p,b){for(var y=0;y<p.length;++y)b[y]=255&p.charCodeAt(y);return b}e("setimmediate"),o.newBlob=function(p,b){o.checkSupport("blob");try{return new Blob([p],{type:b})}catch{try{var y=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return y.append(p),y.getBlob(b)}catch{throw new Error("Bug : can't construct the Blob.")}}};var u={stringifyByChunk:function(p,b,y){var x=[],_=0,A=p.length;if(A<=y)return String.fromCharCode.apply(null,p);for(;_<A;)b==="array"||b==="nodebuffer"?x.push(String.fromCharCode.apply(null,p.slice(_,Math.min(_+y,A)))):x.push(String.fromCharCode.apply(null,p.subarray(_,Math.min(_+y,A)))),_+=y;return x.join("")},stringifyByChar:function(p){for(var b="",y=0;y<p.length;y++)b+=String.fromCharCode(p[y]);return b},applyCanBeUsed:{uint8array:(function(){try{return s.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return s.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function v(p){var b=65536,y=o.getTypeOf(p),x=!0;if(y==="uint8array"?x=u.applyCanBeUsed.uint8array:y==="nodebuffer"&&(x=u.applyCanBeUsed.nodebuffer),x)for(;1<b;)try{return u.stringifyByChunk(p,y,b)}catch{b=Math.floor(b/2)}return u.stringifyByChar(p)}function f(p,b){for(var y=0;y<p.length;y++)b[y]=p[y];return b}o.applyFromCharCode=v;var k={};k.string={string:c,array:function(p){return d(p,new Array(p.length))},arraybuffer:function(p){return k.string.uint8array(p).buffer},uint8array:function(p){return d(p,new Uint8Array(p.length))},nodebuffer:function(p){return d(p,r.allocBuffer(p.length))}},k.array={string:v,array:c,arraybuffer:function(p){return new Uint8Array(p).buffer},uint8array:function(p){return new Uint8Array(p)},nodebuffer:function(p){return r.newBufferFrom(p)}},k.arraybuffer={string:function(p){return v(new Uint8Array(p))},array:function(p){return f(new Uint8Array(p),new Array(p.byteLength))},arraybuffer:c,uint8array:function(p){return new Uint8Array(p)},nodebuffer:function(p){return r.newBufferFrom(new Uint8Array(p))}},k.uint8array={string:v,array:function(p){return f(p,new Array(p.length))},arraybuffer:function(p){return p.buffer},uint8array:c,nodebuffer:function(p){return r.newBufferFrom(p)}},k.nodebuffer={string:v,array:function(p){return f(p,new Array(p.length))},arraybuffer:function(p){return k.nodebuffer.uint8array(p).buffer},uint8array:function(p){return f(p,new Uint8Array(p.length))},nodebuffer:c},o.transformTo=function(p,b){if(b=b||"",!p)return b;o.checkSupport(p);var y=o.getTypeOf(b);return k[y][p](b)},o.resolve=function(p){for(var b=p.split("/"),y=[],x=0;x<b.length;x++){var _=b[x];_==="."||_===""&&x!==0&&x!==b.length-1||(_===".."?y.pop():y.push(_))}return y.join("/")},o.getTypeOf=function(p){return typeof p=="string"?"string":Object.prototype.toString.call(p)==="[object Array]"?"array":s.nodebuffer&&r.isBuffer(p)?"nodebuffer":s.uint8array&&p instanceof Uint8Array?"uint8array":s.arraybuffer&&p instanceof ArrayBuffer?"arraybuffer":void 0},o.checkSupport=function(p){if(!s[p.toLowerCase()])throw new Error(p+" is not supported by this platform")},o.MAX_VALUE_16BITS=65535,o.MAX_VALUE_32BITS=-1,o.pretty=function(p){var b,y,x="";for(y=0;y<(p||"").length;y++)x+="\\x"+((b=p.charCodeAt(y))<16?"0":"")+b.toString(16).toUpperCase();return x},o.delay=function(p,b,y){setImmediate(function(){p.apply(y||null,b||[])})},o.inherits=function(p,b){function y(){}y.prototype=b.prototype,p.prototype=new y},o.extend=function(){var p,b,y={};for(p=0;p<arguments.length;p++)for(b in arguments[p])Object.prototype.hasOwnProperty.call(arguments[p],b)&&y[b]===void 0&&(y[b]=arguments[p][b]);return y},o.prepareContent=function(p,b,y,x,_){return a.Promise.resolve(b).then(function(A){return s.blob&&(A instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(A))!==-1)&&typeof FileReader<"u"?new a.Promise(function(I,T){var w=new FileReader;w.onload=function(L){I(L.target.result)},w.onerror=function(L){T(L.target.error)},w.readAsArrayBuffer(A)}):A}).then(function(A){var I=o.getTypeOf(A);return I?(I==="arraybuffer"?A=o.transformTo("uint8array",A):I==="string"&&(_?A=l.decode(A):y&&x!==!0&&(A=(function(T){return d(T,s.uint8array?new Uint8Array(T.length):new Array(T.length))})(A))),A):a.Promise.reject(new Error("Can't read the data of '"+p+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(e,n,o){var s=e("./reader/readerFor"),l=e("./utils"),r=e("./signature"),a=e("./zipEntry"),c=e("./support");function d(u){this.files=[],this.loadOptions=u}d.prototype={checkSignature:function(u){if(!this.reader.readAndCheckSignature(u)){this.reader.index-=4;var v=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(v)+", expected "+l.pretty(u)+")")}},isSignature:function(u,v){var f=this.reader.index;this.reader.setIndex(u);var k=this.reader.readString(4)===v;return this.reader.setIndex(f),k},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var u=this.reader.readData(this.zipCommentLength),v=c.uint8array?"uint8array":"array",f=l.transformTo(v,u);this.zipComment=this.loadOptions.decodeFileName(f)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var u,v,f,k=this.zip64EndOfCentralSize-44;0<k;)u=this.reader.readInt(2),v=this.reader.readInt(4),f=this.reader.readData(v),this.zip64ExtensibleData[u]={id:u,length:v,value:f}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var u,v;for(u=0;u<this.files.length;u++)v=this.files[u],this.reader.setIndex(v.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),v.readLocalPart(this.reader),v.handleUTF8(),v.processAttributes()},readCentralDir:function(){var u;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(u=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(u);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var u=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(u<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(u);var v=u;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(u=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(u),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var f=this.centralDirOffset+this.centralDirSize;this.zip64&&(f+=20,f+=12+this.zip64EndOfCentralSize);var k=v-f;if(0<k)this.isSignature(v,r.CENTRAL_FILE_HEADER)||(this.reader.zero=k);else if(k<0)throw new Error("Corrupted zip: missing "+Math.abs(k)+" bytes.")},prepareReader:function(u){this.reader=s(u)},load:function(u){this.prepareReader(u),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(e,n,o){var s=e("./reader/readerFor"),l=e("./utils"),r=e("./compressedObject"),a=e("./crc32"),c=e("./utf8"),d=e("./compressions"),u=e("./support");function v(f,k){this.options=f,this.loadOptions=k}v.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(f){var k,p;if(f.skip(22),this.fileNameLength=f.readInt(2),p=f.readInt(2),this.fileName=f.readData(this.fileNameLength),f.skip(p),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((k=(function(b){for(var y in d)if(Object.prototype.hasOwnProperty.call(d,y)&&d[y].magic===b)return d[y];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,k,f.readData(this.compressedSize))},readCentralPart:function(f){this.versionMadeBy=f.readInt(2),f.skip(2),this.bitFlag=f.readInt(2),this.compressionMethod=f.readString(2),this.date=f.readDate(),this.crc32=f.readInt(4),this.compressedSize=f.readInt(4),this.uncompressedSize=f.readInt(4);var k=f.readInt(2);if(this.extraFieldsLength=f.readInt(2),this.fileCommentLength=f.readInt(2),this.diskNumberStart=f.readInt(2),this.internalFileAttributes=f.readInt(2),this.externalFileAttributes=f.readInt(4),this.localHeaderOffset=f.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");f.skip(k),this.readExtraFields(f),this.parseZIP64ExtraField(f),this.fileComment=f.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var f=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),f==0&&(this.dosPermissions=63&this.externalFileAttributes),f==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var f=s(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=f.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=f.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=f.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=f.readInt(4))}},readExtraFields:function(f){var k,p,b,y=f.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});f.index+4<y;)k=f.readInt(2),p=f.readInt(2),b=f.readData(p),this.extraFields[k]={id:k,length:p,value:b};f.setIndex(y)},handleUTF8:function(){var f=u.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var k=this.findExtraFieldUnicodePath();if(k!==null)this.fileNameStr=k;else{var p=l.transformTo(f,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(p)}var b=this.findExtraFieldUnicodeComment();if(b!==null)this.fileCommentStr=b;else{var y=l.transformTo(f,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(y)}}},findExtraFieldUnicodePath:function(){var f=this.extraFields[28789];if(f){var k=s(f.value);return k.readInt(1)!==1||a(this.fileName)!==k.readInt(4)?null:c.utf8decode(k.readData(f.length-5))}return null},findExtraFieldUnicodeComment:function(){var f=this.extraFields[25461];if(f){var k=s(f.value);return k.readInt(1)!==1||a(this.fileComment)!==k.readInt(4)?null:c.utf8decode(k.readData(f.length-5))}return null}},n.exports=v},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(e,n,o){function s(k,p,b){this.name=k,this.dir=b.dir,this.date=b.date,this.comment=b.comment,this.unixPermissions=b.unixPermissions,this.dosPermissions=b.dosPermissions,this._data=p,this._dataBinary=b.binary,this.options={compression:b.compression,compressionOptions:b.compressionOptions}}var l=e("./stream/StreamHelper"),r=e("./stream/DataWorker"),a=e("./utf8"),c=e("./compressedObject"),d=e("./stream/GenericWorker");s.prototype={internalStream:function(k){var p=null,b="string";try{if(!k)throw new Error("No output type specified.");var y=(b=k.toLowerCase())==="string"||b==="text";b!=="binarystring"&&b!=="text"||(b="string"),p=this._decompressWorker();var x=!this._dataBinary;x&&!y&&(p=p.pipe(new a.Utf8EncodeWorker)),!x&&y&&(p=p.pipe(new a.Utf8DecodeWorker))}catch(_){(p=new d("error")).error(_)}return new l(p,b,"")},async:function(k,p){return this.internalStream(k).accumulate(p)},nodeStream:function(k,p){return this.internalStream(k||"nodebuffer").toNodejsStream(p)},_compressWorker:function(k,p){if(this._data instanceof c&&this._data.compression.magic===k.magic)return this._data.getCompressedWorker();var b=this._decompressWorker();return this._dataBinary||(b=b.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(b,k,p)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new r(this._data)}};for(var u=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],v=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},f=0;f<u.length;f++)s.prototype[u[f]]=v;n.exports=s},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(e,n,o){(function(s){var l,r,a=s.MutationObserver||s.WebKitMutationObserver;if(a){var c=0,d=new a(k),u=s.document.createTextNode("");d.observe(u,{characterData:!0}),l=function(){u.data=c=++c%2}}else if(s.setImmediate||s.MessageChannel===void 0)l="document"in s&&"onreadystatechange"in s.document.createElement("script")?function(){var p=s.document.createElement("script");p.onreadystatechange=function(){k(),p.onreadystatechange=null,p.parentNode.removeChild(p),p=null},s.document.documentElement.appendChild(p)}:function(){setTimeout(k,0)};else{var v=new s.MessageChannel;v.port1.onmessage=k,l=function(){v.port2.postMessage(0)}}var f=[];function k(){var p,b;r=!0;for(var y=f.length;y;){for(b=f,f=[],p=-1;++p<y;)b[p]();y=f.length}r=!1}n.exports=function(p){f.push(p)!==1||r||l()}}).call(this,typeof Wn<"u"?Wn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(e,n,o){var s=e("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function u(y){if(typeof y!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,y!==l&&p(this,y)}function v(y,x,_){this.promise=y,typeof x=="function"&&(this.onFulfilled=x,this.callFulfilled=this.otherCallFulfilled),typeof _=="function"&&(this.onRejected=_,this.callRejected=this.otherCallRejected)}function f(y,x,_){s(function(){var A;try{A=x(_)}catch(I){return r.reject(y,I)}A===y?r.reject(y,new TypeError("Cannot resolve promise with itself")):r.resolve(y,A)})}function k(y){var x=y&&y.then;if(y&&(typeof y=="object"||typeof y=="function")&&typeof x=="function")return function(){x.apply(y,arguments)}}function p(y,x){var _=!1;function A(w){_||(_=!0,r.reject(y,w))}function I(w){_||(_=!0,r.resolve(y,w))}var T=b(function(){x(I,A)});T.status==="error"&&A(T.value)}function b(y,x){var _={};try{_.value=y(x),_.status="success"}catch(A){_.status="error",_.value=A}return _}(n.exports=u).prototype.finally=function(y){if(typeof y!="function")return this;var x=this.constructor;return this.then(function(_){return x.resolve(y()).then(function(){return _})},function(_){return x.resolve(y()).then(function(){throw _})})},u.prototype.catch=function(y){return this.then(null,y)},u.prototype.then=function(y,x){if(typeof y!="function"&&this.state===c||typeof x!="function"&&this.state===a)return this;var _=new this.constructor(l);return this.state!==d?f(_,this.state===c?y:x,this.outcome):this.queue.push(new v(_,y,x)),_},v.prototype.callFulfilled=function(y){r.resolve(this.promise,y)},v.prototype.otherCallFulfilled=function(y){f(this.promise,this.onFulfilled,y)},v.prototype.callRejected=function(y){r.reject(this.promise,y)},v.prototype.otherCallRejected=function(y){f(this.promise,this.onRejected,y)},r.resolve=function(y,x){var _=b(k,x);if(_.status==="error")return r.reject(y,_.value);var A=_.value;if(A)p(y,A);else{y.state=c,y.outcome=x;for(var I=-1,T=y.queue.length;++I<T;)y.queue[I].callFulfilled(x)}return y},r.reject=function(y,x){y.state=a,y.outcome=x;for(var _=-1,A=y.queue.length;++_<A;)y.queue[_].callRejected(x);return y},u.resolve=function(y){return y instanceof this?y:r.resolve(new this(l),y)},u.reject=function(y){var x=new this(l);return r.reject(x,y)},u.all=function(y){var x=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var _=y.length,A=!1;if(!_)return this.resolve([]);for(var I=new Array(_),T=0,w=-1,L=new this(l);++w<_;)B(y[w],w);return L;function B(N,Z){x.resolve(N).then(function($){I[Z]=$,++T!==_||A||(A=!0,r.resolve(L,I))},function($){A||(A=!0,r.reject(L,$))})}},u.race=function(y){var x=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var _=y.length,A=!1;if(!_)return this.resolve([]);for(var I=-1,T=new this(l);++I<_;)w=y[I],x.resolve(w).then(function(L){A||(A=!0,r.resolve(T,L))},function(L){A||(A=!0,r.reject(T,L))});var w;return T}},{immediate:36}],38:[function(e,n,o){var s={};(0,e("./lib/utils/common").assign)(s,e("./lib/deflate"),e("./lib/inflate"),e("./lib/zlib/constants")),n.exports=s},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(e,n,o){var s=e("./zlib/deflate"),l=e("./utils/common"),r=e("./utils/strings"),a=e("./zlib/messages"),c=e("./zlib/zstream"),d=Object.prototype.toString,u=0,v=-1,f=0,k=8;function p(y){if(!(this instanceof p))return new p(y);this.options=l.assign({level:v,method:k,chunkSize:16384,windowBits:15,memLevel:8,strategy:f,to:""},y||{});var x=this.options;x.raw&&0<x.windowBits?x.windowBits=-x.windowBits:x.gzip&&0<x.windowBits&&x.windowBits<16&&(x.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var _=s.deflateInit2(this.strm,x.level,x.method,x.windowBits,x.memLevel,x.strategy);if(_!==u)throw new Error(a[_]);if(x.header&&s.deflateSetHeader(this.strm,x.header),x.dictionary){var A;if(A=typeof x.dictionary=="string"?r.string2buf(x.dictionary):d.call(x.dictionary)==="[object ArrayBuffer]"?new Uint8Array(x.dictionary):x.dictionary,(_=s.deflateSetDictionary(this.strm,A))!==u)throw new Error(a[_]);this._dict_set=!0}}function b(y,x){var _=new p(x);if(_.push(y,!0),_.err)throw _.msg||a[_.err];return _.result}p.prototype.push=function(y,x){var _,A,I=this.strm,T=this.options.chunkSize;if(this.ended)return!1;A=x===~~x?x:x===!0?4:0,typeof y=="string"?I.input=r.string2buf(y):d.call(y)==="[object ArrayBuffer]"?I.input=new Uint8Array(y):I.input=y,I.next_in=0,I.avail_in=I.input.length;do{if(I.avail_out===0&&(I.output=new l.Buf8(T),I.next_out=0,I.avail_out=T),(_=s.deflate(I,A))!==1&&_!==u)return this.onEnd(_),!(this.ended=!0);I.avail_out!==0&&(I.avail_in!==0||A!==4&&A!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(I.output,I.next_out))):this.onData(l.shrinkBuf(I.output,I.next_out)))}while((0<I.avail_in||I.avail_out===0)&&_!==1);return A===4?(_=s.deflateEnd(this.strm),this.onEnd(_),this.ended=!0,_===u):A!==2||(this.onEnd(u),!(I.avail_out=0))},p.prototype.onData=function(y){this.chunks.push(y)},p.prototype.onEnd=function(y){y===u&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=y,this.msg=this.strm.msg},o.Deflate=p,o.deflate=b,o.deflateRaw=function(y,x){return(x=x||{}).raw=!0,b(y,x)},o.gzip=function(y,x){return(x=x||{}).gzip=!0,b(y,x)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(e,n,o){var s=e("./zlib/inflate"),l=e("./utils/common"),r=e("./utils/strings"),a=e("./zlib/constants"),c=e("./zlib/messages"),d=e("./zlib/zstream"),u=e("./zlib/gzheader"),v=Object.prototype.toString;function f(p){if(!(this instanceof f))return new f(p);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},p||{});var b=this.options;b.raw&&0<=b.windowBits&&b.windowBits<16&&(b.windowBits=-b.windowBits,b.windowBits===0&&(b.windowBits=-15)),!(0<=b.windowBits&&b.windowBits<16)||p&&p.windowBits||(b.windowBits+=32),15<b.windowBits&&b.windowBits<48&&(15&b.windowBits)==0&&(b.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var y=s.inflateInit2(this.strm,b.windowBits);if(y!==a.Z_OK)throw new Error(c[y]);this.header=new u,s.inflateGetHeader(this.strm,this.header)}function k(p,b){var y=new f(b);if(y.push(p,!0),y.err)throw y.msg||c[y.err];return y.result}f.prototype.push=function(p,b){var y,x,_,A,I,T,w=this.strm,L=this.options.chunkSize,B=this.options.dictionary,N=!1;if(this.ended)return!1;x=b===~~b?b:b===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof p=="string"?w.input=r.binstring2buf(p):v.call(p)==="[object ArrayBuffer]"?w.input=new Uint8Array(p):w.input=p,w.next_in=0,w.avail_in=w.input.length;do{if(w.avail_out===0&&(w.output=new l.Buf8(L),w.next_out=0,w.avail_out=L),(y=s.inflate(w,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&B&&(T=typeof B=="string"?r.string2buf(B):v.call(B)==="[object ArrayBuffer]"?new Uint8Array(B):B,y=s.inflateSetDictionary(this.strm,T)),y===a.Z_BUF_ERROR&&N===!0&&(y=a.Z_OK,N=!1),y!==a.Z_STREAM_END&&y!==a.Z_OK)return this.onEnd(y),!(this.ended=!0);w.next_out&&(w.avail_out!==0&&y!==a.Z_STREAM_END&&(w.avail_in!==0||x!==a.Z_FINISH&&x!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(_=r.utf8border(w.output,w.next_out),A=w.next_out-_,I=r.buf2string(w.output,_),w.next_out=A,w.avail_out=L-A,A&&l.arraySet(w.output,w.output,_,A,0),this.onData(I)):this.onData(l.shrinkBuf(w.output,w.next_out)))),w.avail_in===0&&w.avail_out===0&&(N=!0)}while((0<w.avail_in||w.avail_out===0)&&y!==a.Z_STREAM_END);return y===a.Z_STREAM_END&&(x=a.Z_FINISH),x===a.Z_FINISH?(y=s.inflateEnd(this.strm),this.onEnd(y),this.ended=!0,y===a.Z_OK):x!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(w.avail_out=0))},f.prototype.onData=function(p){this.chunks.push(p)},f.prototype.onEnd=function(p){p===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=p,this.msg=this.strm.msg},o.Inflate=f,o.inflate=k,o.inflateRaw=function(p,b){return(b=b||{}).raw=!0,k(p,b)},o.ungzip=k},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(e,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";o.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var u in d)d.hasOwnProperty(u)&&(a[u]=d[u])}}return a},o.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,u,v){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+u),v);else for(var f=0;f<u;f++)a[v+f]=c[d+f]},flattenChunks:function(a){var c,d,u,v,f,k;for(c=u=0,d=a.length;c<d;c++)u+=a[c].length;for(k=new Uint8Array(u),c=v=0,d=a.length;c<d;c++)f=a[c],k.set(f,v),v+=f.length;return k}},r={arraySet:function(a,c,d,u,v){for(var f=0;f<u;f++)a[v+f]=c[d+f]},flattenChunks:function(a){return[].concat.apply([],a)}};o.setTyped=function(a){a?(o.Buf8=Uint8Array,o.Buf16=Uint16Array,o.Buf32=Int32Array,o.assign(o,l)):(o.Buf8=Array,o.Buf16=Array,o.Buf32=Array,o.assign(o,r))},o.setTyped(s)},{}],42:[function(e,n,o){var s=e("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new s.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(u,v){if(v<65537&&(u.subarray&&r||!u.subarray&&l))return String.fromCharCode.apply(null,s.shrinkBuf(u,v));for(var f="",k=0;k<v;k++)f+=String.fromCharCode(u[k]);return f}a[254]=a[254]=1,o.string2buf=function(u){var v,f,k,p,b,y=u.length,x=0;for(p=0;p<y;p++)(64512&(f=u.charCodeAt(p)))==55296&&p+1<y&&(64512&(k=u.charCodeAt(p+1)))==56320&&(f=65536+(f-55296<<10)+(k-56320),p++),x+=f<128?1:f<2048?2:f<65536?3:4;for(v=new s.Buf8(x),p=b=0;b<x;p++)(64512&(f=u.charCodeAt(p)))==55296&&p+1<y&&(64512&(k=u.charCodeAt(p+1)))==56320&&(f=65536+(f-55296<<10)+(k-56320),p++),f<128?v[b++]=f:(f<2048?v[b++]=192|f>>>6:(f<65536?v[b++]=224|f>>>12:(v[b++]=240|f>>>18,v[b++]=128|f>>>12&63),v[b++]=128|f>>>6&63),v[b++]=128|63&f);return v},o.buf2binstring=function(u){return d(u,u.length)},o.binstring2buf=function(u){for(var v=new s.Buf8(u.length),f=0,k=v.length;f<k;f++)v[f]=u.charCodeAt(f);return v},o.buf2string=function(u,v){var f,k,p,b,y=v||u.length,x=new Array(2*y);for(f=k=0;f<y;)if((p=u[f++])<128)x[k++]=p;else if(4<(b=a[p]))x[k++]=65533,f+=b-1;else{for(p&=b===2?31:b===3?15:7;1<b&&f<y;)p=p<<6|63&u[f++],b--;1<b?x[k++]=65533:p<65536?x[k++]=p:(p-=65536,x[k++]=55296|p>>10&1023,x[k++]=56320|1023&p)}return d(x,k)},o.utf8border=function(u,v){var f;for((v=v||u.length)>u.length&&(v=u.length),f=v-1;0<=f&&(192&u[f])==128;)f--;return f<0||f===0?v:f+a[u[f]]>v?f:v}},{"./common":41}],43:[function(e,n,o){n.exports=function(s,l,r,a){for(var c=65535&s|0,d=s>>>16&65535|0,u=0;r!==0;){for(r-=u=2e3<r?2e3:r;d=d+(c=c+l[a++]|0)|0,--u;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(e,n,o){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(e,n,o){var s=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();n.exports=function(l,r,a,c){var d=s,u=c+a;l^=-1;for(var v=c;v<u;v++)l=l>>>8^d[255&(l^r[v])];return-1^l}},{}],46:[function(e,n,o){var s,l=e("../utils/common"),r=e("./trees"),a=e("./adler32"),c=e("./crc32"),d=e("./messages"),u=0,v=4,f=0,k=-2,p=-1,b=4,y=2,x=8,_=9,A=286,I=30,T=19,w=2*A+1,L=15,B=3,N=258,Z=N+B+1,$=42,U=113,m=1,K=2,E=3,M=4;function F(h,H){return h.msg=d[H],H}function O(h){return(h<<1)-(4<h?9:0)}function J(h){for(var H=h.length;0<=--H;)h[H]=0}function j(h){var H=h.state,P=H.pending;P>h.avail_out&&(P=h.avail_out),P!==0&&(l.arraySet(h.output,H.pending_buf,H.pending_out,P,h.next_out),h.next_out+=P,H.pending_out+=P,h.total_out+=P,h.avail_out-=P,H.pending-=P,H.pending===0&&(H.pending_out=0))}function q(h,H){r._tr_flush_block(h,0<=h.block_start?h.block_start:-1,h.strstart-h.block_start,H),h.block_start=h.strstart,j(h.strm)}function rt(h,H){h.pending_buf[h.pending++]=H}function lt(h,H){h.pending_buf[h.pending++]=H>>>8&255,h.pending_buf[h.pending++]=255&H}function st(h,H){var P,S,C=h.max_chain_length,R=h.strstart,G=h.prev_length,W=h.nice_match,V=h.strstart>h.w_size-Z?h.strstart-(h.w_size-Z):0,Y=h.window,ot=h.w_mask,it=h.prev,at=h.strstart+N,St=Y[R+G-1],kt=Y[R+G];h.prev_length>=h.good_match&&(C>>=2),W>h.lookahead&&(W=h.lookahead);do if(Y[(P=H)+G]===kt&&Y[P+G-1]===St&&Y[P]===Y[R]&&Y[++P]===Y[R+1]){R+=2,P++;do;while(Y[++R]===Y[++P]&&Y[++R]===Y[++P]&&Y[++R]===Y[++P]&&Y[++R]===Y[++P]&&Y[++R]===Y[++P]&&Y[++R]===Y[++P]&&Y[++R]===Y[++P]&&Y[++R]===Y[++P]&&R<at);if(S=N-(at-R),R=at-N,G<S){if(h.match_start=H,W<=(G=S))break;St=Y[R+G-1],kt=Y[R+G]}}while((H=it[H&ot])>V&&--C!=0);return G<=h.lookahead?G:h.lookahead}function Q(h){var H,P,S,C,R,G,W,V,Y,ot,it=h.w_size;do{if(C=h.window_size-h.lookahead-h.strstart,h.strstart>=it+(it-Z)){for(l.arraySet(h.window,h.window,it,it,0),h.match_start-=it,h.strstart-=it,h.block_start-=it,H=P=h.hash_size;S=h.head[--H],h.head[H]=it<=S?S-it:0,--P;);for(H=P=it;S=h.prev[--H],h.prev[H]=it<=S?S-it:0,--P;);C+=it}if(h.strm.avail_in===0)break;if(G=h.strm,W=h.window,V=h.strstart+h.lookahead,Y=C,ot=void 0,ot=G.avail_in,Y<ot&&(ot=Y),P=ot===0?0:(G.avail_in-=ot,l.arraySet(W,G.input,G.next_in,ot,V),G.state.wrap===1?G.adler=a(G.adler,W,ot,V):G.state.wrap===2&&(G.adler=c(G.adler,W,ot,V)),G.next_in+=ot,G.total_in+=ot,ot),h.lookahead+=P,h.lookahead+h.insert>=B)for(R=h.strstart-h.insert,h.ins_h=h.window[R],h.ins_h=(h.ins_h<<h.hash_shift^h.window[R+1])&h.hash_mask;h.insert&&(h.ins_h=(h.ins_h<<h.hash_shift^h.window[R+B-1])&h.hash_mask,h.prev[R&h.w_mask]=h.head[h.ins_h],h.head[h.ins_h]=R,R++,h.insert--,!(h.lookahead+h.insert<B)););}while(h.lookahead<Z&&h.strm.avail_in!==0)}function pt(h,H){for(var P,S;;){if(h.lookahead<Z){if(Q(h),h.lookahead<Z&&H===u)return m;if(h.lookahead===0)break}if(P=0,h.lookahead>=B&&(h.ins_h=(h.ins_h<<h.hash_shift^h.window[h.strstart+B-1])&h.hash_mask,P=h.prev[h.strstart&h.w_mask]=h.head[h.ins_h],h.head[h.ins_h]=h.strstart),P!==0&&h.strstart-P<=h.w_size-Z&&(h.match_length=st(h,P)),h.match_length>=B)if(S=r._tr_tally(h,h.strstart-h.match_start,h.match_length-B),h.lookahead-=h.match_length,h.match_length<=h.max_lazy_match&&h.lookahead>=B){for(h.match_length--;h.strstart++,h.ins_h=(h.ins_h<<h.hash_shift^h.window[h.strstart+B-1])&h.hash_mask,P=h.prev[h.strstart&h.w_mask]=h.head[h.ins_h],h.head[h.ins_h]=h.strstart,--h.match_length!=0;);h.strstart++}else h.strstart+=h.match_length,h.match_length=0,h.ins_h=h.window[h.strstart],h.ins_h=(h.ins_h<<h.hash_shift^h.window[h.strstart+1])&h.hash_mask;else S=r._tr_tally(h,0,h.window[h.strstart]),h.lookahead--,h.strstart++;if(S&&(q(h,!1),h.strm.avail_out===0))return m}return h.insert=h.strstart<B-1?h.strstart:B-1,H===v?(q(h,!0),h.strm.avail_out===0?E:M):h.last_lit&&(q(h,!1),h.strm.avail_out===0)?m:K}function bt(h,H){for(var P,S,C;;){if(h.lookahead<Z){if(Q(h),h.lookahead<Z&&H===u)return m;if(h.lookahead===0)break}if(P=0,h.lookahead>=B&&(h.ins_h=(h.ins_h<<h.hash_shift^h.window[h.strstart+B-1])&h.hash_mask,P=h.prev[h.strstart&h.w_mask]=h.head[h.ins_h],h.head[h.ins_h]=h.strstart),h.prev_length=h.match_length,h.prev_match=h.match_start,h.match_length=B-1,P!==0&&h.prev_length<h.max_lazy_match&&h.strstart-P<=h.w_size-Z&&(h.match_length=st(h,P),h.match_length<=5&&(h.strategy===1||h.match_length===B&&4096<h.strstart-h.match_start)&&(h.match_length=B-1)),h.prev_length>=B&&h.match_length<=h.prev_length){for(C=h.strstart+h.lookahead-B,S=r._tr_tally(h,h.strstart-1-h.prev_match,h.prev_length-B),h.lookahead-=h.prev_length-1,h.prev_length-=2;++h.strstart<=C&&(h.ins_h=(h.ins_h<<h.hash_shift^h.window[h.strstart+B-1])&h.hash_mask,P=h.prev[h.strstart&h.w_mask]=h.head[h.ins_h],h.head[h.ins_h]=h.strstart),--h.prev_length!=0;);if(h.match_available=0,h.match_length=B-1,h.strstart++,S&&(q(h,!1),h.strm.avail_out===0))return m}else if(h.match_available){if((S=r._tr_tally(h,0,h.window[h.strstart-1]))&&q(h,!1),h.strstart++,h.lookahead--,h.strm.avail_out===0)return m}else h.match_available=1,h.strstart++,h.lookahead--}return h.match_available&&(S=r._tr_tally(h,0,h.window[h.strstart-1]),h.match_available=0),h.insert=h.strstart<B-1?h.strstart:B-1,H===v?(q(h,!0),h.strm.avail_out===0?E:M):h.last_lit&&(q(h,!1),h.strm.avail_out===0)?m:K}function X(h,H,P,S,C){this.good_length=h,this.max_lazy=H,this.nice_length=P,this.max_chain=S,this.func=C}function ut(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=x,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*w),this.dyn_dtree=new l.Buf16(2*(2*I+1)),this.bl_tree=new l.Buf16(2*(2*T+1)),J(this.dyn_ltree),J(this.dyn_dtree),J(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(L+1),this.heap=new l.Buf16(2*A+1),J(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*A+1),J(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function vt(h){var H;return h&&h.state?(h.total_in=h.total_out=0,h.data_type=y,(H=h.state).pending=0,H.pending_out=0,H.wrap<0&&(H.wrap=-H.wrap),H.status=H.wrap?$:U,h.adler=H.wrap===2?0:1,H.last_flush=u,r._tr_init(H),f):F(h,k)}function D(h){var H=vt(h);return H===f&&(function(P){P.window_size=2*P.w_size,J(P.head),P.max_lazy_match=s[P.level].max_lazy,P.good_match=s[P.level].good_length,P.nice_match=s[P.level].nice_length,P.max_chain_length=s[P.level].max_chain,P.strstart=0,P.block_start=0,P.lookahead=0,P.insert=0,P.match_length=P.prev_length=B-1,P.match_available=0,P.ins_h=0})(h.state),H}function z(h,H,P,S,C,R){if(!h)return k;var G=1;if(H===p&&(H=6),S<0?(G=0,S=-S):15<S&&(G=2,S-=16),C<1||_<C||P!==x||S<8||15<S||H<0||9<H||R<0||b<R)return F(h,k);S===8&&(S=9);var W=new ut;return(h.state=W).strm=h,W.wrap=G,W.gzhead=null,W.w_bits=S,W.w_size=1<<W.w_bits,W.w_mask=W.w_size-1,W.hash_bits=C+7,W.hash_size=1<<W.hash_bits,W.hash_mask=W.hash_size-1,W.hash_shift=~~((W.hash_bits+B-1)/B),W.window=new l.Buf8(2*W.w_size),W.head=new l.Buf16(W.hash_size),W.prev=new l.Buf16(W.w_size),W.lit_bufsize=1<<C+6,W.pending_buf_size=4*W.lit_bufsize,W.pending_buf=new l.Buf8(W.pending_buf_size),W.d_buf=1*W.lit_bufsize,W.l_buf=3*W.lit_bufsize,W.level=H,W.strategy=R,W.method=P,D(h)}s=[new X(0,0,0,0,function(h,H){var P=65535;for(P>h.pending_buf_size-5&&(P=h.pending_buf_size-5);;){if(h.lookahead<=1){if(Q(h),h.lookahead===0&&H===u)return m;if(h.lookahead===0)break}h.strstart+=h.lookahead,h.lookahead=0;var S=h.block_start+P;if((h.strstart===0||h.strstart>=S)&&(h.lookahead=h.strstart-S,h.strstart=S,q(h,!1),h.strm.avail_out===0)||h.strstart-h.block_start>=h.w_size-Z&&(q(h,!1),h.strm.avail_out===0))return m}return h.insert=0,H===v?(q(h,!0),h.strm.avail_out===0?E:M):(h.strstart>h.block_start&&(q(h,!1),h.strm.avail_out),m)}),new X(4,4,8,4,pt),new X(4,5,16,8,pt),new X(4,6,32,32,pt),new X(4,4,16,16,bt),new X(8,16,32,32,bt),new X(8,16,128,128,bt),new X(8,32,128,256,bt),new X(32,128,258,1024,bt),new X(32,258,258,4096,bt)],o.deflateInit=function(h,H){return z(h,H,x,15,8,0)},o.deflateInit2=z,o.deflateReset=D,o.deflateResetKeep=vt,o.deflateSetHeader=function(h,H){return h&&h.state?h.state.wrap!==2?k:(h.state.gzhead=H,f):k},o.deflate=function(h,H){var P,S,C,R;if(!h||!h.state||5<H||H<0)return h?F(h,k):k;if(S=h.state,!h.output||!h.input&&h.avail_in!==0||S.status===666&&H!==v)return F(h,h.avail_out===0?-5:k);if(S.strm=h,P=S.last_flush,S.last_flush=H,S.status===$)if(S.wrap===2)h.adler=0,rt(S,31),rt(S,139),rt(S,8),S.gzhead?(rt(S,(S.gzhead.text?1:0)+(S.gzhead.hcrc?2:0)+(S.gzhead.extra?4:0)+(S.gzhead.name?8:0)+(S.gzhead.comment?16:0)),rt(S,255&S.gzhead.time),rt(S,S.gzhead.time>>8&255),rt(S,S.gzhead.time>>16&255),rt(S,S.gzhead.time>>24&255),rt(S,S.level===9?2:2<=S.strategy||S.level<2?4:0),rt(S,255&S.gzhead.os),S.gzhead.extra&&S.gzhead.extra.length&&(rt(S,255&S.gzhead.extra.length),rt(S,S.gzhead.extra.length>>8&255)),S.gzhead.hcrc&&(h.adler=c(h.adler,S.pending_buf,S.pending,0)),S.gzindex=0,S.status=69):(rt(S,0),rt(S,0),rt(S,0),rt(S,0),rt(S,0),rt(S,S.level===9?2:2<=S.strategy||S.level<2?4:0),rt(S,3),S.status=U);else{var G=x+(S.w_bits-8<<4)<<8;G|=(2<=S.strategy||S.level<2?0:S.level<6?1:S.level===6?2:3)<<6,S.strstart!==0&&(G|=32),G+=31-G%31,S.status=U,lt(S,G),S.strstart!==0&&(lt(S,h.adler>>>16),lt(S,65535&h.adler)),h.adler=1}if(S.status===69)if(S.gzhead.extra){for(C=S.pending;S.gzindex<(65535&S.gzhead.extra.length)&&(S.pending!==S.pending_buf_size||(S.gzhead.hcrc&&S.pending>C&&(h.adler=c(h.adler,S.pending_buf,S.pending-C,C)),j(h),C=S.pending,S.pending!==S.pending_buf_size));)rt(S,255&S.gzhead.extra[S.gzindex]),S.gzindex++;S.gzhead.hcrc&&S.pending>C&&(h.adler=c(h.adler,S.pending_buf,S.pending-C,C)),S.gzindex===S.gzhead.extra.length&&(S.gzindex=0,S.status=73)}else S.status=73;if(S.status===73)if(S.gzhead.name){C=S.pending;do{if(S.pending===S.pending_buf_size&&(S.gzhead.hcrc&&S.pending>C&&(h.adler=c(h.adler,S.pending_buf,S.pending-C,C)),j(h),C=S.pending,S.pending===S.pending_buf_size)){R=1;break}R=S.gzindex<S.gzhead.name.length?255&S.gzhead.name.charCodeAt(S.gzindex++):0,rt(S,R)}while(R!==0);S.gzhead.hcrc&&S.pending>C&&(h.adler=c(h.adler,S.pending_buf,S.pending-C,C)),R===0&&(S.gzindex=0,S.status=91)}else S.status=91;if(S.status===91)if(S.gzhead.comment){C=S.pending;do{if(S.pending===S.pending_buf_size&&(S.gzhead.hcrc&&S.pending>C&&(h.adler=c(h.adler,S.pending_buf,S.pending-C,C)),j(h),C=S.pending,S.pending===S.pending_buf_size)){R=1;break}R=S.gzindex<S.gzhead.comment.length?255&S.gzhead.comment.charCodeAt(S.gzindex++):0,rt(S,R)}while(R!==0);S.gzhead.hcrc&&S.pending>C&&(h.adler=c(h.adler,S.pending_buf,S.pending-C,C)),R===0&&(S.status=103)}else S.status=103;if(S.status===103&&(S.gzhead.hcrc?(S.pending+2>S.pending_buf_size&&j(h),S.pending+2<=S.pending_buf_size&&(rt(S,255&h.adler),rt(S,h.adler>>8&255),h.adler=0,S.status=U)):S.status=U),S.pending!==0){if(j(h),h.avail_out===0)return S.last_flush=-1,f}else if(h.avail_in===0&&O(H)<=O(P)&&H!==v)return F(h,-5);if(S.status===666&&h.avail_in!==0)return F(h,-5);if(h.avail_in!==0||S.lookahead!==0||H!==u&&S.status!==666){var W=S.strategy===2?(function(V,Y){for(var ot;;){if(V.lookahead===0&&(Q(V),V.lookahead===0)){if(Y===u)return m;break}if(V.match_length=0,ot=r._tr_tally(V,0,V.window[V.strstart]),V.lookahead--,V.strstart++,ot&&(q(V,!1),V.strm.avail_out===0))return m}return V.insert=0,Y===v?(q(V,!0),V.strm.avail_out===0?E:M):V.last_lit&&(q(V,!1),V.strm.avail_out===0)?m:K})(S,H):S.strategy===3?(function(V,Y){for(var ot,it,at,St,kt=V.window;;){if(V.lookahead<=N){if(Q(V),V.lookahead<=N&&Y===u)return m;if(V.lookahead===0)break}if(V.match_length=0,V.lookahead>=B&&0<V.strstart&&(it=kt[at=V.strstart-1])===kt[++at]&&it===kt[++at]&&it===kt[++at]){St=V.strstart+N;do;while(it===kt[++at]&&it===kt[++at]&&it===kt[++at]&&it===kt[++at]&&it===kt[++at]&&it===kt[++at]&&it===kt[++at]&&it===kt[++at]&&at<St);V.match_length=N-(St-at),V.match_length>V.lookahead&&(V.match_length=V.lookahead)}if(V.match_length>=B?(ot=r._tr_tally(V,1,V.match_length-B),V.lookahead-=V.match_length,V.strstart+=V.match_length,V.match_length=0):(ot=r._tr_tally(V,0,V.window[V.strstart]),V.lookahead--,V.strstart++),ot&&(q(V,!1),V.strm.avail_out===0))return m}return V.insert=0,Y===v?(q(V,!0),V.strm.avail_out===0?E:M):V.last_lit&&(q(V,!1),V.strm.avail_out===0)?m:K})(S,H):s[S.level].func(S,H);if(W!==E&&W!==M||(S.status=666),W===m||W===E)return h.avail_out===0&&(S.last_flush=-1),f;if(W===K&&(H===1?r._tr_align(S):H!==5&&(r._tr_stored_block(S,0,0,!1),H===3&&(J(S.head),S.lookahead===0&&(S.strstart=0,S.block_start=0,S.insert=0))),j(h),h.avail_out===0))return S.last_flush=-1,f}return H!==v?f:S.wrap<=0?1:(S.wrap===2?(rt(S,255&h.adler),rt(S,h.adler>>8&255),rt(S,h.adler>>16&255),rt(S,h.adler>>24&255),rt(S,255&h.total_in),rt(S,h.total_in>>8&255),rt(S,h.total_in>>16&255),rt(S,h.total_in>>24&255)):(lt(S,h.adler>>>16),lt(S,65535&h.adler)),j(h),0<S.wrap&&(S.wrap=-S.wrap),S.pending!==0?f:1)},o.deflateEnd=function(h){var H;return h&&h.state?(H=h.state.status)!==$&&H!==69&&H!==73&&H!==91&&H!==103&&H!==U&&H!==666?F(h,k):(h.state=null,H===U?F(h,-3):f):k},o.deflateSetDictionary=function(h,H){var P,S,C,R,G,W,V,Y,ot=H.length;if(!h||!h.state||(R=(P=h.state).wrap)===2||R===1&&P.status!==$||P.lookahead)return k;for(R===1&&(h.adler=a(h.adler,H,ot,0)),P.wrap=0,ot>=P.w_size&&(R===0&&(J(P.head),P.strstart=0,P.block_start=0,P.insert=0),Y=new l.Buf8(P.w_size),l.arraySet(Y,H,ot-P.w_size,P.w_size,0),H=Y,ot=P.w_size),G=h.avail_in,W=h.next_in,V=h.input,h.avail_in=ot,h.next_in=0,h.input=H,Q(P);P.lookahead>=B;){for(S=P.strstart,C=P.lookahead-(B-1);P.ins_h=(P.ins_h<<P.hash_shift^P.window[S+B-1])&P.hash_mask,P.prev[S&P.w_mask]=P.head[P.ins_h],P.head[P.ins_h]=S,S++,--C;);P.strstart=S,P.lookahead=B-1,Q(P)}return P.strstart+=P.lookahead,P.block_start=P.strstart,P.insert=P.lookahead,P.lookahead=0,P.match_length=P.prev_length=B-1,P.match_available=0,h.next_in=W,h.input=V,h.avail_in=G,P.wrap=R,f},o.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(e,n,o){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(e,n,o){n.exports=function(s,l){var r,a,c,d,u,v,f,k,p,b,y,x,_,A,I,T,w,L,B,N,Z,$,U,m,K;r=s.state,a=s.next_in,m=s.input,c=a+(s.avail_in-5),d=s.next_out,K=s.output,u=d-(l-s.avail_out),v=d+(s.avail_out-257),f=r.dmax,k=r.wsize,p=r.whave,b=r.wnext,y=r.window,x=r.hold,_=r.bits,A=r.lencode,I=r.distcode,T=(1<<r.lenbits)-1,w=(1<<r.distbits)-1;t:do{_<15&&(x+=m[a++]<<_,_+=8,x+=m[a++]<<_,_+=8),L=A[x&T];e:for(;;){if(x>>>=B=L>>>24,_-=B,(B=L>>>16&255)===0)K[d++]=65535&L;else{if(!(16&B)){if((64&B)==0){L=A[(65535&L)+(x&(1<<B)-1)];continue e}if(32&B){r.mode=12;break t}s.msg="invalid literal/length code",r.mode=30;break t}N=65535&L,(B&=15)&&(_<B&&(x+=m[a++]<<_,_+=8),N+=x&(1<<B)-1,x>>>=B,_-=B),_<15&&(x+=m[a++]<<_,_+=8,x+=m[a++]<<_,_+=8),L=I[x&w];i:for(;;){if(x>>>=B=L>>>24,_-=B,!(16&(B=L>>>16&255))){if((64&B)==0){L=I[(65535&L)+(x&(1<<B)-1)];continue i}s.msg="invalid distance code",r.mode=30;break t}if(Z=65535&L,_<(B&=15)&&(x+=m[a++]<<_,(_+=8)<B&&(x+=m[a++]<<_,_+=8)),f<(Z+=x&(1<<B)-1)){s.msg="invalid distance too far back",r.mode=30;break t}if(x>>>=B,_-=B,(B=d-u)<Z){if(p<(B=Z-B)&&r.sane){s.msg="invalid distance too far back",r.mode=30;break t}if(U=y,($=0)===b){if($+=k-B,B<N){for(N-=B;K[d++]=y[$++],--B;);$=d-Z,U=K}}else if(b<B){if($+=k+b-B,(B-=b)<N){for(N-=B;K[d++]=y[$++],--B;);if($=0,b<N){for(N-=B=b;K[d++]=y[$++],--B;);$=d-Z,U=K}}}else if($+=b-B,B<N){for(N-=B;K[d++]=y[$++],--B;);$=d-Z,U=K}for(;2<N;)K[d++]=U[$++],K[d++]=U[$++],K[d++]=U[$++],N-=3;N&&(K[d++]=U[$++],1<N&&(K[d++]=U[$++]))}else{for($=d-Z;K[d++]=K[$++],K[d++]=K[$++],K[d++]=K[$++],2<(N-=3););N&&(K[d++]=K[$++],1<N&&(K[d++]=K[$++]))}break}}break}}while(a<c&&d<v);a-=N=_>>3,x&=(1<<(_-=N<<3))-1,s.next_in=a,s.next_out=d,s.avail_in=a<c?c-a+5:5-(a-c),s.avail_out=d<v?v-d+257:257-(d-v),r.hold=x,r.bits=_}},{}],49:[function(e,n,o){var s=e("../utils/common"),l=e("./adler32"),r=e("./crc32"),a=e("./inffast"),c=e("./inftrees"),d=1,u=2,v=0,f=-2,k=1,p=852,b=592;function y($){return($>>>24&255)+($>>>8&65280)+((65280&$)<<8)+((255&$)<<24)}function x(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new s.Buf16(320),this.work=new s.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function _($){var U;return $&&$.state?(U=$.state,$.total_in=$.total_out=U.total=0,$.msg="",U.wrap&&($.adler=1&U.wrap),U.mode=k,U.last=0,U.havedict=0,U.dmax=32768,U.head=null,U.hold=0,U.bits=0,U.lencode=U.lendyn=new s.Buf32(p),U.distcode=U.distdyn=new s.Buf32(b),U.sane=1,U.back=-1,v):f}function A($){var U;return $&&$.state?((U=$.state).wsize=0,U.whave=0,U.wnext=0,_($)):f}function I($,U){var m,K;return $&&$.state?(K=$.state,U<0?(m=0,U=-U):(m=1+(U>>4),U<48&&(U&=15)),U&&(U<8||15<U)?f:(K.window!==null&&K.wbits!==U&&(K.window=null),K.wrap=m,K.wbits=U,A($))):f}function T($,U){var m,K;return $?(K=new x,($.state=K).window=null,(m=I($,U))!==v&&($.state=null),m):f}var w,L,B=!0;function N($){if(B){var U;for(w=new s.Buf32(512),L=new s.Buf32(32),U=0;U<144;)$.lens[U++]=8;for(;U<256;)$.lens[U++]=9;for(;U<280;)$.lens[U++]=7;for(;U<288;)$.lens[U++]=8;for(c(d,$.lens,0,288,w,0,$.work,{bits:9}),U=0;U<32;)$.lens[U++]=5;c(u,$.lens,0,32,L,0,$.work,{bits:5}),B=!1}$.lencode=w,$.lenbits=9,$.distcode=L,$.distbits=5}function Z($,U,m,K){var E,M=$.state;return M.window===null&&(M.wsize=1<<M.wbits,M.wnext=0,M.whave=0,M.window=new s.Buf8(M.wsize)),K>=M.wsize?(s.arraySet(M.window,U,m-M.wsize,M.wsize,0),M.wnext=0,M.whave=M.wsize):(K<(E=M.wsize-M.wnext)&&(E=K),s.arraySet(M.window,U,m-K,E,M.wnext),(K-=E)?(s.arraySet(M.window,U,m-K,K,0),M.wnext=K,M.whave=M.wsize):(M.wnext+=E,M.wnext===M.wsize&&(M.wnext=0),M.whave<M.wsize&&(M.whave+=E))),0}o.inflateReset=A,o.inflateReset2=I,o.inflateResetKeep=_,o.inflateInit=function($){return T($,15)},o.inflateInit2=T,o.inflate=function($,U){var m,K,E,M,F,O,J,j,q,rt,lt,st,Q,pt,bt,X,ut,vt,D,z,h,H,P,S,C=0,R=new s.Buf8(4),G=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!$||!$.state||!$.output||!$.input&&$.avail_in!==0)return f;(m=$.state).mode===12&&(m.mode=13),F=$.next_out,E=$.output,J=$.avail_out,M=$.next_in,K=$.input,O=$.avail_in,j=m.hold,q=m.bits,rt=O,lt=J,H=v;t:for(;;)switch(m.mode){case k:if(m.wrap===0){m.mode=13;break}for(;q<16;){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}if(2&m.wrap&&j===35615){R[m.check=0]=255&j,R[1]=j>>>8&255,m.check=r(m.check,R,2,0),q=j=0,m.mode=2;break}if(m.flags=0,m.head&&(m.head.done=!1),!(1&m.wrap)||(((255&j)<<8)+(j>>8))%31){$.msg="incorrect header check",m.mode=30;break}if((15&j)!=8){$.msg="unknown compression method",m.mode=30;break}if(q-=4,h=8+(15&(j>>>=4)),m.wbits===0)m.wbits=h;else if(h>m.wbits){$.msg="invalid window size",m.mode=30;break}m.dmax=1<<h,$.adler=m.check=1,m.mode=512&j?10:12,q=j=0;break;case 2:for(;q<16;){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}if(m.flags=j,(255&m.flags)!=8){$.msg="unknown compression method",m.mode=30;break}if(57344&m.flags){$.msg="unknown header flags set",m.mode=30;break}m.head&&(m.head.text=j>>8&1),512&m.flags&&(R[0]=255&j,R[1]=j>>>8&255,m.check=r(m.check,R,2,0)),q=j=0,m.mode=3;case 3:for(;q<32;){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}m.head&&(m.head.time=j),512&m.flags&&(R[0]=255&j,R[1]=j>>>8&255,R[2]=j>>>16&255,R[3]=j>>>24&255,m.check=r(m.check,R,4,0)),q=j=0,m.mode=4;case 4:for(;q<16;){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}m.head&&(m.head.xflags=255&j,m.head.os=j>>8),512&m.flags&&(R[0]=255&j,R[1]=j>>>8&255,m.check=r(m.check,R,2,0)),q=j=0,m.mode=5;case 5:if(1024&m.flags){for(;q<16;){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}m.length=j,m.head&&(m.head.extra_len=j),512&m.flags&&(R[0]=255&j,R[1]=j>>>8&255,m.check=r(m.check,R,2,0)),q=j=0}else m.head&&(m.head.extra=null);m.mode=6;case 6:if(1024&m.flags&&(O<(st=m.length)&&(st=O),st&&(m.head&&(h=m.head.extra_len-m.length,m.head.extra||(m.head.extra=new Array(m.head.extra_len)),s.arraySet(m.head.extra,K,M,st,h)),512&m.flags&&(m.check=r(m.check,K,st,M)),O-=st,M+=st,m.length-=st),m.length))break t;m.length=0,m.mode=7;case 7:if(2048&m.flags){if(O===0)break t;for(st=0;h=K[M+st++],m.head&&h&&m.length<65536&&(m.head.name+=String.fromCharCode(h)),h&&st<O;);if(512&m.flags&&(m.check=r(m.check,K,st,M)),O-=st,M+=st,h)break t}else m.head&&(m.head.name=null);m.length=0,m.mode=8;case 8:if(4096&m.flags){if(O===0)break t;for(st=0;h=K[M+st++],m.head&&h&&m.length<65536&&(m.head.comment+=String.fromCharCode(h)),h&&st<O;);if(512&m.flags&&(m.check=r(m.check,K,st,M)),O-=st,M+=st,h)break t}else m.head&&(m.head.comment=null);m.mode=9;case 9:if(512&m.flags){for(;q<16;){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}if(j!==(65535&m.check)){$.msg="header crc mismatch",m.mode=30;break}q=j=0}m.head&&(m.head.hcrc=m.flags>>9&1,m.head.done=!0),$.adler=m.check=0,m.mode=12;break;case 10:for(;q<32;){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}$.adler=m.check=y(j),q=j=0,m.mode=11;case 11:if(m.havedict===0)return $.next_out=F,$.avail_out=J,$.next_in=M,$.avail_in=O,m.hold=j,m.bits=q,2;$.adler=m.check=1,m.mode=12;case 12:if(U===5||U===6)break t;case 13:if(m.last){j>>>=7&q,q-=7&q,m.mode=27;break}for(;q<3;){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}switch(m.last=1&j,q-=1,3&(j>>>=1)){case 0:m.mode=14;break;case 1:if(N(m),m.mode=20,U!==6)break;j>>>=2,q-=2;break t;case 2:m.mode=17;break;case 3:$.msg="invalid block type",m.mode=30}j>>>=2,q-=2;break;case 14:for(j>>>=7&q,q-=7&q;q<32;){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}if((65535&j)!=(j>>>16^65535)){$.msg="invalid stored block lengths",m.mode=30;break}if(m.length=65535&j,q=j=0,m.mode=15,U===6)break t;case 15:m.mode=16;case 16:if(st=m.length){if(O<st&&(st=O),J<st&&(st=J),st===0)break t;s.arraySet(E,K,M,st,F),O-=st,M+=st,J-=st,F+=st,m.length-=st;break}m.mode=12;break;case 17:for(;q<14;){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}if(m.nlen=257+(31&j),j>>>=5,q-=5,m.ndist=1+(31&j),j>>>=5,q-=5,m.ncode=4+(15&j),j>>>=4,q-=4,286<m.nlen||30<m.ndist){$.msg="too many length or distance symbols",m.mode=30;break}m.have=0,m.mode=18;case 18:for(;m.have<m.ncode;){for(;q<3;){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}m.lens[G[m.have++]]=7&j,j>>>=3,q-=3}for(;m.have<19;)m.lens[G[m.have++]]=0;if(m.lencode=m.lendyn,m.lenbits=7,P={bits:m.lenbits},H=c(0,m.lens,0,19,m.lencode,0,m.work,P),m.lenbits=P.bits,H){$.msg="invalid code lengths set",m.mode=30;break}m.have=0,m.mode=19;case 19:for(;m.have<m.nlen+m.ndist;){for(;X=(C=m.lencode[j&(1<<m.lenbits)-1])>>>16&255,ut=65535&C,!((bt=C>>>24)<=q);){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}if(ut<16)j>>>=bt,q-=bt,m.lens[m.have++]=ut;else{if(ut===16){for(S=bt+2;q<S;){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}if(j>>>=bt,q-=bt,m.have===0){$.msg="invalid bit length repeat",m.mode=30;break}h=m.lens[m.have-1],st=3+(3&j),j>>>=2,q-=2}else if(ut===17){for(S=bt+3;q<S;){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}q-=bt,h=0,st=3+(7&(j>>>=bt)),j>>>=3,q-=3}else{for(S=bt+7;q<S;){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}q-=bt,h=0,st=11+(127&(j>>>=bt)),j>>>=7,q-=7}if(m.have+st>m.nlen+m.ndist){$.msg="invalid bit length repeat",m.mode=30;break}for(;st--;)m.lens[m.have++]=h}}if(m.mode===30)break;if(m.lens[256]===0){$.msg="invalid code -- missing end-of-block",m.mode=30;break}if(m.lenbits=9,P={bits:m.lenbits},H=c(d,m.lens,0,m.nlen,m.lencode,0,m.work,P),m.lenbits=P.bits,H){$.msg="invalid literal/lengths set",m.mode=30;break}if(m.distbits=6,m.distcode=m.distdyn,P={bits:m.distbits},H=c(u,m.lens,m.nlen,m.ndist,m.distcode,0,m.work,P),m.distbits=P.bits,H){$.msg="invalid distances set",m.mode=30;break}if(m.mode=20,U===6)break t;case 20:m.mode=21;case 21:if(6<=O&&258<=J){$.next_out=F,$.avail_out=J,$.next_in=M,$.avail_in=O,m.hold=j,m.bits=q,a($,lt),F=$.next_out,E=$.output,J=$.avail_out,M=$.next_in,K=$.input,O=$.avail_in,j=m.hold,q=m.bits,m.mode===12&&(m.back=-1);break}for(m.back=0;X=(C=m.lencode[j&(1<<m.lenbits)-1])>>>16&255,ut=65535&C,!((bt=C>>>24)<=q);){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}if(X&&(240&X)==0){for(vt=bt,D=X,z=ut;X=(C=m.lencode[z+((j&(1<<vt+D)-1)>>vt)])>>>16&255,ut=65535&C,!(vt+(bt=C>>>24)<=q);){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}j>>>=vt,q-=vt,m.back+=vt}if(j>>>=bt,q-=bt,m.back+=bt,m.length=ut,X===0){m.mode=26;break}if(32&X){m.back=-1,m.mode=12;break}if(64&X){$.msg="invalid literal/length code",m.mode=30;break}m.extra=15&X,m.mode=22;case 22:if(m.extra){for(S=m.extra;q<S;){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}m.length+=j&(1<<m.extra)-1,j>>>=m.extra,q-=m.extra,m.back+=m.extra}m.was=m.length,m.mode=23;case 23:for(;X=(C=m.distcode[j&(1<<m.distbits)-1])>>>16&255,ut=65535&C,!((bt=C>>>24)<=q);){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}if((240&X)==0){for(vt=bt,D=X,z=ut;X=(C=m.distcode[z+((j&(1<<vt+D)-1)>>vt)])>>>16&255,ut=65535&C,!(vt+(bt=C>>>24)<=q);){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}j>>>=vt,q-=vt,m.back+=vt}if(j>>>=bt,q-=bt,m.back+=bt,64&X){$.msg="invalid distance code",m.mode=30;break}m.offset=ut,m.extra=15&X,m.mode=24;case 24:if(m.extra){for(S=m.extra;q<S;){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}m.offset+=j&(1<<m.extra)-1,j>>>=m.extra,q-=m.extra,m.back+=m.extra}if(m.offset>m.dmax){$.msg="invalid distance too far back",m.mode=30;break}m.mode=25;case 25:if(J===0)break t;if(st=lt-J,m.offset>st){if((st=m.offset-st)>m.whave&&m.sane){$.msg="invalid distance too far back",m.mode=30;break}Q=st>m.wnext?(st-=m.wnext,m.wsize-st):m.wnext-st,st>m.length&&(st=m.length),pt=m.window}else pt=E,Q=F-m.offset,st=m.length;for(J<st&&(st=J),J-=st,m.length-=st;E[F++]=pt[Q++],--st;);m.length===0&&(m.mode=21);break;case 26:if(J===0)break t;E[F++]=m.length,J--,m.mode=21;break;case 27:if(m.wrap){for(;q<32;){if(O===0)break t;O--,j|=K[M++]<<q,q+=8}if(lt-=J,$.total_out+=lt,m.total+=lt,lt&&($.adler=m.check=m.flags?r(m.check,E,lt,F-lt):l(m.check,E,lt,F-lt)),lt=J,(m.flags?j:y(j))!==m.check){$.msg="incorrect data check",m.mode=30;break}q=j=0}m.mode=28;case 28:if(m.wrap&&m.flags){for(;q<32;){if(O===0)break t;O--,j+=K[M++]<<q,q+=8}if(j!==(4294967295&m.total)){$.msg="incorrect length check",m.mode=30;break}q=j=0}m.mode=29;case 29:H=1;break t;case 30:H=-3;break t;case 31:return-4;case 32:default:return f}return $.next_out=F,$.avail_out=J,$.next_in=M,$.avail_in=O,m.hold=j,m.bits=q,(m.wsize||lt!==$.avail_out&&m.mode<30&&(m.mode<27||U!==4))&&Z($,$.output,$.next_out,lt-$.avail_out)?(m.mode=31,-4):(rt-=$.avail_in,lt-=$.avail_out,$.total_in+=rt,$.total_out+=lt,m.total+=lt,m.wrap&&lt&&($.adler=m.check=m.flags?r(m.check,E,lt,$.next_out-lt):l(m.check,E,lt,$.next_out-lt)),$.data_type=m.bits+(m.last?64:0)+(m.mode===12?128:0)+(m.mode===20||m.mode===15?256:0),(rt==0&&lt===0||U===4)&&H===v&&(H=-5),H)},o.inflateEnd=function($){if(!$||!$.state)return f;var U=$.state;return U.window&&(U.window=null),$.state=null,v},o.inflateGetHeader=function($,U){var m;return $&&$.state?(2&(m=$.state).wrap)==0?f:((m.head=U).done=!1,v):f},o.inflateSetDictionary=function($,U){var m,K=U.length;return $&&$.state?(m=$.state).wrap!==0&&m.mode!==11?f:m.mode===11&&l(1,U,K,0)!==m.check?-3:Z($,U,K,K)?(m.mode=31,-4):(m.havedict=1,v):f},o.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(e,n,o){var s=e("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(d,u,v,f,k,p,b,y){var x,_,A,I,T,w,L,B,N,Z=y.bits,$=0,U=0,m=0,K=0,E=0,M=0,F=0,O=0,J=0,j=0,q=null,rt=0,lt=new s.Buf16(16),st=new s.Buf16(16),Q=null,pt=0;for($=0;$<=15;$++)lt[$]=0;for(U=0;U<f;U++)lt[u[v+U]]++;for(E=Z,K=15;1<=K&&lt[K]===0;K--);if(K<E&&(E=K),K===0)return k[p++]=20971520,k[p++]=20971520,y.bits=1,0;for(m=1;m<K&&lt[m]===0;m++);for(E<m&&(E=m),$=O=1;$<=15;$++)if(O<<=1,(O-=lt[$])<0)return-1;if(0<O&&(d===0||K!==1))return-1;for(st[1]=0,$=1;$<15;$++)st[$+1]=st[$]+lt[$];for(U=0;U<f;U++)u[v+U]!==0&&(b[st[u[v+U]]++]=U);if(w=d===0?(q=Q=b,19):d===1?(q=l,rt-=257,Q=r,pt-=257,256):(q=a,Q=c,-1),$=m,T=p,F=U=j=0,A=-1,I=(J=1<<(M=E))-1,d===1&&852<J||d===2&&592<J)return 1;for(;;){for(L=$-F,N=b[U]<w?(B=0,b[U]):b[U]>w?(B=Q[pt+b[U]],q[rt+b[U]]):(B=96,0),x=1<<$-F,m=_=1<<M;k[T+(j>>F)+(_-=x)]=L<<24|B<<16|N|0,_!==0;);for(x=1<<$-1;j&x;)x>>=1;if(x!==0?(j&=x-1,j+=x):j=0,U++,--lt[$]==0){if($===K)break;$=u[v+b[U]]}if(E<$&&(j&I)!==A){for(F===0&&(F=E),T+=m,O=1<<(M=$-F);M+F<K&&!((O-=lt[M+F])<=0);)M++,O<<=1;if(J+=1<<M,d===1&&852<J||d===2&&592<J)return 1;k[A=j&I]=E<<24|M<<16|T-p|0}}return j!==0&&(k[T+j]=$-F<<24|64<<16|0),y.bits=E,0}},{"../utils/common":41}],51:[function(e,n,o){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(e,n,o){var s=e("../utils/common"),l=0,r=1;function a(C){for(var R=C.length;0<=--R;)C[R]=0}var c=0,d=29,u=256,v=u+1+d,f=30,k=19,p=2*v+1,b=15,y=16,x=7,_=256,A=16,I=17,T=18,w=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],L=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],B=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],N=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],Z=new Array(2*(v+2));a(Z);var $=new Array(2*f);a($);var U=new Array(512);a(U);var m=new Array(256);a(m);var K=new Array(d);a(K);var E,M,F,O=new Array(f);function J(C,R,G,W,V){this.static_tree=C,this.extra_bits=R,this.extra_base=G,this.elems=W,this.max_length=V,this.has_stree=C&&C.length}function j(C,R){this.dyn_tree=C,this.max_code=0,this.stat_desc=R}function q(C){return C<256?U[C]:U[256+(C>>>7)]}function rt(C,R){C.pending_buf[C.pending++]=255&R,C.pending_buf[C.pending++]=R>>>8&255}function lt(C,R,G){C.bi_valid>y-G?(C.bi_buf|=R<<C.bi_valid&65535,rt(C,C.bi_buf),C.bi_buf=R>>y-C.bi_valid,C.bi_valid+=G-y):(C.bi_buf|=R<<C.bi_valid&65535,C.bi_valid+=G)}function st(C,R,G){lt(C,G[2*R],G[2*R+1])}function Q(C,R){for(var G=0;G|=1&C,C>>>=1,G<<=1,0<--R;);return G>>>1}function pt(C,R,G){var W,V,Y=new Array(b+1),ot=0;for(W=1;W<=b;W++)Y[W]=ot=ot+G[W-1]<<1;for(V=0;V<=R;V++){var it=C[2*V+1];it!==0&&(C[2*V]=Q(Y[it]++,it))}}function bt(C){var R;for(R=0;R<v;R++)C.dyn_ltree[2*R]=0;for(R=0;R<f;R++)C.dyn_dtree[2*R]=0;for(R=0;R<k;R++)C.bl_tree[2*R]=0;C.dyn_ltree[2*_]=1,C.opt_len=C.static_len=0,C.last_lit=C.matches=0}function X(C){8<C.bi_valid?rt(C,C.bi_buf):0<C.bi_valid&&(C.pending_buf[C.pending++]=C.bi_buf),C.bi_buf=0,C.bi_valid=0}function ut(C,R,G,W){var V=2*R,Y=2*G;return C[V]<C[Y]||C[V]===C[Y]&&W[R]<=W[G]}function vt(C,R,G){for(var W=C.heap[G],V=G<<1;V<=C.heap_len&&(V<C.heap_len&&ut(R,C.heap[V+1],C.heap[V],C.depth)&&V++,!ut(R,W,C.heap[V],C.depth));)C.heap[G]=C.heap[V],G=V,V<<=1;C.heap[G]=W}function D(C,R,G){var W,V,Y,ot,it=0;if(C.last_lit!==0)for(;W=C.pending_buf[C.d_buf+2*it]<<8|C.pending_buf[C.d_buf+2*it+1],V=C.pending_buf[C.l_buf+it],it++,W===0?st(C,V,R):(st(C,(Y=m[V])+u+1,R),(ot=w[Y])!==0&&lt(C,V-=K[Y],ot),st(C,Y=q(--W),G),(ot=L[Y])!==0&&lt(C,W-=O[Y],ot)),it<C.last_lit;);st(C,_,R)}function z(C,R){var G,W,V,Y=R.dyn_tree,ot=R.stat_desc.static_tree,it=R.stat_desc.has_stree,at=R.stat_desc.elems,St=-1;for(C.heap_len=0,C.heap_max=p,G=0;G<at;G++)Y[2*G]!==0?(C.heap[++C.heap_len]=St=G,C.depth[G]=0):Y[2*G+1]=0;for(;C.heap_len<2;)Y[2*(V=C.heap[++C.heap_len]=St<2?++St:0)]=1,C.depth[V]=0,C.opt_len--,it&&(C.static_len-=ot[2*V+1]);for(R.max_code=St,G=C.heap_len>>1;1<=G;G--)vt(C,Y,G);for(V=at;G=C.heap[1],C.heap[1]=C.heap[C.heap_len--],vt(C,Y,1),W=C.heap[1],C.heap[--C.heap_max]=G,C.heap[--C.heap_max]=W,Y[2*V]=Y[2*G]+Y[2*W],C.depth[V]=(C.depth[G]>=C.depth[W]?C.depth[G]:C.depth[W])+1,Y[2*G+1]=Y[2*W+1]=V,C.heap[1]=V++,vt(C,Y,1),2<=C.heap_len;);C.heap[--C.heap_max]=C.heap[1],(function(kt,Mt){var qt,Gt,ne,Nt,Ke,ee,Jt=Mt.dyn_tree,bi=Mt.max_code,Li=Mt.stat_desc.static_tree,Ao=Mt.stat_desc.has_stree,To=Mt.stat_desc.extra_bits,Pn=Mt.stat_desc.extra_base,yi=Mt.stat_desc.max_length,Ri=0;for(Nt=0;Nt<=b;Nt++)kt.bl_count[Nt]=0;for(Jt[2*kt.heap[kt.heap_max]+1]=0,qt=kt.heap_max+1;qt<p;qt++)yi<(Nt=Jt[2*Jt[2*(Gt=kt.heap[qt])+1]+1]+1)&&(Nt=yi,Ri++),Jt[2*Gt+1]=Nt,bi<Gt||(kt.bl_count[Nt]++,Ke=0,Pn<=Gt&&(Ke=To[Gt-Pn]),ee=Jt[2*Gt],kt.opt_len+=ee*(Nt+Ke),Ao&&(kt.static_len+=ee*(Li[2*Gt+1]+Ke)));if(Ri!==0){do{for(Nt=yi-1;kt.bl_count[Nt]===0;)Nt--;kt.bl_count[Nt]--,kt.bl_count[Nt+1]+=2,kt.bl_count[yi]--,Ri-=2}while(0<Ri);for(Nt=yi;Nt!==0;Nt--)for(Gt=kt.bl_count[Nt];Gt!==0;)bi<(ne=kt.heap[--qt])||(Jt[2*ne+1]!==Nt&&(kt.opt_len+=(Nt-Jt[2*ne+1])*Jt[2*ne],Jt[2*ne+1]=Nt),Gt--)}})(C,R),pt(Y,St,C.bl_count)}function h(C,R,G){var W,V,Y=-1,ot=R[1],it=0,at=7,St=4;for(ot===0&&(at=138,St=3),R[2*(G+1)+1]=65535,W=0;W<=G;W++)V=ot,ot=R[2*(W+1)+1],++it<at&&V===ot||(it<St?C.bl_tree[2*V]+=it:V!==0?(V!==Y&&C.bl_tree[2*V]++,C.bl_tree[2*A]++):it<=10?C.bl_tree[2*I]++:C.bl_tree[2*T]++,Y=V,St=(it=0)===ot?(at=138,3):V===ot?(at=6,3):(at=7,4))}function H(C,R,G){var W,V,Y=-1,ot=R[1],it=0,at=7,St=4;for(ot===0&&(at=138,St=3),W=0;W<=G;W++)if(V=ot,ot=R[2*(W+1)+1],!(++it<at&&V===ot)){if(it<St)for(;st(C,V,C.bl_tree),--it!=0;);else V!==0?(V!==Y&&(st(C,V,C.bl_tree),it--),st(C,A,C.bl_tree),lt(C,it-3,2)):it<=10?(st(C,I,C.bl_tree),lt(C,it-3,3)):(st(C,T,C.bl_tree),lt(C,it-11,7));Y=V,St=(it=0)===ot?(at=138,3):V===ot?(at=6,3):(at=7,4)}}a(O);var P=!1;function S(C,R,G,W){lt(C,(c<<1)+(W?1:0),3),(function(V,Y,ot,it){X(V),rt(V,ot),rt(V,~ot),s.arraySet(V.pending_buf,V.window,Y,ot,V.pending),V.pending+=ot})(C,R,G)}o._tr_init=function(C){P||((function(){var R,G,W,V,Y,ot=new Array(b+1);for(V=W=0;V<d-1;V++)for(K[V]=W,R=0;R<1<<w[V];R++)m[W++]=V;for(m[W-1]=V,V=Y=0;V<16;V++)for(O[V]=Y,R=0;R<1<<L[V];R++)U[Y++]=V;for(Y>>=7;V<f;V++)for(O[V]=Y<<7,R=0;R<1<<L[V]-7;R++)U[256+Y++]=V;for(G=0;G<=b;G++)ot[G]=0;for(R=0;R<=143;)Z[2*R+1]=8,R++,ot[8]++;for(;R<=255;)Z[2*R+1]=9,R++,ot[9]++;for(;R<=279;)Z[2*R+1]=7,R++,ot[7]++;for(;R<=287;)Z[2*R+1]=8,R++,ot[8]++;for(pt(Z,v+1,ot),R=0;R<f;R++)$[2*R+1]=5,$[2*R]=Q(R,5);E=new J(Z,w,u+1,v,b),M=new J($,L,0,f,b),F=new J(new Array(0),B,0,k,x)})(),P=!0),C.l_desc=new j(C.dyn_ltree,E),C.d_desc=new j(C.dyn_dtree,M),C.bl_desc=new j(C.bl_tree,F),C.bi_buf=0,C.bi_valid=0,bt(C)},o._tr_stored_block=S,o._tr_flush_block=function(C,R,G,W){var V,Y,ot=0;0<C.level?(C.strm.data_type===2&&(C.strm.data_type=(function(it){var at,St=4093624447;for(at=0;at<=31;at++,St>>>=1)if(1&St&&it.dyn_ltree[2*at]!==0)return l;if(it.dyn_ltree[18]!==0||it.dyn_ltree[20]!==0||it.dyn_ltree[26]!==0)return r;for(at=32;at<u;at++)if(it.dyn_ltree[2*at]!==0)return r;return l})(C)),z(C,C.l_desc),z(C,C.d_desc),ot=(function(it){var at;for(h(it,it.dyn_ltree,it.l_desc.max_code),h(it,it.dyn_dtree,it.d_desc.max_code),z(it,it.bl_desc),at=k-1;3<=at&&it.bl_tree[2*N[at]+1]===0;at--);return it.opt_len+=3*(at+1)+5+5+4,at})(C),V=C.opt_len+3+7>>>3,(Y=C.static_len+3+7>>>3)<=V&&(V=Y)):V=Y=G+5,G+4<=V&&R!==-1?S(C,R,G,W):C.strategy===4||Y===V?(lt(C,2+(W?1:0),3),D(C,Z,$)):(lt(C,4+(W?1:0),3),(function(it,at,St,kt){var Mt;for(lt(it,at-257,5),lt(it,St-1,5),lt(it,kt-4,4),Mt=0;Mt<kt;Mt++)lt(it,it.bl_tree[2*N[Mt]+1],3);H(it,it.dyn_ltree,at-1),H(it,it.dyn_dtree,St-1)})(C,C.l_desc.max_code+1,C.d_desc.max_code+1,ot+1),D(C,C.dyn_ltree,C.dyn_dtree)),bt(C),W&&X(C)},o._tr_tally=function(C,R,G){return C.pending_buf[C.d_buf+2*C.last_lit]=R>>>8&255,C.pending_buf[C.d_buf+2*C.last_lit+1]=255&R,C.pending_buf[C.l_buf+C.last_lit]=255&G,C.last_lit++,R===0?C.dyn_ltree[2*G]++:(C.matches++,R--,C.dyn_ltree[2*(m[G]+u+1)]++,C.dyn_dtree[2*q(R)]++),C.last_lit===C.lit_bufsize-1},o._tr_align=function(C){lt(C,2,3),st(C,_,Z),(function(R){R.bi_valid===16?(rt(R,R.bi_buf),R.bi_buf=0,R.bi_valid=0):8<=R.bi_valid&&(R.pending_buf[R.pending++]=255&R.bi_buf,R.bi_buf>>=8,R.bi_valid-=8)})(C)}},{"../utils/common":41}],53:[function(e,n,o){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(e,n,o){(function(s){(function(l,r){if(!l.setImmediate){var a,c,d,u,v=1,f={},k=!1,p=l.document,b=Object.getPrototypeOf&&Object.getPrototypeOf(l);b=b&&b.setTimeout?b:l,a={}.toString.call(l.process)==="[object process]"?function(A){process.nextTick(function(){x(A)})}:(function(){if(l.postMessage&&!l.importScripts){var A=!0,I=l.onmessage;return l.onmessage=function(){A=!1},l.postMessage("","*"),l.onmessage=I,A}})()?(u="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",_,!1):l.attachEvent("onmessage",_),function(A){l.postMessage(u+A,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(A){x(A.data)},function(A){d.port2.postMessage(A)}):p&&"onreadystatechange"in p.createElement("script")?(c=p.documentElement,function(A){var I=p.createElement("script");I.onreadystatechange=function(){x(A),I.onreadystatechange=null,c.removeChild(I),I=null},c.appendChild(I)}):function(A){setTimeout(x,0,A)},b.setImmediate=function(A){typeof A!="function"&&(A=new Function(""+A));for(var I=new Array(arguments.length-1),T=0;T<I.length;T++)I[T]=arguments[T+1];var w={callback:A,args:I};return f[v]=w,a(v),v++},b.clearImmediate=y}function y(A){delete f[A]}function x(A){if(k)setTimeout(x,0,A);else{var I=f[A];if(I){k=!0;try{(function(T){var w=T.callback,L=T.args;switch(L.length){case 0:w();break;case 1:w(L[0]);break;case 2:w(L[0],L[1]);break;case 3:w(L[0],L[1],L[2]);break;default:w.apply(r,L)}})(I)}finally{y(A),k=!1}}}}function _(A){A.source===l&&typeof A.data=="string"&&A.data.indexOf(u)===0&&x(+A.data.slice(u.length))}})(typeof self>"u"?s===void 0?this:s:self)}).call(this,typeof Wn<"u"?Wn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Wo)),Wo.exports}var nb=ib();const ob=eb(nb),sb=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,rb=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function lb(t){const i=await ob.loadAsync(t),e={},n=[];let o="",s="";const l=[];i.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(o=await r.file.async("string"),s=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||rb.test(c)||c.includes("snippets/")){const d=await a.file.async("string");e[c]=d;const u=c.split("/");u.length>1&&(e[u.slice(1).join("/")]=d)}else if(sb.test(c)){const d=await a.file.async("uint8array"),u=c.split("/").pop()||c,v=typeof Blob<"u"?new Blob([d]):void 0;n.push({zipPath:c,fileName:u,data:d,blob:v})}}return{entryMarkdown:o,entryMarkdownPath:s,virtualFiles:e,assets:n}}function ab(t,i){if(Object.keys(i).length===0)return t;function e(o){const s=o.trim().replace(/^['"]|['"]$/g,""),l=s.split("/").pop()||s;if(i[s])return i[s];const r=s.replace(/^\.?\//,"");return i[r]?i[r]:i[l]?i[l]:null}function n(o){let s=o;return s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=e(a);return c?`![${r}](${c})`:l}),s=s.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=e(r);return a?`src="${a}"`:l}),s}for(const o of t.slides)if(o.rawMarkdown=n(o.rawMarkdown),o.pageAttrs["custom-slidev-background"]){const s=o.pageAttrs["custom-slidev-background"],l=e(s);l&&(o.pageAttrs["custom-slidev-background"]=l)}if(t.flattenedMarkdown=n(t.flattenedMarkdown),t.docRootAttrs["custom-slidev-background"]){const o=t.docRootAttrs["custom-slidev-background"],s=e(o);s&&(t.docRootAttrs["custom-slidev-background"]=s)}return t}function aa(t){try{if(typeof process<"u"&&typeof require<"u"){const i=require("fs");if(i.existsSync(t))return i.readFileSync(t,"utf-8")}}catch{}return null}function cb(t,i){const e=t.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!e)return null;const n=e[1].trim(),o=n.indexOf("#"),s=o!==-1?n.slice(0,o):n,l=o!==-1?n.slice(o+1):"",r=s.replace(/^@\//,"").replace(/^\.\//,""),a=(i==null?void 0:i.virtualFiles)||{};let c=a[s]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const f=r.split("/").pop();for(const[k,p]of Object.entries(a))if(k.endsWith(`/${r}`)||f&&k.endsWith(`/${f}`)){c=p;break}}if(!c){const f=[];if(i!=null&&i.baseDir)try{const k=require("path");f.push(k.resolve(i.baseDir,r)),f.push(k.resolve(i.baseDir,s))}catch{}try{const k=require("path");f.push(k.resolve(process.cwd(),r))}catch{}for(const k of f){const p=aa(k);if(p!==null){c=p;break}}}if(!c){const f=Ql||{};if(c=f[s]||f[r]||f[`snippets/${r}`],!c){const k=r.split("/").pop();for(const[p,b]of Object.entries(f))if(p.endsWith(`/${r}`)||k&&p.endsWith(`/${k}`)){c=b;break}}}if(!c)return null;let d=c;if(l){const f=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),k=c.match(f);if(k){const p=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(p?p[1]:"")+k[1].trimEnd()}}const u=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${u?u[1]:""}
${d}
\`\`\``}function db(t){let i=!1,e=!1;for(let n=0;n<t.length;n++){const o=t[n];if(o==="'"&&!e)i=!i;else if(o==='"'&&!i)e=!e;else if(o==="#"&&!i&&!e)return t.slice(0,n).trim()}return t.trim()}function Zn(t){const i={},e=t.split(/\r?\n/);let n=0;for(;n<e.length;){const o=e[n],s=o.trim();if(!s||s.startsWith("#")){n++;continue}const l=o.indexOf(":");if(l>0){const r=o.slice(0,l).trim();let a=o.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let d=-1;for(;n<e.length;){const u=e[n];if(!u.trim()){c.push(""),n++;continue}const f=u.match(/^(\s+)/),k=f?f[1].length:0;if(d===-1&&(d=k),k<d)break;c.push(u.slice(d)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();i[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=db(a),!a){let c=n+1;const d=[];let u=-1;for(;c<e.length;){const v=e[c],f=v.trim();if(!f||f.startsWith("#")){u!==-1&&d.push(""),c++;continue}const k=v.match(/^(\s+)/),p=k?k[1].length:0;if(u===-1)if(p>0)u=p;else break;if(p<u)break;d.push(v.slice(u)),c++}if(d.length>0){i[r]=Zn(d.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),i[r]=a}n++}return i}const ub=/^\s*```ya?ml([\s\S]*?)```/;function Ir(t){let i={},e=t.trim();const n=e.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const s=Zn(n[1]);if(Object.keys(s).length>0||!n[1].trim())return i=s,e=e.slice(n[0].length).trim(),{frontmatter:i,content:e}}if(e.startsWith("---")){const s=e.match(/^---[^\n\r]*(?:\r?\n|$)/);s&&(e=e.slice(s[0].length).trim())}const o=e.match(ub);if(o)i=Zn(o[1]),e=e.slice(o[0].length).trim();else{const s=e.split(/\r?\n/),l=[];let r=0;for(let a=0;a<s.length;a++){const c=s[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(i=Zn(l.join(`
`)),e=s.slice(r).join(`
`).trim())}return{frontmatter:i,content:e}}function fb(t){const i=t.split(/\r?\n/),e=[];let n=0,o=!1;function s(l){if(n>=l)return;const r=i.slice(n,l).join(`
`).trim();r&&e.push(r),n=l+1}for(let l=0;l<i.length;l++){const a=i[l].trimEnd();if(o){a.includes("-->")&&(o=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(o=!0);continue}if(a.startsWith("---")){s(l);const c=i[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<i.length&&i[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let u=l+1;for(;u<i.length&&!i[u].trimStart().startsWith(d);u++);u<i.length&&(l=u)}}return n<i.length&&s(i.length),e}function Yn(t,i={}){const{stripNotesFromMarkdown:e=!0,cleanVClicks:n=!0,cleanShikiLines:o=!0,cleanSlots:s=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=i;let d=t;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const u=fb(d),v={};let f="",k="",p=0;if(u.length>0){const N=u[0],Z=Ir(N),$=Object.keys(Z.frontmatter).length>0,U=Z.content.length>0;$&&!U&&u.length>1?(p=1,b(Z.frontmatter)):$&&b(Z.frontmatter)}function b(N){f=N.title||"",N.theme&&(v[bn]=String(N.theme)),N.aspectRatio&&(v[yn]=String(N.aspectRatio)),N.highlighter&&(v[Rr]=String(N.highlighter)),N.transition&&(v[kn]=String(N.transition)),N.colorSchema&&(v[Pr]=String(N.colorSchema)),N.layout&&(v[dt]=String(N.layout)),N.background&&(v[Ht]=String(N.background)),N.image&&(v[Be]=String(N.image)),N.class&&(v[ji]=String(N.class));for(const[Z,$]of Object.entries(N))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(Z)||(v[`custom-slidev-${Z}`]=typeof $=="object"?JSON.stringify($):String($))}const y=[];let x=0,_=0,A=0,I=0;const T=new Set,w={};let L=1;for(let N=p;N<u.length;N++){const Z=u[N],{frontmatter:$,content:U}=Ir(Z),m=Z.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),K=$.src||(m?m[1]:void 0);if(K){const X=String(K).trim().replace(/^['"]|['"]$/g,"");let ut=c[X]||c[X.replace(/^\.\//,"")]||c[`pages/${X.replace(/^.*pages\//,"")}`];if(!ut){const D=X.replace(/^\.\//,""),z=[];if(i.baseDir)try{const h=require("path");z.push(h.resolve(i.baseDir,D)),z.push(h.resolve(i.baseDir,X))}catch{}try{const h=require("path");z.push(h.resolve(process.cwd(),D)),z.push(h.resolve(process.cwd(),X))}catch{}for(const h of z){const H=aa(h);if(H!==null){ut=H;break}}}const vt={};$.layout&&(vt[dt]=String($.layout)),$.transition&&(vt[Qt]=String($.transition)),$.background&&(vt[Ht]=String($.background)),$.image&&(vt[Be]=String($.image)),$.class&&(vt[ji]=String($.class));for(const[D,z]of Object.entries($))["src","layout","transition","background","image","class"].includes(D)||(vt[`custom-slidev-${D}`]=typeof z=="object"?JSON.stringify(z):String(z));if(ut){const D=Yn(ut,{...i,virtualFiles:c});for(const z of D.slides){z.pageIndex=L++,z.pageAttrs={...vt,...z.pageAttrs},y.push(z);const h=z.pageAttrs[dt]||"default";w[h]=(w[h]||0)+1}continue}else{y.push({pageIndex:L++,pageAttrs:{...vt,"custom-slidev-src":X},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${X}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const D=vt[dt]||"default";w[D]=(w[D]||0)+1;continue}}const E={};$.layout&&(E[dt]=String($.layout)),$.transition&&(E[Qt]=String($.transition)),$.background&&(E[Ht]=String($.background)),$.image&&(E[Be]=String($.image)),$.class&&(E[ji]=String($.class));for(const[X,ut]of Object.entries($))["layout","transition","background","image","class"].includes(X)||(E[`custom-slidev-${X}`]=typeof ut=="object"?JSON.stringify(ut):String(ut));let M=U;const F=[];let O=M.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,X=>{const ut=`__CODE_TOKEN_NOTE_${F.length}__`;return F.push(X),ut});O=O.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,X=>{const ut=`__CODE_TOKEN_NOTE_${F.length}__`;return F.push(X),ut});let J="";const j=Array.from(O.matchAll(/<!--([\s\S]*?)-->/g));if(j.length>0){const X=j[j.length-1],ut=O.slice(X.index+X[0].length).trim();if(!ut||!ut.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const D=X[1].trim();D.startsWith("TODO:")||(J=D,x++),e&&(O=O.slice(0,X.index).trimEnd()+O.slice(X.index+X[0].length))}}e&&(O=O.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let X=0;X<F.length;X++)O=O.replace(`__CODE_TOKEN_NOTE_${X}__`,F[X]);if(M=O,J){for(let vt=0;vt<F.length;vt++)J=J.replace(`__CODE_TOKEN_NOTE_${vt}__`,F[vt]);const ut=`> [!NOTE] 💡 演讲备注
${J.split(/\r?\n/).map(vt=>`> ${vt}`).join(`
`)}
{: custom-slidev-note="true"}`;M=M?`${M}

${ut}`:ut}let q=!1;if(/<style\b/i.test(M)){q=!0;const X=M.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(X){for(const ut of X){const vt=ut.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();k=k?`${k}

${vt}`:vt}l&&(M=M.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const rt=M.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);rt&&(_+=rt.length);const lt=M.match(/```\w+\s+\{[^}]+\}/g);lt&&(A+=lt.length);const st=M.match(/::\w+::|<template\s+#[^>]+>/g);if(st&&(I+=st.length),M=M.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,X=>cb(X,{...i,virtualFiles:c})||X),n&&(M=M.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),o&&(M=M.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),M=M.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),s&&(M=M.replace(/^::\w+::\s*$/gm,"")),r&&(M=rc(M)),a){let X=M.trim(),ut="";const vt=X.lastIndexOf("> [!NOTE] 💡 演讲备注");if(vt!==-1&&(ut=X.slice(vt),X=X.slice(0,vt).trim()),($.layout==="image-left"||$.layout==="image-right")&&$.image){const D=String($.image).trim(),z=$.layout==="image-left"?"image-left":"image-right",h=`![配图](${D})
{: custom-slidev-layout="${z}" }`;$.layout==="image-left"?X=`{{{col

${h}

${X}

}}}`:X=`{{{col

${X}

${h}

}}}`}if($.background){const z=`![背景图](${String($.background).trim()})
{: custom-slidev-role="background" }`;X=X?`${z}

${X}`:z}M=ut?`${X}

${ut}`:X}const Q=pb(M);E[Ht]&&Q.push(E[Ht]),E[Be]&&Q.push(E[Be]);for(const X of Q)T.add(X);const pt=/<[A-Z][a-zA-Z0-9]+/.test(M),bt=E[dt]||(L===1?v[dt]||"cover":"default");w[bt]=(w[bt]||0)+1,y.push({pageIndex:L++,pageAttrs:E,notes:J,rawMarkdown:M,hasVueComponent:pt,hasStyleTag:q,assetReferences:Q})}if(!f&&y.length>0){const N=y[0].rawMarkdown.match(/^#\s+(.+)$/m);N&&(f=N[1].trim())}k&&(v["custom-slidev-custom-css"]=k);let B=y.map(N=>`---

${N.rawMarkdown}`).join(`

`);return B.trimStart().startsWith("---")||(B=`---

${B.trimStart()}`),{docTitle:f||"Slidev 演示文稿",docRootAttrs:v,slides:y,totalSlides:y.length,stats:{totalNotes:x,totalVClicks:_,totalShikiHighlights:A,totalSlots:I,discoveredAssets:Array.from(T),layoutDistribution:w},flattenedMarkdown:B,customCss:k}}function pb(t){const i=[],e=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=e.exec(t))!==null;){const s=n[1].split(/\s+/)[0].trim();s&&i.push(s)}const o=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=o.exec(t))!==null;){const s=n[1].trim();s&&i.push(s)}return i}function ca(t){if(!t)return!1;const i=String(t.type||"").toLowerCase(),e=String(t.markdown||"").trim(),n=String(t.content||"").trim();return i==="tb"||i==="thematic-break"||i==="nodethematicbreak"||e==="---"||e==="***"||n==="---"||n==="***"}function hb(t){return(t.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function mb(t,i,e=Rt){const n=t.filter(ca);let o=0;if(n.length>=i.length)for(let s=0;s<i.length;s++){const l=i[s],r=n[s];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await e(r.id,l.pageAttrs),o++)}else for(let s=1;s<i.length;s++){const l=i[s],r=n[s-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await e(r.id,l.pageAttrs),o++)}return o}async function gb(t,i=Rt){let e=!1,n=0;for(const o of t){if(ca(o)){e=!1;continue}const s=(o.markdown||o.content||"").trim();if(s==="::right::"||s.startsWith("::right::")){e=!0;continue}e&&o.id&&(await i(o.id,{[Tt]:"right"}).catch(()=>{}),n++)}return n}async function vb(t,i,e=Er){const n={};if(!i||i.length===0)return n;const o=[];for(const s of i){const l=new File([s.data],s.fileName,{type:"application/octet-stream"});o.push(l)}try{const s=await e("/data/assets",o);if(s!=null&&s.succMap)for(const[l,r]of Object.entries(s.succMap))n[l]=String(r)}catch(s){console.warn("上传本地静态资产失败，保留原路径:",s)}return Object.keys(n).length>0&&ab(t,n),n}async function bb(t){var A;const{presentation:i,notebookId:e,docTitle:n,extractedAssets:o=[],uploadAssets:s=!0,autoPreview:l=!0,plugin:r,api:a={}}=t,c=a.uploadFn||Er,d=a.createDocFn||Fa,u=a.setAttrsFn||Rt,v=a.getChildBlocksFn||Xn,f=a.openTabFn||mt.openTab,k=a.showMessageFn||mt.showMessage;s&&o.length>0&&await vb(i,o,c);const p=hb(n),b=`/${p}`,y=await d(e,b,i.flattenedMarkdown);if(!y)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const x=((A=i.slides[0])==null?void 0:A.pageAttrs)||{};await u(y,{...x,...i.docRootAttrs});const _=await v(y).catch(()=>[]);return Array.isArray(_)&&_.length>0&&(await mb(_,i.slides,u),await gb(_,u)),k(`🎉 成功导入 Slidev 演示文档《${p}》！`),l&&r&&(r.currentDocId=y,await f({app:r.app,doc:{id:y}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),y}function yb(t){const i=ft("file"),e=ft(!1),n=ft(!1),o=ft(""),s=ft(null),l=ft(null),r=ft(""),a=ft(0),c=ft(""),d=ft([]),u=ft(null),v=ft(""),f=ft([]),k=ft(""),p=ft(!0),b=ft(!0),y=ft(!0),x=ft(!0),_=_t(()=>{const E=a.value;if(E===0)return"0 B";const M=1024,F=["B","KB","MB","GB"],O=Math.floor(Math.log(E)/Math.log(M));return`${(E/M**O).toFixed(1)} ${F[O]}`}),A=_t(()=>{var E;return((E=u.value)==null?void 0:E.docRootAttrs["custom-slidev-theme"])||"default"}),I=_t(()=>{var E;return d.value.length>0?d.value.length:((E=u.value)==null?void 0:E.stats.discoveredAssets.length)||0}),T=_t(()=>{var M;const E=((M=u.value)==null?void 0:M.stats.layoutDistribution)||{};return Object.entries(E).map(([F,O])=>({name:F,count:O}))});async function w(E=Na){try{const M=await E();M!=null&&M.notebooks&&Array.isArray(M.notebooks)&&(f.value=M.notebooks.filter(F=>!F.closed),f.value.length>0&&!k.value&&(k.value=f.value[0].id))}catch(M){console.warn("获取笔记本列表失败:",M)}}function L(){var E;(E=s.value)==null||E.click()}function B(){l.value=null,r.value="",a.value=0,u.value=null,d.value=[],o.value=""}async function N(E){o.value="",l.value=E,r.value=E.name,a.value=E.size;try{if(E.name.toLowerCase().endsWith(".zip")){const F=await E.arrayBuffer(),O=await lb(F);if(!O.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}d.value=O.assets;const J=Yn(O.entryMarkdown,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:p.value,cleanSlots:!1,virtualFiles:O.virtualFiles});u.value=J,v.value=J.docTitle||E.name.replace(/\.zip$/i,"")}else{const F=await E.text();d.value=[];const O=E.path||"",J=O?O.replace(/[\\/][^\\/]+$/,""):"",j=Yn(F,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:p.value,cleanSlots:!1,baseDir:J||void 0});u.value=j,v.value=j.docTitle||E.name.replace(/\.md$/i,"")}}catch(M){console.error("解析文件失败:",M),o.value=`解析文件失败: ${M.message||String(M)}`}}function Z(){if(o.value="",!c.value.trim()){u.value=null;return}try{const E=Yn(c.value,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:p.value,cleanSlots:!1});u.value=E,v.value=E.docTitle||"Slidev 演示文稿"}catch(E){o.value=`解析 Markdown 源码失败: ${E.message||String(E)}`}}async function $(){l.value?await N(l.value):c.value&&Z()}async function U(E){const M=E.target;M.files&&M.files[0]&&await N(M.files[0])}async function m(E){var M;e.value=!1,(M=E.dataTransfer)!=null&&M.files&&E.dataTransfer.files[0]&&await N(E.dataTransfer.files[0])}async function K(E=t){if(u.value){if(!k.value&&f.value.length>0&&(k.value=f.value[0].id),!k.value){o.value="请先选择目标笔记本";return}n.value=!0,o.value="";try{return await bb({presentation:u.value,notebookId:k.value,docTitle:v.value,extractedAssets:d.value,uploadAssets:y.value,autoPreview:x.value,plugin:E})}catch(M){console.error("导入 Slidev 演示失败:",M),o.value=`导入执行失败: ${M.message||String(M)}`}finally{n.value=!1}}}return{inputMode:i,isDragging:e,isImporting:n,errorMessage:o,fileInputRef:s,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:d,parsedPresentation:u,customDocTitle:v,notebooks:f,selectedNotebookId:k,optCleanHtml:p,optStripNotes:b,optUploadAssets:y,optAutoPreview:x,formattedFileSize:_,currentTheme:A,extractedAssetsCount:I,layoutChips:T,fetchNotebooks:w,triggerFileInput:L,clearFile:B,processFile:N,onFileSelected:U,onFileDrop:m,onTextChange:Z,reprocessCurrentInput:$,handleConfirmImport:K}}const kb={class:"spm-import-dialog"},wb={class:"spm-tabs-header"},xb={class:"spm-dialog-body"},_b={key:0,class:"spm-file-section"},Sb={key:0,class:"spm-dropzone-prompt"},Cb={key:1,class:"spm-dropzone-active"},$b={class:"spm-file-badge"},Ib={class:"spm-file-size"},Ab={key:1,class:"spm-text-section"},Tb={key:2,class:"spm-error-banner"},Bb={key:3,class:"spm-preview-card"},Eb={class:"spm-config-grid"},Mb={class:"spm-form-item"},Db={class:"spm-form-item"},Lb=["value"],Rb={class:"spm-stats-grid"},Pb={class:"spm-stat-box"},Ob={class:"spm-stat-value"},zb={class:"spm-stat-box"},Nb={class:"spm-stat-value"},Fb={class:"spm-stat-box"},jb={class:"spm-stat-value"},Hb={class:"spm-stat-box"},Ub={class:"spm-stat-value"},Wb={key:0,class:"spm-chips-row"},Vb={class:"spm-options-group"},Kb={class:"spm-checkbox-label"},qb={class:"spm-checkbox-label"},Gb={class:"spm-checkbox-label"},Zb={class:"spm-checkbox-label"},Yb={class:"spm-dialog-footer"},Jb=["disabled"],Xb=["disabled"],Qb={key:0},t1={key:1},e1=xe({__name:"SlidevImportDialog",emits:["close","success"],setup(t,{emit:i}){const e=i,n=Qe("plugin"),{inputMode:o,isDragging:s,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:d,extractedAssetsCount:u,parsedPresentation:v,customDocTitle:f,notebooks:k,selectedNotebookId:p,optCleanHtml:b,optStripNotes:y,optUploadAssets:x,optAutoPreview:_,formattedFileSize:A,currentTheme:I,layoutChips:T,fetchNotebooks:w,triggerFileInput:L,clearFile:B,onFileSelected:N,onFileDrop:Z,onTextChange:$,reprocessCurrentInput:U,handleConfirmImport:m}=yb(n);Dn(async()=>{await w()});async function K(){const M=await m();M&&(e("success",{docId:M}),e("close"))}function E(){e("close")}return(M,F)=>(tt(),nt("div",{class:"spm-modal-overlay",onClick:Ee(E,["self"])},[g("div",kb,[g("div",{class:"spm-dialog-header"},[F[18]||(F[18]=g("div",{class:"spm-dialog-title"},[g("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[g("use",{"xlink:href":"#iconSlidev"})]),g("span",null,"导入 Slidev 演示文档")],-1)),g("button",{class:"spm-close-btn",title:"关闭",onClick:E},"✕")]),g("div",wb,[g("button",{class:It(["spm-tab-btn",{active:ht(o)==="file"}]),onClick:F[0]||(F[0]=O=>o.value="file")}," 📦 文件 / 压缩包导入 (.zip / .md) ",2),g("button",{class:It(["spm-tab-btn",{active:ht(o)==="text"}]),onClick:F[1]||(F[1]=O=>o.value="text")}," 📝 粘贴 Markdown 源码 ",2)]),g("div",xb,[ht(o)==="file"?(tt(),nt("div",_b,[g("div",{class:It(["spm-dropzone",{dragover:ht(s),"has-file":!!ht(c)}]),onDragover:F[4]||(F[4]=Ee(O=>s.value=!0,["prevent"])),onDragleave:F[5]||(F[5]=Ee(O=>s.value=!1,["prevent"])),onDrop:F[6]||(F[6]=Ee((...O)=>ht(Z)&&ht(Z)(...O),["prevent"])),onClick:F[7]||(F[7]=(...O)=>ht(L)&&ht(L)(...O))},[g("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:F[2]||(F[2]=(...O)=>ht(N)&&ht(N)(...O))},null,544),ht(c)?(tt(),nt("div",Cb,[g("span",$b,"📄 "+xt(ht(c)),1),g("span",Ib,"("+xt(ht(A))+")",1),g("button",{class:"spm-btn-text",onClick:F[3]||(F[3]=Ee((...O)=>ht(B)&&ht(B)(...O),["stop"]))},"更换文件")])):(tt(),nt("div",Sb,[...F[19]||(F[19]=[g("span",{class:"spm-dropzone-icon"},"📁",-1),g("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1),g("p",{class:"spm-dropzone-hint"},[co(" 支持 Slidev 完整工程 "),g("strong",null,".zip"),co("（自动解包 public/ 静态素材）或单文件 "),g("strong",null,".md")],-1)])]))],34)])):(tt(),nt("div",Ab,[Te(g("textarea",{"onUpdate:modelValue":F[8]||(F[8]=O=>Yt(d)?d.value=O:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:F[9]||(F[9]=(...O)=>ht($)&&ht($)(...O))},null,544),[[ho,ht(d)]])])),ht(r)?(tt(),nt("div",Tb," ⚠️ "+xt(ht(r)),1)):Lt("",!0),ht(v)?(tt(),nt("div",Bb,[F[31]||(F[31]=g("div",{class:"spm-preview-card__header"},[g("span",null,"✨ 演示解析摘要"),g("span",{class:"spm-badge-success"},"预检就绪")],-1)),g("div",Eb,[g("div",Mb,[F[20]||(F[20]=g("label",{class:"spm-form-label"},"笔记文档标题",-1)),Te(g("input",{"onUpdate:modelValue":F[10]||(F[10]=O=>Yt(f)?f.value=O:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[ho,ht(f)]])]),g("div",Db,[F[21]||(F[21]=g("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Te(g("select",{"onUpdate:modelValue":F[11]||(F[11]=O=>Yt(p)?p.value=O:null),class:"spm-select"},[(tt(!0),nt(Kt,null,ye(ht(k),O=>(tt(),nt("option",{key:O.id,value:O.id},xt(O.name),9,Lb))),128))],512),[[Eu,ht(p)]])])]),g("div",Rb,[g("div",Pb,[g("span",Ob,xt(ht(v).totalSlides),1),F[22]||(F[22]=g("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),g("div",zb,[g("span",Nb,xt(ht(I)),1),F[23]||(F[23]=g("span",{class:"spm-stat-label"},"演示主题",-1))]),g("div",Fb,[g("span",jb,xt(ht(v).stats.totalNotes),1),F[24]||(F[24]=g("span",{class:"spm-stat-label"},"演讲者提词",-1))]),g("div",Hb,[g("span",Ub,xt(ht(u)),1),F[25]||(F[25]=g("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),ht(T).length>0?(tt(),nt("div",Wb,[F[26]||(F[26]=g("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(tt(!0),nt(Kt,null,ye(ht(T),O=>(tt(),nt("span",{key:O.name,class:"spm-chip-badge"},xt(O.name)+": "+xt(O.count),1))),128))])):Lt("",!0),g("div",Vb,[g("label",Kb,[Te(g("input",{"onUpdate:modelValue":F[12]||(F[12]=O=>Yt(b)?b.value=O:null),type:"checkbox",onChange:F[13]||(F[13]=(...O)=>ht(U)&&ht(U)(...O))},null,544),[[Un,ht(b)]]),F[27]||(F[27]=g("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),g("label",qb,[Te(g("input",{"onUpdate:modelValue":F[14]||(F[14]=O=>Yt(y)?y.value=O:null),type:"checkbox",onChange:F[15]||(F[15]=(...O)=>ht(U)&&ht(U)(...O))},null,544),[[Un,ht(y)]]),F[28]||(F[28]=g("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),g("label",Gb,[Te(g("input",{"onUpdate:modelValue":F[16]||(F[16]=O=>Yt(x)?x.value=O:null),type:"checkbox"},null,512),[[Un,ht(x)]]),F[29]||(F[29]=g("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),g("label",Zb,[Te(g("input",{"onUpdate:modelValue":F[17]||(F[17]=O=>Yt(_)?_.value=O:null),type:"checkbox"},null,512),[[Un,ht(_)]]),F[30]||(F[30]=g("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Lt("",!0)]),g("div",Yb,[g("button",{class:"spm-btn-secondary",disabled:ht(l),onClick:E}," 取消 ",8,Jb),g("button",{class:"spm-btn-primary",disabled:!ht(v)||ht(l),onClick:K},[ht(l)?(tt(),nt("span",Qb,"⏳ 正在导入生成中...")):(tt(),nt("span",t1,"🚀 确认导入思源笔记"))],8,Xb)])])]))}}),i1=Oe(e1,[["__scopeId","data-v-59ad789d"]]);function da(t){return t?t==="NodeThematicBreak"||t==="tb"||t==="thematic-break":!1}function n1(t,i){var r;if(!t||t.length===0)return null;const e=i.activeBlockId||"",n=i.currentTopBlockId||e,o=i.currentPageDividerId||"",s=i.activeBlockType||"";if(da(s)&&e){let a=t.find(c=>c.startBlockId===e);if(a||(a=t.find(c=>{var d,u;return((u=(d=c.blocks)==null?void 0:d[0])==null?void 0:u.id)===e}),a)||(a=t.find(c=>{var d;return(d=c.allBlockIds)==null?void 0:d.includes(e)}),a))return a}if(o){let a=t.find(c=>c.startBlockId===o);if(a||(a=t.find(c=>{var d,u;return((u=(d=c.blocks)==null?void 0:d[0])==null?void 0:u.id)===o}),a))return a}if(e){let a=t.find(d=>d.startBlockId===e);if(a||(a=t.find(d=>{var u,v;return((u=d.blocks)==null?void 0:u.some(f=>f.id===e))||((v=d.allBlockIds)==null?void 0:v.includes(e))}),a)||n&&n!==e&&(a=t.find(d=>{var u,v;return((u=d.blocks)==null?void 0:u.some(f=>f.id===n))||((v=d.allBlockIds)==null?void 0:v.includes(n))}),a)||(a=t.find(d=>{var u;return(u=d.noteBlocks)==null?void 0:u.some(v=>v.id===e||v.id===n)}),a))return a;const c=(r=i.activeBlockAttrs)==null?void 0:r[Tt];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=t.find(d=>{var u,v;return((u=d.frontmatter)==null?void 0:u.layout)==="three-cols-header"||((v=d.blocks)==null?void 0:v.some(f=>f.slot==="col-1"||f.slot==="col-2"||f.slot==="col-3"))}),a))return a}return t[0]||null}function Ar(t,i){const e=(t.blocks||[]).filter(l=>{const r=(l.content||l.rawMarkdown||"").trim();return r&&r!=="---"});if(e.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],o=[];for(const l of e){const r=(l.content||l.rawMarkdown||"").trim();r&&(l.type==="h"||r.startsWith("#")?n.push(r.replace(/^#+\s*/,"")):o.push(r.slice(0,50)))}const s=[];return n.length>0&&s.push(`【核心重点】：${n.join("、")}`),o.length>0&&(s.push("【口播要点】："),o.slice(0,3).forEach((l,r)=>{s.push(`${r+1}. 讲解 ${l}`)})),s.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),s.join(`
`)}async function ua(t,i){const e=t.blocks&&t.blocks.length>0?t.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(t.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(i&&e){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${e}`;try{const o=await i(n);if(o&&o.trim())return{notes:o.trim(),isAiGenerated:!0}}catch(o){return{notes:Ar(t),isAiGenerated:!1,error:(o==null?void 0:o.message)||"AI 调用异常"}}}return{notes:Ar(t),isAiGenerated:!1}}async function o1(t,i){return(await ua(t,i)).notes}function s1(t){let i=null;function e(E="已同步"){t.saveStatus.value=E,i&&(typeof window<"u"?window.clearTimeout(i):clearTimeout(i));const M=()=>{t.saveStatus.value=""};typeof window<"u"?i=window.setTimeout(M,1200):i=setTimeout(M,1200)}async function n(E){const M=t.activeBlockId.value||t.currentDocId.value;if(M){for(const[F,O]of Object.entries(E))t.activeBlockAttrs.value[F]=O;if(Pt.setBlockAttrOverride(M,E),ie(M,E),dt in E){const F=E[dt];t.currentPageDividerLayout.value=F,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=F)}if(Zt in E){const F=E[Zt];t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=F)}e("保存中...");try{await Rt(M,E),e("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{e("同步失败")}}}async function o(E,M){const F=t.activeBlockId.value||t.currentDocId.value;if(F){t.activeBlockAttrs.value[E]=M,Pt.setBlockAttrOverride(F,{[E]:M}),ie(F,{[E]:M}),E===dt&&(t.currentPageDividerLayout.value=M,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=M)),E===Zt&&t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=M),e("保存中...");try{await Rt(F,{[E]:M}),e("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{e("同步失败")}}}function s(){const E=t.activeBlockType.value==="NodeThematicBreak"||t.activeBlockType.value==="NodeThematicBreakBlock"||t.activeBlockType.value==="hr"||t.activeBlockType.value==="thematicbreak";return t.currentPageDividerId.value||(E?t.activeBlockId.value:"")||t.currentDocId.value}async function l(E,M){const F=s();if(F){F===t.activeBlockId.value&&(t.activeBlockAttrs.value[E]=M),Pt.setBlockAttrOverride(F,{[E]:M}),ie(F,{[E]:M}),E===dt&&(t.currentPageDividerLayout.value=M,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=M)),E===Zt&&t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=M),e("保存中...");try{await Rt(F,{[E]:M}),e("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{e("同步失败")}}}async function r(E,M){const F=s();if(!F)return;const O={[dt]:E,[Zt]:M};F===t.activeBlockId.value&&(t.activeBlockAttrs.value[dt]=E,t.activeBlockAttrs.value[Zt]=M),t.currentPageDividerLayout.value=E,Pt.setBlockAttrOverride(F,O),ie(F,O),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=E,t.targetSlide.value.frontmatter.layoutRatio=M),e("应用排版中...");try{await Rt(F,O),e("已应用分栏与比例"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{e("应用失败")}}async function a(E,M){var O;const F=t.currentDocId.value||t.activeBlockId.value;if(F){t.activeBlockAttrs.value[E]=M,Pt.setBlockAttrOverride(F,{[E]:M}),ie(F,{[E]:M}),(O=t.latestDoc.value)!=null&&O.config&&(E===bn&&(t.latestDoc.value.config.theme=M),E===yn&&(t.latestDoc.value.config.aspectRatio=M),E===kn&&(t.latestDoc.value.config.defaultTransition=M)),e("更新中...");try{await Rt(F,{[E]:M}),e("已更新"),t.plugin&&await t.plugin.compileCurrentDocument(F)}catch{e("更新失败")}}}async function c(){(t.videoAutoplay.value?"false":"true")==="true"?(await n({[Ii]:"true",[Ni]:"true"}),t.activeBlockAttrs.value[Ii]="true",t.activeBlockAttrs.value[Ni]="true"):(await o(Ii,"false"),t.activeBlockAttrs.value[Ii]="false")}async function d(){const E=t.videoLoop.value?"false":"true";await o(Qn,E)}async function u(){const E=t.videoMuted.value?"false":"true";await o(Ni,E)}async function v(){const E=t.videoControls.value?"false":"true";await o(to,E)}async function f(E){var j;const M=t.activeBlockId.value;if(!M)return;const F=t.rawSnippet.value||"",O=mi(F)||"",J=t.currentPageDividerId.value||t.currentDocId.value;if(E)if(E==="background"){const q={[Vt]:"background",[dt]:""};J&&O&&(t.pageBackground.value=O,await Rt(J,{[Ht]:O}).catch(()=>{}),Pt.setBlockAttrOverride(J,{[Ht]:O}),ie(J,{[Ht]:O}),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.background=O)),await n(q)}else(E===eo||E===io)&&await n({[dt]:E,[Vt]:""});else{const q={[Vt]:"",[dt]:""};if(t.activeBlockAttrs.value[Ht]==="true"&&(q[Ht]=""),J&&O&&t.pageBackground.value===O&&(t.pageBackground.value="",await Rt(J,{[Ht]:""}).catch(()=>{}),Pt.setBlockAttrOverride(J,{[Ht]:""}),ie(J,{[Ht]:""}),(j=t.targetSlide.value)!=null&&j.frontmatter&&delete t.targetSlide.value.frontmatter.background),await n(q),typeof document<"u"){const rt=document.querySelector(`.protyle-wysiwyg [data-node-id="${M}"]`),lt=rt==null?void 0:rt.closest('[data-type="NodeListItem"]'),st=lt==null?void 0:lt.getAttribute("data-node-id");if(st&&st!==M){const Q={[dt]:"",[Vt]:""};ie(st,Q),Pt.setBlockAttrOverride(st,Q),await Rt(st,Q).catch(()=>{})}}}}async function k(E){var st,Q,pt,bt,X,ut,vt,D;const O=`> [!NOTE] 💡 演讲备注
${(E||"在此输入本页讲稿提词...").split(/\r?\n/).map(z=>`> ${z}`).join(`
`)}
{: custom-slidev-note="true"}`,J=((st=t.latestDoc.value)==null?void 0:st.slides)||[],j=t.targetSlide.value,q=j?J.findIndex(z=>z===j):-1;let rt=null;if(q!==-1&&q<J.length-1){const z=J[q+1];rt=await rn("markdown",O,z.startBlockId)}else{const z=((Q=j==null?void 0:j.noteBlocks)==null?void 0:Q.slice(-1)[0])||((pt=j==null?void 0:j.blocks)==null?void 0:pt.slice(-1)[0]),h=(z==null?void 0:z.id)||(j==null?void 0:j.startBlockId);h?rt=await rn("markdown",O,void 0,h):rt=await Mr("markdown",O,t.currentDocId.value)}const lt=((ut=(X=(bt=rt==null?void 0:rt[0])==null?void 0:bt.doOperations)==null?void 0:X[0])==null?void 0:ut.id)||((vt=rt==null?void 0:rt[0])==null?void 0:vt.id);return lt&&(await Rt(lt,{[se]:"true"}),Pt.setBlockAttrOverride(lt,{[se]:"true"}),Mi(lt,(D=t.plugin)==null?void 0:D.app)),t.plugin&&await t.plugin.compileCurrentDocument(),lt}async function p(){const E=t.activeBlockId.value;if(E)if(t.isNoteBlock.value){e("取消中...");try{await Rt(E,{[se]:"","slidev-note":""}),Pt.setBlockAttrOverride(E,{[se]:"","slidev-note":""}),ie(E,{[se]:"","slidev-note":""}),delete t.activeBlockAttrs.value[se],delete t.activeBlockAttrs.value["slidev-note"],e("已取消备注"),mt.showMessage("已取消讲稿备注"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(M){console.error("[SiYuanSlidev] 取消讲稿备注失败:",M),e("取消失败"),mt.showMessage("取消讲稿备注失败")}}else{e("转换中...");try{let M=t.rawSnippet.value;try{const j=await Ha(E);j!=null&&j.kramdown&&(M=j.kramdown)}catch{}const J=`> [!NOTE] 💡 演讲备注
${(jr(M)||M.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(j=>`> ${j}`).join(`
`)}
{: custom-slidev-note="true"}`;await Hs("markdown",J,E),await Rt(E,{[se]:"true"}),Pt.setBlockAttrOverride(E,{[se]:"true"}),ie(E,{[se]:"true"}),t.activeBlockAttrs.value[se]="true",t.activeBlockType.value="NodeCallout",e("已设为讲稿备注"),mt.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(M){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",M),e("设置失败"),mt.showMessage("转为讲稿备注提示块失败")}}}async function b(){try{await k(),mt.showMessage("已在正文末尾插入讲稿备注提示块")}catch(E){mt.showMessage("插入讲稿备注块失败"),console.error(E)}}function y(){var F;const E=t.currentSlideNoteBlockId.value;if(!E){mt.showMessage("未找到本页关联的讲稿备注块");return}Mi(E,(F=t.plugin)==null?void 0:F.app)?mt.showMessage("已在编辑区定位讲稿备注块"):mt.showMessage("定位讲稿备注块失败")}async function x(){var F;if(!t.currentDocId.value)return;const E=t.targetSlide.value||{startBlockId:t.activeBlockId.value||t.currentDocId.value,blocks:t.rawSnippet.value&&t.rawSnippet.value!=="---"?[{id:t.activeBlockId.value,type:t.activeBlockType.value,content:t.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:t.rawSnippet.value&&t.rawSnippet.value!=="---"?t.rawSnippet.value:""};mt.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const M=await ua(E,Dr);if(M.notes){const O=t.currentSlideNoteBlockId.value;if(O){const J=`> [!NOTE] 💡 演讲备注
${M.notes.split(/\r?\n/).map(j=>`> ${j}`).join(`
`)}
{: custom-slidev-note="true"}`;await Hs("markdown",J,O),await Rt(O,{[se]:"true"}),Pt.setBlockAttrOverride(O,{[se]:"true"}),Mi(O,(F=t.plugin)==null?void 0:F.app)}else await k(M.notes);M.isAiGenerated?mt.showMessage("思源 AI 演讲提词卡生成成功！"):mt.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),t.plugin&&await t.plugin.compileCurrentDocument()}}function _(){t.elemClick.value?o($e,""):o($e,"+1")}function A(E){o($e,E)}function I(E){o(We,E)}function T(E){(t.activeBlockAttrs.value[Tt]||"")===E?o(Tt,""):o(Tt,E)}function w(E){t.elemShikiLines.value=E,o(Di,E)}function L(E){t.elemMaxHeight.value=E,o(wn,E)}async function B(){const E=t.currentSlideLayout.value==="three-cols-header";await o(Tt,E?"col-1":"left"),mt.showMessage(E?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function N(){const E=t.activeBlockId.value;if(!E)return;const M={[$e]:"",[We]:"",[Tt]:"",[Di]:"",[wn]:"",[se]:"","slidev-note":"",[dt]:"",[Zt]:"",[Vt]:"",[Qt]:"",[Ht]:"",[Be]:"",[Ii]:"",[Qn]:"",[Ni]:"",[to]:""};if(ie(E,M),await Rt(E,M),Pt.clearBlockAttrOverride(E),typeof document<"u"){const F=document.querySelector(`.protyle-wysiwyg [data-node-id="${E}"]`),O=F==null?void 0:F.closest('[data-type="NodeListItem"]'),J=O==null?void 0:O.getAttribute("data-node-id");J&&J!==E&&(ie(J,M),await Rt(J,M).catch(()=>{}),Pt.clearBlockAttrOverride(J))}t.activeBlockAttrs.value={},t.elemShikiLines.value="",t.elemMaxHeight.value="",t.pageBackground.value="",t.pageImage.value="",mt.showMessage("已清除本块演示属性"),t.plugin&&await t.plugin.compileCurrentDocument()}async function Z(){if(t.activeBlockId.value)try{await rn("markdown","---",t.activeBlockId.value,void 0),mt.showMessage("已在上方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{mt.showMessage("插入分页符失败")}}async function $(){const E=t.activeBlockId.value||t.currentDocId.value;if(E)try{await rn("markdown","---",void 0,E),mt.showMessage("已在下方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{mt.showMessage("插入分页符失败")}}async function U(){if(t.activeBlockId.value)try{await ja(t.activeBlockId.value),mt.showMessage("已删除该分页符"),t.activeBlockId.value="",t.activeBlockType.value="",t.plugin&&t.plugin.compileCurrentDocument()}catch{mt.showMessage("删除失败")}}function m(){if(!t.latestDoc.value){mt.showMessage("请先在主编辑区打开幻灯片文档");return}const E=sa(t.latestDoc.value);ra("presentation.html",E)&&mt.showMessage("已开始下载单文件离线 HTML 演示包")}function K(){if(!t.latestDoc.value){mt.showMessage("请先在主编辑区打开幻灯片文档");return}la(t.latestDoc.value)&&mt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return{triggerSaveNotice:e,saveAttrs:n,saveAttr:o,savePageAttr:l,applyPageLayoutAndRatio:r,saveDocAttr:a,onToggleVideoAutoplay:c,onToggleVideoLoop:d,onToggleVideoMuted:u,onToggleVideoControls:v,onImageRoleChange:f,onToggleNoteBlock:p,createNoteBlockOnCurrentSlide:k,onAddNoteBlock:b,onLocateNoteBlock:y,onGenerateNotesWithAI:x,toggleElemClick:_,onElemClickStepChange:A,onElemMotionChange:I,onElemSlotChange:T,onElemShikiLinesChange:w,onElemMaxHeightChange:L,onSetTwoColsContrast:B,onClearBlockAttrs:N,onInsertDividerBefore:Z,onInsertDividerAfter:$,onDeleteCurrentBlock:U,onExportHtml:m,onExportPdf:K}}const r1={class:"spm-slidev-inspector"},l1={class:"spm-inspector-topbar"},a1={class:"spm-inspector-title"},c1={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},d1={class:"spm-inspector-topbar-actions"},u1={class:"spm-target-banner"},f1={class:"spm-target-info"},p1=["aria-label"],h1={key:0,class:"spm-save-status"},m1=["title"],g1={class:"spm-inspector-body"},v1=xe({__name:"SlidevInspectorDockView",setup(t,{expose:i}){const e=Qe("plugin"),n=ft(!1);function o(et){n.value=!1,c.value=et.docId,e!=null&&e.compileCurrentDocument&&e.compileCurrentDocument(et.docId)}const s=ft(""),l=ft(""),r=ft({}),a=ft(""),c=ft(""),d=ft(""),u=ft(""),v=ft(""),f=ft(null),k=ft(""),p=ft("");function b(){var yt;const et=s.value||c.value;et&&typeof navigator<"u"&&(yt=navigator==null?void 0:navigator.clipboard)!=null&&yt.writeText&&navigator.clipboard.writeText(et).then(()=>{p.value="已复制！",setTimeout(()=>{p.value=""},1500)}).catch(()=>{})}const y=_t(()=>da(l.value)),x=_t(()=>l.value==="NodeCodeBlock"),_=ft(!1),A=_t(()=>{if(_.value||W.value)return!0;const et=a.value||"";return!!mi(et)}),I=_t(()=>{const et=l.value||"";if(et==="NodeVideo"||et==="video")return!0;const yt=a.value||"";return!!(/<video\b/i.test(yt)||/\.mp4\b/i.test(yt))}),T=_t(()=>!s.value||s.value===c.value||l.value==="doc"||l.value==="NodeDocument"),w=_t(()=>{const et=s.value||c.value||"";return et.length>8?et.slice(-8):et||"无"}),L=_t(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),B=_t(()=>{if(y.value)return"分页符 (---)";if(T.value)return"全局文档";if(I.value)return"视频块";switch(l.value){case"NodeHeading":return"标题块";case"NodeParagraph":return"段落块";case"NodeCodeBlock":return"代码块";case"NodeVideo":return"视频块";case"NodeList":case"NodeListItem":return"列表项";case"NodeBlockquote":return"引述块";case"NodeTable":return"表格块";case"NodeSuperBlock":case"s":case"sb":return"超级块";default:return"内容块"}}),N=_t(()=>y.value?"tag-divider":T.value?"tag-doc":"tag-block"),Z=_t(()=>r.value[dt]||"default"),$=_t(()=>r.value[Qt]||"slide-left"),U=ft(""),m=ft(""),K=_t(()=>r.value[cn]||"inherit"),E=_t(()=>{var et;return n1((et=f.value)==null?void 0:et.slides,{activeBlockId:s.value,activeBlockType:l.value,currentTopBlockId:d.value,currentPageDividerId:u.value,activeBlockAttrs:r.value})}),M=_t(()=>{var et;return((et=E.value)==null?void 0:et.notes)||""}),F=_t(()=>{var et,yt,$t;return(($t=(yt=(et=E.value)==null?void 0:et.noteBlocks)==null?void 0:yt[0])==null?void 0:$t.id)||""}),O=_t(()=>{var Et,Ft,Dt,de,On,ai;if(y.value){const Xt=r.value[dt]||r.value["custom-slidev-layout"];if(Xt)return Xt}const et=r.value[Tt]||r.value["custom-slidev-slot"];if(et&&(["col-1","col-2","col-3"].includes(et)||/^col-\d+$/.test(et)))return"cols-header";if(v.value)return v.value;const yt=u.value||(y.value?s.value:"");if(yt){const Xt=Pt.getBlockAttrOverride(yt);if(Xt!=null&&Xt[dt])return Xt[dt]}if(yt&&((Et=f.value)!=null&&Et.slides)){const Xt=f.value.slides.find(Pi=>Pi.startBlockId===yt);if((Ft=Xt==null?void 0:Xt.frontmatter)!=null&&Ft.layout)return Xt.frontmatter.layout}if((de=(Dt=E.value)==null?void 0:Dt.frontmatter)!=null&&de.layout)return E.value.frontmatter.layout;if((ai=(On=E.value)==null?void 0:On.blocks)!=null&&ai.some(Xt=>Xt.slot&&(["col-1","col-2","col-3"].includes(Xt.slot)||/^col-\d+$/.test(Xt.slot))))return"cols-header";const $t=Pt.getBlockAttrOverride(c.value);return $t!=null&&$t[dt]?$t[dt]:"default"}),J=_t(()=>{var yt,$t;if(y.value){const Et=r.value[Zt]||r.value["custom-slidev-layout-ratio"];if(Et)return Et}const et=u.value||(y.value?s.value:"");if(et){const Et=Pt.getBlockAttrOverride(et);if(Et!=null&&Et[Zt])return Et[Zt]}return(($t=(yt=E.value)==null?void 0:yt.frontmatter)==null?void 0:$t.layoutRatio)||""});function j(et){if(!et||(et.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const $t=Array.from(et.querySelectorAll(":scope > [data-node-id]"));if($t.length<2)return null;const Et=$t.length,Ft=$t.map(ai=>{const Xt=ai.getAttribute("style")||"",Pi=Xt.match(/calc\(\s*([\d.]+)%/);if(Pi)return parseFloat(Pi[1]);const tn=Xt.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return tn?parseFloat(tn[1]):null});let Dt="",de=!1;if(Ft.some(ai=>ai!==null)){de=!0;const ai=Ft.reduce((Bt,ue)=>Bt+(ue||0),0),Xt=Ft.filter(Bt=>Bt===null).length,Pi=Xt>0?Math.max(0,100-ai)/Xt:100/$t.length,tn=Ft.map(Bt=>Bt!==null?Bt:Pi),Ea=tn.reduce((Bt,ue)=>Bt+ue,0)||1,en=tn.map(Bt=>Bt/Ea*100);if(en.length===2){const[Bt]=en;if(Bt>=48&&Bt<=52)Dt="1:1";else if(Bt>=31&&Bt<=35)Dt="1:2";else if(Bt>=65&&Bt<=69)Dt="2:1";else if(Bt>=28&&Bt<=32)Dt="3:7";else if(Bt>=68&&Bt<=72)Dt="7:3";else if(Bt>=38&&Bt<=42)Dt="4:6";else if(Bt>=58&&Bt<=62)Dt="6:4";else{const ue=Math.round(Bt);Dt=`${ue}:${100-ue}`}}else if(en.length===3){const[Bt,ue,ci]=en;if(Bt>=31&&Bt<=35&&ue>=31&&ue<=35&&ci>=31&&ci<=35)Dt="1:1:1";else if(Bt>=23&&Bt<=27&&ue>=48&&ue<=52&&ci>=23&&ci<=27)Dt="1:2:1";else if(Bt>=48&&Bt<=52&&ue>=23&&ue<=27&&ci>=23&&ci<=27)Dt="2:1:1";else if(Bt>=23&&Bt<=27&&ue>=23&&ue<=27&&ci>=48&&ci<=52)Dt="1:1:2";else{const Fs=Math.round(Bt),js=Math.round(ue);Dt=`${Fs}:${js}:${100-Fs-js}`}}else Dt=en.map(Bt=>Math.round(Bt)).join(":")}else de=!1,Dt=Array.from({length:Et},()=>1).join(":");const On=Et>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:Et,ratio:Dt,isCustomWidth:de,recommendedLayout:On}}function q(et){if(!(et!=null&&et.blocks))return null;for(const yt of et.blocks){const $t=yt.rawNode;if($t&&oe($t)&&ii($t)){const Ft=Bn($t).length,Dt=ds($t);return{hasSuperBlock:!0,colCount:Ft,ratio:Dt||Array.from({length:Ft},()=>1).join(":"),isCustomWidth:!!Dt,recommendedLayout:Ft>=2?"cols-header":"two-cols"}}}return null}const rt=_t(()=>{var et;if(typeof document<"u"){const yt=s.value;if(yt){const Et=document.querySelector(`.protyle-wysiwyg [data-node-id="${yt}"]`);if(Et){const Ft=Et.getAttribute("data-type")==="NodeSuperBlock"?Et:Et.closest('[data-type="NodeSuperBlock"]');if(Ft){const Dt=j(Ft);if(Dt)return Dt}}}const $t=u.value||(y.value?s.value:"");if($t){const Et=document.querySelector(`.protyle-wysiwyg [data-node-id="${$t}"]`);if(Et){let Ft=Et.nextElementSibling;for(;Ft&&!(Ft.getAttribute("data-type")==="NodeThematicBreak"||(et=Ft.classList)!=null&&et.contains("protyle-wysiwyg__block--hr"));){const Dt=Ft.getAttribute("data-type")==="NodeSuperBlock"?Ft:Ft.querySelector('[data-type="NodeSuperBlock"]');if(Dt){const de=j(Dt);if(de)return de}Ft=Ft.nextElementSibling}}}else{const Et=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Ft=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Dt of Ft)if(!Et||Dt.compareDocumentPosition(Et)&Node.DOCUMENT_POSITION_FOLLOWING){const de=j(Dt);if(de)return de}}}return q(E.value)}),lt=_t(()=>{var et;return((et=rt.value)==null?void 0:et.ratio)||""}),st=_t(()=>{const et=l.value||"";if(et==="NodeSuperBlock"||et==="s"||et==="sb")return!0;if(typeof document<"u"&&s.value){const yt=document.querySelector(`.protyle-wysiwyg [data-node-id="${s.value}"]`);if(yt!=null&&yt.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),Q=_t(()=>{var et;return((et=E.value)==null?void 0:et.pageIndex)||1}),pt=_t(()=>!!(r.value[se]||r.value["slidev-note"])),bt=_t(()=>{var yt;if(r.value[$e])return r.value[$e];const et=s.value;if(et&&((yt=E.value)!=null&&yt.blocks)){const $t=E.value.blocks.find(Et=>Et.id===et);if($t!=null&&$t.clicks)return $t.clicks}return""}),X=_t(()=>{var yt;if(r.value[We])return r.value[We];const et=s.value;if(et&&((yt=E.value)!=null&&yt.blocks)){const $t=E.value.blocks.find(Et=>Et.id===et);if($t!=null&&$t.motion)return typeof $t.motion=="string"?$t.motion:JSON.stringify($t.motion)}return""}),ut=_t(()=>{var yt;if(r.value[Tt])return r.value[Tt];const et=s.value;if(et&&((yt=E.value)!=null&&yt.blocks)){const $t=E.value.blocks.find(Et=>Et.id===et);if($t!=null&&$t.slot)return $t.slot}return""}),vt=ft(""),D=ft(""),z=_t(()=>r.value[Ii]==="true"),h=_t(()=>r.value[Qn]==="true"),H=_t(()=>r.value[Ni]==="true"),P=_t(()=>r.value[to]!=="false"),S=_t(()=>{var et,yt;return((yt=(et=f.value)==null?void 0:et.config)==null?void 0:yt.theme)||r.value[bn]||"default"}),C=_t(()=>{var et,yt;return((yt=(et=f.value)==null?void 0:et.config)==null?void 0:yt.aspectRatio)||r.value[yn]||"16/9"}),R=_t(()=>{var et,yt;return((yt=(et=f.value)==null?void 0:et.config)==null?void 0:yt.defaultTransition)||r.value[kn]||"slide-left"}),G=_t(()=>{var et,yt;return((yt=(et=f.value)==null?void 0:et.config)==null?void 0:yt.spacing)||r.value[qo]||"normal"}),W=_t(()=>{var Ft,Dt;if((r.value[Vt]||r.value["slidev-role"])===Or||r.value[Ht]==="true")return"background";const yt=r.value[dt]||r.value["slidev-layout"];if(yt==="image-left"||yt==="image-right")return yt;const $t=a.value||"",Et=mi($t);if(Et&&((Dt=(Ft=E.value)==null?void 0:Ft.frontmatter)!=null&&Dt.background)){const de=E.value.frontmatter.background;if(de===Et||de.endsWith(Et)||Et.endsWith(de))return"background"}return""}),V=_t(()=>!!(r.value[$e]||r.value[We]||r.value[Tt]||r.value[Di]||r.value[se]||r.value["slidev-note"]||r.value[Vt]||r.value[dt]||r.value[Ii]||r.value[Qn]||r.value[Ni]||r.value[to])),{saveAttr:Y,savePageAttr:ot,applyPageLayoutAndRatio:it,saveDocAttr:at,onToggleVideoAutoplay:St,onToggleVideoLoop:kt,onToggleVideoMuted:Mt,onToggleVideoControls:qt,onImageRoleChange:Gt,onToggleNoteBlock:ne,onAddNoteBlock:Nt,onLocateNoteBlock:Ke,onGenerateNotesWithAI:ee,toggleElemClick:Jt,onElemClickStepChange:bi,onElemMotionChange:Li,onElemSlotChange:Ao,onElemShikiLinesChange:To,onElemMaxHeightChange:Pn,onSetTwoColsContrast:yi,onClearBlockAttrs:Ri,onInsertDividerBefore:ha,onInsertDividerAfter:Os,onDeleteCurrentBlock:ma,onExportHtml:ga,onExportPdf:va}=s1({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:u,currentPageDividerLayout:v,latestDoc:f,targetSlide:E,currentSlideNoteBlockId:F,currentSlideLayout:O,isNoteBlock:pt,elemClick:bt,videoAutoplay:z,videoLoop:h,videoMuted:H,videoControls:P,pageBackground:U,pageImage:m,elemShikiLines:vt,elemMaxHeight:D,saveStatus:k,plugin:e});function ba(et){Y(dt,et)}function ya(et){ot(Zt,et)}function zs(et){if(!et)return;const yt=et.recommendedLayout||(et.colCount&&et.colCount>=2?"cols-header":"two-cols"),$t=et.ratio||(et.colCount?Array(et.colCount).fill(1).join(":"):"1:1");it(yt,$t)}function ka(et){ot(Zt,et)}function wa(et){Y(Qt,et)}function xa(et){U.value=et,Y(Ht,et)}function _a(et){m.value=et,Y(Be,et)}function Sa(et){Y(cn,et==="inherit"?"":et)}function Ca(et){at(bn,et)}function $a(et){at(yn,et)}function Ia(et){at(kn,et)}function Aa(et){at(qo,et)}function Ns(){e!=null&&e.openBottomPreviewTab&&e.openBottomPreviewTab()}function Ta(){typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function Ba(){e!=null&&e.executeCommand&&e.executeCommand("slidevAiSplit")}return i({setActiveBlock(et){s.value=et.id,l.value=et.type,r.value={...et.attrs},a.value=et.content||et.markdown||"",d.value=et.topBlockId||et.id,u.value=et.pageDividerId||"",v.value=et.pageDividerLayout||"",et.rootId?c.value=et.rootId:(et.type==="doc"||et.type==="NodeDocument")&&et.id&&(c.value=et.id),U.value=et.attrs[Ht]||"",m.value=et.attrs[Be]||"",vt.value=et.attrs[Di]||"",D.value=et.attrs[wn]||"",_.value=!!et.isImage},updateDocument(et){f.value=et,c.value=et.docId},openImportDialog(){n.value=!0},setCurrentDocId(et){c.value=et}}),(et,yt)=>(tt(),nt("div",r1,[g("div",l1,[g("div",a1,[(tt(),nt("svg",c1,[...yt[2]||(yt[2]=[g("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),g("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),g("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),yt[3]||(yt[3]=g("span",null,"演示配置",-1))]),g("div",d1,[g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:yt[0]||(yt[0]=$t=>n.value=!0)},[ct(gt,{name:"import"}),yt[4]||(yt[4]=g("span",null,"导入",-1))]),g("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:Ns},[ct(gt,{name:"split-preview"}),yt[5]||(yt[5]=g("span",null,"分屏预览",-1))])])]),g("div",u1,[g("div",f1,[g("span",{class:It(["spm-target-tag",N.value])},xt(B.value),3),g("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":p.value||"点击复制 ID: "+(s.value||c.value),onClick:b},[ct(gt,{name:"copy"}),g("span",null,"#"+xt(w.value),1)],8,p1)]),k.value?(tt(),nt("span",h1,"● "+xt(k.value),1)):Lt("",!0)]),L.value?(tt(),nt("div",{key:0,class:"spm-context-quote",title:a.value},xt(L.value),9,m1)):Lt("",!0),g("div",g1,[y.value?(tt(),Me(Um,{key:0,"page-layout":Z.value,"page-layout-ratio":J.value,"detected-sb-ratio":lt.value,"detected-sb-info":rt.value,"page-transition":$.value,"page-background":U.value,"page-spacing":K.value,"page-image":m.value,"page-notes":M.value,"page-index":Q.value,"onUpdate:pageLayout":ba,"onUpdate:pageLayoutRatio":ya,onApplySuperBlockLayout:zs,"onUpdate:pageTransition":wa,"onUpdate:pageBackground":xa,"onUpdate:pageSpacing":Sa,"onUpdate:pageImage":_a,onAddNoteBlock:ht(Nt),onLocateNoteBlock:ht(Ke),onGenerateNotes:ht(ee),onInsertDividerAfter:ht(Os),onDeleteDivider:ht(ma)},null,8,["page-layout","page-layout-ratio","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onInsertDividerAfter","onDeleteDivider"])):s.value&&!T.value?(tt(),Me(xv,{key:1,"elem-click":bt.value,"elem-motion":X.value,"elem-slot":ut.value,"elem-shiki-lines":vt.value,"elem-max-height":D.value,"is-code-block":x.value,"is-image":A.value,"is-video":I.value,"is-super-block":st.value,"detected-sb-info":rt.value,"video-autoplay":z.value,"video-loop":h.value,"video-muted":H.value,"video-controls":P.value,"has-block-attrs":V.value,"is-note":pt.value,"image-role":W.value,"current-slide-layout":O.value,onToggleNote:ht(ne),onToggleElemClick:ht(Jt),onToggleVideoAutoplay:ht(St),onToggleVideoLoop:ht(kt),onToggleVideoMuted:ht(Mt),onToggleVideoControls:ht(qt),"onUpdate:imageRole":ht(Gt),"onUpdate:elemClick":ht(bi),"onUpdate:elemMotion":ht(Li),"onUpdate:elemSlot":ht(Ao),"onUpdate:elemShikiLines":ht(To),"onUpdate:elemMaxHeight":ht(Pn),onApplySuperBlockLayout:zs,onApplySuperBlockRatio:ka,onInsertDividerBefore:ht(ha),onInsertDividerAfter:ht(Os),onSetTwoColsContrast:ht(yi),onClearBlockAttrs:ht(Ri)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(tt(),Me(tb,{key:2,"doc-theme":S.value,"doc-aspect-ratio":C.value,"doc-default-transition":R.value,"doc-spacing":G.value,"onUpdate:docTheme":Ca,"onUpdate:docAspectRatio":$a,"onUpdate:docDefaultTransition":Ia,"onUpdate:docSpacing":Aa,onOpenBottomPreview:Ns,onOpenPresenter:Ta,onAiAutoSplit:Ba,onExportHtml:ht(ga),onExportPdf:ht(va)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf"]))]),n.value?(tt(),Me(i1,{key:1,onClose:yt[1]||(yt[1]=$t=>n.value=!1),onSuccess:o})):Lt("",!0)]))}}),Rn=new Ls;let pi=null,Ue=null;function b1(t,i){pi&&fa(),pi=Yl(qh),pi.provide("plugin",i),pi.provide("sandboxBridge",Rn);const e=pi.mount(t);return Ue=e,e}function fa(t){pi&&(pi.unmount(),pi=null,Ue=null)}let hi=null,we=null;function y1(t,i){hi&&pa(),hi=Yl(v1),hi.provide("plugin",i),hi.provide("sandboxBridge",Rn);const e=hi.mount(t);return we=e,e}function pa(t){hi&&(hi.unmount(),hi=null,we=null)}function k1(t,i){we!=null&&we.updateDocument&&we.updateDocument(t),Ue!=null&&Ue.updateDocument?Ue.updateDocument(t,i):Rn.updateSlides(t.slides,t.config,t.fullMarkdown)}function as(t){Ue!=null&&Ue.navigateToBlock?Ue.navigateToBlock(t):Rn.highlightElement(t)}function Jn(t){we!=null&&we.setActiveBlock&&we.setActiveBlock(t)}function w1(){return we!=null&&we.openImportDialog?(we.openImportDialog(),!0):!1}function x1(t,i){const e=[];let o=0;for(let s=0;s<t.length;s++){const l=t[s];if(no(l)){o=0;continue}const r=l.markdown||l.content||"";if(!(s===0)){if(l.type==="h"&&(l.subType==="h1"||r.startsWith("# "))){e.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),o=0;continue}if(l.type==="h"&&(l.subType==="h2"||r.startsWith("## "))){e.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),o=0;continue}}if(o++,o>=6&&s<t.length-1){const c=t[s+1];no(c)||(e.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),o=0)}}return e}const _1=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:$i,value:"true"},{key:dt,value:"cover"},{key:Qt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:$i,value:"true"},{key:dt,value:"two-cols"},{key:Qt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:$i,value:"true"},{key:dt,value:"fact"},{key:Qt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:$i,value:"true"},{key:dt,value:"intro"},{key:Qt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:$i,value:"true"},{key:dt,value:"quote"},{key:Qt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:$e,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:$e,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Tt,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Di,value:"1-3"}]}];class Vo{getPresetTemplates(){return _1}buildScanSlidevBlocksSql(i="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${i}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${Qt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(i,e,n,o){const s=`SELECT block_id FROM attributes WHERE name = '${Qt}' AND value = '${i}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{[Qt]:e}),r++)}return{updatedCount:r}}async batchUpdateLayout(i,e,n,o){const s=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${i}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{"custom-slidev-layout":e}),r++)}return{updatedCount:r}}exportTemplatesJson(){const i=this.getPresetTemplates();return JSON.stringify({templates:i,counter:i.length},null,2)}formatTransitionSummary(i){return!i||i.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${i.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function S1(t){t.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{t.openBottomPreviewTab()}}),t.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{w1()||mt.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),t.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const i=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(i==null?void 0:i.getAttribute("data-doc-id"))||""}t.currentDocId&&(await Rt(t.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),mt.showMessage("已为当前文档初始化 Slidev 演示属性"),t.compileCurrentDocument(t.currentDocId))}}),t.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const s=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}if(!t.currentDocId){mt.showMessage("请先打开一篇思源笔记文档");return}const i=await Xn(t.currentDocId).catch(()=>[]);if(!i||i.length===0){mt.showMessage("当前文档无内容，无需断页");return}const e=i.map(s=>({id:s.id,type:s.type,subType:s.subType,content:s.content||"",markdown:s.markdown||""})),n=x1(e);if(n.length===0){mt.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}mt.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const s of n)try{await rn("markdown","---",void 0,s.blockId),await Rt(s.blockId,{"custom-slidev-layout":s.recommendedLayout}),o++}catch(l){console.warn("Failed to insert divider:",l)}mt.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,d,u;if(!t.currentDocId){const v=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(v==null?void 0:v.getAttribute("data-doc-id"))||""}if(!t.currentDocId){mt.showMessage("请先打开一篇思源笔记文档");return}mt.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const i=await Xn(t.currentDocId).catch(()=>[]),e={startBlockId:t.currentDocId,blocks:i.map(v=>({id:v.id,type:v.type,content:v.content||"",rawMarkdown:v.markdown||""})),rawMarkdown:""},s=`> [!NOTE] 💡 演讲备注
${(await o1(e,Dr)).split(/\r?\n/).map(v=>`> ${v}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await Mr("markdown",s,t.currentDocId).catch(()=>null),r=((d=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:d.id)||((u=l==null?void 0:l[0])==null?void 0:u.id);r&&(await Rt(r,{"custom-slidev-note":"true"}),Pt.setBlockAttrOverride(r,{"custom-slidev-note":"true"}),Mi(r,t.app)),mt.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new Vo,e=i.buildTransitionStatsSql(),n=await vn(e).catch(()=>[]),o=i.formatTransitionSummary(n||[]);mt.showMessage(o)}}),t.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const e=new Vo().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(e),mt.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):mt.showMessage(`已生成模板数据（请在控制台查看）：
`+e)}}),t.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const e=await new Vo().batchUpdateTransitions("fade","slide-left",n=>vn(n).catch(()=>[]),(n,o)=>Rt(n,o));mt.showMessage(`全库批量替换完成：已将 ${e.updatedCount} 处 fade 转场更新为 slide-left`),t.compileCurrentDocument()}}),t.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),t.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){mt.showMessage("请先打开并放映一篇思源笔记文档");return}t.cliBridge.downloadSlidesMd(t.latestCompiledDoc,`slides-${t.currentDocId||"demo"}.md`)&&mt.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),t.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{mt.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await t.cliBridge.probeServer(1500)?mt.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):mt.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),t.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){mt.showMessage("请先打开并放映一篇思源笔记文档");return}const i=await t.cliBridge.syncToWorkspaceFile(t.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",Ko);i.success?mt.showMessage(`已成功同步最新 slides.md 至工作空间：${i.path}`):mt.showMessage(`同步失败：${i.error}`)}})}class C1{getActiveDocumentId(){if(typeof document>"u")return"";const i=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),e=i==null?void 0:i.getAttribute("data-node-id");if(e)return e;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=document.querySelector("[data-doc-id]"),l=s==null?void 0:s.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(i,e=""){const n=i.closest(".protyle-title"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=i.closest(".protyle"),l=s==null?void 0:s.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=i.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||e}async switchToDocGlobalInspector(i,e){var s;if(!i)return;let n=e||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${i}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${i}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((s=l==null?void 0:l.innerText)==null?void 0:s.trim())||""}const o=await Ge(i).catch(()=>({}));Jn({id:i,rootId:i,type:"doc",content:n,attrs:o,isDivider:!1,isCode:!1}),as(i)}handleBlockClickedFromSlide(i,e,n,o){var a;if(!i)return!1;const s=Mi(i,e),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`),r=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,i,r,n,o);else{let c="",d="";if(o!=null&&o.slides){const u=o.slides.find(v=>{var f,k,p;return v.startBlockId===i||((f=v.blocks)==null?void 0:f.some(b=>b.id===i))||((k=v.allBlockIds)==null?void 0:k.includes(i))||((p=v.noteBlocks)==null?void 0:p.some(b=>b.id===i))});u!=null&&u.startBlockId&&(c=u.startBlockId),(a=u==null?void 0:u.frontmatter)!=null&&a.layout&&(d=u.frontmatter.layout)}Ge(i).then(async u=>{if(c&&!d){const v=Pt.getBlockAttrOverride(c);if(v!=null&&v[dt]||v!=null&&v["custom-slidev-layout"])d=v[dt]||v["custom-slidev-layout"]||"";else{const f=await Ge(c).catch(()=>({}))||{};d=f[dt]||f["custom-slidev-layout"]||"",f&&Object.keys(f).length>0&&Pt.setBlockAttrOverride(c,f)}}Jn({id:i,rootId:n,type:r||"NodeParagraph",attrs:u||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return s}async syncInspectorBlock(i,e,n,o,s){var $,U,m,K,E,M,F,O;let l=i,r=e,a=n;const c=i.closest('[data-type="NodeCallout"]');if(c&&c!==i){const J=c.getAttribute("data-node-id");if(J){const j=await Ge(J).catch(()=>({}))||{},q=Pt.getBlockAttrOverride(J)||{},rt={...j,...q};(rt[se]||rt["slidev-note"])&&(l=c,r=J,a="NodeCallout")}}const d=l.closest(".protyle-wysiwyg > [data-node-id]")||l,u=(d==null?void 0:d.getAttribute("data-node-id"))||r,v=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(d==null?void 0:d.getAttribute("data-type"))==="NodeThematicBreak"||(d==null?void 0:d.getAttribute("data-type"))==="tb"||!!(($=d==null?void 0:d.classList)!=null&&$.contains("hr")),f=a==="NodeCodeBlock",k=((U=l.innerText)==null?void 0:U.trim())||"",p=await Ge(r).catch(()=>({}))||{},b=Pt.getBlockAttrOverride(r)||{},y={...p,...b};let x="",_="";if(v)x=r,_=y[dt]||y["custom-slidev-layout"]||"";else{let J=d.previousElementSibling;for(;J;){const j=J.getAttribute("data-type");if(j==="NodeThematicBreak"||j==="tb"||(m=J.classList)!=null&&m.contains("hr")){x=J.getAttribute("data-node-id")||"";break}J=J.previousElementSibling}}if(s!=null&&s.slides){const J=[r,u];let j=l.parentElement;for(;j&&!j.classList.contains("protyle-wysiwyg");){const rt=j.getAttribute("data-node-id");rt&&!J.includes(rt)&&J.push(rt),j=j.parentElement}const q=s.slides.find(rt=>{var lt,st,Q;return J.includes(rt.startBlockId)||((lt=rt.blocks)==null?void 0:lt.some(pt=>J.includes(pt.id)))||((st=rt.allBlockIds)==null?void 0:st.some(pt=>J.includes(pt)))||((Q=rt.noteBlocks)==null?void 0:Q.some(pt=>J.includes(pt.id)))});q&&(!x&&q.startBlockId&&(x=q.startBlockId),!_&&((K=q.frontmatter)!=null&&K.layout)&&(_=q.frontmatter.layout))}if(x){const J=Pt.getBlockAttrOverride(x);if(J&&(dt in J||"custom-slidev-layout"in J)&&(_=J[dt]||J["custom-slidev-layout"]||""),!_&&(s!=null&&s.slides)){const j=s.slides.find(q=>q.startBlockId===x);(E=j==null?void 0:j.frontmatter)!=null&&E.layout&&(_=j.frontmatter.layout)}if(!_){const j=await Ge(x).catch(()=>({}))||{};_=j[dt]||j["custom-slidev-layout"]||"",j&&Object.keys(j).length>0&&Pt.setBlockAttrOverride(x,j)}ie(x,{[dt]:_||""})}else if(o){const J=Pt.getBlockAttrOverride(o);J&&(dt in J||"custom-slidev-layout"in J)?_=J[dt]||J["custom-slidev-layout"]||"":!_&&((O=(F=(M=s==null?void 0:s.slides)==null?void 0:M[0])==null?void 0:F.frontmatter)!=null&&O.layout)&&(_=s.slides[0].frontmatter.layout)}const A=l.getAttribute(dt)||l.getAttribute("custom-slidev-layout"),I=y[dt]||y["custom-slidev-layout"]||"";A&&A!==I&&ie(r,{[dt]:I});const T=l.getAttribute(Vt)||l.getAttribute("custom-slidev-role"),w=y[Vt]||y["custom-slidev-role"]||"";T&&T!==w&&ie(r,{[Vt]:w});const L=l.closest('[data-type="NodeListItem"]');if(L&&L!==l){const J=L.getAttribute("data-node-id");if(J){const j=await Ge(J).catch(()=>({}))||{},q=Pt.getBlockAttrOverride(J)||{},rt={...j,...q},lt=rt[dt]||rt["custom-slidev-layout"]||"",st=L.getAttribute(dt)||L.getAttribute("custom-slidev-layout");st&&st!==lt&&ie(J,{[dt]:lt});const Q=rt[Vt]||rt["custom-slidev-role"]||"",pt=L.getAttribute(Vt)||L.getAttribute("custom-slidev-role");pt&&pt!==Q&&ie(J,{[Vt]:Q})}}const B=!!l.querySelector("img, span[data-type='img']"),N=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),Z=B&&N.length<=50;Jn({id:r,rootId:o,type:a,content:k,attrs:y,isDivider:v,isCode:f,isImage:Z,topBlockId:u,pageDividerId:x,pageDividerLayout:_})}patchThematicBreakTransactions(i){if((i==null?void 0:i.cmd)==="transactions"&&Array.isArray(i.data)){for(const e of i.data)if(Array.isArray(e==null?void 0:e.doOperations)){for(const n of e.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const o=n.data.old||{},s=n.data.new||{},l={};for(const r of Object.keys(o))r in s||(l[r]="");for(const[r,a]of Object.entries(s))l[r]=String(a??"");ie(n.id,l),Pt.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidevAttrs(i){var o,s,l;if(typeof document>"u"||!i)return;const e=new Map;if(Array.isArray(i.slides))for(const r of i.slides){if(r.startBlockId){const a=e.get(r.startBlockId)||{};(o=r.frontmatter)!=null&&o.layout&&(a[dt]=r.frontmatter.layout),e.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=e.get(a.id)||{};(s=a.ial)!=null&&s[dt]&&(c[dt]=a.ial[dt]),(l=a.ial)!=null&&l[Vt]&&(c[Vt]=a.ial[Vt]),Object.keys(c).length>0&&e.set(a.id,c)}}}const n=Pt.getAllAttrOverrides();for(const[r,a]of n.entries()){const c=e.get(r)||{};a[dt]!==void 0&&(c[dt]=a[dt]),a[Vt]!==void 0&&(c[Vt]=a[Vt]),e.set(r,c)}Qf(e)}}const Si=new C1,$1=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,I1="slidev-dock",Tr="slidev-preview-tab",Br=Up;class A1 extends mt.Plugin{constructor(){super(...arguments);wt(this,"isMobile",!1);wt(this,"currentDocId","");wt(this,"latestCompiledDoc",null);wt(this,"cliBridge",new us);wt(this,"debounceTimer",null);wt(this,"activeCursorBlockId","");wt(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));wt(this,"onWsMainBound",this.onWsMain.bind(this));wt(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));wt(this,"onClickEditorTitleIconBound",this.onClickEditorTitleIcon.bind(this));wt(this,"onEditorClickBound",this.onEditorClick.bind(this));wt(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));wt(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this))}async onload(){const e=mt.getFrontend();this.isMobile=e==="mobile"||e==="browser-mobile",await this.loadGlobalSettings(),this.addIcons($1),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"Slidev 演示 (下方分屏)",position:"right",callback:()=>{this.openBottomPreviewTab()}}),S1(this);const n=this;if(this.addTab({type:Tr,init(){b1(this.element,n)},destroy(){fa(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:I1,init(){y1(this.element,n)},destroy(){pa(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(o,s)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${o}`,{detail:s}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound)),typeof document<"u"){const o=()=>{const s=this.getActiveDocumentId();s&&(s!==this.currentDocId&&(this.currentDocId=s),this.latestCompiledDoc||this.compileCurrentDocument(s))};setTimeout(o,300),setTimeout(o,1e3)}}async onDataChanged(e){await this.loadGlobalSettings(),this.currentDocId&&await this.compileCurrentDocument(this.currentDocId)}async loadGlobalSettings(){try{const e=await this.loadData(Br),n=Wp(e);return qi(n),n}catch{return qi(Ji),Ji}}async saveGlobalSettings(e){const n=Ps(),o=qi({...n,...e||{}});try{await this.saveData(Br,o)}catch(s){console.error("保存 Slidev 全局配置失败",s)}return o}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound)),Rn.detach()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),await mt.openTab({app:this.app,custom:{id:this.name+Tr,title:"Slidev 演示预览",icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId)}onClickEditorTitleIcon(e){var l;const n=e.detail,o=n==null?void 0:n.menu,s=((l=n==null?void 0:n.data)==null?void 0:l.id)||this.currentDocId;!o||!s||o.addItem({icon:"iconSlidev",label:"Slidev 全局演示配置",submenu:[{label:"初始化演示属性 (custom-slidev-*)",click:async()=>{await Rt(s,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),mt.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(s)}},{type:"separator"},{label:"主题: 默认 (default)",click:async()=>{await Rt(s,{"custom-slidev-theme":"default"}),mt.showMessage("已切换为 default 主题"),this.compileCurrentDocument(s)}},{label:"主题: 优雅衬线 (seriph)",click:async()=>{await Rt(s,{"custom-slidev-theme":"seriph"}),mt.showMessage("已切换为 seriph 主题"),this.compileCurrentDocument(s)}},{label:"主题: 苹果极简 (apple-basic)",click:async()=>{await Rt(s,{"custom-slidev-theme":"apple-basic"}),mt.showMessage("已切换为 apple-basic 主题"),this.compileCurrentDocument(s)}},{type:"separator"},{label:"画幅: 16 / 9 (宽屏)",click:async()=>{await Rt(s,{"custom-slidev-aspect-ratio":"16/9"}),mt.showMessage("已切换画幅为 16/9"),this.compileCurrentDocument(s)}},{label:"画幅: 4 / 3 (标屏)",click:async()=>{await Rt(s,{"custom-slidev-aspect-ratio":"4/3"}),mt.showMessage("已切换画幅为 4/3"),this.compileCurrentDocument(s)}}]})}async onSwitchProtyle(e){var s,l;const n=(s=e.detail)==null?void 0:s.protyle,o=(l=n==null?void 0:n.block)==null?void 0:l.rootID;if(o&&o!==this.currentDocId){this.currentDocId=o,this.activeCursorBlockId=o;const r=await Ge(o).catch(()=>({}));Jn({id:o,rootId:o,type:"doc",attrs:r}),this.compileCurrentDocument(o)}}onClickEditorContent(e){var s,l;const n=e==null?void 0:e.detail;if(!n)return;const o=(l=(s=n.protyle)==null?void 0:s.block)==null?void 0:l.rootID;o&&(!this.currentDocId||this.currentDocId!==o)&&(this.currentDocId=o),n.event&&this.onEditorClick(n.event)}getActiveDocumentId(){return Si.getActiveDocumentId()}resolveDocIdFromElement(e){return Si.resolveDocIdFromElement(e,this.currentDocId)}async switchToDocGlobalInspector(e,n){e&&(this.activeCursorBlockId=e,this.currentDocId=e,await Si.switchToDocGlobalInspector(e,n))}onWsMain(e){const n=e.detail;n&&(Si.patchThematicBreakTransactions(n),this.debounceTimer&&window.clearTimeout(this.debounceTimer),this.debounceTimer=window.setTimeout(()=>{this.compileCurrentDocument()},150))}handleBlockClickedFromSlide(e,n){return e?(this.activeCursorBlockId=e,Si.handleBlockClickedFromSlide(e,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(e){const n=(e==null?void 0:e.detail)||e;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(e){const n=e.target;if(!n)return;const o=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(o||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const u=o||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),v=u==null?void 0:u.querySelector(".protyle-title__input"),f=((v==null?void 0:v.innerText)||(u==null?void 0:u.innerText)||"").trim();this.switchToDocGlobalInspector(d,f)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const a=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,as(a)),this.syncInspectorBlock(r,a,c))}onSelectionChange(){if(typeof window>"u")return;const e=window.getSelection();if(!e||e.rangeCount===0)return;const n=e.anchorNode;if(!n)return;const o=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!o)return;const s=o.closest(".protyle-title");if(!!(s||o.closest(".protyle-content")&&!o.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(o);if(d&&this.activeCursorBlockId!==d){const u=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),v=u==null?void 0:u.querySelector(".protyle-title__input"),f=((v==null?void 0:v.innerText)||(u==null?void 0:u.innerText)||"").trim();this.switchToDocGlobalInspector(d,f)}return}if(!o.closest(".protyle-wysiwyg"))return;const r=o.closest("[data-node-id]"),a=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";r&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(o)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,as(a)),this.syncInspectorBlock(r,a,c))}async syncInspectorBlock(e,n,o){await Si.syncInspectorBlock(e,n,o,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(e){let n=e||this.currentDocId;if(!n){const o=this.getActiveDocumentId();if(o)this.currentDocId=o,n=o;else return}try{const o=await Pt.compile(n);this.latestCompiledDoc=o,k1(o,n),this.purgeStaleDomSlidevAttrs(o)}catch(o){console.error("[SiYuanSlidev] Failed to compile document:",o)}}purgeStaleDomSlidevAttrs(e){Si.purgeStaleDomSlidevAttrs(e)}}module.exports=A1;
