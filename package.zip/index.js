"use strict";var sd=Object.defineProperty;var rd=(e,t,o)=>t in e?sd(e,t,{enumerable:!0,configurable:!0,writable:!0,value:o}):e[t]=o;var $e=(e,t,o)=>rd(e,typeof t!="symbol"?t+"":t,o);const ae=require("siyuan");async function Tt(e,t){const o=await ae.fetchSyncPost(e,t);return o.code===0?o.data:null}async function ld(){return Tt("/api/notebook/lsNotebooks","")}async function ad(e,t,o){return Tt("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:o})}async function Sl(e,t){const o=new FormData;o.append("assetsDirPath",e);for(const n of t)o.append("file[]",n);return Tt("/api/asset/upload",o)}async function Uo(e,t,o,i,n){return Tt("/api/block/insertBlock",{dataType:e,data:t,nextID:o,previousID:i,parentID:n})}async function bs(e,t,o){return Tt("/api/block/appendBlock",{dataType:e,data:t,parentID:o})}async function vs(e,t,o){return Tt("/api/block/updateBlock",{dataType:e,data:t,id:o})}async function Fs(e){return Tt("/api/block/deleteBlock",{id:e})}async function cd(e){return Tt("/api/block/getBlockKramdown",{id:e})}async function bi(e){return Tt("/api/block/getChildBlocks",{id:e})}async function dd(e){return Tt("/api/block/getDocBlocksOrders",{id:e})}async function ze(e,t){return Tt("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function js(e){return Tt("/api/attr/getBlockAttrs",{id:e})}async function pi(e){return Tt("/api/query/sql",{stmt:e})}async function Cl(e){const t="/api/ai/chatGPT";try{const o=await Tt(t,{msg:e});return typeof o=="string"&&o.trim().length>0?o.trim():o&&typeof o.content=="string"&&o.content.trim().length>0?o.content.trim():null}catch{return null}}async function ud(){return Tt("/api/storage/getInlineStyles","")}function vr(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function _l(e){const t={};if(!e)return t;const o=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),i=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let n;for(;(n=i.exec(o))!==null;){const s=n[1],l=n[2]??n[3]??n[4]??"";t[s]=l}return t}const Il=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function fd(e){const t=[];if(!e)return t;const o=new RegExp(Il.source,"g");let i;for(;(i=o.exec(e))!==null;){const n=i[2]??i[3]??i[4];t.push({fullMatch:i[0],blockId:i[1],anchorText:n?n.trim():void 0})}return t}function hd(e,t){if(!e)return"";const o=new RegExp(Il.source,"g");return e.replace(o,(i,n,s,l,r)=>{const a=(s??l??r??"").trim();if(t&&t[n]){const u=t[n].trim();return`<div class="slides-block-ref" data-ref-id="${n}">${u}</div>`}const c=a||`Ref(${n.slice(0,8)})`;return`<a href="siyuan://blocks/${n}" data-ref-id="${n}" class="slides-ref-tag">🔗 ${c}</a>`})}const ji="custom-slides-theme",Wi="custom-slides-aspect-ratio",Ui="custom-slides-default-transition",$l="custom-slides-color-schema",ks="custom-slides-spacing",wn="custom-slides-background",kr="custom-slides-show-unordered-list-markers",wr="custom-slides-show-ordered-list-markers",fo="custom-slides-slide",be="custom-slides-layout",wt="custom-slides-transition",ct="custom-slides-background",Ft="custom-slides-image",Jn="custom-slides-notes",ni="custom-slides-class",Bi="custom-slides-spacing",mt="custom-slides-layout-ratio",si="custom-slides-mask",qo="custom-slides-mask-ratio",ri="custom-slides-mask-style",li="custom-slides-mask-initial",Oe="custom-slides-click",$t="custom-slides-motion",Jo="custom-slides-shiki-lines",Me="custom-slides-slot",Ve="custom-slides-note",Ye="custom-slides-role",Vi="custom-slides-max-height",Wo="custom-slides-autoplay",xn="custom-slides-loop",ii="custom-slides-muted",Sn="custom-slides-controls",Ml="background",Cn="image-left",_n="image-right";function ai(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function pd(e,t=2){const o=t===4?[25,50,75,100]:[50,100],i=t===4?4:2;if(!e||typeof e!="string")return{steps:i,breakpoints:o};const n=e.trim();if(!n||t===4&&(n==="1:1"||n==="1"))return{steps:i,breakpoints:o};const s=n.split(":").map(y=>parseFloat(y.trim())).filter(y=>!isNaN(y)&&y>0);if(s.length===0)return{steps:i,breakpoints:o};if(s.length===1){const y=Math.min(100,Math.max(1,s[0]));return y===100?{steps:1,breakpoints:[100]}:{steps:2,breakpoints:[Math.round(y*100)/100,100]}}const l=s.every((y,d)=>d===0||y>s[d-1]),r=s[s.length-1];if(l&&(r===100||s.some(y=>y>10))){const y=s.map(d=>Math.min(100,Math.round(d*100)/100));return y[y.length-1]<100&&y.push(100),{steps:y.length,breakpoints:y}}const c=s.reduce((y,d)=>y+d,0);if(c<=0)return{steps:i,breakpoints:o};let u=0;const p=[];for(let y=0;y<s.length;y++)u+=s[y],y===s.length-1?p.push(100):p.push(Math.round(u/c*1e4)/100);return{steps:p.length,breakpoints:p}}function Tl(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function Al(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function Et(e,t){if(!Tl(e))return e;const o=Al(e);return t!=null&&t.base64Map&&t.base64Map[o]?t.base64Map[o]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${o}`:`/${o}`}function md(e,t){if(!e)return"";let o=e;return o=o.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(i,n,s)=>{const l=Et(s,t);return`![${n}](${l})`}),o=o.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(i,n,s,l)=>{const r=Et(s,t);return`${n}${r}${l}`}),o=o.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(i,n,s,l)=>{const r=Et(s,t);return`${n}${r}${l}`}),o}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Ws(e){const t=Object.create(null);for(const o of e.split(","))t[o]=1;return o=>o in t}const Ze={},ci=[],oo=()=>{},El=()=>!1,On=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),Pn=e=>e.startsWith("onUpdate:"),yt=Object.assign,Us=(e,t)=>{const o=e.indexOf(t);o>-1&&e.splice(o,1)},gd=Object.prototype.hasOwnProperty,je=(e,t)=>gd.call(e,t),Ae=Array.isArray,di=e=>Xi(e)==="[object Map]",vi=e=>Xi(e)==="[object Set]",xr=e=>Xi(e)==="[object Date]",De=e=>typeof e=="function",nt=e=>typeof e=="string",Ut=e=>typeof e=="symbol",qe=e=>e!==null&&typeof e=="object",Bl=e=>(qe(e)||De(e))&&De(e.then)&&De(e.catch),Dl=Object.prototype.toString,Xi=e=>Dl.call(e),yd=e=>Xi(e).slice(8,-1),Ll=e=>Xi(e)==="[object Object]",Vs=e=>nt(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,Di=Ws(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Nn=e=>{const t=Object.create(null);return(o=>t[o]||(t[o]=e(o)))},bd=/-\w/g,Mt=Nn(e=>e.replace(bd,t=>t.slice(1).toUpperCase())),vd=/\B([A-Z])/g,Ro=Nn(e=>e.replace(vd,"-$1").toLowerCase()),Rn=Nn(e=>e.charAt(0).toUpperCase()+e.slice(1)),Xn=Nn(e=>e?`on${Rn(e)}`:""),Xt=(e,t)=>!Object.is(e,t),un=(e,...t)=>{for(let o=0;o<e.length;o++)e[o](...t)},Ol=(e,t,o,i=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:i,value:o})},zn=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let Sr;const Hn=()=>Sr||(Sr=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function Qt(e){if(Ae(e)){const t={};for(let o=0;o<e.length;o++){const i=e[o],n=nt(i)?Sd(i):Qt(i);if(n)for(const s in n)t[s]=n[s]}return t}else if(nt(e)||qe(e))return e}const kd=/;(?![^(]*\))/g,wd=/:([^]+)/,xd=/\/\*[^]*?\*\//g;function Sd(e){const t={};return e.replace(xd,"").split(kd).forEach(o=>{if(o){const i=o.split(wd);i.length>1&&(t[i[0].trim()]=i[1].trim())}}),t}function xe(e){let t="";if(nt(e))t=e;else if(Ae(e))for(let o=0;o<e.length;o++){const i=xe(e[o]);i&&(t+=i+" ")}else if(qe(e))for(const o in e)e[o]&&(t+=o+" ");return t.trim()}const Cd="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",_d=Ws(Cd);function Pl(e){return!!e||e===""}function Id(e,t){if(e.length!==t.length)return!1;let o=!0;for(let i=0;o&&i<e.length;i++)o=ki(e[i],t[i]);return o}function ki(e,t){if(e===t)return!0;let o=xr(e),i=xr(t);if(o||i)return o&&i?e.getTime()===t.getTime():!1;if(o=Ut(e),i=Ut(t),o||i)return e===t;if(o=Ae(e),i=Ae(t),o||i)return o&&i?Id(e,t):!1;if(o=qe(e),i=qe(t),o||i){if(!o||!i)return!1;const n=Object.keys(e).length,s=Object.keys(t).length;if(n!==s)return!1;for(const l in e){const r=e.hasOwnProperty(l),a=t.hasOwnProperty(l);if(r&&!a||!r&&a||!ki(e[l],t[l]))return!1}}return String(e)===String(t)}function qs(e,t){return e.findIndex(o=>ki(o,t))}const Nl=e=>!!(e&&e.__v_isRef===!0),ve=e=>nt(e)?e:e==null?"":Ae(e)||qe(e)&&(e.toString===Dl||!De(e.toString))?Nl(e)?ve(e.value):JSON.stringify(e,Rl,2):String(e),Rl=(e,t)=>Nl(t)?Rl(e,t.value):di(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((o,[i,n],s)=>(o[Qn(i,s)+" =>"]=n,o),{})}:vi(t)?{[`Set(${t.size})`]:[...t.values()].map(o=>Qn(o))}:Ut(t)?Qn(t):qe(t)&&!Ae(t)&&!Ll(t)?String(t):t,Qn=(e,t="")=>{var o;return Ut(e)?`Symbol(${(o=e.description)!=null?o:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let pt;class $d{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&pt&&(pt.active?(this.parent=pt,this.index=(pt.scopes||(pt.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,o;if(this.scopes){const i=this.scopes.slice();for(t=0,o=i.length;t<o;t++)i[t].pause()}for(t=0,o=this.effects.length;t<o;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,o;if(this.scopes){const n=this.scopes.slice();for(t=0,o=n.length;t<o;t++)n[t].resume()}const i=this.effects.slice();for(t=0,o=i.length;t<o;t++)i[t].resume()}}run(t){if(this._active){const o=pt;try{return pt=this,t()}finally{pt=o}}}on(){++this._on===1&&(this.prevScope=pt,pt=this)}off(){if(this._on>0&&--this._on===0){if(pt===this)pt=this.prevScope;else{let t=pt;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let o,i;for(o=0,i=this.effects.length;o<i;o++)this.effects[o].stop();for(this.effects.length=0,o=0,i=this.cleanups.length;o<i;o++)this.cleanups[o]();if(this.cleanups.length=0,this.scopes){const n=this.scopes.slice();for(o=0,i=n.length;o<i;o++)n[o].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const n=this.parent.scopes.pop();n&&n!==this&&(this.parent.scopes[this.index]=n,n.index=this.index)}this.parent=void 0}}}function Md(){return pt}let Xe;const es=new WeakSet;class zl{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,pt&&(pt.active?pt.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,es.has(this)&&(es.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Fl(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Cr(this),jl(this);const t=Xe,o=jt;Xe=this,jt=!0;try{return this.fn()}finally{Wl(this),Xe=t,jt=o,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)Ys(t);this.deps=this.depsTail=void 0,Cr(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?es.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){ws(this)&&this.run()}get dirty(){return ws(this)}}let Hl=0,Li,Oi;function Fl(e,t=!1){if(e.flags|=8,t){e.next=Oi,Oi=e;return}e.next=Li,Li=e}function Gs(){Hl++}function Ks(){if(--Hl>0)return;if(Oi){let t=Oi;for(Oi=void 0;t;){const o=t.next;t.next=void 0,t.flags&=-9,t=o}}let e;for(;Li;){let t=Li;for(Li=void 0;t;){const o=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(i){e||(e=i)}t=o}}if(e)throw e}function jl(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function Wl(e){let t,o=e.depsTail,i=o;for(;i;){const n=i.prevDep;i.version===-1?(i===o&&(o=n),Ys(i),Td(i)):t=i,i.dep.activeLink=i.prevActiveLink,i.prevActiveLink=void 0,i=n}e.deps=t,e.depsTail=o}function ws(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(Ul(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function Ul(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===qi)||(e.globalVersion=qi,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!ws(e))))return;e.flags|=2;const t=e.dep,o=Xe,i=jt;Xe=e,jt=!0;try{jl(e);const n=e.fn(e._value);(t.version===0||Xt(n,e._value))&&(e.flags|=128,e._value=n,t.version++)}catch(n){throw t.version++,n}finally{Xe=o,jt=i,Wl(e),e.flags&=-3}}function Ys(e,t=!1){const{dep:o,prevSub:i,nextSub:n}=e;if(i&&(i.nextSub=n,e.prevSub=void 0),n&&(n.prevSub=i,e.nextSub=void 0),o.subs===e&&(o.subs=i,!i&&o.computed)){o.computed.flags&=-5;for(let s=o.computed.deps;s;s=s.nextDep)Ys(s,!0)}!t&&!--o.sc&&o.map&&o.map.delete(o.key)}function Td(e){const{prevDep:t,nextDep:o}=e;t&&(t.nextDep=o,e.prevDep=void 0),o&&(o.prevDep=t,e.nextDep=void 0)}let jt=!0;const Vl=[];function vo(){Vl.push(jt),jt=!1}function ko(){const e=Vl.pop();jt=e===void 0?!0:e}function Cr(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const o=Xe;Xe=void 0;try{t()}finally{Xe=o}}}let qi=0;class Ad{constructor(t,o){this.sub=t,this.dep=o,this.version=o.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class Zs{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!Xe||!jt||Xe===this.computed)return;let o=this.activeLink;if(o===void 0||o.sub!==Xe)o=this.activeLink=new Ad(Xe,this),Xe.deps?(o.prevDep=Xe.depsTail,Xe.depsTail.nextDep=o,Xe.depsTail=o):Xe.deps=Xe.depsTail=o,ql(o);else if(o.version===-1&&(o.version=this.version,o.nextDep)){const i=o.nextDep;i.prevDep=o.prevDep,o.prevDep&&(o.prevDep.nextDep=i),o.prevDep=Xe.depsTail,o.nextDep=void 0,Xe.depsTail.nextDep=o,Xe.depsTail=o,Xe.deps===o&&(Xe.deps=i)}return o}trigger(t){this.version++,qi++,this.notify(t)}notify(t){Gs();try{for(let o=this.subs;o;o=o.prevSub)o.sub.notify()&&o.sub.dep.notify()}finally{Ks()}}}function ql(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let i=t.deps;i;i=i.nextDep)ql(i)}const o=e.dep.subs;o!==e&&(e.prevSub=o,o&&(o.nextSub=e)),e.dep.subs=e}}const xs=new WeakMap,Go=Symbol(""),Ss=Symbol(""),Gi=Symbol("");function kt(e,t,o){if(jt&&Xe){let i=xs.get(e);i||xs.set(e,i=new Map);let n=i.get(o);n||(i.set(o,n=new Zs),n.map=i,n.key=o),n.track()}}function ho(e,t,o,i,n,s){const l=xs.get(e);if(!l){qi++;return}const r=a=>{a&&a.trigger()};if(Gs(),t==="clear")l.forEach(r);else{const a=Ae(e),c=a&&Vs(o);if(a&&o==="length"){const u=Number(i);l.forEach((p,y)=>{(y==="length"||y===Gi||!Ut(y)&&y>=u)&&r(p)})}else switch((o!==void 0||l.has(void 0))&&r(l.get(o)),c&&r(l.get(Gi)),t){case"add":a?c&&r(l.get("length")):(r(l.get(Go)),di(e)&&r(l.get(Ss)));break;case"delete":a||(r(l.get(Go)),di(e)&&r(l.get(Ss)));break;case"set":di(e)&&r(l.get(Go));break}}Ks()}function Qo(e){const t=Fe(e);return t===e?t:(kt(t,"iterate",Gi),zt(e)?t:t.map(Vt))}function Fn(e){return kt(e=Fe(e),"iterate",Gi),e}function Zt(e,t){return wo(e)?mi(Ko(e)?Vt(t):t):Vt(t)}const Ed={__proto__:null,[Symbol.iterator](){return ts(this,Symbol.iterator,e=>Zt(this,e))},concat(...e){return Qo(this).concat(...e.map(t=>Ae(t)?Qo(t):t))},entries(){return ts(this,"entries",e=>(e[1]=Zt(this,e[1]),e))},every(e,t){return lo(this,"every",e,t,void 0,arguments)},filter(e,t){return lo(this,"filter",e,t,o=>o.map(i=>Zt(this,i)),arguments)},find(e,t){return lo(this,"find",e,t,o=>Zt(this,o),arguments)},findIndex(e,t){return lo(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return lo(this,"findLast",e,t,o=>Zt(this,o),arguments)},findLastIndex(e,t){return lo(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return lo(this,"forEach",e,t,void 0,arguments)},includes(...e){return os(this,"includes",e)},indexOf(...e){return os(this,"indexOf",e)},join(e){return Qo(this).join(e)},lastIndexOf(...e){return os(this,"lastIndexOf",e)},map(e,t){return lo(this,"map",e,t,void 0,arguments)},pop(){return Ii(this,"pop")},push(...e){return Ii(this,"push",e)},reduce(e,...t){return _r(this,"reduce",e,t)},reduceRight(e,...t){return _r(this,"reduceRight",e,t)},shift(){return Ii(this,"shift")},some(e,t){return lo(this,"some",e,t,void 0,arguments)},splice(...e){return Ii(this,"splice",e)},toReversed(){return Qo(this).toReversed()},toSorted(e){return Qo(this).toSorted(e)},toSpliced(...e){return Qo(this).toSpliced(...e)},unshift(...e){return Ii(this,"unshift",e)},values(){return ts(this,"values",e=>Zt(this,e))}};function ts(e,t,o){const i=Fn(e),n=i[t]();return i!==e&&!zt(e)&&(n._next=n.next,n.next=()=>{const s=n._next();return s.done||(s.value=o(s.value)),s}),n}const Bd=Array.prototype;function lo(e,t,o,i,n,s){const l=Fn(e),r=l!==e&&!zt(e),a=l[t];if(a!==Bd[t]){const p=a.apply(e,s);return r?Vt(p):p}let c=o;l!==e&&(r?c=function(p,y){return o.call(this,Zt(e,p),y,e)}:o.length>2&&(c=function(p,y){return o.call(this,p,y,e)}));const u=a.call(l,c,i);return r&&n?n(u):u}function _r(e,t,o,i){const n=Fn(e),s=n!==e&&!zt(e);let l=o,r=!1;n!==e&&(s?(r=i.length===0,l=function(c,u,p){return r&&(r=!1,c=Zt(e,c)),o.call(this,c,Zt(e,u),p,e)}):o.length>3&&(l=function(c,u,p){return o.call(this,c,u,p,e)}));const a=n[t](l,...i);return r?Zt(e,a):a}function os(e,t,o){const i=Fe(e);kt(i,"iterate",Gi);const n=i[t](...o);return(n===-1||n===!1)&&Qs(o[0])?(o[0]=Fe(o[0]),i[t](...o)):n}function Ii(e,t,o=[]){vo(),Gs();const i=Fe(e)[t].apply(e,o);return Ks(),ko(),i}const Dd=Ws("__proto__,__v_isRef,__isVue"),Gl=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Ut));function Ld(e){Ut(e)||(e=String(e));const t=Fe(this);return kt(t,"has",e),t.hasOwnProperty(e)}class Kl{constructor(t=!1,o=!1){this._isReadonly=t,this._isShallow=o}get(t,o,i){if(o==="__v_skip")return t.__v_skip;const n=this._isReadonly,s=this._isShallow;if(o==="__v_isReactive")return!n;if(o==="__v_isReadonly")return n;if(o==="__v_isShallow")return s;if(o==="__v_raw")return i===(n?s?Ud:Xl:s?Jl:Zl).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(i)?t:void 0;const l=Ae(t);if(!n){let a;if(l&&(a=Ed[o]))return a;if(o==="hasOwnProperty")return Ld}const r=Reflect.get(t,o,ot(t)?t:i);if((Ut(o)?Gl.has(o):Dd(o))||(n||kt(t,"get",o),s))return r;if(ot(r)){const a=l&&Vs(o)?r:r.value;return n&&qe(a)?_s(a):a}return qe(r)?n?_s(r):jn(r):r}}class Yl extends Kl{constructor(t=!1){super(!1,t)}set(t,o,i,n){let s=t[o];const l=Ae(t)&&Vs(o);if(!this._isShallow){const c=wo(s);if(!zt(i)&&!wo(i)&&(s=Fe(s),i=Fe(i)),!l&&ot(s)&&!ot(i))return c||(s.value=i),!0}const r=l?Number(o)<t.length:je(t,o),a=Reflect.set(t,o,i,ot(t)?t:n);return t===Fe(n)&&a&&(r?Xt(i,s)&&ho(t,"set",o,i):ho(t,"add",o,i)),a}deleteProperty(t,o){const i=je(t,o);t[o];const n=Reflect.deleteProperty(t,o);return n&&i&&ho(t,"delete",o,void 0),n}has(t,o){const i=Reflect.has(t,o);return(!Ut(o)||!Gl.has(o))&&kt(t,"has",o),i}ownKeys(t){return kt(t,"iterate",Ae(t)?"length":Go),Reflect.ownKeys(t)}}class Od extends Kl{constructor(t=!1){super(!0,t)}set(t,o){return!0}deleteProperty(t,o){return!0}}const Pd=new Yl,Nd=new Od,Rd=new Yl(!0);const Cs=e=>e,nn=e=>Reflect.getPrototypeOf(e);function zd(e,t,o){return function(...i){const n=this.__v_raw,s=Fe(n),l=di(s),r=e==="entries"||e===Symbol.iterator&&l,a=e==="keys"&&l,c=n[e](...i),u=o?Cs:t?mi:Vt;return!t&&kt(s,"iterate",a?Ss:Go),yt(Object.create(c),{next(){const{value:p,done:y}=c.next();return y?{value:p,done:y}:{value:r?[u(p[0]),u(p[1])]:u(p),done:y}}})}}function sn(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function Hd(e,t){const o={get(n){const s=this.__v_raw,l=Fe(s),r=Fe(n);e||(Xt(n,r)&&kt(l,"get",n),kt(l,"get",r));const{has:a}=nn(l),c=t?Cs:e?mi:Vt;if(a.call(l,n))return c(s.get(n));if(a.call(l,r))return c(s.get(r));s!==l&&s.get(n)},get size(){const n=this.__v_raw;return!e&&kt(Fe(n),"iterate",Go),n.size},has(n){const s=this.__v_raw,l=Fe(s),r=Fe(n);return e||(Xt(n,r)&&kt(l,"has",n),kt(l,"has",r)),n===r?s.has(n):s.has(n)||s.has(r)},forEach(n,s){const l=this,r=l.__v_raw,a=Fe(r),c=t?Cs:e?mi:Vt;return!e&&kt(a,"iterate",Go),r.forEach((u,p)=>n.call(s,c(u),c(p),l))}};return yt(o,e?{add:sn("add"),set:sn("set"),delete:sn("delete"),clear:sn("clear")}:{add(n){const s=Fe(this),l=nn(s),r=Fe(n),a=!t&&!zt(n)&&!wo(n)?r:n;return l.has.call(s,a)||Xt(n,a)&&l.has.call(s,n)||Xt(r,a)&&l.has.call(s,r)||(s.add(a),ho(s,"add",a,a)),this},set(n,s){!t&&!zt(s)&&!wo(s)&&(s=Fe(s));const l=Fe(this),{has:r,get:a}=nn(l);let c=r.call(l,n);c||(n=Fe(n),c=r.call(l,n));const u=a.call(l,n);return l.set(n,s),c?Xt(s,u)&&ho(l,"set",n,s):ho(l,"add",n,s),this},delete(n){const s=Fe(this),{has:l,get:r}=nn(s);let a=l.call(s,n);a||(n=Fe(n),a=l.call(s,n)),r&&r.call(s,n);const c=s.delete(n);return a&&ho(s,"delete",n,void 0),c},clear(){const n=Fe(this),s=n.size!==0,l=n.clear();return s&&ho(n,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(n=>{o[n]=zd(n,e,t)}),o}function Js(e,t){const o=Hd(e,t);return(i,n,s)=>n==="__v_isReactive"?!e:n==="__v_isReadonly"?e:n==="__v_raw"?i:Reflect.get(je(o,n)&&n in i?o:i,n,s)}const Fd={get:Js(!1,!1)},jd={get:Js(!1,!0)},Wd={get:Js(!0,!1)};const Zl=new WeakMap,Jl=new WeakMap,Xl=new WeakMap,Ud=new WeakMap;function Vd(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function jn(e){return wo(e)?e:Xs(e,!1,Pd,Fd,Zl)}function qd(e){return Xs(e,!1,Rd,jd,Jl)}function _s(e){return Xs(e,!0,Nd,Wd,Xl)}function Xs(e,t,o,i,n){if(!qe(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const s=n.get(e);if(s)return s;const l=Vd(yd(e));if(l===0)return e;const r=new Proxy(e,l===2?i:o);return n.set(e,r),r}function Ko(e){return wo(e)?Ko(e.__v_raw):!!(e&&e.__v_isReactive)}function wo(e){return!!(e&&e.__v_isReadonly)}function zt(e){return!!(e&&e.__v_isShallow)}function Qs(e){return e?!!e.__v_raw:!1}function Fe(e){const t=e&&e.__v_raw;return t?Fe(t):e}function Gd(e){return!je(e,"__v_skip")&&Object.isExtensible(e)&&Ol(e,"__v_skip",!0),e}const Vt=e=>qe(e)?jn(e):e,mi=e=>qe(e)?_s(e):e;function ot(e){return e?e.__v_isRef===!0:!1}function pe(e){return Kd(e,!1)}function Kd(e,t){return ot(e)?e:new Yd(e,t)}class Yd{constructor(t,o){this.dep=new Zs,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=o?t:Fe(t),this._value=o?t:Vt(t),this.__v_isShallow=o}get value(){return this.dep.track(),this._value}set value(t){const o=this._rawValue,i=this.__v_isShallow||zt(t)||wo(t);t=i?t:Fe(t),Xt(t,o)&&(this._rawValue=t,this._value=i?t:Vt(t),this.dep.trigger())}}function he(e){return ot(e)?e.value:e}const Zd={get:(e,t,o)=>t==="__v_raw"?e:he(Reflect.get(e,t,o)),set:(e,t,o,i)=>{const n=e[t];return ot(n)&&!ot(o)?(n.value=o,!0):Reflect.set(e,t,o,i)}};function Ql(e){return Ko(e)?e:new Proxy(e,Zd)}class Jd{constructor(t,o,i){this.fn=t,this.setter=o,this._value=void 0,this.dep=new Zs(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=qi-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!o,this.isSSR=i}notify(){if(this.flags|=16,!(this.flags&8)&&Xe!==this)return Fl(this,!0),!0}get value(){const t=this.dep.track();return Ul(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function Xd(e,t,o=!1){let i,n;return De(e)?i=e:(i=e.get,n=e.set),new Jd(i,n,o)}const rn={},In=new WeakMap;let jo;function Qd(e,t=!1,o=jo){if(o){let i=In.get(o);i||In.set(o,i=[]),i.push(e)}}function eu(e,t,o=Ze){const{immediate:i,deep:n,once:s,scheduler:l,augmentJob:r,call:a}=o,c=C=>n?C:zt(C)||n===!1||n===0?po(C,1):po(C);let u,p,y,d,h=!1,m=!1;if(ot(e)?(p=()=>e.value,h=zt(e)):Ko(e)?(p=()=>c(e),h=!0):Ae(e)?(m=!0,h=e.some(C=>Ko(C)||zt(C)),p=()=>e.map(C=>{if(ot(C))return C.value;if(Ko(C))return c(C);if(De(C))return a?a(C,2):C()})):De(e)?t?p=a?()=>a(e,2):e:p=()=>{if(y){vo();try{y()}finally{ko()}}const C=jo;jo=u;try{return a?a(e,3,[d]):e(d)}finally{jo=C}}:p=oo,t&&n){const C=p,A=n===!0?1/0:n;p=()=>po(C(),A)}const g=Md(),b=()=>{u.stop(),g&&g.active&&Us(g.effects,u)};if(s&&t){const C=t;t=(...A)=>{const M=C(...A);return b(),M}}let k=m?new Array(e.length).fill(rn):rn;const w=C=>{if(!(!(u.flags&1)||!u.dirty&&!C))if(t){const A=u.run();if(C||n||h||(m?A.some((M,I)=>Xt(M,k[I])):Xt(A,k))){y&&y();const M=jo;jo=u;try{const I=[A,k===rn?void 0:m&&k[0]===rn?[]:k,d];k=A,a?a(t,3,I):t(...I)}finally{jo=M}}}else u.run()};return r&&r(w),u=new zl(p),u.scheduler=l?()=>l(w,!1):w,d=C=>Qd(C,!1,u),y=u.onStop=()=>{const C=In.get(u);if(C){if(a)a(C,4);else for(const A of C)A();In.delete(u)}},t?i?w(!0):k=u.run():l?l(w.bind(null,!0),!0):u.run(),b.pause=u.pause.bind(u),b.resume=u.resume.bind(u),b.stop=b,b}function po(e,t=1/0,o){if(t<=0||!qe(e)||e.__v_skip||(o=o||new Map,(o.get(e)||0)>=t))return e;if(o.set(e,t),t--,ot(e))po(e.value,t,o);else if(Ae(e))for(let i=0;i<e.length;i++)po(e[i],t,o);else if(vi(e)||di(e))e.forEach(i=>{po(i,t,o)});else if(Ll(e)){for(const i in e)po(e[i],t,o);for(const i of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,i)&&po(e[i],t,o)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Qi(e,t,o,i){try{return i?e(...i):e()}catch(n){Wn(n,t,o)}}function qt(e,t,o,i){if(De(e)){const n=Qi(e,t,o,i);return n&&Bl(n)&&n.catch(s=>{Wn(s,t,o)}),n}if(Ae(e)){const n=[];for(let s=0;s<e.length;s++)n.push(qt(e[s],t,o,i));return n}}function Wn(e,t,o,i=!0){const n=t?t.vnode:null,{errorHandler:s,throwUnhandledErrorInProduction:l}=t&&t.appContext.config||Ze;if(t){let r=t.parent;const a=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${o}`;for(;r;){const u=r.ec;if(u){for(let p=0;p<u.length;p++)if(u[p](e,a,c)===!1)return}r=r.parent}if(s){vo(),Qi(s,null,10,[e,a,c]),ko();return}}tu(e,o,n,i,l)}function tu(e,t,o,i=!0,n=!1){if(n)throw e;console.error(e)}const _t=[];let Kt=-1;const ui=[];let Mo=null,ti=0;const ea=Promise.resolve();let $n=null;function Mn(e){const t=$n||ea;return e?t.then(this?e.bind(this):e):t}function ou(e){let t=Kt+1,o=_t.length;for(;t<o;){const i=t+o>>>1,n=_t[i],s=Ki(n);s<e||s===e&&n.flags&2?t=i+1:o=i}return t}function er(e){if(!(e.flags&1)){const t=Ki(e),o=_t[_t.length-1];!o||!(e.flags&2)&&t>=Ki(o)?_t.push(e):_t.splice(ou(t),0,e),e.flags|=1,ta()}}function ta(){$n||($n=ea.then(ia))}function iu(e){Ae(e)?ui.push(...e):Mo&&e.id===-1?Mo.splice(ti+1,0,e):e.flags&1||(ui.push(e),e.flags|=1),ta()}function Ir(e,t,o=Kt+1){for(;o<_t.length;o++){const i=_t[o];if(i&&i.flags&2){if(e&&i.id!==e.uid)continue;_t.splice(o,1),o--,i.flags&4&&(i.flags&=-2),i(),i.flags&4||(i.flags&=-2)}}}function oa(e){if(ui.length){const t=[...new Set(ui)].sort((o,i)=>Ki(o)-Ki(i));if(ui.length=0,Mo){Mo.push(...t);return}for(Mo=t,ti=0;ti<Mo.length;ti++){const o=Mo[ti];o.flags&4&&(o.flags&=-2),o.flags&8||o(),o.flags&=-2}Mo=null,ti=0}}const Ki=e=>e.id==null?e.flags&2?-1:1/0:e.id;function ia(e){try{for(Kt=0;Kt<_t.length;Kt++){const t=_t[Kt];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),Qi(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;Kt<_t.length;Kt++){const t=_t[Kt];t&&(t.flags&=-2)}Kt=-1,_t.length=0,oa(),$n=null,(_t.length||ui.length)&&ia()}}let gt=null,na=null;function Tn(e){const t=gt;return gt=e,na=e&&e.type.__scopeId||null,t}function sa(e,t=gt,o){if(!t||e._n)return e;const i=(...n)=>{i._d&&Rr(-1);const s=Tn(t),l=go.length;let r;try{r=e(...n)}finally{for(let a=go.length;a>l;a--)sr();Tn(s),i._d&&Rr(1)}return r};return i._n=!0,i._c=!0,i._d=!0,i}function Ht(e,t){if(gt===null)return e;const o=Kn(gt),i=e.dirs||(e.dirs=[]);for(let n=0;n<t.length;n++){let[s,l,r,a=Ze]=t[n];s&&(De(s)&&(s={mounted:s,updated:s}),s.deep&&po(l),i.push({dir:s,instance:o,value:l,oldValue:void 0,arg:r,modifiers:a}))}return e}function zo(e,t,o,i){const n=e.dirs,s=t&&t.dirs;for(let l=0;l<n.length;l++){const r=n[l];s&&(r.oldValue=s[l].value);let a=r.dir[i];a&&(vo(),qt(a,o,8,[e.el,r,e,t]),ko())}}function nu(e,t){if(xt){let o=xt.provides;const i=xt.parent&&xt.parent.provides;i===o&&(o=xt.provides=Object.create(i)),o[e]=t}}function Wt(e,t,o=!1){const i=of();if(i||hi){let n=hi?hi._context.provides:i?i.parent==null||i.ce?i.vnode.appContext&&i.vnode.appContext.provides:i.parent.provides:void 0;if(n&&e in n)return n[e];if(arguments.length>1)return o&&De(t)?t.call(i&&i.proxy):t}}const su=Symbol.for("v-scx"),ru=()=>Wt(su);function Yo(e,t,o){return ra(e,t,o)}function ra(e,t,o=Ze){const{immediate:i,deep:n,flush:s,once:l}=o,r=yt({},o),a=t&&i||!t&&s!=="post";let c;if(Zi){if(s==="sync"){const d=ru();c=d.__watcherHandles||(d.__watcherHandles=[])}else if(!a){const d=()=>{};return d.stop=oo,d.resume=oo,d.pause=oo,d}}const u=xt;r.call=(d,h,m)=>qt(d,u,h,m);let p=!1;s==="post"?r.scheduler=d=>{At(d,u&&u.suspense)}:s!=="sync"&&(p=!0,r.scheduler=(d,h)=>{h?d():er(d)}),r.augmentJob=d=>{t&&(d.flags|=4),p&&(d.flags|=2,u&&(d.id=u.uid,d.i=u))};const y=eu(e,t,r);return Zi&&(c?c.push(y):a&&y()),y}function lu(e,t,o){const i=this.proxy,n=nt(e)?e.includes(".")?la(i,e):()=>i[e]:e.bind(i,i);let s;De(t)?s=t:(s=t.handler,o=t);const l=en(this),r=ra(n,s.bind(i),o);return l(),r}function la(e,t){const o=t.split(".");return()=>{let i=e;for(let n=0;n<o.length&&i;n++)i=i[o[n]];return i}}const au=Symbol("_vte"),cu=e=>e.__isTeleport,is=Symbol("_leaveCb");function tr(e,t){e.shapeFlag&6&&e.component?(e.transition=t,tr(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function Nt(e,t){return De(e)?yt({name:e.name},t,{setup:e}):e}function aa(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function $r(e,t){let o;return!!((o=Object.getOwnPropertyDescriptor(e,t))&&!o.configurable)}const An=new WeakMap;function Pi(e,t,o,i,n=!1){if(Ae(e)){e.forEach((m,g)=>Pi(m,t&&(Ae(t)?t[g]:t),o,i,n));return}if(fi(i)&&!n){i.shapeFlag&512&&i.type.__asyncResolved&&i.component.subTree.component&&Pi(e,t,o,i.component.subTree);return}const s=i.shapeFlag&4?Kn(i.component):i.el,l=n?null:s,{i:r,r:a}=e,c=t&&t.r,u=r.refs===Ze?r.refs={}:r.refs,p=r.setupState,y=Fe(p),d=p===Ze?El:m=>$r(u,m)?!1:je(y,m),h=(m,g)=>!(g&&$r(u,g));if(c!=null&&c!==a){if(Mr(t),nt(c))u[c]=null,d(c)&&(p[c]=null);else if(ot(c)){const m=t;h(c,m.k)&&(c.value=null),m.k&&(u[m.k]=null)}}if(De(a))Qi(a,r,12,[l,u]);else{const m=nt(a),g=ot(a);if(m||g){const b=()=>{if(e.f){const k=m?d(a)?p[a]:u[a]:h()||!e.k?a.value:u[e.k];if(n)Ae(k)&&Us(k,s);else if(Ae(k))k.includes(s)||k.push(s);else if(m)u[a]=[s],d(a)&&(p[a]=u[a]);else{const w=[s];h(a,e.k)&&(a.value=w),e.k&&(u[e.k]=w)}}else m?(u[a]=l,d(a)&&(p[a]=l)):g&&(h(a,e.k)&&(a.value=l),e.k&&(u[e.k]=l))};if(l){const k=()=>{b(),An.delete(e)};k.id=-1,An.set(e,k),At(k,o)}else Mr(e),b()}}}function Mr(e){const t=An.get(e);t&&(t.flags|=8,An.delete(e))}Hn().requestIdleCallback;Hn().cancelIdleCallback;const fi=e=>!!e.type.__asyncLoader,ca=e=>e.type.__isKeepAlive;function du(e,t){da(e,"a",t)}function uu(e,t){da(e,"da",t)}function da(e,t,o=xt){const i=e.__wdc||(e.__wdc=()=>{let n=o;for(;n;){if(n.isDeactivated)return;n=n.parent}return e()});if(Un(t,i,o),o){let n=o.parent;for(;n&&n.parent;)ca(n.parent.vnode)&&fu(i,t,o,n),n=n.parent}}function fu(e,t,o,i){const n=Un(t,e,i,!0);Vn(()=>{Us(i[t],n)},o)}function Un(e,t,o=xt,i=!1){if(o){const n=o[e]||(o[e]=[]),s=t.__weh||(t.__weh=(...l)=>{vo();const r=en(o),a=qt(t,o,e,l);return r(),ko(),a});return i?n.unshift(s):n.push(s),s}}const So=e=>(t,o=xt)=>{(!Zi||e==="sp")&&Un(e,(...i)=>t(...i),o)},hu=So("bm"),wi=So("m"),pu=So("bu"),mu=So("u"),or=So("bum"),Vn=So("um"),gu=So("sp"),yu=So("rtg"),bu=So("rtc");function vu(e,t=xt){Un("ec",e,t)}const ku="components";function wu(e,t){return Su(ku,e,!0,t)||e}const xu=Symbol.for("v-ndc");function Su(e,t,o=!0,i=!1){const n=gt||xt;if(n){const s=n.type;{const r=af(s,!1);if(r&&(r===t||r===Mt(t)||r===Rn(Mt(t))))return s}const l=Tr(n[e]||s[e],t)||Tr(n.appContext[e],t);return!l&&i?s:l}}function Tr(e,t){return e&&(e[t]||e[Mt(t)]||e[Rn(Mt(t))])}function It(e,t,o,i){let n;const s=o,l=Ae(e);if(l||nt(e)){const r=l&&Ko(e);let a=!1,c=!1;r&&(a=!zt(e),c=wo(e),e=Fn(e)),n=new Array(e.length);for(let u=0,p=e.length;u<p;u++)n[u]=t(a?c?mi(Vt(e[u])):Vt(e[u]):e[u],u,void 0,s)}else if(typeof e=="number"){n=new Array(e);for(let r=0;r<e;r++)n[r]=t(r+1,r,void 0,s)}else if(qe(e))if(e[Symbol.iterator])n=Array.from(e,(r,a)=>t(r,a,void 0,s));else{const r=Object.keys(e);n=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const u=r[a];n[a]=t(e[u],u,a,s)}}else n=[];return n}function ln(e,t,o={},i,n,s){if(gt.ce||gt.parent&&fi(gt.parent)&&gt.parent.ce){const c=o,u=Object.keys(c).length>0;return t!=="default"&&(c.name=t),J(),to(Je,null,[re("slot",c,i&&i())],u?-2:64)}let l=e[t];l&&l._c&&(l._d=!1);const r=go.length;J();let a;try{const c=l&&ua(l(o)),u=o.key||s||c&&c.key;a=to(Je,{key:(u&&!Ut(u)?u:`_${t}`)+(!c&&i?"_fb":"")},c||(i?i():[]),c&&e._===1?64:-2)}catch(c){for(let u=go.length;u>r;u--)sr();throw c}finally{l&&l._c&&(l._d=!0)}return a}function ua(e){return e.some(t=>rr(t)?!(t.type===xo||t.type===Je&&!ua(t.children)):!0)?e:null}const Is=e=>e?Ea(e)?Kn(e):Is(e.parent):null,Ni=yt(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>Is(e.parent),$root:e=>Is(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>ha(e),$forceUpdate:e=>e.f||(e.f=()=>{er(e.update)}),$nextTick:e=>e.n||(e.n=Mn.bind(e.proxy)),$watch:e=>lu.bind(e)}),ns=(e,t)=>e!==Ze&&!e.__isScriptSetup&&je(e,t),Cu={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:o,setupState:i,data:n,props:s,accessCache:l,type:r,appContext:a}=e;if(t[0]!=="$"){const y=l[t];if(y!==void 0)switch(y){case 1:return i[t];case 2:return n[t];case 4:return o[t];case 3:return s[t]}else{if(ns(i,t))return l[t]=1,i[t];if(n!==Ze&&je(n,t))return l[t]=2,n[t];if(je(s,t))return l[t]=3,s[t];if(o!==Ze&&je(o,t))return l[t]=4,o[t];$s&&(l[t]=0)}}const c=Ni[t];let u,p;if(c)return t==="$attrs"&&kt(e.attrs,"get",""),c(e);if((u=r.__cssModules)&&(u=u[t]))return u;if(o!==Ze&&je(o,t))return l[t]=4,o[t];if(p=a.config.globalProperties,je(p,t))return p[t]},set({_:e},t,o){const{data:i,setupState:n,ctx:s}=e;return ns(n,t)?(n[t]=o,!0):i!==Ze&&je(i,t)?(i[t]=o,!0):je(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(s[t]=o,!0)},has({_:{data:e,setupState:t,accessCache:o,ctx:i,appContext:n,props:s,type:l}},r){let a;return!!(o[r]||e!==Ze&&r[0]!=="$"&&je(e,r)||ns(t,r)||je(s,r)||je(i,r)||je(Ni,r)||je(n.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(e,t,o){return o.get!=null?e._.accessCache[t]=0:je(o,"value")&&this.set(e,t,o.value,null),Reflect.defineProperty(e,t,o)}};function Ar(e){return Ae(e)?e.reduce((t,o)=>(t[o]=null,t),{}):e}let $s=!0;function _u(e){const t=ha(e),o=e.proxy,i=e.ctx;$s=!1,t.beforeCreate&&Er(t.beforeCreate,e,"bc");const{data:n,computed:s,methods:l,watch:r,provide:a,inject:c,created:u,beforeMount:p,mounted:y,beforeUpdate:d,updated:h,activated:m,deactivated:g,beforeDestroy:b,beforeUnmount:k,destroyed:w,unmounted:C,render:A,renderTracked:M,renderTriggered:I,errorCaptured:N,serverPrefetch:D,expose:U,inheritAttrs:W,components:E,directives:P,filters:x}=t;if(c&&Iu(c,i,null),l)for(const $ in l){const T=l[$];De(T)&&(i[$]=T.bind(o))}if(n){const $=n.call(o,o);qe($)&&(e.data=jn($))}if($s=!0,s)for(const $ in s){const T=s[$],O=De(T)?T.bind(o,o):De(T.get)?T.get.bind(o,o):oo,te=!De(T)&&De(T.set)?T.set.bind(o):oo,Y=ye({get:O,set:te});Object.defineProperty(i,$,{enumerable:!0,configurable:!0,get:()=>Y.value,set:Z=>Y.value=Z})}if(r)for(const $ in r)fa(r[$],i,o,$);if(a){const $=De(a)?a.call(o):a;Reflect.ownKeys($).forEach(T=>{nu(T,$[T])})}u&&Er(u,e,"c");function j($,T){Ae(T)?T.forEach(O=>$(O.bind(o))):T&&$(T.bind(o))}if(j(hu,p),j(wi,y),j(pu,d),j(mu,h),j(du,m),j(uu,g),j(vu,N),j(bu,M),j(yu,I),j(or,k),j(Vn,C),j(gu,D),Ae(U))if(U.length){const $=e.exposed||(e.exposed={});U.forEach(T=>{Object.defineProperty($,T,{get:()=>o[T],set:O=>o[T]=O,enumerable:!0})})}else e.exposed||(e.exposed={});A&&e.render===oo&&(e.render=A),W!=null&&(e.inheritAttrs=W),E&&(e.components=E),P&&(e.directives=P),D&&aa(e)}function Iu(e,t,o=oo){Ae(e)&&(e=Ms(e));for(const i in e){const n=e[i];let s;qe(n)?"default"in n?s=Wt(n.from||i,n.default,!0):s=Wt(n.from||i):s=Wt(n),ot(s)?Object.defineProperty(t,i,{enumerable:!0,configurable:!0,get:()=>s.value,set:l=>s.value=l}):t[i]=s}}function Er(e,t,o){qt(Ae(e)?e.map(i=>i.bind(t.proxy)):e.bind(t.proxy),t,o)}function fa(e,t,o,i){let n=i.includes(".")?la(o,i):()=>o[i];if(nt(e)){const s=t[e];De(s)&&Yo(n,s)}else if(De(e))Yo(n,e.bind(o));else if(qe(e))if(Ae(e))e.forEach(s=>fa(s,t,o,i));else{const s=De(e.handler)?e.handler.bind(o):t[e.handler];De(s)&&Yo(n,s,e)}}function ha(e){const t=e.type,{mixins:o,extends:i}=t,{mixins:n,optionsCache:s,config:{optionMergeStrategies:l}}=e.appContext,r=s.get(t);let a;return r?a=r:!n.length&&!o&&!i?a=t:(a={},n.length&&n.forEach(c=>En(a,c,l,!0)),En(a,t,l)),qe(t)&&s.set(t,a),a}function En(e,t,o,i=!1){const{mixins:n,extends:s}=t;s&&En(e,s,o,!0),n&&n.forEach(l=>En(e,l,o,!0));for(const l in t)if(!(i&&l==="expose")){const r=$u[l]||o&&o[l];e[l]=r?r(e[l],t[l]):t[l]}return e}const $u={data:Br,props:Dr,emits:Dr,methods:Ti,computed:Ti,beforeCreate:Ct,created:Ct,beforeMount:Ct,mounted:Ct,beforeUpdate:Ct,updated:Ct,beforeDestroy:Ct,beforeUnmount:Ct,destroyed:Ct,unmounted:Ct,activated:Ct,deactivated:Ct,errorCaptured:Ct,serverPrefetch:Ct,components:Ti,directives:Ti,watch:Tu,provide:Br,inject:Mu};function Br(e,t){return t?e?function(){return yt(De(e)?e.call(this,this):e,De(t)?t.call(this,this):t)}:t:e}function Mu(e,t){return Ti(Ms(e),Ms(t))}function Ms(e){if(Ae(e)){const t={};for(let o=0;o<e.length;o++)t[e[o]]=e[o];return t}return e}function Ct(e,t){return e?[...new Set([].concat(e,t))]:t}function Ti(e,t){return e?yt(Object.create(null),e,t):t}function Dr(e,t){return e?Ae(e)&&Ae(t)?[...new Set([...e,...t])]:yt(Object.create(null),Ar(e),Ar(t??{})):t}function Tu(e,t){if(!e)return t;if(!t)return e;const o=yt(Object.create(null),e);for(const i in t)o[i]=Ct(e[i],t[i]);return o}function pa(){return{app:null,config:{isNativeTag:El,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Au=0;function Eu(e,t){return function(i,n=null){De(i)||(i=yt({},i)),n!=null&&!qe(n)&&(n=null);const s=pa(),l=new WeakSet,r=[];let a=!1;const c=s.app={_uid:Au++,_component:i,_props:n,_container:null,_context:s,_instance:null,version:df,get config(){return s.config},set config(u){},use(u,...p){return l.has(u)||(u&&De(u.install)?(l.add(u),u.install(c,...p)):De(u)&&(l.add(u),u(c,...p))),c},mixin(u){return s.mixins.includes(u)||s.mixins.push(u),c},component(u,p){return p?(s.components[u]=p,c):s.components[u]},directive(u,p){return p?(s.directives[u]=p,c):s.directives[u]},mount(u,p,y){if(!a){const d=c._ceVNode||re(i,n);return d.appContext=s,y===!0?y="svg":y===!1&&(y=void 0),e(d,u,y),a=!0,c._container=u,u.__vue_app__=c,Kn(d.component)}},onUnmount(u){r.push(u)},unmount(){a&&(qt(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(u,p){return s.provides[u]=p,c},runWithContext(u){const p=hi;hi=c;try{return u()}finally{hi=p}}};return c}}let hi=null;const Bu=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${Mt(t)}Modifiers`]||e[`${Ro(t)}Modifiers`];function Du(e,t,...o){if(e.isUnmounted)return;const i=e.vnode.props||Ze;let n=o;const s=t.startsWith("update:"),l=s&&Bu(i,t.slice(7));l&&(l.trim&&(n=o.map(u=>nt(u)?u.trim():u)),l.number&&(n=o.map(zn)));let r,a=i[r=Xn(t)]||i[r=Xn(Mt(t))];!a&&s&&(a=i[r=Xn(Ro(t))]),a&&qt(a,e,6,n);const c=i[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,qt(c,e,6,n)}}const Lu=new WeakMap;function ma(e,t,o=!1){const i=o?Lu:t.emitsCache,n=i.get(e);if(n!==void 0)return n;const s=e.emits;let l={},r=!1;if(!De(e)){const a=c=>{const u=ma(c,t,!0);u&&(r=!0,yt(l,u))};!o&&t.mixins.length&&t.mixins.forEach(a),e.extends&&a(e.extends),e.mixins&&e.mixins.forEach(a)}return!s&&!r?(qe(e)&&i.set(e,null),null):(Ae(s)?s.forEach(a=>l[a]=null):yt(l,s),qe(e)&&i.set(e,l),l)}function qn(e,t){return!e||!On(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),je(e,t[0].toLowerCase()+t.slice(1))||je(e,Ro(t))||je(e,t))}function Lr(e){const{type:t,vnode:o,proxy:i,withProxy:n,propsOptions:[s],slots:l,attrs:r,emit:a,render:c,renderCache:u,props:p,data:y,setupState:d,ctx:h,inheritAttrs:m}=e,g=Tn(e);let b,k;try{if(o.shapeFlag&4){const C=n||i,A=C;b=Jt(c.call(A,C,u,p,d,y,h)),k=r}else{const C=t;b=Jt(C.length>1?C(p,{attrs:r,slots:l,emit:a}):C(p,null)),k=t.props?r:Ou(r)}}catch(C){go.length=0,Wn(C,e,1),b=re(xo)}let w=b;if(k&&m!==!1){const C=Object.keys(k),{shapeFlag:A}=w;C.length&&A&7&&(s&&C.some(Pn)&&(k=Pu(k,s)),w=gi(w,k,!1,!0))}return o.dirs&&(w=gi(w,null,!1,!0),w.dirs=w.dirs?w.dirs.concat(o.dirs):o.dirs),o.transition&&tr(w,o.transition),b=w,Tn(g),b}const Ou=e=>{let t;for(const o in e)(o==="class"||o==="style"||On(o))&&((t||(t={}))[o]=e[o]);return t},Pu=(e,t)=>{const o={};for(const i in e)(!Pn(i)||!(i.slice(9)in t))&&(o[i]=e[i]);return o};function Nu(e,t,o){const{props:i,children:n,component:s}=e,{props:l,children:r,patchFlag:a}=t,c=s.emitsOptions;if(t.dirs||t.transition)return!0;if(o&&a>=0){if(a&1024)return!0;if(a&16)return i?Or(i,l,c):!!l;if(a&8){const u=t.dynamicProps;for(let p=0;p<u.length;p++){const y=u[p];if(ga(l,i,y)&&!qn(c,y))return!0}}}else return(n||r)&&(!r||!r.$stable)?!0:i===l?!1:i?l?Or(i,l,c):!0:!!l;return!1}function Or(e,t,o){const i=Object.keys(t);if(i.length!==Object.keys(e).length)return!0;for(let n=0;n<i.length;n++){const s=i[n];if(ga(t,e,s)&&!qn(o,s))return!0}return!1}function ga(e,t,o){const i=e[o],n=t[o];return o==="style"&&qe(i)&&qe(n)?!ki(i,n):i!==n}function Ru({vnode:e,parent:t,suspense:o},i){for(;t;){const n=t.subTree;if(n.suspense&&n.suspense.activeBranch===e&&(n.suspense.vnode.el=n.el=i,e=n),n===e)(e=t.vnode).el=i,t=t.parent;else break}o&&o.activeBranch===e&&(o.vnode.el=i)}const ya={},ba=()=>Object.create(ya),va=e=>Object.getPrototypeOf(e)===ya;function zu(e,t,o,i=!1){const n={},s=ba();e.propsDefaults=Object.create(null),ka(e,t,n,s);for(const l in e.propsOptions[0])l in n||(n[l]=void 0);o?e.props=i?n:qd(n):e.type.props?e.props=n:e.props=s,e.attrs=s}function Hu(e,t,o,i){const{props:n,attrs:s,vnode:{patchFlag:l}}=e,r=Fe(n),[a]=e.propsOptions;let c=!1;if((i||l>0)&&!(l&16)){if(l&8){const u=e.vnode.dynamicProps;for(let p=0;p<u.length;p++){let y=u[p];if(qn(e.emitsOptions,y))continue;const d=t[y];if(a)if(je(s,y))d!==s[y]&&(s[y]=d,c=!0);else{const h=Mt(y);n[h]=Ts(a,r,h,d,e,!1)}else d!==s[y]&&(s[y]=d,c=!0)}}}else{ka(e,t,n,s)&&(c=!0);let u;for(const p in r)(!t||!je(t,p)&&((u=Ro(p))===p||!je(t,u)))&&(a?o&&(o[p]!==void 0||o[u]!==void 0)&&(n[p]=Ts(a,r,p,void 0,e,!0)):delete n[p]);if(s!==r)for(const p in s)(!t||!je(t,p))&&(delete s[p],c=!0)}c&&ho(e.attrs,"set","")}function ka(e,t,o,i){const[n,s]=e.propsOptions;let l=!1,r;if(t)for(let a in t){if(Di(a))continue;const c=t[a];let u;n&&je(n,u=Mt(a))?!s||!s.includes(u)?o[u]=c:(r||(r={}))[u]=c:qn(e.emitsOptions,a)||(!(a in i)||c!==i[a])&&(i[a]=c,l=!0)}if(s){const a=Fe(o),c=r||Ze;for(let u=0;u<s.length;u++){const p=s[u];o[p]=Ts(n,a,p,c[p],e,!je(c,p))}}return l}function Ts(e,t,o,i,n,s){const l=e[o];if(l!=null){const r=je(l,"default");if(r&&i===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&De(a)){const{propsDefaults:c}=n;if(o in c)i=c[o];else{const u=en(n);i=c[o]=a.call(null,t),u()}}else i=a;n.ce&&n.ce._setProp(o,i)}l[0]&&(s&&!r?i=!1:l[1]&&(i===""||i===Ro(o))&&(i=!0))}return i}const Fu=new WeakMap;function wa(e,t,o=!1){const i=o?Fu:t.propsCache,n=i.get(e);if(n)return n;const s=e.props,l={},r=[];let a=!1;if(!De(e)){const u=p=>{a=!0;const[y,d]=wa(p,t,!0);yt(l,y),d&&r.push(...d)};!o&&t.mixins.length&&t.mixins.forEach(u),e.extends&&u(e.extends),e.mixins&&e.mixins.forEach(u)}if(!s&&!a)return qe(e)&&i.set(e,ci),ci;if(Ae(s))for(let u=0;u<s.length;u++){const p=Mt(s[u]);Pr(p)&&(l[p]=Ze)}else if(s)for(const u in s){const p=Mt(u);if(Pr(p)){const y=s[u],d=l[p]=Ae(y)||De(y)?{type:y}:yt({},y),h=d.type;let m=!1,g=!0;if(Ae(h))for(let b=0;b<h.length;++b){const k=h[b],w=De(k)&&k.name;if(w==="Boolean"){m=!0;break}else w==="String"&&(g=!1)}else m=De(h)&&h.name==="Boolean";d[0]=m,d[1]=g,(m||je(d,"default"))&&r.push(p)}}const c=[l,r];return qe(e)&&i.set(e,c),c}function Pr(e){return e[0]!=="$"&&!Di(e)}const ir=e=>e==="_"||e==="_ctx"||e==="$stable",nr=e=>Ae(e)?e.map(Jt):[Jt(e)],ju=(e,t,o)=>{if(t._n)return t;const i=sa((...n)=>nr(t(...n)),o);return i._c=!1,i},xa=(e,t,o)=>{const i=e._ctx;for(const n in e){if(ir(n))continue;const s=e[n];if(De(s))t[n]=ju(n,s,i);else if(s!=null){const l=nr(s);t[n]=()=>l}}},Sa=(e,t)=>{const o=nr(t);e.slots.default=()=>o},Ca=(e,t,o)=>{for(const i in t)(o||!ir(i))&&(e[i]=t[i])},Wu=(e,t,o)=>{const i=e.slots=ba();if(e.vnode.shapeFlag&32){const n=t._;n?(Ca(i,t,o),o&&Ol(i,"_",n,!0)):xa(t,i)}else t&&Sa(e,t)},Uu=(e,t,o)=>{const{vnode:i,slots:n}=e;let s=!0,l=Ze;if(i.shapeFlag&32){const r=t._;r?o&&r===1?s=!1:Ca(n,t,o):(s=!t.$stable,xa(t,n)),l=t}else t&&(Sa(e,t),l={default:1});if(s)for(const r in n)!ir(r)&&l[r]==null&&delete n[r]},At=Yu;function Vu(e){return qu(e)}function qu(e,t){const o=Hn();o.__VUE__=!0;const{insert:i,remove:n,patchProp:s,createElement:l,createText:r,createComment:a,setText:c,setElementText:u,parentNode:p,nextSibling:y,setScopeId:d=oo,insertStaticContent:h}=e,m=(B,H,v,F=null,z=null,S=null,_=void 0,L=null,q=!!H.dynamicChildren)=>{if(B===H)return;B&&!$i(B,H)&&(F=_e(B),Z(B,z,S,!0),B=null),H.patchFlag===-2&&(q=!1,H.dynamicChildren=null);const{type:V,ref:G,shapeFlag:X}=H;switch(V){case Gn:g(B,H,v,F);break;case xo:b(B,H,v,F);break;case fn:B==null&&k(H,v,F,_);break;case Je:E(B,H,v,F,z,S,_,L,q);break;default:X&1?A(B,H,v,F,z,S,_,L,q):X&6?P(B,H,v,F,z,S,_,L,q):(X&64||X&128)&&V.process(B,H,v,F,z,S,_,L,q,R)}G!=null&&z?Pi(G,B&&B.ref,S,H||B,!H):G==null&&B&&B.ref!=null&&Pi(B.ref,null,S,B,!0)},g=(B,H,v,F)=>{if(B==null)i(H.el=r(H.children),v,F);else{const z=H.el=B.el;H.children!==B.children&&c(z,H.children)}},b=(B,H,v,F)=>{B==null?i(H.el=a(H.children||""),v,F):H.el=B.el},k=(B,H,v,F)=>{[B.el,B.anchor]=h(B.children,H,v,F,B.el,B.anchor)},w=({el:B,anchor:H},v,F)=>{let z;for(;B&&B!==H;)z=y(B),i(B,v,F),B=z;i(H,v,F)},C=({el:B,anchor:H})=>{let v;for(;B&&B!==H;)v=y(B),n(B),B=v;n(H)},A=(B,H,v,F,z,S,_,L,q)=>{if(H.type==="svg"?_="svg":H.type==="math"&&(_="mathml"),B==null)M(H,v,F,z,S,_,L,q);else{const V=B.el&&B.el._isVueCE?B.el:null;try{V&&V._beginPatch(),D(B,H,z,S,_,L,q)}finally{V&&V._endPatch()}}},M=(B,H,v,F,z,S,_,L)=>{let q,V;const{props:G,shapeFlag:X,transition:le,dirs:se}=B;if(q=B.el=l(B.type,S,G&&G.is,G),X&8?u(q,B.children):X&16&&N(B.children,q,null,F,z,ss(B,S),_,L),se&&zo(B,null,F,"created"),I(q,B,B.scopeId,_,F),G){for(const Se in G)Se!=="value"&&!Di(Se)&&s(q,Se,null,G[Se],S,F);"value"in G&&s(q,"value",null,G.value,S),(V=G.onVnodeBeforeMount)&&Gt(V,F,B)}se&&zo(B,null,F,"beforeMount");const me=Gu(z,le);me&&le.beforeEnter(q),i(q,H,v),((V=G&&G.onVnodeMounted)||me||se)&&At(()=>{try{V&&Gt(V,F,B),me&&le.enter(q),se&&zo(B,null,F,"mounted")}finally{}},z)},I=(B,H,v,F,z)=>{if(v&&d(B,v),F)for(let S=0;S<F.length;S++)d(B,F[S]);if(z){let S=z.subTree;if(H===S||Ma(S.type)&&(S.ssContent===H||S.ssFallback===H)){const _=z.vnode;I(B,_,_.scopeId,_.slotScopeIds,z.parent)}}},N=(B,H,v,F,z,S,_,L,q=0)=>{for(let V=q;V<B.length;V++){const G=B[V]=L?co(B[V]):Jt(B[V]);m(null,G,H,v,F,z,S,_,L)}},D=(B,H,v,F,z,S,_)=>{const L=H.el=B.el;let{patchFlag:q,dynamicChildren:V,dirs:G}=H;q|=B.patchFlag&16;const X=B.props||Ze,le=H.props||Ze;let se;if(v&&Ho(v,!1),(se=le.onVnodeBeforeUpdate)&&Gt(se,v,H,B),G&&zo(H,B,v,"beforeUpdate"),v&&Ho(v,!0),V&&(!B.dynamicChildren||B.dynamicChildren.length!==V.length)&&(q=0,_=!1,V=null),(X.innerHTML&&le.innerHTML==null||X.textContent&&le.textContent==null)&&u(L,""),V?U(B.dynamicChildren,V,L,v,F,ss(H,z),S):_||T(B,H,L,null,v,F,ss(H,z),S,!1),q>0){if(q&16)W(L,X,le,v,z);else if(q&2&&X.class!==le.class&&s(L,"class",null,le.class,z),q&4&&s(L,"style",X.style,le.style,z),q&8){const me=H.dynamicProps;for(let Se=0;Se<me.length;Se++){const we=me[Se],Le=X[we],He=le[we];(He!==Le||we==="value")&&s(L,we,Le,He,z,v)}}q&1&&B.children!==H.children&&u(L,H.children)}else!_&&V==null&&W(L,X,le,v,z);((se=le.onVnodeUpdated)||G)&&At(()=>{se&&Gt(se,v,H,B),G&&zo(H,B,v,"updated")},F)},U=(B,H,v,F,z,S,_)=>{for(let L=0;L<H.length;L++){const q=B[L],V=H[L],G=q.el&&(q.type===Je||!$i(q,V)||q.shapeFlag&198)?p(q.el):v;m(q,V,G,null,F,z,S,_,!0)}},W=(B,H,v,F,z)=>{if(H!==v){if(H!==Ze)for(const S in H)!Di(S)&&!(S in v)&&s(B,S,H[S],null,z,F);for(const S in v){if(Di(S))continue;const _=v[S],L=H[S];_!==L&&S!=="value"&&s(B,S,L,_,z,F)}"value"in v&&s(B,"value",H.value,v.value,z)}},E=(B,H,v,F,z,S,_,L,q)=>{const V=H.el=B?B.el:r(""),G=H.anchor=B?B.anchor:r("");let{patchFlag:X,dynamicChildren:le,slotScopeIds:se}=H;se&&(L=L?L.concat(se):se),B==null?(i(V,v,F),i(G,v,F),N(H.children||[],v,G,z,S,_,L,q)):X>0&&X&64&&le&&B.dynamicChildren&&B.dynamicChildren.length===le.length?(U(B.dynamicChildren,le,v,z,S,_,L),(H.key!=null||z&&H===z.subTree)&&_a(B,H,!0)):T(B,H,v,G,z,S,_,L,q)},P=(B,H,v,F,z,S,_,L,q)=>{H.slotScopeIds=L,B==null?H.shapeFlag&512?z.ctx.activate(H,v,F,_,q):x(H,v,F,z,S,_,q):K(B,H,q)},x=(B,H,v,F,z,S,_)=>{const L=B.component=tf(B,F,z);if(ca(B)&&(L.ctx.renderer=R),nf(L,!1,_),L.asyncDep){if(z&&z.registerDep(L,j,_),!B.el){const q=L.subTree=re(xo);b(null,q,H,v),B.placeholder=q.el}}else j(L,B,H,v,z,S,_)},K=(B,H,v)=>{const F=H.component=B.component;if(Nu(B,H,v))if(F.asyncDep&&!F.asyncResolved){$(F,H,v);return}else F.next=H,F.update();else H.el=B.el,F.vnode=H},j=(B,H,v,F,z,S,_)=>{const L=()=>{if(B.isMounted){let{next:X,bu:le,u:se,parent:me,vnode:Se}=B;{const rt=Ia(B);if(rt){X&&(X.el=Se.el,$(B,X,_)),rt.asyncDep.then(()=>{At(()=>{B.isUnmounted||V()},z)});return}}let we=X,Le;Ho(B,!1),X?(X.el=Se.el,$(B,X,_)):X=Se,le&&un(le),(Le=X.props&&X.props.onVnodeBeforeUpdate)&&Gt(Le,me,X,Se),Ho(B,!0);const He=Lr(B),Ge=B.subTree;B.subTree=He,m(Ge,He,p(Ge.el),_e(Ge),B,z,S),X.el=He.el,we===null&&Ru(B,He.el),se&&At(se,z),(Le=X.props&&X.props.onVnodeUpdated)&&At(()=>Gt(Le,me,X,Se),z)}else{let X;const{el:le,props:se}=H,{bm:me,m:Se,parent:we,root:Le,type:He}=B,Ge=fi(H);Ho(B,!1),me&&un(me),!Ge&&(X=se&&se.onVnodeBeforeMount)&&Gt(X,we,H),Ho(B,!0);{Le.ce&&Le.ce._hasShadowRoot()&&Le.ce._injectChildStyle(He,B.parent?B.parent.type:void 0);const rt=B.subTree=Lr(B);m(null,rt,v,F,B,z,S),H.el=rt.el}if(Se&&At(Se,z),!Ge&&(X=se&&se.onVnodeMounted)){const rt=H;At(()=>Gt(X,we,rt),z)}(H.shapeFlag&256||we&&fi(we.vnode)&&we.vnode.shapeFlag&256)&&B.a&&At(B.a,z),B.isMounted=!0,H=v=F=null}};B.scope.on();const q=B.effect=new zl(L);B.scope.off();const V=B.update=q.run.bind(q),G=B.job=q.runIfDirty.bind(q);G.i=B,G.id=B.uid,q.scheduler=()=>er(G),Ho(B,!0),V()},$=(B,H,v)=>{H.component=B;const F=B.vnode.props;B.vnode=H,B.next=null,Hu(B,H.props,F,v),Uu(B,H.children,v),vo(),Ir(B),ko()},T=(B,H,v,F,z,S,_,L,q=!1)=>{const V=B&&B.children,G=B?B.shapeFlag:0,X=H.children,{patchFlag:le,shapeFlag:se}=H;if(le>0){if(le&128){te(V,X,v,F,z,S,_,L,q);return}else if(le&256){O(V,X,v,F,z,S,_,L,q);return}}se&8?(G&16&&Ce(V,z,S),X!==V&&u(v,X)):G&16?se&16?te(V,X,v,F,z,S,_,L,q):Ce(V,z,S,!0):(G&8&&u(v,""),se&16&&N(X,v,F,z,S,_,L,q))},O=(B,H,v,F,z,S,_,L,q)=>{B=B||ci,H=H||ci;const V=B.length,G=H.length,X=Math.min(V,G);let le;for(le=0;le<X;le++){const se=H[le]=q?co(H[le]):Jt(H[le]);m(B[le],se,v,null,z,S,_,L,q)}V>G?Ce(B,z,S,!0,!1,X):N(H,v,F,z,S,_,L,q,X)},te=(B,H,v,F,z,S,_,L,q)=>{let V=0;const G=H.length;let X=B.length-1,le=G-1;for(;V<=X&&V<=le;){const se=B[V],me=H[V]=q?co(H[V]):Jt(H[V]);if($i(se,me))m(se,me,v,null,z,S,_,L,q);else break;V++}for(;V<=X&&V<=le;){const se=B[X],me=H[le]=q?co(H[le]):Jt(H[le]);if($i(se,me))m(se,me,v,null,z,S,_,L,q);else break;X--,le--}if(V>X){if(V<=le){const se=le+1,me=se<G?H[se].el:F;for(;V<=le;)m(null,H[V]=q?co(H[V]):Jt(H[V]),v,me,z,S,_,L,q),V++}}else if(V>le)for(;V<=X;)Z(B[V],z,S,!0),V++;else{const se=V,me=V,Se=new Map;for(V=me;V<=le;V++){const tt=H[V]=q?co(H[V]):Jt(H[V]);tt.key!=null&&Se.set(tt.key,V)}let we,Le=0;const He=le-me+1;let Ge=!1,rt=0;const Ne=new Array(He);for(V=0;V<He;V++)Ne[V]=0;for(V=se;V<=X;V++){const tt=B[V];if(Le>=He){Z(tt,z,S,!0);continue}let Ke;if(tt.key!=null)Ke=Se.get(tt.key);else for(we=me;we<=le;we++)if(Ne[we-me]===0&&$i(tt,H[we])){Ke=we;break}Ke===void 0?Z(tt,z,S,!0):(Ne[Ke-me]=V+1,Ke>=rt?rt=Ke:Ge=!0,m(tt,H[Ke],v,null,z,S,_,L,q),Le++)}const ft=Ge?Ku(Ne):ci;for(we=ft.length-1,V=He-1;V>=0;V--){const tt=me+V,Ke=H[tt],ue=H[tt+1],fe=tt+1<G?ue.el||$a(ue):F;Ne[V]===0?m(null,Ke,v,fe,z,S,_,L,q):Ge&&(we<0||V!==ft[we]?Y(Ke,v,fe,2):we--)}}},Y=(B,H,v,F,z=null)=>{const{el:S,type:_,transition:L,children:q,shapeFlag:V}=B;if(V&6){Y(B.component.subTree,H,v,F);return}if(V&128){B.suspense.move(H,v,F);return}if(V&64){_.move(B,H,v,R);return}if(_===Je){i(S,H,v);for(let X=0;X<q.length;X++)Y(q[X],H,v,F);i(B.anchor,H,v);return}if(_===fn){w(B,H,v);return}if(F!==2&&V&1&&L)if(F===0)L.persisted&&!S[is]?i(S,H,v):(L.beforeEnter(S),i(S,H,v),At(()=>L.enter(S),z));else{const{leave:X,delayLeave:le,afterLeave:se}=L,me=()=>{B.ctx.isUnmounted?n(S):i(S,H,v)},Se=()=>{const we=S._isLeaving||!!S[is];S._isLeaving&&S[is](!0),L.persisted&&!we?me():X(S,()=>{me(),se&&se()})};le?le(S,me,Se):Se()}else i(S,H,v)},Z=(B,H,v,F=!1,z=!1)=>{const{type:S,props:_,ref:L,children:q,dynamicChildren:V,shapeFlag:G,patchFlag:X,dirs:le,cacheIndex:se,memo:me}=B;if(X===-2&&(z=!1),L!=null&&(vo(),Pi(L,null,v,B,!0),ko()),se!=null&&(H.renderCache[se]=void 0),G&256){H.ctx.deactivate(B);return}const Se=G&1&&le,we=!fi(B);let Le;if(we&&(Le=_&&_.onVnodeBeforeUnmount)&&Gt(Le,H,B),G&6)ne(B.component,v,F);else{if(G&128){B.suspense.unmount(v,F);return}Se&&zo(B,null,H,"beforeUnmount"),G&64?B.type.remove(B,H,v,R,F):V&&!V.hasOnce&&(S!==Je||X>0&&X&64)?Ce(V,H,v,!1,!0):(S===Je&&X&384||!z&&G&16)&&Ce(q,H,v),F&&ce(B)}const He=me!=null&&se==null;(we&&(Le=_&&_.onVnodeUnmounted)||Se||He)&&At(()=>{Le&&Gt(Le,H,B),Se&&zo(B,null,H,"unmounted"),He&&(B.el=null)},v)},ce=B=>{const{type:H,el:v,anchor:F,transition:z}=B;if(H===Je){oe(v,F);return}if(H===fn){C(B);return}const S=()=>{n(v),z&&!z.persisted&&z.afterLeave&&z.afterLeave()};if(B.shapeFlag&1&&z&&!z.persisted){const{leave:_,delayLeave:L}=z,q=()=>_(v,S);L?L(B.el,S,q):q()}else S()},oe=(B,H)=>{let v;for(;B!==H;)v=y(B),n(B),B=v;n(H)},ne=(B,H,v)=>{const{bum:F,scope:z,job:S,subTree:_,um:L,m:q,a:V}=B;Nr(q),Nr(V),F&&un(F),z.stop(),S&&(S.flags|=8,Z(_,B,H,v)),L&&At(L,H),At(()=>{B.isUnmounted=!0},H)},Ce=(B,H,v,F=!1,z=!1,S=0)=>{for(let _=S;_<B.length;_++)Z(B[_],H,v,F,z)},_e=B=>{if(B.shapeFlag&6)return _e(B.component.subTree);if(B.shapeFlag&128)return B.suspense.next();const H=y(B.anchor||B.el),v=H&&H[au];return v?y(v):H};let ke=!1;const Ie=(B,H,v)=>{let F;B==null?H._vnode&&(Z(H._vnode,null,null,!0),F=H._vnode.component):m(H._vnode||null,B,H,null,null,null,v),H._vnode=B,ke||(ke=!0,Ir(F),oa(),ke=!1)},R={p:m,um:Z,m:Y,r:ce,mt:x,mc:N,pc:T,pbc:U,n:_e,o:e};return{render:Ie,hydrate:void 0,createApp:Eu(Ie)}}function ss({type:e,props:t},o){return o==="svg"&&e==="foreignObject"||o==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:o}function Ho({effect:e,job:t},o){o?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function Gu(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function _a(e,t,o=!1){const i=e.children,n=t.children;if(Ae(i)&&Ae(n))for(let s=0;s<i.length;s++){const l=i[s];let r=n[s];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=n[s]=co(n[s]),r.el=l.el),!o&&r.patchFlag!==-2&&_a(l,r)),r.type===Gn&&(r.patchFlag===-1&&(r=n[s]=co(r)),r.el=l.el),r.type===xo&&!r.el&&(r.el=l.el)}}function Ku(e){const t=e.slice(),o=[0];let i,n,s,l,r;const a=e.length;for(i=0;i<a;i++){const c=e[i];if(c!==0){if(n=o[o.length-1],e[n]<c){t[i]=n,o.push(i);continue}for(s=0,l=o.length-1;s<l;)r=s+l>>1,e[o[r]]<c?s=r+1:l=r;c<e[o[s]]&&(s>0&&(t[i]=o[s-1]),o[s]=i)}}for(s=o.length,l=o[s-1];s-- >0;)o[s]=l,l=t[l];return o}function Ia(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:Ia(t)}function Nr(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function $a(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?$a(t.subTree):null}const Ma=e=>e.__isSuspense;function Yu(e,t){t&&t.pendingBranch?Ae(e)?t.effects.push(...e):t.effects.push(e):iu(e)}const Je=Symbol.for("v-fgt"),Gn=Symbol.for("v-txt"),xo=Symbol.for("v-cmt"),fn=Symbol.for("v-stc"),go=[];let Pt=null;function J(e=!1){go.push(Pt=e?null:[])}function sr(){go.pop(),Pt=go[go.length-1]||null}let Yi=1;function Rr(e,t=!1){Yi+=e,e<0&&Pt&&t&&(Pt.hasOnce=!0)}function Ta(e){return e.dynamicChildren=Yi>0?Pt||ci:null,sr(),Yi>0&&Pt&&Pt.push(e),e}function ee(e,t,o,i,n,s){return Ta(f(e,t,o,i,n,s,!0))}function to(e,t,o,i,n){return Ta(re(e,t,o,i,n,!0))}function rr(e){return e?e.__v_isVNode===!0:!1}function $i(e,t){return e.type===t.type&&e.key===t.key}const Aa=({key:e})=>e??null,hn=({ref:e,ref_key:t,ref_for:o})=>(typeof e=="number"&&(e=""+e),e!=null?nt(e)||ot(e)||De(e)?{i:gt,r:e,k:t,f:!!o}:e:null);function f(e,t=null,o=null,i=0,n=null,s=e===Je?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&Aa(t),ref:t&&hn(t),scopeId:na,slotScopeIds:null,children:o,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:i,dynamicProps:n,dynamicChildren:null,appContext:null,ctx:gt};return r?(Bn(a,o),s&128&&e.normalize(a)):o&&(a.shapeFlag|=nt(o)?8:16),Yi>0&&!l&&Pt&&(a.patchFlag>0||s&6)&&a.patchFlag!==32&&Pt.push(a),a}const re=Zu;function Zu(e,t=null,o=null,i=0,n=null,s=!1){if((!e||e===xu)&&(e=xo),rr(e)){const r=gi(e,t,!0);return o&&Bn(r,o),Yi>0&&!s&&Pt&&(r.shapeFlag&6?Pt[Pt.indexOf(e)]=r:Pt.push(r)),r.patchFlag=-2,r}if(cf(e)&&(e=e.__vccOpts),t){t=Ju(t);let{class:r,style:a}=t;r&&!nt(r)&&(t.class=xe(r)),qe(a)&&(Qs(a)&&!Ae(a)&&(a=yt({},a)),t.style=Qt(a))}const l=nt(e)?1:Ma(e)?128:cu(e)?64:qe(e)?4:De(e)?2:0;return f(e,t,o,i,n,l,s,!0)}function Ju(e){return e?Qs(e)||va(e)?yt({},e):e:null}function gi(e,t,o=!1,i=!1){const{props:n,ref:s,patchFlag:l,children:r,transition:a}=e,c=t?Xu(n||{},t):n,u={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&Aa(c),ref:t&&t.ref?o&&s?Ae(s)?s.concat(hn(t)):[s,hn(t)]:hn(t):s,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Je?l===-1?16:l|16:l,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:a,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&gi(e.ssContent),ssFallback:e.ssFallback&&gi(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return a&&i&&tr(u,a.clone(u)),u}function Bt(e=" ",t=0){return re(Gn,null,e,t)}function ht(e,t){const o=re(fn,null,e);return o.staticCount=t,o}function Te(e="",t=!1){return t?(J(),to(xo,null,e)):re(xo,null,e)}function Jt(e){return e==null||typeof e=="boolean"?re(xo):Ae(e)?re(Je,null,e.slice()):rr(e)?co(e):re(Gn,null,String(e))}function co(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:gi(e)}function Bn(e,t){let o=0;const{shapeFlag:i}=e;if(t==null)t=null;else if(Ae(t))o=16;else if(typeof t=="object")if(i&65){const n=t.default;n&&(n._c&&(n._d=!1),Bn(e,n()),n._c&&(n._d=!0));return}else{o=32;const n=t._;!n&&!va(t)?t._ctx=gt:n===3&&gt&&(gt.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(De(t)){if(i&65){Bn(e,{default:t});return}t={default:t,_ctx:gt},o=32}else t=String(t),i&64?(o=16,t=[Bt(t)]):o=8;e.children=t,e.shapeFlag|=o}function Xu(...e){const t={};for(let o=0;o<e.length;o++){const i=e[o];for(const n in i)if(n==="class")t.class!==i.class&&(t.class=xe([t.class,i.class]));else if(n==="style")t.style=Qt([t.style,i.style]);else if(On(n)){const s=t[n],l=i[n];l&&s!==l&&!(Ae(s)&&s.includes(l))?t[n]=s?[].concat(s,l):l:l==null&&s==null&&!Pn(n)&&(t[n]=l)}else n!==""&&(t[n]=i[n])}return t}function Gt(e,t,o,i=null){qt(e,t,7,[o,i])}const Qu=pa();let ef=0;function tf(e,t,o){const i=e.type,n=(t?t.appContext:e.appContext)||Qu,s={uid:ef++,vnode:e,type:i,parent:t,appContext:n,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new $d(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(n.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:wa(i,n),emitsOptions:ma(i,n),emit:null,emitted:null,propsDefaults:Ze,inheritAttrs:i.inheritAttrs,ctx:Ze,data:Ze,props:Ze,attrs:Ze,slots:Ze,refs:Ze,setupState:Ze,setupContext:null,suspense:o,suspenseId:o?o.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return s.ctx={_:s},s.root=t?t.root:s,s.emit=Du.bind(null,s),e.ce&&e.ce(s),s}let xt=null;const of=()=>xt||gt;let Dn,As;{const e=Hn(),t=(o,i)=>{let n;return(n=e[o])||(n=e[o]=[]),n.push(i),s=>{n.length>1?n.forEach(l=>l(s)):n[0](s)}};Dn=t("__VUE_INSTANCE_SETTERS__",o=>xt=o),As=t("__VUE_SSR_SETTERS__",o=>Zi=o)}const en=e=>{const t=xt;return Dn(e),e.scope.on(),()=>{e.scope.off(),Dn(t)}},zr=()=>{xt&&xt.scope.off(),Dn(null)};function Ea(e){return e.vnode.shapeFlag&4}let Zi=!1;function nf(e,t=!1,o=!1){t&&As(t);const{props:i,children:n}=e.vnode,s=Ea(e);zu(e,i,s,t),Wu(e,n,o||t);const l=s?sf(e,t):void 0;return t&&As(!1),l}function sf(e,t){const o=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,Cu);const{setup:i}=o;if(i){vo();const n=e.setupContext=i.length>1?lf(e):null,s=en(e),l=Qi(i,e,0,[e.props,n]),r=Bl(l);if(ko(),s(),(r||e.sp)&&!fi(e)&&aa(e),r){if(l.then(zr,zr),t)return l.then(a=>{Hr(e,a)}).catch(a=>{Wn(a,e,0)});e.asyncDep=l}else Hr(e,l)}else Ba(e)}function Hr(e,t,o){De(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:qe(t)&&(e.setupState=Ql(t)),Ba(e)}function Ba(e,t,o){const i=e.type;e.render||(e.render=i.render||oo);{const n=en(e);vo();try{_u(e)}finally{ko(),n()}}}const rf={get(e,t){return kt(e,"get",""),e[t]}};function lf(e){const t=o=>{e.exposed=o||{}};return{attrs:new Proxy(e.attrs,rf),slots:e.slots,emit:e.emit,expose:t}}function Kn(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(Ql(Gd(e.exposed)),{get(t,o){if(o in t)return t[o];if(o in Ni)return Ni[o](e)},has(t,o){return o in t||o in Ni}})):e.proxy}function af(e,t=!0){return De(e)?e.displayName||e.name:e.name||t&&e.__name}function cf(e){return De(e)&&"__vccOpts"in e}const ye=(e,t)=>Xd(e,t,Zi),df="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Es;const Fr=typeof window<"u"&&window.trustedTypes;if(Fr)try{Es=Fr.createPolicy("vue",{createHTML:e=>e})}catch{}const Da=Es?e=>Es.createHTML(e):e=>e,uf="http://www.w3.org/2000/svg",ff="http://www.w3.org/1998/Math/MathML",ao=typeof document<"u"?document:null,jr=ao&&ao.createElement("template"),hf={insert:(e,t,o)=>{t.insertBefore(e,o||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,o,i)=>{const n=t==="svg"?ao.createElementNS(uf,e):t==="mathml"?ao.createElementNS(ff,e):o?ao.createElement(e,{is:o}):ao.createElement(e);return e==="select"&&i&&i.multiple!=null&&n.setAttribute("multiple",i.multiple),n},createText:e=>ao.createTextNode(e),createComment:e=>ao.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>ao.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,o,i,n,s){const l=o?o.previousSibling:t.lastChild;if(n&&(n===s||n.nextSibling))for(;t.insertBefore(n.cloneNode(!0),o),!(n===s||!(n=n.nextSibling)););else{jr.innerHTML=Da(i==="svg"?`<svg>${e}</svg>`:i==="mathml"?`<math>${e}</math>`:e);const r=jr.content;if(i==="svg"||i==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}t.insertBefore(r,o)}return[l?l.nextSibling:t.firstChild,o?o.previousSibling:t.lastChild]}},pf=Symbol("_vtc");function mf(e,t,o){const i=e[pf];i&&(t=(t?[t,...i]:[...i]).join(" ")),t==null?e.removeAttribute("class"):o?e.setAttribute("class",t):e.className=t}const Ln=Symbol("_vod"),La=Symbol("_vsh"),Bs={name:"show",beforeMount(e,{value:t},{transition:o}){e[Ln]=e.style.display==="none"?"":e.style.display,o&&t?o.beforeEnter(e):Mi(e,t)},mounted(e,{value:t},{transition:o}){o&&t&&o.enter(e)},updated(e,{value:t,oldValue:o},{transition:i}){!t!=!o&&(i?t?(i.beforeEnter(e),Mi(e,!0),i.enter(e)):i.leave(e,()=>{Mi(e,!1)}):Mi(e,t))},beforeUnmount(e,{value:t}){Mi(e,t)}};function Mi(e,t){e.style.display=t?e[Ln]:"none",e[La]=!t}const gf=Symbol(""),yf=/(?:^|;)\s*display\s*:/;function bf(e,t,o){const i=e.style,n=nt(o);let s=!1;if(o&&!n){if(t)if(nt(t))for(const l of t.split(";")){const r=l.slice(0,l.indexOf(":")).trim();o[r]==null&&Ai(i,r,"")}else for(const l in t)o[l]==null&&Ai(i,l,"");for(const l in o){l==="display"&&(s=!0);const r=o[l];r!=null?kf(e,l,!nt(t)&&t?t[l]:void 0,r)||Ai(i,l,r):Ai(i,l,"")}}else if(n){if(t!==o){const l=i[gf];l&&(o+=";"+l),i.cssText=o,s=yf.test(o)}}else t&&e.removeAttribute("style");Ln in e&&(e[Ln]=s?i.display:"",e[La]&&(i.display="none"))}const Wr=/\s*!important$/;function Ai(e,t,o){if(Ae(o))o.forEach(i=>Ai(e,t,i));else if(o==null&&(o=""),t.startsWith("--"))e.setProperty(t,o);else{const i=vf(e,t);Wr.test(o)?e.setProperty(Ro(i),o.replace(Wr,""),"important"):e[i]=o}}const Ur=["Webkit","Moz","ms"],rs={};function vf(e,t){const o=rs[t];if(o)return o;let i=Mt(t);if(i!=="filter"&&i in e)return rs[t]=i;i=Rn(i);for(let n=0;n<Ur.length;n++){const s=Ur[n]+i;if(s in e)return rs[t]=s}return t}function kf(e,t,o,i){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&nt(i)&&o===i}const Vr="http://www.w3.org/1999/xlink";function qr(e,t,o,i,n,s=_d(t)){i&&t.startsWith("xlink:")?o==null?e.removeAttributeNS(Vr,t.slice(6,t.length)):e.setAttributeNS(Vr,t,o):o==null||s&&!Pl(o)?e.removeAttribute(t):e.setAttribute(t,s?"":Ut(o)?String(o):o)}function Gr(e,t,o,i,n){if(t==="innerHTML"||t==="textContent"){o!=null&&(e[t]=t==="innerHTML"?Da(o):o);return}const s=e.tagName;if(t==="value"&&s!=="PROGRESS"&&!s.includes("-")){const r=s==="OPTION"?e.getAttribute("value")||"":e.value,a=o==null?e.type==="checkbox"?"on":"":String(o);(r!==a||!("_value"in e))&&(e.value=a),o==null&&e.removeAttribute(t),e._value=o;return}let l=!1;if(o===""||o==null){const r=typeof e[t];r==="boolean"?o=Pl(o):o==null&&r==="string"?(o="",l=!0):r==="number"&&(o=0,l=!0)}try{e[t]=o}catch{}l&&e.removeAttribute(n||t)}function To(e,t,o,i){e.addEventListener(t,o,i)}function wf(e,t,o,i){e.removeEventListener(t,o,i)}const Kr=Symbol("_vei");function xf(e,t,o,i,n=null){const s=e[Kr]||(e[Kr]={}),l=s[t];if(i&&l)l.value=i;else{const[r,a]=_f(t);if(i){const c=s[t]=Mf(i,n);To(e,r,c,a)}else l&&(wf(e,r,l,a),s[t]=void 0)}}const Sf=/(Once|Passive|Capture)$/,Cf=/^on:?(?:Once|Passive|Capture)$/;function _f(e){let t,o;for(;(o=e.match(Sf))&&!Cf.test(e);)t||(t={}),e=e.slice(0,e.length-o[1].length),t[o[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):Ro(e.slice(2)),t]}let ls=0;const If=Promise.resolve(),$f=()=>ls||(If.then(()=>ls=0),ls=Date.now());function Mf(e,t){const o=i=>{if(!i._vts)i._vts=Date.now();else if(i._vts<=o.attached)return;const n=o.value;if(Ae(n)){const s=i.stopImmediatePropagation;i.stopImmediatePropagation=()=>{s.call(i),i._stopped=!0};const l=n.slice(),r=[i];for(let a=0;a<l.length&&!i._stopped;a++){const c=l[a];c&&qt(c,t,5,r)}}else qt(n,t,5,[i])};return o.value=e,o.attached=$f(),o}const Yr=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,Tf=(e,t,o,i,n,s)=>{const l=n==="svg";t==="class"?mf(e,i,l):t==="style"?bf(e,o,i):On(t)?Pn(t)||xf(e,t,o,i,s):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):Af(e,t,i,l))?(Gr(e,t,i),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&qr(e,t,i,l,s,t!=="value")):e._isVueCE&&(Ef(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!nt(i)))?Gr(e,Mt(t),i,s,t):(t==="true-value"?e._trueValue=i:t==="false-value"&&(e._falseValue=i),qr(e,t,i,l))};function Af(e,t,o,i){if(i)return!!(t==="innerHTML"||t==="textContent"||t in e&&Yr(t)&&De(o));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const n=e.tagName;if(n==="IMG"||n==="VIDEO"||n==="CANVAS"||n==="SOURCE")return!1}return Yr(t)&&nt(o)?!1:t in e}function Ef(e,t){const o=e._def.props;if(!o)return!1;const i=Mt(t);return Array.isArray(o)?o.some(n=>Mt(n)===i):Object.keys(o).some(n=>Mt(n)===i)}const yi=e=>{const t=e.props["onUpdate:modelValue"]||!1;return Ae(t)?o=>un(t,o):t};function Bf(e){e.target.composing=!0}function Zr(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const yo=Symbol("_assign");function Jr(e,t,o){return t&&(e=e.trim()),o&&(e=zn(e)),e}const Ds={created(e,{modifiers:{lazy:t,trim:o,number:i}},n){e[yo]=yi(n);const s=i||n.props&&n.props.type==="number";To(e,t?"change":"input",l=>{l.target.composing||e[yo](Jr(e.value,o,s))}),(o||s)&&To(e,"change",()=>{e.value=Jr(e.value,o,s)}),t||(To(e,"compositionstart",Bf),To(e,"compositionend",Zr),To(e,"change",Zr))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:o,modifiers:{lazy:i,trim:n,number:s}},l){if(e[yo]=yi(l),e.composing)return;const r=(s||e.type==="number")&&!/^0\d/.test(e.value)?zn(e.value):e.value,a=t??"";if(r===a)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(i&&t===o||n&&e.value.trim()===a)||(e.value=a)}},an={deep:!0,created(e,t,o){e[yo]=yi(o),To(e,"change",()=>{const i=e._modelValue,n=Ji(e),s=e.checked,l=e[yo];if(Ae(i)){const r=qs(i,n),a=r!==-1;if(s&&!a)l(i.concat(n));else if(!s&&a){const c=[...i];c.splice(r,1),l(c)}}else if(vi(i)){const r=new Set(i);s?r.add(n):r.delete(n),l(r)}else l(Oa(e,s))})},mounted:Xr,beforeUpdate(e,t,o){e[yo]=yi(o),Xr(e,t,o)}};function Xr(e,{value:t,oldValue:o},i){e._modelValue=t;let n;if(Ae(t))n=qs(t,i.props.value)>-1;else if(vi(t))n=t.has(i.props.value);else{if(t===o)return;n=ki(t,Oa(e,!0))}e.checked!==n&&(e.checked=n)}const Df={deep:!0,created(e,{value:t,modifiers:{number:o}},i){e._modelValue=t,To(e,"change",()=>{const n=Array.prototype.filter.call(e.options,s=>s.selected).map(s=>o?zn(Ji(s)):Ji(s));e[yo](e.multiple?vi(e._modelValue)?new Set(n):n:n[0]),e._assigning=!0,Mn(()=>{e._assigning=!1})}),e[yo]=yi(i)},mounted(e,{value:t}){Qr(e,t)},beforeUpdate(e,{value:t},o){e._modelValue=t,e[yo]=yi(o)},updated(e,{value:t}){e._assigning||Qr(e,t)}};function Qr(e,t){const o=e.multiple,i=Ae(t);if(!(o&&!i&&!vi(t))){for(let n=0,s=e.options.length;n<s;n++){const l=e.options[n],r=Ji(l);if(o)if(i){const a=typeof r;a==="string"||a==="number"?l.selected=t.some(c=>String(c)===String(r)):l.selected=qs(t,r)>-1}else l.selected=t.has(r);else if(ki(Ji(l),t)){e.selectedIndex!==n&&(e.selectedIndex=n);return}}!o&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function Ji(e){return"_value"in e?e._value:e.value}function Oa(e,t){const o=t?"_trueValue":"_falseValue";return o in e?e[o]:t}const Lf=["ctrl","shift","alt","meta"],Of={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>Lf.some(o=>e[`${o}Key`]&&!t.includes(o))},eo=(e,t)=>{if(!e)return e;const o=e._withMods||(e._withMods={}),i=t.join(".");return o[i]||(o[i]=((n,...s)=>{for(let l=0;l<t.length;l++){const r=Of[t[l]];if(r&&r(n,t))return}return e(n,...s)}))},Pf={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},Nf=(e,t)=>{const o=e._withKeys||(e._withKeys={}),i=t.join(".");return o[i]||(o[i]=(n=>{if(!("key"in n))return;const s=Ro(n.key);if(t.some(l=>l===s||Pf[l]===s))return e(n)}))},Rf=yt({patchProp:Tf},hf);let el;function zf(){return el||(el=Vu(Rf))}const lr=((...e)=>{const t=zf().createApp(...e),{mount:o}=t;return t.mount=i=>{const n=Ff(i);if(!n)return;const s=t._component;!De(s)&&!s.render&&!s.template&&(s.template=n.innerHTML),n.nodeType===1&&(n.textContent="");const l=o(n,!1,Hf(n));return n instanceof Element&&(n.removeAttribute("v-cloak"),n.setAttribute("data-v-app","")),l},t});function Hf(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function Ff(e){return nt(e)?document.querySelector(e):e}const jf="slides-config.json",Lo={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0},Yt=jn({...Lo});function Wf(e){if(!e||typeof e!="object")return{...Lo};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():Lo.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers!==void 0?!!t.showUnorderedListMarkers:Lo.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers!==void 0?!!t.showOrderedListMarkers:Lo.showOrderedListMarkers}}function uo(e){if(!e||typeof e!="object")return{...Yt};const t=e;return t.enableWebServeJump!==void 0&&(Yt.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(Yt.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(Yt.normalizeHeadingSizes=!!t.normalizeHeadingSizes),t.showUnorderedListMarkers!==void 0&&(Yt.showUnorderedListMarkers=!!t.showUnorderedListMarkers),t.showOrderedListMarkers!==void 0&&(Yt.showOrderedListMarkers=!!t.showOrderedListMarkers),{...Yt}}function Yn(){return{...Yt}}function Pa(e,t,o){const i=(e||Lo.webServeUrl).trim(),n=i.startsWith("http://")||i.startsWith("https://")?i:`http://${i}`,s=(o==null?void 0:o.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(n);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",t),o!=null&&o.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",s),l.toString()}catch{const l=o!=null&&o.focus?"&focus=1":"";return`${n.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${l}&r=${s}`}}const ei={theme:"apple-basic",aspectRatio:"16/9",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",background:"",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0};function Uf(e){var n,s,l,r,a,c;const t=Yn();if(!e)return{...ei,normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers};const o=e[kr]!==void 0?e[kr]!=="false":t.showUnorderedListMarkers,i=e[wr]!==void 0?e[wr]!=="false":t.showOrderedListMarkers;return{theme:((n=e[ji])==null?void 0:n.trim())||ei.theme,aspectRatio:((s=e[Wi])==null?void 0:s.trim())||ei.aspectRatio,defaultTransition:((l=e[Ui])==null?void 0:l.trim())||ei.defaultTransition,colorSchema:((r=e[$l])==null?void 0:r.trim())||ei.colorSchema,spacing:((a=e[ks])==null?void 0:a.trim())||ei.spacing,background:((c=e[wn])==null?void 0:c.trim())||"",normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:o,showOrderedListMarkers:i}}function mo(e){var o,i,n,s,l;const t=(o=e.ial)==null?void 0:o[fo];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((i=e.markdown)==null?void 0:i.trim())==="---"||((n=e.markdown)==null?void 0:n.trim())==="***"||e.type==="b"&&(((s=e.markdown)==null?void 0:s.trim())==="---"||((l=e.content)==null?void 0:l.trim())==="---"))}function tl(e){const t={};let o="";if(!e)return{frontmatter:t,notes:o};e[be]&&(t.layout=e[be].trim()),e[wt]&&(t.transition=e[wt].trim()),e[ct]&&(t.background=e[ct].trim()),e[Ft]&&(t.image=e[Ft].trim()),e[ni]&&(t.class=e[ni].trim()),e[Bi]&&(t.spacing=e[Bi].trim()),e[mt]&&(t.layoutRatio=e[mt].trim()),e[si]&&(t.mask=e[si].trim()),e[qo]&&(t.maskRatio=e[qo].trim()),e[ri]&&(t.maskStyle=e[ri].trim()),e[li]&&(t.maskInitial=e[li].trim()),e[Jn]&&(o=e[Jn].trim());for(const[i,n]of Object.entries(e))if(i.startsWith("custom-slides-")&&![be,mt,si,qo,ri,li,wt,ct,Ft,ni,Bi,Jn,fo].includes(i)){const s=i.replace(/^custom-slides-/,"");try{t[s]=JSON.parse(n)}catch{t[s]=n}}return{frontmatter:t,notes:o}}function ol(e){const t={};if(!e)return t;const o=e[Ve];o!=null&&o!==""&&o!=="false"&&o!=="0"&&(t.isNote=!0);const i=e[Ye],n=e[ct];(i===Ml||n==="true"||n==="1")&&(t.isBackground=!0);const s=e[be];s===Cn||s===_n?t.imageLayout=s:(i===Cn||i===_n)&&(t.imageLayout=i);const l=e[Oe];if(l!=null&&(t.clicks=l.trim()),e[$t])try{const r=JSON.parse(e[$t]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[$t].trim()}}return e[Jo]&&(t.shikiLines=e[Jo].trim()),e[Vi]&&(t.maxHeight=e[Vi].trim()),e[Me]&&(t.slot=e[Me].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function bo(e,t){const o=(e||t||"").trim();if(!o)return null;const i=o.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(i)return i[1].trim();const n=o.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(n)return n[1].trim();const s=o.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(s)?s:null}function Ri(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const o=t[0],i=o.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!i)return e;const n=i[1].length,s=i[2].trim(),l=o.length-i[2].length;if(t.length===1)return s;const r=[s];for(let a=1;a<t.length;a++){const c=t[a];if(!c.trim()){r.push("");continue}const u=c.match(/^(\s*)/),p=u?u[1].length:0;p>=l?r.push(c.slice(l)):p>n?r.push(c.slice(p)):r.push(c)}return r.join(`
`)}function Po(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const o=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(o)}function as(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const o=e.trim();if(!o)return`repeat(${t}, 1fr)`;if(o.includes(":")){const n=o.split(":").map(s=>parseFloat(s.trim())).filter(s=>!isNaN(s)&&s>0);if(n.length>=2)return n.map(s=>`${s}fr`).join(" ")}const i=o.split(/\s+/).filter(Boolean);return i.length>=2?i.join(" "):`repeat(${t}, 1fr)`}function zi(e){if(!e)return[];if(ut(e)&&io(e)&&!no(e)){const i=xi(e),n=[];for(const s of i)n.push(...zi(s));return n}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const l=e.children.filter(Po);if(l.length>0)return l}const n=(e.markdown||e.content||"").trim().split(/\r?\n/),s=[];for(let l=0;l<n.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(n[l])&&s.push(l);if(s.length>=2){const l=[];for(let r=0;r<s.length;r++){const a=s[r],c=r+1<s.length?s[r+1]:n.length,u=n.slice(a,c).join(`
`);l.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:u,content:u,ial:{...e.ial||{}}})}return l}}return Po(e)?[e]:[]}function ar(e){var n;if(!e||!ut(e)||!io(e)||no(e))return null;const t=xi(e);if(t.length===0)return null;if(t.length===1&&ut(t[0])&&io(t[0])){const s=ar(t[0]);return s?{items:s.items,nestedSuperBlocks:[t[0],...s.nestedSuperBlocks]}:null}const o=[];for(const s of t)if(ut(s)){o.push(s);const l=((n=s.children)==null?void 0:n.filter(ut))||[];o.push(...l)}const i=t.map(zi);if(i.length>=2&&i.every(s=>s.length>0)){const s=i.flat();if(s.length>=2&&s.length<=6)return{items:s,nestedSuperBlocks:o}}if(t.length===2){const s=zi(t[0]),l=zi(t[1]);if(s.length+l.length>=2&&s.length+l.length<=6&&(s.length>0||l.length>0))return{items:[...s,...l],nestedSuperBlocks:o}}return null}function Vf(e){if(!e||!ut(e)||!io(e)||no(e))return null;const t=ar(e);if(!t)return null;const{items:o,nestedSuperBlocks:i}=t;if(o.length<2||o.length>6)return null;const n=cr(e)||void 0,s=o.length;return{superBlockNode:e,nestedSuperBlocks:i,count:s,layout:"cols-header",items:o,slots:o.map((l,r)=>`col-${r+1}`),ratio:n}}function Na(e){if(!e||!ut(e)||!io(e)||no(e))return null;const t=xi(e);if(t.length===0)return null;const o=[];for(const i of t){const n=zi(i);if(n.length===0)return null;o.push(...n)}return o}function qf(e){if(!e||!ut(e)||!io(e)||no(e))return null;const t=Na(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function Gf(e){if(!e||!ut(e)||!io(e)||no(e))return null;const t=ar(e);if(t&&t.items.length===4)return t.items;const o=Na(e);if(o&&o.length===4)return o;const i=xi(e);return i.length===4?i:null}function Kf(e,t){if(!e||e.length===0)return null;const o=[];function i(r,a){if(ut(r)){const c=Gf(r);c&&c.length===4&&o.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)i(c,a)}for(let r=0;r<e.length;r++)i(e[r],r);if(o.length===0)return null;let n=null;t&&(n=o.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const a=c=>c.id===t?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),n||(n=o[0]);const l=e.slice(0,n.topLevelIndex).slice().reverse().find(r=>Ra(r));return{superBlockNode:n.sbNode,items:n.items,headerNode:l}}function Yf(e,t,o){var u,p,y,d,h;const i=[],n=[],s=(o==null?void 0:o.tracked)||[],l=[];let r={pageTargetId:e,blocks:[]};l.push(r);for(let m=0;m<t.length;m++){const g=t[m];if(mo(g)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=g.id,r.blocks.push(g);continue}r={pageTargetId:g.id,blocks:[g]},l.push(r)}else r.blocks.push(g)}function a(m){const g=[];for(const b of m)ut(b)&&g.push(b),b.children&&b.children.length>0&&g.push(...a(b.children));return g}function c(m,g,b){const k={blockId:m,attrs:g,previousAttrs:b};i.push(k),o!=null&&o.onTagChange&&o.onTagChange(k)}for(const m of l){const g=m.pageTargetId,b=t.find(M=>M.id===g),k=s.find(M=>M.pageTargetId===g);if(m.blocks.some(M=>{var I,N;return!!(no(M)||Ls(M)&&(((I=M.ial)==null?void 0:I[be])==="image-left"||((N=M.ial)==null?void 0:N[be])==="image-right"))})){if(k){const M=k.headerId;if(M){c(M,{[Me]:""});const I=t.find(N=>N.id===M);I!=null&&I.ial&&(I.ial[Me]="")}for(const I of k.itemIds){c(I,{[Me]:""});const N=t.find(D=>D.id===I);N!=null&&N.ial&&(N.ial[Me]="")}}continue}let C=null,A=-1;for(let M=0;M<m.blocks.length;M++){const I=m.blocks[M],N=ut(I)?[I,...a(I.children||[])]:I.children?a(I.children):[];for(const D of N){const U=Vf(D);if(U){C=U,A=M;break}}if(C)break}if(C){const{superBlockNode:M,layout:I,items:N,slots:D}=C,W=m.blocks.slice(0,A).find($=>Ra($)),E=W==null?void 0:W.id,P=((u=b==null?void 0:b.ial)==null?void 0:u[be])||"",x=P==="clover",K=x?"clover":I;if(P!==K&&(c(g,{[be]:K},{[be]:P}),b&&(b.ial||(b.ial={}),b.ial[be]=K)),W){const $=((p=W.ial)==null?void 0:p[Me])||"";$!=="header"&&(c(W.id,{[Me]:"header"},{[Me]:$}),W.ial||(W.ial={}),W.ial[Me]="header")}if(k!=null&&k.headerId&&k.headerId!==E){c(k.headerId,{[Me]:""});const $=t.find(T=>T.id===k.headerId);$&&($.ial||($.ial={}),$.ial[Me]="")}const j=[];for(let $=0;$<N.length;$++){const T=N[$],O=D[$];j.push(T.id);const te=((y=T.ial)==null?void 0:y[Me])||"";if(te!==O&&(c(T.id,{[Me]:O},{[Me]:te}),T.ial||(T.ial={}),T.ial[Me]=O),T.children&&T.children.length>0)for(const Y of T.children)Y.ial||(Y.ial={}),Y.ial[Me]!==O&&(Y.ial[Me]=O)}if(k!=null&&k.itemIds){for(const $ of k.itemIds)if(!j.includes($)){c($,{[Me]:""});const T=t.find(O=>O.id===$);T&&(T.ial||(T.ial={}),T.ial[Me]="")}}n.push({superBlockId:M.id,nestedSuperBlockIds:(d=C.nestedSuperBlocks)==null?void 0:d.map($=>$.id),pageTargetId:g,headerId:E,itemIds:j,layout:x?"clover":I})}else{let M=!1;const I=[];for(const U of m.blocks){const W=ut(U)?[U,...a(U.children||[])]:U.children?a(U.children):[];for(const E of W){const P=qf(E);if(P){M=!0;for(const x of P.items)I.push(x.id)}}}const N=((h=b==null?void 0:b.ial)==null?void 0:h[be])||"",D=ai(N);if(k||M&&D){c(g,{[be]:""},{[be]:N}),b&&(b.ial||(b.ial={}),b.ial[be]="");const U=k==null?void 0:k.headerId;if(U){c(U,{[Me]:""});const E=t.find(P=>P.id===U);E&&(E.ial||(E.ial={}),E.ial[Me]="")}const W=new Set([...(k==null?void 0:k.itemIds)||[],...I]);for(const E of W){c(E,{[Me]:""});const P=t.find(x=>x.id===E);P&&(P.ial||(P.ial={}),P.ial[Me]="")}}}}return{changes:i,newTracked:n}}function ut(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function io(e){if(!ut(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const i=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(i==="col"||i==="h")return!0;if(i==="row"||i==="v")return!1}if(e.children&&e.children.length>0){for(const i of e.children)if(i.type==="NodeSuperBlockLayoutMarker"||i.type==="layout-marker"){const n=(i.content||i.markdown||"").trim().toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}}const o=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(o)?!0:!/^\{\{\{row\b/i.test(o)}function Ls(e){return!e||Po(e)||ut(e)||!bo(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function cr(e){var y;if(!e||!ut(e)||!io(e))return null;const t=xi(e);if(!t||t.length<2)return null;const o=[];let i=!1;for(const d of t){const h=(((y=d.ial)==null?void 0:y.style)||d.style||"").trim();let m=null;if(h){const g=h.match(/calc\(\s*([\d.]+)%/i);if(g)m=parseFloat(g[1]);else{const b=h.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);b&&(m=parseFloat(b[1]))}}m!==null&&!isNaN(m)&&m>0?(o.push(m),i=!0):o.push(null)}if(!i)return null;const n=t.length,s=o.reduce((d,h)=>d+(h||0),0),l=o.filter(d=>d===null).length,r=Math.max(0,100-s),a=l>0?r/l:100/n,c=o.map(d=>d!==null?d:a),u=c.reduce((d,h)=>d+h,0);if(u<=0)return null;const p=c.map(d=>d/u*100);if(p.length===2){const[d]=p;if(d>=48&&d<=52)return"1:1";if(d>=31&&d<=35)return"1:2";if(d>=65&&d<=69)return"2:1";if(d>=28&&d<=32)return"3:7";if(d>=68&&d<=72)return"7:3";if(d>=38&&d<=42)return"4:6";if(d>=58&&d<=62)return"6:4";if(d>=23&&d<=27)return"1:3";if(d>=73&&d<=77)return"3:1";const h=Math.round(d),m=100-h;return`${h}:${m}`}if(p.length===3){const[d,h,m]=p;if(d>=31&&d<=35&&h>=31&&h<=35&&m>=31&&m<=35)return"1:1:1";if(d>=23&&d<=27&&h>=48&&h<=52&&m>=23&&m<=27)return"1:2:1";if(d>=48&&d<=52&&h>=23&&h<=27&&m>=23&&m<=27)return"2:1:1";if(d>=23&&d<=27&&h>=23&&h<=27&&m>=48&&m<=52)return"1:1:2";if(d>=18&&d<=22&&h>=58&&h<=62&&m>=18&&m<=22)return"1:3:1";const g=Math.round(d),b=Math.round(h),k=100-g-b;return`${g}:${b}:${k}`}return p.map(d=>Math.round(d)).join(":")}function no(e){if(!e||!ut(e)||!io(e))return null;const t=(e.children||[]).filter(s=>{const l=s.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const o=Ls(t[0]),i=Ls(t[t.length-1]),n=cr(e)||void 0;if(o&&!i){const s=bo(t[0].markdown,t[0].content);if(s)return{imageNode:t[0],imageUrl:s,layout:Cn,contentNodes:t.slice(1),ratio:n}}if(!o&&i){const s=bo(t[t.length-1].markdown,t[t.length-1].content);if(s)return{imageNode:t[t.length-1],imageUrl:s,layout:_n,contentNodes:t.slice(0,t.length-1),ratio:n}}return null}function Zf(e,t){const o=[];function i(n){for(const s of n){const l=no(s);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const u=r.ial[be];if(u!==a){const y={blockId:r.id,layout:a,previousLayout:u,ratio:c};r.ial[be]=a,o.push(y),t&&t(y)}}s.children&&s.children.length>0&&i(s.children)}}return i(e),o}function xi(e){return(e.children||[]).filter(t=>{const o=t.type||"";if(o==="NodeSuperBlockOpenMarker"||o==="NodeSuperBlockLayoutMarker"||o==="NodeSuperBlockCloseMarker"||o==="open-marker"||o==="layout-marker"||o==="close-marker")return!1;const i=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(i)||i==="}}}")})}function Ra(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const o=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(o)}function Fo(e,t,o){let i="",n=0;const s=/<div\b([^>]*)>/gi;for(;n<e.length;){s.lastIndex=n;let l,r=!1,a=-1,c=0;for(;(l=s.exec(e))!==null;){const b=l[1].match(/\bclass=["']([^"']*)["']/i);if(b){const k=b[1];if(typeof t=="string"?k.split(/\s+/).includes(t):t.test(k)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){i+=e.slice(n);break}i+=e.slice(n,a);const u=a+c;let p=1,y=-1,d=-1;const h=/<\/?div\b[^>]*>/gi;h.lastIndex=u;let m;for(;(m=h.exec(e))!==null;)if(m[0].startsWith("</")){if(p--,p===0){y=m.index,d=m.index+m[0].length;break}}else p++;if(y!==-1&&d!==-1){const g=e.slice(u,y);i+=o(g),n=d}else i+=e.slice(a,u),n=u}return i}function Jf(e){const t=[];let o="",i=0;const n=/<div\b([^>]*)>/gi;for(;i<e.length;){n.lastIndex=i;let s,l=!1,r=-1,a=0;for(;(s=n.exec(e))!==null;){const m=s[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(m)){l=!0,r=s.index,a=s[0].length;break}}if(!l){o+=e.slice(i);break}o+=e.slice(i,r);const c=r+a;let u=1,p=-1,y=-1;const d=/<\/?div\b[^>]*>/gi;d.lastIndex=c;let h;for(;(h=d.exec(e))!==null;)if(h[0].startsWith("</")){if(u--,u===0){p=h.index,y=h.index+h[0].length;break}}else u++;if(p!==-1&&y!==-1){const m=e.slice(r,y),g=`__VUE_DIV_TOKEN_${t.length}__`;t.push(m),o+=g,i=y}else o+=e.slice(r,c),i=c}return{text:o,tokens:t}}function Xf(e){const t=[];let o=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});o=o.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});const i=[];o=o.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${i.length}__`;return i.push(r),a});const{text:n,tokens:s}=Jf(o);o=n;const l=[];o=o.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),o=o.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),o=o.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),o=o.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),o=o.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),o=o.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),o=o.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),o=o.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),o=o.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),o=o.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(u=>`\`${u[1].trim()}\``).join(" | ")}
`),o=o.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),o=Fo(o,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const u=c[2].trim().toUpperCase(),p=c[3].trim();return`**${u}:**
\`\`\`yaml
${p}
\`\`\``}).join(`

`)+`
`:r}),o=Fo(o,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let u=`
`;return a&&(u+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(u+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),u.trim()?u:r}),o=o.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(u=>`- ${u[1]} ${u[2].trim()}`).join(`
`)+`
`:a}),o=Fo(o,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const u=c[1]||"";let p="-";return u.includes("warn")?p="- ⚠️":u.includes("bad")?p="- ❌":u.includes("ok")&&(p="- ✅"),`${p} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),o=Fo(o,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,u)=>{const y=(c[1]||"").includes("hot")?"⚠️ ":"";return`${u+1}. ${y}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),o=Fo(o,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),o=Fo(o,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),o=Fo(o,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),o=o.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),o=o.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),o=o.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),o=o.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),o=o.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),o=o.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),o=o.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),o=o.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),o=o.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),o=o.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),o=o.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),o=o.replace(/<br\s*\/?>/gi,`
`),o=o.replace(/<hr\s*\/?>/gi,`
---
`),o=o.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),o=o.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),o=o.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),o=o.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((p,y)=>Math.max(p,y.length),0),u="`".repeat(c+1);return`${u} ${a} ${u}`}return`\`${a}\``}),o=o.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),o=o.replace(/\*{4}/g,"** **"),o=o.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),o=o.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),o=o.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),o=o.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,u,p)=>{const y=p.trim();return y.includes("<")||y.includes(`
`)?r:`[${y}](${c})`}),o=o.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),o=o.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const u=c.replace(/<[^>]+>/g,"").trim();return u?`((${a} '${u}'))`:`((${a}))`}),o=o.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),o=o.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),o=o.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),o=o.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)o=o.replace(`__VUE_COMP_TOKEN_${r}__`,()=>l[r]);for(let r=0;r<s.length;r++)o=o.replace(`__VUE_DIV_TOKEN_${r}__`,()=>s[r]);for(let r=0;r<i.length;r++)o=o.replace(`__SCRIPT_TOKEN_${r}__`,()=>i[r]);for(let r=0;r<t.length;r++)o=o.replace(`__CODE_TOKEN_${r}__`,()=>t[r]);return o=o.replace(/\n{3,}/g,`

`).trim(),o}function za(e){if(!e||typeof e!="string")return"";const t=[];let o=e.replace(/`([^`]+)`/g,i=>(t.push(i),`%%INLINE_CODE_${t.length-1}%%`));return o=o.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),o=o.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),o=o.replace(/\{:[^}]*\}/g,""),o=o.replace(/%%INLINE_CODE_(\d+)%%/g,(i,n)=>t[parseInt(n,10)]||""),o}function Os(e){if(!e)return"";const t=e.trim();return t?/^\d+$/.test(t)?`${t}px`:/^(\d+(?:\.\d+)?)%$/.test(t)?`${t.slice(0,-1)}cqh`:/^(\d+(?:\.\d+)?)vh$/.test(t)?`${t.slice(0,-2)}cqh`:t:""}function dr(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let n=t.split(/\r?\n/).map(s=>s.trim().replace(/^>\s*/,"")).join(`
`).trim();return n=n.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),n=n.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),n=n.replace(/^[-*+]\s+/,""),n=n.replace(/^\d+\.\s+/,""),n.trim()}function Qf(e){var i;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const o=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return o?o[1].length:e.type==="h"?(i=e.ial)!=null&&i.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function Ps(e,t=2){const o=Math.max(2,t);if(!e||e.length===0)return Array.from({length:o},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,u=Array.from({length:o},()=>[]),p=Math.min(o,c.length),y=Math.floor(c.length/p),d=c.length%p;let h=0;for(let m=0;m<p;m++){const g=y+(m<d?1:0);u[m]=c.slice(h,h+g),h+=g}return u}if(e.length===1){const c=e[0],p=(c.slot||"").trim().match(/^col-(\d+)$/i),y=p?parseInt(p[1],10):null,d=(c.rawMarkdown||c.content||"").trim(),h=d.split(/\r?\n/),m=[];for(let k=0;k<h.length;k++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(h[k])&&m.push(k);if(m.length>=o){const k=Array.from({length:o},()=>[]);let w=0;for(let C=0;C<o;C++){const A=o-C,M=m.length-w,I=Math.ceil(M/A),N=m[w],D=w+I<m.length?m[w+I]:h.length,U=h.slice(N,D).join(`
`);k[C]=[{...c,id:C===0?c.id:`${c.id}-col${C+1}`,rawMarkdown:U,content:U}],w+=I}return k}const g=d.match(/<li[\s\S]*?<\/li>/gi);if(g&&g.length>=o){const k=Array.from({length:o},()=>[]);let w=0;for(let C=0;C<o;C++){const A=o-C,M=g.length-w,I=Math.ceil(M/A),N=`<ul>
${g.slice(w,w+I).join(`
`)}
</ul>`;k[C]=[{...c,id:C===0?c.id:`${c.id}-col${C+1}`,rawMarkdown:N,content:N}],w+=I}return k}const b=d.split(/\r?\n\s*\r?\n/).filter(k=>k.trim()!=="");if(b.length>=o){const k=Array.from({length:o},()=>[]);let w=0;for(let C=0;C<o;C++){const A=o-C,M=b.length-w,I=Math.ceil(M/A),N=b.slice(w,w+I).join(`

`);k[C]=[{...c,id:C===0?c.id:`${c.id}-col${C+1}`,rawMarkdown:N,content:N}],w+=I}return k}if(y&&y>=1&&y<=o){const k=Array.from({length:o},()=>[]);return k[y-1]=[c],k}return[[c],...Array.from({length:o-1},()=>[])]}const i=c=>{const u=(c.slot||"").trim();if(!u)return null;if(u==="left")return 1;if(u==="center")return 2;if(u==="right")return o===2?2:o;const p=u.match(/^col-(\d+)$/i);if(p){const y=parseInt(p[1],10);if(y>=1&&y<=o)return y}return null},n=e.map(i);if(n.some(c=>c!==null)){if(n.some(d=>d!==null&&d>=2)){const d=Array.from({length:o},()=>[]);let h=1;for(const g of e){const b=i(g);b!==null&&(h=b),d[h-1].push(g)}if(!e.some(g=>/^col-\d+$/i.test((g.slot||"").trim()))&&d[0].length===0){const g=d.filter(b=>b.length>0);if(g.length===1)return[g[0],...Array.from({length:o-1},()=>[])]}return d}const u=e.filter(d=>i(d)===1),p=e.filter(d=>i(d)===null),y=o-1;if(p.length>=y){const d=Math.floor(p.length/y),h=p.length%y,m=[u];let g=0;for(let b=0;b<y;b++){const k=d+(b<h?1:0);m.push(p.slice(g,g+k)),g+=k}return m}else if(p.length>0){const d=[u];for(let h=0;h<y;h++)d.push(h<p.length?[p[h]]:[]);return d}else return[u,...Array.from({length:y},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const u=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(u)},r=e.map((c,u)=>l(c)?u:-1).filter(c=>c!==-1);if(r.length>=o){const c=Array.from({length:o},()=>[]);for(let u=0;u<o;u++){const p=r[u],y=u+1<o?r[u+1]:e.length;c[u]=e.slice(p,y)}return c}if(e.length>=o){const c=Array.from({length:o},()=>[]);let u=0;for(let p=0;p<o;p++){const y=o-p,d=e.length-u,h=Math.ceil(d/y);c[p]=e.slice(u,u+h),u+=h}return c}if(e.length>1&&e.length<o){const c=Array.from({length:o},()=>[]);for(let u=0;u<e.length;u++)c[u]=[e[u]];return c}const a=Array.from({length:o},()=>[]);return a[0]=e,a}function il(e,t,o,i){const n=Uf(t),s=[],l=tl(t),r=n.background?Et(n.background,i):void 0;let a={pageIndex:1,startBlockId:e,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};a.frontmatter.background&&(a.frontmatter.background=Et(a.frontmatter.background,i)),a.frontmatter.image&&(a.frontmatter.image=Et(a.frontmatter.image,i));const c=d=>{const h=[];for(let m=d;m<o.length&&!(m>d&&mo(o[m]));m++)h.push(o[m]);return h},u=d=>{let h,m,g;const b=k=>{var I;if(h)return;const w=no(k);if(w){h=w.layout,m=w.imageUrl,g=w.ratio;return}const C=vr(k),A=k.ial?{...k.ial}:{},M=ol(A);if(M.imageLayout==="image-left"||M.imageLayout==="image-right"){const N=bo(C,k.content);if(N){h=M.imageLayout,m=N,g=(I=k.ial)==null?void 0:I[mt];return}}if(k.children&&k.children.length>0){for(const N of k.children)if(b(N),h)return}};for(const k of d)if(b(k),h)break;return{foundLayout:h,foundImage:m,foundRatio:g}},p=(d,h)=>{const{foundLayout:m,foundImage:g,foundRatio:b}=u(h);m&&(d.frontmatter.layout=m,g&&(d.frontmatter.image=Et(g,i)),b&&!d.frontmatter.layoutRatio&&(d.frontmatter.layoutRatio=b))};p(a,c(0)),s.push(a);let y=[];for(let d=0;d<o.length;d++){const h=o[d];if(mo(h)){y=[];const g=tl(h.ial);if(s.length===1&&a.blocks.length===0){a.startBlockId=h.id,a.allBlockIds||(a.allBlockIds=[]),a.allBlockIds.includes(h.id)||a.allBlockIds.push(h.id),g.frontmatter.layout&&(a.frontmatter.layout=g.frontmatter.layout),Object.assign(a.frontmatter,g.frontmatter),delete a.frontmatter.background,!g.frontmatter.image&&l.frontmatter.image&&(a.frontmatter.image=l.frontmatter.image),r&&(a.frontmatter.background=r),a.frontmatter.background&&(a.frontmatter.background=Et(a.frontmatter.background,i)),a.frontmatter.image&&(a.frontmatter.image=Et(a.frontmatter.image,i)),p(a,c(d+1));continue}a={pageIndex:s.length+1,startBlockId:h.id,frontmatter:{layout:g.frontmatter.layout||"default",...g.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[h.id]},r||delete a.frontmatter.background,a.frontmatter.background&&(a.frontmatter.background=Et(a.frontmatter.background,i)),a.frontmatter.image&&(a.frontmatter.image=Et(a.frontmatter.image,i)),p(a,c(d+1)),s.push(a);continue}const m=(g,b)=>{var ce,oe,ne,Ce,_e,ke,Ie;if(a.allBlockIds||(a.allBlockIds=[]),g.id&&!a.allBlockIds.includes(g.id)&&a.allBlockIds.push(g.id),g.children&&g.children.length>0){const R=ie=>{for(const B of ie)B.id&&!a.allBlockIds.includes(B.id)&&a.allBlockIds.push(B.id),B.children&&B.children.length>0&&R(B.children)};R(g.children)}let k=vr(g),w=g.ial?{...g.ial}:{};const C=k.match(/\{:\s*([^}]+)\s*\}\s*$/);C&&(w={..._l(C[0]),...w},k=k.slice(0,C.index).trim()),g.type!=="c"&&!k.startsWith("```")&&(k=za(k));let A=k.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(A)||A==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(A)&&/\r?\n\}\}\}$/.test(A)&&(k=A.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),A=k.trim());const M=ol(w);if(k=md(k,i),k=hd(k,i==null?void 0:i.refContentMap),g.children&&g.children.length>0){const R=["custom-slides-autoplay","custom-slides-loop","custom-slides-muted","custom-slides-controls"],ie=B=>{for(const H of B){if(H.ial)for(const[v,F]of Object.entries(H.ial))R.includes(v)&&!w[v]&&(w[v]=F);H.children&&H.children.length>0&&ie(H.children)}};ie(g.children)}const I=g.type==="video"||g.type==="NodeVideo"||/<video\b/i.test(k);if(I){const R=w["custom-slides-autoplay"]==="true",ie=w["custom-slides-loop"]==="true",B=w["custom-slides-muted"]==="true"||R,H=w["custom-slides-controls"]==="false";k=k.replace(/<video\b([^>]*)>/gi,(v,F)=>{let z=F;return H?z=z.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(z)||(z+=" controls"),R&&!/autoplay/i.test(z)?z+=" autoplay playsinline":!R&&w["custom-slides-autoplay"]==="false"&&(z=z.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),ie&&!/loop/i.test(z)?z+=" loop":!ie&&w["custom-slides-loop"]==="false"&&(z=z.replace(/\bloop\b/gi,"").trim()),B&&!/muted/i.test(z)?z+=" muted":!B&&w["custom-slides-muted"]==="false"&&(z=z.replace(/\bmuted\b/gi,"").trim()),`<video ${z.trim()}>`})}if(M.isBackground){const R=bo(k,g.content);if(R){a.frontmatter.background=Et(R,i);return}}const N=no(g);if(N){a.frontmatter.layout=N.layout,a.frontmatter.image=Et(N.imageUrl,i),!a.frontmatter.layoutRatio&&N.ratio&&(a.frontmatter.layoutRatio=N.ratio);for(const R of N.contentNodes)m(R);return}if(M.imageLayout==="image-left"||M.imageLayout==="image-right"){const R=bo(k,g.content);if(R){a.frontmatter.layout=M.imageLayout,a.frontmatter.image=Et(R,i),!a.frontmatter.layoutRatio&&((ce=g.ial)!=null&&ce[mt])&&(a.frontmatter.layoutRatio=g.ial[mt]);return}}if(ut(g)&&g.children&&g.children.length>0){for(const R of g.children)m(R);return}const D=!!(M.slot||b!=null&&b.defaultSlot||a.frontmatter.layout==="clover"||ai(a.frontmatter.layout)||a.frontmatter.layout==="two-cols"),U=!!(g.children&&g.children.some(R=>{var ie,B;return((ie=R.ial)==null?void 0:ie[Me])||((B=R.ial)==null?void 0:B[Oe])||R.children&&R.children.length>=2||R.children&&R.children.some(H=>{var v,F,z,S,_,L;return((v=H.ial)==null?void 0:v[Oe])||((F=H.ial)==null?void 0:F[Me])||((z=H.ial)==null?void 0:z[Ye])||((S=H.ial)==null?void 0:S[be])||((_=H.ial)==null?void 0:_["custom-slides-role"])||((L=H.ial)==null?void 0:L["custom-slides-layout"])})}));if((g.type==="l"||g.type==="NodeList"||g.type==="list")&&g.children&&g.children.length>0&&(U||M.slot||M.clicks||D)){const R=/^\s*\d+\.\s+/m.test(g.markdown||"")||g.subType==="o"||g.subtype==="o";for(let ie=0;ie<g.children.length;ie++){const B=g.children[ie];M.slot&&(!B.ial||!B.ial[Me])&&(B.ial||(B.ial={}),B.ial[Me]=M.slot),m(B,{...b,parentClicks:M.clicks||(b==null?void 0:b.parentClicks),defaultSlot:M.slot||(b==null?void 0:b.defaultSlot),isParentListUnpacked:!0,isListItem:!0,listContext:{isOrdered:R,itemIndex:ie+1}})}return}const W=!!(b!=null&&b.isParentListUnpacked),E=!!(g.children&&g.children.length>=2)||!!M.clicks||!!((oe=g.children)!=null&&oe.some(R=>{var ie;return(ie=R.ial)==null?void 0:ie[Oe]}))||W||!g.markdown&&!!(g.children&&g.children.length>0);if(Po(g)&&g.children&&g.children.length>0&&(D||W||M.clicks||g.children.some(R=>{var ie;return(ie=R.ial)==null?void 0:ie[Oe]}))&&E){const R=!!(g.children&&g.children.length>=2),ie=g.children.find(_=>!!(_.markdown||_.content||"").trim())||g.children[0],B=((ne=ie==null?void 0:ie.ial)==null?void 0:ne[Oe])||((Ce=ie==null?void 0:ie.ial)==null?void 0:Ce["custom-slides-click"]),H=!!(!M.clicks&&R&&B),v=M.clicks||(H?B:void 0)||(b==null?void 0:b.parentClicks),F=g.id||(b==null?void 0:b.parentContainerId),z=M.slot||(b==null?void 0:b.defaultSlot);let S=!0;for(const _ of g.children){z&&(!_.ial||!_.ial[Me])&&(_.ial||(_.ial={}),_.ial[Me]=z);const L=!!(_.markdown||_.content||"").trim(),q=S&&L;if(q){if(!(a.frontmatter.layout==="image-right"||a.frontmatter.layout==="image-left")&&!!(a.frontmatter.layout==="clover"||ai(a.frontmatter.layout)||a.frontmatter.layout==="two-cols")&&!!(b!=null&&b.defaultSlot||M.slot||(_e=g.ial)!=null&&_e[Me]))_.markdown&&(_.markdown=Ri(_.markdown)),_.content&&(_.content=Ri(_.content));else{const se=!!((ke=b==null?void 0:b.listContext)!=null&&ke.isOrdered),me=((Ie=b==null?void 0:b.listContext)==null?void 0:Ie.itemIndex)||1,Se=se?`${me}. `:"- ",we=Le=>{if(!Le)return Se.trim();const He=Le.trim();return/^[-*+]\s+/.test(He)||/^\d+\.\s+/.test(He)?Le:`${Se}${Le}`};_.markdown&&(_.markdown=we(_.markdown)),_.content&&(_.content=we(_.content))}S=!1}let V=_;q&&v&&R?(V={..._,ial:{..._.ial||{}}},delete V.ial[Oe],delete V.ial["custom-slides-click"]):!R&&v&&(V={..._,ial:{..._.ial||{},[Oe]:v}}),m(V,{...b,parentClicks:v,parentContainerId:F,defaultSlot:z,isListItem:!0})}return}if(M.isNote){const R=dr(k);R&&(a.notes?a.notes+=`

`+R:a.notes=R),a.noteBlocks||(a.noteBlocks=[]),a.noteBlocks.push({id:g.id,type:g.type,content:R||g.content||"",rawMarkdown:k,isNote:!0,attributes:g.ial});return}A=k.trim();const P=(g.content||"").trim();if(A==="::right::"||P==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(A)||A.startsWith("::right::")){a.blocks.push({id:g.id,type:g.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:g.ial});return}const K=Qf(g);let j=M.slot,$=M.clicks,T=M.motion,O={...g.ial||{}};if(K!==null){for(;y.length>0&&y[y.length-1].level>=K;)y.pop();const R=y.length>0?y[y.length-1]:void 0;!j&&(R!=null&&R.slot)&&(j=R.slot),!$&&(R!=null&&R.clicks)&&!(b!=null&&b.parentContainerId)&&($=R.clicks),!T&&(R!=null&&R.motion)&&(T=R.motion);const ie={...(R==null?void 0:R.customAttrs)||{}};if(g.ial)for(const[B,H]of Object.entries(g.ial))B.startsWith("custom-slides-")&&!B.startsWith("custom-slides-slide")&&(ie[B]=H);b!=null&&b.parentContainerId||y.push({level:K,slot:j,clicks:$,motion:T,customAttrs:ie})}else{const R=y.length>0?y[y.length-1]:void 0;R&&(!j&&R.slot&&R.slot!=="header"&&(j=R.slot),!$&&R.clicks&&!(b!=null&&b.parentContainerId)&&($=R.clicks),!T&&R.motion&&(T=R.motion),R.customAttrs&&(O={...R.customAttrs,...O}))}!j&&a.blocks.some(R=>R.slot==="slot-divider-right")&&(j="right"),!j&&(b!=null&&b.defaultSlot)&&(j=b.defaultSlot),j&&(O[Me]=j),$&&!O[Oe]&&(O[Oe]=$),T&&!O[$t]&&(O[$t]=JSON.stringify(T)),(I||w["custom-slides-autoplay"]||w["custom-slides-muted"])&&(w["custom-slides-autoplay"]&&(O["custom-slides-autoplay"]=w["custom-slides-autoplay"],w["custom-slides-autoplay"]==="true"&&!w["custom-slides-muted"]&&(O["custom-slides-muted"]="true")),w["custom-slides-loop"]&&(O["custom-slides-loop"]=w["custom-slides-loop"]),w["custom-slides-muted"]&&(O["custom-slides-muted"]=w["custom-slides-muted"]),w["custom-slides-controls"]&&(O["custom-slides-controls"]=w["custom-slides-controls"]));const te=M.maxHeight?Os(M.maxHeight):void 0,Y=!!(b!=null&&b.isListItem||Po(g)),Z={id:g.id,type:g.type,content:g.content||"",rawMarkdown:k,clicks:$,parentClicks:b==null?void 0:b.parentClicks,parentContainerId:b==null?void 0:b.parentContainerId,motion:T,shikiLines:M.shikiLines,maxHeight:te,slot:j,attributes:O,attrs:O,rawNode:g,isListItem:Y};a.blocks.push(Z)};m(h)}for(let d=0;d<s.length;d++){const h=s[d],m=h.blocks.filter(k=>k.slot!=="slot-divider-right"),g=k=>{const w=k.filter(I=>!!(I.rawMarkdown||I.content||"").trim());if(w.length===0)return;const C=w[0],A=(C.rawMarkdown||C.content||"").trim();(Po(C)||/^(?:[-*+]|\d+\.)\s+/.test(A))&&(C.rawMarkdown=Ri(C.rawMarkdown||C.content||""),C.content=C.rawMarkdown)},b=h.frontmatter.layout||"default";if(b==="clover"||ai(b)){let k=[];const w=m.filter(N=>N.slot==="header");if(w.length>0)k=w;else if(m.length>0){const N=m.find(D=>D.type==="h"&&(!D.slot||D.slot==="default"));N&&(k=[N])}const C=m.filter(N=>!k.includes(N));let A=2;if(b==="clover")A=4;else if(b==="three-cols-header")A=3;else if(b==="two-cols-header")A=2;else{let N=0;for(const D of C){const U=(D.slot||"").match(/^col-(\d+)$/i);U&&(N=Math.max(N,parseInt(U[1],10)))}if(N>=2)A=N;else if(h.frontmatter.layoutRatio){const D=h.frontmatter.layoutRatio.trim();if(D.includes(":")){const U=D.split(":").map(W=>parseFloat(W.trim())).filter(W=>!isNaN(W)&&W>0);U.length>=2&&(A=U.length)}else{const U=D.split(/\s+/).filter(Boolean);U.length>=2&&(A=U.length)}}else C.length===1&&C[0].children&&C[0].children.length>=2&&(A=Math.min(6,C[0].children.length))}const M=Ps(C,A);M.forEach((N,D)=>{const U=`col-${D+1}`;for(const W of N)(!W.slot||W.slot==="default")&&(W.slot=U);g(N)});const I=M.flat();if(C.length===1&&I.length>1){const N=h.blocks.findIndex(D=>D.id===C[0].id);N!==-1&&h.blocks.splice(N,1,...I)}}else if(b==="two-cols"){const k=m.filter(C=>C.slot==="right"),w=m.filter(C=>!C.slot||C.slot==="default");if(k.length===0&&w.length>=2){const[,C]=Ps(w,2);for(const A of C)A.slot="right"}g(m.filter(C=>C.slot!=="right")),g(m.filter(C=>C.slot==="right"))}h.rawMarkdown=h.blocks.filter(k=>k.slot!=="slot-divider-right").map(k=>k.rawMarkdown||k.content||"").filter(Boolean).join(`

`).trim()}return{docId:e,config:n,slides:s}}const nl=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function eh(e){var n,s,l,r,a,c,u,p,y,d,h,m;if(!e||typeof e!="object")return"";const t=[],o=[];if(Array.isArray(e.styles))for(const g of e.styles){if(!g||!g.id)continue;const b=`--b3-inline-style-${g.id}`;(n=g.light)!=null&&n.color&&t.push(`  ${b}-color: ${g.light.color};`),(s=g.light)!=null&&s.backgroundColor&&t.push(`  ${b}-background-color: ${g.light.backgroundColor};`),(l=g.dark)!=null&&l.color&&o.push(`  ${b}-color: ${g.dark.color};`),(r=g.dark)!=null&&r.backgroundColor&&o.push(`  ${b}-background-color: ${g.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const g of e.builtin.colors){if(!g||typeof g.index!="number")continue;const b=g.index;(a=g.light)!=null&&a.color&&t.push(`  --b3-font-color${b}: ${g.light.color};`),(c=g.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${b}: ${g.light.backgroundColor};`),(u=g.dark)!=null&&u.color&&o.push(`  --b3-font-color${b}: ${g.dark.color};`),(p=g.dark)!=null&&p.backgroundColor&&o.push(`  --b3-font-background${b}: ${g.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const g of e.builtin.styles){if(!g||!g.id)continue;const b=g.id;(y=g.light)!=null&&y.color&&t.push(`  --b3-card-${b}-color: ${g.light.color};`),(d=g.light)!=null&&d.backgroundColor&&t.push(`  --b3-card-${b}-background: ${g.light.backgroundColor};`),(h=g.dark)!=null&&h.color&&o.push(`  --b3-card-${b}-color: ${g.dark.color};`),(m=g.dark)!=null&&m.backgroundColor&&o.push(`  --b3-card-${b}-background: ${g.dark.backgroundColor};`)}if(t.length===0&&o.length===0)return"";const i=[];return t.length>0&&i.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),o.length>0&&i.push(`html.dark, [data-theme="dark"], .dark {
${o.join(`
`)}
}`),i.join(`

`)}function Hi(e){const t=eh(e);return t?`${nl}

/* Custom Workspace Inline Styles */
${t}`:nl}const cs=_l;function th(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function oh(e,t){const o=new Map,i=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:o,rebuildRoots:i};const n=new Map;for(const s of t)s!=null&&s.id&&n.set(s.id,s);for(const s of e||[]){if(!(s!=null&&s.id))continue;const l=n.get(s.id);if(!l)continue;const r=s.content??"",a=s.markdown??"";(l.content??"")===r&&(l.markdown??"")===a||(th(l)?i.push(s.id):o.set(s.id,{content:r,markdown:a}))}return{usable:!0,reason:"",leafPatch:o,rebuildRoots:i}}function ih(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function Ns(e){return ut(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function nh(e,t,o,i=8,n){const s=new Map;for(const y of t)y!=null&&y.id&&s.set(y.id,y);const l=y=>({id:y.id,parent_id:y.parent_id,root_id:y.root_id||e,type:y.type,subType:y.subtype??y.subType??"",content:y.content||"",markdown:y.markdown||"",ial:o(y.id,y.ial),children:[]}),r=y=>{let d=y.parent_id,h=0;for(;d&&d!==e&&h++<16;){const m=s.get(d);if(!m||!ih(m))return d;d=m.parent_id}return d||e},a=new Map;for(const y of t){if(!(y!=null&&y.id)||y.id===e||n&&n.size>0&&!n.has(y.id))continue;const d=r(y),h=a.get(d);h?h.push(y):a.set(d,[y])}if(n&&n.size>0)for(const y of a.values())y.sort((d,h)=>(n.get(d.id)??Number.MAX_SAFE_INTEGER)-(n.get(h.id)??Number.MAX_SAFE_INTEGER));const c=new Map,u=(y,d)=>{const h=l(y);if(c.set(h.id,h),d>=i||!Ns(h))return h;const m=a.get(h.id);return m&&m.length>0&&(h.children=m.map(g=>u(g,d+1))),h};return{topLevel:(a.get(e)||[]).map(y=>u(y,0)),byId:c}}const sh={getBlockAttrs:js,getChildBlocks:bi,getDocBlocksOrders:dd,setBlockAttrs:ze,sql:pi,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:ud};class rh{constructor(t){$e(this,"deps");$e(this,"attrOverrides",new Map);$e(this,"trackedListSuperBlocks",new Map);$e(this,"fallbackWarnedDocId","");this.deps={...sh,...t||{}}}setBlockAttrOverride(t,o){if(!t||!o)return;const n={...this.attrOverrides.get(t)||{}};for(const[s,l]of Object.entries(o))l===""||l===null||l===void 0?delete n[s]:n[s]=String(l);Object.keys(n).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,n)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,o){if(!t)return;if(!o){this.attrOverrides.delete(t);return}const i=this.attrOverrides.get(t);i&&(delete i[o],Object.keys(i).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const o=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},i=this.attrOverrides.get(t);i&&Object.assign(o,i);const n=await this.deps.getChildBlocks(t).catch(()=>[])||[],s=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],l=new Map;for(let j=0;j<s.length;j++)s[j]&&l.set(s[j],j);const r=l.size>0,a=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[],u=oh(n,c),p=new Map;if(Array.isArray(c))for(const j of c)j.id&&j.ial&&p.set(j.id,cs(j.ial));const y=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,d=await this.deps.sql(y).catch(()=>[])||[];if(Array.isArray(d)){for(const j of d)if(j.block_id&&j.name){let $=p.get(j.block_id);$||($={},p.set(j.block_id,$)),$[j.name]=j.value||""}}const h=(j,$)=>{const T={...p.get(j)||($?cs($):{})},O=this.attrOverrides.get(j);return O&&Object.assign(T,O),T},m=Array.isArray(c)&&c.length>0?nh(t,c,h,8,l):null,g=n.map(j=>j.id).filter(Boolean),b=j=>({id:j.id,parent_id:j.parent_id,root_id:j.root_id||t,type:j.type,subType:j.subType,content:j.content||"",markdown:j.markdown||"",ial:h(j.id,j.ial),children:j.children}),k=async(j,$=0)=>{if(!j||$>8||!Ns(j))return;const T=await this.deps.getChildBlocks(j.id).catch(()=>[])||[];if(!(!Array.isArray(T)||T.length===0)){j.children=T.filter(O=>O==null?void 0:O.id).map(O=>({id:O.id,parent_id:j.id,root_id:t,type:O.type,subType:O.subType,content:O.content||"",markdown:O.markdown||"",ial:h(O.id,O.ial),children:[]}));for(const O of j.children)await k(O,$+1)}},w=new Map;for(const j of c)j!=null&&j.id&&w.set(j.id,j);const C=g.every(j=>{const $=w.get(j);return!$||!!$.type});let A=[],M=!1;if(m&&u.usable&&r&&C){this.fallbackWarnedDocId="";for(const[$,T]of u.leafPatch){const O=m.byId.get($);O&&(O.content=T.content,O.markdown=T.markdown)}const j=new Map;for(const $ of n)$!=null&&$.id&&j.set($.id,$);for(const $ of u.rebuildRoots){const T=m.byId.get($),O=j.get($);T&&O&&(T.content=O.content||"",T.markdown=O.markdown||""),await k(T)}for(const $ of n){if(!($!=null&&$.id)||m.byId.has($.id))continue;const T=b($);await k(T),m.byId.set(T.id,T),m.topLevel.push(T)}A=m.topLevel.filter($=>l.has($.id)).sort(($,T)=>(l.get($.id)??0)-(l.get(T.id)??0))}else g.length>0?(M=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${g.length} 索引行=${c.length} 文档序=${s.length} 原因=${u.reason||"缺少实时文档序"}`)),A=n.map(j=>b(j))):m&&(A=m.topLevel);const I=async(j,$=0)=>{if(!(!j||j.length===0||$>8))for(const T of j){if(Ns(T)&&(!T.children||T.children.length===0)){let te=await this.deps.getChildBlocks(T.id).catch(()=>[]);if(!te||te.length===0){const Y=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${T.id}' ORDER BY sort ASC, created ASC`;te=await this.deps.sql(Y).catch(()=>[])||[]}if(Array.isArray(te)&&te.length>0){const Y=new Set(A.map(ce=>ce.id)),Z=te.filter(ce=>ce.id!==T.id&&!Y.has(ce.id));Z.length>0&&(T.children=Z.map(ce=>{const oe=p.get(ce.id)||(ce.ial?cs(ce.ial):{}),ne=this.attrOverrides.get(ce.id);return ne&&Object.assign(oe,ne),{id:ce.id,parent_id:ce.parent_id||T.id,root_id:ce.root_id||t,type:ce.type,subType:ce.subType,content:ce.content||"",markdown:ce.markdown||"",ial:oe}}))}}T.children&&T.children.length>0&&await I(T.children,$+1)}};M&&await I(A);const N=j=>{var $,T;for(const O of j)if(O.children&&O.children.length>0){N(O.children);for(const te of O.children)if(te.ial)for(const[Y,Z]of Object.entries(te.ial))Y.startsWith("custom-slides-")&&!(($=O.ial)!=null&&$[Y])&&(O.ial||(O.ial={}),O.ial[Y]=Z);if(O.ial){for(const[te,Y]of Object.entries(O.ial))if(te.startsWith("custom-slides-"))for(const Z of O.children)(Z.type==="video"||Z.type==="NodeVideo"||/<video\b/i.test(Z.markdown||Z.content||""))&&!((T=Z.ial)!=null&&T[te])&&(Z.ial||(Z.ial={}),Z.ial[te]=Y)}}};N(A),Zf(A,j=>{const $={[be]:j.layout};this.setBlockAttrOverride(j.blockId,$),(this.deps.setBlockAttrs||ze)(j.blockId,$).catch(O=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",O)})});const D=this.trackedListSuperBlocks.get(t)||[],U=Yf(t,A,{tracked:D,onTagChange:j=>{this.setBlockAttrOverride(j.blockId,j.attrs),j.blockId===t&&Object.assign(o,j.attrs);const $=O=>{for(const te of O)te.id===j.blockId&&(te.ial||(te.ial={}),Object.assign(te.ial,j.attrs)),te.children&&te.children.length>0&&$(te.children)};$(A),(this.deps.setBlockAttrs||ze)(j.blockId,j.attrs).catch(O=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",O)})}});this.trackedListSuperBlocks.set(t,U.newTracked);const W=new Set,E=j=>{for(const $ of j){const T=$.markdown||$.content||"";if(T.includes("((")){const O=fd(T);for(const te of O)W.add(te.blockId)}$.children&&$.children.length>0&&E($.children)}};E(A);const P={};if(W.size>0){const j=Array.from(W).map(T=>`'${T}'`).join(","),$=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${j})`).catch(()=>[])||[];if(Array.isArray($))for(const T of $)T.id&&(P[T.id]=T.markdown||T.content||"")}const x=this.deps.getBaseUrl?this.deps.getBaseUrl():"",K=il(t,o,A,{baseUrl:x,refContentMap:P});try{const j=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;K.customThemeCss=Hi(j)}catch{K.customThemeCss=Hi(null)}return K}catch(o){console.error("[DocumentCompilerService] Failed to compile document:",o);const i=il(t,{},[],{});return i.customThemeCss=Hi(null),i}}}const Be=new rh,lh={presenterMode:!0,exportHtml:!0,exportPdf:!1,exportImage:!0,import:!1,aiScript:!0};function Ao(e){return lh[e]===!1}function Dt(e){return!Ao(e)}const sl=["white","snow","ivory","ghostwhite","floralwhite","aliceblue","whitesmoke","seashell","beige","oldlace","linen","antiquewhite","lightyellow","lightcyan","papayawhip","blanchedalmond","cornsilk","lavender","lavenderblush","lemonchiffon","honeydew","mintcream","azure","mistyrose","wheat","lightgoldenrodyellow","palegoldenrod","gainsboro","lightgrey","lightgray","silver","pink","lightpink","peachpuff","navajowhite","moccasin","bisque","khaki","palegreen","lightgreen","lightblue","powderblue","paleturquoise","lightsteelblue","thistle","yellow","cyan","aqua"],rl=["black","transparent","navy","darkblue","midnightblue","darkslategray","darkslategrey","maroon","darkred","darkgreen","indigo","darkslateblue","dimgray","dimgrey","purple","brown","olive","teal","blue","darkviolet","darkmagenta","darkcyan","darkolivegreen","saddlebrown","sienna","firebrick","crimson","mediumblue","rebeccapurple"];function ur(e,t,o){return .299*e+.587*t+.114*o}function ll(e){let t=e.startsWith("#")?e.slice(1):e;if((t.length===3||t.length===4)&&(t=t.slice(0,3).split("").map(o=>o+o).join("")),t.length>=6){const o=parseInt(t.substring(0,2),16),i=parseInt(t.substring(2,4),16),n=parseInt(t.substring(4,6),16);if(!isNaN(o)&&!isNaN(i)&&!isNaN(n))return ur(o,i,n)}return null}function al(e){const t=e.match(/rgba?\s*\(\s*(\d+(?:\.\d+)?)\s*[,\s]\s*(\d+(?:\.\d+)?)\s*[,\s]\s*(\d+(?:\.\d+)?)(?:\s*[,/]\s*([0-9.]+%?))?/i);if(!t)return null;const o=Number(t[1]),i=Number(t[2]),n=Number(t[3]);if(isNaN(o)||isNaN(i)||isNaN(n))return null;if(t[4]!==void 0){const s=t[4].endsWith("%")?parseFloat(t[4])/100:parseFloat(t[4]);if(!isNaN(s)&&s<=.05)return null}return ur(o,i,n)}function cl(e){const t=e.match(/hsla?\s*\(\s*([0-9.]+)(?:deg)?\s*[,\s]\s*([0-9.]+)%\s*[,\s]\s*([0-9.]+)%(?:\s*[,/]\s*([0-9.]+%?))?/i);if(!t)return null;if(t[4]!==void 0){const a=t[4].endsWith("%")?parseFloat(t[4])/100:parseFloat(t[4]);if(!isNaN(a)&&a<=.05)return null}const o=(Number(t[1])%360+360)%360/360,i=Math.max(0,Math.min(1,Number(t[2])/100)),n=Math.max(0,Math.min(1,Number(t[3])/100));let s,l,r;if(i===0)s=l=r=n*255;else{const a=n<.5?n*(1+i):n+i-n*i,c=2*n-a,u=p=>{let y=p;return y<0&&(y+=1),y>1&&(y-=1),y<1/6?c+(a-c)*6*y:y<1/2?a:y<2/3?c+(a-c)*(2/3-y)*6:c};s=u(o+1/3)*255,l=u(o)*255,r=u(o-1/3)*255}return ur(s,l,r)}function Ha(e){if(!e||typeof e!="string")return null;const t=e.trim().toLowerCase();if(!t||/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/|url\s*\()/i.test(t))return null;if(sl.includes(t))return!0;if(rl.includes(t))return!1;if(t.startsWith("#")){const o=ll(t);return o===null?null:o>140}if(/^rgba?\s*\(/i.test(t)){const o=al(t);return o===null?null:o>140}if(/^hsla?\s*\(/i.test(t)){const o=cl(t);return o===null?null:o>140}if(/(?:linear|radial|conic)-gradient\s*\(/i.test(t)){const o=[],i=t.match(/#(?:[0-9a-f]{8}|[0-9a-f]{6}|[0-9a-f]{4}|[0-9a-f]{3})\b/gi);if(i)for(const a of i){const c=ll(a);c!==null&&o.push(c)}const n=t.match(/rgba?\s*\([^)]+\)/gi);if(n)for(const a of n){const c=al(a);c!==null&&o.push(c)}const s=t.match(/hsla?\s*\([^)]+\)/gi);if(s)for(const a of s){const c=cl(a);c!==null&&o.push(c)}const r=t.replace(/#[0-9a-f]+|rgba?\([^)]+\)|hsla?\([^)]+\)/gi," ").match(/\b[a-z]+\b/gi);if(r)for(const a of r)a!=="transparent"&&(sl.includes(a)?o.push(240):rl.includes(a)&&o.push(20));if(o.length>0)return o.reduce((c,u)=>c+u,0)/o.length>140;if(/\btransparent\b/.test(t))return!1}return null}function No(){var e,t,o,i,n,s,l,r,a,c,u,p,y;if(typeof window<"u"){const d=(o=(t=(e=window.siyuan)==null?void 0:e.config)==null?void 0:t.appearance)==null?void 0:o.mode;if(d===0)return"light";if(d===1)return"dark"}if(typeof document<"u"){const d=(i=document.documentElement)==null?void 0:i.getAttribute("data-theme-mode");if(d==="light"||d==="dark")return d;const h=(n=document.body)==null?void 0:n.getAttribute("data-theme-mode");if(h==="light"||h==="dark")return h;if((l=(s=document.documentElement)==null?void 0:s.classList)!=null&&l.contains("theme--dark")||(a=(r=document.body)==null?void 0:r.classList)!=null&&a.contains("theme--dark"))return"dark";if((u=(c=document.documentElement)==null?void 0:c.classList)!=null&&u.contains("theme--light")||(y=(p=document.body)==null?void 0:p.classList)!=null&&y.contains("theme--light"))return"light"}if(typeof window<"u"&&typeof window.matchMedia=="function"){if(window.matchMedia("(prefers-color-scheme: light)").matches)return"light";if(window.matchMedia("(prefers-color-scheme: dark)").matches)return"dark"}return"light"}function fr(e,t){return e==="light"?"light":e==="dark"?"dark":t==="light"||t==="dark"?t:No()}function Fa(e){if(typeof MutationObserver>"u"||typeof document>"u")return()=>{};let t=No();const o=()=>{const n=No();n!==t&&(t=n,e(n))},i=new MutationObserver(o);return document.documentElement&&i.observe(document.documentElement,{attributes:!0,attributeFilter:["data-theme-mode","class"]}),document.body&&i.observe(document.body,{attributes:!0,attributeFilter:["data-theme-mode","class"]}),()=>i.disconnect()}class Zn{constructor(){$e(this,"iframe",null);$e(this,"isReady",!1);$e(this,"pendingMessages",[]);$e(this,"slideChangedHandlers",[]);$e(this,"blockClickedHandlers",[]);$e(this,"openInEditorHandlers",[]);$e(this,"clientReadyHandlers",[]);$e(this,"openPeekDrawerHandlers",[]);$e(this,"toggleFullscreenHandlers",[]);$e(this,"openPresenterHandlers",[]);$e(this,"captureProgressHandlers",[]);$e(this,"capturePageDoneHandlers",[]);$e(this,"captureCompleteHandlers",[]);$e(this,"captureErrorHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}resetReady(){this.isReady=!1}postMessage(t,o){var n;const i={source:"siyuan-slides-host",action:t,payload:o};if(!((n=this.iframe)!=null&&n.contentWindow)||!this.isReady){if(t==="UPDATE_SLIDES"||t==="NAVIGATE_PAGE"){const s=this.pendingMessages.findIndex(l=>l.action===t);s!==-1?this.pendingMessages[s]=i:this.pendingMessages.push(i)}else this.pendingMessages.length>=50&&this.pendingMessages.shift(),this.pendingMessages.push(i);return}try{this.iframe.contentWindow.postMessage(i,"*")}catch(s){console.warn("[WebSandboxBridge] postMessage error:",s)}}updateSlides(t,o,i){const n=o?{...o,hostThemeMode:o.hostThemeMode||No()}:void 0;this.postMessage("UPDATE_SLIDES",{slides:t,config:n,customThemeCss:i})}navigatePage(t,o){const i={pageIndex:t};typeof o=="number"&&(i.step=o),this.postMessage("NAVIGATE_PAGE",i)}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}startImageExport(t){this.postMessage("START_IMAGE_EXPORT",{captureOptions:t})}cancelImageExport(){this.postMessage("CANCEL_IMAGE_EXPORT",{})}onCaptureProgress(t){return this.captureProgressHandlers.push(t),()=>{this.captureProgressHandlers=this.captureProgressHandlers.filter(o=>o!==t)}}onCapturePageDone(t){return this.capturePageDoneHandlers.push(t),()=>{this.capturePageDoneHandlers=this.capturePageDoneHandlers.filter(o=>o!==t)}}onCaptureComplete(t){return this.captureCompleteHandlers.push(t),()=>{this.captureCompleteHandlers=this.captureCompleteHandlers.filter(o=>o!==t)}}onCaptureError(t){return this.captureErrorHandlers.push(t),()=>{this.captureErrorHandlers=this.captureErrorHandlers.filter(o=>o!==t)}}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(o=>o!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(o=>o!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(o=>o!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(o=>o!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(o=>o!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(o=>o!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(o=>o!==t)}}handleWindowMessage(t){var i,n;const o=t.data;if(!(!o||o.source!=="siyuan-slides-client")&&!((i=this.iframe)!=null&&i.contentWindow&&t.source&&t.source!==this.iframe.contentWindow))switch(o.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const s=this.pendingMessages.shift();s&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(s,"*")}for(const s of this.clientReadyHandlers)s();break;case"SLIDE_CHANGED":if(o.payload.currentPage!==void 0)for(const s of this.slideChangedHandlers)o.payload.currentStep!==void 0||o.payload.maxStep!==void 0?s(o.payload.currentPage,o.payload.totalPages||1,o.payload.currentBlockId||"",o.payload.currentStep,o.payload.maxStep):s(o.payload.currentPage,o.payload.totalPages||1,o.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(o.payload.clickedBlockId)for(const s of this.blockClickedHandlers)s(o.payload.clickedBlockId,o.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(o.payload.blockId||o.payload.clickedBlockId){const s=o.payload.blockId||o.payload.clickedBlockId||"";for(const l of this.openInEditorHandlers)l(s,o.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(o.payload.peekType){const s=o.payload.blockId||o.payload.url||"",l={peekType:o.payload.peekType,target:s,title:o.payload.title};for(const r of this.openPeekDrawerHandlers)r(l)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const s of this.toggleFullscreenHandlers)s();break;case"OPEN_PRESENTER":for(const s of this.openPresenterHandlers)s();break;case"CAPTURE_PROGRESS":if(o.payload.captureProgress)for(const s of this.captureProgressHandlers)s(o.payload.captureProgress);break;case"CAPTURE_PAGE_DONE":if(o.payload.captureResult)for(const s of this.capturePageDoneHandlers)s(o.payload.captureResult);break;case"CAPTURE_COMPLETE":for(const s of this.captureCompleteHandlers)s({total:o.payload.totalPages||0});break;case"CAPTURE_ERROR":for(const s of this.captureErrorHandlers)s(o.payload.captureError||"未知沙箱截图异常");break}}}const ah={class:"slides-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},ch={key:0},dh={key:1},uh={key:2},fh={key:3},hh={key:4},ph={key:5},mh={key:6},gh={key:7},yh={key:8},bh={key:9},vh={key:10},kh={key:11},wh={key:12},xh={key:13},Sh={key:14},Ch={key:15},_h={key:16},Ih={key:17},$h={key:18},Mh={key:19},Th={key:20},Ah={key:21},Eh={key:22},Bh={key:23},Dh={key:24},Lh={key:25},Oh={key:26},Ph={key:27},Nh={key:28},Rh={key:29},zh={key:30},Hh={key:31},Fh={key:32},jh={key:33},Wh={key:34},Uh={key:35},Vh={key:36},qh={key:37},Gh={key:38},Kh={key:39},Yh={key:40},Zh={key:41},Jh={key:42},Xh={key:43},Qh={key:44},ep={key:45},tp={key:46},op={key:47},ip={key:48},np={key:49},sp={key:50},rp={key:51},lp={key:52},ap={key:53},cp={key:54},dp={key:55},up={key:56},fp={key:57},hp={key:58},pp={key:59},mp={key:60},gp={key:61},yp={key:62},bp={key:63},vp={key:64},kp={key:65},wp={key:66},xp={key:67},Sp={key:68},Cp={key:69},_p={key:70},Ip={key:71},$p={key:72},Mp=Nt({__name:"SlidesIcon",props:{name:{}},setup(e){return(t,o)=>(J(),ee("svg",ah,[e.name==="fullscreen"||e.name==="maximize"?(J(),ee("g",ch,[...o[0]||(o[0]=[f("polyline",{points:"15 3 21 3 21 9"},null,-1),f("polyline",{points:"9 21 3 21 3 15"},null,-1),f("polyline",{points:"21 15 21 21 15 21"},null,-1),f("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(J(),ee("g",dh,[...o[1]||(o[1]=[f("polyline",{points:"4 14 10 14 10 20"},null,-1),f("polyline",{points:"20 10 14 10 14 4"},null,-1),f("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),f("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(J(),ee("g",uh,[...o[2]||(o[2]=[f("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),f("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(J(),ee("g",fh,[...o[3]||(o[3]=[f("path",{d:"M12 20h9"},null,-1),f("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(J(),ee("g",hh,[...o[4]||(o[4]=[f("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),f("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(J(),ee("g",ph,[...o[5]||(o[5]=[f("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),f("polyline",{points:"15 3 21 3 21 9"},null,-1),f("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(J(),ee("g",mh,[...o[6]||(o[6]=[f("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),f("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(J(),ee("g",gh,[...o[7]||(o[7]=[f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),f("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(J(),ee("g",yh,[...o[8]||(o[8]=[f("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(J(),ee("g",bh,[...o[9]||(o[9]=[f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(J(),ee("g",vh,[...o[10]||(o[10]=[f("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),f("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(J(),ee("g",kh,[...o[11]||(o[11]=[f("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),f("polyline",{points:"7 9 12 14 17 9"},null,-1),f("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(J(),ee("g",wh,[...o[12]||(o[12]=[f("path",{d:"M2 3h20"},null,-1),f("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),f("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(J(),ee("g",xh,[...o[13]||(o[13]=[f("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),f("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(J(),ee("g",Sh,[...o[14]||(o[14]=[f("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(J(),ee("g",Ch,[...o[15]||(o[15]=[f("path",{d:"M5 12h14"},null,-1),f("path",{d:"m12 5 7 7-7 7"},null,-1),f("path",{d:"M5 6h4"},null,-1),f("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(J(),ee("g",_h,[...o[16]||(o[16]=[f("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),f("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="code"?(J(),ee("g",Ih,[...o[17]||(o[17]=[f("polyline",{points:"16 18 22 12 16 6"},null,-1),f("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="list"?(J(),ee("g",$h,[...o[18]||(o[18]=[ht('<line x1="8" y1="6" x2="21" y2="6" data-v-af7d02a2></line><line x1="8" y1="12" x2="21" y2="12" data-v-af7d02a2></line><line x1="8" y1="18" x2="21" y2="18" data-v-af7d02a2></line><line x1="3" y1="6" x2="3.01" y2="6" data-v-af7d02a2></line><line x1="3" y1="12" x2="3.01" y2="12" data-v-af7d02a2></line><line x1="3" y1="18" x2="3.01" y2="18" data-v-af7d02a2></line>',6)])])):e.name==="insert-above"?(J(),ee("g",Mh,[...o[19]||(o[19]=[f("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),f("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),f("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(J(),ee("g",Th,[...o[20]||(o[20]=[f("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),f("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),f("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(J(),ee("g",Ah,[...o[21]||(o[21]=[f("path",{d:"m18 15-6-6"},null,-1),f("path",{d:"M4 20h16"},null,-1),f("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(J(),ee("g",Eh,[...o[22]||(o[22]=[f("path",{d:"M3 6h18"},null,-1),f("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),f("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(J(),ee("g",Bh,[...o[23]||(o[23]=[f("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(J(),ee("g",Dh,[...o[24]||(o[24]=[ht('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-af7d02a2></path>',5)])])):e.name==="ratio"?(J(),ee("g",Lh,[...o[25]||(o[25]=[f("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(J(),ee("g",Oh,[...o[26]||(o[26]=[f("path",{d:"M8 3 4 7l4 4"},null,-1),f("path",{d:"M4 7h16"},null,-1),f("path",{d:"m16 21 4-4-4-4"},null,-1),f("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(J(),ee("g",Ph,[...o[27]||(o[27]=[f("polyline",{points:"16 16 12 12 8 16"},null,-1),f("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),f("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(J(),ee("g",Nh,[...o[28]||(o[28]=[f("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),f("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),f("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(J(),ee("g",Rh,[...o[29]||(o[29]=[f("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),f("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(J(),ee("g",zh,[...o[30]||(o[30]=[f("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),f("path",{d:"M21 3v5h-5"},null,-1),f("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),f("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(J(),ee("g",Hh,[...o[31]||(o[31]=[f("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),f("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),f("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="chevron-left"?(J(),ee("g",Fh,[...o[32]||(o[32]=[f("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(J(),ee("g",jh,[...o[33]||(o[33]=[f("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="chevron-down"?(J(),ee("g",Wh,[...o[34]||(o[34]=[f("polyline",{points:"6 9 12 15 18 9"},null,-1)])])):e.name==="chevrons-left"?(J(),ee("g",Uh,[...o[35]||(o[35]=[f("polyline",{points:"11 17 6 12 11 7"},null,-1),f("polyline",{points:"18 17 13 12 18 7"},null,-1)])])):e.name==="chevrons-right"?(J(),ee("g",Vh,[...o[36]||(o[36]=[f("polyline",{points:"13 17 18 12 13 7"},null,-1),f("polyline",{points:"6 17 11 12 6 7"},null,-1)])])):e.name==="play"?(J(),ee("g",qh,[...o[37]||(o[37]=[f("polygon",{points:"6 3 20 12 6 21 6 3"},null,-1)])])):e.name==="pause"?(J(),ee("g",Gh,[...o[38]||(o[38]=[f("line",{x1:"10",y1:"4",x2:"10",y2:"20"},null,-1),f("line",{x1:"14",y1:"4",x2:"14",y2:"20"},null,-1)])])):e.name==="clock"?(J(),ee("g",Kh,[...o[39]||(o[39]=[f("circle",{cx:"12",cy:"12",r:"10"},null,-1),f("polyline",{points:"12 6 12 12 16 14"},null,-1)])])):e.name==="copy"?(J(),ee("g",Yh,[...o[40]||(o[40]=[f("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),f("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"||e.name==="export-image"?(J(),ee("g",Zh,[...o[41]||(o[41]=[f("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),f("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),f("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(J(),ee("g",Jh,[...o[42]||(o[42]=[f("circle",{cx:"11",cy:"11",r:"7"},null,-1),f("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(J(),ee("g",Xh,[...o[43]||(o[43]=[f("circle",{cx:"12",cy:"12",r:"3"},null,-1),f("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(J(),ee("g",Qh,[...o[44]||(o[44]=[ht('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-af7d02a2></path><polyline points="14 2 14 8 20 8" data-v-af7d02a2></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-af7d02a2></line><line x1="16" y1="17" x2="8" y2="17" data-v-af7d02a2></line><line x1="10" y1="9" x2="8" y2="9" data-v-af7d02a2></line>',5)])])):e.name==="focus"||e.name==="target"?(J(),ee("g",ep,[...o[45]||(o[45]=[f("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),f("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),f("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(J(),ee("g",tp,[...o[46]||(o[46]=[f("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),f("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),f("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),f("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(J(),ee("g",op,[...o[47]||(o[47]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-af7d02a2></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-af7d02a2></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-af7d02a2></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-af7d02a2></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(J(),ee("g",ip,[...o[48]||(o[48]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-af7d02a2></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-af7d02a2></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-af7d02a2></line><line x1="5" y1="15" x2="8" y2="15" data-v-af7d02a2></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-af7d02a2></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-af7d02a2></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-af7d02a2></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(J(),ee("g",np,[...o[49]||(o[49]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-af7d02a2></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-af7d02a2></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-af7d02a2></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-af7d02a2></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-af7d02a2></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(J(),ee("g",sp,[...o[50]||(o[50]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-af7d02a2></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-af7d02a2></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-af7d02a2></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-af7d02a2></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-af7d02a2></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-af7d02a2></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-af7d02a2></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(J(),ee("g",rp,[...o[51]||(o[51]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7" x2="13" y2="7" data-v-af7d02a2></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-af7d02a2></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-af7d02a2></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-af7d02a2></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-af7d02a2></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(J(),ee("g",lp,[...o[52]||(o[52]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" data-v-af7d02a2></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-af7d02a2></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-af7d02a2></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-af7d02a2></line><circle cx="15.5" cy="8.5" r="1.2" data-v-af7d02a2></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-af7d02a2></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(J(),ee("g",ap,[...o[53]||(o[53]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" data-v-af7d02a2></line><circle cx="6" cy="8.5" r="1.2" data-v-af7d02a2></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-af7d02a2></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-af7d02a2></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-af7d02a2></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-af7d02a2></line>',7)])])):e.name==="layout-center"||e.name==="center"?(J(),ee("g",cp,[...o[54]||(o[54]=[f("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),f("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),f("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(J(),ee("g",dp,[...o[55]||(o[55]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><circle cx="8" cy="9" r="1.5" data-v-af7d02a2></circle><line x1="14" y1="8" x2="9" y2="14" data-v-af7d02a2></line><circle cx="15" cy="13" r="1.5" data-v-af7d02a2></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-af7d02a2></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(J(),ee("g",up,[...o[56]||(o[56]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><circle cx="7.5" cy="9.5" r="2" data-v-af7d02a2></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-af7d02a2></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-af7d02a2></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-af7d02a2></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-af7d02a2></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(J(),ee("g",fp,[...o[57]||(o[57]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-af7d02a2></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-af7d02a2></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-af7d02a2></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-af7d02a2></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(J(),ee("g",hp,[...o[58]||(o[58]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(J(),ee("g",pp,[...o[59]||(o[59]=[f("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),f("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(J(),ee("g",mp,[...o[60]||(o[60]=[f("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),f("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),f("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(J(),ee("g",gp,[...o[61]||(o[61]=[f("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),f("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(J(),ee("g",yp,[...o[62]||(o[62]=[f("path",{d:"m17 1 4 4-4 4"},null,-1),f("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),f("path",{d:"m7 23-4-4 4-4"},null,-1),f("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(J(),ee("g",bp,[...o[63]||(o[63]=[f("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),f("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),f("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(J(),ee("g",vp,[...o[64]||(o[64]=[ht('<line x1="4" y1="21" x2="4" y2="14" data-v-af7d02a2></line><line x1="4" y1="10" x2="4" y2="3" data-v-af7d02a2></line><line x1="12" y1="21" x2="12" y2="12" data-v-af7d02a2></line><line x1="12" y1="8" x2="12" y2="3" data-v-af7d02a2></line><line x1="20" y1="21" x2="20" y2="16" data-v-af7d02a2></line><line x1="20" y1="12" x2="20" y2="3" data-v-af7d02a2></line><line x1="1" y1="14" x2="7" y2="14" data-v-af7d02a2></line><line x1="9" y1="8" x2="15" y2="8" data-v-af7d02a2></line><line x1="17" y1="16" x2="23" y2="16" data-v-af7d02a2></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(J(),ee("g",kp,[...o[65]||(o[65]=[f("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),f("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),f("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),f("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(J(),ee("g",wp,[...o[66]||(o[66]=[f("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(J(),ee("g",xp,[...o[67]||(o[67]=[f("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),f("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),f("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),f("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(J(),ee("g",Sp,[...o[68]||(o[68]=[f("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),f("path",{d:"m13 8 2 2"},null,-1),f("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(J(),ee("g",Cp,[...o[69]||(o[69]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-af7d02a2></rect><line x1="13" y1="8" x2="19" y2="8" data-v-af7d02a2></line><line x1="13" y1="12" x2="19" y2="12" data-v-af7d02a2></line><line x1="13" y1="16" x2="17" y2="16" data-v-af7d02a2></line>',5)])])):e.name==="image-right"?(J(),ee("g",_p,[...o[70]||(o[70]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-af7d02a2></rect><line x1="5" y1="8" x2="11" y2="8" data-v-af7d02a2></line><line x1="5" y1="12" x2="11" y2="12" data-v-af7d02a2></line><line x1="5" y1="16" x2="9" y2="16" data-v-af7d02a2></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(J(),ee("g",Ip,[...o[71]||(o[71]=[f("circle",{cx:"12",cy:"12",r:"10"},null,-1),f("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),f("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(J(),ee("g",$p,[...o[72]||(o[72]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),so=(e,t)=>{const o=e.__vccOpts||e;for(const[i,n]of t)o[i]=n;return o},de=so(Mp,[["__scopeId","data-v-af7d02a2"]]),Tp={class:"spm-immersion-header"},Ap={class:"spm-immersion-header__left"},Ep={class:"spm-immersion-title"},Bp={class:"spm-immersion-header__center"},Dp={class:"spm-immersion-header__actions"},Lp=["aria-label"],Op={class:"spm-immersion-body"},Pp=Nt({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const o=e,i=t;function n(){i("update:visible",!1),i("close")}function s(){o.closeOnClickMask&&n()}function l(){i("update:isMaximized",!o.isMaximized),i("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),n())}return(a,c)=>Ht((J(),ee("div",{class:xe(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:eo(r,["stop"])},[f("div",{class:"spm-immersion-mask",onClick:s}),f("div",{class:xe(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[f("div",Tp,[f("div",Ap,[ln(a.$slots,"header-left",{},()=>[f("span",Ep,ve(e.title),1)])]),f("div",Bp,[ln(a.$slots,"header-center",{},void 0)]),f("div",Dp,[ln(a.$slots,"header-actions",{},void 0),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[re(de,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,Lp),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:n},[re(de,{name:"close"})])])]),f("div",Op,[ln(a.$slots,"default",{},void 0)])],2)],34)),[[Bs,e.visible]])}}),Np=so(Pp,[["__scopeId","data-v-1359fecb"]]);function Rp(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function tn(e){const t=Rp();if(t)try{return t(e)}catch{try{const o=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(o)}catch{}}}function zp(){var t;if(typeof window<"u"&&window.process)return window.process;const e=tn("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function Hp(){var t,o;const e=zp();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const i=tn("child_process");if(i&&typeof i.spawn=="function")return!0}return!!(typeof process<"u"&&((o=process.versions)!=null&&o.node))}function Fp(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}const jp={class:"spm-protyle-drawer"},Wp={class:"spm-protyle-drawer__subbar"},Up={class:"spm-protyle-drawer__nav"},Vp=["title"],qp={class:"spm-protyle-drawer__actions"},Gp=["aria-label"],Kp=["aria-label"],Yp=Nt({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const o=t,i=e,n=pe(i.blockId),s=pe(i.title||""),l=pe(!1),r=pe(!0),a=pe(!1),c=pe(""),u=Yt,p=pe([]),y=pe(null);let d=null;Yo(()=>i.blockId,I=>{I&&I!==n.value&&(n.value=I,s.value=i.title||"",p.value=[],m(I))}),wi(()=>{n.value&&m(n.value)}),or(()=>{g()});async function h(I){try{const N=await pi(`SELECT id, root_id, type, content FROM blocks WHERE id = '${I}' LIMIT 1`);if(Array.isArray(N)&&N.length>0){const D=N[0];c.value=D.root_id||"";const U=D.id===D.root_id||D.type==="d";a.value=U,r.value=!U,!s.value&&D.content&&(s.value=D.content.trim().slice(0,30));return}}catch(N){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",N)}a.value=!1,r.value=!0}async function m(I,N){if(!y.value||!I)return;g(),await h(I),typeof N=="boolean"&&(r.value=!a.value&&N);let D,U;r.value&&!a.value?(D=["cb-get-all","cb-get-hl","cb-get-focus"],U={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(D=["cb-get-context","cb-get-hl"],U={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{d=new ae.Protyle(i.plugin.app,y.value,{blockId:I,action:D,render:U}),!l.value&&d&&typeof d.disable=="function"&&d.disable()}catch(W){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",W)}}function g(){if(d){try{typeof d.destroy=="function"&&d.destroy()}catch(I){console.warn("[ProtylePeekDrawer] Error destroying protyle:",I)}d=null}y.value&&(y.value.innerHTML="")}function b(){a.value||(r.value=!r.value,m(n.value,r.value))}function k(){l.value=!l.value,d&&(l.value?(typeof d.enable=="function"&&d.enable(),typeof d.focus=="function"&&d.focus()):typeof d.disable=="function"&&d.disable())}function w(){if(n.value)try{ae.openWindow({doc:{id:n.value},alwaysOnTop:!0})}catch(I){console.warn("[ProtylePeekDrawer] openWindow failed:",I)}}function C(){var D;if(!n.value)return;const I=Yn(),N=Pa(I.webServeUrl,n.value,{focus:!a.value});if(typeof window<"u"){const U=tn("electron");(D=U==null?void 0:U.shell)!=null&&D.openExternal?U.shell.openExternal(N).catch(()=>{window.open(N,"_blank")}):window.open(N,"_blank")}o("external-jump",N)}function A(){if(p.value.length>0){const I=p.value.pop();I&&(n.value=I.blockId,s.value=I.title,r.value=I.isFocusMode,a.value=I.isDoc,m(I.blockId,I.isFocusMode))}}function M(I){const N=I.target;if(!N)return;const D=N.closest('[data-type="block-ref"]');if(D){const W=D.getAttribute("data-id");if(W&&W!==n.value){I.preventDefault(),I.stopPropagation(),p.value.push({blockId:n.value,title:s.value||n.value,isFocusMode:r.value,isDoc:a.value}),n.value=W,s.value=D.innerText.trim()||W,m(W);return}}const U=N.closest("a");if(U&&U.href&&U.href.startsWith("siyuan://blocks/")){I.preventDefault(),I.stopPropagation();const W=U.href.replace("siyuan://blocks/","").split("?")[0];W&&W!==n.value&&(p.value.push({blockId:n.value,title:s.value||n.value,isFocusMode:r.value,isDoc:a.value}),n.value=W,s.value=U.innerText.trim()||W,m(W))}}return(I,N)=>(J(),ee("div",jp,[f("div",Wp,[f("div",Up,[p.value.length>0?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:A},[re(de,{name:"arrow-left"}),N[0]||(N[0]=f("span",null,"返回",-1))])):Te("",!0),f("span",{class:xe(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},ve(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),f("span",{class:"spm-protyle-id",title:s.value||n.value},ve(s.value||n.value),9,Vp)]),f("div",qp,[a.value?Te("",!0):(J(),ee("button",{key:0,class:xe(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:b},[re(de,{name:r.value?"focus":"file-text"},null,8,["name"]),f("span",null,ve(r.value?"块聚焦":"展开全文"),1)],10,Gp)),f("button",{class:xe(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:k},[re(de,{name:l.value?"edit":"eye"},null,8,["name"]),f("span",null,ve(l.value?"编辑中":"只读"),1)],10,Kp),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:w},[re(de,{name:"window"}),N[1]||(N[1]=f("span",null,"独立窗口",-1))]),he(u).enableWebServeJump?(J(),ee("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:C},[re(de,{name:"external-link"}),N[2]||(N[2]=f("span",null,"外跳",-1))])):Te("",!0)])]),f("div",{ref_key:"mountEl",ref:y,class:xe(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:M},null,2)]))}}),Zp=so(Yp,[["__scopeId","data-v-0d6e2df3"]]),Jp=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,Xp=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function dl(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const o=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(o)return`/assets/${o[1]}`;const i=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return i?`/plugins/${i[1]}`:null}function ja(e){const t=(e||"").replace(/^file:\/\//i,"");let o=t;try{o=decodeURIComponent(t)}catch{}if(o.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(o)?o.slice(1):o;const i=o.indexOf("/");return i>=0?o.slice(i):o}function Qp(e){const t=e.split(/[/?#]/)[0];return!t||Xp.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function em(e){const t=e.indexOf("#"),o=t>=0?e.slice(t):"",i=t>=0?e.slice(0,t):e,n=i.indexOf("?"),s=n>=0?i.slice(0,n):i,l=n>=0?i.slice(n+1):"";if(!/^\/?assets\/.+\.html?$/i.test(s))return e;const r=new URLSearchParams(l);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${s}?${r.toString()}${o}`)}function Wa(e){const t=tm(e);return t.external||!t.url?t:{url:em(t.url),external:!1}}function tm(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(Tl(t))return{url:`/${Al(t)}`,external:!1};if(/^file:/i.test(t)){const i=dl(ja(t));return i?{url:i,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const i=dl(t);return i?{url:i,external:!1}:{url:t,external:!0}}return Jp.test(t)?{url:t,external:!0}:Qp(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const om={class:"spm-webview-drawer"},im={class:"spm-webview-toolbar"},nm={class:"spm-webview-toolbar__nav"},sm=["disabled"],rm=["disabled"],lm=["aria-label"],am={class:"spm-webview-toolbar__address"},cm=["aria-label"],dm={class:"spm-webview-toolbar__actions"},um=["aria-label"],fm={class:"spm-zoom-controller"},hm=["disabled"],pm=["disabled"],mm={key:1,class:"spm-webview-fallback"},gm=["src"],ym={key:2,class:"spm-load-error"},bm={class:"spm-load-error__code"},vm={class:"spm-load-error__code-num"},km={class:"spm-load-error__url"},wm={class:"spm-load-error__hint"},xm={class:"spm-load-error__actions"},ul="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",Ua="siyuan-slides-peek-view-mode";let Va="desktop";function Sm(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(Ua);if(e==="mobile"||e==="desktop")return e}catch{}return Va}function Cm(e){if(Va=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(Ua,e)}catch{}}function _m(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const Im=Nt({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const o=t,i=e,n=pe(Hp()&&!Fp()),s=pe(i.url),l=pe(i.url),r=i.url,a=pe(!1),c=pe(null),u=pe(!1),p=pe(!1),y=pe(1),d=pe(!1),h=pe(Sm());let m=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const g=ye(()=>h.value==="mobile"?ul:m||void 0),b=pe(null),k=pe(null);let w=null,C=null,A=null;Yo(()=>i.url,R=>{R&&R!==s.value&&(s.value=R,l.value=R,h.value==="mobile"&&U(!1),b.value&&typeof b.value.loadURL=="function"&&b.value.loadURL(R))}),Yo(()=>i.visible,R=>{if(R)ce(),h.value==="mobile"&&U(!1);else if(b.value)try{typeof b.value.stop=="function"&&b.value.stop()}catch{}}),wi(()=>{M(),k.value&&typeof ResizeObserver<"u"&&(w=new ResizeObserver(()=>{const R=b.value;if(R&&typeof R.invalidate=="function")try{R.invalidate()}catch{}}),w.observe(k.value)),C=R=>{var B;const ie=R.message||((B=R.error)==null?void 0:B.message);if(typeof ie=="string"&&ie.includes("Invalid guestInstanceId"))return R.preventDefault(),R.stopImmediatePropagation(),!0},window.addEventListener("error",C,!0),A=R=>{const ie=R.reason,B=typeof ie=="string"?ie:ie==null?void 0:ie.message;typeof B=="string"&&B.includes("Invalid guestInstanceId")&&R.preventDefault()},window.addEventListener("unhandledrejection",A)}),or(()=>{if(I(),w&&(w.disconnect(),w=null),C&&(window.removeEventListener("error",C,!0),C=null),A&&(window.removeEventListener("unhandledrejection",A),A=null),b.value)try{typeof b.value.stop=="function"&&b.value.stop()}catch{}});function M(){const R=b.value;R&&(R.addEventListener("dom-ready",N),R.addEventListener("did-start-loading",W),R.addEventListener("did-stop-loading",x),R.addEventListener("did-navigate",K),R.addEventListener("did-navigate-in-page",j),R.addEventListener("new-window",$),R.addEventListener("did-fail-load",E),R.addEventListener("did-fail-provisional-load",E))}function I(){const R=b.value;if(R)try{R.removeEventListener("dom-ready",N),R.removeEventListener("did-start-loading",W),R.removeEventListener("did-stop-loading",x),R.removeEventListener("did-navigate",K),R.removeEventListener("did-navigate-in-page",j),R.removeEventListener("new-window",$),R.removeEventListener("did-fail-load",E),R.removeEventListener("did-fail-provisional-load",E)}catch{}}function N(){const R=b.value;if(R&&typeof R.getUserAgent=="function"&&!m)try{const ie=R.getUserAgent();ie&&!ie.includes("iPhone")&&(m=ie)}catch{}h.value==="mobile"&&U(!1),ce(),T()}function D(){const R=h.value==="mobile"?"desktop":"mobile";h.value=R,Cm(R),U(!0)}function U(R=!1){const ie=b.value;if(!ie)return;const B=h.value==="mobile"?ul:m;if(typeof ie.setUserAgent=="function"&&B)try{ie.setUserAgent(B)}catch(H){console.warn("[WebviewPeekDrawer] setUserAgent error:",H)}if(R&&typeof ie.reload=="function")try{ie.reload()}catch(H){console.warn("[WebviewPeekDrawer] reload error:",H)}}function W(){a.value=!0,c.value=null}function E(R){if(R&&R.isMainFrame===!1||R&&Number(R.errorCode)===-3)return;const ie=String((R==null?void 0:R.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((R==null?void 0:R.errorCode)??0),description:ie,validatedURL:String((R==null?void 0:R.validatedURL)||s.value),hint:_m(ie)},a.value=!1}function P(){c.value=null,Y()}function x(){if(a.value=!1,T(),b.value&&typeof b.value.getURL=="function"){const R=b.value.getURL();R&&R!=="about:blank"&&(s.value=R,l.value=R)}}function K(R){R!=null&&R.url&&(s.value=R.url,l.value=R.url),T()}function j(R){R!=null&&R.url&&(s.value=R.url,l.value=R.url),T()}function $(R){R&&R.url&&(R.preventDefault(),b.value&&typeof b.value.loadURL=="function"&&b.value.loadURL(R.url))}function T(){const R=b.value;R&&(typeof R.canGoBack=="function"&&(u.value=R.canGoBack()),typeof R.canGoForward=="function"&&(p.value=R.canGoForward()))}function O(){b.value&&typeof b.value.goBack=="function"&&b.value.goBack()}function te(){b.value&&typeof b.value.goForward=="function"&&b.value.goForward()}function Y(){b.value&&typeof b.value.reload=="function"&&b.value.reload()}function Z(){const R=Wa(l.value);if(R.url){if(R.external){s.value=R.url,Ie();return}s.value=R.url,l.value=R.url,b.value&&typeof b.value.loadURL=="function"&&b.value.loadURL(R.url)}}function ce(){const R=b.value;if(R&&typeof R.setZoomFactor=="function")try{R.setZoomFactor(y.value)}catch(ie){console.warn("[WebviewPeekDrawer] setZoomFactor error:",ie)}}function oe(){y.value=Math.min(2.5,Math.round((y.value+.1)*10)/10),ce()}function ne(){y.value=Math.max(.5,Math.round((y.value-.1)*10)/10),ce()}function Ce(){y.value=1,ce()}function _e(R){R.preventDefault(),R.deltaY<0?oe():R.deltaY>0&&ne()}async function ke(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(s.value),d.value=!0,setTimeout(()=>{d.value=!1},2e3)}catch(R){console.warn("Copy url failed:",R)}}function Ie(){var ie;const R=s.value;if(typeof window<"u"){const B=tn("electron");(ie=B==null?void 0:B.shell)!=null&&ie.openExternal?B.shell.openExternal(R).catch(()=>{window.open(R,"_blank")}):window.open(R,"_blank")}o("external-jump",R)}return(R,ie)=>{const B=wu("webview");return J(),ee("div",om,[f("div",im,[f("div",nm,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!u.value,"aria-label":"后退",onClick:O},[re(de,{name:"arrow-left"})],8,sm),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!p.value,"aria-label":"前进",onClick:te},[re(de,{name:"arrow-right"})],8,rm),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":a.value?"正在加载...":"刷新页面",onClick:Y},[re(de,{name:"refresh"})],8,lm)]),f("div",am,[Ht(f("input",{"onUpdate:modelValue":ie[0]||(ie[0]=H=>l.value=H),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:Nf(Z,["enter"])},null,544),[[Ds,l.value]]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":d.value?"已复制地址！":"复制网址",onClick:ke},[re(de,{name:"copy"})],8,cm)]),f("div",dm,[f("button",{class:xe(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":h.value==="mobile"}]),"aria-label":h.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:D},[re(de,{name:h.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,um),f("div",fm,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:y.value<=.5,onClick:ne},[re(de,{name:"minus"})],8,hm),f("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:Ce},ve(Math.round(y.value*100))+"% ",1),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:y.value>=2.5,onClick:oe},[re(de,{name:"plus"})],8,pm)]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:Ie},[re(de,{name:"external-link"}),ie[1]||(ie[1]=f("span",null,"外跳",-1))])])]),f("div",{ref_key:"containerEl",ref:k,class:xe(["spm-webview-body",{"is-mobile":h.value==="mobile"}]),onWheel:eo(_e,["ctrl"])},[f("div",{class:xe(["spm-webview-viewport",{"is-mobile":h.value==="mobile"}])},[n.value?(J(),to(B,{key:0,ref_key:"webviewRef",ref:b,class:"spm-webview-frame",src:he(r),useragent:g.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(J(),ee("div",mm,[f("iframe",{class:"spm-webview-fallback-frame",src:s.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,gm),f("div",{class:"spm-fallback-bar"},[ie[2]||(ie[2]=f("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),f("button",{class:"spm-icon-btn is-primary",onClick:Ie}," 在新标签页中打开 ↗ ")])])),c.value?(J(),ee("div",ym,[re(de,{name:"alert",class:"spm-load-error__icon"}),ie[5]||(ie[5]=f("div",{class:"spm-load-error__title"},"页面加载失败",-1)),f("div",bm,[Bt(ve(c.value.description)+" ",1),f("span",vm,"("+ve(c.value.errorCode)+")",1)]),f("div",km,ve(c.value.validatedURL),1),f("p",wm,ve(c.value.hint),1),f("div",xm,[f("button",{class:"spm-icon-btn","aria-label":"重试",onClick:P},[re(de,{name:"refresh"}),ie[3]||(ie[3]=f("span",null,"重试",-1))]),f("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:Ie},[re(de,{name:"external-link"}),ie[4]||(ie[4]=f("span",null,"用系统浏览器打开 ↗",-1))])])])):Te("",!0)],2)],34)])}}}),$m=so(Im,[["__scopeId","data-v-6e363f73"]]);class Mm{constructor(){$e(this,"timers",new Map)}debounce(t,o,i=150){this.cancel(t);const n=setTimeout(()=>{this.timers.delete(t),o()},i);this.timers.set(t,n)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class Tm{constructor(t){$e(this,"blockToPageMap",new Map);$e(this,"debounceCtrl",new Mm);$e(this,"activeBlockId","");$e(this,"activePageIndex",1);$e(this,"currentDocId","");$e(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t}updateSlidesIndex(t){this.blockToPageMap.clear();for(const o of t){o.startBlockId&&this.blockToPageMap.set(o.startBlockId,o.pageIndex);for(const i of o.blocks)this.blockToPageMap.set(i.id,o.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;this.activeBlockId=t;let o=this.getPageByBlockId(t);!o&&(t===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(o=1),o&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=o,this.bridge&&(this.bridge.navigatePage(o),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t,t||this.debounceCtrl.cancel("cursor-navigate");const o=this.getPageByBlockId(t);o&&(this.activePageIndex=o)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}let Ot=null,pn=null,mn="";function Fi(){var e,t;if(pn&&(clearTimeout(pn),pn=null),Ot){try{Ot.classList.remove("protyle-wysiwyg--select"),mn?Ot.style.outline=mn:typeof((e=Ot.style)==null?void 0:e.removeProperty)=="function"?Ot.style.removeProperty("outline"):Ot.style&&(Ot.style.outline=""),typeof((t=Ot.style)==null?void 0:t.removeProperty)=="function"?Ot.style.removeProperty("transition"):Ot.style&&(Ot.style.transition="")}catch(o){console.warn("[SelectionMirror] clear activeHighlightEl failed:",o)}Ot=null,mn=""}if(typeof document<"u"&&typeof document.querySelectorAll=="function")try{document.querySelectorAll(".protyle-wysiwyg [data-node-id].protyle-wysiwyg--select, .protyle-wysiwyg [data-node-id][style*='outline']").forEach(i=>{var s,l;i.classList.remove("protyle-wysiwyg--select");const n=((s=i.style)==null?void 0:s.outline)||"";(n.includes("#3b82f6")||n.includes("rgb(59, 130, 246)")||n.includes("59, 130, 246"))&&(typeof((l=i.style)==null?void 0:l.removeProperty)=="function"?(i.style.removeProperty("outline"),i.style.removeProperty("transition")):i.style&&(i.style.outline="",i.style.transition=""))})}catch{}}function Zo(e,t){var l,r,a,c;if(!e||typeof document>"u")return Fi(),!1;Fi();const o=(l=globalThis.CSS)!=null&&l.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),i=document.querySelector(`.protyle-wysiwyg [data-node-id="${o}"]`)||document.querySelector(`[data-node-id="${o}"]`);if(!i){if(t)try{return ae.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(u){console.warn("[SelectionMirror] openTab fallback failed:",u)}return!1}try{i.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{(r=i.scrollIntoView)==null||r.call(i)}try{(a=i.focus)==null||a.call(i,{preventScroll:!0})}catch{}const n=((c=i.style)==null?void 0:c.outline)||"";return mn=n.includes("#3b82f6")||n.includes("rgb(59, 130, 246)")||n.includes("59, 130, 246")?"":n,i.classList.add("protyle-wysiwyg--select"),i.style&&(i.style.outline="2px solid #3b82f6",i.style.transition="outline 0.2s ease"),Ot=i,pn=setTimeout(()=>{Fi()},500),!0}function Am(e){if(!e)return"";const t=e.split(`
`).map(l=>l.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(l=>/^#{1,6}\s+/.test(l)))return t.map(l=>dt(l)).join("<br/>");const i=[];let n=[];const s=()=>{if(n.length>0){const l=n.map(r=>dt(r)).join("<br/>");i.push(`<p class="slide-list-item-desc">${l}</p>`),n=[]}};for(const l of t){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){s();const a=r[1].length,c=r[2].trim();i.push(`<h${a} class="slide-list-item-title">${dt(c)}</h${a}>`)}else n.push(l)}return s(),i.join(`
`)}function Em(e){if(e.length===0)return"";const t=[],o=e[0],i=o.match(/^(#{1,6})\s+(.*)$/);if(i){const n=i[1].length,s=i[2].trim();t.push(`<h${n} class="slide-list-item-title">${dt(s)}</h${n}>`)}else t.push(`<p class="slide-list-item-title">${dt(o)}</p>`);if(e.length>1){const n=e.slice(1);let s=[];const l=()=>{if(s.length>0){const r=s.map(a=>dt(a)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),s=[]}};for(const r of n){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,u=a[2].trim();t.push(`<h${c} class="slide-list-item-title">${dt(u)}</h${c}>`)}else s.push(r)}l()}return t.join(`
`)+(t.length>0?`
`:"")}function qa(e,t,o){var y,d,h,m;const i=e.split(`
`);if(!i.some(g=>/^(\s*)([-*+]|\d+\.)\s+/.test(g)))return(o!=null&&o.isListItem||(o==null?void 0:o.type)==="i")&&!(o!=null&&o.isColFirst)?`<ul class="slide-list slide-list--unordered">
<li class="slide-list-item">${dt(e)}</li>
</ul>`:null;const s=[],l=[];let r=!1;for(let g=0;g<i.length;g++){const b=i[g];if(!b.trim())continue;const k=b.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(k){const M=k[1].length,I=Math.floor(M/2);l.push({type:"task",level:I,checked:k[2].toLowerCase()==="x",text:k[3],media:[]});continue}const w=b.match(/^(\s*)[-*+]\s+(.*)$/);if(w){const M=w[1].length,I=Math.floor(M/2);l.push({type:"unordered",level:I,text:w[2],media:[]});continue}const C=b.match(/^(\s*)\d+\.\s+(.*)$/);if(C){l.length===0&&(r=!0);const M=C[1].length,I=Math.floor(M/2);l.push({type:"ordered",level:I,text:C[2],media:[]});continue}const A=b.trim();if(!(!A||/^\{:.*?\}$/.test(A)))if(l.length>0){const M=A.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(M){const D=/\.gif(?:\?|$)/i.test(M[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${st(M[1])}" src="${M[2]}" class="${D}" /></div>`);continue}if(A.match(/^<img\b[\s\S]*?\/?>$/i)){const N=A.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${N}</div>`);continue}if(/<video\b/i.test(A)){let N=A;if(!/<\/video>/i.test(N))for(;g+1<i.length&&!/<\/video>/i.test(N);)g++,N+=" "+i[g].trim();const D=((y=o==null?void 0:o.attributes)==null?void 0:y["custom-slides-autoplay"])==="true"||/autoplay/i.test(N),U=((d=o==null?void 0:o.attributes)==null?void 0:d["custom-slides-loop"])==="true"||/loop/i.test(N),W=((h=o==null?void 0:o.attributes)==null?void 0:h["custom-slides-muted"])==="true"||D||/muted/i.test(N),E=((m=o==null?void 0:o.attributes)==null?void 0:m["custom-slides-controls"])==="false",P=N.match(/\bsrc=["']([^"']+)["']/i),x=P?P[1]:"",K=['class="slide-video-player"'];E||K.push("controls"),D&&(K.push("autoplay"),K.push("playsinline")),U&&K.push("loop"),W&&K.push("muted"),K.push('preload="metadata"'),x&&K.push(`src="${x}"`);const j=N.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let $=j?j[1].trim():"";!$&&x&&($=`<source src="${x}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${D?"true":"false"}" data-muted="${W?"true":"false"}"><video ${K.join(" ")}>${$}</video></div>`);continue}l[l.length-1].text+=`
`+A}else s.push(A)}if(l.length===0)return null;const a=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),u=l.map(g=>{const b=Am(g.text),k=g.media&&g.media.length>0?`
${g.media.join(`
`)}`:"",w=g.level||0,C=w>0?` style="margin-left:${(w*1.25).toFixed(2)}em;${g.type==="unordered"?`list-style-type:${w%2===1?"circle":"square"} !important;`:""}"`:"",A=w>0?" slide-list-item--nested":"";if(g.type==="task"){const I=g.checked?' checked=""':"";return`<li class="pdf-task-item${A}"${C}><label><input type="checkbox" disabled=""${I}/> <span>${b}</span></label>${k}</li>`}return`<li${A?` class="${A.trim()}"`:""}${C}>${b}${k}</li>`}).join(`
`);return`${Em(s)}<${a} class="${c}">
${u}
</${a}>`}function Bm(e,t,o){const i=(t==null?void 0:t.containerClassName)||"pdf-block",n=e.split(/\r?\n/),s=[];let l=[];for(let c=0;c<n.length;c++){const u=n[c],p=u.trim();if(/^#{1,6}\s+/.test(p)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(p);continue}if(!p){l.length>0&&(s.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(p)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(p);continue}if(/<video\b/i.test(p)){l.length>0&&(s.push(l.join(`
`)),l=[]);let y=p;if(!/<\/video>/i.test(y))for(;c+1<n.length&&!/<\/video>/i.test(y);)c++,y+=`
`+n[c];s.push(y);continue}l.push(u)}l.length>0&&s.push(l.join(`
`));let r=!0;return s.map(c=>{var h,m,g,b;const u=c.trim();if(!u)return"";const p=u.match(/^(#{1,6})\s+(.*)$/);if(p){r=!1;const k=p[1].length;return`<h${k} class="slide-list-item-title">${dt(p[2].trim())}</h${k}>`}const y=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(y){const k=/\.gif(?:\?|$)/i.test(y[2]),w=(t==null?void 0:t.imageClassName)||(k?"list-item-gif":"pdf-image slide-media-img");return`<div class="${i} ${i}--image slide-media-block slide-media-container slide-list-media"><img alt="${st(y[1])}" src="${y[2]}" class="${w}" /></div>`}if(/<video\b/i.test(u)){const k=((h=o==null?void 0:o.attributes)==null?void 0:h["custom-slides-autoplay"])==="true"||/autoplay/i.test(u),w=((m=o==null?void 0:o.attributes)==null?void 0:m["custom-slides-loop"])==="true"||/loop/i.test(u),C=((g=o==null?void 0:o.attributes)==null?void 0:g["custom-slides-muted"])==="true"||k||/muted/i.test(u),A=((b=o==null?void 0:o.attributes)==null?void 0:b["custom-slides-controls"])==="false",M=u.match(/\bsrc=["']([^"']+)["']/i),I=M?M[1]:"",N=['class="slide-video-player"'];A||N.push("controls"),k&&N.push("autoplay playsinline"),w&&N.push("loop"),C&&N.push("muted"),N.push('preload="metadata"'),I&&N.push(`src="${I}"`);const D=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let U=D?D[1].trim():"";return!U&&I&&(U=`<source src="${I}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${i} ${i}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${k?"true":"false"}" data-muted="${C?"true":"false"}"><video ${N.join(" ")}>${U}</video></div>`}const d=qa(u,t,o);if(d)return r=!1,d;if(r){r=!1;const k=u.split(/\r?\n/).map(M=>M.trim()).filter(Boolean);if(k.length===1)return`<p class="slide-list-item-title">${dt(k[0])}</p>`;const w=k[0],A=k.slice(1).map(M=>dt(M)).join("<br/>");return`<p class="slide-list-item-title">${dt(w)}</p>
<p class="slide-list-item-desc">${A}</p>`}return`<p class="slide-list-item-desc">${dt(u)}</p>`}).filter(Boolean).join(`
`)}function ds(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function Ga(e,t){var r,a,c,u,p,y,d,h;const o=((r=e.frontmatter)==null?void 0:r.layout)||"default",n=(e.blocks||[]).filter(m=>m.slot!=="slot-divider-right"),l=o==="cover"?null:n.find(ds);if(o==="two-cols"){const m=n.some(W=>W.slot==="right");let g=[],b=[];if(m)g=n.filter(W=>W.slot!=="right"),b=n.filter(W=>W.slot==="right");else{const W=Math.ceil(n.length/2);g=n.slice(0,W),b=n.slice(W)}const k=W=>{const E=W.filter(P=>!!(P.rawMarkdown||P.content||"").trim());if(E.length>0){const P=E[0],x=(P.rawMarkdown||P.content||"").trim();(Po(P)||/^(?:[-*+]|\d+\.)\s+/.test(x))&&(P.rawMarkdown=Ri(P.rawMarkdown||P.content||""),P.content=P.rawMarkdown)}};k(g),k(b);const w=g.map(W=>Io(W,t)).join(`
`),C=b.map(W=>Io(W,t)).join(`
`),A=(t==null?void 0:t.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",M=(a=e.frontmatter)!=null&&a.layoutClass?` ${e.frontmatter.layoutClass}`:"",I=(t==null?void 0:t.leftColClass)||"pdf-col pdf-col--left",N=(t==null?void 0:t.rightColClass)||"pdf-col pdf-col--right",U=`style="grid-template-columns: ${as((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${A}${M}" ${U}>
        <div class="${I}">${w}</div>
        <div class="${N}">${C}</div>
      </div>
    `}if(o==="clover"||ai(o)){const m=o==="clover";let g=[];const b=n.filter(K=>K.slot==="header");if(b.length>0)g=b;else if(n.length>0){const K=n.find(j=>j.type==="h"&&(!j.slot||j.slot==="default"));K&&(g=[K])}const k=n.filter(K=>!g.includes(K));let w=2;if(m)w=4;else if(o==="three-cols-header")w=3;else if(o==="two-cols-header")w=2;else{let K=0;for(const j of k){const $=(j.slot||"").match(/^col-(\d+)$/i);$&&(K=Math.max(K,parseInt($[1],10)))}if(K>=2)w=K;else if((u=e.frontmatter)!=null&&u.layoutRatio){const j=e.frontmatter.layoutRatio.trim();if(j.includes(":")){const $=j.split(":").map(T=>parseFloat(T.trim())).filter(T=>!isNaN(T)&&T>0);$.length>=2&&(w=$.length)}else{const $=j.split(/\s+/).filter(Boolean);$.length>=2&&(w=$.length)}}else k.length===1&&k[0].children&&k[0].children.length>=2&&(w=Math.min(6,k[0].children.length))}const C=Ps(k,w),A=k.some(K=>K.slot&&/^(?:col-\d+|left|right)$/i.test(K.slot)),M=o==="clover"||o==="two-cols-header"||o==="three-cols-header"||ai(o)&&A,I=K=>{const j=K.filter(T=>!!(T.rawMarkdown||T.content||"").trim());if(M&&j.length>0){const T=j[0],O=(T.rawMarkdown||T.content||"").trim();(Po(T)||/^(?:[-*+]|\d+\.)\s+/.test(O))&&(T.rawMarkdown=Ri(T.rawMarkdown||T.content||""),T.content=T.rawMarkdown),T.isColFirst=!0}const $=M?j.find(ds):null;return j.map(T=>Io(T,{...t,extraClassName:T===$?"slides-col-first-heading-block":""})).join(`
`)},N=g.find(ds),D=g.map(K=>Io(K,{...t,extraClassName:K===N?"slides-page-first-heading-block":""})).join(`
`),U=m?"repeat(2, minmax(0, 1fr))":as((p=e.frontmatter)==null?void 0:p.layoutRatio,w),W=m?`style="grid-template-columns: ${U}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${U};"`,E=[m?"layout-clover-container":"layout-cols-header-container",w===2?"layout-two-cols-header-container":"",w===3?"layout-three-cols-header-container":"",`layout-${o}-container`,M?"has-superblock-cols":""].filter(Boolean).join(" "),P=[m?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",w===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",w===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",M?"has-superblock-cols":""].filter(Boolean).join(" "),x=C.map((K,j)=>{const $=j+1;return`<div class="${["pdf-col",w===2&&$===1?"pdf-col--left":"",w===2&&$===2?"pdf-col--right":"",`pdf-col--${$}`,`col-${$}`].filter(Boolean).join(" ")}">${I(K)}</div>`}).join(`
`);return`
      <div class="${E}">
        <div class="layout-header-section">${D}</div>
        <div class="${P}" ${W}>
          ${x}
        </div>
      </div>
    `}if(o==="image-right"||o==="image-left"){const m=o==="image-right",g=n.map(M=>Io(M,t)).join(`
`),b=((y=e.frontmatter)==null?void 0:y.image)||((d=e.frontmatter)==null?void 0:d.background)||"",k=`<div class="pdf-image-col" style="background-image:url('${st(b)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${st(b)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,w=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${g}</div>`,C=m?`${w}
${k}`:`${k}
${w}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${as((h=e.frontmatter)==null?void 0:h.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${C}
      </div>
    `}return o==="fact"?`<div class="layout-fact-container">${n.map(g=>Io(g,t)).join(`
`)}</div>`:o==="cover"?`<div class="layout-cover-container">${n.map(g=>Io(g,t)).join(`
`)}</div>`:n.map(m=>Io(m,{...t,extraClassName:m===l?"slides-page-first-heading-block":""})).join(`
`)}function st(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Dm(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,o=e.split("|");for(const i of o){const n=i.trim();if(n==="all")return"all";if(n.includes("-")){const[s,l]=n.split("-"),r=parseInt(s,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)t.add(c)}else{const s=parseInt(n,10);isNaN(s)||t.add(s)}}return t}const Lm=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function dt(e){if(!e)return"";const t=za(e),o=[],i=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,l)=>{const r=l.toLowerCase();if(!Lm.has(r)||/on\w+\s*=|javascript:/i.test(s))return s;if(r==="v-mark"){const a=s.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return s.startsWith("</")?o.push("</mark>"):o.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${o.length-1}%%`}return o.push(s),`%%SAFE_HTML_${o.length-1}%%`});let n=st(i);return n=n.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,l,r,a,c,u,p)=>{const d=(r??a??c??u??p??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${d}</a>`}),n=n.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),n=n.replace(/!\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),n=n.replace(/\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slides-link">${l}</a>`}),n=n.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${r}</a>`),n=n.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),n=n.replace(/\*(.*?)\*/g,"<em>$1</em>"),n=n.replace(/~~(.*?)~~/g,"<del>$1</del>"),n=n.replace(/`([^`]+)`/g,"<code>$1</code>"),n=n.replace(/%%SAFE_HTML_(\d+)%%/g,(s,l)=>{const r=parseInt(l,10);return o[r]||""}),n}function Om(e,t="pdf-table"){if(e.length<2)return"";const o=e.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),i=o[0];let n=[],s=1;e.length>=2&&o[1].every(a=>/^:?-+:?$/.test(a))&&(n=o[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),s=2);const l=`<thead><tr>${i.map((a,c)=>`<th${n[c]?` style="text-align: ${n[c]}"`:""}>${dt(a)}</th>`).join("")}</tr></thead>`,r=o.slice(s).map(a=>`<tr>${a.map((c,u)=>`<td${n[u]?` style="text-align: ${n[u]}"`:""}>${dt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${l}<tbody>${r}</tbody></table>`}function us(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function fl(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${us(e)}</span>`;const o=[];function i(s,l){return o.push(`<span class="${s}">${us(l)}</span>`),`__TOK_${o.length-1}__`}let n=e.replace(/(['"`])(.*?)\1/g,(s,l,r)=>i("token-string",`${l}${r}${l}`));return n=n.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,s=>i("token-keyword",s)),n=n.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,s=>i("token-type",s)),n=n.replace(/\b(\d+)\b/g,s=>i("token-number",s)),n=us(n),n=n.replace(/__TOK_(\d+)__/g,(s,l)=>o[parseInt(l,10)]||""),n}function Pm(e,t){if(!e)return null;const o=e.frontmatter||{};if(o.hideInToc===!0||o.hideInToc==="true")return null;let i=(o.title||"").trim(),n=o.level?parseInt(o.level,10):0;if(!i){const s=e.blocks||[];for(const l of s){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){n||(n=a[1].length),i=a[2].trim();break}}}return i?((!n||isNaN(n))&&(n=1),{pageIndex:e.pageIndex||t,title:i,level:n}):null}function Nm(e,t=1,o={}){const i=o.minDepth!==void 0?Number(o.minDepth):1,n=o.maxDepth!==void 0?Number(o.maxDepth):1/0,s=[];Array.isArray(e)&&e.forEach((c,u)=>{const p=Pm(c,u+1);p&&s.push(p)});const l=[];let r=null;for(const c of s){const u={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(u),r=u):r?(u.active&&(r.hasActiveChild=!0),r.children.push(u)):l.push(u)}function a(c,u=1){if(u>n)return[];const p=[];for(const y of c){const d=a(y.children,u+1);u>=i?p.push({...y,children:d}):p.push(...d)}return p}return a(l,1)}function Rm(e,t=1,o={}){const i=Nm(e,t,o),n=o.columns?Number(o.columns):1,s=n>1?` style="column-count: ${n};"`:"",l=o.textSm?" text-sm":"";function r(c,u=1){if(!c||c.length===0)return"";const p=`slides-toc-list slides-toc-list-level-${u}`,y=c.map(d=>{const h=d.active?" slides-toc-item-active":d.hasActiveChild?" slides-toc-item-parent-active":"",m=d.children&&d.children.length>0?r(d.children,u+1):"";let g=dt(d.title);return g.includes("LaTeX")&&(g=g.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slides-toc-item${h}" data-page="${d.pageIndex}">
          <a class="slides-toc-link" href="javascript:void(0)">
            <span class="slides-toc-title">${g}</span>
          </a>
          ${m}
        </li>
      `}).join("");return`<ol class="${p}">${y}</ol>`}const a=r(i,1);return`<div class="slides-toc${l}"${s}>${a}</div>`}function Io(e,t){var A,M,I,N,D,U,W,E,P,x,K,j;let o="",i="",n="";const s=[];(A=e.motion)!=null&&A.preset&&e.motion.preset!=="none"&&(o=` slides-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&s.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&s.push(`--motion-delay:${e.motion.delay}ms`));const l=((M=e.attributes)==null?void 0:M.style)||"";l&&(s.push(l),n=" slide-styled-block"),s.length>0&&(i=` style="${st(s.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",a=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=t!=null&&t.blockClassResolver?t.blockClassResolver(e):"",u=c?` ${c}`:"",p=`${r}${o}${n}${a}${u}`,y=(e.rawMarkdown||e.content||"").trim();if(!y)return`<div class="${p}"${i}></div>`;if(y.includes('class="slides-block-ref"')||y.includes('class="slides-ref-tag"'))return`<div class="${p}"${i}>${y}</div>`;if(y.startsWith("$$")&&y.endsWith("$$")){const $=y.slice(2,-2).trim();return`<div class="${p} katex-display-container"${i}><div class="katex-display font-math"><em>${st($)}</em></div></div>`}const d=y.match(/^(#{1,6})\s+(.*)$/);if(d){const $=d[1].length,T=dt(d[2]),te=!!(e.isColFirst||e.type==="i"&&((I=t==null?void 0:t.extraClassName)!=null&&I.includes("slides-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${p}"${i}><h${$}${te}>${T}</h${$}></div>`}if(y.startsWith(":::")){const $=y.split(`
`),O=$[0].replace(/^:::\s*/,"").trim()||"info",te=$.slice(1,$[$.length-1].startsWith(":::")?-1:void 0).join(`
`),Y=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${p}"${i}><div class="${Y} ${Y}--${O}"><div class="${Y}-title">${O.toUpperCase()}</div><div class="${Y}-body">${dt(te)}</div></div></div>`}if(y.startsWith("<<<")){const O=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((oe,ne)=>`<span class="code-line shiki-focus"><span class="line-no">${ne+1}</span><span class="line-content">${fl(oe,"ts")}</span></span>`).join(`
`),te=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",Y=((N=e.attrs)==null?void 0:N["custom-slides-max-height"])||((D=e.attributes)==null?void 0:D["custom-slides-max-height"])||e.maxHeight||"",Z=Os(String(Y||"")),ce=Z?` style="max-height:${st(Z)};overflow-y:auto;"`:"";return`<div class="${p}"${i}><pre class="${te}"${ce}><span class="lang-badge">TS</span><code>${O}</code></pre></div>`}if(y.startsWith("<style")||y.startsWith("<!-- Inline style -->")||y.startsWith(`<!--
Notes`))return"";if(y.startsWith("```")){const $=y.split(`
`),T=$[0].slice(3).trim(),O=T.match(/^([^\s{\[]+)/),te=O?O[1]:"",Y=T.match(/\[([^\]]+)\]/),Z=Y?Y[1]:"",ce=T.includes("twoslash"),oe=e.shikiLines||((U=T.match(/\{([^}]+)\}/))==null?void 0:U[1])||"",ne=Dm(oe),Ce=$.length>2?$[$.length-1]==="```"?$.slice(1,-1):$.slice(1):[y.slice(3).replace(/```$/,"")],_e=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",ke=Z?`${_e} has-filename`:_e,Ie=ne!=="all",R=Ce.map((z,S)=>{const _=S+1,q=ne==="all"||ne.has(_)?"code-line shiki-focus":Ie?"code-line shiki-dimmed":"code-line";let G=(t==null?void 0:t.highlight)===!0?fl(z,te):st(z);return ce&&z.includes("doubled.value = 2")?(G=G.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${q}"><span class="line-no">${_}</span><span class="line-content">${G}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${q}"><span class="line-no">${_}</span><span class="line-content">${G}</span></span>`}).join(`
`),ie=te?`<span class="lang-badge">${st(te)}</span>`:"",B=Z?`<span class="code-filename">${st(Z)}</span>`:"",H=((W=e.attrs)==null?void 0:W["custom-slides-max-height"])||((E=e.attributes)==null?void 0:E["custom-slides-max-height"])||e.maxHeight||"",v=Os(String(H||"")),F=v?` style="max-height:${st(v)};overflow-y:auto;"`:"";return`<div class="${p}"${i}><pre class="${ke}"${F}>${B}${ie}<code>${R}</code></pre></div>`}if(y.includes("|")&&y.split(`
`).filter($=>$.trim().startsWith("|")).length>=2){const $=y.split(`
`).filter(O=>O.trim().startsWith("|")),T=Om($,t==null?void 0:t.tableClassName);return`<div class="${p}"${i}>${T}</div>`}if(y.startsWith("> ")){const $=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${p}"${i}><blockquote class="${$}"><p>${dt(y.slice(2))}</p></blockquote></div>`}const h=/<video\b/i.test(y)||e.type==="video"||e.type==="NodeVideo",m=/^(\s*)([-*+]|\d+\.)\s+/m.test(y),g=/(?:^|\n)\s*#{1,6}\s+/.test(y);if(h&&!m&&!g&&!y.includes(`
`)){const $=((P=e.attributes)==null?void 0:P["custom-slides-autoplay"])==="true"||/autoplay/i.test(y),T=((x=e.attributes)==null?void 0:x["custom-slides-loop"])==="true"||/loop/i.test(y),O=((K=e.attributes)==null?void 0:K["custom-slides-muted"])==="true"||$||/muted/i.test(y),te=((j=e.attributes)==null?void 0:j["custom-slides-controls"])==="false",Y=y.match(/\bsrc=["']([^"']+)["']/i),Z=Y?Y[1]:"",ce=['class="slide-video-player"'];te||ce.push("controls"),$&&(ce.push("autoplay"),ce.push("playsinline")),T&&ce.push("loop"),O&&ce.push("muted"),ce.push('preload="auto"'),Z&&ce.push(`src="${Z}"`);const oe=y.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let ne=oe?oe[1].trim():"";return!ne&&Z&&(ne=`<source src="${Z}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${p} ${p}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${$?"true":"false"}" data-muted="${O?"true":"false"}"${i}><video ${ce.join(" ")}>${ne}</video></div>`}const b=y.match(/^!\[(.*?)\]\((.*?)\)$/);if(b){const $=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${p} ${p}--image slide-media-block slide-media-container"${i}><img alt="${st(b[1])}" src="${b[2]}" class="${$}" /></div>`}const k=qa(y,t,e);if(k)return`<div class="${p} pdf-list-item"${i}>${k}</div>`;if(/<(?:Toc|toc)\b/i.test(y)&&!y.startsWith("```")){const $=y.match(/minDepth=["']?(\d+)["']?/i),T=y.match(/maxDepth=["']?(\d+)["']?/i),O=y.match(/columns=["']?(\d+)["']?/i),te=(t==null?void 0:t.allSlides)||[];return`<div class="${p}"${i}>${Rm(te,(t==null?void 0:t.currentPageIndex)||1,{minDepth:$?parseInt($[1],10):1,maxDepth:T?parseInt(T[1],10):1/0,columns:O?parseInt(O[1],10):1,textSm:y.includes("text-sm")})}</div>`}if(y.includes(`
`)||g){const $=Bm(y,t,e);if($)return`<div class="${p}"${i}>${$}</div>`}const C=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${p}"${i}><p${C}>${dt(y)}</p></div>`}function zm(e){return`
    ${Hi(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default (Modern Tech / Digital Geek) */
    [data-slides-theme="tech"],
    .slides-theme-tech {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
      --slide-accent-secondary: #06b6d4;
    }
    [data-theme="light"][data-slides-theme="tech"],
    [data-theme="light"] .slides-theme-tech,
    .slide-viewport[data-theme="light"].slides-theme-tech,
    .slide-viewport[data-theme="light"] {
      --slide-bg: #f8fafc;
      --slide-text: #0f172a;
      --slide-text-secondary: #475569;
      --slide-code-bg: #f1f5f9;
      --slide-code-border: rgba(15, 23, 42, 0.12);
      --slide-accent: #059669;
      --slide-accent-secondary: #0284c7;
      --slide-card-bg: rgba(255, 255, 255, 0.85);
      --slide-card-border: rgba(148, 163, 184, 0.35);
      --slide-card-shadow: 0 4px 14px rgba(15, 23, 42, 0.06);
    }
    [data-theme="dark"][data-slides-theme="tech"],
    [data-theme="dark"] .slides-theme-tech,
    .slide-viewport[data-theme="dark"].slides-theme-tech,
    .slide-viewport:not([data-theme="light"]) {
      --slide-bg: #090d16;
      --slide-text: #f1f5f9;
      --slide-text-secondary: #94a3b8;
      --slide-code-bg: #0f172a;
      --slide-code-border: rgba(56, 189, 248, 0.22);
      --slide-accent: #10b981;
      --slide-accent-secondary: #38bdf8;
      --slide-card-bg: rgba(15, 23, 42, 0.7);
      --slide-card-border: rgba(56, 189, 248, 0.2);
      --slide-card-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
    }
    /* 单页为 light 时高特异性覆盖，即使外层是 dark 也强制生效 */
    [data-theme="dark"] .slide-viewport[data-theme="light"],
    .slide-viewport[data-theme="light"] {
      color: var(--slide-text) !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-tech,
    .slide-viewport[data-theme="light"].slides-theme-tech {
      --slide-text: #0f172a !important;
      --slide-text-secondary: #475569 !important;
      --slide-accent: #059669 !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-seriph,
    .slide-viewport[data-theme="light"].slides-theme-seriph {
      --slide-text: #231f1d !important;
      --slide-text-secondary: #57534e !important;
      --slide-accent: #b45309 !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-apple-basic,
    .slide-viewport[data-theme="light"].slides-theme-apple-basic {
      --slide-text: #000000 !important;
      --slide-text-secondary: #6e6e73 !important;
      --slide-accent: #0071e3 !important;
    }
    /* 单页为 dark 时高特异性覆盖，即使外层是 light 也强制生效 */
    [data-theme="light"] .slide-viewport[data-theme="dark"],
    .slide-viewport[data-theme="dark"] {
      color: var(--slide-text) !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-tech,
    .slide-viewport[data-theme="dark"].slides-theme-tech {
      --slide-text: #f1f5f9 !important;
      --slide-text-secondary: #94a3b8 !important;
      --slide-accent: #10b981 !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-seriph,
    .slide-viewport[data-theme="dark"].slides-theme-seriph {
      --slide-text: #f5f2eb !important;
      --slide-text-secondary: #a8a29e !important;
      --slide-accent: #f59e0b !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-apple-basic,
    .slide-viewport[data-theme="dark"].slides-theme-apple-basic {
      --slide-text: #ffffff !important;
      --slide-text-secondary: #86868b !important;
      --slide-accent: #2997ff !important;
    }
    .slides-theme-tech .layout-cover h1,
    .slides-theme-tech .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, var(--slide-accent), var(--slide-accent-secondary)) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slides-theme-tech .layout-cover h2,
    .slides-theme-tech .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      color: var(--slide-text-secondary) !important;
      margin-bottom: 12px !important;
    }
    .slides-theme-tech .layout-cover p,
    .slides-theme-tech .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      color: var(--slide-text-secondary) !important;
    }
    /* 默认科技风：内容页顶部标题带 Accent 垂直指示条与柔和横向高亮底衬 */
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      color: var(--slide-accent);
      border-left: 4px solid var(--slide-accent);
      padding: 4px 14px;
      padding-left: 14px;
      background: linear-gradient(90deg, color-mix(in srgb, var(--slide-accent) 13%, transparent), transparent 76%);
      border-radius: 0 6px 6px 0;
      letter-spacing: -0.015em;
    }
    .slides-theme-tech blockquote {
      border-left: 3px solid var(--slide-accent) !important;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent) !important;
      border-radius: 4px;
      padding: 12px 18px !important;
    }
    .slides-theme-tech pre {
      border: 1px solid var(--slide-code-border) !important;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.18) !important;
      border-radius: 8px !important;
    }

    /* 2. 优雅衬线主题 Seriph (典雅学术书卷风) */
    [data-slides-theme="seriph"],
    .slides-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      --slide-accent-secondary: #9a3412;
      letter-spacing: 0.02em;
    }
    [data-theme="light"][data-slides-theme="seriph"],
    [data-theme="light"] .slides-theme-seriph {
      --slide-bg: #fcfbf7;
      --slide-text: #231f1d;
      --slide-text-secondary: #57534e;
      --slide-code-bg: #f5f0e6;
      --slide-code-border: rgba(180, 83, 9, 0.2);
      --slide-accent: #b45309;
      --slide-accent-secondary: #9a3412;
      --slide-card-bg: rgba(255, 255, 255, 0.75);
      --slide-card-border: rgba(180, 83, 9, 0.25);
      --slide-card-shadow: 0 2px 10px rgba(41, 37, 36, 0.04);
    }
    [data-theme="dark"][data-slides-theme="seriph"],
    [data-theme="dark"] .slides-theme-seriph {
      --slide-bg: #171513;
      --slide-text: #f5f2eb;
      --slide-text-secondary: #a8a29e;
      --slide-code-bg: #24201c;
      --slide-code-border: rgba(245, 158, 11, 0.22);
      --slide-accent: #f59e0b;
      --slide-accent-secondary: #fb923c;
      --slide-card-bg: rgba(32, 28, 24, 0.8);
      --slide-card-border: rgba(245, 158, 11, 0.22);
      --slide-card-shadow: 0 4px 16px rgba(0, 0, 0, 0.4);
    }
    .slides-theme-seriph,
    .slides-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.75;
    }
    .slides-theme-seriph h1,
    .slides-theme-seriph h2,
    .slides-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slides-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      font-weight: 700 !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
      margin-bottom: 24px;
    }
    .slides-theme-seriph .layout-cover p {
      font-style: italic;
      color: var(--slide-text-secondary);
    }
    /* 优雅衬线风：内容页顶部标题学术双线眉批 */
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      display: block;
      position: relative;
      color: var(--slide-accent);
      border-bottom: 1.5px solid color-mix(in srgb, var(--slide-accent) 45%, transparent);
      padding-bottom: 10px;
      margin-bottom: 14px;
    }
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3::after {
      content: "";
      position: absolute;
      left: 0;
      right: 0;
      bottom: 3px;
      height: 1.5px;
      pointer-events: none;
      background: linear-gradient(90deg, var(--slide-accent) 0%, color-mix(in srgb, var(--slide-accent) 35%, transparent) 50%, transparent 92%);
    }
    .slides-theme-seriph blockquote {
      position: relative;
      font-style: italic;
      border-left: 2px solid var(--slide-accent) !important;
      background: color-mix(in srgb, var(--slide-accent) 6%, transparent) !important;
      padding: 14px 20px 14px 28px !important;
      border-radius: 4px;
      margin: 12px 0 !important;
    }
    .slides-theme-seriph blockquote::before {
      content: "“";
      position: absolute;
      left: 8px;
      top: 6px;
      font-size: 2rem;
      line-height: 1;
      color: var(--slide-accent);
      opacity: 0.6;
      font-family: Georgia, serif;
    }
    .slides-theme-seriph pre {
      border: 1px solid var(--slide-code-border) !important;
      border-radius: 4px !important;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08) !important;
    }

    /* 3. 极简发布会主题 Apple Basic (苹果 Keynote / 瑞士纯粹主义) */
    [data-slides-theme="apple-basic"],
    .slides-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
      --slide-accent-secondary: #0077ed;
      letter-spacing: -0.025em;
    }
    [data-theme="light"][data-slides-theme="apple-basic"],
    [data-theme="light"] .slides-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #000000;
      --slide-text-secondary: #6e6e73;
      --slide-code-bg: #f5f5f7;
      --slide-code-border: transparent;
      --slide-accent: #0071e3;
      --slide-accent-secondary: #0077ed;
      --slide-card-bg: #f5f5f7;
      --slide-card-border: transparent;
      --slide-card-shadow: none;
    }
    [data-theme="dark"][data-slides-theme="apple-basic"],
    [data-theme="dark"] .slides-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #ffffff;
      --slide-text-secondary: #86868b;
      --slide-code-bg: #161617;
      --slide-code-border: transparent;
      --slide-accent: #2997ff;
      --slide-accent-secondary: #64d2ff;
      --slide-card-bg: #161617;
      --slide-card-border: transparent;
      --slide-card-shadow: none;
    }
    .slides-theme-apple-basic,
    .slides-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slides-theme-apple-basic h1,
    .slides-theme-apple-basic h2,
    .slides-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slides-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 4rem !important;
      font-weight: 800 !important;
      letter-spacing: -0.045em !important;
      margin-bottom: 12px;
    }
    .slides-theme-apple-basic .layout-cover p {
      color: var(--slide-text-secondary) !important;
      font-size: 1.35rem !important;
      font-weight: 500 !important;
      opacity: 1 !important;
    }
    /* 极简发布会风：彻底去装饰化，高字重、紧凑字距与充沛留白 */
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      border: none !important;
      background: none !important;
      padding: 0 !important;
      margin-bottom: 16px !important;
      letter-spacing: -0.04em !important;
      font-weight: 800 !important;
    }
    .slides-theme-apple-basic pre {
      border-radius: 16px !important;
      border: none !important;
      background: var(--slide-code-bg) !important;
      box-shadow: none !important;
    }
    .slides-theme-apple-basic blockquote {
      border-left: none !important;
      background: var(--slide-card-bg) !important;
      border-radius: 14px !important;
      padding: 18px 24px !important;
      font-size: 1.15rem !important;
      color: var(--slide-text) !important;
    }

    /* 复杂背景防穿透文字保护 (Text Scrim & Backdrop Protection) */
    .slide-viewport[style*="background-image"] .slide-content h1,
    .slide-viewport[style*="background-image"] .slide-content h2,
    .slide-viewport[style*="background-image"] .slide-content h3,
    .slide-viewport[style*="background-image"] .slide-content p,
    .slide-viewport[style*="background-image"] .slide-content li {
      text-shadow: 0 1px 3px rgba(0, 0, 0, 0.75), 0 2px 8px rgba(0, 0, 0, 0.45);
    }
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h1,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h2,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h3,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content p,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content li {
      text-shadow: 0 1px 3px rgba(255, 255, 255, 0.85);
    }
    .slide-viewport[style*="background-image"] .layout-cols-grid > div,
    .slide-viewport[style*="background-image"] .layout-two-cols-grid > div,
    .slide-viewport[style*="background-image"] .layout-three-cols-grid > div,
    .slide-viewport[style*="background-image"] .two-cols-left,
    .slide-viewport[style*="background-image"] .two-cols-right,
    .slide-viewport[style*="background-image"] .pdf-col {
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
    }

    /* 封面页在背景图或显式设置文字颜色时，禁用透明渐变镂空，避免与 text-shadow 叠加成浮雕黑芯并遵循主题及实际文字色 */
    .slide-viewport[style*="background-image"] .layout-cover h1,
    .slide-viewport[style*="background-image"] .layout-cover .slide-block h1,
    .slides-overview-canvas[style*="background-image"].layout-cover h1,
    .slides-overview-canvas[style*="background-image"].layout-cover .slide-block h1,
    .slides-overview-canvas[style*="background-image"] .layout-cover h1,
    .slides-overview-canvas[style*="background-image"] .layout-cover .slide-block h1,
    .slides-theme-tech .layout-cover .slide-block[style^="color:"] h1,
    .slides-theme-tech .layout-cover .slide-block[style*=" color:"] h1,
    .slides-theme-tech .layout-cover .slide-block[style*=";color:"] h1,
    .slides-theme-tech .layout-cover h1[style^="color:"],
    .slides-theme-tech .layout-cover h1[style*=" color:"],
    .slides-theme-tech .layout-cover h1[style*=";color:"] {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
    }
    .layout-cover h1 span[style^="color:"],
    .layout-cover h1 span[style*=" color:"],
    .layout-cover h1 span[style*=";color:"],
    .layout-cover h1 font[color] {
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: currentColor !important;
    }
    /* 当内容页存在背景图时，顶部标题回退至高对比正文字色并配合局部半透明底衬，同时保留主题装饰 */
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      color: var(--slide-text);
    }
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      background: linear-gradient(90deg, color-mix(in srgb, var(--slide-bg) 42%, transparent), transparent 82%);
    }
    /* 用户显式块级前景色优先于主题及背景图默认回退色 */
    .slide-viewport .slide-block[style^="color:"] h1,
    .slide-viewport .slide-block[style*=" color:"] h1,
    .slide-viewport .slide-block[style*=";color:"] h1,
    .slide-viewport .slide-block[style^="color:"] h2,
    .slide-viewport .slide-block[style*=" color:"] h2,
    .slide-viewport .slide-block[style*=";color:"] h2,
    .slide-viewport .slide-block[style^="color:"] h3,
    .slide-viewport .slide-block[style*=" color:"] h3,
    .slide-viewport .slide-block[style*=";color:"] h3 {
      color: inherit !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slides-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
      container-type: size;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slides-spacing="compact"] {
      --slides-padding-y: 16px;
      --slides-padding-x: 28px;
      --slides-block-gap: 8px;
      --slides-list-gap: 4px;
      --slides-cols-gap: 20px;
      --slides-title-margin-bottom: 8px;
      --slides-header-gap: 10px;
      --slides-line-height: 1.45;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slides-spacing="normal"] {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-block-gap: 14px;
      --slides-list-gap: 6px;
      --slides-cols-gap: 32px;
      --slides-title-margin-bottom: 12px;
      --slides-header-gap: 16px;
      --slides-line-height: 1.6;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slides-spacing="loose"] {
      --slides-padding-y: 52px;
      --slides-padding-x: 72px;
      --slides-block-gap: 22px;
      --slides-list-gap: 10px;
      --slides-cols-gap: 44px;
      --slides-title-margin-bottom: 18px;
      --slides-header-gap: 24px;
      --slides-line-height: 1.75;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: var(--slides-cols-gap, 32px);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.75);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.625);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: var(--slides-block-gap, 14px);
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: var(--slides-block-gap, 14px); line-height: var(--slides-line-height, 1.6); }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: var(--slides-title-margin-bottom, 12px); }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: calc(var(--slides-title-margin-bottom, 10px) * 0.85); }
    .slide-block p { font-size: 1.15rem; line-height: var(--slides-line-height, 1.6); }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: calc(var(--slides-block-gap, 14px) * 0.6) 0;
      display: flex;
      flex-direction: column;
      gap: var(--slides-list-gap, 6px);
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: var(--slides-line-height, 1.6);
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: var(--slides-list-gap, 6px) !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: var(--slides-line-height, 1.6) !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slides-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slides-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slides-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slides-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
      user-select: none;
      -webkit-user-drag: none;
      touch-action: none;
    }
    .slides-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slides-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slides-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidesMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidesMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidesMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slides-motion-fade-in { animation: slidesMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-up { animation: slidesMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-down { animation: slidesMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-left { animation: slidesMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-right { animation: slidesMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-zoom-in, .slides-motion-pop { animation: slidesMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slides-motion-bounce { animation: slidesMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slides-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    a.slides-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    a.slides-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slides-ref-tag:hover, a.slides-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slides-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slides-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slides-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slides-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-left: var(--slides-padding-x, 48px) !important;
      padding-right: var(--slides-padding-x, 48px) !important;
      padding-bottom: var(--slides-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slides-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slides-mask-body-container--has-mask:first-child,
    .slide-content > .slides-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-top: var(--slides-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slides-padding-x: 0px !important;
      --slides-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slides-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slides-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slides-mask-layer--solid .slides-mask-overlay,
    .slides-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slides-mask-layer--solid .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slides-mask-layer--blur .slides-mask-overlay,
    .slides-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slides-mask-layer--blur .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slides-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slides-mask-layer--down .slides-mask-divider-line,
    .slides-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--right .slides-mask-divider-line,
    .slides-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--clockwise,
    .slides-mask-layer--counter-clockwise,
    .slides-mask-layer--cw,
    .slides-mask-layer--ccw,
    .slides-mask-layer--clock {
      transform: none !important;
    }
    .slides-mask-layer--clockwise .slides-mask-divider-line,
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-layer--cw .slides-mask-divider-line,
    .slides-mask-layer--ccw .slides-mask-divider-line,
    .slides-mask-layer--clock .slides-mask-divider-line,
    .slides-mask-divider-line--clock,
    .slides-mask-divider-line--clockwise,
    .slides-mask-divider-line--counter-clockwise {
      top: 50%;
      left: 50%;
      right: auto;
      bottom: auto;
      width: 55%;
      height: 2.5px;
      transform-origin: 0% 50%;
      transform: translateY(-50%) rotate(-180deg);
      background: linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1), opacity 0.3s ease;
      will-change: transform, opacity;
    }
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-divider-line--counter-clockwise {
      transform: translateY(-50%) rotate(-90deg);
    }`}function Hm(){return`    (function() {
      const data = window.__SLIDES_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function Fm(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slides-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slides-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slides-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slides-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slides-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slides-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slides-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slides-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slides-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slides-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slides-overview-canvas *{scrollbar-width:none;}.slides-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slides-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slides-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slides-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slides-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function jm(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slides-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr, defaultSteps) {
        var defSteps = (defaultSteps === 4) ? 4 : 2;
        var defBps = (defaultSteps === 4) ? [25, 50, 75, 100] : [50, 100];
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: defSteps, breakpoints: defBps };
        }
        var clean = ratioStr.trim();
        if (!clean || (defaultSteps === 4 && (clean === "1:1" || clean === "1"))) return { steps: defSteps, breakpoints: defBps };
        var parts = clean.split(":").map(function(p) { return parseFloat(p.trim()); }).filter(function(n) { return !isNaN(n) && n > 0; });
        if (parts.length === 0) return { steps: defSteps, breakpoints: defBps };
        if (parts.length === 1) {
          var val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        var isMonotonic = parts.every(function(val, idx) { return idx === 0 || val > parts[idx - 1]; });
        var maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(function(p) { return p > 10; }))) {
          var bps = parts.map(function(p) { return Math.min(100, Math.round(p * 100) / 100); });
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        var totalWeight = parts.reduce(function(acc, cur) { return acc + cur; }, 0);
        if (totalWeight <= 0) return { steps: defSteps, breakpoints: defBps };
        var accumulated = 0;
        var bps = [];
        for (var i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        if (currentMaskConfig.isClock) {
          const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
          const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360));
          const needleAngle = isCw ? (-180 + sweepDeg) : (-90 - sweepDeg);

          if (maskOverlayEl) {
            let maskGrad = "";
            if (sweepDeg <= 0) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)";
            } else if (sweepDeg >= 360) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)";
            } else if (isCw) {
              maskGrad = "conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent " + sweepDeg + "deg, #000 " + sweepDeg + "deg, #000 360deg)";
            } else {
              const remDeg = 360 - sweepDeg;
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 " + remDeg + "deg, transparent " + remDeg + "deg, transparent 360deg)";
            }
            maskOverlayEl.style.webkitMaskImage = maskGrad;
            maskOverlayEl.style.maskImage = maskGrad;
          }

          if (maskDividerEl) {
            maskDividerEl.style.transform = "translateY(-50%) rotate(" + needleAngle + "deg)";
            maskDividerEl.style.opacity = (p <= 0 || p >= 100) ? "0" : "1";
          }

          if (p >= 100) {
            maskLayerEl.style.opacity = "0";
            maskLayerEl.style.pointerEvents = "none";
          } else {
            maskLayerEl.style.opacity = "1";
            maskLayerEl.style.pointerEvents = "none";
          }
          return;
        }

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        // FSM-9 优化：回退至上一页时传递 backward 方向，使上一页遮罩处于完全展开状态
        renderSlide(currentIndex - 1, "backward");
      }

`}function Wm(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slides-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slides-block-ref"') || md.includes('class="slides-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          var rawMaxH = block?.attributes?.["custom-slides-max-height"] || block?.attrs?.["custom-slides-max-height"] || block?.maxHeight || "";
          var customMaxHeight = "";
          if (rawMaxH) {
            var sMaxH = String(rawMaxH).trim();
            if (/^\\d+$/.test(sMaxH)) customMaxHeight = sMaxH + "px";
            else if (/^(\\d+(?:\\.\\d+)?)%$/.test(sMaxH)) customMaxHeight = sMaxH.replace("%", "cqh");
            else if (/^(\\d+(?:\\.\\d+)?)vh$/.test(sMaxH)) customMaxHeight = sMaxH.replace("vh", "cqh");
            else customMaxHeight = sMaxH;
          }
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (
          /^(s*)([-*+]|d+.)s+/m.test(md) ||
          (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
"))) ||
          ((block && (block.isListItem || block.type === "i")) && !block.isColFirst)
        ) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          if (items.length === 0 && (block && (block.isListItem || block.type === "i")) && !block.isColFirst) {
            items.push({ type: "unordered", level: 0, text: md, media: [] });
            leadLines.length = 0;
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

`}function Um(){return`      function renderSlide(idx, direction) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        function isLightColor(colorStr) {
          if (!colorStr || typeof colorStr !== 'string') return null;
          const s = colorStr.trim().toLowerCase();
          if (!s) return null;
          if (/^(?:https?:\\/\\/|\\/|data:|assets\\/|\\.\\/assets\\/|url\\s*\\()/i.test(s)) return null;
          const lightNamed = ['white', 'snow', 'ivory', 'ghostwhite', 'floralwhite', 'aliceblue', 'whitesmoke', 'seashell', 'beige', 'oldlace', 'linen', 'antiquewhite', 'lightyellow', 'lightcyan', 'papayawhip', 'blanchedalmond', 'cornsilk', 'lavender', 'lavenderblush', 'lemonchiffon', 'honeydew', 'mintcream', 'azure', 'mistyrose', 'wheat', 'lightgoldenrodyellow', 'palegoldenrod', 'gainsboro', 'lightgrey', 'lightgray', 'silver', 'pink', 'lightpink', 'peachpuff', 'navajowhite', 'moccasin', 'bisque', 'khaki', 'palegreen', 'lightgreen', 'lightblue', 'powderblue', 'paleturquoise', 'lightsteelblue', 'thistle', 'yellow', 'cyan', 'aqua'];
          const darkNamed = ['black', 'transparent', 'navy', 'darkblue', 'midnightblue', 'darkslategray', 'darkslategrey', 'maroon', 'darkred', 'darkgreen', 'indigo', 'darkslateblue', 'dimgray', 'dimgrey', 'purple', 'brown', 'olive', 'teal', 'blue', 'darkviolet', 'darkmagenta', 'darkcyan', 'darkolivegreen', 'saddlebrown', 'sienna', 'firebrick', 'crimson', 'mediumblue', 'rebeccapurple'];
          if (lightNamed.includes(s)) return true;
          if (darkNamed.includes(s)) return false;

          function calcLum(r, g, b) {
            return 0.299 * r + 0.587 * g + 0.114 * b;
          }
          function parseHexLum(hexRaw) {
            let hex = hexRaw.startsWith('#') ? hexRaw.slice(1) : hexRaw;
            if (hex.length === 3 || hex.length === 4) hex = hex.slice(0, 3).split('').map(c => c + c).join('');
            if (hex.length >= 6) {
              const r = parseInt(hex.substring(0, 2), 16);
              const g = parseInt(hex.substring(2, 4), 16);
              const b = parseInt(hex.substring(4, 6), 16);
              if (!isNaN(r) && !isNaN(g) && !isNaN(b)) return calcLum(r, g, b);
            }
            return null;
          }
          function parseRgbLum(rgbStr) {
            const m = rgbStr.match(/rgba?\\s*\\(\\s*(\\d+(?:\\.\\d+)?)\\s*[,\\s]\\s*(\\d+(?:\\.\\d+)?)\\s*[,\\s]\\s*(\\d+(?:\\.\\d+)?)(?:\\s*[,\\/]\\s*([0-9.]+%?))?/i);
            if (!m) return null;
            const r = Number(m[1]), g = Number(m[2]), b = Number(m[3]);
            if (isNaN(r) || isNaN(g) || isNaN(b)) return null;
            if (m[4] !== undefined) {
              const a = m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
              if (!isNaN(a) && a <= 0.05) return null;
            }
            return calcLum(r, g, b);
          }
          function parseHslLum(hslStr) {
            const m = hslStr.match(/hsla?\\s*\\(\\s*([0-9.]+)(?:deg)?\\s*[,\\s]\\s*([0-9.]+)%\\s*[,\\s]\\s*([0-9.]+)%(?:\\s*[,\\/]\\s*([0-9.]+%?))?/i);
            if (!m) return null;
            if (m[4] !== undefined) {
              const a = m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
              if (!isNaN(a) && a <= 0.05) return null;
            }
            const h = (((Number(m[1]) % 360) + 360) % 360) / 360;
            const sat = Math.max(0, Math.min(1, Number(m[2]) / 100));
            const lig = Math.max(0, Math.min(1, Number(m[3]) / 100));
            let r, g, b;
            if (sat === 0) {
              r = g = b = lig * 255;
            } else {
              const q = lig < 0.5 ? lig * (1 + sat) : lig + sat - lig * sat;
              const p = 2 * lig - q;
              const hue2rgb = (t) => {
                let tt = t;
                if (tt < 0) tt += 1;
                if (tt > 1) tt -= 1;
                if (tt < 1 / 6) return p + (q - p) * 6 * tt;
                if (tt < 1 / 2) return q;
                if (tt < 2 / 3) return p + (q - p) * (2 / 3 - tt) * 6;
                return p;
              };
              r = hue2rgb(h + 1 / 3) * 255;
              g = hue2rgb(h) * 255;
              b = hue2rgb(h - 1 / 3) * 255;
            }
            return calcLum(r, g, b);
          }

          if (s.startsWith('#')) {
            const lum = parseHexLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/^rgba?\\s*\\(/i.test(s)) {
            const lum = parseRgbLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/^hsla?\\s*\\(/i.test(s)) {
            const lum = parseHslLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/(?:linear|radial|conic)-gradient\\s*\\(/i.test(s)) {
            const luminances = [];
            const hexMatches = s.match(/#(?:[0-9a-f]{8}|[0-9a-f]{6}|[0-9a-f]{4}|[0-9a-f]{3})\\b/gi);
            if (hexMatches) {
              for (const h of hexMatches) {
                const lum = parseHexLum(h);
                if (lum !== null) luminances.push(lum);
              }
            }
            const rgbMatches = s.match(/rgba?\\s*\\([^)]+\\)/gi);
            if (rgbMatches) {
              for (const r of rgbMatches) {
                const lum = parseRgbLum(r);
                if (lum !== null) luminances.push(lum);
              }
            }
            const hslMatches = s.match(/hsla?\\s*\\([^)]+\\)/gi);
            if (hslMatches) {
              for (const h of hslMatches) {
                const lum = parseHslLum(h);
                if (lum !== null) luminances.push(lum);
              }
            }
            const stripped = s.replace(/#[0-9a-f]+|rgba?\\([^)]+\\)|hsla?\\([^)]+\\)/gi, ' ');
            const wordMatches = stripped.match(/\\b[a-z]+\\b/gi);
            if (wordMatches) {
              for (const w of wordMatches) {
                if (w === 'transparent') continue;
                if (lightNamed.includes(w)) luminances.push(240);
                else if (darkNamed.includes(w)) luminances.push(20);
              }
            }
            if (luminances.length > 0) {
              const avg = luminances.reduce((acc, v) => acc + v, 0) / luminances.length;
              return avg > 140;
            }
            if (/\\btransparent\\b/.test(s)) return false;
          }
          return null;
        }

        const slideBg = slide.frontmatter?.background || (data.config && data.config.background);
        const isLightBg = isLightColor(slideBg);
        const curTheme = data.config?.theme || "default";
        if (slideBg) {
          if (/^(http|\\/|data:|assets\\/)/.test(slideBg)) {
            container.style.backgroundImage = 'url("' + slideBg + '")';
            container.style.backgroundSize = "cover";
            container.style.backgroundPosition = "center";
          } else {
            container.style.backgroundImage = "none";
            container.style.background = slideBg;
          }
        } else {
          container.style.backgroundImage = "none";
          container.style.background = "";
        }
        if (isLightBg === true) {
          if (viewport) viewport.setAttribute("data-theme", "light");
          const textColor = curTheme === "apple-basic" ? "#000000" : (curTheme === "seriph" ? "#231f1d" : "#0f172a");
          container.style.color = textColor;
          container.style.setProperty("--slide-text", textColor);
        } else if (isLightBg === false) {
          if (viewport) viewport.setAttribute("data-theme", "dark");
          const textColor = curTheme === "apple-basic" ? "#ffffff" : (curTheme === "seriph" ? "#f5f2eb" : "#f1f5f9");
          container.style.color = textColor;
          container.style.setProperty("--slide-text", textColor);
        } else {
          const fallbackSchema = (data.config?.colorSchema === "light" || data.config?.colorSchema === "dark")
            ? data.config.colorSchema
            : (data.config?.hostThemeMode || null);
          if (viewport) {
            if (fallbackSchema === "light" || fallbackSchema === "dark") {
              viewport.setAttribute("data-theme", fallbackSchema);
            } else {
              viewport.removeAttribute("data-theme");
            }
          }
          container.style.color = "";
          container.style.removeProperty("--slide-text");
        }

        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        const isClock = maskDir === "clockwise" || maskDir === "counter-clockwise" || maskDir === "cw" || maskDir === "ccw";
        if (maskDir === "down" || maskDir === "right" || isClock) {
          const isClover = slide.frontmatter?.layout === "clover";
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio, (isClock || isClover) ? 4 : 2);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: isClock ? ((maskDir === "cw" || maskDir === "clockwise") ? "clockwise" : "counter-clockwise") : maskDir,
            isClock: isClock,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          // FSM-9 优化：后退进入历史页时，遮罩与逐步呈现处于全部揭开完成状态，避免上一页重新变为全黑遮盖
          currentMaskStep = (direction === "backward") ? currentMaskConfig.totalSteps : 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slides-mask-layer slides-mask-layer--" + currentMaskConfig.style + " slides-mask-layer--" + currentMaskConfig.direction + (currentMaskConfig.isClock ? " slides-mask-layer--clock" : "");
          const overlay = document.createElement("div");
          overlay.className = "slides-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slides-mask-divider-line" + (currentMaskConfig.isClock ? " slides-mask-divider-line--clock" : "");
          divider.style.opacity = "0";
          if (currentMaskConfig.isClock) {
            const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
            divider.style.transform = isCw ? "translateY(-50%) rotate(-180deg)" : "translateY(-50%) rotate(-90deg)";
          }
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slides-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slides-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slides-mask-body-container slides-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slides-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slides-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slides-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function Vm(){return`      let lightboxScale = 1.0;
      let lightboxTranslateX = 0;
      let lightboxTranslateY = 0;
      let isLightboxDragging = false;
      let lightboxDragStartX = 0;
      let lightboxDragStartY = 0;
      let lightboxInitialTx = 0;
      let lightboxInitialTy = 0;
      let lightboxHasMoved = false;
      let lightboxMediaType = "";

      function updateLightboxImgTransform(animate) {
        if (!lightboxContent) return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        img.style.transformOrigin = "center center";
        img.style.transform = "translate(" + lightboxTranslateX + "px, " + lightboxTranslateY + "px) scale(" + lightboxScale + ")";
        img.style.transition = animate ? "transform 0.12s cubic-bezier(0.16, 1, 0.3, 1)" : "none";
        img.style.cursor = lightboxScale > 1.0 ? (isLightboxDragging ? "grabbing" : "grab") : "zoom-in";
      }

      function resetLightboxZoom() {
        lightboxScale = 1.0;
        lightboxTranslateX = 0;
        lightboxTranslateY = 0;
        isLightboxDragging = false;
        lightboxHasMoved = false;
        updateLightboxImgTransform(false);
      }

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        lightboxMediaType = type;
        resetLightboxZoom();
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slides-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slides-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
          updateLightboxImgTransform(false);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
        lightboxMediaType = "";
        resetLightboxZoom();
      }

      function handleLightboxWheel(e) {
        if (!lightboxContent || lightboxMediaType !== "image") return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        e.preventDefault();
        e.stopPropagation();
        if (Math.abs(e.deltaY) < 1) return;

        const factor = e.deltaY < 0 ? 1.2 : 1 / 1.2;
        const currentScale = lightboxScale;
        let nextScale = currentScale * factor;

        if (nextScale <= 1.02) {
          resetLightboxZoom();
          return;
        }
        if (nextScale > 5.0) {
          nextScale = 5.0;
        }

        const rect = img.getBoundingClientRect();
        const currentCenterX = rect.left + rect.width / 2;
        const currentCenterY = rect.top + rect.height / 2;
        const origCenterX = currentCenterX - lightboxTranslateX;
        const origCenterY = currentCenterY - lightboxTranslateY;

        const nextTx = (e.clientX - origCenterX) * (1 - nextScale / currentScale) + lightboxTranslateX * (nextScale / currentScale);
        const nextTy = (e.clientY - origCenterY) * (1 - nextScale / currentScale) + lightboxTranslateY * (nextScale / currentScale);

        lightboxTranslateX = Math.round(nextTx * 10) / 10;
        lightboxTranslateY = Math.round(nextTy * 10) / 10;
        lightboxScale = Math.round(nextScale * 1000) / 1000;
        updateLightboxImgTransform(true);
      }

      if (lightboxContent) {
        lightboxContent.addEventListener("pointerdown", (e) => {
          if (e.button !== 0 || lightboxMediaType !== "image" || lightboxScale <= 1.0) return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          isLightboxDragging = true;
          lightboxDragStartX = e.clientX;
          lightboxDragStartY = e.clientY;
          lightboxInitialTx = lightboxTranslateX;
          lightboxInitialTy = lightboxTranslateY;
          lightboxHasMoved = false;
          if (img.setPointerCapture) {
            try { img.setPointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        });

        window.addEventListener("pointermove", (e) => {
          if (!isLightboxDragging || lightboxMediaType !== "image") return;
          e.preventDefault();
          e.stopPropagation();
          const dx = e.clientX - lightboxDragStartX;
          const dy = e.clientY - lightboxDragStartY;
          if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
            lightboxHasMoved = true;
          }
          lightboxTranslateX = Math.round((lightboxInitialTx + dx) * 10) / 10;
          lightboxTranslateY = Math.round((lightboxInitialTy + dy) * 10) / 10;
          updateLightboxImgTransform(false);
        });

        const onLightboxPointerEnd = (e) => {
          if (!isLightboxDragging) return;
          isLightboxDragging = false;
          const img = lightboxContent ? lightboxContent.querySelector(".slides-lightbox-img") : null;
          if (img && img.releasePointerCapture) {
            try { img.releasePointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        };
        window.addEventListener("pointerup", onLightboxPointerEnd);
        window.addEventListener("pointercancel", onLightboxPointerEnd);

        lightboxContent.addEventListener("dblclick", (e) => {
          if (lightboxMediaType !== "image") return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          if (lightboxScale > 1.05 || lightboxTranslateX !== 0 || lightboxTranslateY !== 0) {
            resetLightboxZoom();
          } else {
            const targetScale = 2.0;
            const rect = img.getBoundingClientRect();
            const currentCenterX = rect.left + rect.width / 2;
            const currentCenterY = rect.top + rect.height / 2;
            const origCenterX = currentCenterX - lightboxTranslateX;
            const origCenterY = currentCenterY - lightboxTranslateY;
            lightboxTranslateX = Math.round(((e.clientX - origCenterX) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxTranslateY = Math.round(((e.clientY - origCenterY) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxScale = targetScale;
            updateLightboxImgTransform(true);
          }
        });
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            if (lightboxHasMoved) {
              lightboxHasMoved = false;
              return;
            }
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function qm(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function Gm(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slides-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slides-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slides-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background || (data.config && data.config.background);
          if (bg) {
            if (/^(http|/|data:|assets/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slides-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slides-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slides-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slides-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slides-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function Km(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slides-viewport") || cur.classList.contains("slides-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) {
          if (typeof handleLightboxWheel === "function") {
            handleLightboxWheel(e);
          }
          return;
        }
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          if (typeof lightboxHasMoved !== "undefined" && lightboxHasMoved) {
            lightboxHasMoved = false;
            e.stopPropagation();
            return;
          }
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slides-lightbox-img, .slides-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const hasPendingMask = currentMaskConfig && (currentMaskStep < currentMaskConfig.totalSteps);
        if (hasPendingMask) {
          const isBottomControls = targetEl.closest(".controls-bar, .controls, .slides-toc");
          if (isBottomControls) return;
          e.preventDefault();
          e.stopPropagation();
          goNext();
          return;
        }

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slides-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function Ym(){return[Hm(),Fm(),jm(),Wm(),Um(),Vm(),qm(),Gm(),Km()].join("")}function Ka(e,t){const o=(t==null?void 0:t.title)||"即现演示文稿";let i=e.slides;if(t!=null&&t.inlineAssetBase64Map&&Object.keys(t.inlineAssetBase64Map).length>0){const r=t.inlineAssetBase64Map;i=e.slides.map(a=>{let c=a.rawMarkdown;for(const[y,d]of Object.entries(r))c.includes(y)&&(c=c.split(y).join(d));const u=a.blocks.map(y=>{let d=y.rawMarkdown;for(const[h,m]of Object.entries(r))d.includes(h)&&(d=d.split(h).join(m));return{...y,rawMarkdown:d}});let p=a.frontmatter?{...a.frontmatter}:a.frontmatter;if(p){if(typeof p.background=="string")for(const[y,d]of Object.entries(r))p.background.includes(y)&&(p.background=p.background.split(y).join(d));if(typeof p.image=="string")for(const[y,d]of Object.entries(r))p.image.includes(y)&&(p.image=p.image.split(y).join(d))}return{...a,rawMarkdown:c,blocks:u,frontmatter:p}})}const n=fr(e.config.colorSchema),s=JSON.stringify(i),l=JSON.stringify({...e.config,hostThemeMode:e.config.hostThemeMode||n});return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${st(o)}</title>
  <style>
${zm(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDES_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${s},
      config: ${l}
    };
  <\/script>
</head>
<body>
  <div id="app" data-theme="${n}" data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
    <div class="slide-viewport slides-theme-${e.config.theme||"apple-basic"}" id="viewport" data-theme="${n}" data-slides-theme="${e.config.theme||"apple-basic"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slides-lightbox" class="slides-lightbox">
      <button class="slides-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slides-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${Ym()}
  <\/script>
</body>
</html>`}function Ya(e,t){if(typeof document>"u")return!1;const o=new Blob([t],{type:"text/html;charset=utf-8"}),i=URL.createObjectURL(o),n=document.createElement("a");return n.href=i,n.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(i),!0}function Zm(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function Jm(e){const t=Zm(e==null?void 0:e.pageRatio);return`
    ${Hi(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slides-padding-y, 36px) var(--slides-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
      container-type: size;
    }
    .pdf-slide-page.spacing-compact {
      --slides-padding-y: 16px;
      --slides-padding-x: 28px;
      --slides-block-gap: 8px;
      --slides-list-gap: 4px;
      --slides-cols-gap: 20px;
      --slides-title-margin-bottom: 8px;
      --slides-header-gap: 10px;
      --slides-line-height: 1.45;
    }
    .pdf-slide-page.spacing-normal {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-block-gap: 14px;
      --slides-list-gap: 6px;
      --slides-cols-gap: 32px;
      --slides-title-margin-bottom: 12px;
      --slides-header-gap: 16px;
      --slides-line-height: 1.6;
    }
    .pdf-slide-page.spacing-loose {
      --slides-padding-y: 52px;
      --slides-padding-x: 72px;
      --slides-block-gap: 22px;
      --slides-list-gap: 10px;
      --slides-cols-gap: 44px;
      --slides-title-margin-bottom: 18px;
      --slides-header-gap: 24px;
      --slides-line-height: 1.75;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }

    /* 1. 默认科技主题 Default (Modern Tech) */
    .pdf-slide-page.slides-theme-tech {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
    }
    .pdf-slide-page.slides-theme-tech.theme-light {
      background: #f8fafc;
      color: #0f172a;
    }
    .pdf-slide-page.slides-theme-tech.theme-dark {
      background: #090d16;
      color: #f1f5f9;
    }
    .slides-theme-tech .pdf-block h1 { color: #059669; }
    .theme-dark.slides-theme-tech .pdf-block h1 { color: #10b981; }
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #059669;
      border-left: 4px solid #059669;
      padding: 4px 14px;
      padding-left: 14px;
      background: linear-gradient(90deg, rgba(5, 150, 105, 0.13), transparent 76%);
      border-radius: 0 6px 6px 0;
      letter-spacing: -0.015em;
    }
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #10b981;
      border-left-color: #10b981;
      background: linear-gradient(90deg, rgba(16, 185, 129, 0.14), transparent 76%);
    }

    /* 2. 优雅衬线主题 Seriph (Editorial Academic) */
    .pdf-slide-page.slides-theme-seriph {
      font-family: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      letter-spacing: 0.015em;
    }
    .pdf-slide-page.slides-theme-seriph.theme-light {
      background: #fcfbf7;
      color: #231f1d;
    }
    .pdf-slide-page.slides-theme-seriph.theme-dark {
      background: #171513;
      color: #f5f2eb;
    }
    .slides-theme-seriph .pdf-block h1 { color: #b45309; }
    .theme-dark.slides-theme-seriph .pdf-block h1 { color: #f59e0b; }
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      display: block;
      position: relative;
      color: #b45309;
      border-bottom: 1.5px solid rgba(180, 83, 9, 0.45);
      padding-bottom: 10px;
      margin-bottom: 14px;
    }
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3::after {
      content: "";
      position: absolute;
      left: 0;
      right: 0;
      bottom: 3px;
      height: 1.5px;
      pointer-events: none;
      background: linear-gradient(90deg, #b45309 0%, rgba(180, 83, 9, 0.35) 50%, transparent 92%);
    }
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #f59e0b;
      border-bottom-color: rgba(245, 158, 11, 0.45);
    }
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3::after {
      background: linear-gradient(90deg, #f59e0b 0%, rgba(245, 158, 11, 0.35) 50%, transparent 92%);
    }

    /* 3. 极简发布会主题 Apple Basic (Swiss Minimal) */
    .pdf-slide-page.slides-theme-apple-basic {
      font-family: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      letter-spacing: -0.025em;
    }
    .pdf-slide-page.slides-theme-apple-basic.theme-light {
      background: #ffffff;
      color: #000000;
    }
    .pdf-slide-page.slides-theme-apple-basic.theme-dark {
      background: #000000;
      color: #ffffff;
    }
    .slides-theme-apple-basic .pdf-block h1 {
      color: #000000;
      font-weight: 800;
      letter-spacing: -0.035em;
    }
    .theme-dark.slides-theme-apple-basic .pdf-block h1 {
      color: #ffffff;
      font-weight: 800;
      letter-spacing: -0.035em;
    }
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      border: none !important;
      background: none !important;
      padding: 0 !important;
      margin-bottom: 16px !important;
      letter-spacing: -0.04em !important;
      font-weight: 800 !important;
    }
    /* 页面存在背景图时，内容页顶部标题回退高对比文字与局部衬底，保留用户块级前景色 */
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #0f172a;
      text-shadow: 0 1px 3px rgba(255, 255, 255, 0.85);
    }
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3 {
      color: #f8fafc;
      text-shadow: 0 1px 3px rgba(0, 0, 0, 0.75);
    }
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3 {
      background: linear-gradient(90deg, rgba(255, 255, 255, 0.55), transparent 82%);
    }
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3 {
      background: linear-gradient(90deg, rgba(15, 23, 42, 0.42), transparent 82%);
    }
    .pdf-slide-page .pdf-block[style^="color:"] h1,
    .pdf-slide-page .pdf-block[style*=" color:"] h1,
    .pdf-slide-page .pdf-block[style*=";color:"] h1,
    .pdf-slide-page .pdf-block[style^="color:"] h2,
    .pdf-slide-page .pdf-block[style*=" color:"] h2,
    .pdf-slide-page .pdf-block[style*=";color:"] h2,
    .pdf-slide-page .pdf-block[style^="color:"] h3,
    .pdf-slide-page .pdf-block[style*=" color:"] h3,
    .pdf-slide-page .pdf-block[style*=";color:"] h3 {
      color: inherit !important;
    }
    .slides-theme-apple-basic .pdf-code,
    .slides-theme-apple-basic pre {
      border-radius: 14px !important;
      border-left: none !important;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: var(--slides-cols-gap, 32px);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.75);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.625);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: var(--slides-block-gap, 14px);
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: calc(var(--slides-block-gap, 14px) * 0.6) 0;
      display: flex;
      flex-direction: column;
      gap: var(--slides-list-gap, 6px);
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: var(--slides-line-height, 1.6);
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: var(--slides-list-gap, 6px) !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: var(--slides-line-height, 1.6) !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slides-ref-tag, .theme-dark a.slides-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slides-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slides-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slides-motion-fade-in,
      .slides-motion-slide-up,
      .slides-motion-slide-down,
      .slides-motion-slide-left,
      .slides-motion-slide-right,
      .slides-motion-zoom-in,
      .slides-motion-pop,
      .slides-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slides-mask-layer,
      .slides-mask-overlay,
      .slides-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
        mask: none !important;
        -webkit-mask: none !important;
      }
      .slides-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function Xm(e,t){const o="即现演示讲义",i="16:9",n=fr(e.config.colorSchema),s=e.config.theme||"apple-basic",l=e.slides.map((r,a)=>{const c=r.frontmatter.layout||"default",u=r.frontmatter.spacing,p=u&&u!=="inherit"?u:e.config.spacing||"normal",y=Ga(r),d=`${a+1} / ${e.slides.length}`,h=r.frontmatter.background||e.config.background,m=Ha(h),g=m===!0?"light":m===!1?"dark":n,b=h&&!/^(http|\/|data:|assets\/)/.test(h)?`background: ${st(h)};`:"";return`
      <section class="pdf-slide-page layout-${c} theme-${g} spacing-${p} slides-theme-${s}" data-slides-theme="${s}" style="${b}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${st(o)}</span>
          ${`<span class="pdf-page-badge">P. ${d}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${y}
        </div>
        ${r.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${st(r.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${st(o)} - 高保真讲义</title>
  <style>
    ${Jm({pageRatio:i,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
  ${l}
</body>
</html>`}function Za(e,t){var n;if(typeof window>"u"||typeof document>"u")return!1;const o=Xm(e,t);try{const s=document.createElement("iframe");s.style.position="fixed",s.style.right="0",s.style.bottom="0",s.style.width="0",s.style.height="0",s.style.border="none",s.style.visibility="hidden",document.body.appendChild(s);const l=(n=s.contentWindow)==null?void 0:n.document;if(l)return l.open(),l.write(o),l.close(),setTimeout(()=>{var r,a;try{(r=s.contentWindow)==null||r.focus(),(a=s.contentWindow)==null||a.print()}finally{setTimeout(()=>{s.remove()},2e3)}},350),!0}catch(s){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",s)}const i=window.open("","_blank");return i?(i.document.write(o),i.document.close(),i.focus(),setTimeout(()=>{i.print(),i.close()},350),!0):!1}var cn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function Qm(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function dn(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var fs={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var hl;function eg(){return hl||(hl=1,(function(e,t){(function(o){e.exports=o()})(function(){return(function o(i,n,s){function l(c,u){if(!n[c]){if(!i[c]){var p=typeof dn=="function"&&dn;if(!u&&p)return p(c,!0);if(r)return r(c,!0);var y=new Error("Cannot find module '"+c+"'");throw y.code="MODULE_NOT_FOUND",y}var d=n[c]={exports:{}};i[c][0].call(d.exports,function(h){var m=i[c][1][h];return l(m||h)},d,d.exports,o,i,n,s)}return n[c].exports}for(var r=typeof dn=="function"&&dn,a=0;a<s.length;a++)l(s[a]);return l})({1:[function(o,i,n){var s=o("./utils"),l=o("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";n.encode=function(a){for(var c,u,p,y,d,h,m,g=[],b=0,k=a.length,w=k,C=s.getTypeOf(a)!=="string";b<a.length;)w=k-b,p=C?(c=a[b++],u=b<k?a[b++]:0,b<k?a[b++]:0):(c=a.charCodeAt(b++),u=b<k?a.charCodeAt(b++):0,b<k?a.charCodeAt(b++):0),y=c>>2,d=(3&c)<<4|u>>4,h=1<w?(15&u)<<2|p>>6:64,m=2<w?63&p:64,g.push(r.charAt(y)+r.charAt(d)+r.charAt(h)+r.charAt(m));return g.join("")},n.decode=function(a){var c,u,p,y,d,h,m=0,g=0,b="data:";if(a.substr(0,b.length)===b)throw new Error("Invalid base64 input, it looks like a data url.");var k,w=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&w--,a.charAt(a.length-2)===r.charAt(64)&&w--,w%1!=0)throw new Error("Invalid base64 input, bad content length.");for(k=l.uint8array?new Uint8Array(0|w):new Array(0|w);m<a.length;)c=r.indexOf(a.charAt(m++))<<2|(y=r.indexOf(a.charAt(m++)))>>4,u=(15&y)<<4|(d=r.indexOf(a.charAt(m++)))>>2,p=(3&d)<<6|(h=r.indexOf(a.charAt(m++))),k[g++]=c,d!==64&&(k[g++]=u),h!==64&&(k[g++]=p);return k}},{"./support":30,"./utils":32}],2:[function(o,i,n){var s=o("./external"),l=o("./stream/DataWorker"),r=o("./stream/Crc32Probe"),a=o("./stream/DataLengthProbe");function c(u,p,y,d,h){this.compressedSize=u,this.uncompressedSize=p,this.crc32=y,this.compression=d,this.compressedContent=h}c.prototype={getContentWorker:function(){var u=new l(s.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),p=this;return u.on("end",function(){if(this.streamInfo.data_length!==p.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),u},getCompressedWorker:function(){return new l(s.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(u,p,y){return u.pipe(new r).pipe(new a("uncompressedSize")).pipe(p.compressWorker(y)).pipe(new a("compressedSize")).withStreamInfo("compression",p)},i.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(o,i,n){var s=o("./stream/GenericWorker");n.STORE={magic:"\0\0",compressWorker:function(){return new s("STORE compression")},uncompressWorker:function(){return new s("STORE decompression")}},n.DEFLATE=o("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(o,i,n){var s=o("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var u=0;u<8;u++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();i.exports=function(r,a){return r!==void 0&&r.length?s.getTypeOf(r)!=="string"?(function(c,u,p,y){var d=l,h=y+p;c^=-1;for(var m=y;m<h;m++)c=c>>>8^d[255&(c^u[m])];return-1^c})(0|a,r,r.length,0):(function(c,u,p,y){var d=l,h=y+p;c^=-1;for(var m=y;m<h;m++)c=c>>>8^d[255&(c^u.charCodeAt(m))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(o,i,n){n.base64=!1,n.binary=!1,n.dir=!1,n.createFolders=!0,n.date=null,n.compression=null,n.compressionOptions=null,n.comment=null,n.unixPermissions=null,n.dosPermissions=null},{}],6:[function(o,i,n){var s=null;s=typeof Promise<"u"?Promise:o("lie"),i.exports={Promise:s}},{lie:37}],7:[function(o,i,n){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=o("pako"),r=o("./utils"),a=o("./stream/GenericWorker"),c=s?"uint8array":"array";function u(p,y){a.call(this,"FlateWorker/"+p),this._pako=null,this._pakoAction=p,this._pakoOptions=y,this.meta={}}n.magic="\b\0",r.inherits(u,a),u.prototype.processChunk=function(p){this.meta=p.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,p.data),!1)},u.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},u.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},u.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var p=this;this._pako.onData=function(y){p.push({data:y,meta:p.meta})}},n.compressWorker=function(p){return new u("Deflate",p)},n.uncompressWorker=function(){return new u("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(o,i,n){function s(d,h){var m,g="";for(m=0;m<h;m++)g+=String.fromCharCode(255&d),d>>>=8;return g}function l(d,h,m,g,b,k){var w,C,A=d.file,M=d.compression,I=k!==c.utf8encode,N=r.transformTo("string",k(A.name)),D=r.transformTo("string",c.utf8encode(A.name)),U=A.comment,W=r.transformTo("string",k(U)),E=r.transformTo("string",c.utf8encode(U)),P=D.length!==A.name.length,x=E.length!==U.length,K="",j="",$="",T=A.dir,O=A.date,te={crc32:0,compressedSize:0,uncompressedSize:0};h&&!m||(te.crc32=d.crc32,te.compressedSize=d.compressedSize,te.uncompressedSize=d.uncompressedSize);var Y=0;h&&(Y|=8),I||!P&&!x||(Y|=2048);var Z=0,ce=0;T&&(Z|=16),b==="UNIX"?(ce=798,Z|=(function(ne,Ce){var _e=ne;return ne||(_e=Ce?16893:33204),(65535&_e)<<16})(A.unixPermissions,T)):(ce=20,Z|=(function(ne){return 63&(ne||0)})(A.dosPermissions)),w=O.getUTCHours(),w<<=6,w|=O.getUTCMinutes(),w<<=5,w|=O.getUTCSeconds()/2,C=O.getUTCFullYear()-1980,C<<=4,C|=O.getUTCMonth()+1,C<<=5,C|=O.getUTCDate(),P&&(j=s(1,1)+s(u(N),4)+D,K+="up"+s(j.length,2)+j),x&&($=s(1,1)+s(u(W),4)+E,K+="uc"+s($.length,2)+$);var oe="";return oe+=`
\0`,oe+=s(Y,2),oe+=M.magic,oe+=s(w,2),oe+=s(C,2),oe+=s(te.crc32,4),oe+=s(te.compressedSize,4),oe+=s(te.uncompressedSize,4),oe+=s(N.length,2),oe+=s(K.length,2),{fileRecord:p.LOCAL_FILE_HEADER+oe+N+K,dirRecord:p.CENTRAL_FILE_HEADER+s(ce,2)+oe+s(W.length,2)+"\0\0\0\0"+s(Z,4)+s(g,4)+N+K+W}}var r=o("../utils"),a=o("../stream/GenericWorker"),c=o("../utf8"),u=o("../crc32"),p=o("../signature");function y(d,h,m,g){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=h,this.zipPlatform=m,this.encodeFileName=g,this.streamFiles=d,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(y,a),y.prototype.push=function(d){var h=d.meta.percent||0,m=this.entriesCount,g=this._sources.length;this.accumulate?this.contentBuffer.push(d):(this.bytesWritten+=d.data.length,a.prototype.push.call(this,{data:d.data,meta:{currentFile:this.currentFile,percent:m?(h+100*(m-g-1))/m:100}}))},y.prototype.openedSource=function(d){this.currentSourceOffset=this.bytesWritten,this.currentFile=d.file.name;var h=this.streamFiles&&!d.file.dir;if(h){var m=l(d,h,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:m.fileRecord,meta:{percent:0}})}else this.accumulate=!0},y.prototype.closedSource=function(d){this.accumulate=!1;var h=this.streamFiles&&!d.file.dir,m=l(d,h,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(m.dirRecord),h)this.push({data:(function(g){return p.DATA_DESCRIPTOR+s(g.crc32,4)+s(g.compressedSize,4)+s(g.uncompressedSize,4)})(d),meta:{percent:100}});else for(this.push({data:m.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},y.prototype.flush=function(){for(var d=this.bytesWritten,h=0;h<this.dirRecords.length;h++)this.push({data:this.dirRecords[h],meta:{percent:100}});var m=this.bytesWritten-d,g=(function(b,k,w,C,A){var M=r.transformTo("string",A(C));return p.CENTRAL_DIRECTORY_END+"\0\0\0\0"+s(b,2)+s(b,2)+s(k,4)+s(w,4)+s(M.length,2)+M})(this.dirRecords.length,m,d,this.zipComment,this.encodeFileName);this.push({data:g,meta:{percent:100}})},y.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},y.prototype.registerPrevious=function(d){this._sources.push(d);var h=this;return d.on("data",function(m){h.processChunk(m)}),d.on("end",function(){h.closedSource(h.previous.streamInfo),h._sources.length?h.prepareNextSource():h.end()}),d.on("error",function(m){h.error(m)}),this},y.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},y.prototype.error=function(d){var h=this._sources;if(!a.prototype.error.call(this,d))return!1;for(var m=0;m<h.length;m++)try{h[m].error(d)}catch{}return!0},y.prototype.lock=function(){a.prototype.lock.call(this);for(var d=this._sources,h=0;h<d.length;h++)d[h].lock()},i.exports=y},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(o,i,n){var s=o("../compressions"),l=o("./ZipFileWorker");n.generateWorker=function(r,a,c){var u=new l(a.streamFiles,c,a.platform,a.encodeFileName),p=0;try{r.forEach(function(y,d){p++;var h=(function(k,w){var C=k||w,A=s[C];if(!A)throw new Error(C+" is not a valid compression method !");return A})(d.options.compression,a.compression),m=d.options.compressionOptions||a.compressionOptions||{},g=d.dir,b=d.date;d._compressWorker(h,m).withStreamInfo("file",{name:y,dir:g,date:b,comment:d.comment||"",unixPermissions:d.unixPermissions,dosPermissions:d.dosPermissions}).pipe(u)}),u.entriesCount=p}catch(y){u.error(y)}return u}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(o,i,n){function s(){if(!(this instanceof s))return new s;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new s;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(s.prototype=o("./object")).loadAsync=o("./load"),s.support=o("./support"),s.defaults=o("./defaults"),s.version="3.10.1",s.loadAsync=function(l,r){return new s().loadAsync(l,r)},s.external=o("./external"),i.exports=s},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(o,i,n){var s=o("./utils"),l=o("./external"),r=o("./utf8"),a=o("./zipEntries"),c=o("./stream/Crc32Probe"),u=o("./nodejsUtils");function p(y){return new l.Promise(function(d,h){var m=y.decompressed.getContentWorker().pipe(new c);m.on("error",function(g){h(g)}).on("end",function(){m.streamInfo.crc32!==y.decompressed.crc32?h(new Error("Corrupted zip : CRC32 mismatch")):d()}).resume()})}i.exports=function(y,d){var h=this;return d=s.extend(d||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),u.isNode&&u.isStream(y)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):s.prepareContent("the loaded zip file",y,!0,d.optimizedBinaryString,d.base64).then(function(m){var g=new a(d);return g.load(m),g}).then(function(m){var g=[l.Promise.resolve(m)],b=m.files;if(d.checkCRC32)for(var k=0;k<b.length;k++)g.push(p(b[k]));return l.Promise.all(g)}).then(function(m){for(var g=m.shift(),b=g.files,k=0;k<b.length;k++){var w=b[k],C=w.fileNameStr,A=s.resolve(w.fileNameStr);h.file(A,w.decompressed,{binary:!0,optimizedBinaryString:!0,date:w.date,dir:w.dir,comment:w.fileCommentStr.length?w.fileCommentStr:null,unixPermissions:w.unixPermissions,dosPermissions:w.dosPermissions,createFolders:d.createFolders}),w.dir||(h.file(A).unsafeOriginalName=C)}return g.zipComment.length&&(h.comment=g.zipComment),h})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(o,i,n){var s=o("../utils"),l=o("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}s.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(u){c.push({data:u,meta:{percent:0}})}).on("error",function(u){c.isPaused?this.generatedError=u:c.error(u)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},i.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(o,i,n){var s=o("readable-stream").Readable;function l(r,a,c){s.call(this,a),this._helper=r;var u=this;r.on("data",function(p,y){u.push(p)||u._helper.pause(),c&&c(y)}).on("error",function(p){u.emit("error",p)}).on("end",function(){u.push(null)})}o("../utils").inherits(l,s),l.prototype._read=function(){this._helper.resume()},i.exports=l},{"../utils":32,"readable-stream":16}],14:[function(o,i,n){i.exports={isNode:typeof Buffer<"u",newBufferFrom:function(s,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(s,l);if(typeof s=="number")throw new Error('The "data" argument must not be a number');return new Buffer(s,l)},allocBuffer:function(s){if(Buffer.alloc)return Buffer.alloc(s);var l=new Buffer(s);return l.fill(0),l},isBuffer:function(s){return Buffer.isBuffer(s)},isStream:function(s){return s&&typeof s.on=="function"&&typeof s.pause=="function"&&typeof s.resume=="function"}}},{}],15:[function(o,i,n){function s(A,M,I){var N,D=r.getTypeOf(M),U=r.extend(I||{},u);U.date=U.date||new Date,U.compression!==null&&(U.compression=U.compression.toUpperCase()),typeof U.unixPermissions=="string"&&(U.unixPermissions=parseInt(U.unixPermissions,8)),U.unixPermissions&&16384&U.unixPermissions&&(U.dir=!0),U.dosPermissions&&16&U.dosPermissions&&(U.dir=!0),U.dir&&(A=b(A)),U.createFolders&&(N=g(A))&&k.call(this,N,!0);var W=D==="string"&&U.binary===!1&&U.base64===!1;I&&I.binary!==void 0||(U.binary=!W),(M instanceof p&&M.uncompressedSize===0||U.dir||!M||M.length===0)&&(U.base64=!1,U.binary=!0,M="",U.compression="STORE",D="string");var E=null;E=M instanceof p||M instanceof a?M:h.isNode&&h.isStream(M)?new m(A,M):r.prepareContent(A,M,U.binary,U.optimizedBinaryString,U.base64);var P=new y(A,E,U);this.files[A]=P}var l=o("./utf8"),r=o("./utils"),a=o("./stream/GenericWorker"),c=o("./stream/StreamHelper"),u=o("./defaults"),p=o("./compressedObject"),y=o("./zipObject"),d=o("./generate"),h=o("./nodejsUtils"),m=o("./nodejs/NodejsStreamInputAdapter"),g=function(A){A.slice(-1)==="/"&&(A=A.substring(0,A.length-1));var M=A.lastIndexOf("/");return 0<M?A.substring(0,M):""},b=function(A){return A.slice(-1)!=="/"&&(A+="/"),A},k=function(A,M){return M=M!==void 0?M:u.createFolders,A=b(A),this.files[A]||s.call(this,A,null,{dir:!0,createFolders:M}),this.files[A]};function w(A){return Object.prototype.toString.call(A)==="[object RegExp]"}var C={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(A){var M,I,N;for(M in this.files)N=this.files[M],(I=M.slice(this.root.length,M.length))&&M.slice(0,this.root.length)===this.root&&A(I,N)},filter:function(A){var M=[];return this.forEach(function(I,N){A(I,N)&&M.push(N)}),M},file:function(A,M,I){if(arguments.length!==1)return A=this.root+A,s.call(this,A,M,I),this;if(w(A)){var N=A;return this.filter(function(U,W){return!W.dir&&N.test(U)})}var D=this.files[this.root+A];return D&&!D.dir?D:null},folder:function(A){if(!A)return this;if(w(A))return this.filter(function(D,U){return U.dir&&A.test(D)});var M=this.root+A,I=k.call(this,M),N=this.clone();return N.root=I.name,N},remove:function(A){A=this.root+A;var M=this.files[A];if(M||(A.slice(-1)!=="/"&&(A+="/"),M=this.files[A]),M&&!M.dir)delete this.files[A];else for(var I=this.filter(function(D,U){return U.name.slice(0,A.length)===A}),N=0;N<I.length;N++)delete this.files[I[N].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(A){var M,I={};try{if((I=r.extend(A||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=I.type.toLowerCase(),I.compression=I.compression.toUpperCase(),I.type==="binarystring"&&(I.type="string"),!I.type)throw new Error("No output type specified.");r.checkSupport(I.type),I.platform!=="darwin"&&I.platform!=="freebsd"&&I.platform!=="linux"&&I.platform!=="sunos"||(I.platform="UNIX"),I.platform==="win32"&&(I.platform="DOS");var N=I.comment||this.comment||"";M=d.generateWorker(this,I,N)}catch(D){(M=new a("error")).error(D)}return new c(M,I.type||"string",I.mimeType)},generateAsync:function(A,M){return this.generateInternalStream(A).accumulate(M)},generateNodeStream:function(A,M){return(A=A||{}).type||(A.type="nodebuffer"),this.generateInternalStream(A).toNodejsStream(M)}};i.exports=C},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(o,i,n){i.exports=o("stream")},{stream:void 0}],17:[function(o,i,n){var s=o("./DataReader");function l(r){s.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}o("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),p=r.charCodeAt(3),y=this.length-4;0<=y;--y)if(this.data[y]===a&&this.data[y+1]===c&&this.data[y+2]===u&&this.data[y+3]===p)return y-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),p=r.charCodeAt(3),y=this.readData(4);return a===y[0]&&c===y[1]&&u===y[2]&&p===y[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./DataReader":18}],18:[function(o,i,n){var s=o("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return s.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},i.exports=l},{"../utils":32}],19:[function(o,i,n){var s=o("./Uint8ArrayReader");function l(r){s.call(this,r)}o("../utils").inherits(l,s),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(o,i,n){var s=o("./DataReader");function l(r){s.call(this,r)}o("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./DataReader":18}],21:[function(o,i,n){var s=o("./ArrayReader");function l(r){s.call(this,r)}o("../utils").inherits(l,s),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(o,i,n){var s=o("../utils"),l=o("../support"),r=o("./ArrayReader"),a=o("./StringReader"),c=o("./NodeBufferReader"),u=o("./Uint8ArrayReader");i.exports=function(p){var y=s.getTypeOf(p);return s.checkSupport(y),y!=="string"||l.uint8array?y==="nodebuffer"?new c(p):l.uint8array?new u(s.transformTo("uint8array",p)):new r(s.transformTo("array",p)):new a(p)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(o,i,n){n.LOCAL_FILE_HEADER="PK",n.CENTRAL_FILE_HEADER="PK",n.CENTRAL_DIRECTORY_END="PK",n.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",n.ZIP64_CENTRAL_DIRECTORY_END="PK",n.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(o,i,n){var s=o("./GenericWorker"),l=o("../utils");function r(a){s.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,s),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},i.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(o,i,n){var s=o("./GenericWorker"),l=o("../crc32");function r(){s.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}o("../utils").inherits(r,s),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},i.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(o,i,n){var s=o("../utils"),l=o("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}s.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},i.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(o,i,n){var s=o("../utils"),l=o("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(u){c.dataIsReady=!0,c.data=u,c.max=u&&u.length||0,c.type=s.getTypeOf(u),c.isPaused||c._tickAndRepeat()},function(u){c.error(u)})}s.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,s.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(s.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},i.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(o,i,n){function s(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}s.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},i.exports=s},{}],29:[function(o,i,n){var s=o("../utils"),l=o("./ConvertWorker"),r=o("./GenericWorker"),a=o("../base64"),c=o("../support"),u=o("../external"),p=null;if(c.nodestream)try{p=o("../nodejs/NodejsStreamOutputAdapter")}catch{}function y(h,m){return new u.Promise(function(g,b){var k=[],w=h._internalType,C=h._outputType,A=h._mimeType;h.on("data",function(M,I){k.push(M),m&&m(I)}).on("error",function(M){k=[],b(M)}).on("end",function(){try{var M=(function(I,N,D){switch(I){case"blob":return s.newBlob(s.transformTo("arraybuffer",N),D);case"base64":return a.encode(N);default:return s.transformTo(I,N)}})(C,(function(I,N){var D,U=0,W=null,E=0;for(D=0;D<N.length;D++)E+=N[D].length;switch(I){case"string":return N.join("");case"array":return Array.prototype.concat.apply([],N);case"uint8array":for(W=new Uint8Array(E),D=0;D<N.length;D++)W.set(N[D],U),U+=N[D].length;return W;case"nodebuffer":return Buffer.concat(N);default:throw new Error("concat : unsupported type '"+I+"'")}})(w,k),A);g(M)}catch(I){b(I)}k=[]}).resume()})}function d(h,m,g){var b=m;switch(m){case"blob":case"arraybuffer":b="uint8array";break;case"base64":b="string"}try{this._internalType=b,this._outputType=m,this._mimeType=g,s.checkSupport(b),this._worker=h.pipe(new l(b)),h.lock()}catch(k){this._worker=new r("error"),this._worker.error(k)}}d.prototype={accumulate:function(h){return y(this,h)},on:function(h,m){var g=this;return h==="data"?this._worker.on(h,function(b){m.call(g,b.data,b.meta)}):this._worker.on(h,function(){s.delay(m,arguments,g)}),this},resume:function(){return s.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(h){if(s.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new p(this,{objectMode:this._outputType!=="nodebuffer"},h)}},i.exports=d},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(o,i,n){if(n.base64=!0,n.array=!0,n.string=!0,n.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",n.nodebuffer=typeof Buffer<"u",n.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")n.blob=!1;else{var s=new ArrayBuffer(0);try{n.blob=new Blob([s],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(s),n.blob=l.getBlob("application/zip").size===0}catch{n.blob=!1}}}try{n.nodestream=!!o("readable-stream").Readable}catch{n.nodestream=!1}},{"readable-stream":16}],31:[function(o,i,n){for(var s=o("./utils"),l=o("./support"),r=o("./nodejsUtils"),a=o("./stream/GenericWorker"),c=new Array(256),u=0;u<256;u++)c[u]=252<=u?6:248<=u?5:240<=u?4:224<=u?3:192<=u?2:1;c[254]=c[254]=1;function p(){a.call(this,"utf-8 decode"),this.leftOver=null}function y(){a.call(this,"utf-8 encode")}n.utf8encode=function(d){return l.nodebuffer?r.newBufferFrom(d,"utf-8"):(function(h){var m,g,b,k,w,C=h.length,A=0;for(k=0;k<C;k++)(64512&(g=h.charCodeAt(k)))==55296&&k+1<C&&(64512&(b=h.charCodeAt(k+1)))==56320&&(g=65536+(g-55296<<10)+(b-56320),k++),A+=g<128?1:g<2048?2:g<65536?3:4;for(m=l.uint8array?new Uint8Array(A):new Array(A),k=w=0;w<A;k++)(64512&(g=h.charCodeAt(k)))==55296&&k+1<C&&(64512&(b=h.charCodeAt(k+1)))==56320&&(g=65536+(g-55296<<10)+(b-56320),k++),g<128?m[w++]=g:(g<2048?m[w++]=192|g>>>6:(g<65536?m[w++]=224|g>>>12:(m[w++]=240|g>>>18,m[w++]=128|g>>>12&63),m[w++]=128|g>>>6&63),m[w++]=128|63&g);return m})(d)},n.utf8decode=function(d){return l.nodebuffer?s.transformTo("nodebuffer",d).toString("utf-8"):(function(h){var m,g,b,k,w=h.length,C=new Array(2*w);for(m=g=0;m<w;)if((b=h[m++])<128)C[g++]=b;else if(4<(k=c[b]))C[g++]=65533,m+=k-1;else{for(b&=k===2?31:k===3?15:7;1<k&&m<w;)b=b<<6|63&h[m++],k--;1<k?C[g++]=65533:b<65536?C[g++]=b:(b-=65536,C[g++]=55296|b>>10&1023,C[g++]=56320|1023&b)}return C.length!==g&&(C.subarray?C=C.subarray(0,g):C.length=g),s.applyFromCharCode(C)})(d=s.transformTo(l.uint8array?"uint8array":"array",d))},s.inherits(p,a),p.prototype.processChunk=function(d){var h=s.transformTo(l.uint8array?"uint8array":"array",d.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var m=h;(h=new Uint8Array(m.length+this.leftOver.length)).set(this.leftOver,0),h.set(m,this.leftOver.length)}else h=this.leftOver.concat(h);this.leftOver=null}var g=(function(k,w){var C;for((w=w||k.length)>k.length&&(w=k.length),C=w-1;0<=C&&(192&k[C])==128;)C--;return C<0||C===0?w:C+c[k[C]]>w?C:w})(h),b=h;g!==h.length&&(l.uint8array?(b=h.subarray(0,g),this.leftOver=h.subarray(g,h.length)):(b=h.slice(0,g),this.leftOver=h.slice(g,h.length))),this.push({data:n.utf8decode(b),meta:d.meta})},p.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:n.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},n.Utf8DecodeWorker=p,s.inherits(y,a),y.prototype.processChunk=function(d){this.push({data:n.utf8encode(d.data),meta:d.meta})},n.Utf8EncodeWorker=y},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(o,i,n){var s=o("./support"),l=o("./base64"),r=o("./nodejsUtils"),a=o("./external");function c(m){return m}function u(m,g){for(var b=0;b<m.length;++b)g[b]=255&m.charCodeAt(b);return g}o("setimmediate"),n.newBlob=function(m,g){n.checkSupport("blob");try{return new Blob([m],{type:g})}catch{try{var b=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return b.append(m),b.getBlob(g)}catch{throw new Error("Bug : can't construct the Blob.")}}};var p={stringifyByChunk:function(m,g,b){var k=[],w=0,C=m.length;if(C<=b)return String.fromCharCode.apply(null,m);for(;w<C;)g==="array"||g==="nodebuffer"?k.push(String.fromCharCode.apply(null,m.slice(w,Math.min(w+b,C)))):k.push(String.fromCharCode.apply(null,m.subarray(w,Math.min(w+b,C)))),w+=b;return k.join("")},stringifyByChar:function(m){for(var g="",b=0;b<m.length;b++)g+=String.fromCharCode(m[b]);return g},applyCanBeUsed:{uint8array:(function(){try{return s.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return s.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function y(m){var g=65536,b=n.getTypeOf(m),k=!0;if(b==="uint8array"?k=p.applyCanBeUsed.uint8array:b==="nodebuffer"&&(k=p.applyCanBeUsed.nodebuffer),k)for(;1<g;)try{return p.stringifyByChunk(m,b,g)}catch{g=Math.floor(g/2)}return p.stringifyByChar(m)}function d(m,g){for(var b=0;b<m.length;b++)g[b]=m[b];return g}n.applyFromCharCode=y;var h={};h.string={string:c,array:function(m){return u(m,new Array(m.length))},arraybuffer:function(m){return h.string.uint8array(m).buffer},uint8array:function(m){return u(m,new Uint8Array(m.length))},nodebuffer:function(m){return u(m,r.allocBuffer(m.length))}},h.array={string:y,array:c,arraybuffer:function(m){return new Uint8Array(m).buffer},uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(m)}},h.arraybuffer={string:function(m){return y(new Uint8Array(m))},array:function(m){return d(new Uint8Array(m),new Array(m.byteLength))},arraybuffer:c,uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(new Uint8Array(m))}},h.uint8array={string:y,array:function(m){return d(m,new Array(m.length))},arraybuffer:function(m){return m.buffer},uint8array:c,nodebuffer:function(m){return r.newBufferFrom(m)}},h.nodebuffer={string:y,array:function(m){return d(m,new Array(m.length))},arraybuffer:function(m){return h.nodebuffer.uint8array(m).buffer},uint8array:function(m){return d(m,new Uint8Array(m.length))},nodebuffer:c},n.transformTo=function(m,g){if(g=g||"",!m)return g;n.checkSupport(m);var b=n.getTypeOf(g);return h[b][m](g)},n.resolve=function(m){for(var g=m.split("/"),b=[],k=0;k<g.length;k++){var w=g[k];w==="."||w===""&&k!==0&&k!==g.length-1||(w===".."?b.pop():b.push(w))}return b.join("/")},n.getTypeOf=function(m){return typeof m=="string"?"string":Object.prototype.toString.call(m)==="[object Array]"?"array":s.nodebuffer&&r.isBuffer(m)?"nodebuffer":s.uint8array&&m instanceof Uint8Array?"uint8array":s.arraybuffer&&m instanceof ArrayBuffer?"arraybuffer":void 0},n.checkSupport=function(m){if(!s[m.toLowerCase()])throw new Error(m+" is not supported by this platform")},n.MAX_VALUE_16BITS=65535,n.MAX_VALUE_32BITS=-1,n.pretty=function(m){var g,b,k="";for(b=0;b<(m||"").length;b++)k+="\\x"+((g=m.charCodeAt(b))<16?"0":"")+g.toString(16).toUpperCase();return k},n.delay=function(m,g,b){setImmediate(function(){m.apply(b||null,g||[])})},n.inherits=function(m,g){function b(){}b.prototype=g.prototype,m.prototype=new b},n.extend=function(){var m,g,b={};for(m=0;m<arguments.length;m++)for(g in arguments[m])Object.prototype.hasOwnProperty.call(arguments[m],g)&&b[g]===void 0&&(b[g]=arguments[m][g]);return b},n.prepareContent=function(m,g,b,k,w){return a.Promise.resolve(g).then(function(C){return s.blob&&(C instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(C))!==-1)&&typeof FileReader<"u"?new a.Promise(function(A,M){var I=new FileReader;I.onload=function(N){A(N.target.result)},I.onerror=function(N){M(N.target.error)},I.readAsArrayBuffer(C)}):C}).then(function(C){var A=n.getTypeOf(C);return A?(A==="arraybuffer"?C=n.transformTo("uint8array",C):A==="string"&&(w?C=l.decode(C):b&&k!==!0&&(C=(function(M){return u(M,s.uint8array?new Uint8Array(M.length):new Array(M.length))})(C))),C):a.Promise.reject(new Error("Can't read the data of '"+m+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(o,i,n){var s=o("./reader/readerFor"),l=o("./utils"),r=o("./signature"),a=o("./zipEntry"),c=o("./support");function u(p){this.files=[],this.loadOptions=p}u.prototype={checkSignature:function(p){if(!this.reader.readAndCheckSignature(p)){this.reader.index-=4;var y=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(y)+", expected "+l.pretty(p)+")")}},isSignature:function(p,y){var d=this.reader.index;this.reader.setIndex(p);var h=this.reader.readString(4)===y;return this.reader.setIndex(d),h},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var p=this.reader.readData(this.zipCommentLength),y=c.uint8array?"uint8array":"array",d=l.transformTo(y,p);this.zipComment=this.loadOptions.decodeFileName(d)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var p,y,d,h=this.zip64EndOfCentralSize-44;0<h;)p=this.reader.readInt(2),y=this.reader.readInt(4),d=this.reader.readData(y),this.zip64ExtensibleData[p]={id:p,length:y,value:d}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var p,y;for(p=0;p<this.files.length;p++)y=this.files[p],this.reader.setIndex(y.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),y.readLocalPart(this.reader),y.handleUTF8(),y.processAttributes()},readCentralDir:function(){var p;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(p=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(p);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var p=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(p<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(p);var y=p;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(p=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(p),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var d=this.centralDirOffset+this.centralDirSize;this.zip64&&(d+=20,d+=12+this.zip64EndOfCentralSize);var h=y-d;if(0<h)this.isSignature(y,r.CENTRAL_FILE_HEADER)||(this.reader.zero=h);else if(h<0)throw new Error("Corrupted zip: missing "+Math.abs(h)+" bytes.")},prepareReader:function(p){this.reader=s(p)},load:function(p){this.prepareReader(p),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},i.exports=u},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(o,i,n){var s=o("./reader/readerFor"),l=o("./utils"),r=o("./compressedObject"),a=o("./crc32"),c=o("./utf8"),u=o("./compressions"),p=o("./support");function y(d,h){this.options=d,this.loadOptions=h}y.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(d){var h,m;if(d.skip(22),this.fileNameLength=d.readInt(2),m=d.readInt(2),this.fileName=d.readData(this.fileNameLength),d.skip(m),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((h=(function(g){for(var b in u)if(Object.prototype.hasOwnProperty.call(u,b)&&u[b].magic===g)return u[b];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,h,d.readData(this.compressedSize))},readCentralPart:function(d){this.versionMadeBy=d.readInt(2),d.skip(2),this.bitFlag=d.readInt(2),this.compressionMethod=d.readString(2),this.date=d.readDate(),this.crc32=d.readInt(4),this.compressedSize=d.readInt(4),this.uncompressedSize=d.readInt(4);var h=d.readInt(2);if(this.extraFieldsLength=d.readInt(2),this.fileCommentLength=d.readInt(2),this.diskNumberStart=d.readInt(2),this.internalFileAttributes=d.readInt(2),this.externalFileAttributes=d.readInt(4),this.localHeaderOffset=d.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");d.skip(h),this.readExtraFields(d),this.parseZIP64ExtraField(d),this.fileComment=d.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var d=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),d==0&&(this.dosPermissions=63&this.externalFileAttributes),d==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var d=s(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=d.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=d.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=d.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=d.readInt(4))}},readExtraFields:function(d){var h,m,g,b=d.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});d.index+4<b;)h=d.readInt(2),m=d.readInt(2),g=d.readData(m),this.extraFields[h]={id:h,length:m,value:g};d.setIndex(b)},handleUTF8:function(){var d=p.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var h=this.findExtraFieldUnicodePath();if(h!==null)this.fileNameStr=h;else{var m=l.transformTo(d,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(m)}var g=this.findExtraFieldUnicodeComment();if(g!==null)this.fileCommentStr=g;else{var b=l.transformTo(d,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(b)}}},findExtraFieldUnicodePath:function(){var d=this.extraFields[28789];if(d){var h=s(d.value);return h.readInt(1)!==1||a(this.fileName)!==h.readInt(4)?null:c.utf8decode(h.readData(d.length-5))}return null},findExtraFieldUnicodeComment:function(){var d=this.extraFields[25461];if(d){var h=s(d.value);return h.readInt(1)!==1||a(this.fileComment)!==h.readInt(4)?null:c.utf8decode(h.readData(d.length-5))}return null}},i.exports=y},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(o,i,n){function s(h,m,g){this.name=h,this.dir=g.dir,this.date=g.date,this.comment=g.comment,this.unixPermissions=g.unixPermissions,this.dosPermissions=g.dosPermissions,this._data=m,this._dataBinary=g.binary,this.options={compression:g.compression,compressionOptions:g.compressionOptions}}var l=o("./stream/StreamHelper"),r=o("./stream/DataWorker"),a=o("./utf8"),c=o("./compressedObject"),u=o("./stream/GenericWorker");s.prototype={internalStream:function(h){var m=null,g="string";try{if(!h)throw new Error("No output type specified.");var b=(g=h.toLowerCase())==="string"||g==="text";g!=="binarystring"&&g!=="text"||(g="string"),m=this._decompressWorker();var k=!this._dataBinary;k&&!b&&(m=m.pipe(new a.Utf8EncodeWorker)),!k&&b&&(m=m.pipe(new a.Utf8DecodeWorker))}catch(w){(m=new u("error")).error(w)}return new l(m,g,"")},async:function(h,m){return this.internalStream(h).accumulate(m)},nodeStream:function(h,m){return this.internalStream(h||"nodebuffer").toNodejsStream(m)},_compressWorker:function(h,m){if(this._data instanceof c&&this._data.compression.magic===h.magic)return this._data.getCompressedWorker();var g=this._decompressWorker();return this._dataBinary||(g=g.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(g,h,m)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof u?this._data:new r(this._data)}};for(var p=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],y=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},d=0;d<p.length;d++)s.prototype[p[d]]=y;i.exports=s},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(o,i,n){(function(s){var l,r,a=s.MutationObserver||s.WebKitMutationObserver;if(a){var c=0,u=new a(h),p=s.document.createTextNode("");u.observe(p,{characterData:!0}),l=function(){p.data=c=++c%2}}else if(s.setImmediate||s.MessageChannel===void 0)l="document"in s&&"onreadystatechange"in s.document.createElement("script")?function(){var m=s.document.createElement("script");m.onreadystatechange=function(){h(),m.onreadystatechange=null,m.parentNode.removeChild(m),m=null},s.document.documentElement.appendChild(m)}:function(){setTimeout(h,0)};else{var y=new s.MessageChannel;y.port1.onmessage=h,l=function(){y.port2.postMessage(0)}}var d=[];function h(){var m,g;r=!0;for(var b=d.length;b;){for(g=d,d=[],m=-1;++m<b;)g[m]();b=d.length}r=!1}i.exports=function(m){d.push(m)!==1||r||l()}}).call(this,typeof cn<"u"?cn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(o,i,n){var s=o("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],u=["PENDING"];function p(b){if(typeof b!="function")throw new TypeError("resolver must be a function");this.state=u,this.queue=[],this.outcome=void 0,b!==l&&m(this,b)}function y(b,k,w){this.promise=b,typeof k=="function"&&(this.onFulfilled=k,this.callFulfilled=this.otherCallFulfilled),typeof w=="function"&&(this.onRejected=w,this.callRejected=this.otherCallRejected)}function d(b,k,w){s(function(){var C;try{C=k(w)}catch(A){return r.reject(b,A)}C===b?r.reject(b,new TypeError("Cannot resolve promise with itself")):r.resolve(b,C)})}function h(b){var k=b&&b.then;if(b&&(typeof b=="object"||typeof b=="function")&&typeof k=="function")return function(){k.apply(b,arguments)}}function m(b,k){var w=!1;function C(I){w||(w=!0,r.reject(b,I))}function A(I){w||(w=!0,r.resolve(b,I))}var M=g(function(){k(A,C)});M.status==="error"&&C(M.value)}function g(b,k){var w={};try{w.value=b(k),w.status="success"}catch(C){w.status="error",w.value=C}return w}(i.exports=p).prototype.finally=function(b){if(typeof b!="function")return this;var k=this.constructor;return this.then(function(w){return k.resolve(b()).then(function(){return w})},function(w){return k.resolve(b()).then(function(){throw w})})},p.prototype.catch=function(b){return this.then(null,b)},p.prototype.then=function(b,k){if(typeof b!="function"&&this.state===c||typeof k!="function"&&this.state===a)return this;var w=new this.constructor(l);return this.state!==u?d(w,this.state===c?b:k,this.outcome):this.queue.push(new y(w,b,k)),w},y.prototype.callFulfilled=function(b){r.resolve(this.promise,b)},y.prototype.otherCallFulfilled=function(b){d(this.promise,this.onFulfilled,b)},y.prototype.callRejected=function(b){r.reject(this.promise,b)},y.prototype.otherCallRejected=function(b){d(this.promise,this.onRejected,b)},r.resolve=function(b,k){var w=g(h,k);if(w.status==="error")return r.reject(b,w.value);var C=w.value;if(C)m(b,C);else{b.state=c,b.outcome=k;for(var A=-1,M=b.queue.length;++A<M;)b.queue[A].callFulfilled(k)}return b},r.reject=function(b,k){b.state=a,b.outcome=k;for(var w=-1,C=b.queue.length;++w<C;)b.queue[w].callRejected(k);return b},p.resolve=function(b){return b instanceof this?b:r.resolve(new this(l),b)},p.reject=function(b){var k=new this(l);return r.reject(k,b)},p.all=function(b){var k=this;if(Object.prototype.toString.call(b)!=="[object Array]")return this.reject(new TypeError("must be an array"));var w=b.length,C=!1;if(!w)return this.resolve([]);for(var A=new Array(w),M=0,I=-1,N=new this(l);++I<w;)D(b[I],I);return N;function D(U,W){k.resolve(U).then(function(E){A[W]=E,++M!==w||C||(C=!0,r.resolve(N,A))},function(E){C||(C=!0,r.reject(N,E))})}},p.race=function(b){var k=this;if(Object.prototype.toString.call(b)!=="[object Array]")return this.reject(new TypeError("must be an array"));var w=b.length,C=!1;if(!w)return this.resolve([]);for(var A=-1,M=new this(l);++A<w;)I=b[A],k.resolve(I).then(function(N){C||(C=!0,r.resolve(M,N))},function(N){C||(C=!0,r.reject(M,N))});var I;return M}},{immediate:36}],38:[function(o,i,n){var s={};(0,o("./lib/utils/common").assign)(s,o("./lib/deflate"),o("./lib/inflate"),o("./lib/zlib/constants")),i.exports=s},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(o,i,n){var s=o("./zlib/deflate"),l=o("./utils/common"),r=o("./utils/strings"),a=o("./zlib/messages"),c=o("./zlib/zstream"),u=Object.prototype.toString,p=0,y=-1,d=0,h=8;function m(b){if(!(this instanceof m))return new m(b);this.options=l.assign({level:y,method:h,chunkSize:16384,windowBits:15,memLevel:8,strategy:d,to:""},b||{});var k=this.options;k.raw&&0<k.windowBits?k.windowBits=-k.windowBits:k.gzip&&0<k.windowBits&&k.windowBits<16&&(k.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var w=s.deflateInit2(this.strm,k.level,k.method,k.windowBits,k.memLevel,k.strategy);if(w!==p)throw new Error(a[w]);if(k.header&&s.deflateSetHeader(this.strm,k.header),k.dictionary){var C;if(C=typeof k.dictionary=="string"?r.string2buf(k.dictionary):u.call(k.dictionary)==="[object ArrayBuffer]"?new Uint8Array(k.dictionary):k.dictionary,(w=s.deflateSetDictionary(this.strm,C))!==p)throw new Error(a[w]);this._dict_set=!0}}function g(b,k){var w=new m(k);if(w.push(b,!0),w.err)throw w.msg||a[w.err];return w.result}m.prototype.push=function(b,k){var w,C,A=this.strm,M=this.options.chunkSize;if(this.ended)return!1;C=k===~~k?k:k===!0?4:0,typeof b=="string"?A.input=r.string2buf(b):u.call(b)==="[object ArrayBuffer]"?A.input=new Uint8Array(b):A.input=b,A.next_in=0,A.avail_in=A.input.length;do{if(A.avail_out===0&&(A.output=new l.Buf8(M),A.next_out=0,A.avail_out=M),(w=s.deflate(A,C))!==1&&w!==p)return this.onEnd(w),!(this.ended=!0);A.avail_out!==0&&(A.avail_in!==0||C!==4&&C!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(A.output,A.next_out))):this.onData(l.shrinkBuf(A.output,A.next_out)))}while((0<A.avail_in||A.avail_out===0)&&w!==1);return C===4?(w=s.deflateEnd(this.strm),this.onEnd(w),this.ended=!0,w===p):C!==2||(this.onEnd(p),!(A.avail_out=0))},m.prototype.onData=function(b){this.chunks.push(b)},m.prototype.onEnd=function(b){b===p&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=b,this.msg=this.strm.msg},n.Deflate=m,n.deflate=g,n.deflateRaw=function(b,k){return(k=k||{}).raw=!0,g(b,k)},n.gzip=function(b,k){return(k=k||{}).gzip=!0,g(b,k)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(o,i,n){var s=o("./zlib/inflate"),l=o("./utils/common"),r=o("./utils/strings"),a=o("./zlib/constants"),c=o("./zlib/messages"),u=o("./zlib/zstream"),p=o("./zlib/gzheader"),y=Object.prototype.toString;function d(m){if(!(this instanceof d))return new d(m);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},m||{});var g=this.options;g.raw&&0<=g.windowBits&&g.windowBits<16&&(g.windowBits=-g.windowBits,g.windowBits===0&&(g.windowBits=-15)),!(0<=g.windowBits&&g.windowBits<16)||m&&m.windowBits||(g.windowBits+=32),15<g.windowBits&&g.windowBits<48&&(15&g.windowBits)==0&&(g.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var b=s.inflateInit2(this.strm,g.windowBits);if(b!==a.Z_OK)throw new Error(c[b]);this.header=new p,s.inflateGetHeader(this.strm,this.header)}function h(m,g){var b=new d(g);if(b.push(m,!0),b.err)throw b.msg||c[b.err];return b.result}d.prototype.push=function(m,g){var b,k,w,C,A,M,I=this.strm,N=this.options.chunkSize,D=this.options.dictionary,U=!1;if(this.ended)return!1;k=g===~~g?g:g===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof m=="string"?I.input=r.binstring2buf(m):y.call(m)==="[object ArrayBuffer]"?I.input=new Uint8Array(m):I.input=m,I.next_in=0,I.avail_in=I.input.length;do{if(I.avail_out===0&&(I.output=new l.Buf8(N),I.next_out=0,I.avail_out=N),(b=s.inflate(I,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&D&&(M=typeof D=="string"?r.string2buf(D):y.call(D)==="[object ArrayBuffer]"?new Uint8Array(D):D,b=s.inflateSetDictionary(this.strm,M)),b===a.Z_BUF_ERROR&&U===!0&&(b=a.Z_OK,U=!1),b!==a.Z_STREAM_END&&b!==a.Z_OK)return this.onEnd(b),!(this.ended=!0);I.next_out&&(I.avail_out!==0&&b!==a.Z_STREAM_END&&(I.avail_in!==0||k!==a.Z_FINISH&&k!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(w=r.utf8border(I.output,I.next_out),C=I.next_out-w,A=r.buf2string(I.output,w),I.next_out=C,I.avail_out=N-C,C&&l.arraySet(I.output,I.output,w,C,0),this.onData(A)):this.onData(l.shrinkBuf(I.output,I.next_out)))),I.avail_in===0&&I.avail_out===0&&(U=!0)}while((0<I.avail_in||I.avail_out===0)&&b!==a.Z_STREAM_END);return b===a.Z_STREAM_END&&(k=a.Z_FINISH),k===a.Z_FINISH?(b=s.inflateEnd(this.strm),this.onEnd(b),this.ended=!0,b===a.Z_OK):k!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(I.avail_out=0))},d.prototype.onData=function(m){this.chunks.push(m)},d.prototype.onEnd=function(m){m===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=m,this.msg=this.strm.msg},n.Inflate=d,n.inflate=h,n.inflateRaw=function(m,g){return(g=g||{}).raw=!0,h(m,g)},n.ungzip=h},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(o,i,n){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";n.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var u=c.shift();if(u){if(typeof u!="object")throw new TypeError(u+"must be non-object");for(var p in u)u.hasOwnProperty(p)&&(a[p]=u[p])}}return a},n.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,u,p,y){if(c.subarray&&a.subarray)a.set(c.subarray(u,u+p),y);else for(var d=0;d<p;d++)a[y+d]=c[u+d]},flattenChunks:function(a){var c,u,p,y,d,h;for(c=p=0,u=a.length;c<u;c++)p+=a[c].length;for(h=new Uint8Array(p),c=y=0,u=a.length;c<u;c++)d=a[c],h.set(d,y),y+=d.length;return h}},r={arraySet:function(a,c,u,p,y){for(var d=0;d<p;d++)a[y+d]=c[u+d]},flattenChunks:function(a){return[].concat.apply([],a)}};n.setTyped=function(a){a?(n.Buf8=Uint8Array,n.Buf16=Uint16Array,n.Buf32=Int32Array,n.assign(n,l)):(n.Buf8=Array,n.Buf16=Array,n.Buf32=Array,n.assign(n,r))},n.setTyped(s)},{}],42:[function(o,i,n){var s=o("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new s.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function u(p,y){if(y<65537&&(p.subarray&&r||!p.subarray&&l))return String.fromCharCode.apply(null,s.shrinkBuf(p,y));for(var d="",h=0;h<y;h++)d+=String.fromCharCode(p[h]);return d}a[254]=a[254]=1,n.string2buf=function(p){var y,d,h,m,g,b=p.length,k=0;for(m=0;m<b;m++)(64512&(d=p.charCodeAt(m)))==55296&&m+1<b&&(64512&(h=p.charCodeAt(m+1)))==56320&&(d=65536+(d-55296<<10)+(h-56320),m++),k+=d<128?1:d<2048?2:d<65536?3:4;for(y=new s.Buf8(k),m=g=0;g<k;m++)(64512&(d=p.charCodeAt(m)))==55296&&m+1<b&&(64512&(h=p.charCodeAt(m+1)))==56320&&(d=65536+(d-55296<<10)+(h-56320),m++),d<128?y[g++]=d:(d<2048?y[g++]=192|d>>>6:(d<65536?y[g++]=224|d>>>12:(y[g++]=240|d>>>18,y[g++]=128|d>>>12&63),y[g++]=128|d>>>6&63),y[g++]=128|63&d);return y},n.buf2binstring=function(p){return u(p,p.length)},n.binstring2buf=function(p){for(var y=new s.Buf8(p.length),d=0,h=y.length;d<h;d++)y[d]=p.charCodeAt(d);return y},n.buf2string=function(p,y){var d,h,m,g,b=y||p.length,k=new Array(2*b);for(d=h=0;d<b;)if((m=p[d++])<128)k[h++]=m;else if(4<(g=a[m]))k[h++]=65533,d+=g-1;else{for(m&=g===2?31:g===3?15:7;1<g&&d<b;)m=m<<6|63&p[d++],g--;1<g?k[h++]=65533:m<65536?k[h++]=m:(m-=65536,k[h++]=55296|m>>10&1023,k[h++]=56320|1023&m)}return u(k,h)},n.utf8border=function(p,y){var d;for((y=y||p.length)>p.length&&(y=p.length),d=y-1;0<=d&&(192&p[d])==128;)d--;return d<0||d===0?y:d+a[p[d]]>y?d:y}},{"./common":41}],43:[function(o,i,n){i.exports=function(s,l,r,a){for(var c=65535&s|0,u=s>>>16&65535|0,p=0;r!==0;){for(r-=p=2e3<r?2e3:r;u=u+(c=c+l[a++]|0)|0,--p;);c%=65521,u%=65521}return c|u<<16|0}},{}],44:[function(o,i,n){i.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(o,i,n){var s=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();i.exports=function(l,r,a,c){var u=s,p=c+a;l^=-1;for(var y=c;y<p;y++)l=l>>>8^u[255&(l^r[y])];return-1^l}},{}],46:[function(o,i,n){var s,l=o("../utils/common"),r=o("./trees"),a=o("./adler32"),c=o("./crc32"),u=o("./messages"),p=0,y=4,d=0,h=-2,m=-1,g=4,b=2,k=8,w=9,C=286,A=30,M=19,I=2*C+1,N=15,D=3,U=258,W=U+D+1,E=42,P=113,x=1,K=2,j=3,$=4;function T(v,F){return v.msg=u[F],F}function O(v){return(v<<1)-(4<v?9:0)}function te(v){for(var F=v.length;0<=--F;)v[F]=0}function Y(v){var F=v.state,z=F.pending;z>v.avail_out&&(z=v.avail_out),z!==0&&(l.arraySet(v.output,F.pending_buf,F.pending_out,z,v.next_out),v.next_out+=z,F.pending_out+=z,v.total_out+=z,v.avail_out-=z,F.pending-=z,F.pending===0&&(F.pending_out=0))}function Z(v,F){r._tr_flush_block(v,0<=v.block_start?v.block_start:-1,v.strstart-v.block_start,F),v.block_start=v.strstart,Y(v.strm)}function ce(v,F){v.pending_buf[v.pending++]=F}function oe(v,F){v.pending_buf[v.pending++]=F>>>8&255,v.pending_buf[v.pending++]=255&F}function ne(v,F){var z,S,_=v.max_chain_length,L=v.strstart,q=v.prev_length,V=v.nice_match,G=v.strstart>v.w_size-W?v.strstart-(v.w_size-W):0,X=v.window,le=v.w_mask,se=v.prev,me=v.strstart+U,Se=X[L+q-1],we=X[L+q];v.prev_length>=v.good_match&&(_>>=2),V>v.lookahead&&(V=v.lookahead);do if(X[(z=F)+q]===we&&X[z+q-1]===Se&&X[z]===X[L]&&X[++z]===X[L+1]){L+=2,z++;do;while(X[++L]===X[++z]&&X[++L]===X[++z]&&X[++L]===X[++z]&&X[++L]===X[++z]&&X[++L]===X[++z]&&X[++L]===X[++z]&&X[++L]===X[++z]&&X[++L]===X[++z]&&L<me);if(S=U-(me-L),L=me-U,q<S){if(v.match_start=F,V<=(q=S))break;Se=X[L+q-1],we=X[L+q]}}while((F=se[F&le])>G&&--_!=0);return q<=v.lookahead?q:v.lookahead}function Ce(v){var F,z,S,_,L,q,V,G,X,le,se=v.w_size;do{if(_=v.window_size-v.lookahead-v.strstart,v.strstart>=se+(se-W)){for(l.arraySet(v.window,v.window,se,se,0),v.match_start-=se,v.strstart-=se,v.block_start-=se,F=z=v.hash_size;S=v.head[--F],v.head[F]=se<=S?S-se:0,--z;);for(F=z=se;S=v.prev[--F],v.prev[F]=se<=S?S-se:0,--z;);_+=se}if(v.strm.avail_in===0)break;if(q=v.strm,V=v.window,G=v.strstart+v.lookahead,X=_,le=void 0,le=q.avail_in,X<le&&(le=X),z=le===0?0:(q.avail_in-=le,l.arraySet(V,q.input,q.next_in,le,G),q.state.wrap===1?q.adler=a(q.adler,V,le,G):q.state.wrap===2&&(q.adler=c(q.adler,V,le,G)),q.next_in+=le,q.total_in+=le,le),v.lookahead+=z,v.lookahead+v.insert>=D)for(L=v.strstart-v.insert,v.ins_h=v.window[L],v.ins_h=(v.ins_h<<v.hash_shift^v.window[L+1])&v.hash_mask;v.insert&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[L+D-1])&v.hash_mask,v.prev[L&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=L,L++,v.insert--,!(v.lookahead+v.insert<D)););}while(v.lookahead<W&&v.strm.avail_in!==0)}function _e(v,F){for(var z,S;;){if(v.lookahead<W){if(Ce(v),v.lookahead<W&&F===p)return x;if(v.lookahead===0)break}if(z=0,v.lookahead>=D&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+D-1])&v.hash_mask,z=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),z!==0&&v.strstart-z<=v.w_size-W&&(v.match_length=ne(v,z)),v.match_length>=D)if(S=r._tr_tally(v,v.strstart-v.match_start,v.match_length-D),v.lookahead-=v.match_length,v.match_length<=v.max_lazy_match&&v.lookahead>=D){for(v.match_length--;v.strstart++,v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+D-1])&v.hash_mask,z=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart,--v.match_length!=0;);v.strstart++}else v.strstart+=v.match_length,v.match_length=0,v.ins_h=v.window[v.strstart],v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+1])&v.hash_mask;else S=r._tr_tally(v,0,v.window[v.strstart]),v.lookahead--,v.strstart++;if(S&&(Z(v,!1),v.strm.avail_out===0))return x}return v.insert=v.strstart<D-1?v.strstart:D-1,F===y?(Z(v,!0),v.strm.avail_out===0?j:$):v.last_lit&&(Z(v,!1),v.strm.avail_out===0)?x:K}function ke(v,F){for(var z,S,_;;){if(v.lookahead<W){if(Ce(v),v.lookahead<W&&F===p)return x;if(v.lookahead===0)break}if(z=0,v.lookahead>=D&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+D-1])&v.hash_mask,z=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),v.prev_length=v.match_length,v.prev_match=v.match_start,v.match_length=D-1,z!==0&&v.prev_length<v.max_lazy_match&&v.strstart-z<=v.w_size-W&&(v.match_length=ne(v,z),v.match_length<=5&&(v.strategy===1||v.match_length===D&&4096<v.strstart-v.match_start)&&(v.match_length=D-1)),v.prev_length>=D&&v.match_length<=v.prev_length){for(_=v.strstart+v.lookahead-D,S=r._tr_tally(v,v.strstart-1-v.prev_match,v.prev_length-D),v.lookahead-=v.prev_length-1,v.prev_length-=2;++v.strstart<=_&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+D-1])&v.hash_mask,z=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),--v.prev_length!=0;);if(v.match_available=0,v.match_length=D-1,v.strstart++,S&&(Z(v,!1),v.strm.avail_out===0))return x}else if(v.match_available){if((S=r._tr_tally(v,0,v.window[v.strstart-1]))&&Z(v,!1),v.strstart++,v.lookahead--,v.strm.avail_out===0)return x}else v.match_available=1,v.strstart++,v.lookahead--}return v.match_available&&(S=r._tr_tally(v,0,v.window[v.strstart-1]),v.match_available=0),v.insert=v.strstart<D-1?v.strstart:D-1,F===y?(Z(v,!0),v.strm.avail_out===0?j:$):v.last_lit&&(Z(v,!1),v.strm.avail_out===0)?x:K}function Ie(v,F,z,S,_){this.good_length=v,this.max_lazy=F,this.nice_length=z,this.max_chain=S,this.func=_}function R(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=k,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*I),this.dyn_dtree=new l.Buf16(2*(2*A+1)),this.bl_tree=new l.Buf16(2*(2*M+1)),te(this.dyn_ltree),te(this.dyn_dtree),te(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(N+1),this.heap=new l.Buf16(2*C+1),te(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*C+1),te(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ie(v){var F;return v&&v.state?(v.total_in=v.total_out=0,v.data_type=b,(F=v.state).pending=0,F.pending_out=0,F.wrap<0&&(F.wrap=-F.wrap),F.status=F.wrap?E:P,v.adler=F.wrap===2?0:1,F.last_flush=p,r._tr_init(F),d):T(v,h)}function B(v){var F=ie(v);return F===d&&(function(z){z.window_size=2*z.w_size,te(z.head),z.max_lazy_match=s[z.level].max_lazy,z.good_match=s[z.level].good_length,z.nice_match=s[z.level].nice_length,z.max_chain_length=s[z.level].max_chain,z.strstart=0,z.block_start=0,z.lookahead=0,z.insert=0,z.match_length=z.prev_length=D-1,z.match_available=0,z.ins_h=0})(v.state),F}function H(v,F,z,S,_,L){if(!v)return h;var q=1;if(F===m&&(F=6),S<0?(q=0,S=-S):15<S&&(q=2,S-=16),_<1||w<_||z!==k||S<8||15<S||F<0||9<F||L<0||g<L)return T(v,h);S===8&&(S=9);var V=new R;return(v.state=V).strm=v,V.wrap=q,V.gzhead=null,V.w_bits=S,V.w_size=1<<V.w_bits,V.w_mask=V.w_size-1,V.hash_bits=_+7,V.hash_size=1<<V.hash_bits,V.hash_mask=V.hash_size-1,V.hash_shift=~~((V.hash_bits+D-1)/D),V.window=new l.Buf8(2*V.w_size),V.head=new l.Buf16(V.hash_size),V.prev=new l.Buf16(V.w_size),V.lit_bufsize=1<<_+6,V.pending_buf_size=4*V.lit_bufsize,V.pending_buf=new l.Buf8(V.pending_buf_size),V.d_buf=1*V.lit_bufsize,V.l_buf=3*V.lit_bufsize,V.level=F,V.strategy=L,V.method=z,B(v)}s=[new Ie(0,0,0,0,function(v,F){var z=65535;for(z>v.pending_buf_size-5&&(z=v.pending_buf_size-5);;){if(v.lookahead<=1){if(Ce(v),v.lookahead===0&&F===p)return x;if(v.lookahead===0)break}v.strstart+=v.lookahead,v.lookahead=0;var S=v.block_start+z;if((v.strstart===0||v.strstart>=S)&&(v.lookahead=v.strstart-S,v.strstart=S,Z(v,!1),v.strm.avail_out===0)||v.strstart-v.block_start>=v.w_size-W&&(Z(v,!1),v.strm.avail_out===0))return x}return v.insert=0,F===y?(Z(v,!0),v.strm.avail_out===0?j:$):(v.strstart>v.block_start&&(Z(v,!1),v.strm.avail_out),x)}),new Ie(4,4,8,4,_e),new Ie(4,5,16,8,_e),new Ie(4,6,32,32,_e),new Ie(4,4,16,16,ke),new Ie(8,16,32,32,ke),new Ie(8,16,128,128,ke),new Ie(8,32,128,256,ke),new Ie(32,128,258,1024,ke),new Ie(32,258,258,4096,ke)],n.deflateInit=function(v,F){return H(v,F,k,15,8,0)},n.deflateInit2=H,n.deflateReset=B,n.deflateResetKeep=ie,n.deflateSetHeader=function(v,F){return v&&v.state?v.state.wrap!==2?h:(v.state.gzhead=F,d):h},n.deflate=function(v,F){var z,S,_,L;if(!v||!v.state||5<F||F<0)return v?T(v,h):h;if(S=v.state,!v.output||!v.input&&v.avail_in!==0||S.status===666&&F!==y)return T(v,v.avail_out===0?-5:h);if(S.strm=v,z=S.last_flush,S.last_flush=F,S.status===E)if(S.wrap===2)v.adler=0,ce(S,31),ce(S,139),ce(S,8),S.gzhead?(ce(S,(S.gzhead.text?1:0)+(S.gzhead.hcrc?2:0)+(S.gzhead.extra?4:0)+(S.gzhead.name?8:0)+(S.gzhead.comment?16:0)),ce(S,255&S.gzhead.time),ce(S,S.gzhead.time>>8&255),ce(S,S.gzhead.time>>16&255),ce(S,S.gzhead.time>>24&255),ce(S,S.level===9?2:2<=S.strategy||S.level<2?4:0),ce(S,255&S.gzhead.os),S.gzhead.extra&&S.gzhead.extra.length&&(ce(S,255&S.gzhead.extra.length),ce(S,S.gzhead.extra.length>>8&255)),S.gzhead.hcrc&&(v.adler=c(v.adler,S.pending_buf,S.pending,0)),S.gzindex=0,S.status=69):(ce(S,0),ce(S,0),ce(S,0),ce(S,0),ce(S,0),ce(S,S.level===9?2:2<=S.strategy||S.level<2?4:0),ce(S,3),S.status=P);else{var q=k+(S.w_bits-8<<4)<<8;q|=(2<=S.strategy||S.level<2?0:S.level<6?1:S.level===6?2:3)<<6,S.strstart!==0&&(q|=32),q+=31-q%31,S.status=P,oe(S,q),S.strstart!==0&&(oe(S,v.adler>>>16),oe(S,65535&v.adler)),v.adler=1}if(S.status===69)if(S.gzhead.extra){for(_=S.pending;S.gzindex<(65535&S.gzhead.extra.length)&&(S.pending!==S.pending_buf_size||(S.gzhead.hcrc&&S.pending>_&&(v.adler=c(v.adler,S.pending_buf,S.pending-_,_)),Y(v),_=S.pending,S.pending!==S.pending_buf_size));)ce(S,255&S.gzhead.extra[S.gzindex]),S.gzindex++;S.gzhead.hcrc&&S.pending>_&&(v.adler=c(v.adler,S.pending_buf,S.pending-_,_)),S.gzindex===S.gzhead.extra.length&&(S.gzindex=0,S.status=73)}else S.status=73;if(S.status===73)if(S.gzhead.name){_=S.pending;do{if(S.pending===S.pending_buf_size&&(S.gzhead.hcrc&&S.pending>_&&(v.adler=c(v.adler,S.pending_buf,S.pending-_,_)),Y(v),_=S.pending,S.pending===S.pending_buf_size)){L=1;break}L=S.gzindex<S.gzhead.name.length?255&S.gzhead.name.charCodeAt(S.gzindex++):0,ce(S,L)}while(L!==0);S.gzhead.hcrc&&S.pending>_&&(v.adler=c(v.adler,S.pending_buf,S.pending-_,_)),L===0&&(S.gzindex=0,S.status=91)}else S.status=91;if(S.status===91)if(S.gzhead.comment){_=S.pending;do{if(S.pending===S.pending_buf_size&&(S.gzhead.hcrc&&S.pending>_&&(v.adler=c(v.adler,S.pending_buf,S.pending-_,_)),Y(v),_=S.pending,S.pending===S.pending_buf_size)){L=1;break}L=S.gzindex<S.gzhead.comment.length?255&S.gzhead.comment.charCodeAt(S.gzindex++):0,ce(S,L)}while(L!==0);S.gzhead.hcrc&&S.pending>_&&(v.adler=c(v.adler,S.pending_buf,S.pending-_,_)),L===0&&(S.status=103)}else S.status=103;if(S.status===103&&(S.gzhead.hcrc?(S.pending+2>S.pending_buf_size&&Y(v),S.pending+2<=S.pending_buf_size&&(ce(S,255&v.adler),ce(S,v.adler>>8&255),v.adler=0,S.status=P)):S.status=P),S.pending!==0){if(Y(v),v.avail_out===0)return S.last_flush=-1,d}else if(v.avail_in===0&&O(F)<=O(z)&&F!==y)return T(v,-5);if(S.status===666&&v.avail_in!==0)return T(v,-5);if(v.avail_in!==0||S.lookahead!==0||F!==p&&S.status!==666){var V=S.strategy===2?(function(G,X){for(var le;;){if(G.lookahead===0&&(Ce(G),G.lookahead===0)){if(X===p)return x;break}if(G.match_length=0,le=r._tr_tally(G,0,G.window[G.strstart]),G.lookahead--,G.strstart++,le&&(Z(G,!1),G.strm.avail_out===0))return x}return G.insert=0,X===y?(Z(G,!0),G.strm.avail_out===0?j:$):G.last_lit&&(Z(G,!1),G.strm.avail_out===0)?x:K})(S,F):S.strategy===3?(function(G,X){for(var le,se,me,Se,we=G.window;;){if(G.lookahead<=U){if(Ce(G),G.lookahead<=U&&X===p)return x;if(G.lookahead===0)break}if(G.match_length=0,G.lookahead>=D&&0<G.strstart&&(se=we[me=G.strstart-1])===we[++me]&&se===we[++me]&&se===we[++me]){Se=G.strstart+U;do;while(se===we[++me]&&se===we[++me]&&se===we[++me]&&se===we[++me]&&se===we[++me]&&se===we[++me]&&se===we[++me]&&se===we[++me]&&me<Se);G.match_length=U-(Se-me),G.match_length>G.lookahead&&(G.match_length=G.lookahead)}if(G.match_length>=D?(le=r._tr_tally(G,1,G.match_length-D),G.lookahead-=G.match_length,G.strstart+=G.match_length,G.match_length=0):(le=r._tr_tally(G,0,G.window[G.strstart]),G.lookahead--,G.strstart++),le&&(Z(G,!1),G.strm.avail_out===0))return x}return G.insert=0,X===y?(Z(G,!0),G.strm.avail_out===0?j:$):G.last_lit&&(Z(G,!1),G.strm.avail_out===0)?x:K})(S,F):s[S.level].func(S,F);if(V!==j&&V!==$||(S.status=666),V===x||V===j)return v.avail_out===0&&(S.last_flush=-1),d;if(V===K&&(F===1?r._tr_align(S):F!==5&&(r._tr_stored_block(S,0,0,!1),F===3&&(te(S.head),S.lookahead===0&&(S.strstart=0,S.block_start=0,S.insert=0))),Y(v),v.avail_out===0))return S.last_flush=-1,d}return F!==y?d:S.wrap<=0?1:(S.wrap===2?(ce(S,255&v.adler),ce(S,v.adler>>8&255),ce(S,v.adler>>16&255),ce(S,v.adler>>24&255),ce(S,255&v.total_in),ce(S,v.total_in>>8&255),ce(S,v.total_in>>16&255),ce(S,v.total_in>>24&255)):(oe(S,v.adler>>>16),oe(S,65535&v.adler)),Y(v),0<S.wrap&&(S.wrap=-S.wrap),S.pending!==0?d:1)},n.deflateEnd=function(v){var F;return v&&v.state?(F=v.state.status)!==E&&F!==69&&F!==73&&F!==91&&F!==103&&F!==P&&F!==666?T(v,h):(v.state=null,F===P?T(v,-3):d):h},n.deflateSetDictionary=function(v,F){var z,S,_,L,q,V,G,X,le=F.length;if(!v||!v.state||(L=(z=v.state).wrap)===2||L===1&&z.status!==E||z.lookahead)return h;for(L===1&&(v.adler=a(v.adler,F,le,0)),z.wrap=0,le>=z.w_size&&(L===0&&(te(z.head),z.strstart=0,z.block_start=0,z.insert=0),X=new l.Buf8(z.w_size),l.arraySet(X,F,le-z.w_size,z.w_size,0),F=X,le=z.w_size),q=v.avail_in,V=v.next_in,G=v.input,v.avail_in=le,v.next_in=0,v.input=F,Ce(z);z.lookahead>=D;){for(S=z.strstart,_=z.lookahead-(D-1);z.ins_h=(z.ins_h<<z.hash_shift^z.window[S+D-1])&z.hash_mask,z.prev[S&z.w_mask]=z.head[z.ins_h],z.head[z.ins_h]=S,S++,--_;);z.strstart=S,z.lookahead=D-1,Ce(z)}return z.strstart+=z.lookahead,z.block_start=z.strstart,z.insert=z.lookahead,z.lookahead=0,z.match_length=z.prev_length=D-1,z.match_available=0,v.next_in=V,v.input=G,v.avail_in=q,z.wrap=L,d},n.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(o,i,n){i.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(o,i,n){i.exports=function(s,l){var r,a,c,u,p,y,d,h,m,g,b,k,w,C,A,M,I,N,D,U,W,E,P,x,K;r=s.state,a=s.next_in,x=s.input,c=a+(s.avail_in-5),u=s.next_out,K=s.output,p=u-(l-s.avail_out),y=u+(s.avail_out-257),d=r.dmax,h=r.wsize,m=r.whave,g=r.wnext,b=r.window,k=r.hold,w=r.bits,C=r.lencode,A=r.distcode,M=(1<<r.lenbits)-1,I=(1<<r.distbits)-1;e:do{w<15&&(k+=x[a++]<<w,w+=8,k+=x[a++]<<w,w+=8),N=C[k&M];t:for(;;){if(k>>>=D=N>>>24,w-=D,(D=N>>>16&255)===0)K[u++]=65535&N;else{if(!(16&D)){if((64&D)==0){N=C[(65535&N)+(k&(1<<D)-1)];continue t}if(32&D){r.mode=12;break e}s.msg="invalid literal/length code",r.mode=30;break e}U=65535&N,(D&=15)&&(w<D&&(k+=x[a++]<<w,w+=8),U+=k&(1<<D)-1,k>>>=D,w-=D),w<15&&(k+=x[a++]<<w,w+=8,k+=x[a++]<<w,w+=8),N=A[k&I];o:for(;;){if(k>>>=D=N>>>24,w-=D,!(16&(D=N>>>16&255))){if((64&D)==0){N=A[(65535&N)+(k&(1<<D)-1)];continue o}s.msg="invalid distance code",r.mode=30;break e}if(W=65535&N,w<(D&=15)&&(k+=x[a++]<<w,(w+=8)<D&&(k+=x[a++]<<w,w+=8)),d<(W+=k&(1<<D)-1)){s.msg="invalid distance too far back",r.mode=30;break e}if(k>>>=D,w-=D,(D=u-p)<W){if(m<(D=W-D)&&r.sane){s.msg="invalid distance too far back",r.mode=30;break e}if(P=b,(E=0)===g){if(E+=h-D,D<U){for(U-=D;K[u++]=b[E++],--D;);E=u-W,P=K}}else if(g<D){if(E+=h+g-D,(D-=g)<U){for(U-=D;K[u++]=b[E++],--D;);if(E=0,g<U){for(U-=D=g;K[u++]=b[E++],--D;);E=u-W,P=K}}}else if(E+=g-D,D<U){for(U-=D;K[u++]=b[E++],--D;);E=u-W,P=K}for(;2<U;)K[u++]=P[E++],K[u++]=P[E++],K[u++]=P[E++],U-=3;U&&(K[u++]=P[E++],1<U&&(K[u++]=P[E++]))}else{for(E=u-W;K[u++]=K[E++],K[u++]=K[E++],K[u++]=K[E++],2<(U-=3););U&&(K[u++]=K[E++],1<U&&(K[u++]=K[E++]))}break}}break}}while(a<c&&u<y);a-=U=w>>3,k&=(1<<(w-=U<<3))-1,s.next_in=a,s.next_out=u,s.avail_in=a<c?c-a+5:5-(a-c),s.avail_out=u<y?y-u+257:257-(u-y),r.hold=k,r.bits=w}},{}],49:[function(o,i,n){var s=o("../utils/common"),l=o("./adler32"),r=o("./crc32"),a=o("./inffast"),c=o("./inftrees"),u=1,p=2,y=0,d=-2,h=1,m=852,g=592;function b(E){return(E>>>24&255)+(E>>>8&65280)+((65280&E)<<8)+((255&E)<<24)}function k(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new s.Buf16(320),this.work=new s.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function w(E){var P;return E&&E.state?(P=E.state,E.total_in=E.total_out=P.total=0,E.msg="",P.wrap&&(E.adler=1&P.wrap),P.mode=h,P.last=0,P.havedict=0,P.dmax=32768,P.head=null,P.hold=0,P.bits=0,P.lencode=P.lendyn=new s.Buf32(m),P.distcode=P.distdyn=new s.Buf32(g),P.sane=1,P.back=-1,y):d}function C(E){var P;return E&&E.state?((P=E.state).wsize=0,P.whave=0,P.wnext=0,w(E)):d}function A(E,P){var x,K;return E&&E.state?(K=E.state,P<0?(x=0,P=-P):(x=1+(P>>4),P<48&&(P&=15)),P&&(P<8||15<P)?d:(K.window!==null&&K.wbits!==P&&(K.window=null),K.wrap=x,K.wbits=P,C(E))):d}function M(E,P){var x,K;return E?(K=new k,(E.state=K).window=null,(x=A(E,P))!==y&&(E.state=null),x):d}var I,N,D=!0;function U(E){if(D){var P;for(I=new s.Buf32(512),N=new s.Buf32(32),P=0;P<144;)E.lens[P++]=8;for(;P<256;)E.lens[P++]=9;for(;P<280;)E.lens[P++]=7;for(;P<288;)E.lens[P++]=8;for(c(u,E.lens,0,288,I,0,E.work,{bits:9}),P=0;P<32;)E.lens[P++]=5;c(p,E.lens,0,32,N,0,E.work,{bits:5}),D=!1}E.lencode=I,E.lenbits=9,E.distcode=N,E.distbits=5}function W(E,P,x,K){var j,$=E.state;return $.window===null&&($.wsize=1<<$.wbits,$.wnext=0,$.whave=0,$.window=new s.Buf8($.wsize)),K>=$.wsize?(s.arraySet($.window,P,x-$.wsize,$.wsize,0),$.wnext=0,$.whave=$.wsize):(K<(j=$.wsize-$.wnext)&&(j=K),s.arraySet($.window,P,x-K,j,$.wnext),(K-=j)?(s.arraySet($.window,P,x-K,K,0),$.wnext=K,$.whave=$.wsize):($.wnext+=j,$.wnext===$.wsize&&($.wnext=0),$.whave<$.wsize&&($.whave+=j))),0}n.inflateReset=C,n.inflateReset2=A,n.inflateResetKeep=w,n.inflateInit=function(E){return M(E,15)},n.inflateInit2=M,n.inflate=function(E,P){var x,K,j,$,T,O,te,Y,Z,ce,oe,ne,Ce,_e,ke,Ie,R,ie,B,H,v,F,z,S,_=0,L=new s.Buf8(4),q=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!E||!E.state||!E.output||!E.input&&E.avail_in!==0)return d;(x=E.state).mode===12&&(x.mode=13),T=E.next_out,j=E.output,te=E.avail_out,$=E.next_in,K=E.input,O=E.avail_in,Y=x.hold,Z=x.bits,ce=O,oe=te,F=y;e:for(;;)switch(x.mode){case h:if(x.wrap===0){x.mode=13;break}for(;Z<16;){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}if(2&x.wrap&&Y===35615){L[x.check=0]=255&Y,L[1]=Y>>>8&255,x.check=r(x.check,L,2,0),Z=Y=0,x.mode=2;break}if(x.flags=0,x.head&&(x.head.done=!1),!(1&x.wrap)||(((255&Y)<<8)+(Y>>8))%31){E.msg="incorrect header check",x.mode=30;break}if((15&Y)!=8){E.msg="unknown compression method",x.mode=30;break}if(Z-=4,v=8+(15&(Y>>>=4)),x.wbits===0)x.wbits=v;else if(v>x.wbits){E.msg="invalid window size",x.mode=30;break}x.dmax=1<<v,E.adler=x.check=1,x.mode=512&Y?10:12,Z=Y=0;break;case 2:for(;Z<16;){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}if(x.flags=Y,(255&x.flags)!=8){E.msg="unknown compression method",x.mode=30;break}if(57344&x.flags){E.msg="unknown header flags set",x.mode=30;break}x.head&&(x.head.text=Y>>8&1),512&x.flags&&(L[0]=255&Y,L[1]=Y>>>8&255,x.check=r(x.check,L,2,0)),Z=Y=0,x.mode=3;case 3:for(;Z<32;){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}x.head&&(x.head.time=Y),512&x.flags&&(L[0]=255&Y,L[1]=Y>>>8&255,L[2]=Y>>>16&255,L[3]=Y>>>24&255,x.check=r(x.check,L,4,0)),Z=Y=0,x.mode=4;case 4:for(;Z<16;){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}x.head&&(x.head.xflags=255&Y,x.head.os=Y>>8),512&x.flags&&(L[0]=255&Y,L[1]=Y>>>8&255,x.check=r(x.check,L,2,0)),Z=Y=0,x.mode=5;case 5:if(1024&x.flags){for(;Z<16;){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}x.length=Y,x.head&&(x.head.extra_len=Y),512&x.flags&&(L[0]=255&Y,L[1]=Y>>>8&255,x.check=r(x.check,L,2,0)),Z=Y=0}else x.head&&(x.head.extra=null);x.mode=6;case 6:if(1024&x.flags&&(O<(ne=x.length)&&(ne=O),ne&&(x.head&&(v=x.head.extra_len-x.length,x.head.extra||(x.head.extra=new Array(x.head.extra_len)),s.arraySet(x.head.extra,K,$,ne,v)),512&x.flags&&(x.check=r(x.check,K,ne,$)),O-=ne,$+=ne,x.length-=ne),x.length))break e;x.length=0,x.mode=7;case 7:if(2048&x.flags){if(O===0)break e;for(ne=0;v=K[$+ne++],x.head&&v&&x.length<65536&&(x.head.name+=String.fromCharCode(v)),v&&ne<O;);if(512&x.flags&&(x.check=r(x.check,K,ne,$)),O-=ne,$+=ne,v)break e}else x.head&&(x.head.name=null);x.length=0,x.mode=8;case 8:if(4096&x.flags){if(O===0)break e;for(ne=0;v=K[$+ne++],x.head&&v&&x.length<65536&&(x.head.comment+=String.fromCharCode(v)),v&&ne<O;);if(512&x.flags&&(x.check=r(x.check,K,ne,$)),O-=ne,$+=ne,v)break e}else x.head&&(x.head.comment=null);x.mode=9;case 9:if(512&x.flags){for(;Z<16;){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}if(Y!==(65535&x.check)){E.msg="header crc mismatch",x.mode=30;break}Z=Y=0}x.head&&(x.head.hcrc=x.flags>>9&1,x.head.done=!0),E.adler=x.check=0,x.mode=12;break;case 10:for(;Z<32;){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}E.adler=x.check=b(Y),Z=Y=0,x.mode=11;case 11:if(x.havedict===0)return E.next_out=T,E.avail_out=te,E.next_in=$,E.avail_in=O,x.hold=Y,x.bits=Z,2;E.adler=x.check=1,x.mode=12;case 12:if(P===5||P===6)break e;case 13:if(x.last){Y>>>=7&Z,Z-=7&Z,x.mode=27;break}for(;Z<3;){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}switch(x.last=1&Y,Z-=1,3&(Y>>>=1)){case 0:x.mode=14;break;case 1:if(U(x),x.mode=20,P!==6)break;Y>>>=2,Z-=2;break e;case 2:x.mode=17;break;case 3:E.msg="invalid block type",x.mode=30}Y>>>=2,Z-=2;break;case 14:for(Y>>>=7&Z,Z-=7&Z;Z<32;){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}if((65535&Y)!=(Y>>>16^65535)){E.msg="invalid stored block lengths",x.mode=30;break}if(x.length=65535&Y,Z=Y=0,x.mode=15,P===6)break e;case 15:x.mode=16;case 16:if(ne=x.length){if(O<ne&&(ne=O),te<ne&&(ne=te),ne===0)break e;s.arraySet(j,K,$,ne,T),O-=ne,$+=ne,te-=ne,T+=ne,x.length-=ne;break}x.mode=12;break;case 17:for(;Z<14;){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}if(x.nlen=257+(31&Y),Y>>>=5,Z-=5,x.ndist=1+(31&Y),Y>>>=5,Z-=5,x.ncode=4+(15&Y),Y>>>=4,Z-=4,286<x.nlen||30<x.ndist){E.msg="too many length or distance symbols",x.mode=30;break}x.have=0,x.mode=18;case 18:for(;x.have<x.ncode;){for(;Z<3;){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}x.lens[q[x.have++]]=7&Y,Y>>>=3,Z-=3}for(;x.have<19;)x.lens[q[x.have++]]=0;if(x.lencode=x.lendyn,x.lenbits=7,z={bits:x.lenbits},F=c(0,x.lens,0,19,x.lencode,0,x.work,z),x.lenbits=z.bits,F){E.msg="invalid code lengths set",x.mode=30;break}x.have=0,x.mode=19;case 19:for(;x.have<x.nlen+x.ndist;){for(;Ie=(_=x.lencode[Y&(1<<x.lenbits)-1])>>>16&255,R=65535&_,!((ke=_>>>24)<=Z);){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}if(R<16)Y>>>=ke,Z-=ke,x.lens[x.have++]=R;else{if(R===16){for(S=ke+2;Z<S;){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}if(Y>>>=ke,Z-=ke,x.have===0){E.msg="invalid bit length repeat",x.mode=30;break}v=x.lens[x.have-1],ne=3+(3&Y),Y>>>=2,Z-=2}else if(R===17){for(S=ke+3;Z<S;){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}Z-=ke,v=0,ne=3+(7&(Y>>>=ke)),Y>>>=3,Z-=3}else{for(S=ke+7;Z<S;){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}Z-=ke,v=0,ne=11+(127&(Y>>>=ke)),Y>>>=7,Z-=7}if(x.have+ne>x.nlen+x.ndist){E.msg="invalid bit length repeat",x.mode=30;break}for(;ne--;)x.lens[x.have++]=v}}if(x.mode===30)break;if(x.lens[256]===0){E.msg="invalid code -- missing end-of-block",x.mode=30;break}if(x.lenbits=9,z={bits:x.lenbits},F=c(u,x.lens,0,x.nlen,x.lencode,0,x.work,z),x.lenbits=z.bits,F){E.msg="invalid literal/lengths set",x.mode=30;break}if(x.distbits=6,x.distcode=x.distdyn,z={bits:x.distbits},F=c(p,x.lens,x.nlen,x.ndist,x.distcode,0,x.work,z),x.distbits=z.bits,F){E.msg="invalid distances set",x.mode=30;break}if(x.mode=20,P===6)break e;case 20:x.mode=21;case 21:if(6<=O&&258<=te){E.next_out=T,E.avail_out=te,E.next_in=$,E.avail_in=O,x.hold=Y,x.bits=Z,a(E,oe),T=E.next_out,j=E.output,te=E.avail_out,$=E.next_in,K=E.input,O=E.avail_in,Y=x.hold,Z=x.bits,x.mode===12&&(x.back=-1);break}for(x.back=0;Ie=(_=x.lencode[Y&(1<<x.lenbits)-1])>>>16&255,R=65535&_,!((ke=_>>>24)<=Z);){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}if(Ie&&(240&Ie)==0){for(ie=ke,B=Ie,H=R;Ie=(_=x.lencode[H+((Y&(1<<ie+B)-1)>>ie)])>>>16&255,R=65535&_,!(ie+(ke=_>>>24)<=Z);){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}Y>>>=ie,Z-=ie,x.back+=ie}if(Y>>>=ke,Z-=ke,x.back+=ke,x.length=R,Ie===0){x.mode=26;break}if(32&Ie){x.back=-1,x.mode=12;break}if(64&Ie){E.msg="invalid literal/length code",x.mode=30;break}x.extra=15&Ie,x.mode=22;case 22:if(x.extra){for(S=x.extra;Z<S;){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}x.length+=Y&(1<<x.extra)-1,Y>>>=x.extra,Z-=x.extra,x.back+=x.extra}x.was=x.length,x.mode=23;case 23:for(;Ie=(_=x.distcode[Y&(1<<x.distbits)-1])>>>16&255,R=65535&_,!((ke=_>>>24)<=Z);){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}if((240&Ie)==0){for(ie=ke,B=Ie,H=R;Ie=(_=x.distcode[H+((Y&(1<<ie+B)-1)>>ie)])>>>16&255,R=65535&_,!(ie+(ke=_>>>24)<=Z);){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}Y>>>=ie,Z-=ie,x.back+=ie}if(Y>>>=ke,Z-=ke,x.back+=ke,64&Ie){E.msg="invalid distance code",x.mode=30;break}x.offset=R,x.extra=15&Ie,x.mode=24;case 24:if(x.extra){for(S=x.extra;Z<S;){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}x.offset+=Y&(1<<x.extra)-1,Y>>>=x.extra,Z-=x.extra,x.back+=x.extra}if(x.offset>x.dmax){E.msg="invalid distance too far back",x.mode=30;break}x.mode=25;case 25:if(te===0)break e;if(ne=oe-te,x.offset>ne){if((ne=x.offset-ne)>x.whave&&x.sane){E.msg="invalid distance too far back",x.mode=30;break}Ce=ne>x.wnext?(ne-=x.wnext,x.wsize-ne):x.wnext-ne,ne>x.length&&(ne=x.length),_e=x.window}else _e=j,Ce=T-x.offset,ne=x.length;for(te<ne&&(ne=te),te-=ne,x.length-=ne;j[T++]=_e[Ce++],--ne;);x.length===0&&(x.mode=21);break;case 26:if(te===0)break e;j[T++]=x.length,te--,x.mode=21;break;case 27:if(x.wrap){for(;Z<32;){if(O===0)break e;O--,Y|=K[$++]<<Z,Z+=8}if(oe-=te,E.total_out+=oe,x.total+=oe,oe&&(E.adler=x.check=x.flags?r(x.check,j,oe,T-oe):l(x.check,j,oe,T-oe)),oe=te,(x.flags?Y:b(Y))!==x.check){E.msg="incorrect data check",x.mode=30;break}Z=Y=0}x.mode=28;case 28:if(x.wrap&&x.flags){for(;Z<32;){if(O===0)break e;O--,Y+=K[$++]<<Z,Z+=8}if(Y!==(4294967295&x.total)){E.msg="incorrect length check",x.mode=30;break}Z=Y=0}x.mode=29;case 29:F=1;break e;case 30:F=-3;break e;case 31:return-4;case 32:default:return d}return E.next_out=T,E.avail_out=te,E.next_in=$,E.avail_in=O,x.hold=Y,x.bits=Z,(x.wsize||oe!==E.avail_out&&x.mode<30&&(x.mode<27||P!==4))&&W(E,E.output,E.next_out,oe-E.avail_out)?(x.mode=31,-4):(ce-=E.avail_in,oe-=E.avail_out,E.total_in+=ce,E.total_out+=oe,x.total+=oe,x.wrap&&oe&&(E.adler=x.check=x.flags?r(x.check,j,oe,E.next_out-oe):l(x.check,j,oe,E.next_out-oe)),E.data_type=x.bits+(x.last?64:0)+(x.mode===12?128:0)+(x.mode===20||x.mode===15?256:0),(ce==0&&oe===0||P===4)&&F===y&&(F=-5),F)},n.inflateEnd=function(E){if(!E||!E.state)return d;var P=E.state;return P.window&&(P.window=null),E.state=null,y},n.inflateGetHeader=function(E,P){var x;return E&&E.state?(2&(x=E.state).wrap)==0?d:((x.head=P).done=!1,y):d},n.inflateSetDictionary=function(E,P){var x,K=P.length;return E&&E.state?(x=E.state).wrap!==0&&x.mode!==11?d:x.mode===11&&l(1,P,K,0)!==x.check?-3:W(E,P,K,K)?(x.mode=31,-4):(x.havedict=1,y):d},n.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(o,i,n){var s=o("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];i.exports=function(u,p,y,d,h,m,g,b){var k,w,C,A,M,I,N,D,U,W=b.bits,E=0,P=0,x=0,K=0,j=0,$=0,T=0,O=0,te=0,Y=0,Z=null,ce=0,oe=new s.Buf16(16),ne=new s.Buf16(16),Ce=null,_e=0;for(E=0;E<=15;E++)oe[E]=0;for(P=0;P<d;P++)oe[p[y+P]]++;for(j=W,K=15;1<=K&&oe[K]===0;K--);if(K<j&&(j=K),K===0)return h[m++]=20971520,h[m++]=20971520,b.bits=1,0;for(x=1;x<K&&oe[x]===0;x++);for(j<x&&(j=x),E=O=1;E<=15;E++)if(O<<=1,(O-=oe[E])<0)return-1;if(0<O&&(u===0||K!==1))return-1;for(ne[1]=0,E=1;E<15;E++)ne[E+1]=ne[E]+oe[E];for(P=0;P<d;P++)p[y+P]!==0&&(g[ne[p[y+P]]++]=P);if(I=u===0?(Z=Ce=g,19):u===1?(Z=l,ce-=257,Ce=r,_e-=257,256):(Z=a,Ce=c,-1),E=x,M=m,T=P=Y=0,C=-1,A=(te=1<<($=j))-1,u===1&&852<te||u===2&&592<te)return 1;for(;;){for(N=E-T,U=g[P]<I?(D=0,g[P]):g[P]>I?(D=Ce[_e+g[P]],Z[ce+g[P]]):(D=96,0),k=1<<E-T,x=w=1<<$;h[M+(Y>>T)+(w-=k)]=N<<24|D<<16|U|0,w!==0;);for(k=1<<E-1;Y&k;)k>>=1;if(k!==0?(Y&=k-1,Y+=k):Y=0,P++,--oe[E]==0){if(E===K)break;E=p[y+g[P]]}if(j<E&&(Y&A)!==C){for(T===0&&(T=j),M+=x,O=1<<($=E-T);$+T<K&&!((O-=oe[$+T])<=0);)$++,O<<=1;if(te+=1<<$,u===1&&852<te||u===2&&592<te)return 1;h[C=Y&A]=j<<24|$<<16|M-m|0}}return Y!==0&&(h[M+Y]=E-T<<24|64<<16|0),b.bits=j,0}},{"../utils/common":41}],51:[function(o,i,n){i.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(o,i,n){var s=o("../utils/common"),l=0,r=1;function a(_){for(var L=_.length;0<=--L;)_[L]=0}var c=0,u=29,p=256,y=p+1+u,d=30,h=19,m=2*y+1,g=15,b=16,k=7,w=256,C=16,A=17,M=18,I=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],N=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],D=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],U=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],W=new Array(2*(y+2));a(W);var E=new Array(2*d);a(E);var P=new Array(512);a(P);var x=new Array(256);a(x);var K=new Array(u);a(K);var j,$,T,O=new Array(d);function te(_,L,q,V,G){this.static_tree=_,this.extra_bits=L,this.extra_base=q,this.elems=V,this.max_length=G,this.has_stree=_&&_.length}function Y(_,L){this.dyn_tree=_,this.max_code=0,this.stat_desc=L}function Z(_){return _<256?P[_]:P[256+(_>>>7)]}function ce(_,L){_.pending_buf[_.pending++]=255&L,_.pending_buf[_.pending++]=L>>>8&255}function oe(_,L,q){_.bi_valid>b-q?(_.bi_buf|=L<<_.bi_valid&65535,ce(_,_.bi_buf),_.bi_buf=L>>b-_.bi_valid,_.bi_valid+=q-b):(_.bi_buf|=L<<_.bi_valid&65535,_.bi_valid+=q)}function ne(_,L,q){oe(_,q[2*L],q[2*L+1])}function Ce(_,L){for(var q=0;q|=1&_,_>>>=1,q<<=1,0<--L;);return q>>>1}function _e(_,L,q){var V,G,X=new Array(g+1),le=0;for(V=1;V<=g;V++)X[V]=le=le+q[V-1]<<1;for(G=0;G<=L;G++){var se=_[2*G+1];se!==0&&(_[2*G]=Ce(X[se]++,se))}}function ke(_){var L;for(L=0;L<y;L++)_.dyn_ltree[2*L]=0;for(L=0;L<d;L++)_.dyn_dtree[2*L]=0;for(L=0;L<h;L++)_.bl_tree[2*L]=0;_.dyn_ltree[2*w]=1,_.opt_len=_.static_len=0,_.last_lit=_.matches=0}function Ie(_){8<_.bi_valid?ce(_,_.bi_buf):0<_.bi_valid&&(_.pending_buf[_.pending++]=_.bi_buf),_.bi_buf=0,_.bi_valid=0}function R(_,L,q,V){var G=2*L,X=2*q;return _[G]<_[X]||_[G]===_[X]&&V[L]<=V[q]}function ie(_,L,q){for(var V=_.heap[q],G=q<<1;G<=_.heap_len&&(G<_.heap_len&&R(L,_.heap[G+1],_.heap[G],_.depth)&&G++,!R(L,V,_.heap[G],_.depth));)_.heap[q]=_.heap[G],q=G,G<<=1;_.heap[q]=V}function B(_,L,q){var V,G,X,le,se=0;if(_.last_lit!==0)for(;V=_.pending_buf[_.d_buf+2*se]<<8|_.pending_buf[_.d_buf+2*se+1],G=_.pending_buf[_.l_buf+se],se++,V===0?ne(_,G,L):(ne(_,(X=x[G])+p+1,L),(le=I[X])!==0&&oe(_,G-=K[X],le),ne(_,X=Z(--V),q),(le=N[X])!==0&&oe(_,V-=O[X],le)),se<_.last_lit;);ne(_,w,L)}function H(_,L){var q,V,G,X=L.dyn_tree,le=L.stat_desc.static_tree,se=L.stat_desc.has_stree,me=L.stat_desc.elems,Se=-1;for(_.heap_len=0,_.heap_max=m,q=0;q<me;q++)X[2*q]!==0?(_.heap[++_.heap_len]=Se=q,_.depth[q]=0):X[2*q+1]=0;for(;_.heap_len<2;)X[2*(G=_.heap[++_.heap_len]=Se<2?++Se:0)]=1,_.depth[G]=0,_.opt_len--,se&&(_.static_len-=le[2*G+1]);for(L.max_code=Se,q=_.heap_len>>1;1<=q;q--)ie(_,X,q);for(G=me;q=_.heap[1],_.heap[1]=_.heap[_.heap_len--],ie(_,X,1),V=_.heap[1],_.heap[--_.heap_max]=q,_.heap[--_.heap_max]=V,X[2*G]=X[2*q]+X[2*V],_.depth[G]=(_.depth[q]>=_.depth[V]?_.depth[q]:_.depth[V])+1,X[2*q+1]=X[2*V+1]=G,_.heap[1]=G++,ie(_,X,1),2<=_.heap_len;);_.heap[--_.heap_max]=_.heap[1],(function(we,Le){var He,Ge,rt,Ne,ft,tt,Ke=Le.dyn_tree,ue=Le.max_code,fe=Le.stat_desc.static_tree,Qe=Le.stat_desc.has_stree,lt=Le.stat_desc.extra_bits,St=Le.stat_desc.extra_base,at=Le.stat_desc.max_length,ro=0;for(Ne=0;Ne<=g;Ne++)we.bl_count[Ne]=0;for(Ke[2*we.heap[we.heap_max]+1]=0,He=we.heap_max+1;He<m;He++)at<(Ne=Ke[2*Ke[2*(Ge=we.heap[He])+1]+1]+1)&&(Ne=at,ro++),Ke[2*Ge+1]=Ne,ue<Ge||(we.bl_count[Ne]++,ft=0,St<=Ge&&(ft=lt[Ge-St]),tt=Ke[2*Ge],we.opt_len+=tt*(Ne+ft),Qe&&(we.static_len+=tt*(fe[2*Ge+1]+ft)));if(ro!==0){do{for(Ne=at-1;we.bl_count[Ne]===0;)Ne--;we.bl_count[Ne]--,we.bl_count[Ne+1]+=2,we.bl_count[at]--,ro-=2}while(0<ro);for(Ne=at;Ne!==0;Ne--)for(Ge=we.bl_count[Ne];Ge!==0;)ue<(rt=we.heap[--He])||(Ke[2*rt+1]!==Ne&&(we.opt_len+=(Ne-Ke[2*rt+1])*Ke[2*rt],Ke[2*rt+1]=Ne),Ge--)}})(_,L),_e(X,Se,_.bl_count)}function v(_,L,q){var V,G,X=-1,le=L[1],se=0,me=7,Se=4;for(le===0&&(me=138,Se=3),L[2*(q+1)+1]=65535,V=0;V<=q;V++)G=le,le=L[2*(V+1)+1],++se<me&&G===le||(se<Se?_.bl_tree[2*G]+=se:G!==0?(G!==X&&_.bl_tree[2*G]++,_.bl_tree[2*C]++):se<=10?_.bl_tree[2*A]++:_.bl_tree[2*M]++,X=G,Se=(se=0)===le?(me=138,3):G===le?(me=6,3):(me=7,4))}function F(_,L,q){var V,G,X=-1,le=L[1],se=0,me=7,Se=4;for(le===0&&(me=138,Se=3),V=0;V<=q;V++)if(G=le,le=L[2*(V+1)+1],!(++se<me&&G===le)){if(se<Se)for(;ne(_,G,_.bl_tree),--se!=0;);else G!==0?(G!==X&&(ne(_,G,_.bl_tree),se--),ne(_,C,_.bl_tree),oe(_,se-3,2)):se<=10?(ne(_,A,_.bl_tree),oe(_,se-3,3)):(ne(_,M,_.bl_tree),oe(_,se-11,7));X=G,Se=(se=0)===le?(me=138,3):G===le?(me=6,3):(me=7,4)}}a(O);var z=!1;function S(_,L,q,V){oe(_,(c<<1)+(V?1:0),3),(function(G,X,le,se){Ie(G),ce(G,le),ce(G,~le),s.arraySet(G.pending_buf,G.window,X,le,G.pending),G.pending+=le})(_,L,q)}n._tr_init=function(_){z||((function(){var L,q,V,G,X,le=new Array(g+1);for(G=V=0;G<u-1;G++)for(K[G]=V,L=0;L<1<<I[G];L++)x[V++]=G;for(x[V-1]=G,G=X=0;G<16;G++)for(O[G]=X,L=0;L<1<<N[G];L++)P[X++]=G;for(X>>=7;G<d;G++)for(O[G]=X<<7,L=0;L<1<<N[G]-7;L++)P[256+X++]=G;for(q=0;q<=g;q++)le[q]=0;for(L=0;L<=143;)W[2*L+1]=8,L++,le[8]++;for(;L<=255;)W[2*L+1]=9,L++,le[9]++;for(;L<=279;)W[2*L+1]=7,L++,le[7]++;for(;L<=287;)W[2*L+1]=8,L++,le[8]++;for(_e(W,y+1,le),L=0;L<d;L++)E[2*L+1]=5,E[2*L]=Ce(L,5);j=new te(W,I,p+1,y,g),$=new te(E,N,0,d,g),T=new te(new Array(0),D,0,h,k)})(),z=!0),_.l_desc=new Y(_.dyn_ltree,j),_.d_desc=new Y(_.dyn_dtree,$),_.bl_desc=new Y(_.bl_tree,T),_.bi_buf=0,_.bi_valid=0,ke(_)},n._tr_stored_block=S,n._tr_flush_block=function(_,L,q,V){var G,X,le=0;0<_.level?(_.strm.data_type===2&&(_.strm.data_type=(function(se){var me,Se=4093624447;for(me=0;me<=31;me++,Se>>>=1)if(1&Se&&se.dyn_ltree[2*me]!==0)return l;if(se.dyn_ltree[18]!==0||se.dyn_ltree[20]!==0||se.dyn_ltree[26]!==0)return r;for(me=32;me<p;me++)if(se.dyn_ltree[2*me]!==0)return r;return l})(_)),H(_,_.l_desc),H(_,_.d_desc),le=(function(se){var me;for(v(se,se.dyn_ltree,se.l_desc.max_code),v(se,se.dyn_dtree,se.d_desc.max_code),H(se,se.bl_desc),me=h-1;3<=me&&se.bl_tree[2*U[me]+1]===0;me--);return se.opt_len+=3*(me+1)+5+5+4,me})(_),G=_.opt_len+3+7>>>3,(X=_.static_len+3+7>>>3)<=G&&(G=X)):G=X=q+5,q+4<=G&&L!==-1?S(_,L,q,V):_.strategy===4||X===G?(oe(_,2+(V?1:0),3),B(_,W,E)):(oe(_,4+(V?1:0),3),(function(se,me,Se,we){var Le;for(oe(se,me-257,5),oe(se,Se-1,5),oe(se,we-4,4),Le=0;Le<we;Le++)oe(se,se.bl_tree[2*U[Le]+1],3);F(se,se.dyn_ltree,me-1),F(se,se.dyn_dtree,Se-1)})(_,_.l_desc.max_code+1,_.d_desc.max_code+1,le+1),B(_,_.dyn_ltree,_.dyn_dtree)),ke(_),V&&Ie(_)},n._tr_tally=function(_,L,q){return _.pending_buf[_.d_buf+2*_.last_lit]=L>>>8&255,_.pending_buf[_.d_buf+2*_.last_lit+1]=255&L,_.pending_buf[_.l_buf+_.last_lit]=255&q,_.last_lit++,L===0?_.dyn_ltree[2*q]++:(_.matches++,L--,_.dyn_ltree[2*(x[q]+p+1)]++,_.dyn_dtree[2*Z(L)]++),_.last_lit===_.lit_bufsize-1},n._tr_align=function(_){oe(_,2,3),ne(_,w,W),(function(L){L.bi_valid===16?(ce(L,L.bi_buf),L.bi_buf=0,L.bi_valid=0):8<=L.bi_valid&&(L.pending_buf[L.pending++]=255&L.bi_buf,L.bi_buf>>=8,L.bi_valid-=8)})(_)}},{"../utils/common":41}],53:[function(o,i,n){i.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(o,i,n){(function(s){(function(l,r){if(!l.setImmediate){var a,c,u,p,y=1,d={},h=!1,m=l.document,g=Object.getPrototypeOf&&Object.getPrototypeOf(l);g=g&&g.setTimeout?g:l,a={}.toString.call(l.process)==="[object process]"?function(C){process.nextTick(function(){k(C)})}:(function(){if(l.postMessage&&!l.importScripts){var C=!0,A=l.onmessage;return l.onmessage=function(){C=!1},l.postMessage("","*"),l.onmessage=A,C}})()?(p="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",w,!1):l.attachEvent("onmessage",w),function(C){l.postMessage(p+C,"*")}):l.MessageChannel?((u=new MessageChannel).port1.onmessage=function(C){k(C.data)},function(C){u.port2.postMessage(C)}):m&&"onreadystatechange"in m.createElement("script")?(c=m.documentElement,function(C){var A=m.createElement("script");A.onreadystatechange=function(){k(C),A.onreadystatechange=null,c.removeChild(A),A=null},c.appendChild(A)}):function(C){setTimeout(k,0,C)},g.setImmediate=function(C){typeof C!="function"&&(C=new Function(""+C));for(var A=new Array(arguments.length-1),M=0;M<A.length;M++)A[M]=arguments[M+1];var I={callback:C,args:A};return d[y]=I,a(y),y++},g.clearImmediate=b}function b(C){delete d[C]}function k(C){if(h)setTimeout(k,0,C);else{var A=d[C];if(A){h=!0;try{(function(M){var I=M.callback,N=M.args;switch(N.length){case 0:I();break;case 1:I(N[0]);break;case 2:I(N[0],N[1]);break;case 3:I(N[0],N[1],N[2]);break;default:I.apply(r,N)}})(A)}finally{b(C),h=!1}}}}function w(C){C.source===l&&typeof C.data=="string"&&C.data.indexOf(p)===0&&k(+C.data.slice(p.length))}})(typeof self>"u"?s===void 0?this:s:self)}).call(this,typeof cn<"u"?cn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(fs)),fs.exports}var tg=eg();const Ja=Qm(tg);function Xa(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function Qa(e,t){var o,i,n;if(!t)return"";if(typeof document<"u"){const s=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),l=((s==null?void 0:s.innerText)||(s==null?void 0:s.textContent)||"").trim();if(l)return l}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const s=(o=e.latestCompiledDoc.slides)==null?void 0:o[0],l=(i=s==null?void 0:s.blocks)==null?void 0:i.find(r=>r.type==="h"||r.type==="NodeHeading");if(l!=null&&l.content)return l.content.trim()}try{const s=await pi(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(s)&&s.length>0&&((n=s[0])!=null&&n.content))return String(s[0].content).trim()}catch{}return""}async function og(e,t,o){var c,u,p;const i=Tw(),n=!!((c=i==null?void 0:i.isPinned)!=null&&c.value),s=String(((u=i==null?void 0:i.pinnedDocId)==null?void 0:u.value)||"");if(n&&s&&o&&o!==s)return;const l=o||(n&&s?s:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&l&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(l):await Qa(e,l));const a=Xa(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(a),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",a);return}if(typeof document<"u"){const y=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const d of y){const h=d.querySelector(".item__text"),m=((p=h==null?void 0:h.textContent)==null?void 0:p.trim())||"";if(m.includes("Slidev 演示预览")||m.startsWith("即现")){h&&(h.textContent=a),d.setAttribute("title",a);break}}}}function Ei(e){return(e||"").replace(/[/\\?%*:|"<>]/g,"_").replace(/_+/g,"_").trim().replace(/^_+|_+$/g,"")||"presentation"}async function Oo(e,t,o){var n,s;const i=t||(e==null?void 0:e.docId)||"";if(o&&typeof o.fetchDocumentTitle=="function"&&i)try{const l=await o.fetchDocumentTitle(i);if(l&&l.trim())return Ei(l)}catch{}if(typeof document<"u")try{const l=(i?document.querySelector(`.protyle-title[data-node-id="${i}"] .protyle-title__input`):null)||(i?document.querySelector(`.protyle[data-doc-id="${i}"] .protyle-title__input`):null)||document.querySelector(".layout__wnd--active .protyle-title__input")||document.querySelector(".protyle-title__input"),r=((l==null?void 0:l.innerText)||(l==null?void 0:l.textContent)||"").trim();if(r)return Ei(r)}catch{}if((n=e==null?void 0:e.config)!=null&&n.title&&e.config.title.trim()&&e.config.title.trim().toLowerCase()!=="presentation")return Ei(e.config.title);if(e!=null&&e.slides&&e.slides.length>0){const r=(s=e.slides[0].blocks)==null?void 0:s.find(c=>c.type==="h"||c.type==="NodeHeading"),a=((r==null?void 0:r.content)||"").replace(/^#+\s*/,"").trim();if(a)return Ei(a)}return"presentation"}function ig(e,t){if(typeof document>"u")return!1;const o=URL.createObjectURL(t),i=document.createElement("a");return i.href=o,i.download=e,document.body.appendChild(i),i.click(),document.body.removeChild(i),URL.revokeObjectURL(o),!0}function pl(e,t){if(typeof document>"u")return!1;const o=document.createElement("a");return o.href=t,o.download=e,document.body.appendChild(o),o.click(),document.body.removeChild(o),!0}async function ng(e){if(typeof navigator>"u"||!navigator.clipboard||typeof ClipboardItem>"u")return!1;try{const o=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({[o.type||"image/png"]:o})]),!0}catch(t){return console.warn("[image-exporter] 复制图像至剪贴板失败:",t),!1}}async function Rs(e,t){return new Promise(o=>{let i=[],n=null;const s=()=>{n&&(clearTimeout(n),n=null),i.forEach(a=>a()),i=[]};n=setTimeout(()=>{s(),o({success:!1,error:"单页截图超时（沙箱无响应）"})},2e4);const l=e.onCapturePageDone(a=>{s(),o({success:!0,dataUrl:a.dataUrl})});i.push(l);const r=e.onCaptureError(a=>{s(),o({success:!1,error:a})});i.push(r),e.startImageExport({mode:"current",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function ec(e,t){const o=[],i=Ei((t==null?void 0:t.title)||"presentation");return new Promise(n=>{let s=[],l=null;const r=()=>{l&&(clearTimeout(l),l=null),s.forEach(d=>d()),s=[]},a=()=>{l&&clearTimeout(l),l=setTimeout(()=>{r(),n({success:!1,error:"幻灯片逐页导出超时（沙箱无响应）"})},35e3)};a();const c=e.onCaptureProgress(d=>{var h;a(),(h=t==null?void 0:t.onProgress)==null||h.call(t,d.current,d.total,d.pageIndex)});s.push(c);const u=e.onCapturePageDone(d=>{a(),(d.mode==="all"||!d.mode)&&o.push({pageIndex:d.pageIndex,dataUrl:d.dataUrl})});s.push(u);const p=async()=>{r();try{if(o.length===0){n({success:!1,error:"未采集到幻灯片图像数据"});return}const d=new Ja,h=(t==null?void 0:t.format)==="jpeg"?"jpg":"png";for(const b of o){const k=String(b.pageIndex).padStart(2,"0"),w=b.dataUrl.split(",")[1];d.file(`slide-${k}.${h}`,w,{base64:!0})}const m=await d.generateAsync({type:"blob",compression:"DEFLATE"}),g=ig(`${i}.zip`,m);n({success:g,total:o.length})}catch(d){n({success:!1,error:(d==null?void 0:d.message)||String(d)})}};s.push(e.onCaptureComplete(p));const y=e.onCaptureError(d=>{r(),n({success:!1,error:d})});s.push(y),e.startImageExport({mode:"all",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function tc(e,t){if(typeof document>"u")return{success:!1,error:"环境不支持 DOM 沙箱挂载"};const o=document.createElement("iframe");o.style.position="fixed",o.style.left="-9999px",o.style.top="-9999px",o.style.width="1920px",o.style.height="1080px",o.style.opacity="0",o.style.pointerEvents="none",o.src="/plugins/siyuan-live-slides/slides-client/index.html?headless=true",document.body.appendChild(o);const i=new Zn;i.attach(o);try{if(await new Promise((n,s)=>{const l=setTimeout(()=>s(new Error("静默后台沙箱加载超时")),12e3);i.onClientReady(()=>{clearTimeout(l),n()})}),i.updateSlides(e.slides,e.config),await new Promise(n=>setTimeout(n,250)),(t==null?void 0:t.mode)==="current"){const n=await Rs(i,t);return{success:n.success,total:1,error:n.error}}else{const n=(t==null?void 0:t.title)||await Oo(e,e.docId);return await ec(i,{...t,title:n})}}catch(n){return{success:!1,error:(n==null?void 0:n.message)||String(n)}}finally{i.detach(),o.remove()}}const sg=1500,rg=500,lg=4,ag=new Set(["INPUT","TEXTAREA","SELECT"]);function oc(e){const t=e;return!t||!t.tagName?!1:ag.has(t.tagName)||t.isContentEditable===!0}function cg(e){let t="",o=!1,i=null,n=null;function s(){e.onStateChange&&e.onStateChange({display:t,invalid:o})}function l(){i&&(clearTimeout(i),i=null),n&&(clearTimeout(n),n=null)}function r(){l(),t="",o=!1,s()}function a(){i&&clearTimeout(i),i=setTimeout(r,sg)}function c(){i&&(clearTimeout(i),i=null),o=!0,s(),n&&clearTimeout(n),n=setTimeout(r,rg)}function u(p){if(e.isEnabled&&!e.isEnabled()||oc(p.target)||p.isComposing||p.ctrlKey||p.metaKey||p.altKey)return!1;if(/^[0-9]$/.test(p.key))return o||t.length>=lg||(t+=p.key,s(),a()),!0;if(p.key==="Enter"){if(!t||o)return!1;const d=parseInt(t,10),h=e.getTotalPages();return!isNaN(d)&&d>=1&&h>0&&d<=h?(r(),e.onJump(d),!0):(c(),!0)}return p.key==="Escape"&&(t||o)?(r(),!0):!1}return{handleKeydown:u,getState:()=>({display:t,invalid:o}),clear:r}}const dg={class:"spm-slides-tab__toolbar"},ug={class:"spm-slides-tab__nav"},fg=["disabled"],hg={class:"spm-page-badge"},pg=["disabled"],mg=["aria-label"],gg={class:"spm-slides-tab__tools"},yg={key:3,class:"spm-export-image-dropdown",style:{position:"relative",display:"inline-flex","align-items":"center"}},bg={key:0,class:"b3-menu b3-menu--context",style:{position:"absolute",top:"calc(100% + 4px)",right:"0","z-index":"100","min-width":"190px","box-shadow":"var(--b3-point-shadow)","border-radius":"4px",background:"var(--b3-theme-surface)"}},vg=["src"],kg=Nt({__name:"SlidesPreviewTab",setup(e,{expose:t}){const o=Wt("plugin"),i=Wt("sandboxBridge",new Zn),n=new Tm(i),s=pe(null),l=pe(!1),r=pe(null),a=pe(1),c=pe(1),u=pe(!1),p=pe(!1),y=pe(!1),d=pe("siyuan"),h=pe(""),m=pe(""),g=pe(""),b=pe(!1),k=pe(!1),w=pe(""),C=pe(""),A=pe(!1),M=cg({getTotalPages:()=>c.value,isEnabled:()=>!p.value,onJump:S=>D(S),onStateChange:S=>{C.value=S.display,A.value=S.invalid}});function I(S){if(S.key==="o"||S.key==="O"){if(p.value||S.isComposing||S.ctrlKey||S.metaKey||S.altKey||oc(S.target))return;S.preventDefault(),N();return}M.handleKeydown(S)&&S.preventDefault()}function N(){var S;i.toggleOverview(),(S=r.value)==null||S.focus()}function D(S){var _;a.value=S,i.navigatePage(S),(_=r.value)==null||_.focus()}const U=pe("/plugins/siyuan-live-slides/slides-client/index.html");let W=null,E=null,P=null,x=null,K=null,j=null,$=null,T=null;wi(()=>{r.value&&i.attach(r.value),W=i.onSlideChanged((S,_)=>{a.value=S,c.value=_}),E=i.onBlockClicked((S,_)=>{a.value=_,n.setActiveBlockId(S),S||Fi(),o&&typeof o.handleBlockClickedFromSlide=="function"?o.handleBlockClickedFromSlide(S,_):S&&Zo(S,o==null?void 0:o.app)}),P=i.onOpenInEditor((S,_)=>{a.value=_,n.setActiveBlockId(S),Zo(S,o==null?void 0:o.app)}),x=i.onOpenPeekDrawer(async S=>{const _=Yn();if(S.peekType==="siyuan"&&_.enableWebServeJump){let L=!1;if(T&&T.docId===S.target)L=!0;else if(T&&T.slides&&T.slides.some(q=>{var V;return(V=q.blocks)==null?void 0:V.some(G=>G.id===S.target)}))L=!1;else try{const q=await pi(`SELECT id, root_id, type FROM blocks WHERE id = '${S.target}' LIMIT 1`);q&&q.length>0&&(L=q[0].type==="d"||q[0].id===q[0].root_id)}catch(q){console.warn("[SlidesPreviewTab] detect block type failed:",q)}d.value="web",b.value=!0,m.value=Pa(_.webServeUrl,S.target,{focus:!L}),g.value=S.title||`${L?"思源文档":"思源块"}: ${S.target.slice(0,8)}`,p.value=!0,i.freezeKeyboardNav(!0)}else{if(d.value=S.peekType,S.peekType==="siyuan")h.value=S.target,g.value=S.title||`块速览: ${S.target.slice(0,8)}`;else{const L=Wa(S.target);if(L.external){_e(S.target);return}b.value=!0,m.value=L.url,g.value=S.title||L.url}p.value=!0,i.freezeKeyboardNav(!0)}}),K=i.onRequestToggleFullscreen(()=>{Ie()}),j=i.onOpenPresenter(()=>{R()}),typeof document<"u"&&document.addEventListener("fullscreenchange",ke),$=Fa(S=>{T&&i.updateSlides(T.slides,{...T.config,hostThemeMode:S},T.customThemeCss)})}),Vn(()=>{$&&($(),$=null),typeof document<"u"&&document.removeEventListener("fullscreenchange",ke),x&&x(),K&&K(),j&&j(),W&&W(),E&&E(),P&&P(),i.detach(),M.clear(),n.destroy()});function O(){k.value=!k.value,k.value?(w.value=(T==null?void 0:T.docId)||"",o&&typeof o.updatePreviewTabHeader=="function"&&o.updatePreviewTabHeader("",w.value)):(w.value="",oe(),o&&typeof o.updatePreviewTabHeader=="function"&&o.updatePreviewTabHeader())}let te=0;function Y(S){if(p.value||Math.abs(S.deltaY)<Math.abs(S.deltaX)||Math.abs(S.deltaY)<15)return;const _=Date.now();_-te<280||(te=_,S.deltaY>0?ce():Z())}function Z(){if(a.value>1){const S=a.value-1;a.value=S,i.navigatePage(S)}}function ce(){if(a.value<c.value){const S=a.value+1;a.value=S,i.navigatePage(S)}}function oe(){o&&typeof o.compileCurrentDocument=="function"?o.compileCurrentDocument():o!=null&&o.eventBus&&typeof o.eventBus.emit=="function"&&o.eventBus.emit("slides:request-compile")}function ne(){p.value=!1,i.freezeKeyboardNav(!1)}function Ce(){ne()}function _e(S){var V,G;const _=/^file:/i.test(S),L=_||/^[a-zA-Z]:[\\/]/.test(S),q=tn("electron");if(L&&typeof((V=q==null?void 0:q.shell)==null?void 0:V.openPath)=="function"){q.shell.openPath(_?ja(S):S),ae.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((G=q==null?void 0:q.shell)==null?void 0:G.openExternal)=="function"?q.shell.openExternal(S).catch(()=>{typeof window<"u"&&window.open(S,"_blank")}):typeof window<"u"&&window.open(S,"_blank"),ae.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function ke(){typeof document<"u"&&(l.value=!!document.fullscreenElement,i.postMessage("FULLSCREEN_CHANGED",{isFullscreen:l.value}))}function Ie(){const S=s.value||r.value;S&&(document.fullscreenElement?document.exitFullscreen().then(()=>{i.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):S.requestFullscreen().then(()=>{i.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function R(){o&&typeof o.openPresenterTab=="function"&&o.openPresenterTab()}async function ie(){if(!T){ae.showMessage("请先在主编辑区打开幻灯片文档");return}const S=await Oo(T,o==null?void 0:o.currentDocId,o),_=Ka(T,{title:S});Ya(`${S}.html`,_)&&ae.showMessage(`已开始下载单文件离线 HTML 演示包 (${S}.html)`)}function B(){if(!T){ae.showMessage("请先在主编辑区打开幻灯片文档");return}Za(T)&&ae.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const H=pe(!1);async function v(){if(H.value){ae.showMessage("正在逐页导出幻灯片图片中，请稍候...",2e3);return}if(!T){ae.showMessage("请先在主编辑区打开幻灯片文档");return}H.value=!0;try{ae.showMessage("正在逐页导出幻灯片图片...",2e3);const S=await Oo(T,o==null?void 0:o.currentDocId,o),_=await ec(i,{title:S,onProgress:(L,q)=>{ae.showMessage(`正在导出幻灯片图片 (${L} / ${q})...`,1500)}});_.success?ae.showMessage(`🎉 成功导出 ${_.total||0} 张高清图片并保存为 ${S}.zip！`,4e3):ae.showMessage(`导出图片失败：${_.error||"未知异常"}`)}finally{H.value=!1}}async function F(){if(!T){ae.showMessage("请先在主编辑区打开幻灯片文档");return}ae.showMessage("正在导出当前幻灯片图片...",1500);const S=await Rs(i);if(S.success&&S.dataUrl){const _=await Oo(T,o==null?void 0:o.currentDocId,o),L=a.value||1,V=(c.value||1)>1?`${_}-${L}.png`:`${_}.png`;pl(V,S.dataUrl),ae.showMessage(`已下载当前页高清图片 (${V})`)}else ae.showMessage(`导出当前页图片失败：${S.error||"未知异常"}`)}async function z(){if(!T){ae.showMessage("请先在主编辑区打开幻灯片文档");return}ae.showMessage("正在复制当前幻灯片截图到剪贴板...",1500);const S=await Rs(i);if(S.success&&S.dataUrl)if(await ng(S.dataUrl))ae.showMessage(`已成功将第 ${a.value||1} 页幻灯片复制到剪贴板！`);else{const L=await Oo(T,o==null?void 0:o.currentDocId,o),q=a.value||1,G=(c.value||1)>1?`${L}-${q}.png`:`${L}.png`;pl(G,S.dataUrl),ae.showMessage(`剪贴板权限不可用，已自动下载为 ${G}`)}else ae.showMessage(`复制失败：${S.error||"未知异常"}`)}return t({updateDocument(S,_){k.value&&w.value&&_&&_!==w.value||(T=S,k.value&&!w.value&&(w.value=S.docId),c.value=S.slides.length,n.setDocId(S.docId),n.updateSlidesIndex(S.slides),i.updateSlides(S.slides,{...S.config,hostThemeMode:No()},S.customThemeCss),o&&typeof o.updatePreviewTabHeader=="function"&&o.updatePreviewTabHeader("",S.docId))},navigateToBlock(S){n.onCursorFocusBlock(S)},isPinned:k,pinnedDocId:w}),(S,_)=>(J(),ee("div",{class:"spm-slides-preview-tab",onKeydown:I},[f("div",dg,[f("div",ug,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:a.value<=1,"aria-label":"上一页",onClick:Z},[re(de,{name:"chevron-left"})],8,fg),f("span",hg,ve(a.value)+" / "+ve(c.value||1),1),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:a.value>=c.value,"aria-label":"下一页",onClick:ce},[re(de,{name:"chevron-right"})],8,pg),f("button",{class:xe(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":k.value}]),"aria-label":k.value?"已锁定当前文档（点击解除）："+w.value:"点击锁定当前文档（不随主编辑区切换）",onClick:O},[re(de,{name:"pin"}),f("span",null,ve(k.value?"已锁定":"跟随"),1)],10,mg)]),f("div",gg,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:N},[re(de,{name:"columns"})]),he(Dt)("presenterMode")?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:R},[re(de,{name:"presenter"})])):Te("",!0),he(Dt)("exportHtml")?(J(),ee("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:ie},[re(de,{name:"export-html"})])):Te("",!0),he(Dt)("exportPdf")?(J(),ee("button",{key:2,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:B},[re(de,{name:"export-pdf"})])):Te("",!0),he(Dt)("exportImage")?(J(),ee("div",yg,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出幻灯片为图片包 (ZIP)",onClick:v},[re(de,{name:"export-image"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",style:{padding:"2px 2px","margin-left":"-4px"},"aria-label":"更多图片导出选项",onClick:_[0]||(_[0]=eo(L=>u.value=!u.value,["stop"]))},[re(de,{name:"chevron-down"})]),u.value?(J(),ee("div",bg,[f("button",{class:"b3-menu__item",onClick:_[1]||(_[1]=L=>{v(),u.value=!1})},[..._[6]||(_[6]=[f("span",{class:"b3-menu__label"},"📦 导出全篇为图片包 (ZIP)",-1)])]),f("button",{class:"b3-menu__item",onClick:_[2]||(_[2]=L=>{F(),u.value=!1})},[..._[7]||(_[7]=[f("span",{class:"b3-menu__label"},"🖼️ 导出当前页为图片 (PNG)",-1)])]),f("button",{class:"b3-menu__item",onClick:_[3]||(_[3]=L=>{z(),u.value=!1})},[..._[8]||(_[8]=[f("span",{class:"b3-menu__label"},"📋 复制当前页至剪贴板",-1)])])])):Te("",!0)])):Te("",!0),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:oe},[re(de,{name:"refresh"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:Ie},[re(de,{name:"fullscreen"})])])]),f("div",{ref_key:"fullscreenContainerRef",ref:s,class:"spm-slides-tab__viewport spm-slides-fullscreen-container",onWheel:Y},[f("iframe",{ref_key:"sandboxIframeRef",ref:r,class:"spm-slides-tab__iframe",src:U.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,vg),re(Np,{visible:p.value,"onUpdate:visible":_[4]||(_[4]=L=>p.value=L),"is-maximized":y.value,"onUpdate:isMaximized":_[5]||(_[5]=L=>y.value=L),title:g.value,onClose:ne},{default:sa(()=>[d.value==="siyuan"&&h.value?(J(),to(Zp,{key:0,"block-id":h.value,title:g.value,plugin:he(o),onExternalJump:Ce},null,8,["block-id","title","plugin"])):Te("",!0),b.value?Ht((J(),to($m,{key:1,visible:p.value&&d.value==="web",url:m.value,title:g.value,onExternalJump:Ce},null,8,["visible","url","title"])),[[Bs,d.value==="web"]]):Te("",!0)]),_:1},8,["visible","is-maximized","title"]),Ht(f("div",{class:xe(["spm-jump-badge",{"is-invalid":A.value}])},ve(C.value),3),[[Bs,C.value]])],544)],32))}}),wg=so(kg,[["__scopeId","data-v-4f4e2799"]]);function ic(e){if(!e||e.length===0)return{maxStep:0,blockMap:new Map,idMap:new Map};const t=new Map,o=new Map,i=new Map;let n=0;const s=(r,a)=>{t.set(r,a);const c=r.id||r.blockId;c&&o.set(c,a)},l=e.filter(r=>r.slot!=="slot-divider-right");for(const r of l){if(r.parentContainerId&&r.parentClicks&&r.parentClicks.trim()!==""&&!i.has(r.parentContainerId)){const p=String(r.parentClicks).trim();if(/^\d+$/.test(p)){const y=parseInt(p,10);n=Math.max(n,y),i.set(r.parentContainerId,y)}else n+=1,i.set(r.parentContainerId,n)}if(!!!(r.clicks&&String(r.clicks).trim()!=="")){if(r.parentContainerId&&i.has(r.parentContainerId)){const p=i.get(r.parentContainerId);s(r,{type:"step",step:p})}else s(r,{type:"always"});continue}const c=String(r.clicks).trim();if(!c){n+=1,s(r,{type:"step",step:n});continue}if(c.startsWith("[")&&c.endsWith("]"))try{const p=JSON.parse(c);if(Array.isArray(p)&&p.length>=2){const y=Math.min(Number(p[0]),Number(p[1])),d=Math.max(Number(p[0]),Number(p[1]));if(!isNaN(y)&&!isNaN(d)){n=Math.max(n,d),s(r,{type:"range",min:y,max:d});continue}}}catch{}if(c.toLowerCase()==="hide"){n+=1,s(r,{type:"hide",step:n});continue}if(/^\+\d+$/.test(c)||c==="true"){const p=c==="true"?1:parseInt(c.slice(1),10)||1;n+=p,s(r,{type:"step",step:n});continue}if(/^-\d+$/.test(c)){const p=parseInt(c.slice(1),10)||1;n=Math.max(1,n-p),s(r,{type:"step",step:n});continue}if(/^\d+$/.test(c)){const p=parseInt(c,10);if(!isNaN(p)){n=Math.max(n,p),s(r,{type:"step",step:p});continue}}const u=parseInt(c,10);!isNaN(u)&&u>0?(n=Math.max(n,u),s(r,{type:"step",step:u})):(n+=1,s(r,{type:"step",step:n}))}return{maxStep:n,blockMap:t,idMap:o}}function xg(e,t,o){if(!e)return"v-click-visible";const i=e.id||e.blockId,n=o.blockMap.get(e)||(i?o.idMap.get(i):null);return!n||n.type==="always"?"v-click-visible":n.type==="range"?t>=n.min&&t<=n.max?"v-click-visible":"v-click-hidden":n.type==="hide"?t<n.step?"v-click-visible":"v-click-hidden":n.type==="step"?t>=n.step?"v-click-visible":"v-click-hidden":"v-click-visible"}const zs=980;function Sg(e){if(!e)return 0;const o=ic(e.blocks||[]).maxStep||0,i=e.frontmatter||{},n=i.mask;if(n!=="down"&&n!=="right")return o;const s=pd(i.maskRatio),r=i.maskInitial==="revealed"?Math.max(0,s.steps-1):s.steps;return Math.max(o,r)}function Cg(e,t=zs){const o=(e||"16/9").trim();let i=16/9;if(o==="4/3"||o==="4:3")i=4/3;else if(o==="16/10"||o==="16:10")i=16/10;else if(o.includes("/")||o.includes(":")){const s=o.includes("/")?"/":":",l=o.split(s).map(r=>parseFloat(r.trim()));l.length===2&&l[0]>0&&l[1]>0&&!isNaN(l[0])&&!isNaN(l[1])&&(i=l[0]/l[1])}else{const s=parseFloat(o);!isNaN(s)&&s>.2&&s<5&&(i=s)}const n=Math.ceil(t/i);return{baseWidth:t,baseHeight:n,ratio:i}}function ml(e,t,o=zs,i=552,n=16){const s=o>0?o:zs,l=i>0?i:552,r=Math.max(0,e-n),a=Math.max(0,t-n);if(r<=0||a<=0)return{scale:.36,boxWidth:Math.round(s*.36),boxHeight:Math.round(l*.36)};const c=Math.min(r/s,a/l),u=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:u,boxWidth:Math.max(1,Math.round(s*u)),boxHeight:Math.max(1,Math.round(l*u))}}function _g(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0,motion:t.motion?{...t.motion}:void 0,children:Array.isArray(t.children)?t.children.map(o=>({...o,attrs:o.attrs?{...o.attrs}:void 0,attributes:o.attributes?{...o.attributes}:void 0})):void 0})):[]}}function gl(e,t){if(!e)return"";const o=_g(e),i=o.frontmatter||{},n=i.layout||"default",s=(t==null?void 0:t.config)||{};(n==="image-right"||n==="image-left")&&!i.image&&!i.background&&s.image&&(i.image=s.image);const l=typeof(t==null?void 0:t.currentStep)=="number",r=l?Math.max(0,t.currentStep):0,a=l?ic(o.blocks||[]):null,u=Ga(o,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(t==null?void 0:t.allSlides)||[],currentPageIndex:(t==null?void 0:t.pageIndex)||o.pageIndex||1,highlight:!0,blockClassResolver:a?w=>{if(xg(w,r,a)==="v-click-hidden")return"presenter-v-click-pending";if(r>0){const A=w.id||w.blockId,M=a.blockMap.get(w)||(A?a.idMap.get(A):void 0);if((M==null?void 0:M.type)==="step"&&M.step===r||(M==null?void 0:M.type)==="range"&&M.min===r)return"presenter-v-click-active"}return""}:void 0}).replace(/<video\b([^>]*)>/gi,(w,C)=>{let A=C.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test(A)||(A+=" muted"),`<video ${A.trim()}>`}),p=i.spacing,y=p&&p!=="inherit"?p:s.spacing||"normal",d=["slide-content",`layout-${n}`,`spacing-${y}`,i.class||"",i.layoutClass||""].filter(Boolean).join(" "),h=[],m=(i.background||s.background||"").trim();if(m)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(m)){const w=m.startsWith("assets/")?`/${m}`:m.startsWith("./assets/")?m.slice(1):m;h.push(`background-image:url('${st(w)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else h.push(`background:${st(m)};`);const g=typeof i.zoom=="number"?i.zoom:typeof i.zoom=="string"?parseFloat(i.zoom):1,b=!isNaN(g)&&g>0?g:1;b!==1&&h.push(`width:${(100/b).toFixed(2)}%;height:${(100/b).toFixed(2)}%;transform-origin:top left;transform:scale(${b});`);const k=h.length>0?` style="${h.join("")}"`:"";return`<div class="${st(d)}"${k}>${u}</div>`}const Ig={class:"presenter-header"},$g={class:"presenter-title-area"},Mg={class:"presenter-brand"},Tg={class:"header-pills"},Ag={class:"pill pill-page"},Eg={key:0,class:"pill pill-step"},Bg={class:"header-toolbar"},Dg={class:"timer-capsule"},Lg={class:"timer-digits"},Og={class:"timer-actions"},Pg=["aria-label"],Ng={class:"wall-clock b3-tooltips b3-tooltips__sw","aria-label":"系统当前时间"},Rg={key:0,class:"presenter-grid"},zg={class:"slide-panels"},Hg={class:"panel-box current-slide-panel"},Fg={class:"panel-header"},jg={class:"panel-header-left"},Wg={class:"panel-page-num"},Ug={class:"panel-header-meta"},Vg={key:0,class:"panel-step-pill"},qg={class:"panel-layout-pill"},Gg=["aria-label"],Kg=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],Yg={key:1,class:"panel-fallback"},Zg=["aria-label"],Jg={class:"panel-header"},Xg={class:"panel-header-left"},Qg={key:0,class:"panel-page-num"},ey={class:"panel-header-meta"},ty={key:0,class:"panel-end-pill"},oy={key:1,class:"panel-layout-pill"},iy=["aria-label"],ny=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],sy={key:1,class:"panel-fallback"},ry={class:"notes-panel"},ly={class:"panel-header"},ay={class:"panel-header-left"},cy={class:"notes-size-controls"},dy=["disabled"],uy={class:"notes-size-value"},fy=["disabled"],hy={key:1,class:"presenter-empty"},py={class:"empty-icon-wrap"},my={class:"empty-actions"},gy={class:"presenter-actions"},yy={class:"nav-btn-group"},by=["disabled"],vy=["disabled"],ky={class:"actions-center"},wy={class:"center-meta"},xy={class:"progress-pill"},Sy={class:"nav-btn-group"},Cy=["aria-label"],_y={class:"step-dots-text"},Iy=["disabled"],$y=["disabled"],My=280,Ty=15,Ay=Nt({__name:"SlidesPresenterTab",setup(e,{expose:t}){const o=Wt("plugin"),i=Wt("sandboxBridge",new Zn),n=pe([]),s=pe({}),l=pe(1),r=pe(0),a=pe(0),c=pe(0),u=ye(()=>n.value.length||a.value),p=pe(null),y=pe(null),d=pe({width:0,height:0}),h=pe({width:0,height:0}),m=pe(No()),g=ye(()=>{var ue;return Cg((ue=s.value)==null?void 0:ue.aspectRatio)}),b=ye(()=>{var ue;return((ue=s.value)==null?void 0:ue.theme)||"apple-basic"}),k=ye(()=>{var ue;return fr((ue=s.value)==null?void 0:ue.colorSchema,m.value)}),w=ye(()=>{var ue;return!!((ue=s.value)!=null&&ue.normalizeHeadingSizes)}),C=ye(()=>{var ue;return((ue=s.value)==null?void 0:ue.showUnorderedListMarkers)===!1}),A=ye(()=>{var ue;return((ue=s.value)==null?void 0:ue.showOrderedListMarkers)===!1}),M=ye(()=>ml(d.value.width,d.value.height,g.value.baseWidth,g.value.baseHeight,14)),I=ye(()=>ml(h.value.width,h.value.height,g.value.baseWidth,g.value.baseHeight,14));function N(){p.value&&(d.value={width:p.value.clientWidth,height:p.value.clientHeight}),y.value&&(h.value={width:y.value.clientWidth,height:y.value.clientHeight})}let D=null;function U(){typeof window>"u"||typeof window.ResizeObserver!="function"||(D||(D=new window.ResizeObserver(()=>{N()})),D.disconnect(),p.value&&D.observe(p.value),y.value&&D.observe(y.value))}Yo([p,y,u],()=>{Mn(()=>{U(),N()})},{flush:"post"});const W=pe(0),E=pe(!0);let P=null,x=Date.now(),K=0;const j=ye(()=>{const ue=String(Math.floor(W.value/60)).padStart(2,"0"),fe=String(W.value%60).padStart(2,"0");return`${ue}:${fe}`});function $(){if(E.value){const ue=K+(Date.now()-x);W.value=Math.floor(ue/1e3)}}function T(){E.value?(K+=Date.now()-x,E.value=!1):(x=Date.now(),E.value=!0,$())}function O(){x=Date.now(),K=0,W.value=0}const te=pe("");let Y=null;function Z(){const ue=new Date,fe=String(ue.getHours()).padStart(2,"0"),Qe=String(ue.getMinutes()).padStart(2,"0");te.value=`${fe}:${Qe}`}const ce=ye(()=>n.value.length===0?null:n.value[l.value-1]||null),oe=ye(()=>l.value>=n.value.length?null:n.value[l.value]||null);function ne(ue){var St;const fe=ue==null?void 0:ue.frontmatter;if((fe==null?void 0:fe.colorSchema)==="light")return"light";if((fe==null?void 0:fe.colorSchema)==="dark")return"dark";if(typeof(fe==null?void 0:fe.class)=="string"){const at=fe.class.split(/\s+/);if(at.includes("light"))return"light";if(at.includes("dark"))return"dark"}const Qe=(fe==null?void 0:fe.background)||((St=s.value)==null?void 0:St.background),lt=Ha(Qe);return lt===!0?"light":lt===!1?"dark":k.value}const Ce=ye(()=>ne(ce.value)),_e=ye(()=>ne(oe.value)),ke=ye(()=>ce.value?Sg(ce.value):c.value),Ie=ye(()=>l.value>1||r.value>0),R=ye(()=>l.value<u.value||r.value<ke.value),ie=ye(()=>gl(ce.value,{config:s.value,allSlides:n.value,pageIndex:l.value,currentStep:r.value})),B=ye(()=>gl(oe.value,{config:s.value,allSlides:n.value,pageIndex:l.value+1})),H=ye(()=>{var fe;if(!ce.value)return"无内容";const ue=(fe=ce.value.blocks)==null?void 0:fe[0];return(ue==null?void 0:ue.content)||(ue==null?void 0:ue.rawMarkdown)||`第 ${l.value} 页`});function v(ue){return(ue||[]).slice(1).map(fe=>(fe.content||fe.rawMarkdown||"").trim()).filter(fe=>fe&&!/^(image\s+)?assets\/\S*$/i.test(fe)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(fe)).join(" | ").slice(0,120)}const F=ye(()=>{var ue;return v((ue=ce.value)==null?void 0:ue.blocks)}),z=ye(()=>{var fe;if(!oe.value)return"演示结束";const ue=(fe=oe.value.blocks)==null?void 0:fe[0];return(ue==null?void 0:ue.content)||(ue==null?void 0:ue.rawMarkdown)||`第 ${l.value+1} 页`}),S=ye(()=>oe.value?v(oe.value.blocks):"这是最后一页"),_=ye(()=>{var ue;return((ue=ce.value)==null?void 0:ue.notes)||""}),L=pe(20);function q(){L.value<36&&(L.value+=2)}function V(){L.value>14&&(L.value-=2)}const G=ye(()=>u.value<=1?100:Math.round(l.value/u.value*100));let X=null;try{X=new BroadcastChannel("siyuan-slides-sync"),X.onmessage=ue=>{const fe=ue.data;if(fe&&(fe.type==="SYNC_PAGE"&&typeof fe.page=="number"&&(l.value=fe.page,r.value=typeof fe.step=="number"?Math.max(0,fe.step):0,typeof fe.maxStep=="number"&&(c.value=Math.max(0,fe.maxStep))),fe.type==="SYNC_SLIDES"&&Array.isArray(fe.slides)&&(n.value=fe.slides,fe.config&&typeof fe.config=="object"&&(s.value=fe.config)),fe.type==="REQUEST_SYNC"&&n.value.length>0))try{X==null||X.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(n.value)),config:JSON.parse(JSON.stringify(s.value||{}))}),X==null||X.postMessage({type:"SYNC_PAGE",page:l.value,step:r.value,maxStep:ke.value})}catch{}}}catch{X=null}function le(ue,fe=0){const Qe=Number(ue)||1,lt=Math.max(0,Number(fe)||0);i.navigatePage(Qe,lt);try{X==null||X.postMessage({type:"SYNC_PAGE",page:Qe,step:lt,maxStep:ke.value})}catch{}}function se(){if(r.value<ke.value){r.value++,le(l.value,r.value);return}l.value<u.value&&(l.value++,r.value=0,le(l.value,0))}function me(){if(r.value>0){r.value--,le(l.value,r.value);return}l.value>1&&(l.value--,r.value=0,le(l.value,0))}function Se(){l.value<u.value&&(l.value++,r.value=0,le(l.value,0))}function we(){l.value>1&&(l.value--,r.value=0,le(l.value,0))}function Le(){l.value=1,r.value=0,O(),le(1,0)}function He(){const ue=o;typeof(ue==null?void 0:ue.openBottomPreviewTab)=="function"&&ue.openBottomPreviewTab()}function Ge(){const ue=o;typeof(ue==null?void 0:ue.openStandalonePreviewWindow)=="function"&&ue.openStandalonePreviewWindow()}function rt(ue){var fe,Qe;if(!(ue.key===" "&&((Qe=(fe=ue.target)==null?void 0:fe.closest)!=null&&Qe.call(fe,"button")))){if(ue.shiftKey&&ue.key==="ArrowRight"||ue.key==="ArrowDown"){ue.preventDefault(),Se();return}if(ue.shiftKey&&ue.key==="ArrowLeft"||ue.key==="ArrowUp"){ue.preventDefault(),we();return}ue.key==="ArrowRight"||ue.key===" "||ue.key==="PageDown"?(ue.preventDefault(),se()):(ue.key==="ArrowLeft"||ue.key==="PageUp")&&(ue.preventDefault(),me())}}let Ne=0;function ft(ue){var lt,St;if(Math.abs(ue.deltaY)<Ty)return;const fe=(St=(lt=ue.target)==null?void 0:lt.closest)==null?void 0:St.call(lt,".notes-content");if(fe){const at=fe.scrollHeight-fe.clientHeight;if(at>2&&(ue.deltaY>0&&fe.scrollTop<at-1||ue.deltaY<0&&fe.scrollTop>1))return}const Qe=Date.now();Qe-Ne<My||(Ne=Qe,ue.deltaY>0?se():me())}let tt=null,Ke=null;return wi(()=>{var fe;m.value=No(),Ke=Fa(Qe=>{m.value=Qe}),x=Date.now(),K=0,P=window.setInterval($,500),typeof document<"u"&&document.addEventListener("visibilitychange",$),Z(),Y=window.setInterval(Z,1e3),tt=i.onSlideChanged((Qe,lt,St,at,ro)=>{l.value=Qe,lt>0&&(a.value=lt),typeof at=="number"&&(r.value=Math.max(0,at)),typeof ro=="number"&&(c.value=Math.max(0,ro))});try{X==null||X.postMessage({type:"REQUEST_SYNC"})}catch{}const ue=o==null?void 0:o.latestCompiledDoc;(fe=ue==null?void 0:ue.slides)!=null&&fe.length&&(n.value=ue.slides,ue.config&&(s.value=ue.config)),typeof window<"u"&&window.addEventListener("resize",N),Mn(()=>{U(),N()})}),Vn(()=>{Ke&&(Ke(),Ke=null),P&&(window.clearInterval(P),P=null),typeof document<"u"&&document.removeEventListener("visibilitychange",$),Y&&(window.clearInterval(Y),Y=null),tt&&tt(),typeof window<"u"&&window.removeEventListener("resize",N),D&&(D.disconnect(),D=null);try{X==null||X.close()}catch{}X=null}),t({updateDocument(ue){var fe;(fe=ue==null?void 0:ue.slides)!=null&&fe.length&&(n.value=ue.slides),ue!=null&&ue.config&&(s.value=ue.config)}}),(ue,fe)=>{var Qe,lt,St;return J(),ee("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:rt,onWheel:ft},[f("header",Ig,[f("div",$g,[f("div",Mg,[re(de,{name:"presenter",class:"brand-icon"}),fe[1]||(fe[1]=f("span",{class:"title-name"},"演讲者控制台",-1))]),f("div",Tg,[f("span",Ag,"P."+ve(l.value)+" / "+ve(u.value||1),1),ke.value>0?(J(),ee("span",Eg,[re(de,{name:"step",class:"pill-icon"}),Bt(" 步进 "+ve(r.value)+" / "+ve(ke.value),1)])):Te("",!0)])]),f("div",Bg,[f("button",{class:"btn-tool b3-tooltips b3-tooltips__s","aria-label":"弹出大屏放映独立窗口 (16:9)",onClick:Ge},[re(de,{name:"window"}),fe[2]||(fe[2]=f("span",{class:"btn-tool-label"},"独立放映",-1))]),f("div",Dg,[re(de,{name:"clock",class:"timer-icon"}),f("span",Lg,ve(j.value),1),f("div",Og,[f("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":E.value?"暂停计时":"继续计时",onClick:T},[re(de,{name:E.value?"pause":"play"},null,8,["name"])],8,Pg),f("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":"重置计时",onClick:O},[re(de,{name:"reset"})])])]),f("div",Ng,[f("span",null,ve(te.value),1)])])]),u.value>0?(J(),ee("main",Rg,[f("section",zg,[f("div",Hg,[f("div",Fg,[f("div",jg,[fe[3]||(fe[3]=f("span",{class:"panel-tag is-current"},"当前放映",-1)),f("span",Wg,"P."+ve(l.value),1)]),f("div",Ug,[ke.value>0?(J(),ee("span",Vg," 步进 "+ve(r.value)+" / "+ve(ke.value),1)):Te("",!0),f("span",qg,ve(((lt=(Qe=ce.value)==null?void 0:Qe.frontmatter)==null?void 0:lt.layout)||"default"),1)])]),f("div",{ref_key:"currentPreviewRef",ref:p,class:"panel-preview","aria-label":H.value},[ce.value?(J(),ee("div",{key:0,class:"presenter-thumb-box",style:Qt({width:M.value.boxWidth+"px",height:M.value.boxHeight+"px"})},[f("div",{class:xe(["presenter-thumb-viewport slide-viewport","slides-theme-"+b.value]),"data-theme":Ce.value,"data-slides-theme":b.value,"data-normalize-headings":w.value?"true":"false","data-hide-unordered-markers":C.value?"true":"false","data-hide-ordered-markers":A.value?"true":"false",style:Qt({width:g.value.baseWidth+"px",height:g.value.baseHeight+"px",transform:"scale("+M.value.scale+")"}),innerHTML:ie.value},null,14,Kg)],4)):(J(),ee("div",Yg,[f("h2",null,ve(H.value),1),f("p",null,ve(F.value),1)]))],8,Gg)]),f("div",{class:xe(["panel-box next-slide-panel",{"is-clickable":!!oe.value,"b3-tooltips b3-tooltips__n":!!oe.value}]),"aria-label":oe.value?"点击直接跳至下一页":"",onClick:fe[0]||(fe[0]=at=>oe.value&&Se())},[f("div",Jg,[f("div",Xg,[fe[4]||(fe[4]=f("span",{class:"panel-tag"},"下一页预告",-1)),l.value<u.value?(J(),ee("span",Qg,"P."+ve(l.value+1),1)):Te("",!0)]),f("div",ey,[l.value>=u.value?(J(),ee("span",ty,"已到尾页")):oe.value?(J(),ee("span",oy,ve(((St=oe.value.frontmatter)==null?void 0:St.layout)||"default"),1)):Te("",!0)])]),f("div",{ref_key:"nextPreviewRef",ref:y,class:"panel-preview panel-preview--dim","aria-label":z.value},[oe.value?(J(),ee("div",{key:0,class:"presenter-thumb-box",style:Qt({width:I.value.boxWidth+"px",height:I.value.boxHeight+"px"})},[f("div",{class:xe(["presenter-thumb-viewport slide-viewport","slides-theme-"+b.value]),"data-theme":_e.value,"data-slides-theme":b.value,"data-normalize-headings":w.value?"true":"false","data-hide-unordered-markers":C.value?"true":"false","data-hide-ordered-markers":A.value?"true":"false",style:Qt({width:g.value.baseWidth+"px",height:g.value.baseHeight+"px",transform:"scale("+I.value.scale+")"}),innerHTML:B.value},null,14,ny)],4)):(J(),ee("div",sy,[f("h2",null,ve(z.value),1),f("p",null,ve(S.value),1)]))],8,iy)],10,Zg)]),f("section",ry,[f("div",ly,[f("div",ay,[re(de,{name:"notes",class:"panel-title-icon"}),fe[5]||(fe[5]=f("span",null,"讲稿备忘",-1))]),f("div",cy,[f("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"减小字体",disabled:L.value<=14,onClick:V},[re(de,{name:"minus"})],8,dy),f("span",uy,ve(L.value)+"px",1),f("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"增大字体",disabled:L.value>=36,onClick:q},[re(de,{name:"plus"})],8,fy)])]),f("div",{class:xe(["notes-content",{"is-empty":!_.value}]),style:Qt({fontSize:L.value+"px"})},ve(_.value||"（本页未设置演讲者备忘录）"),7)])])):(J(),ee("main",hy,[f("div",py,[re(de,{name:"refresh",class:"empty-icon"})]),fe[8]||(fe[8]=f("h2",null,"等待大屏放映数据",-1)),fe[9]||(fe[9]=f("p",null,"未检测到活跃的幻灯片数据，请先开启大屏放映端。",-1)),f("div",my,[f("button",{class:"btn-empty-action b3-tooltips b3-tooltips__n","aria-label":"在思源中打开底部演示预览页签",onClick:He},[re(de,{name:"presenter"}),fe[6]||(fe[6]=f("span",null,"打开大屏放映页签",-1))]),f("button",{class:"btn-empty-action btn-empty-action--popout b3-tooltips b3-tooltips__n","aria-label":"将放映端弹出为独立窗口 (16:9)",onClick:Ge},[re(de,{name:"window"}),fe[7]||(fe[7]=f("span",null,"弹出独立放映窗口",-1))])])])),f("footer",gy,[f("div",yy,[f("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__ne",disabled:l.value<=1,"aria-label":"快速返回上一页 (Shift + ←)",onClick:we},[re(de,{name:"chevrons-left"}),fe[10]||(fe[10]=f("span",null,"上一页",-1))],8,by),f("button",{class:"btn-nav btn-nav--step b3-tooltips b3-tooltips__n",disabled:!Ie.value,"aria-label":"回退一步 (←)",onClick:me},[re(de,{name:"chevron-left"}),fe[11]||(fe[11]=f("span",null,"上一步",-1))],8,vy)]),f("div",ky,[f("div",wy,[f("span",xy,ve(G.value)+"%",1)]),f("button",{class:"btn-restart b3-tooltips b3-tooltips__n","aria-label":"从第一页重新放映 (Home)",onClick:Le},[re(de,{name:"reset"}),fe[12]||(fe[12]=f("span",null,"重头放映",-1))])]),f("div",Sy,[ke.value>0?(J(),ee("div",{key:0,class:"step-dots-bar b3-tooltips b3-tooltips__n","aria-label":`步进进度: ${r.value} / ${ke.value}`},[(J(!0),ee(Je,null,It(ke.value,at=>(J(),ee("span",{key:at,class:xe(["step-dot",{"is-active":at<=r.value}])},null,2))),128)),f("span",_y,ve(r.value)+"/"+ve(ke.value),1)],8,Cy)):Te("",!0),f("button",{class:"btn-nav btn-nav--step btn-nav--primary b3-tooltips b3-tooltips__n",disabled:!R.value,"aria-label":"触发下一步骤或进入下一页 (Space / →)",onClick:se},[fe[13]||(fe[13]=f("span",null,"下一步",-1)),re(de,{name:"chevron-right"})],8,Iy),f("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__nw",disabled:l.value>=u.value,"aria-label":"跳过本页剩余步骤，直接进入下一页 (Shift + →)",onClick:Se},[fe[14]||(fe[14]=f("span",null,"下一页",-1)),re(de,{name:"chevrons-right"})],8,$y)])])],32)}}}),Ey=so(Ay,[["__scopeId","data-v-bb574b10"]]),By={class:"spm-layout-picker"},Dy={class:"spm-layout-picker__grid"},Ly=["title","onClick"],Oy={class:"spm-layout-icon"},Py={class:"spm-layout-label"},Ny=Nt({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const o=e,i=t,n=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function s(r){return o.modelValue===r||r==="cols-header"&&(o.modelValue==="two-cols-header"||o.modelValue==="three-cols-header")}function l(r){i("update:modelValue",r),i("change",r)}return(r,a)=>(J(),ee("div",By,[a[0]||(a[0]=f("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),f("div",Dy,[(J(),ee(Je,null,It(n,c=>f("div",{key:c.name,class:xe(["spm-layout-item",{active:s(c.name)}]),title:c.desc,onClick:u=>l(c.name)},[f("div",Oy,[re(de,{name:"layout-"+c.name},null,8,["name"])]),f("span",Py,ve(c.label),1)],10,Ly)),64))])]))}}),Ry=so(Ny,[["__scopeId","data-v-96c8a248"]]),zy={key:0,class:"spm-transition-selector__header"},Hy={class:"spm-transition-list"},Fy=["onClick"],jy={class:"spm-transition-meta"},Wy={class:"spm-transition-label"},Uy={class:"spm-transition-preview-box"},Vy=Nt({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const o=t,i=[{name:"slide-left",label:"向左滑入",desc:"向左滑入：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function n(s){o("update:modelValue",s),o("change",s)}return(s,l)=>(J(),ee("div",{class:xe(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Te("",!0):(J(),ee("div",zy,ve(e.title||"转场动效"),1)),f("div",Hy,[(J(),ee(Je,null,It(i,r=>f("div",{key:r.name,class:xe(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:a=>n(r.name)},[f("div",jy,[f("span",Wy,ve(r.label),1)]),f("div",Uy,[f("div",{class:xe(["spm-anim-cube","anim-"+r.name])},null,2)])],10,Fy)),64))])],2))}}),nc=so(Vy,[["__scopeId","data-v-b5051f69"]]),qy={class:"spm-section spm-section--page"},Gy={class:"spm-section-header"},Ky={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},Yy={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Zy={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},Jy={key:1,class:"spm-card-control"},Xy={class:"spm-control-header"},Qy={class:"spm-control-title-group"},eb={class:"spm-control-title"},tb={class:"spm-quick-chips"},ob=["onClick"],ib={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},nb=["value"],sb=["aria-label"],rb={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__sw",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},lb={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},ab={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},cb={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},db={class:"spm-card-control"},ub={class:"spm-control-header"},fb={class:"spm-control-title-group"},hb={class:"spm-control-title"},pb={class:"spm-segmented-group"},mb={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},gb={style:{display:"flex","align-items":"center","justify-content":"space-between"}},yb=["aria-label"],bb={class:"spm-quick-chips"},vb=["onClick"],kb=["value"],wb={style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}},xb={style:{display:"flex",gap:"8px","margin-top":"2px"}},Sb={style:{flex:"1"}},Cb={class:"spm-segmented-group"},_b={style:{flex:"1"}},Ib={class:"spm-segmented-group"},$b={class:"spm-card-control"},Mb={class:"spm-control-header"},Tb={class:"spm-control-title-group"},Ab={class:"spm-control-title"},Eb={class:"spm-segmented-group"},Bb={key:2,class:"spm-card-control"},Db={class:"spm-control-header"},Lb={class:"spm-control-title-group"},Ob={class:"spm-control-title"},Pb={class:"spm-quick-chips"},Nb=["onClick"],Rb=["value"],zb={class:"spm-card-control"},Hb={class:"spm-control-header"},Fb={class:"spm-control-title-group"},jb={class:"spm-control-title"},Wb={key:0,class:"spm-note-status-box"},Ub=["title"],Vb={class:"spm-action-grid",style:{"margin-top":"6px"}},qb={key:1,class:"spm-note-empty-box"},Gb={class:"spm-card-control"},Kb={class:"spm-action-grid"},Yb=Nt({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{}},emits:["update:pageLayout","update:pageTransition","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","insertDividerAfter","deleteDivider"],setup(e,{emit:t}){const o=e,i=t,n=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],s=ye(()=>{const k=o.pageMask;return k==="clockwise"||k==="counter-clockwise"||k==="cw"||k==="ccw"}),l=ye(()=>s.value?"1:1:1:1":"1:1"),r=ye(()=>o.pageMaskRatio||l.value);function a(k){i("update:pageMask",k),(!o.pageMaskRatio||o.pageMaskRatio==="1:1")&&i("update:pageMaskRatio","1:1:1:1")}function c(k){i("update:pageMask",k),(!o.pageMaskRatio||o.pageMaskRatio==="1:1:1:1")&&i("update:pageMaskRatio","1:1")}const u=ye(()=>o.pageMask==="clockwise"||o.pageMask==="counter-clockwise"||o.pageMask==="cw"||o.pageMask==="ccw"?`时钟走时规则：
• 顺时针：左上 → 右上 → 右下 → 左下
• 逆时针：左上 → 左下 → 右下 → 右上
• 每次点击时针旋转 90° 并扇形扫开 1/4 象限，全部揭开后翻页`:`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`),p=ye(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(o.pageLayout)),y=ye(()=>{var C,A;if(o.pageLayout==="two-cols-header"||o.pageLayout==="two-cols"||o.pageLayout==="image-left"||o.pageLayout==="image-right")return 2;if(o.pageLayout==="three-cols-header")return 3;const k=(o.pageLayoutRatio||"").trim();if(k.includes(":")){const M=k.split(":").filter(Boolean).length;if(M>=2&&M<=6)return M}const w=(o.detectedSbRatio||"").trim();if(w.includes(":")){const M=w.split(":").filter(Boolean).length;if(M>=2&&M<=6)return M}if((C=o.detectedSbInfo)!=null&&C.colCount&&o.detectedSbInfo.colCount>=2)return Math.min(o.detectedSbInfo.colCount,6);if((A=o.detectedSbInfo)!=null&&A.slots&&Array.isArray(o.detectedSbInfo.slots)){const M=o.detectedSbInfo.slots.length;if(M>=2&&M<=6)return M}return 2}),d=ye(()=>{const k=y.value;return k===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:k===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:k===5?[{label:"默认 1:1:1:1:1",value:""}]:k===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),h=ye(()=>o.pageLayoutRatio||"");function m(){const k=y.value||2,w=Array(k).fill("1").join(":");i("update:pageLayoutRatio",w),i("resetSuperblockRatio")}const g=ye(()=>{if(!o.pageNotes)return"";const k=o.pageNotes.replace(/[\r\n]+/g," ").trim();return k.length>50?k.slice(0,50)+"...":k}),b=[{label:"默认封面",value:"https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1920&q=80"},{label:"清空配图",value:""}];return(k,w)=>(J(),ee("div",qy,[f("div",Gy,[f("span",null,"幻灯片页面设置"+ve(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),re(Ry,{"model-value":e.pageLayout,onChange:w[0]||(w[0]=C=>k.$emit("update:pageLayout",C))},null,8,["model-value"]),!p.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(J(),ee("div",Ky,[f("div",Yy,[f("div",Zy,[re(de,{name:"sparkles"}),f("span",null,[w[29]||(w[29]=Bt("检测到本页横向超级块列宽比例：",-1)),f("b",null,ve(e.detectedSbRatio),1)])]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键应用超级块列宽并设为分栏",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:w[1]||(w[1]=C=>k.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[re(de,{name:"columns"}),w[30]||(w[30]=f("span",null,"设为分栏",-1))])])])):Te("",!0),p.value?(J(),ee("div",Jy,[f("div",Xy,[f("div",Qy,[f("div",eb,[re(de,{name:"ratio"}),w[31]||(w[31]=f("span",null,"分栏比例",-1))]),w[32]||(w[32]=f("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),f("div",tb,[(J(!0),ee(Je,null,It(d.value,C=>(J(),ee("button",{key:C.value,class:xe(["spm-chip",{active:h.value===C.value}]),onClick:A=>k.$emit("update:pageLayoutRatio",C.value)},ve(C.label),11,ob))),128))]),f("div",ib,[f("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:w[2]||(w[2]=C=>k.$emit("update:pageLayoutRatio",C.target.value)),onChange:w[3]||(w[3]=C=>k.$emit("update:pageLayoutRatio",C.target.value))},null,40,nb),e.detectedSbRatio?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":`读取超级块列宽比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:w[4]||(w[4]=C=>k.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[re(de,{name:"sparkles"}),w[33]||(w[33]=f("span",null,"读取",-1))],8,sb)):(J(),ee("button",rb,[re(de,{name:"sparkles"}),w[34]||(w[34]=f("span",null,"读取",-1))])),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"重置为等宽平均分布",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:m},[re(de,{name:"reset"}),w[35]||(w[35]=f("span",null,"重置",-1))])]),e.detectedSbRatio?(J(),ee("div",lb,[re(de,{name:"ratio"}),w[36]||(w[36]=f("span",null,"检测到思源超级块宽度：",-1)),f("code",ab,ve(e.detectedSbRatio),1)])):(J(),ee("div",cb,[re(de,{name:"ratio"}),w[37]||(w[37]=f("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Te("",!0),re(nc,{"model-value":e.pageTransition,onChange:w[5]||(w[5]=C=>k.$emit("update:pageTransition",C))},null,8,["model-value"]),f("div",db,[f("div",ub,[f("div",fb,[f("div",hb,[re(de,{name:"sparkles"}),w[38]||(w[38]=f("span",null,"页面动态蒙版",-1))]),w[39]||(w[39]=f("span",{class:"spm-control-desc"},"随着点击操作分段展露正文内容",-1))])]),f("div",pb,[f("button",{class:xe(["spm-segmented-item",{active:!e.pageMask}]),onClick:w[6]||(w[6]=C=>k.$emit("update:pageMask",""))}," 关闭 ",2),f("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:w[7]||(w[7]=C=>c("down"))}," 从上至下 ",2),f("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:w[8]||(w[8]=C=>c("right"))}," 从左至右 ",2),f("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="clockwise"||e.pageMask==="cw"}]),onClick:w[9]||(w[9]=C=>a("clockwise"))}," 顺时针 ↻ ",2),f("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="counter-clockwise"||e.pageMask==="ccw"}]),onClick:w[10]||(w[10]=C=>a("counter-clockwise"))}," 逆时针 ↺ ",2)]),e.pageMask?(J(),ee("div",mb,[f("div",gb,[w[41]||(w[41]=f("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),f("span",{class:"b3-tooltips b3-tooltips__sw","aria-label":u.value,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},[re(de,{name:"help"}),w[40]||(w[40]=f("span",null,"输入规则",-1))],8,yb)]),f("div",bb,[(J(),ee(Je,null,It(n,C=>f("button",{key:C.value,class:xe(["spm-chip",{active:r.value===C.value}]),onClick:A=>k.$emit("update:pageMaskRatio",C.value)},ve(C.label),11,vb)),64))]),f("input",{value:r.value,class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:w[11]||(w[11]=C=>k.$emit("update:pageMaskRatio",C.target.value)),onChange:w[12]||(w[12]=C=>k.$emit("update:pageMaskRatio",C.target.value))},null,40,kb),f("div",wb,ve(e.pageMask==="clockwise"||e.pageMask==="counter-clockwise"||e.pageMask==="cw"||e.pageMask==="ccw"?"时钟走时蒙版：默认 4 步旋转展露（1:1:1:1，每步 25% 扇形面积）":"提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数"),1),f("div",xb,[f("div",Sb,[w[42]||(w[42]=f("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),f("div",Cb,[f("button",{class:xe(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:w[13]||(w[13]=C=>k.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),f("button",{class:xe(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:w[14]||(w[14]=C=>k.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),f("div",_b,[w[43]||(w[43]=f("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),f("div",Ib,[f("button",{class:xe(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:w[15]||(w[15]=C=>k.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),f("button",{class:xe(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:w[16]||(w[16]=C=>k.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Te("",!0)]),f("div",$b,[f("div",Mb,[f("div",Tb,[f("div",Ab,[re(de,{name:"ratio"}),w[44]||(w[44]=f("span",null,"页面间距",-1))]),w[45]||(w[45]=f("span",{class:"spm-control-desc"},"覆盖本页内衬、内容间隙与正文行距",-1))])]),f("div",Eb,[f("button",{class:xe(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:w[17]||(w[17]=C=>k.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),f("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.pageSpacing==="compact"}]),"aria-label":"紧凑排版：外衬 16/28px，块距 8px，行高 1.45",onClick:w[18]||(w[18]=C=>k.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),f("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.pageSpacing==="normal"}]),"aria-label":"标准排版：外衬 32/48px，块距 14px，行高 1.60",onClick:w[19]||(w[19]=C=>k.$emit("update:pageSpacing","normal"))}," 标准 ",2),f("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:e.pageSpacing==="loose"}]),"aria-label":"宽松排版：外衬 52/72px，块距 22px，行高 1.75",onClick:w[20]||(w[20]=C=>k.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(J(),ee("div",Bb,[f("div",Db,[f("div",Lb,[f("div",Ob,[re(de,{name:"image"}),w[46]||(w[46]=f("span",null,"页面图片",-1))]),w[47]||(w[47]=f("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),f("div",Pb,[(J(),ee(Je,null,It(b,C=>f("button",{key:C.value,class:xe(["spm-chip",{active:e.pageImage===C.value}]),onClick:A=>k.$emit("update:pageImage",C.value)},ve(C.label),11,Nb)),64))]),f("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL 或思源本地资源路径 (如 assets/...)",onInput:w[21]||(w[21]=C=>k.$emit("update:pageImage",C.target.value)),onChange:w[22]||(w[22]=C=>k.$emit("update:pageImage",C.target.value))},null,40,Rb)])):Te("",!0),f("div",zb,[f("div",Hb,[f("div",Fb,[f("div",jb,[re(de,{name:"presenter"}),w[48]||(w[48]=f("span",null,"演讲者提词",-1))]),w[49]||(w[49]=f("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),he(Dt)("aiScript")?(J(),ee("button",{key:0,class:"spm-btn-text b3-tooltips b3-tooltips__sw","aria-label":"AI 自动生成本页讲稿提示块",onClick:w[23]||(w[23]=C=>k.$emit("generateNotes"))},[re(de,{name:"sparkles"}),w[50]||(w[50]=f("span",null,"AI 讲稿",-1))])):Te("",!0)]),e.pageNotes?(J(),ee("div",Wb,[w[53]||(w[53]=f("div",{class:"spm-note-status-badge"},[f("span",{class:"spm-badge-dot"}),f("span",null,"已配置正文讲稿")],-1)),f("div",{class:"spm-note-preview-text",title:e.pageNotes},ve(g.value),9,Ub),f("div",Vb,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:w[24]||(w[24]=C=>k.$emit("locateNoteBlock"))},[re(de,{name:"search"}),w[51]||(w[51]=f("span",null,"定位讲稿块",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在本页末尾追加新的讲稿提示块",onClick:w[25]||(w[25]=C=>k.$emit("addNoteBlock"))},[re(de,{name:"insert-below"}),w[52]||(w[52]=f("span",null,"追加讲稿块",-1))])])])):(J(),ee("div",qb,[w[55]||(w[55]=f("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:w[26]||(w[26]=C=>k.$emit("addNoteBlock"))},[re(de,{name:"insert-below"}),w[54]||(w[54]=f("span",null,"添加讲稿备注块",-1))])]))]),f("div",Gb,[w[58]||(w[58]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),f("div",Kb,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在此分页符之后插入新的空白分页",onClick:w[27]||(w[27]=C=>k.$emit("insertDividerAfter"))},[re(de,{name:"insert-below"}),w[56]||(w[56]=f("span",null,"插入新页",-1))]),f("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:w[28]||(w[28]=C=>k.$emit("deleteDivider"))},[re(de,{name:"trash"}),w[57]||(w[57]=f("span",null,"删除此页",-1))])])])]))}}),Zb=so(Yb,[["__scopeId","data-v-a1fde071"]]),Jb={class:"spm-section spm-section--block"},Xb={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},Qb={class:"spm-control-header"},ev={class:"spm-control-title-group"},tv={class:"spm-control-title"},ov={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},iv={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},nv={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},sv={key:0},rv={key:1},lv={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},av={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},cv={class:"spm-action-grid"},dv={key:1,class:"spm-card-control"},uv={class:"spm-control-header"},fv={class:"spm-control-title-group"},hv={class:"spm-control-title"},pv={class:"spm-quick-chips"},mv={key:2,class:"spm-card-control"},gv={class:"spm-control-header"},yv={class:"spm-control-title-group"},bv={class:"spm-control-title"},vv={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},kv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},wv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},xv=["aria-label"],Sv=["checked"],Cv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},_v={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Iv=["aria-label"],$v=["checked"],Mv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Tv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Av=["aria-label"],Ev=["checked"],Bv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Dv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Lv=["aria-label"],Ov=["checked"],Pv={class:"spm-card-control"},Nv={class:"spm-control-header"},Rv={class:"spm-control-title-group"},zv={class:"spm-control-title"},Hv=["aria-label"],Fv=["checked"],jv={key:0,class:"spm-quick-chips"},Wv=["onClick"],Uv={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Vv={class:"spm-card-control"},qv={class:"spm-control-header"},Gv={class:"spm-control-title-group"},Kv={class:"spm-control-title"},Yv=["aria-label"],Zv=["checked"],Jv={key:0,class:"spm-quick-chips"},Xv=["onClick"],Qv={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},e1={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},t1={style:{display:"flex",gap:"6px"}},o1=["value"],i1=["value"],n1={key:3,class:"spm-card-control"},s1={class:"spm-control-header"},r1={class:"spm-control-title-group"},l1={class:"spm-control-title"},a1={class:"spm-control-desc"},c1={class:"spm-segmented-group"},d1=["onClick"],u1={key:4,class:"spm-card-control"},f1={class:"spm-control-header"},h1={class:"spm-control-title-group"},p1={class:"spm-control-title"},m1={class:"spm-quick-chips"},g1=["onClick"],y1=["value"],b1={key:5,class:"spm-card-control"},v1={class:"spm-control-header"},k1={class:"spm-control-title-group"},w1={class:"spm-control-title"},x1={class:"spm-quick-chips"},S1=["onClick"],C1=["value"],_1={class:"spm-card-control"},I1={class:"spm-action-grid"},$1=["aria-label"],M1=["disabled","aria-label"],T1=Nt({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const o=e,i=ye(()=>{const M=o.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(o.elemSlot)?"cols-header":M}),n=ye(()=>{const M=i.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(M)}),s=ye(()=>{var I,N,D,U;if((I=o.detectedSbInfo)!=null&&I.colCount&&o.detectedSbInfo.colCount>=2)return Math.min(o.detectedSbInfo.colCount,6);const M=(N=o.elemSlot)==null?void 0:N.match(/^col-(\d+)$/);if(M){const W=parseInt(M[1],10);if(W>=2&&W<=6)return Math.max(W,3)}if(o.currentSlideLayout==="three-cols-header")return 3;if(o.currentSlideLayout==="two-cols-header"||o.currentSlideLayout==="two-cols")return 2;if((U=(D=o.detectedSbInfo)==null?void 0:D.ratio)!=null&&U.includes(":")){const W=o.detectedSbInfo.ratio.split(":").filter(Boolean);if(W.length>=2)return Math.min(W.length,6)}return 3}),l=ye(()=>{const M=i.value;return M==="cols-header"?"多栏插槽归属":M==="three-cols-header"?"三栏插槽归属":M==="two-cols-header"?"带表头双栏插槽":"多栏插槽归属"}),r=ye(()=>{const M=i.value;return M==="cols-header"?`在 cols-header 表头多栏（${s.value} 栏）中的内容块位置`:M==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":M==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":M==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=ye(()=>{const M=i.value;if(M==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(M==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(M==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const I=s.value,N=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let D=1;D<=I;D++)N.push({value:`col-${D}`,label:`第 ${D} 栏`});return N});function c(M){const I=o.elemSlot||"";return M?I===M||M==="col-1"&&I==="left"||M==="col-2"&&I==="center"||M==="col-3"&&I==="right"&&s.value===3||M==="col-2"&&I==="right"&&s.value===2||M==="left"&&I==="col-1"||M==="right"&&(I==="col-2"||I==="col-3"):!I||I==="default"}const u=t,p=[{label:"上浮",value:"slide-up"},{label:"淡入",value:"fade-in"},{label:"下沉",value:"slide-down"},{label:"左滑",value:"slide-left"},{label:"右滑",value:"slide-right"},{label:"缩放",value:"zoom-in"},{label:"弹性",value:"bounce"}],y=ye(()=>{if(!o.elemMotion||o.elemMotion.trim()===""||o.elemMotion.trim()==="none")return null;try{const M=JSON.parse(o.elemMotion);if(typeof M=="object"&&M!==null)return{preset:M.preset||M.type||"slide-up",duration:typeof M.duration=="number"?M.duration:0,delay:typeof M.delay=="number"?M.delay:0}}catch{}return{preset:o.elemMotion.trim(),duration:0,delay:0}}),d=ye(()=>!!y.value),h=ye(()=>{var M;return((M=y.value)==null?void 0:M.preset)||"slide-up"}),m=ye(()=>{var M;return((M=y.value)==null?void 0:M.duration)||0}),g=ye(()=>{var M;return((M=y.value)==null?void 0:M.delay)||0});function b(){d.value?u("update:elemMotion",""):u("update:elemMotion","slide-up")}function k(M){A(M,m.value,g.value)}function w(M){A(h.value,M,g.value)}function C(M){A(h.value,m.value,M)}function A(M,I,N){if(!M||M==="none"){u("update:elemMotion","");return}if(!I&&!N){u("update:elemMotion",M);return}const D={preset:M};I>0&&(D.duration=I),N>0&&(D.delay=N),u("update:elemMotion",JSON.stringify(D))}return(M,I)=>{var N,D,U,W,E,P;return J(),ee("div",Jb,[I[58]||(I[58]=f("div",{class:"spm-section-header"},[f("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(N=e.detectedSbInfo)!=null&&N.hasSuperBlock?(J(),ee("div",Xb,[f("div",Qb,[f("div",ev,[f("div",tv,[re(de,{name:"ratio"}),I[23]||(I[23]=f("span",null,"超级块列宽与布局",-1))]),I[24]||(I[24]=f("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),f("div",ov,[f("div",iv,[f("div",nv,[re(de,{name:"ratio"}),(D=e.detectedSbInfo)!=null&&D.isCustomWidth?(J(),ee("span",sv,"已识别自定义列宽比例")):(J(),ee("span",rv,"识别到 "+ve(((U=e.detectedSbInfo)==null?void 0:U.colCount)||2)+" 列超级块分栏",1))]),f("code",lv,ve(((W=e.detectedSbInfo)==null?void 0:W.ratio)||"1:1"),1)]),f("div",av,ve((E=e.detectedSbInfo)!=null&&E.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),f("div",cv,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:I[0]||(I[0]=x=>M.$emit("applySuperBlockLayout",e.detectedSbInfo))},[re(de,{name:"sparkles"}),I[25]||(I[25]=f("span",null,"应用版式与比例",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:I[1]||(I[1]=x=>{var K;return M.$emit("applySuperBlockRatio",((K=e.detectedSbInfo)==null?void 0:K.ratio)||"1:1")})},[re(de,{name:"check"}),f("span",null,"应用比例 ("+ve(((P=e.detectedSbInfo)==null?void 0:P.ratio)||"1:1")+")",1)])])])):Te("",!0),e.isImage||e.imageRole?(J(),ee("div",dv,[f("div",uv,[f("div",fv,[f("div",hv,[re(de,{name:"image"}),I[26]||(I[26]=f("span",null,"图片角色与分栏",-1))]),I[27]||(I[27]=f("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),f("div",pv,[f("button",{class:xe(["spm-chip",{active:!e.imageRole}]),onClick:I[2]||(I[2]=x=>M.$emit("update:imageRole",""))}," 普通内容 ",2),f("button",{class:xe(["spm-chip",{active:e.imageRole==="background"}]),onClick:I[3]||(I[3]=x=>M.$emit("update:imageRole","background"))},[re(de,{name:"image"}),I[28]||(I[28]=f("span",null,"背景图",-1))],2),f("button",{class:xe(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:I[4]||(I[4]=x=>M.$emit("update:imageRole","image-left"))},[re(de,{name:"image-left"}),I[29]||(I[29]=f("span",null,"图左",-1))],2),f("button",{class:xe(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:I[5]||(I[5]=x=>M.$emit("update:imageRole","image-right"))},[re(de,{name:"image-right"}),I[30]||(I[30]=f("span",null,"图右",-1))],2)])])):Te("",!0),e.isVideo?(J(),ee("div",mv,[f("div",gv,[f("div",yv,[f("div",bv,[re(de,{name:"video"}),I[31]||(I[31]=f("span",null,"视频播放设置",-1))]),I[32]||(I[32]=f("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),f("div",vv,[f("div",kv,[f("span",wv,[re(de,{name:"sliders"}),I[33]||(I[33]=Bt(" 控制条",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[f("input",{type:"checkbox",checked:!!e.videoControls,onChange:I[6]||(I[6]=x=>M.$emit("toggleVideoControls"))},null,40,Sv),I[34]||(I[34]=f("span",{class:"spm-switch-slider"},null,-1))],8,xv)]),f("div",Cv,[f("span",_v,[re(de,{name:"video"}),I[35]||(I[35]=Bt(" 自动播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[f("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:I[7]||(I[7]=x=>M.$emit("toggleVideoAutoplay"))},null,40,$v),I[36]||(I[36]=f("span",{class:"spm-switch-slider"},null,-1))],8,Iv)]),f("div",Mv,[f("span",Tv,[re(de,{name:"repeat"}),I[37]||(I[37]=Bt(" 循环播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[f("input",{type:"checkbox",checked:!!e.videoLoop,onChange:I[8]||(I[8]=x=>M.$emit("toggleVideoLoop"))},null,40,Ev),I[38]||(I[38]=f("span",{class:"spm-switch-slider"},null,-1))],8,Av)]),f("div",Bv,[f("span",Dv,[re(de,{name:"volume-x"}),I[39]||(I[39]=Bt(" 静音播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoMuted?"关闭静音":"开启静音"},[f("input",{type:"checkbox",checked:!!e.videoMuted,onChange:I[9]||(I[9]=x=>M.$emit("toggleVideoMuted"))},null,40,Ov),I[40]||(I[40]=f("span",{class:"spm-switch-slider"},null,-1))],8,Lv)])])])):Te("",!0),f("div",Pv,[f("div",Nv,[f("div",Rv,[f("div",zv,[re(de,{name:"step"}),I[41]||(I[41]=f("span",null,"逐步呈现",-1))]),I[42]||(I[42]=f("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[f("input",{type:"checkbox",checked:!!e.elemClick,onChange:I[10]||(I[10]=x=>M.$emit("toggleElemClick"))},null,40,Fv),I[43]||(I[43]=f("span",{class:"spm-switch-slider"},null,-1))],8,Hv)]),e.elemClick?(J(),ee("div",jv,[(J(),ee(Je,null,It(["+1","1","2","hide"],x=>f("button",{key:x,class:xe(["spm-chip",{active:e.elemClick===x}]),onClick:K=>M.$emit("update:elemClick",x)},ve(x==="+1"?"顺延 (+1)":x==="hide"?"隐藏":"第 "+x+" 步"),11,Wv)),64))])):e.parentElemClick?(J(),ee("div",Uv,[re(de,{name:"check"}),I[44]||(I[44]=f("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Te("",!0)]),f("div",Vv,[f("div",qv,[f("div",Gv,[f("div",Kv,[re(de,{name:"motion"}),I[45]||(I[45]=f("span",null,"入场微动效",-1))]),I[46]||(I[46]=f("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":d.value?"关闭微动效":"开启微动效"},[f("input",{type:"checkbox",checked:d.value,onChange:b},null,40,Zv),I[47]||(I[47]=f("span",{class:"spm-switch-slider"},null,-1))],8,Yv)]),d.value?(J(),ee("div",Jv,[(J(),ee(Je,null,It(p,x=>f("button",{key:x.value,class:xe(["spm-chip",{active:h.value===x.value}]),onClick:K=>k(x.value)},ve(x.label),11,Xv)),64))])):Te("",!0),d.value?(J(),ee("div",Qv,[f("div",e1,[f("span",null,"时长: "+ve(m.value?m.value+"ms":"默认 (450ms)"),1),f("span",null,"延迟: "+ve(g.value?g.value+"ms":"0ms"),1)]),f("div",t1,[f("select",{class:"spm-select",style:{flex:"1"},value:m.value,onChange:I[11]||(I[11]=x=>w(Number(x.target.value)))},[...I[48]||(I[48]=[f("option",{value:0},"默认耗时",-1),f("option",{value:200},"极速 (200ms)",-1),f("option",{value:350},"较快 (350ms)",-1),f("option",{value:500},"平滑 (500ms)",-1),f("option",{value:800},"缓慢 (800ms)",-1)])],40,o1),f("select",{class:"spm-select",style:{flex:"1"},value:g.value,onChange:I[12]||(I[12]=x=>C(Number(x.target.value)))},[...I[49]||(I[49]=[f("option",{value:0},"无延迟",-1),f("option",{value:150},"延迟 150ms",-1),f("option",{value:300},"延迟 300ms",-1),f("option",{value:500},"延迟 500ms",-1)])],40,i1)])])):Te("",!0)]),n.value||e.elemSlot?(J(),ee("div",n1,[f("div",s1,[f("div",r1,[f("div",l1,[re(de,{name:"columns"}),f("span",null,ve(l.value),1)]),f("span",a1,ve(r.value),1)])]),f("div",c1,[(J(!0),ee(Je,null,It(a.value,x=>(J(),ee("button",{key:x.value,class:xe(["spm-segmented-item",{active:c(x.value)}]),onClick:K=>M.$emit("update:elemSlot",x.value)},ve(x.label),11,d1))),128))])])):Te("",!0),e.isCodeBlock?(J(),ee("div",u1,[f("div",f1,[f("div",h1,[f("div",p1,[re(de,{name:"code"}),I[50]||(I[50]=f("span",null,"代码逐行聚光",-1))]),I[51]||(I[51]=f("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),f("div",m1,[(J(),ee(Je,null,It(["1-3","all","1|2|3","2-5"],x=>f("button",{key:x,class:xe(["spm-chip",{active:e.elemShikiLines===x}]),onClick:K=>M.$emit("update:elemShikiLines",x)},ve(x),11,g1)),64)),e.elemShikiLines?(J(),ee("button",{key:0,class:"spm-chip spm-chip-clear",onClick:I[13]||(I[13]=x=>M.$emit("update:elemShikiLines",""))}," 清空 ")):Te("",!0)]),f("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:I[14]||(I[14]=x=>M.$emit("update:elemShikiLines",x.target.value)),onChange:I[15]||(I[15]=x=>M.$emit("update:elemShikiLines",x.target.value))},null,40,y1)])):Te("",!0),e.isCodeBlock?(J(),ee("div",b1,[f("div",v1,[f("div",k1,[f("div",w1,[re(de,{name:"code"}),I[52]||(I[52]=f("span",null,"代码块限高",-1))]),I[53]||(I[53]=f("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),f("div",x1,[(J(),ee(Je,null,It(["240px","320px","400px","50%"],x=>f("button",{key:x,class:xe(["spm-chip",{active:e.elemMaxHeight===x||x==="50%"&&(e.elemMaxHeight==="50vh"||e.elemMaxHeight==="50%")}]),onClick:K=>M.$emit("update:elemMaxHeight",x)},ve(x),11,S1)),64)),e.elemMaxHeight?(J(),ee("button",{key:0,class:"spm-chip spm-chip-clear",onClick:I[16]||(I[16]=x=>M.$emit("update:elemMaxHeight",""))}," 自适应 ")):Te("",!0)]),f("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50%",onInput:I[17]||(I[17]=x=>M.$emit("update:elemMaxHeight",x.target.value)),onChange:I[18]||(I[18]=x=>M.$emit("update:elemMaxHeight",x.target.value))},null,40,C1)])):Te("",!0),f("div",_1,[I[57]||(I[57]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"快捷操作")])],-1)),f("div",I1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:I[19]||(I[19]=x=>M.$emit("insertDividerBefore"))},[re(de,{name:"insert-above"}),I[54]||(I[54]=f("span",null,"上方分页",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:I[20]||(I[20]=x=>M.$emit("insertDividerAfter"))},[re(de,{name:"insert-below"}),I[55]||(I[55]=f("span",null,"下方分页",-1))]),f("button",{class:xe(["spm-btn-action b3-tooltips b3-tooltips__se",{"spm-btn-action--active":!!e.isNote}]),"aria-label":e.isNote?"取消当前块的演示讲稿备注":"将当前块设为演示讲稿备注",onClick:I[21]||(I[21]=x=>M.$emit("toggleNote"))},[re(de,{name:"presenter"}),f("span",null,ve(e.isNote?"取消备注":"设为备注"),1)],10,$1),f("button",{class:xe(["spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw",{"is-disabled":!e.hasBlockAttrs}]),disabled:!e.hasBlockAttrs,"aria-label":e.hasBlockAttrs?"一键移除本块所有 custom-slides 演示属性":"当前块无演示属性",onClick:I[22]||(I[22]=x=>M.$emit("clearBlockAttrs"))},[re(de,{name:"broom"}),I[56]||(I[56]=f("span",null,"清除属性",-1))],10,M1)])])])}}}),A1={class:"spm-section spm-section--doc"},E1={class:"spm-card-control"},B1={class:"spm-control-header"},D1={class:"spm-control-title-group"},L1={class:"spm-control-title"},O1={class:"spm-theme-card-grid"},P1=["aria-label","onClick"],N1={key:0,class:"spm-bg-swatch-check"},R1={class:"spm-theme-card-label"},z1={class:"spm-card-control"},H1={class:"spm-control-header"},F1={class:"spm-control-title-group"},j1={class:"spm-control-title"},W1={class:"spm-bg-swatch-grid"},U1=["aria-label","onClick"],V1={key:0,class:"spm-bg-swatch-check"},q1={class:"spm-bg-swatch-label"},G1={class:"spm-bg-input-row"},K1=["value"],Y1={class:"spm-card-control"},Z1={class:"spm-control-header"},J1={class:"spm-control-title-group"},X1={class:"spm-control-title"},Q1={class:"spm-segmented-group"},e0={class:"spm-card-control"},t0={class:"spm-control-header"},o0={class:"spm-control-title-group"},i0={class:"spm-control-title"},n0={class:"spm-segmented-group"},s0={class:"spm-card-control"},r0={class:"spm-control-header"},l0={class:"spm-control-title-group"},a0={class:"spm-control-title"},c0={class:"spm-card-control"},d0={class:"spm-action-grid"},u0=["disabled"],f0=["disabled"],h0=["disabled"],p0=["disabled"],m0=["aria-expanded"],g0={class:"spm-advanced-toggle-label"},y0={key:0,class:"spm-advanced-content"},b0={class:"spm-card-control"},v0={class:"spm-control-header"},k0={class:"spm-control-title-group"},w0={class:"spm-control-title"},x0=["aria-label"],S0=["checked"],C0={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},_0=["value"],I0={class:"spm-card-control"},$0={class:"spm-control-header"},M0={class:"spm-control-title-group"},T0={class:"spm-control-title"},A0=["aria-label"],E0=["checked"],B0={class:"spm-card-control"},D0={class:"spm-control-header"},L0={class:"spm-control-title-group"},O0={class:"spm-control-title"},P0={class:"spm-list-markers-toggles",style:{display:"flex",gap:"8px","margin-top":"8px"}},N0={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},R0=["aria-label"],z0=["checked"],H0={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},F0=["aria-label"],j0=["checked"],W0=Nt({__name:"DocInspectorSection",props:{docTheme:{},docBackground:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{},isBatchProcessing:{type:Boolean}},emits:["update:docTheme","update:docBackground","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","addOrIdentifyNotes","clearNotes","autoAnimate","clearAnimations","aiAutoSplit","clearDividers","exportHtml","exportPdf"],setup(e){const t=Wt("plugin"),o=Yt,i=pe(!1),n=[{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"},{value:"tech",label:"科技 tech",desc:"科技风：现代无衬线排版、Emerald 绿青双色指示与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"}];function s(d){uo({enableWebServeJump:d}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({enableWebServeJump:d})}async function l(d){var h;uo({normalizeHeadingSizes:d}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({normalizeHeadingSizes:d}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((h=t.getActiveDocumentId)==null?void 0:h.call(t)))}async function r(d){var h;uo({showUnorderedListMarkers:d}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showUnorderedListMarkers:d}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((h=t.getActiveDocumentId)==null?void 0:h.call(t)))}async function a(d){var h;uo({showOrderedListMarkers:d}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showOrderedListMarkers:d}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((h=t.getActiveDocumentId)==null?void 0:h.call(t)))}function c(d){uo({webServeUrl:d})}function u(d){uo({webServeUrl:d}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({webServeUrl:d})}const p=[{label:"默认",value:"",mode:"auto",desc:"跟随当前幻灯片主题与明暗模式自适应底色"},{label:"极简白",value:"#ffffff",mode:"light",desc:"纯净高对比白底 (#ffffff)，自动切换深色文字"},{label:"暖羊皮",value:"#f5efe6",mode:"light",desc:"温润护眼米棕纸张底 (#f5efe6)，自动切换深色文字"},{label:"晴空薄荷",value:"linear-gradient(135deg, #e0f2fe 0%, #dcfce7 100%)",mode:"light",desc:"清透天蓝至薄荷微渐变，自动切换深色文字"},{label:"晨曦微光",value:"linear-gradient(135deg, #fef3c7 0%, #fce7f3 100%)",mode:"light",desc:"柔和暖金至淡樱微渐变，自动切换深色文字"},{label:"曜石炭黑",value:"#18181b",mode:"dark",desc:"中性深炭黑 (#18181b)，区别于默认深海蓝底"},{label:"松墨深绿",value:"#0d2621",mode:"dark",desc:"沉稳森林墨绿 (#0d2621)，自动切换浅色文字"},{label:"极光紫青",value:"linear-gradient(135deg, #1e1b4b 0%, #0f3d4c 100%)",mode:"dark",desc:"深邃靛紫至极光青渐变，自动切换浅色文字"},{label:"深空靛蓝",value:"linear-gradient(135deg, #172554 0%, #312e81 100%)",mode:"dark",desc:"科技深空蓝至暮色紫渐变，自动切换浅色文字"}];function y(d){const h=(d||"").trim();return h?/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(h)?{backgroundImage:`url("${h.startsWith("assets/")?`/${h}`:h.startsWith("./assets/")?h.slice(1):h}")`,backgroundSize:"cover",backgroundPosition:"center"}:{background:h}:{background:"linear-gradient(135deg, #f8fafc 50%, #090d16 50%)"}}return(d,h)=>(J(),ee("div",A1,[h[65]||(h[65]=f("div",{class:"spm-section-header"},[f("span",null,"全局演示配置")],-1)),f("div",E1,[f("div",B1,[f("div",D1,[f("div",L1,[re(de,{name:"palette"}),h[29]||(h[29]=f("span",null,"幻灯片主题",-1))]),h[30]||(h[30]=f("span",{class:"spm-control-desc"},"全局幻灯片视觉设计范式",-1))])]),f("div",O1,[(J(),ee(Je,null,It(n,(m,g)=>f("button",{key:m.value,type:"button",class:xe(["spm-theme-card b3-tooltips",["is-"+m.value,g===0?"b3-tooltips__ne":g===n.length-1?"b3-tooltips__nw":"b3-tooltips__n",{active:e.docTheme===m.value}]]),"aria-label":m.desc,onClick:b=>d.$emit("update:docTheme",m.value)},[f("span",{class:xe(["spm-theme-card-preview","theme-preview--"+m.value]),"aria-hidden":"true"},[h[31]||(h[31]=ht('<span class="spm-theme-card-canvas"><span class="spm-theme-card-title">Aa</span><span class="spm-theme-card-lines"><span class="spm-theme-card-line is-primary"></span><span class="spm-theme-card-line is-secondary"></span></span></span>',1)),e.docTheme===m.value?(J(),ee("span",N1,"✓")):Te("",!0)],2),f("span",R1,ve(m.label),1)],10,P1)),64))])]),f("div",z1,[f("div",H1,[f("div",F1,[f("div",j1,[re(de,{name:"palette"}),h[32]||(h[32]=f("span",null,"演示背景",-1))]),h[33]||(h[33]=f("span",{class:"spm-control-desc"},"全篇幻灯片统一底色、微渐变或壁纸",-1))])]),f("div",W1,[(J(),ee(Je,null,It(p,m=>f("button",{key:m.value||"__default__",type:"button",class:xe(["spm-bg-swatch b3-tooltips b3-tooltips__n",{active:(e.docBackground||"")===m.value,"is-default":!m.value}]),"aria-label":m.desc,onClick:g=>d.$emit("update:docBackground",m.value)},[f("span",{class:"spm-bg-swatch-preview",style:Qt(y(m.value))},[f("span",{class:xe(["spm-bg-swatch-aa","is-"+m.mode])},"Aa",2),(e.docBackground||"")===m.value?(J(),ee("span",V1,"✓")):Te("",!0)],4),f("span",q1,ve(m.label),1)],10,U1)),64))]),f("div",G1,[f("span",{class:"spm-bg-input-preview",style:Qt(y(e.docBackground||"")),"aria-hidden":"true"},null,4),f("input",{value:e.docBackground||"",class:"spm-input spm-bg-input",placeholder:"自定义：#hex / gradient / assets/...",onInput:h[0]||(h[0]=m=>d.$emit("update:docBackground",m.target.value)),onChange:h[1]||(h[1]=m=>d.$emit("update:docBackground",m.target.value))},null,40,K1),e.docBackground?(J(),ee("button",{key:0,type:"button",class:"spm-bg-input-clear b3-tooltips b3-tooltips__nw","aria-label":"清除并恢复默认背景",onClick:h[2]||(h[2]=m=>d.$emit("update:docBackground",""))}," ✕ ")):Te("",!0)])]),f("div",Y1,[f("div",Z1,[f("div",J1,[f("div",X1,[re(de,{name:"ratio"}),h[34]||(h[34]=f("span",null,"画幅比例",-1))]),h[35]||(h[35]=f("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),f("div",Q1,[f("button",{class:xe(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:h[3]||(h[3]=m=>d.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),f("button",{class:xe(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:h[4]||(h[4]=m=>d.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),f("button",{class:xe(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:h[5]||(h[5]=m=>d.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),f("div",e0,[f("div",t0,[f("div",o0,[f("div",i0,[re(de,{name:"ratio"}),h[36]||(h[36]=f("span",null,"间距风格",-1))]),h[37]||(h[37]=f("span",{class:"spm-control-desc"},"内衬、内容间隙与正文行距预设",-1))])]),f("div",n0,[f("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__se",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：外衬 16/28px，块距 8px，行高 1.45",onClick:h[6]||(h[6]=m=>d.$emit("update:docSpacing","compact"))}," 紧凑 ",2),f("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：外衬 32/48px，块距 14px，行高 1.60（推荐默认）",onClick:h[7]||(h[7]=m=>d.$emit("update:docSpacing","normal"))}," 标准 ",2),f("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：外衬 52/72px，块距 22px，行高 1.75",onClick:h[8]||(h[8]=m=>d.$emit("update:docSpacing","loose"))}," 宽松 ",2)])]),f("div",s0,[f("div",r0,[f("div",l0,[f("div",a0,[re(de,{name:"transition"}),h[38]||(h[38]=f("span",null,"全局默认转场",-1))]),h[39]||(h[39]=f("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),re(nc,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:h[9]||(h[9]=m=>d.$emit("update:docDefaultTransition",m))},null,8,["model-value"])]),f("div",c0,[h[50]||(h[50]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"演示全局操作")])],-1)),f("div",d0,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:h[10]||(h[10]=m=>d.$emit("openBottomPreview"))},[re(de,{name:"split-preview"}),h[40]||(h[40]=f("span",null,"分屏预览",-1))]),he(Dt)("presenterMode")?(J(),ee("button",{key:0,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:h[11]||(h[11]=m=>d.$emit("openPresenter"))},[re(de,{name:"presenter"}),h[41]||(h[41]=f("span",null,"演讲者视图",-1))])):Te("",!0),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"识别已有候选讲稿并为空白页新增默认讲稿块（不会重复添加）",disabled:e.isBatchProcessing,onClick:h[12]||(h[12]=m=>d.$emit("addOrIdentifyNotes"))},[re(de,{name:"notes"}),h[42]||(h[42]=f("span",null,"增加讲稿块",-1))],8,u0),f("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"物理删除文档中所有页面的全部讲稿备注块（需二次确认）",disabled:e.isBatchProcessing,onClick:h[13]||(h[13]=m=>d.$emit("clearNotes"))},[re(de,{name:"trash"}),h[43]||(h[43]=f("span",null,"清除讲稿块",-1))],8,f0),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"自动为正文各页标题及首块之外的后续内容块配置顺延 (+1) 逐步呈现动效",disabled:e.isBatchProcessing,onClick:h[14]||(h[14]=m=>d.$emit("autoAnimate"))},[re(de,{name:"step"}),h[44]||(h[44]=f("span",null,"智能动效",-1))],8,h0),f("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"清除所有页面内容块的逐步显现与入场微动效配置（需二次确认）",disabled:e.isBatchProcessing,onClick:h[15]||(h[15]=m=>d.$emit("clearAnimations"))},[re(de,{name:"trash"}),h[45]||(h[45]=f("span",null,"清除动效",-1))],8,p0),he(Dt)("aiScript")?(J(),ee("button",{key:1,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"智能分析长文本大纲与篇幅，自动插入分页线",onClick:h[16]||(h[16]=m=>d.$emit("aiAutoSplit"))},[re(de,{name:"sparkles"}),h[46]||(h[46]=f("span",null,"智能分页",-1))])):Te("",!0),he(Dt)("aiScript")?(J(),ee("button",{key:2,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键清除当前文档中的所有幻灯片分页线",onClick:h[17]||(h[17]=m=>d.$emit("clearDividers"))},[re(de,{name:"trash"}),h[47]||(h[47]=f("span",null,"清除分页",-1))])):Te("",!0),he(Dt)("exportHtml")?(J(),ee("button",{key:3,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:h[18]||(h[18]=m=>d.$emit("exportHtml"))},[re(de,{name:"export-html"}),h[48]||(h[48]=f("span",null,"导出 HTML",-1))])):Te("",!0),he(Dt)("exportPdf")?(J(),ee("button",{key:4,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:h[19]||(h[19]=m=>d.$emit("exportPdf"))},[re(de,{name:"export-pdf"}),h[49]||(h[49]=f("span",null,"导出 PDF",-1))])):Te("",!0)])]),f("div",{class:xe(["spm-advanced-menu",{"is-expanded":i.value}])},[f("button",{type:"button",class:"spm-advanced-toggle","aria-expanded":i.value,onClick:h[20]||(h[20]=m=>i.value=!i.value)},[f("span",g0,[re(de,{name:"settings"}),h[51]||(h[51]=f("span",null,"高级设置",-1))]),re(de,{name:"chevron-right",class:"spm-advanced-chevron"})],8,m0),i.value?(J(),ee("div",y0,[f("div",b0,[f("div",v0,[f("div",k0,[f("div",w0,[re(de,{name:"external-link"}),h[52]||(h[52]=f("span",null,"本地网络伺服预览",-1))]),h[53]||(h[53]=f("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(o).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[f("input",{type:"checkbox",checked:he(o).enableWebServeJump,onChange:h[21]||(h[21]=m=>s(m.target.checked))},null,40,S0),h[54]||(h[54]=f("span",{class:"spm-switch-slider"},null,-1))],8,x0)]),he(o).enableWebServeJump?(J(),ee("div",C0,[f("input",{value:he(o).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:h[22]||(h[22]=eo(()=>{},["stop"])),onKeyup:h[23]||(h[23]=eo(()=>{},["stop"])),onInput:h[24]||(h[24]=m=>c(m.target.value)),onChange:h[25]||(h[25]=m=>u(m.target.value))},null,40,_0),h[55]||(h[55]=f("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Te("",!0)]),f("div",I0,[f("div",$0,[f("div",M0,[f("div",T0,[re(de,{name:"type"}),h[56]||(h[56]=f("span",null,"固定特定标题大小",-1))]),h[57]||(h[57]=f("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(o).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[f("input",{type:"checkbox",checked:he(o).normalizeHeadingSizes,onChange:h[26]||(h[26]=m=>l(m.target.checked))},null,40,E0),h[58]||(h[58]=f("span",{class:"spm-switch-slider"},null,-1))],8,A0)])]),f("div",B0,[f("div",D0,[f("div",L0,[f("div",O0,[re(de,{name:"list"}),h[59]||(h[59]=f("span",null,"列表前缀标记",-1))]),h[60]||(h[60]=f("span",{class:"spm-control-desc"},"分别控制正文中无序列表圆点与有序列表数字序号的呈现",-1))])]),f("div",P0,[f("div",N0,[h[62]||(h[62]=f("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"无序圆点",-1)),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(o).showUnorderedListMarkers?"关闭无序列表圆点显示":"开启无序列表圆点显示"},[f("input",{type:"checkbox",checked:he(o).showUnorderedListMarkers,onChange:h[27]||(h[27]=m=>r(m.target.checked))},null,40,z0),h[61]||(h[61]=f("span",{class:"spm-switch-slider"},null,-1))],8,R0)]),f("div",H0,[h[64]||(h[64]=f("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"有序序号",-1)),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(o).showOrderedListMarkers?"关闭有序列表序号显示":"开启有序列表序号显示"},[f("input",{type:"checkbox",checked:he(o).showOrderedListMarkers,onChange:h[28]||(h[28]=m=>a(m.target.checked))},null,40,j0),h[63]||(h[63]=f("span",{class:"spm-switch-slider"},null,-1))],8,F0)])])])])):Te("",!0)],2)]))}}),U0=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,V0=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function q0(e){const t=await Ja.loadAsync(e),o={},i=[];let n="",s="";const l=[];t.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(n=await r.file.async("string"),s=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||V0.test(c)||c.includes("snippets/")){const u=await a.file.async("string");o[c]=u;const p=c.split("/");p.length>1&&(o[p.slice(1).join("/")]=u)}else if(U0.test(c)){const u=await a.file.async("uint8array"),p=c.split("/").pop()||c,y=typeof Blob<"u"?new Blob([u]):void 0;i.push({zipPath:c,fileName:p,data:u,blob:y})}}return{entryMarkdown:n,entryMarkdownPath:s,virtualFiles:o,assets:i}}function G0(e,t){if(Object.keys(t).length===0)return e;function o(n){const s=n.trim().replace(/^['"]|['"]$/g,""),l=s.split("/").pop()||s;if(t[s])return t[s];const r=s.replace(/^\.?\//,"");return t[r]?t[r]:t[l]?t[l]:null}function i(n){let s=n;return s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=o(a);return c?`![${r}](${c})`:l}),s=s.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=o(r);return a?`src="${a}"`:l}),s}for(const n of e.slides)if(n.rawMarkdown=i(n.rawMarkdown),n.pageAttrs["custom-slides-background"]){const s=n.pageAttrs["custom-slides-background"],l=o(s);l&&(n.pageAttrs["custom-slides-background"]=l)}if(e.flattenedMarkdown=i(e.flattenedMarkdown),e.docRootAttrs["custom-slides-background"]){const n=e.docRootAttrs["custom-slides-background"],s=o(n);s&&(e.docRootAttrs["custom-slides-background"]=s)}return e}const K0={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`};function sc(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function Y0(e,t){const o=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!o)return null;const i=o[1].trim(),n=i.indexOf("#"),s=n!==-1?i.slice(0,n):i,l=n!==-1?i.slice(n+1):"",r=s.replace(/^@\//,"").replace(/^\.\//,""),a=(t==null?void 0:t.virtualFiles)||{};let c=a[s]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const d=r.split("/").pop();for(const[h,m]of Object.entries(a))if(h.endsWith(`/${r}`)||d&&h.endsWith(`/${d}`)){c=m;break}}if(!c){const d=[];if(t!=null&&t.baseDir)try{const h=require("path");d.push(h.resolve(t.baseDir,r)),d.push(h.resolve(t.baseDir,s))}catch{}try{const h=require("path");d.push(h.resolve(process.cwd(),r))}catch{}for(const h of d){const m=sc(h);if(m!==null){c=m;break}}}if(!c){const d=K0||{};if(c=d[s]||d[r]||d[`snippets/${r}`],!c){const h=r.split("/").pop();for(const[m,g]of Object.entries(d))if(m.endsWith(`/${r}`)||h&&m.endsWith(`/${h}`)){c=g;break}}}if(!c)return null;let u=c;if(l){const d=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),h=c.match(d);if(h){const m=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);u=(m?m[1]:"")+h[1].trimEnd()}}const p=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${p?p[1]:""}
${u}
\`\`\``}function Z0(e){let t=!1,o=!1;for(let i=0;i<e.length;i++){const n=e[i];if(n==="'"&&!o)t=!t;else if(n==='"'&&!t)o=!o;else if(n==="#"&&!t&&!o)return e.slice(0,i).trim()}return e.trim()}function gn(e){const t={},o=e.split(/\r?\n/);let i=0;for(;i<o.length;){const n=o[i],s=n.trim();if(!s||s.startsWith("#")){i++;continue}const l=n.indexOf(":");if(l>0){const r=n.slice(0,l).trim();let a=n.slice(l+1).trim();if(a==="|"||a===">"){i++;const c=[];let u=-1;for(;i<o.length;){const p=o[i];if(!p.trim()){c.push(""),i++;continue}const d=p.match(/^(\s+)/),h=d?d[1].length:0;if(u===-1&&(u=h),h<u)break;c.push(p.slice(u)),i++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=Z0(a),!a){let c=i+1;const u=[];let p=-1;for(;c<o.length;){const y=o[c],d=y.trim();if(!d||d.startsWith("#")){p!==-1&&u.push(""),c++;continue}const h=y.match(/^(\s+)/),m=h?h[1].length:0;if(p===-1)if(m>0)p=m;else break;if(m<p)break;u.push(y.slice(p)),c++}if(u.length>0){t[r]=gn(u.join(`
`)),i=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),t[r]=a}i++}return t}const J0=/^\s*```ya?ml([\s\S]*?)```/;function yl(e){let t={},o=e.trim();const i=o.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(i&&!i[1].includes("```")){const s=gn(i[1]);if(Object.keys(s).length>0||!i[1].trim())return t=s,o=o.slice(i[0].length).trim(),{frontmatter:t,content:o}}if(o.startsWith("---")){const s=o.match(/^---[^\n\r]*(?:\r?\n|$)/);s&&(o=o.slice(s[0].length).trim())}const n=o.match(J0);if(n)t=gn(n[1]),o=o.slice(n[0].length).trim();else{const s=o.split(/\r?\n/),l=[];let r=0;for(let a=0;a<s.length;a++){const c=s[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(t=gn(l.join(`
`)),o=s.slice(r).join(`
`).trim())}return{frontmatter:t,content:o}}function X0(e){const t=e.split(/\r?\n/),o=[];let i=0,n=!1;function s(l){if(i>=l)return;const r=t.slice(i,l).join(`
`).trim();r&&o.push(r),i=l+1}for(let l=0;l<t.length;l++){const a=t[l].trimEnd();if(n){a.includes("-->")&&(n=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(n=!0);continue}if(a.startsWith("---")){s(l);const c=t[l+1];let u=!1,p=-1;const y=c?c.trim():"";if(a.replace(/^-+/,"").trim()===""&&y.length>0){for(let d=l+1;d<t.length;d++){const h=t[d].trimEnd();if(h.startsWith("```"))break;if(h==="---"){p=d;break}}p!==-1&&p-l<=60&&t.slice(l+1,p).some(m=>{const g=m.trim();return g.length>0&&!g.startsWith("#")&&/^[a-zA-Z0-9_$-]+\s*:\s*.*/.test(g)})&&(u=!0)}u&&p!==-1&&(i=l,l=p)}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),u=c?c[0].trim():"```";let p=l+1;for(;p<t.length&&!t[p].trimStart().startsWith(u);p++);p<t.length&&(l=p)}}return i<t.length&&s(t.length),o}function yn(e,t={}){const{stripNotesFromMarkdown:o=!0,cleanVClicks:i=!0,cleanShikiLines:n=!0,cleanSlots:s=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=t;let u=e;u&&!u.trimStart().startsWith("---")&&(u=`---

${u.trimStart()}`);const p=X0(u),y={};let d="",h="",m=0;if(p.length>0){const W=p[0],E=yl(W),P=Object.keys(E.frontmatter).length>0,x=E.content.length>0;P&&!x&&p.length>1?(m=1,b(E.frontmatter)):P&&b(E.frontmatter)}function g(W,E,P){const x=String(W);x==="two-cols-header"?E[be]="cols-header":x==="three-cols-header"?(E[be]="cols-header",!P.layoutRatio&&!P["layout-ratio"]&&(E[mt]="1:1:1")):E[be]=x}function b(W){d=W.title||"",W.theme&&(y[ji]=String(W.theme)),W.aspectRatio&&(y[Wi]=String(W.aspectRatio)),W.transition&&(y[Ui]=String(W.transition)),W.colorSchema&&(y[$l]=String(W.colorSchema)),W.layout&&g(W.layout,y,W),W.background&&(y[ct]=String(W.background)),W.image&&(y[Ft]=String(W.image)),W.class&&(y[ni]=String(W.class));for(const[E,P]of Object.entries(W))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(E)||(y[`custom-slides-${E}`]=typeof P=="object"?JSON.stringify(P):String(P))}const k=[];let w=0,C=0,A=0,M=0;const I=new Set,N={};let D=1;for(let W=m;W<p.length;W++){const E=p[W],{frontmatter:P,content:x}=yl(E),K=E.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),j=P.src||(K?K[1]:void 0);if(j){const R=String(j).trim().replace(/^['"]|['"]$/g,"");let ie=c[R]||c[R.replace(/^\.\//,"")]||c[`pages/${R.replace(/^.*pages\//,"")}`];if(!ie){const H=R.replace(/^\.\//,""),v=[];if(t.baseDir)try{const F=require("path");v.push(F.resolve(t.baseDir,H)),v.push(F.resolve(t.baseDir,R))}catch{}try{const F=require("path");v.push(F.resolve(process.cwd(),H)),v.push(F.resolve(process.cwd(),R))}catch{}for(const F of v){const z=sc(F);if(z!==null){ie=z;break}}}const B={};P.layout&&g(P.layout,B,P),P.transition&&(B[wt]=String(P.transition)),P.background&&(B[ct]=String(P.background)),P.image&&(B[Ft]=String(P.image)),P.class&&(B[ni]=String(P.class));for(const[H,v]of Object.entries(P))["src","layout","transition","background","image","class"].includes(H)||(B[`custom-slides-${H}`]=typeof v=="object"?JSON.stringify(v):String(v));if(ie){const H=yn(ie,{...t,virtualFiles:c});for(const v of H.slides){v.pageIndex=D++,v.pageAttrs={...B,...v.pageAttrs},k.push(v);const F=v.pageAttrs[be]||"default";N[F]=(N[F]||0)+1}continue}else{k.push({pageIndex:D++,pageAttrs:{...B,"custom-slides-src":R},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${R}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const H=B[be]||"default";N[H]=(N[H]||0)+1;continue}}const $={};P.layout&&g(P.layout,$,P),P.transition&&($[wt]=String(P.transition)),P.background&&($[ct]=String(P.background)),P.image&&($[Ft]=String(P.image)),P.class&&($[ni]=String(P.class)),P.mask&&($[si]=String(P.mask)),(P.maskRatio||P["mask-ratio"])&&($[qo]=String(P.maskRatio||P["mask-ratio"])),(P.maskStyle||P["mask-style"])&&($[ri]=String(P.maskStyle||P["mask-style"])),(P.maskInitial||P["mask-initial"])&&($[li]=String(P.maskInitial||P["mask-initial"]));for(const[R,ie]of Object.entries(P))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(R)||($[`custom-slides-${R}`]=typeof ie=="object"?JSON.stringify(ie):String(ie));let T=x;const O=[];let te=T.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,R=>{const ie=`__CODE_TOKEN_NOTE_${O.length}__`;return O.push(R),ie});te=te.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,R=>{const ie=`__CODE_TOKEN_NOTE_${O.length}__`;return O.push(R),ie});let Y="";const Z=Array.from(te.matchAll(/<!--([\s\S]*?)-->/g));if(Z.length>0){const R=Z[Z.length-1],ie=te.slice(R.index+R[0].length).trim();if(!ie||!ie.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const H=R[1].trim();H.startsWith("TODO:")||(Y=H,w++),o&&(te=te.slice(0,R.index).trimEnd()+te.slice(R.index+R[0].length))}}o&&(te=te.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let R=0;R<O.length;R++)te=te.replace(`__CODE_TOKEN_NOTE_${R}__`,()=>O[R]);if(T=te,Y){for(let B=0;B<O.length;B++)Y=Y.replace(`__CODE_TOKEN_NOTE_${B}__`,()=>O[B]);const ie=`> [!NOTE] 💡 演讲备注
${Y.split(/\r?\n/).map(B=>`> ${B}`).join(`
`)}
{: custom-slides-note="true"}`;T=T?`${T}

${ie}`:ie}let ce=!1;if(/<style\b/i.test(T)){ce=!0;const R=T.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(R){for(const ie of R){const B=ie.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();h=h?`${h}

${B}`:B}l&&(T=T.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const oe=T.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);oe&&(C+=oe.length);const ne=T.match(/```\w+\s+\{[^}]+\}/g);ne&&(A+=ne.length);const Ce=T.match(/::\w+::|<template\s+#[^>]+>/g);if(Ce&&(M+=Ce.length),T=T.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,R=>Y0(R,{...t,virtualFiles:c})||R),i&&(T=T.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),n&&(T=T.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),T=T.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),s&&(T=T.replace(/^::\w+::\s*$/gm,"")),r&&(T=Xf(T)),a){let R=T.trim(),ie="";const B=R.lastIndexOf("> [!NOTE] 💡 演讲备注");if(B!==-1&&(ie=R.slice(B),R=R.slice(0,B).trim()),(P.layout==="image-left"||P.layout==="image-right")&&P.image){const H=String(P.image).trim(),v=P.layout==="image-left"?"image-left":"image-right",F=`![配图](${H})
{: custom-slides-layout="${v}" }`;P.layout==="image-left"?R=`{{{col

${F}

${R}

}}}`:R=`{{{col

${R}

${F}

}}}`}if(P.background){const v=`![背景图](${String(P.background).trim()})
{: custom-slides-role="background" }`;R=R?`${v}

${R}`:v}T=ie?`${R}

${ie}`:R}const _e=Q0(T);$[ct]&&_e.push($[ct]),$[Ft]&&_e.push($[Ft]);for(const R of _e)I.add(R);const ke=/<[A-Z][a-zA-Z0-9]+/.test(T),Ie=$[be]||(D===1?y[be]||"cover":"default");N[Ie]=(N[Ie]||0)+1,k.push({pageIndex:D++,pageAttrs:$,notes:Y,rawMarkdown:T,hasVueComponent:ke,hasStyleTag:ce,assetReferences:_e})}if(!d&&k.length>0){const W=k[0].rawMarkdown.match(/^#\s+(.+)$/m);W&&(d=W[1].trim())}h&&(y["custom-slides-custom-css"]=h);let U=k.map(W=>`---

${W.rawMarkdown}`).join(`

`);return U.trimStart().startsWith("---")||(U=`---

${U.trimStart()}`),{docTitle:d||"Slidev 演示文稿",docRootAttrs:y,slides:k,totalSlides:k.length,stats:{totalNotes:w,totalVClicks:C,totalShikiHighlights:A,totalSlots:M,discoveredAssets:Array.from(I),layoutDistribution:N},flattenedMarkdown:U,customCss:h}}function Q0(e){const t=[],o=/!\[.*?\]\((.*?)\)/g;let i;for(;(i=o.exec(e))!==null;){const s=i[1].split(/\s+/)[0].trim();s&&t.push(s)}const n=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(i=n.exec(e))!==null;){const s=i[1].trim();s&&t.push(s)}return t}function rc(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),o=String(e.markdown||"").trim(),i=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||o==="---"||o==="***"||i==="---"||i==="***"}function ek(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function tk(e,t,o=ze){const i=e.filter(rc);let n=0;if(i.length>=t.length)for(let s=0;s<t.length;s++){const l=t[s],r=i[s];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await o(r.id,l.pageAttrs),n++)}else for(let s=1;s<t.length;s++){const l=t[s],r=i[s-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await o(r.id,l.pageAttrs),n++)}return n}async function ok(e,t=ze){let o=!1,i=0;for(const n of e){if(rc(n)){o=!1;continue}const s=(n.markdown||n.content||"").trim();if(s==="::right::"||s.startsWith("::right::")){o=!0;continue}o&&n.id&&(await t(n.id,{[Me]:"right"}).catch(()=>{}),i++)}return i}async function ik(e,t,o=Sl){const i={};if(!t||t.length===0)return i;const n=[];for(const s of t){const l=new File([s.data],s.fileName,{type:"application/octet-stream"});n.push(l)}try{const s=await o("/data/assets",n);if(s!=null&&s.succMap)for(const[l,r]of Object.entries(s.succMap))i[l]=String(r)}catch(s){console.warn("上传本地静态资产失败，保留原路径:",s)}return Object.keys(i).length>0&&G0(e,i),i}async function nk(e){var k;const{presentation:t,notebookId:o,docTitle:i,extractedAssets:n=[],uploadAssets:s=!0,autoPreview:l=!0,plugin:r,api:a={}}=e,c=a.uploadFn||Sl,u=a.createDocFn||ad,p=a.setAttrsFn||ze,y=a.getChildBlocksFn||bi,d=a.openTabFn||ae.openTab,h=a.showMessageFn||ae.showMessage;s&&n.length>0&&await ik(t,n,c);const m=ek(i),g=`/${m}`,b=await u(o,g,t.flattenedMarkdown);if(!b)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");try{const w=((k=t.slides[0])==null?void 0:k.pageAttrs)||{};await p(b,{...w,...t.docRootAttrs});const C=await y(b).catch(()=>[]);Array.isArray(C)&&C.length>0&&(await tk(C,t.slides,p),await ok(C,p))}catch(w){console.warn("[SlidesImport] 版式属性回填阶段遇到警告:",w),h(`⚠️ 文档已创建(${m})，但部分版式属性回填未完全完成: ${w.message||String(w)}`,6e3)}return h(`🎉 成功导入 Slidev 演示文档《${m}》！`),l&&r&&(r.currentDocId=b,await d({app:r.app,doc:{id:b}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),b}function sk(e){const t=pe("file"),o=pe(!1),i=pe(!1),n=pe(""),s=pe(null),l=pe(null),r=pe(""),a=pe(0),c=pe(""),u=pe([]),p=pe(null),y=pe(""),d=pe([]),h=pe(""),m=pe(!0),g=pe(!0),b=pe(!0),k=pe(!0),w=ye(()=>{const $=a.value;if($===0)return"0 B";const T=1024,O=["B","KB","MB","GB"],te=Math.floor(Math.log($)/Math.log(T));return`${($/T**te).toFixed(1)} ${O[te]}`}),C=ye(()=>{var $;return(($=p.value)==null?void 0:$.docRootAttrs["custom-slides-theme"])||"default"}),A=ye(()=>{var $;return u.value.length>0?u.value.length:(($=p.value)==null?void 0:$.stats.discoveredAssets.length)||0}),M=ye(()=>{var T;const $=((T=p.value)==null?void 0:T.stats.layoutDistribution)||{};return Object.entries($).map(([O,te])=>({name:O,count:te}))});async function I($=ld){try{const T=await $();T!=null&&T.notebooks&&Array.isArray(T.notebooks)&&(d.value=T.notebooks.filter(O=>!O.closed),d.value.length>0&&!h.value&&(h.value=d.value[0].id))}catch(T){console.warn("获取笔记本列表失败:",T)}}function N(){var $;($=s.value)==null||$.click()}function D(){l.value=null,r.value="",a.value=0,p.value=null,u.value=[],n.value=""}let U=0;async function W($){const T=++U;n.value="",l.value=$,r.value=$.name,a.value=$.size;try{if($.name.toLowerCase().endsWith(".zip")){const te=await $.arrayBuffer();if(T!==U)return;const Y=await q0(te);if(T!==U)return;if(!Y.entryMarkdown){n.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=Y.assets;const Z=yn(Y.entryMarkdown,{stripNotesFromMarkdown:g.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,virtualFiles:Y.virtualFiles});if(T!==U)return;p.value=Z,y.value=Z.docTitle||$.name.replace(/\.zip$/i,"")}else{const te=await $.text();if(T!==U)return;u.value=[];const Y=$.path||"",Z=Y?Y.replace(/[\\/][^\\/]+$/,""):"",ce=yn(te,{stripNotesFromMarkdown:g.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,baseDir:Z||void 0});if(T!==U)return;p.value=ce,y.value=ce.docTitle||$.name.replace(/\.md$/i,"")}}catch(O){if(T!==U)return;console.error("解析文件失败:",O),n.value=`解析文件失败: ${O.message||String(O)}`}}function E(){if(n.value="",!c.value.trim()){p.value=null;return}try{const $=yn(c.value,{stripNotesFromMarkdown:g.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1});p.value=$,y.value=$.docTitle||"Slidev 演示文稿"}catch($){n.value=`解析 Markdown 源码失败: ${$.message||String($)}`}}async function P(){l.value?await W(l.value):c.value&&E()}async function x($){const T=$.target;T.files&&T.files[0]&&await W(T.files[0])}async function K($){var T;o.value=!1,(T=$.dataTransfer)!=null&&T.files&&$.dataTransfer.files[0]&&await W($.dataTransfer.files[0])}async function j($=e){if(p.value){if(!h.value&&d.value.length>0&&(h.value=d.value[0].id),!h.value){n.value="请先选择目标笔记本";return}i.value=!0,n.value="";try{return await nk({presentation:p.value,notebookId:h.value,docTitle:y.value,extractedAssets:u.value,uploadAssets:b.value,autoPreview:k.value,plugin:$})}catch(T){console.error("导入 Slidev 演示失败:",T),n.value=`导入执行失败: ${T.message||String(T)}`}finally{i.value=!1}}}return{inputMode:t,isDragging:o,isImporting:i,errorMessage:n,fileInputRef:s,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:u,parsedPresentation:p,customDocTitle:y,notebooks:d,selectedNotebookId:h,optCleanHtml:m,optStripNotes:g,optUploadAssets:b,optAutoPreview:k,formattedFileSize:w,currentTheme:C,extractedAssetsCount:A,layoutChips:M,fetchNotebooks:I,triggerFileInput:N,clearFile:D,processFile:W,onFileSelected:x,onFileDrop:K,onTextChange:E,reprocessCurrentInput:P,handleConfirmImport:j}}const rk={class:"spm-import-dialog"},lk={class:"spm-tabs-header"},ak={class:"spm-dialog-body"},ck={key:0,class:"spm-file-section"},dk={key:0,class:"spm-dropzone-prompt"},uk={class:"spm-dropzone-icon"},fk={key:1,class:"spm-dropzone-active"},hk={class:"spm-file-badge"},pk={class:"spm-file-size"},mk={key:1,class:"spm-text-section"},gk={key:2,class:"spm-error-banner"},yk={key:3,class:"spm-preview-card"},bk={class:"spm-preview-card__header"},vk={style:{display:"inline-flex","align-items":"center",gap:"4px"}},kk={class:"spm-config-grid"},wk={class:"spm-form-item"},xk={class:"spm-form-item"},Sk=["value"],Ck={class:"spm-stats-grid"},_k={class:"spm-stat-box"},Ik={class:"spm-stat-value"},$k={class:"spm-stat-box"},Mk={class:"spm-stat-value"},Tk={class:"spm-stat-box"},Ak={class:"spm-stat-value"},Ek={class:"spm-stat-box"},Bk={class:"spm-stat-value"},Dk={key:0,class:"spm-chips-row"},Lk={class:"spm-options-group"},Ok={class:"spm-checkbox-label"},Pk={class:"spm-checkbox-label"},Nk={class:"spm-checkbox-label"},Rk={class:"spm-checkbox-label"},zk={class:"spm-dialog-footer"},Hk=["disabled"],Fk=["disabled"],jk={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Wk={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Uk=Nt({__name:"SlidesImportDialog",emits:["close","success"],setup(e,{emit:t}){const o=t,i=Wt("plugin"),{inputMode:n,isDragging:s,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:u,extractedAssetsCount:p,parsedPresentation:y,customDocTitle:d,notebooks:h,selectedNotebookId:m,optCleanHtml:g,optStripNotes:b,optUploadAssets:k,optAutoPreview:w,formattedFileSize:C,currentTheme:A,layoutChips:M,fetchNotebooks:I,triggerFileInput:N,clearFile:D,onFileSelected:U,onFileDrop:W,onTextChange:E,reprocessCurrentInput:P,handleConfirmImport:x}=sk(i);wi(async()=>{await I()});async function K(){const $=await x();$&&(o("success",{docId:$}),o("close"))}function j(){o("close")}return($,T)=>(J(),ee("div",{class:"spm-modal-overlay",onClick:eo(j,["self"])},[f("div",rk,[f("div",{class:"spm-dialog-header"},[T[18]||(T[18]=f("div",{class:"spm-dialog-title"},[f("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[f("use",{"xlink:href":"#iconSlides"})]),f("span",null,"导入 Slidev 演示文档")],-1)),f("button",{class:"spm-close-btn",title:"关闭",onClick:j},"✕")]),f("div",lk,[f("button",{class:xe(["spm-tab-btn",{active:he(n)==="file"}]),onClick:T[0]||(T[0]=O=>n.value="file")},[re(de,{name:"package"}),T[19]||(T[19]=f("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),f("button",{class:xe(["spm-tab-btn",{active:he(n)==="text"}]),onClick:T[1]||(T[1]=O=>n.value="text")},[re(de,{name:"notes"}),T[20]||(T[20]=f("span",null,"粘贴 Markdown 源码",-1))],2)]),f("div",ak,[he(n)==="file"?(J(),ee("div",ck,[f("div",{class:xe(["spm-dropzone",{dragover:he(s),"has-file":!!he(c)}]),onDragover:T[4]||(T[4]=eo(O=>s.value=!0,["prevent"])),onDragleave:T[5]||(T[5]=eo(O=>s.value=!1,["prevent"])),onDrop:T[6]||(T[6]=eo((...O)=>he(W)&&he(W)(...O),["prevent"])),onClick:T[7]||(T[7]=(...O)=>he(N)&&he(N)(...O))},[f("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:T[2]||(T[2]=(...O)=>he(U)&&he(U)(...O))},null,544),he(c)?(J(),ee("div",fk,[f("span",hk,[re(de,{name:"notes"}),Bt(" "+ve(he(c)),1)]),f("span",pk,"("+ve(he(C))+")",1),f("button",{class:"spm-btn-text",onClick:T[3]||(T[3]=eo((...O)=>he(D)&&he(D)(...O),["stop"]))},"更换文件")])):(J(),ee("div",dk,[f("span",uk,[re(de,{name:"folder",style:{"font-size":"32px"}})]),T[21]||(T[21]=f("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),T[22]||(T[22]=f("p",{class:"spm-dropzone-hint"},[Bt(" 支持 Slidev 完整工程 "),f("strong",null,".zip"),Bt("（自动解包 public/ 静态素材）或单文件 "),f("strong",null,".md")],-1))]))],34)])):(J(),ee("div",mk,[Ht(f("textarea",{"onUpdate:modelValue":T[8]||(T[8]=O=>ot(u)?u.value=O:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:T[9]||(T[9]=(...O)=>he(E)&&he(E)(...O))},null,544),[[Ds,he(u)]])])),he(r)?(J(),ee("div",gk," ⚠️ "+ve(he(r)),1)):Te("",!0),he(y)?(J(),ee("div",yk,[f("div",bk,[f("span",vk,[re(de,{name:"sparkles"}),T[23]||(T[23]=Bt(" 演示解析摘要",-1))]),T[24]||(T[24]=f("span",{class:"spm-badge-success"},"预检就绪",-1))]),f("div",kk,[f("div",wk,[T[25]||(T[25]=f("label",{class:"spm-form-label"},"笔记文档标题",-1)),Ht(f("input",{"onUpdate:modelValue":T[10]||(T[10]=O=>ot(d)?d.value=O:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[Ds,he(d)]])]),f("div",xk,[T[26]||(T[26]=f("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Ht(f("select",{"onUpdate:modelValue":T[11]||(T[11]=O=>ot(m)?m.value=O:null),class:"spm-select"},[(J(!0),ee(Je,null,It(he(h),O=>(J(),ee("option",{key:O.id,value:O.id},ve(O.name),9,Sk))),128))],512),[[Df,he(m)]])])]),f("div",Ck,[f("div",_k,[f("span",Ik,ve(he(y).totalSlides),1),T[27]||(T[27]=f("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),f("div",$k,[f("span",Mk,ve(he(A)),1),T[28]||(T[28]=f("span",{class:"spm-stat-label"},"演示主题",-1))]),f("div",Tk,[f("span",Ak,ve(he(y).stats.totalNotes),1),T[29]||(T[29]=f("span",{class:"spm-stat-label"},"演讲者提词",-1))]),f("div",Ek,[f("span",Bk,ve(he(p)),1),T[30]||(T[30]=f("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),he(M).length>0?(J(),ee("div",Dk,[T[31]||(T[31]=f("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(J(!0),ee(Je,null,It(he(M),O=>(J(),ee("span",{key:O.name,class:"spm-chip-badge"},ve(O.name)+": "+ve(O.count),1))),128))])):Te("",!0),f("div",Lk,[f("label",Ok,[Ht(f("input",{"onUpdate:modelValue":T[12]||(T[12]=O=>ot(g)?g.value=O:null),type:"checkbox",onChange:T[13]||(T[13]=(...O)=>he(P)&&he(P)(...O))},null,544),[[an,he(g)]]),T[32]||(T[32]=f("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),f("label",Pk,[Ht(f("input",{"onUpdate:modelValue":T[14]||(T[14]=O=>ot(b)?b.value=O:null),type:"checkbox",onChange:T[15]||(T[15]=(...O)=>he(P)&&he(P)(...O))},null,544),[[an,he(b)]]),T[33]||(T[33]=f("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),f("label",Nk,[Ht(f("input",{"onUpdate:modelValue":T[16]||(T[16]=O=>ot(k)?k.value=O:null),type:"checkbox"},null,512),[[an,he(k)]]),T[34]||(T[34]=f("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),f("label",Rk,[Ht(f("input",{"onUpdate:modelValue":T[17]||(T[17]=O=>ot(w)?w.value=O:null),type:"checkbox"},null,512),[[an,he(w)]]),T[35]||(T[35]=f("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Te("",!0)]),f("div",zk,[f("button",{class:"spm-btn-secondary",disabled:he(l),onClick:j}," 取消 ",8,Hk),f("button",{class:"spm-btn-primary",disabled:!he(y)||he(l),onClick:K},[he(l)?(J(),ee("span",jk,[re(de,{name:"refresh"}),T[36]||(T[36]=Bt(" 正在导入生成中...",-1))])):(J(),ee("span",Wk,[re(de,{name:"rocket"}),T[37]||(T[37]=Bt(" 确认导入思源笔记",-1))]))],8,Fk)])])]))}}),Vk=so(Uk,[["__scopeId","data-v-c56a3d7e"]]);function hr(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function qk(e,t){var r;if(!e||e.length===0)return null;const o=t.activeBlockId||"",i=t.currentTopBlockId||o,n=t.currentPageDividerId||"",s=t.activeBlockType||"";if(hr(s)&&o){let a=e.find(c=>c.startBlockId===o);if(a||(a=e.find(c=>{var u,p;return((p=(u=c.blocks)==null?void 0:u[0])==null?void 0:p.id)===o}),a)||(a=e.find(c=>{var u;return(u=c.allBlockIds)==null?void 0:u.includes(o)}),a))return a}if(n){let a=e.find(c=>c.startBlockId===n);if(a||(a=e.find(c=>{var u,p;return((p=(u=c.blocks)==null?void 0:u[0])==null?void 0:p.id)===n}),a))return a}if(o){let a=e.find(u=>u.startBlockId===o);if(a||(a=e.find(u=>{var p,y;return((p=u.blocks)==null?void 0:p.some(d=>d.id===o))||((y=u.allBlockIds)==null?void 0:y.includes(o))}),a)||i&&i!==o&&(a=e.find(u=>{var p,y;return((p=u.blocks)==null?void 0:p.some(d=>d.id===i))||((y=u.allBlockIds)==null?void 0:y.includes(i))}),a)||(a=e.find(u=>{var p;return(p=u.noteBlocks)==null?void 0:p.some(y=>y.id===o||y.id===i)}),a))return a;const c=(r=t.activeBlockAttrs)==null?void 0:r[Me];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=e.find(u=>{var p,y;return((p=u.frontmatter)==null?void 0:p.layout)==="three-cols-header"||((y=u.blocks)==null?void 0:y.some(d=>d.slot==="col-1"||d.slot==="col-2"||d.slot==="col-3"))}),a))return a}return e[0]||null}function et(e,t){var n;if(typeof document>"u"||!e)return;const o=(n=globalThis.CSS)!=null&&n.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),i=document.querySelectorAll(`[data-node-id="${o}"]`);!i||i.length===0||i.forEach(s=>{for(const[l,r]of Object.entries(t))r!=null&&r!==""?s.setAttribute(l,String(r)):s.removeAttribute(l)})}function Gk(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${be}], .protyle-wysiwyg [${Ye}], .protyle-wysiwyg [custom-slides-layout], .protyle-wysiwyg [custom-slides-role]`,o=document.querySelectorAll(t);!o||o.length===0||o.forEach(i=>{const n=i.getAttribute("data-node-id");if(!n){i.removeAttribute(be),i.removeAttribute("custom-slides-layout"),i.removeAttribute(Ye),i.removeAttribute("custom-slides-role");return}const s=e.get(n),l=(s==null?void 0:s[be])||(s==null?void 0:s["custom-slides-layout"])||"",r=i.getAttribute(be)||i.getAttribute("custom-slides-layout");r&&r!==l&&(l?i.setAttribute(be,l):(i.removeAttribute(be),i.removeAttribute("custom-slides-layout")));const a=(s==null?void 0:s[Ye])||(s==null?void 0:s["custom-slides-role"])||"",c=i.getAttribute(Ye)||i.getAttribute("custom-slides-role");c&&c!==a&&(a?i.setAttribute(Ye,a):(i.removeAttribute(Ye),i.removeAttribute("custom-slides-role")))})}function Kk(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const o=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!o)return!1;const i=o.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(i==null?void 0:i.getAttribute("data-node-id"))===e}function Yk(e){let t=null;function o(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const u=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(u,1200):t=setTimeout(u,1200)}async function i(c){var d;const u=e.activeBlockId.value||e.currentDocId.value;if(!u)return;for(const[h,m]of Object.entries(c))e.activeBlockAttrs.value[h]=m;Be.setBlockAttrOverride(u,c),et(u,c);const p=(d=e.parentContainerId)==null?void 0:d.value,y=!!(p&&Kk(u,p));if(Oe in c&&y&&p){const h=c[Oe];e.parentContainerClicks&&(e.parentContainerClicks.value=h),Be.setBlockAttrOverride(p,{[Oe]:h}),et(p,{[Oe]:h}),ze(p,{[Oe]:h}).catch(()=>{})}if(be in c){const h=c[be];e.currentPageDividerLayout.value=h,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=h)}if(mt in c){const h=c[mt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=h)}o("保存中...");try{await ze(u,c),o("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{o("同步失败")}}async function n(c,u){await i({[c]:u})}function s(){var u;return(e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak")&&e.activeBlockId.value?e.activeBlockId.value:e.currentPageDividerId.value?e.currentPageDividerId.value:(u=e.targetSlide.value)!=null&&u.startBlockId&&e.targetSlide.value.startBlockId!==e.currentDocId.value?e.targetSlide.value.startBlockId:e.currentDocId.value}async function l(c,u){const p=s();if(p){p===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=u),Be.setBlockAttrOverride(p,{[c]:u}),et(p,{[c]:u}),c===be&&(e.currentPageDividerLayout.value=u,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=u)),c===mt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=u),o("保存中...");try{await ze(p,{[c]:u}),o("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{o("同步失败")}}}async function r(c,u){const p=s();if(!p)return;const y={[be]:c,[mt]:u};p===e.activeBlockId.value&&(e.activeBlockAttrs.value[be]=c,e.activeBlockAttrs.value[mt]=u),e.currentPageDividerLayout.value=c,Be.setBlockAttrOverride(p,y),et(p,y),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=u),o("应用排版中...");try{await ze(p,y),o("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{o("应用失败")}}async function a(c,u){var y;const p=e.currentDocId.value||e.activeBlockId.value;if(p){e.activeBlockAttrs.value[c]=u,Be.setBlockAttrOverride(p,{[c]:u}),et(p,{[c]:u}),(y=e.latestDoc.value)!=null&&y.config&&(c===ji&&(e.latestDoc.value.config.theme=u),c===Wi&&(e.latestDoc.value.config.aspectRatio=u),c===Ui&&(e.latestDoc.value.config.defaultTransition=u),c===wn&&(e.latestDoc.value.config.background=u)),o("更新中...");try{await ze(p,{[c]:u}),o("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(p)}catch{o("更新失败")}}}return{triggerSaveNotice:o,saveAttrs:i,saveAttr:n,getPageTargetBlockId:s,savePageAttr:l,applyPageLayoutAndRatio:r,saveDocAttr:a}}function bl(e){const t=(e.blocks||[]).filter(s=>{const l=(s.content||s.rawMarkdown||"").trim();return l&&l!=="---"});if(t.length===0)return"本页暂无内容，建议过渡承接上下文。";const o=[],i=[];for(const s of t){const l=(s.content||s.rawMarkdown||"").trim();l&&(s.type==="h"||l.startsWith("#")?o.push(l.replace(/^#+\s*/,"")):i.push(l.slice(0,50)))}const n=[];return o.length>0&&n.push(`【核心重点】：${o.join("、")}`),i.length>0&&(n.push("【口播要点】："),i.slice(0,3).forEach((s,l)=>{n.push(`${l+1}. 讲解 ${s}`)})),n.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),n.join(`
`)}async function lc(e,t){const o=e.blocks&&e.blocks.length>0?e.blocks.map(i=>(i.content||i.rawMarkdown||"").trim()).filter(i=>i&&i!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(t&&o){const i=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${o}`;try{const n=await t(i);if(n&&n.trim())return{notes:n.trim(),isAiGenerated:!0}}catch(n){return{notes:bl(e),isAiGenerated:!1,error:(n==null?void 0:n.message)||"AI 调用异常"}}}return{notes:bl(e),isAiGenerated:!1}}async function Zk(e,t){return(await lc(e,t)).notes}function Jk(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return!!(t==="callout"||t==="nodecallout"||t==="b"||t==="nodeblockquote"||String(e.markdown||"").trim().startsWith(">"))}function Xk(e,t){if(!((t==null?void 0:t[Ve])==="true"))return!1;const i=(e||"").trim();return/^>\s*\[!NOTE\]\s*(?:💡\s*)?(?:演讲备注|讲稿备注)/i.test(i)}async function ac(e,t){const i=await((t==null?void 0:t.getChildBlocksFn)||bi)(e).catch(()=>[]);if(!Array.isArray(i)||i.length===0)return[];const n=[];let s=[];for(const r of i){if(mo({...r,ial:{...r.ial||{},...Be.getBlockAttrOverride(r.id)||{}}})){if(n.length===0&&s.length===0)continue;n.push(s),s=[];continue}s.push(r)}n.push(s);const l=[];for(let r=0;r<n.length;r++){const a=n[r];if(!a||a.length===0)continue;let c=null;for(let h=a.length-1;h>=0;h--){const m=a[h];if(!((m.type==="p"||m.type==="NodeParagraph")&&!(m.content||"").trim()&&!(m.markdown||"").trim())){c=m;break}}if(!c||!Jk(c))continue;const u=Be.getBlockAttrOverride(c.id)||{};let p={...c.ial||{},...u};if(!p[Ve]&&(t!=null&&t.getBlockAttrsFn)){const h=await t.getBlockAttrsFn(c.id).catch(()=>({}));p={...p,...h,...u}}let y=c.markdown||c.content||"";if(t!=null&&t.getBlockKramdownFn)try{const h=await t.getBlockKramdownFn(c.id);h!=null&&h.kramdown&&(y=h.kramdown)}catch{}if(Xk(y,p))continue;const d=dr(y)||y.replace(/<[^>]+>/g,"").trim();l.push({id:c.id,pageIndex:r+1,type:c.type,sourceMarkdown:y,cleanContent:d||"在此输入本页讲稿提词..."})}return l}async function cc(e,t,o){const i=(o==null?void 0:o.updateBlockFn)||vs,n=(o==null?void 0:o.setBlockAttrsFn)||ze,s=(o==null?void 0:o.syncDomFn)||et,r=`> [!NOTE] 💡 演讲备注
${t.split(/\r?\n/).map(a=>`> ${a}`).join(`
`)}
{: ${Ve}="true"}`;await i("markdown",r,e),await n(e,{[Ve]:"true"}),Be.setBlockAttrOverride(e,{[Ve]:"true"}),s(e,{[Ve]:"true"})}async function dc(e,t){const o=(t==null?void 0:t.showMessageFn)||ae.showMessage,i=(t==null?void 0:t.confirmFn)||ae.confirm;if(!e)return o("请先在主编辑区打开幻灯片文档"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const n=await ac(e,t);if(n.length===0)return o("未发现待规范化的候选讲稿块"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const s=n.length;return new Promise(l=>{i("识别讲稿块",`扫描检测到 ${s} 处候选讲稿块（提示块或引用块），是否确认将其规范化为标准演讲备注？`,async()=>{var c;o(`正在批量规范化 ${s} 个讲稿块...`);let r=0,a=0;for(const u of n)try{await cc(u.id,u.cleanContent,t),r++}catch(p){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${u.id} 失败:`,p),a++}(c=t==null?void 0:t.onSuccessNotice)==null||c.call(t,"已规范化讲稿"),o(`已成功识别并规范化 ${r} 个讲稿块`),t!=null&&t.compileFn&&await t.compileFn().catch(()=>{}),l({totalScanned:s,matchedCount:s,successCount:r,errorCount:a})},()=>{l({totalScanned:s,matchedCount:s,successCount:0,errorCount:0})})})}function Qk(e,t){const o=pe(!1),{triggerSaveNotice:i}=t;async function n(g){var D,U,W,E,P,x,K,j;const w=`> [!NOTE] 💡 演讲备注
${(g||"在此输入本页讲稿提词...").split(/\r?\n/).map($=>`> ${$}`).join(`
`)}
{: custom-slides-note="true"}`,C=((D=e.latestDoc.value)==null?void 0:D.slides)||[],A=e.targetSlide.value,M=A?C.findIndex($=>$===A):-1;let I=null;if(M!==-1&&M<C.length-1){const $=C[M+1];I=await Uo("markdown",w,$.startBlockId)}else{const $=((U=A==null?void 0:A.noteBlocks)==null?void 0:U.slice(-1)[0])||((W=A==null?void 0:A.blocks)==null?void 0:W.slice(-1)[0]),T=($==null?void 0:$.id)||(A==null?void 0:A.startBlockId);T?I=await Uo("markdown",w,void 0,T):I=await bs("markdown",w,e.currentDocId.value)}const N=((x=(P=(E=I==null?void 0:I[0])==null?void 0:E.doOperations)==null?void 0:P[0])==null?void 0:x.id)||((K=I==null?void 0:I[0])==null?void 0:K.id);return N&&(await ze(N,{[Ve]:"true"}),Be.setBlockAttrOverride(N,{[Ve]:"true"}),Zo(N,(j=e.plugin)==null?void 0:j.app)),e.plugin&&await e.plugin.compileCurrentDocument(),N}async function s(){const g=e.activeBlockId.value;if(g)if(e.isNoteBlock.value){i("取消中...");try{await ze(g,{[Ve]:""}),Be.setBlockAttrOverride(g,{[Ve]:""}),et(g,{[Ve]:""}),delete e.activeBlockAttrs.value[Ve],i("已取消备注"),ae.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(b){console.error("[SiYuanLiveSlides] 取消讲稿备注失败:",b),i("取消失败"),ae.showMessage("取消讲稿备注失败")}}else{i("转换中...");try{let b=e.rawSnippet.value;try{const A=await cd(g);A!=null&&A.kramdown&&(b=A.kramdown)}catch{}const C=`> [!NOTE] 💡 演讲备注
${(dr(b)||b.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(A=>`> ${A}`).join(`
`)}
{: custom-slides-note="true"}`;await vs("markdown",C,g),await ze(g,{[Ve]:"true"}),Be.setBlockAttrOverride(g,{[Ve]:"true"}),et(g,{[Ve]:"true"}),e.activeBlockAttrs.value[Ve]="true",e.activeBlockType.value="NodeCallout",i("已设为讲稿备注"),ae.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(b){console.error("[SiYuanLiveSlides] 转换讲稿备注提示块失败:",b),i("设置失败"),ae.showMessage("转为讲稿备注提示块失败")}}}async function l(){try{await n(),ae.showMessage("已在正文末尾插入讲稿备注提示块")}catch(g){ae.showMessage("插入讲稿备注块失败"),console.error(g)}}function r(){var k;const g=e.currentSlideNoteBlockId.value;if(!g){ae.showMessage("未找到本页关联的讲稿备注块");return}Zo(g,(k=e.plugin)==null?void 0:k.app)?ae.showMessage("已在编辑区定位讲稿备注块"):ae.showMessage("定位讲稿备注块失败")}async function a(){var k;if(!e.currentDocId.value)return;const g=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};ae.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const b=await lc(g,Cl);if(b.notes){const w=e.currentSlideNoteBlockId.value;if(w){const C=`> [!NOTE] 💡 演讲备注
${b.notes.split(/\r?\n/).map(A=>`> ${A}`).join(`
`)}
{: custom-slides-note="true"}`;await vs("markdown",C,w),await ze(w,{[Ve]:"true"}),Be.setBlockAttrOverride(w,{[Ve]:"true"}),Zo(w,(k=e.plugin)==null?void 0:k.app)}else await n(b.notes);b.isAiGenerated?ae.showMessage("思源 AI 演讲提词卡生成成功！"):ae.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}const c=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(k=>`> ${k}`).join(`
`)}
{: custom-slides-note="true"}`;async function u(){var w,C;const g=e.currentDocId.value||((w=e.plugin)==null?void 0:w.currentDocId)||"",b=(C=e.latestDoc.value)==null?void 0:C.slides;if(Array.isArray(b)&&b.length>0)return{docId:g,slides:b};if(!g)return{docId:"",slides:[]};const k=await Be.compile(g).catch(()=>null);return{docId:g,slides:(k==null?void 0:k.slides)||[]}}async function p(g,b,k,w){var M,I,N,D,U,W;let C=null;if(b<k.length-1){const E=k[b+1];C=await Uo("markdown",c,E.startBlockId)}else{const E=((M=g==null?void 0:g.noteBlocks)==null?void 0:M.slice(-1)[0])||((I=g==null?void 0:g.blocks)==null?void 0:I.slice(-1)[0]),P=(E==null?void 0:E.id)||(g==null?void 0:g.startBlockId);P?C=await Uo("markdown",c,void 0,P):C=await bs("markdown",c,w||e.currentDocId.value)}const A=((U=(D=(N=C==null?void 0:C[0])==null?void 0:N.doOperations)==null?void 0:D[0])==null?void 0:U.id)||((W=C==null?void 0:C[0])==null?void 0:W.id);A&&(await ze(A,{[Ve]:"true"}),Be.setBlockAttrOverride(A,{[Ve]:"true"}))}async function y(){if(o.value)return;const{docId:g,slides:b}=await u();if(b.length===0){ae.showMessage("当前文档无幻灯片页面");return}const k=b.map((C,A)=>({slide:C,idx:A})).filter(({slide:C})=>{var I;const A=Array.isArray(C.noteBlocks)&&C.noteBlocks.length>0,M=!!((I=C.notes)!=null&&I.trim());return!A&&!M});if(k.length===0){ae.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const w=k.length;ae.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${w} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{if(o.value)return;o.value=!0,ae.showMessage("正在批量追加讲稿块...");let C=0;try{for(const{slide:A,idx:M}of k)try{await p(A,M,b,g),C++}catch(I){console.error(`[SiYuanLiveSlides] 为第 ${M+1} 页追加讲稿块失败:`,I)}e.plugin&&await e.plugin.compileCurrentDocument(),ae.showMessage(`已成功为 ${C} 页追加讲稿备注块`)}catch(A){console.error("[SiYuanLiveSlides] 批量追加讲稿块失败:",A),ae.showMessage("批量追加讲稿块时出现异常")}finally{o.value=!1}})}async function d(){if(o.value)return;const{slides:g}=await u();if(g.length===0){ae.showMessage("当前文档无幻灯片页面");return}const b=[];for(const C of g)if(C.noteBlocks&&C.noteBlocks.length>0)for(const A of C.noteBlocks)A.id&&b.push({id:A.id,pageIndex:C.pageIndex});if(b.length===0){ae.showMessage("当前文档中没有讲稿备注块，无需删除");return}const k=new Set(b.map(C=>C.pageIndex)).size,w=b.length;ae.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${w} 个讲稿备注块（涉及 ${k} 页），删除后无法撤销。是否确认继续？`,async()=>{if(o.value)return;o.value=!0,ae.showMessage("正在批量删除讲稿块...");let C=0;try{for(const A of b)try{await Fs(A.id),Be.clearBlockAttrOverride(A.id),C++}catch(M){console.error(`[SiYuanLiveSlides] 删除讲稿块 ${A.id} 失败:`,M)}e.activeBlockId.value&&b.some(A=>A.id===e.activeBlockId.value)&&delete e.activeBlockAttrs.value[Ve],e.plugin&&await e.plugin.compileCurrentDocument(),ae.showMessage(`已成功删除全部 ${C} 个讲稿备注块`)}catch(A){console.error("[SiYuanLiveSlides] 批量删除讲稿块失败:",A),ae.showMessage("批量删除讲稿块时出现异常")}finally{o.value=!1}})}async function h(){var b;const g=e.currentDocId.value||((b=e.plugin)==null?void 0:b.currentDocId);if(!g){ae.showMessage("请先在主编辑区打开幻灯片文档");return}if(o.value){ae.showMessage("正在批量处理中，请稍候...");return}o.value=!0;try{await dc(g,{onSuccessNotice:i,compileFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{o.value=!1}}async function m(){if(o.value){ae.showMessage("正在批量处理中，请稍候...");return}const{docId:g,slides:b}=await u();if(!g){ae.showMessage("请先在主编辑区打开幻灯片文档");return}if(b.length===0){ae.showMessage("当前文档无幻灯片页面");return}const k=await ac(g),w=new Set(k.map(M=>M.pageIndex)),C=b.map((M,I)=>({slide:M,idx:I})).filter(({slide:M,idx:I})=>{var W;const N=Array.isArray(M.noteBlocks)&&M.noteBlocks.length>0,D=!!((W=M.notes)!=null&&W.trim()),U=M.pageIndex??I+1;return!N&&!D&&!w.has(U)});if(k.length===0&&C.length===0){ae.showMessage("所有幻灯片页面均已存在讲稿备注块，无需重复操作");return}let A="";k.length>0&&C.length>0?A=`扫描检测到 ${k.length} 处已有候选讲稿待规范化，另有 ${C.length} 页暂无讲稿将新增默认讲稿块，是否继续？`:k.length>0?A=`扫描检测到 ${k.length} 处已有候选讲稿块（提示块或引用块），是否规范化为标准演讲备注？`:A=`将在未配置讲稿的 ${C.length} 页末尾自动增加默认讲稿提示块，是否继续？`,ae.confirm("增加讲稿块",A,async()=>{if(o.value)return;o.value=!0,ae.showMessage("正在处理讲稿块...");let M=0,I=0;try{for(const N of k)try{await cc(N.id,N.cleanContent),M++}catch(D){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${N.id} 失败:`,D)}for(const{slide:N,idx:D}of C)try{await p(N,D,b,g),I++}catch(U){console.error(`[SiYuanLiveSlides] 为第 ${D+1} 页增加讲稿块失败:`,U)}e.plugin&&await e.plugin.compileCurrentDocument(),i("已更新讲稿"),M>0&&I>0?ae.showMessage(`已规范化 ${M} 处现有讲稿，并为 ${I} 页新增讲稿块`):M>0?ae.showMessage(`已成功识别并规范化 ${M} 个讲稿块`):ae.showMessage(`已成功为 ${I} 页增加讲稿备注块`)}catch(N){console.error("[SiYuanLiveSlides] 增加讲稿块失败:",N),ae.showMessage("增加讲稿块时出现异常")}finally{o.value=!1}})}return{isBatchProcessing:o,createNoteBlockOnCurrentSlide:n,onToggleNoteBlock:s,onAddNoteBlock:l,onLocateNoteBlock:r,onGenerateNotesWithAI:a,onBatchAppendNotes:y,onBatchDeleteNotes:d,onIdentifyNotesBlocks:h,onAddOrIdentifyNotesBlocks:m}}function ew(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading")return!0;const o=String(e.subType||"").toLowerCase();if(/^h[1-6]$/.test(o))return!0;const i=String(e.rawMarkdown||e.markdown||"").trim();return!!/^#{1,6}\s+/.test(i)}function tw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return t==="i"||t==="nodelistitem"}function ow(e){const t=[],o=i=>{var n,s,l,r,a,c,u,p,y;for(const d of i){if(!d||d.isNote||((n=d.attributes)==null?void 0:n[Ve])==="true"||((s=d.ial)==null?void 0:s[Ve])==="true"||d.type==="tb"||d.type==="thematic-break"||d.type==="NodeThematicBreak"||String(d.markdown||d.rawMarkdown||"").trim()==="---"||d.slot==="slot-divider-right"||String(d.rawMarkdown||d.markdown||"").trim()==="::right::")continue;if(ew(d)){t.push({id:d.id,type:d.type,isHeading:!0,currentClicks:d.clicks||((l=d.attributes)==null?void 0:l[Oe])||((r=d.ial)==null?void 0:r[Oe]),rawBlock:d});continue}if(tw(d)){t.push({id:d.id,type:d.type||"i",isHeading:!1,currentClicks:d.clicks||((a=d.attributes)==null?void 0:a[Oe])||((c=d.ial)==null?void 0:c[Oe]),rawBlock:d});continue}const h=d.children&&d.children.length>0?d.children:(u=d.rawNode)==null?void 0:u.children;if(Array.isArray(h)&&h.length>0){o(h);continue}t.push({id:d.id,type:d.type,isHeading:!1,currentClicks:d.clicks||((p=d.attributes)==null?void 0:p[Oe])||((y=d.ial)==null?void 0:y[Oe]),rawBlock:d})}};return o(e||[]),t}function iw(e){var n;if(e.pageIndex===1||((n=e.frontmatter)==null?void 0:n.layout)==="cover")return[];const t=ow(e.blocks||[]);if(t.length===0)return[];let o=-1;for(let s=0;s<t.length;s++)if(!t[s].isHeading){o=s;break}if(o===-1)return[];const i=[];for(let s=o+1;s<t.length;s++){const l=t[s];!!!(l.currentClicks&&String(l.currentClicks).trim()!=="")&&l.id&&i.push({blockId:l.id,pageIndex:e.pageIndex,targetClick:"+1"})}return i}async function nw(e,t){const i=await((t==null?void 0:t.compileDocFn)||(l=>Be.compile(l)))(e).catch(()=>null);if(!i||!Array.isArray(i.slides)||i.slides.length===0)return{totalPages:0,animatedPagesCount:0,targets:[]};const n=[],s=new Set;for(const l of i.slides){const r=iw(l);r.length>0&&(n.push(...r),s.add(l.pageIndex))}return{totalPages:i.slides.length,animatedPagesCount:s.size,targets:n}}async function uc(e,t){const o=(t==null?void 0:t.showMessageFn)||ae.showMessage,i=(t==null?void 0:t.confirmFn)||ae.confirm,n=(t==null?void 0:t.setBlockAttrsFn)||ze,s=(t==null?void 0:t.syncDomFn)||et;if(!e)return o("请先在主编辑区打开幻灯片文档"),{totalPages:0,animatedPagesCount:0,targets:[],successCount:0,errorCount:0};const l=await nw(e,t);if(l.targets.length===0)return o("未检测到需要配置顺延动效的后续块"),{...l,successCount:0,errorCount:0};const r=l.targets.length,a=l.animatedPagesCount;return new Promise(c=>{i("智能设置动效",`扫描检测到可为 ${a} 页中的 ${r} 个后续块配置顺延 (+1) 动效，是否继续？`,async()=>{var y;o(`正在批量配置 ${r} 个后续块动效...`);let u=0,p=0;for(const d of l.targets)try{await n(d.blockId,{[Oe]:d.targetClick}),Be.setBlockAttrOverride(d.blockId,{[Oe]:d.targetClick}),s(d.blockId,{[Oe]:d.targetClick}),u++}catch(h){console.error(`[SiYuanLiveSlides] 为块 ${d.blockId} 配置动效失败:`,h),p++}(y=t==null?void 0:t.onSuccessNotice)==null||y.call(t,"已配置智能动效"),o(`已成功为 ${u} 个后续块配置顺延 (+1) 动效`),t!=null&&t.compileCurrentDocFn&&await t.compileCurrentDocFn().catch(()=>{}),c({...l,successCount:u,errorCount:p})},()=>{c({...l,successCount:0,errorCount:0})})})}async function sw(e,t){const i=await((t==null?void 0:t.compileDocFn)||(a=>Be.compile(a)))(e).catch(()=>null);if(!i||!Array.isArray(i.slides)||i.slides.length===0)return{totalPages:0,affectedPagesCount:0,targets:[]};const n=[],s=new Set,l=new Set,r=(a,c)=>{var u,p,y,d,h;for(const m of a){if(!m)continue;if(m.id&&!s.has(m.id)){const b=Be.getBlockAttrOverride(m.id),k=(b==null?void 0:b[Oe])??m.clicks??((u=m.attributes)==null?void 0:u[Oe])??((p=m.ial)==null?void 0:p[Oe]),w=(b==null?void 0:b[$t])??m.motion??((y=m.attributes)==null?void 0:y[$t])??((d=m.ial)==null?void 0:d[$t]),C=!!(k&&String(k).trim()!==""),A=!!(w&&String(w).trim()!=="");(C||A)&&(s.add(m.id),n.push({blockId:m.id,pageIndex:c,hasClick:C,hasMotion:A}),l.add(c))}const g=m.children&&m.children.length>0?m.children:(h=m.rawNode)==null?void 0:h.children;Array.isArray(g)&&g.length>0&&r(g,c)}};for(const a of i.slides)r(a.blocks||[],a.pageIndex);return{totalPages:i.slides.length,affectedPagesCount:l.size,targets:n}}async function rw(e,t){const o=(t==null?void 0:t.showMessageFn)||ae.showMessage,i=(t==null?void 0:t.confirmFn)||ae.confirm,n=(t==null?void 0:t.setBlockAttrsFn)||ze,s=(t==null?void 0:t.syncDomFn)||et;if(!e)return o("请先在主编辑区打开幻灯片文档"),{totalPages:0,affectedPagesCount:0,targets:[],successCount:0,errorCount:0};const l=await sw(e,t);if(l.targets.length===0)return o("当前文档未检测到已配置的页面动效，无需清除"),{...l,successCount:0,errorCount:0};const r=l.targets.length,a=l.affectedPagesCount;return new Promise(c=>{i("危险操作：清除所有页面动效",`此操作将清除 ${a} 页中全部 ${r} 个内容块的逐步显现（v-click）与入场微动效（v-motion）配置，清除后无法撤销。是否确认继续？`,async()=>{var d;o(`正在清除 ${r} 个内容块的动效配置...`);let u=0,p=0;const y={[Oe]:"",[$t]:""};for(const h of l.targets)try{await n(h.blockId,y),Be.setBlockAttrOverride(h.blockId,y),s(h.blockId,y),u++}catch(m){console.error(`[SiYuanLiveSlides] 清除块 ${h.blockId} 动效失败:`,m),p++}(d=t==null?void 0:t.onSuccessNotice)==null||d.call(t,"已清除动效"),o(`已成功清除 ${u} 个内容块的动效配置`),t!=null&&t.compileCurrentDocFn&&await t.compileCurrentDocFn().catch(()=>{}),c({...l,successCount:u,errorCount:p})},()=>{c({...l,successCount:0,errorCount:0})})})}function lw(e,t){const{saveAttr:o,saveAttrs:i,savePageAttr:n}=t;async function s(){(e.videoAutoplay.value?"false":"true")==="true"?(await i({[Wo]:"true",[ii]:"true"}),e.activeBlockAttrs.value[Wo]="true",e.activeBlockAttrs.value[ii]="true"):(await o(Wo,"false"),e.activeBlockAttrs.value[Wo]="false")}async function l(){const D=e.videoLoop.value?"false":"true";await o(xn,D)}async function r(){const D=e.videoMuted.value?"false":"true";await o(ii,D)}async function a(){const D=e.videoControls.value?"false":"true";await o(Sn,D)}async function c(D){var x,K;const U=e.activeBlockId.value;if(!U)return;const W=e.rawSnippet.value||"",E=bo(W)||"",P=e.currentPageDividerId.value||e.currentDocId.value;if(D)if(D==="background"){const j={[Ye]:"background",[be]:""};P&&E&&(e.pageBackground&&(e.pageBackground.value=E),await ze(P,{[ct]:E}).catch(()=>{}),Be.setBlockAttrOverride(P,{[ct]:E}),et(P,{[ct]:E}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=E)),await i(j)}else(D===Cn||D===_n)&&await i({[be]:D,[Ye]:""});else{const j={[Ye]:"",[be]:""};if(e.activeBlockAttrs.value[ct]==="true"&&(j[ct]=""),P&&E&&((x=e.pageBackground)==null?void 0:x.value)===E&&(e.pageBackground&&(e.pageBackground.value=""),await ze(P,{[ct]:""}).catch(()=>{}),Be.setBlockAttrOverride(P,{[ct]:""}),et(P,{[ct]:""}),(K=e.targetSlide.value)!=null&&K.frontmatter&&delete e.targetSlide.value.frontmatter.background),await i(j),typeof document<"u"){const $=document.querySelector(`.protyle-wysiwyg [data-node-id="${U}"]`),T=$==null?void 0:$.closest('[data-type="NodeListItem"]'),O=T==null?void 0:T.getAttribute("data-node-id");if(O&&O!==U){const te={[be]:"",[Ye]:""};et(O,te),Be.setBlockAttrOverride(O,te),await ze(O,te).catch(()=>{})}}}}function u(){e.elemClick.value?o(Oe,""):o(Oe,"+1")}function p(D){o(Oe,D)}function y(D){o($t,D)}function d(D){(e.activeBlockAttrs.value[Me]||"")===D?o(Me,""):o(Me,D)}function h(D){e.elemShikiLines.value=D,o(Jo,D)}function m(D){const U=D?D.trim():"",W=/^\d+$/.test(U)?`${U}px`:U;e.elemMaxHeight.value=W,o(Vi,W)}async function g(){const D=e.currentSlideLayout.value==="three-cols-header";await o(Me,D?"col-1":"left"),ae.showMessage(D?"已将当前块设置为第 1 栏":"已将当前块设置为双栏左栏")}async function b(){const D=e.activeBlockId.value;D&&ae.confirm("清除块演示属性","确定要清除当前块的所有演示属性（包含动画、插槽、备注等）吗？此操作无法撤销。",async()=>{const U={[Oe]:"",[$t]:"",[Me]:"",[Jo]:"",[Vi]:"",[Ve]:"",[be]:"",[mt]:"",[Ye]:"",[wt]:"",[ct]:"",[Ft]:"",[Wo]:"",[xn]:"",[ii]:"",[Sn]:""};if(et(D,U),await ze(D,U),Be.clearBlockAttrOverride(D),typeof document<"u"){const W=document.querySelector(`.protyle-wysiwyg [data-node-id="${D}"]`),E=W==null?void 0:W.closest('[data-type="NodeListItem"]'),P=E==null?void 0:E.getAttribute("data-node-id");P&&P!==D&&(et(P,U),await ze(P,U).catch(()=>{}),Be.clearBlockAttrOverride(P))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground&&(e.pageBackground.value=""),e.pageImage.value="",ae.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()})}async function k(){if(e.activeBlockId.value)try{await Uo("markdown","---",e.activeBlockId.value,void 0),ae.showMessage("已在上方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ae.showMessage("插入分页符失败")}}async function w(){const D=e.activeBlockId.value||e.currentDocId.value;if(D)try{await Uo("markdown","---",void 0,D),ae.showMessage("已在下方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ae.showMessage("插入分页符失败")}}async function C(){if(e.activeBlockId.value)try{await Fs(e.activeBlockId.value),ae.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{ae.showMessage("删除失败")}}async function A(){var D,U;try{let W=null;if(typeof document<"u"){const P=e.activeBlockId.value;if(P){const x=document.querySelector(`.protyle-wysiwyg [data-node-id="${P}"]`);x&&(W=x.getAttribute("data-type")==="NodeSuperBlock"?x:x.closest('[data-type="NodeSuperBlock"]'))}if(!W){const x=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(x){const K=document.querySelector(`.protyle-wysiwyg [data-node-id="${x}"]`);if(K){let j=K.nextElementSibling;for(;j&&!(j.getAttribute("data-type")==="NodeThematicBreak"||(D=j.classList)!=null&&D.contains("protyle-wysiwyg__block--hr"));){const $=j.getAttribute("data-type")==="NodeSuperBlock"?j:j.querySelector('[data-type="NodeSuperBlock"]');if($){W=$;break}j=j.nextElementSibling}}}else{const K=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),j=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const $ of j)if(!K||$.compareDocumentPosition(K)&Node.DOCUMENT_POSITION_FOLLOWING){W=$;break}}}}const E=[];if(W){const P=Array.from(W.querySelectorAll(":scope > [data-node-id]"));for(const x of P){const K=x.getAttribute("data-node-id");K&&(E.push(K),x.removeAttribute("style"))}}else if((U=e.targetSlide.value)!=null&&U.blocks){for(const P of e.targetSlide.value.blocks)if(P.children&&P.children.length>=2){for(const x of P.children)x.id&&E.push(x.id);break}}if(E.length>0)for(const P of E)await ze(P,{style:""}).catch(()=>{});await n(mt,""),ae.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(W){console.error("[layout-actions] resetSuperBlockWidth error:",W),ae.showMessage("重置超级块比例失败")}}async function M(){var D,U,W;try{let E=null;if(typeof document<"u"){const x=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),K=e.activeBlockId.value;let j=[];if(x){const O=document.querySelector(`.protyle-wysiwyg [data-node-id="${x}"]`);if(O){let te=O.nextElementSibling;for(;te&&!(te.getAttribute("data-type")==="NodeThematicBreak"||(D=te.classList)!=null&&D.contains("protyle-wysiwyg__block--hr"));)j.push(te),te=te.nextElementSibling}}else{const O=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),te=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const Y of te)if(!O||Y.compareDocumentPosition(O)&Node.DOCUMENT_POSITION_FOLLOWING)j.push(Y);else break}const $=[];let T;for(const O of j){const te=O.getAttribute("data-type");te==="NodeHeading"&&(T=O.getAttribute("data-node-id")||void 0);const Y=[];te==="NodeSuperBlock"?Y.push(O):Y.push(...Array.from(O.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const Z of Y){if((Z.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const oe=Z.getAttribute("data-node-id")||"";let ne=[];const Ce=Array.from(Z.querySelectorAll('[data-type="NodeListItem"]'));if(Ce.length===4&&(ne=Ce.map(_e=>_e.getAttribute("data-node-id")).filter(Boolean)),ne.length!==4){const _e=Array.from(Z.querySelectorAll(":scope > [data-node-id]"));_e.length===4&&(ne=_e.map(ke=>ke.getAttribute("data-node-id")).filter(Boolean))}ne.length===4&&$.push({sbId:oe,itemIds:ne,headerId:T})}}$.length>0&&(K&&(E=$.find(O=>{if(O.sbId===K||O.itemIds.includes(K))return!0;const te=document.querySelector(`.protyle-wysiwyg [data-node-id="${O.sbId}"]`),Y=document.querySelector(`.protyle-wysiwyg [data-node-id="${K}"]`);return!!(te&&Y&&te.contains(Y))})||null),E||(E=$[0]))}if(!E&&((U=e.targetSlide.value)!=null&&U.blocks)){const x=e.targetSlide.value,K=[];for(const $ of x.blocks)$.rawNode?K.push($.rawNode):K.push({id:$.id,type:$.type,content:$.content,markdown:$.rawMarkdown,children:$.children,ial:$.attributes||$.ial||{}});const j=Kf(K,e.activeBlockId.value);j&&j.items.length===4&&(E={sbId:j.superBlockNode.id,itemIds:j.items.map($=>$.id),headerId:(W=j.headerNode)==null?void 0:W.id})}const P=e.currentPageDividerId.value||e.currentDocId.value;if(P&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Be.setBlockAttrOverride(P,{[be]:"clover"}),et(P,{[be]:"clover"}),await ze(P,{[be]:"clover"}).catch(()=>{})),E&&E.itemIds.length>0){E.headerId&&(Be.setBlockAttrOverride(E.headerId,{[Me]:"header"}),et(E.headerId,{[Me]:"header"}),await ze(E.headerId,{[Me]:"header"}).catch(()=>{}));const x=Math.min(4,E.itemIds.length);for(let K=0;K<x;K++){const j=E.itemIds[K],$=`col-${K+1}`;Be.setBlockAttrOverride(j,{[Me]:$}),et(j,{[Me]:$}),await ze(j,{[Me]:$}).catch(()=>{})}}return ae.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(E){return console.error("[layout-actions] applyCloverLayout error:",E),ae.showMessage("配置四叶草布局失败",4e3,"error"),!1}}async function I(){var U,W;const D=e.currentDocId.value||((U=e.plugin)==null?void 0:U.currentDocId);if(!D){ae.showMessage("请先在主编辑区打开幻灯片文档");return}if((W=t.isBatchProcessing)!=null&&W.value){ae.showMessage("正在批量处理中，请稍候...");return}t.isBatchProcessing&&(t.isBatchProcessing.value=!0);try{await uc(D,{onSuccessNotice:t.triggerSaveNotice,compileCurrentDocFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{t.isBatchProcessing&&(t.isBatchProcessing.value=!1)}}async function N(){var U,W;const D=e.currentDocId.value||((U=e.plugin)==null?void 0:U.currentDocId);if(!D){ae.showMessage("请先在主编辑区打开幻灯片文档");return}if((W=t.isBatchProcessing)!=null&&W.value){ae.showMessage("正在批量处理中，请稍候...");return}t.isBatchProcessing&&(t.isBatchProcessing.value=!0);try{const E=await rw(D,{onSuccessNotice:t.triggerSaveNotice,compileCurrentDocFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}});E.successCount>0&&e.activeBlockId.value&&E.targets.some(P=>P.blockId===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[Oe],delete e.activeBlockAttrs.value[$t])}finally{t.isBatchProcessing&&(t.isBatchProcessing.value=!1)}}return{onToggleVideoAutoplay:s,onToggleVideoLoop:l,onToggleVideoMuted:r,onToggleVideoControls:a,onImageRoleChange:c,toggleElemClick:u,onElemClickStepChange:p,onElemMotionChange:y,onElemSlotChange:d,onElemShikiLinesChange:h,onElemMaxHeightChange:m,onSetTwoColsContrast:g,onClearBlockAttrs:b,onInsertDividerBefore:k,onInsertDividerAfter:w,onDeleteCurrentBlock:C,resetSuperBlockWidth:A,applyCloverLayout:M,onAutoAnimateDocument:I,onClearAnimationsDocument:N}}function aw(e){const{triggerSaveNotice:t,saveAttrs:o,saveAttr:i,savePageAttr:n,applyPageLayoutAndRatio:s,saveDocAttr:l}=Yk(e),r=Qk(e,{triggerSaveNotice:t}),a=lw(e,{saveAttr:i,saveAttrs:o,savePageAttr:n,triggerSaveNotice:t,isBatchProcessing:r.isBatchProcessing});async function c(){var b;if(!e.latestDoc.value){ae.showMessage("请先在主编辑区打开幻灯片文档");return}const d=e.latestDoc.value,h=await Oo(d,(b=e.currentDocId)==null?void 0:b.value,e.plugin),m=Ka(d,{title:h});Ya(`${h}.html`,m)&&ae.showMessage(`已开始下载单文件离线 HTML 演示包 (${h}.html)`)}function u(){if(!e.latestDoc.value){ae.showMessage("请先在主编辑区打开幻灯片文档");return}Za(e.latestDoc.value)&&ae.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const p=pe(!1);async function y(){var d;if(p.value){ae.showMessage("正在导出图片中，请稍候...",2e3);return}if(!e.latestDoc.value){ae.showMessage("请先在主编辑区打开幻灯片文档");return}p.value=!0;try{ae.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const h=e.latestDoc.value,m=await Oo(h,(d=e.currentDocId)==null?void 0:d.value,e.plugin),g=await tc(h,{title:m,onProgress:(b,k)=>{ae.showMessage(`正在导出幻灯片图片 (${b} / ${k})...`,2e3)}});g.success?ae.showMessage(`🎉 成功导出 ${g.total||0} 张幻灯片高清图片并已保存为 ${m}.zip！`,4e3):ae.showMessage(`导出图片失败：${g.error||"未知异常"}`)}finally{p.value=!1}}return{triggerSaveNotice:t,saveAttrs:o,saveAttr:i,savePageAttr:n,applyPageLayoutAndRatio:s,saveDocAttr:l,onToggleVideoAutoplay:a.onToggleVideoAutoplay,onToggleVideoLoop:a.onToggleVideoLoop,onToggleVideoMuted:a.onToggleVideoMuted,onToggleVideoControls:a.onToggleVideoControls,onImageRoleChange:a.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,onIdentifyNotesBlocks:r.onIdentifyNotesBlocks,onAddOrIdentifyNotesBlocks:r.onAddOrIdentifyNotesBlocks,toggleElemClick:a.toggleElemClick,onElemClickStepChange:a.onElemClickStepChange,onElemMotionChange:a.onElemMotionChange,onElemSlotChange:a.onElemSlotChange,onElemShikiLinesChange:a.onElemShikiLinesChange,onElemMaxHeightChange:a.onElemMaxHeightChange,onSetTwoColsContrast:a.onSetTwoColsContrast,onClearBlockAttrs:a.onClearBlockAttrs,onInsertDividerBefore:a.onInsertDividerBefore,onInsertDividerAfter:a.onInsertDividerAfter,onDeleteCurrentBlock:a.onDeleteCurrentBlock,resetSuperBlockWidth:a.resetSuperBlockWidth,applyCloverLayout:a.applyCloverLayout,onAutoAnimateDocument:a.onAutoAnimateDocument,onClearAnimationsDocument:a.onClearAnimationsDocument,isExportingImages:p,onExportHtml:c,onExportPdf:u,onExportImages:y}}function cw(e){const t=ye(()=>hr(e.activeBlockType.value));function o(i){const{attrKey:n,fallback:s,mode:l="defined"}=i,r=a=>l==="truthy"?a:a!==void 0;return ye(()=>{if(t.value){const c=e.activeBlockAttrs.value[n];if(r(c))return c}const a=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(a){const c=Be.getBlockAttrOverride(a);if(r(c==null?void 0:c[n]))return c[n]}return s()})}return{isDivider:t,resolvePageAttr:o}}function hs(e){if(e.type==="h"){if(e.subType==="h1")return 1;if(e.subType==="h2")return 2;if(e.subType==="h3")return 3}const t=(e.markdown||e.content||"").trimStart();return t.startsWith("# ")?1:t.startsWith("## ")?2:t.startsWith("### ")?3:null}function dw(e,t){for(let o=t-1;o>=0;o--){const i=e[o];if(mo(i)||(i.content||i.markdown||"").trim())return i}return null}function ps(e){const t=e.type;if(t==="c"||t==="code"||t==="t"||t==="table"||t==="s"||t==="super")return 3;if(t==="l"||t==="list"||t==="b"||t==="blockquote")return 2;const o=(e.markdown||e.content||"").trim();return o?o.includes("![")||o.includes("<img")||o.length>100?2:1:0}function vl(e,t){if(e===1)return"cover";let o=!1,i=-1;for(let r=0;r<t.length;r++){const a=t[r],c=(a.markdown||a.content||"").trim();if(c.includes("![")||c.includes("<img")||a.type==="img"){o=!0,i=r;break}}if(o)return i===0?"image-left":"image-right";let n=0,s=!1,l=!1;for(const r of t)(r.type==="i"||r.type==="l"||(r.markdown||"").trim().startsWith("- "))&&n++,r.type==="s"&&(s=!0),r.type==="b"&&(l=!0);return s||n>=3?"two-cols":l&&t.length<=2?"quote":"default"}function uw(e,t){const o=[],i=new Set,n=6,s=6;let l=0,r=0,a=0,c=0,u=null;function p(y){const d=[];for(let h=y+1;h<e.length;h++){const m=e[h];if(mo(m))break;const g=hs(m);if(g!==null&&(g===1||g===2||g===3))break;d.push(m)}return d}if(e.length>0){let y=!1,d=-1;for(let h=0;h<e.length;h++){const m=e[h];if(mo(m)){y=!0;break}if((m.content||m.markdown||"").trim()){d=h;break}}if(!y&&d>=0){const h=e[d],m=hs(h);let g=m===1?"cover":"default";if(m!==1){const k=p(d);g=vl(m,k)}const b=m===1?"作为第一页起点插入分页线 (封面大章)":"作为第一页起点插入分页线";o.push({blockId:h.id,recommendedLayout:g,reason:b}),i.add(h.id)}}for(let y=0;y<e.length;y++){const d=e[y];if(mo(d)){l=0,r=0,a=0,c=0,u=null;continue}const h=dw(e,y),m=!h||mo(h),g=hs(d);if(g===1||g===2||g===3){if(!(a===1&&c===0&&u!==null&&!(u===1&&g===2))&&!m&&l>0&&!i.has(d.id)){let A=g===1?"cover":"default";{const I=p(y);A=vl(g,I)}let M=g===1?"检测到一级核心章节标题，建议作为新幻灯片封面/大章":g===2?"检测到二级分论点标题，建议开启新页":"检测到三级要点标题，建议开启新页";A==="image-right"||A==="image-left"?M+=" (推荐图文版式)":A==="two-cols"?M+=" (推荐双栏版式)":A==="quote"&&(M+=" (推荐引言版式)"),o.push({blockId:d.id,recommendedLayout:A,reason:M}),i.add(d.id),l=1,r=ps(d),a=1,c=0,u=g;continue}l++,r+=ps(d),a++,u=g;continue}const k=ps(d);if((l>=n||r+k>s&&l>0)&&!m&&l>0&&!i.has(d.id)){o.push({blockId:d.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),i.add(d.id),l=1,r=k,a=0,c=1,u=null;continue}l++,r+=k,c++}return o}async function fc(e){if(!e.currentDocId&&typeof document<"u"){const s=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ae.showMessage("请先打开一篇思源笔记文档");return}const t=await bi(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ae.showMessage("当前文档无内容，无需断页");return}const o=t.map(s=>({id:s.id,type:s.type,subType:s.subType,content:s.content||"",markdown:s.markdown||""})),i=uw(o);if(i.length===0){ae.showMessage("智能分析完毕：当前文档结构合理，暂无新增分页建议");return}ae.showMessage(`智能分析完毕：发现 ${i.length} 处建议分页点，正在自动插入分页线...`);let n=0;for(const s of i)try{await Uo("markdown","---",s.blockId,void 0),await ze(s.blockId,{"custom-slides-layout":s.recommendedLayout}),n++}catch(l){console.warn("Failed to insert divider:",l)}ae.showMessage(`已成功在 ${n} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}async function hc(e){var s,l,r,a,c,u;if(!e.currentDocId&&typeof document<"u"){const p=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(p==null?void 0:p.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ae.showMessage("请先打开一篇思源笔记文档");return}const t=await bi(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ae.showMessage("当前文档无内容");return}const o=[],i=[];for(const p of t)p.type==="tb"||p.type==="thematic-break"||p.type==="NodeThematicBreak"||((s=p.markdown)==null?void 0:s.trim())==="---"||((l=p.markdown)==null?void 0:l.trim())==="***"||p.type==="b"&&(((r=p.markdown)==null?void 0:r.trim())==="---"||((a=p.content)==null?void 0:a.trim())==="---")?o.push(p.id):((c=p.ial)!=null&&c[fo]||(u=p.ial)!=null&&u[be])&&i.push(p.id);if(o.length===0&&i.length===0){ae.showMessage("当前文档中未发现需要清除的幻灯片分页线");return}ae.showMessage(`正在清除文档中的 ${o.length} 处分页线...`);let n=0;for(const p of o)try{await Fs(p),n++}catch(y){console.warn("Failed to delete divider block:",y)}for(const p of i)try{await ze(p,{[fo]:"",[be]:""})}catch(y){console.warn("Failed to clear slide attrs:",y)}ae.showMessage(`已成功清除文档中的 ${n} 处分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}const fw={class:"spm-slides-inspector"},hw={class:"spm-inspector-topbar"},pw={class:"spm-inspector-title"},mw={class:"slides-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},gw={class:"spm-inspector-topbar-actions"},yw={class:"spm-target-banner"},bw={class:"spm-target-info"},vw=["aria-label"],kw={key:0,class:"spm-save-status"},ww=["title"],xw={class:"spm-inspector-body"},Sw=Nt({__name:"SlidesInspectorDockView",setup(e,{expose:t}){const o=Wt("plugin"),i=pe(!1);function n(Q){i.value=!1,c.value=Q.docId,o!=null&&o.compileCurrentDocument&&o.compileCurrentDocument(Q.docId)}const s=pe(""),l=pe(""),r=pe({}),a=pe(""),c=pe(""),u=pe(""),p=pe(""),y=pe(""),d=pe(""),h=pe(""),m=pe(""),g=pe(null),b=pe(""),k=pe("");function w(){var ge;const Q=s.value||c.value;Q&&typeof navigator<"u"&&(ge=navigator==null?void 0:navigator.clipboard)!=null&&ge.writeText&&navigator.clipboard.writeText(Q).then(()=>{k.value="已复制！",setTimeout(()=>{k.value=""},1500)}).catch(()=>{})}const C=ye(()=>hr(l.value)),A=ye(()=>l.value==="NodeCodeBlock"),M=pe(!1),I=ye(()=>{if(M.value||Ge.value)return!0;const Q=a.value||"";return!!bo(Q)}),N=ye(()=>{const Q=l.value||"";if(Q==="NodeVideo"||Q==="video")return!0;const ge=a.value||"";return!!(/<video\b/i.test(ge)||/\.mp4\b/i.test(ge))}),D=ye(()=>!s.value||s.value===c.value||l.value==="doc"||l.value==="NodeDocument"),U=ye(()=>{const Q=s.value||c.value||"";return Q.length>8?Q.slice(-8):Q||"无"}),W=ye(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),E=ye(()=>{if(C.value)return"分页符 (---)";if(D.value)return"全局文档";if(N.value)return"视频块";let Q="内容块";switch(l.value){case"NodeHeading":Q="标题块";break;case"NodeParagraph":Q="段落块";break;case"NodeCodeBlock":Q="代码块";break;case"NodeVideo":Q="视频块";break;case"NodeList":case"NodeListItem":Q="列表项";break;case"NodeBlockquote":Q="引述块";break;case"NodeTable":Q="表格块";break;case"NodeSuperBlock":case"s":case"sb":Q="超级块";break;default:Q="内容块";break}return d.value?h.value?`${h.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${Q}`:`分栏容器 › ${Q}`:Q}),P=ye(()=>C.value?"tag-divider":D.value?"tag-doc":"tag-block"),x=ye(()=>r.value[be]||"default"),K=ye(()=>r.value[wt]||"slide-left"),j=pe(""),$=pe(""),T=ye(()=>r.value[Bi]||"inherit"),O=ye(()=>{var Q;return qk((Q=g.value)==null?void 0:Q.slides,{activeBlockId:s.value,activeBlockType:l.value,currentTopBlockId:u.value,currentPageDividerId:p.value,activeBlockAttrs:r.value})}),te=ye(()=>{var Q;return((Q=O.value)==null?void 0:Q.notes)||""}),Y=ye(()=>{var Q,ge,Ee;return((Ee=(ge=(Q=O.value)==null?void 0:Q.noteBlocks)==null?void 0:ge[0])==null?void 0:Ee.id)||""}),Z=ye(()=>{var We,Ue,Re,bt,on,Co;if(C.value){const it=r.value[be]||r.value["custom-slides-layout"];if(it)return it}const Q=r.value[Me]||r.value["custom-slides-slot"];if(Q&&(["col-1","col-2","col-3"].includes(Q)||/^col-\d+$/.test(Q)))return"cols-header";if(y.value)return y.value;const ge=p.value||(C.value?s.value:"");if(ge){const it=Be.getBlockAttrOverride(ge);if(it!=null&&it[be])return it[be]}if(ge&&((We=g.value)!=null&&We.slides)){const it=g.value.slides.find(Xo=>Xo.startBlockId===ge);if((Ue=it==null?void 0:it.frontmatter)!=null&&Ue.layout)return it.frontmatter.layout}if((bt=(Re=O.value)==null?void 0:Re.frontmatter)!=null&&bt.layout)return O.value.frontmatter.layout;if((Co=(on=O.value)==null?void 0:on.blocks)!=null&&Co.some(it=>it.slot&&(["col-1","col-2","col-3"].includes(it.slot)||/^col-\d+$/.test(it.slot))))return"cols-header";const Ee=Be.getBlockAttrOverride(c.value);return Ee!=null&&Ee[be]?Ee[be]:"default"}),ce=cw({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,currentPageDividerId:p}),oe=ce.resolvePageAttr({attrKey:mt,mode:"truthy",fallback:()=>{var Q,ge;return((ge=(Q=O.value)==null?void 0:Q.frontmatter)==null?void 0:ge.layoutRatio)||""}}),ne=ce.resolvePageAttr({attrKey:si,fallback:()=>{var Q,ge;return((ge=(Q=O.value)==null?void 0:Q.frontmatter)==null?void 0:ge.mask)||""}}),Ce=ce.resolvePageAttr({attrKey:qo,fallback:()=>{var Q,ge;return((ge=(Q=O.value)==null?void 0:Q.frontmatter)==null?void 0:ge.maskRatio)||""}}),_e=ce.resolvePageAttr({attrKey:ri,fallback:()=>{var Q,ge;return((ge=(Q=O.value)==null?void 0:Q.frontmatter)==null?void 0:ge.maskStyle)||"solid"}}),ke=ce.resolvePageAttr({attrKey:li,fallback:()=>{var Q,ge;return((ge=(Q=O.value)==null?void 0:Q.frontmatter)==null?void 0:ge.maskInitial)||"hidden"}});function Ie(Q){if(!Q||(Q.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Ee=Array.from(Q.querySelectorAll(":scope > [data-node-id]"));if(Ee.length<2)return null;const We=Ee.length,Ue=Ee.map(Co=>{const it=Co.getAttribute("style")||"",Xo=it.match(/calc\(\s*([\d.]+)%/);if(Xo)return parseFloat(Xo[1]);const Ci=it.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return Ci?parseFloat(Ci[1]):null});let Re="",bt=!1;if(Ue.some(Co=>Co!==null)){bt=!0;const Co=Ue.reduce((Pe,vt)=>Pe+(vt||0),0),it=Ue.filter(Pe=>Pe===null).length,Xo=it>0?Math.max(0,100-Co)/it:100/Ee.length,Ci=Ue.map(Pe=>Pe!==null?Pe:Xo),nd=Ci.reduce((Pe,vt)=>Pe+vt,0)||1,_i=Ci.map(Pe=>Pe/nd*100);if(_i.length===2){const[Pe]=_i;if(Pe>=48&&Pe<=52)Re="1:1";else if(Pe>=31&&Pe<=35)Re="1:2";else if(Pe>=65&&Pe<=69)Re="2:1";else if(Pe>=28&&Pe<=32)Re="3:7";else if(Pe>=68&&Pe<=72)Re="7:3";else if(Pe>=38&&Pe<=42)Re="4:6";else if(Pe>=58&&Pe<=62)Re="6:4";else{const vt=Math.round(Pe);Re=`${vt}:${100-vt}`}}else if(_i.length===3){const[Pe,vt,_o]=_i;if(Pe>=31&&Pe<=35&&vt>=31&&vt<=35&&_o>=31&&_o<=35)Re="1:1:1";else if(Pe>=23&&Pe<=27&&vt>=48&&vt<=52&&_o>=23&&_o<=27)Re="1:2:1";else if(Pe>=48&&Pe<=52&&vt>=23&&vt<=27&&_o>=23&&_o<=27)Re="2:1:1";else if(Pe>=23&&Pe<=27&&vt>=23&&vt<=27&&_o>=48&&_o<=52)Re="1:1:2";else{const yr=Math.round(Pe),br=Math.round(vt);Re=`${yr}:${br}:${100-yr-br}`}}else Re=_i.map(Pe=>Math.round(Pe)).join(":")}else bt=!1,Re=Array.from({length:We},()=>1).join(":");const on=We>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:We,ratio:Re,isCustomWidth:bt,recommendedLayout:on}}function R(Q){if(!(Q!=null&&Q.blocks))return null;for(const ge of Q.blocks){const Ee=ge.rawNode;if(Ee&&ut(Ee)&&io(Ee)){const Ue=xi(Ee).length,Re=cr(Ee);return{hasSuperBlock:!0,colCount:Ue,ratio:Re||Array.from({length:Ue},()=>1).join(":"),isCustomWidth:!!Re,recommendedLayout:Ue>=2?"cols-header":"two-cols"}}}return null}const ie=ye(()=>{var Q;if(typeof document<"u"){const ge=s.value;if(ge){const We=document.querySelector(`.protyle-wysiwyg [data-node-id="${ge}"]`);if(We){const Ue=We.getAttribute("data-type")==="NodeSuperBlock"?We:We.closest('[data-type="NodeSuperBlock"]');if(Ue){const Re=Ie(Ue);if(Re)return Re}}}const Ee=p.value||(C.value?s.value:"");if(Ee){const We=document.querySelector(`.protyle-wysiwyg [data-node-id="${Ee}"]`);if(We){let Ue=We.nextElementSibling;for(;Ue&&!(Ue.getAttribute("data-type")==="NodeThematicBreak"||(Q=Ue.classList)!=null&&Q.contains("protyle-wysiwyg__block--hr"));){const Re=Ue.getAttribute("data-type")==="NodeSuperBlock"?Ue:Ue.querySelector('[data-type="NodeSuperBlock"]');if(Re){const bt=Ie(Re);if(bt)return bt}Ue=Ue.nextElementSibling}}}else{const We=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Ue=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Re of Ue)if(!We||Re.compareDocumentPosition(We)&Node.DOCUMENT_POSITION_FOLLOWING){const bt=Ie(Re);if(bt)return bt}}}return R(O.value)}),B=ye(()=>{var Q;return((Q=ie.value)==null?void 0:Q.ratio)||""}),H=ye(()=>{const Q=l.value||"";if(Q==="NodeSuperBlock"||Q==="s"||Q==="sb")return!0;if(typeof document<"u"&&s.value){const ge=document.querySelector(`.protyle-wysiwyg [data-node-id="${s.value}"]`);if(ge!=null&&ge.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),v=ye(()=>{var Q;return((Q=O.value)==null?void 0:Q.pageIndex)||1}),F=ye(()=>!!r.value[Ve]);function z(){if(!d.value)return!1;if(s.value===d.value||typeof document>"u")return!0;const Q=document.querySelector(`.protyle-wysiwyg [data-node-id="${d.value}"]`)||document.querySelector(`[data-node-id="${d.value}"]`);if(!Q)return!1;const ge=Q.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(ge==null?void 0:ge.getAttribute("data-node-id"))===s.value}const S=ye(()=>{var ge;if(r.value[Oe]!==void 0)return r.value[Oe]||"";if(d.value&&z())return m.value||"";if(d.value)return"";const Q=s.value;if(Q&&((ge=O.value)!=null&&ge.blocks)){const Ee=O.value.blocks.find(We=>We.id===Q);if(Ee!=null&&Ee.clicks)return Ee.clicks}return""}),_=ye(()=>{var ge;if(r.value[$t])return r.value[$t];const Q=s.value;if(Q&&((ge=O.value)!=null&&ge.blocks)){const Ee=O.value.blocks.find(We=>We.id===Q);if(Ee!=null&&Ee.motion)return typeof Ee.motion=="string"?Ee.motion:JSON.stringify(Ee.motion)}return""}),L=ye(()=>{var ge;if(r.value[Me])return r.value[Me];const Q=s.value;if(Q&&((ge=O.value)!=null&&ge.blocks)){const Ee=O.value.blocks.find(We=>We.id===Q);if(Ee!=null&&Ee.slot)return Ee.slot}return""}),q=pe(""),V=pe(""),G=ye(()=>r.value[Wo]==="true"),X=ye(()=>r.value[xn]==="true"),le=ye(()=>r.value[ii]==="true"),se=ye(()=>r.value[Sn]!=="false"),me=ye(()=>{var Q,ge;return((ge=(Q=g.value)==null?void 0:Q.config)==null?void 0:ge.theme)||r.value[ji]||"apple-basic"}),Se=ye(()=>{var Q,ge;return((ge=(Q=g.value)==null?void 0:Q.config)==null?void 0:ge.aspectRatio)||r.value[Wi]||"16/9"}),we=ye(()=>{var Q,ge;return((ge=(Q=g.value)==null?void 0:Q.config)==null?void 0:ge.defaultTransition)||r.value[Ui]||"slide-left"}),Le=ye(()=>{var Q,ge;return((ge=(Q=g.value)==null?void 0:Q.config)==null?void 0:ge.spacing)||r.value[ks]||"normal"}),He=ye(()=>{var Q,ge;return((ge=(Q=g.value)==null?void 0:Q.config)==null?void 0:ge.background)||r.value[wn]||""}),Ge=ye(()=>{var Ue,Re;if((r.value[Ye]||r.value["slides-role"])===Ml||r.value[ct]==="true")return"background";const ge=r.value[be]||r.value["slides-layout"];if(ge==="image-left"||ge==="image-right")return ge;const Ee=a.value||"",We=bo(Ee);if(We&&((Re=(Ue=O.value)==null?void 0:Ue.frontmatter)!=null&&Re.background)){const bt=O.value.frontmatter.background;if(bt===We||bt.endsWith(We)||We.endsWith(bt))return"background"}return""}),rt=ye(()=>!!(r.value[Oe]||r.value[$t]||r.value[Me]||r.value[Jo]||r.value[Ve]||r.value["slides-note"]||r.value[Ye]||r.value[be]||r.value[Wo]||r.value[xn]||r.value[ii]||r.value[Sn])),{saveAttr:Ne,savePageAttr:ft,applyPageLayoutAndRatio:tt,applyCloverLayout:Ke,resetSuperBlockWidth:ue,saveDocAttr:fe,onToggleVideoAutoplay:Qe,onToggleVideoLoop:lt,onToggleVideoMuted:St,onToggleVideoControls:at,onImageRoleChange:ro,onToggleNoteBlock:bc,onAddNoteBlock:vc,onLocateNoteBlock:kc,onGenerateNotesWithAI:wc,isBatchProcessing:xc,onBatchDeleteNotes:Sc,onAddOrIdentifyNotesBlocks:Cc,onAutoAnimateDocument:_c,onClearAnimationsDocument:Ic,toggleElemClick:$c,onElemClickStepChange:Mc,onElemMotionChange:Tc,onElemSlotChange:Ac,onElemShikiLinesChange:Ec,onElemMaxHeightChange:Bc,onSetTwoColsContrast:Dc,onClearBlockAttrs:Lc,onInsertDividerBefore:Oc,onInsertDividerAfter:pr,onDeleteCurrentBlock:Pc,onExportHtml:Nc,onExportPdf:Rc}=aw({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:p,currentPageDividerLayout:y,parentContainerId:d,parentContainerClicks:m,latestDoc:g,targetSlide:O,currentSlideNoteBlockId:Y,currentSlideLayout:Z,isNoteBlock:F,elemClick:S,videoAutoplay:G,videoLoop:X,videoMuted:le,videoControls:se,pageBackground:j,pageImage:$,elemShikiLines:q,elemMaxHeight:V,saveStatus:b,plugin:o});async function zc(Q){if(Q==="clover"){if(!await Ke())return}else ft(be,Q)}function Hc(Q){ft(mt,Q)}async function Fc(Q){await ft(si,Q),(Q==="clockwise"||Q==="counter-clockwise"||Q==="cw"||Q==="ccw")&&(!Ce.value||Ce.value==="1:1")&&await ft(qo,"1:1:1:1")}function jc(Q){ft(qo,Q)}function Wc(Q){ft(ri,Q)}function Uc(Q){ft(li,Q)}function mr(Q){if(!Q)return;const ge=Q.recommendedLayout||(Q.colCount&&Q.colCount>=2?"cols-header":"two-cols"),Ee=Q.ratio||(Q.colCount?Array(Q.colCount).fill(1).join(":"):"1:1");tt(ge,Ee)}function Vc(Q){ft(mt,Q)}async function qc(){await ue()}function Gc(Q){Ne(wt,Q)}function Kc(Q){$.value=Q,Ne(Ft,Q)}function Yc(Q){Ne(Bi,Q==="inherit"?"":Q)}function Zc(Q){fe(ji,Q)}function Jc(Q){fe(wn,Q)}function Xc(Q){fe(Wi,Q)}function Qc(Q){fe(Ui,Q)}function ed(Q){fe(ks,Q)}function gr(){o!=null&&o.openBottomPreviewTab&&o.openBottomPreviewTab()}function td(){o!=null&&o.openPresenterTab&&o.openPresenterTab()}function od(){o&&Dt("aiScript")&&fc(o)}function id(){o&&Dt("aiScript")&&hc(o)}return t({setActiveBlock(Q){s.value=Q.id,l.value=Q.type,r.value={...Q.attrs},a.value=Q.content||Q.markdown||"",u.value=Q.topBlockId||Q.id,p.value=Q.pageDividerId||"",y.value=Q.pageDividerLayout||"",d.value=Q.parentContainerId||"",h.value=Q.parentContainerSlot||"",m.value=Q.parentContainerClicks||"",Q.rootId?c.value=Q.rootId:(Q.type==="doc"||Q.type==="NodeDocument")&&Q.id&&(c.value=Q.id),j.value=Q.attrs[ct]||"",$.value=Q.attrs[Ft]||"",q.value=Q.attrs[Jo]||"",V.value=Q.attrs[Vi]||"",M.value=!!Q.isImage},updateDocument(Q){g.value=Q,c.value=Q.docId},openImportDialog(){i.value=!0},setCurrentDocId(Q){c.value=Q}}),(Q,ge)=>(J(),ee("div",fw,[f("div",hw,[f("div",pw,[(J(),ee("svg",mw,[...ge[2]||(ge[2]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),ge[3]||(ge[3]=f("span",null,"演示配置",-1))]),f("div",gw,[he(Dt)("import")?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:ge[0]||(ge[0]=Ee=>i.value=!0)},[re(de,{name:"import"}),ge[4]||(ge[4]=f("span",null,"导入",-1))])):Te("",!0),f("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__sw","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:gr},[re(de,{name:"split-preview"}),ge[5]||(ge[5]=f("span",null,"分屏预览",-1))])])]),f("div",yw,[f("div",bw,[f("span",{class:xe(["spm-target-tag",P.value])},ve(E.value),3),f("span",{class:"spm-target-id b3-tooltips b3-tooltips__se","aria-label":k.value||"点击复制 ID: "+(s.value||c.value),onClick:w},[re(de,{name:"copy"}),f("span",null,"#"+ve(U.value),1)],8,vw)]),b.value?(J(),ee("span",kw,"● "+ve(b.value),1)):Te("",!0)]),W.value?(J(),ee("div",{key:0,class:"spm-context-quote",title:a.value},ve(W.value),9,ww)):Te("",!0),f("div",xw,[C.value?(J(),to(Zb,{key:0,"page-layout":x.value,"page-layout-ratio":he(oe),"page-mask":he(ne),"page-mask-ratio":he(Ce),"page-mask-style":he(_e),"page-mask-initial":he(ke),"detected-sb-ratio":B.value,"detected-sb-info":ie.value,"page-transition":K.value,"page-spacing":T.value,"page-image":$.value,"page-notes":te.value,"page-index":v.value,"onUpdate:pageLayout":zc,"onUpdate:pageLayoutRatio":Hc,"onUpdate:pageMask":Fc,"onUpdate:pageMaskRatio":jc,"onUpdate:pageMaskStyle":Wc,"onUpdate:pageMaskInitial":Uc,onApplySuperBlockLayout:mr,onResetSuperblockRatio:qc,"onUpdate:pageTransition":Gc,"onUpdate:pageSpacing":Yc,"onUpdate:pageImage":Kc,onAddNoteBlock:he(vc),onLocateNoteBlock:he(kc),onGenerateNotes:he(wc),onInsertDividerAfter:he(pr),onDeleteDivider:he(Pc)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onInsertDividerAfter","onDeleteDivider"])):s.value&&!D.value?(J(),to(T1,{key:1,"elem-click":S.value,"elem-motion":_.value,"elem-slot":L.value,"elem-shiki-lines":q.value,"elem-max-height":V.value,"is-code-block":A.value,"is-image":I.value,"is-video":N.value,"is-super-block":H.value,"detected-sb-info":ie.value,"video-autoplay":G.value,"video-loop":X.value,"video-muted":le.value,"video-controls":se.value,"has-block-attrs":rt.value,"is-note":F.value,"image-role":Ge.value,"current-slide-layout":Z.value,"parent-elem-click":m.value,"parent-container-slot":h.value,"parent-container-id":d.value,onToggleNote:he(bc),onToggleElemClick:he($c),onToggleVideoAutoplay:he(Qe),onToggleVideoLoop:he(lt),onToggleVideoMuted:he(St),onToggleVideoControls:he(at),"onUpdate:imageRole":he(ro),"onUpdate:elemClick":he(Mc),"onUpdate:elemMotion":he(Tc),"onUpdate:elemSlot":he(Ac),"onUpdate:elemShikiLines":he(Ec),"onUpdate:elemMaxHeight":he(Bc),onApplySuperBlockLayout:mr,onApplySuperBlockRatio:Vc,onInsertDividerBefore:he(Oc),onInsertDividerAfter:he(pr),onSetTwoColsContrast:he(Dc),onClearBlockAttrs:he(Lc)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(J(),to(W0,{key:2,"doc-theme":me.value,"doc-background":He.value,"doc-aspect-ratio":Se.value,"doc-default-transition":we.value,"doc-spacing":Le.value,"is-batch-processing":he(xc),"onUpdate:docTheme":Zc,"onUpdate:docBackground":Jc,"onUpdate:docAspectRatio":Xc,"onUpdate:docDefaultTransition":Qc,"onUpdate:docSpacing":ed,onOpenBottomPreview:gr,onOpenPresenter:td,onAddOrIdentifyNotes:he(Cc),onClearNotes:he(Sc),onAutoAnimate:he(_c),onClearAnimations:he(Ic),onAiAutoSplit:od,onClearDividers:id,onExportHtml:he(Nc),onExportPdf:he(Rc)},null,8,["doc-theme","doc-background","doc-aspect-ratio","doc-default-transition","doc-spacing","is-batch-processing","onAddOrIdentifyNotes","onClearNotes","onAutoAnimate","onClearAnimations","onExportHtml","onExportPdf"]))]),i.value&&he(Dt)("import")?(J(),to(Vk,{key:1,onClose:ge[1]||(ge[1]=Ee=>i.value=!1),onSuccess:n})):Te("",!0)]))}}),Cw=2e3,_w=600;function Iw(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function ms(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(kl(e))return!0;const t=e.firstElementChild;return!!(t&&kl(t))}function kl(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function $w(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class Mw{constructor(){$e(this,"consumers",new Map);$e(this,"seq",0);$e(this,"verifyTimer",null)}register(t,o,i){if(!o)return()=>{};const n=++this.seq,s=$w(),l={kind:t,element:o,visible:!1,measureOnDemand:!s,observer:null,onVisible:i};return s?(l.observer=new s(r=>{var u;const a=r[r.length-1];if(!a)return;const c=a.isIntersecting&&!l.visible;l.visible=a.isIntersecting,c&&((u=l.onVisible)==null||u.call(l))}),l.observer.observe(o)):l.visible=ms(o),this.consumers.set(n,l),()=>{var r;(r=l.observer)==null||r.disconnect(),this.consumers.delete(n),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const o of this.consumers.values())(t=o.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?ms(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!Iw(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const o of this.consumers.values())if(!o.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var o;this.verifyTimer=null;for(const i of this.consumers.values())if(!i.visible&&ms(i.element)){i.visible=!0,(o=i.onVisible)==null||o.call(i);return}},Cw))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const bn=new Mw,Si=new Zn;function pc(e,t,o){const i=()=>{var s;try{(s=o==null?void 0:o.flushDirtyCompile)==null||s.call(o)}catch{}},n=bn.register(e,t,i);return i(),n}let Eo=null,Rt=null,vn=null;function Tw(){return Rt}function Aw(e,t){Eo&&mc(),Eo=lr(wg),Eo.provide("plugin",t),Eo.provide("sandboxBridge",Si);const o=Eo.mount(e);return Rt=o,vn=pc("preview",e,t),o}function mc(e){vn&&(vn(),vn=null),Eo&&(Eo.unmount(),Eo=null,Rt=null)}function Ew(){return Rt!==null}let Bo=null,Vo=null;function Bw(e,t){return Bo&&gc(),Bo=lr(Ey),Bo.provide("plugin",t),Bo.provide("sandboxBridge",Si),Vo=Bo.mount(e),Vo}function gc(e){Bo&&(Bo.unmount(),Bo=null,Vo=null)}function Dw(e){var t;try{const o=new BroadcastChannel("siyuan-slides-sync");o.postMessage({type:"SYNC_SLIDES",slides:e.slides||[],config:{...e.config||{},hostThemeMode:((t=e.config)==null?void 0:t.hostThemeMode)||No()}}),o.close()}catch{}}let Do=null,Lt=null,kn=null;function Lw(e,t){Do&&yc(),Do=lr(Sw),Do.provide("plugin",t),Do.provide("sandboxBridge",Si);const o=Do.mount(e);return Lt=o,kn=pc("dock",e,t),o}function yc(e){kn&&(kn(),kn=null),Do&&(Do.unmount(),Do=null,Lt=null)}function Ow(e,t){Lt!=null&&Lt.updateDocument&&Lt.updateDocument(e),Rt!=null&&Rt.updateDocument?Rt.updateDocument(e,t):(Si.updateSlides(e.slides,e.config),Dw(e)),Vo!=null&&Vo.updateDocument&&Vo.updateDocument(e)}function Hs(e){Rt!=null&&Rt.navigateToBlock?Rt.navigateToBlock(e):Si.highlightElement(e)}function oi(e){Lt!=null&&Lt.setActiveBlock&&Lt.setActiveBlock(e)}function Pw(){return Ao("import")?!1:Lt!=null&&Lt.openImportDialog?(Lt.openImportDialog(),!0):!1}const Nw=[{id:"slides-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:fo,value:"true"},{key:be,value:"cover"},{key:wt,value:"fade"}]},{id:"slides-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:fo,value:"true"},{key:be,value:"two-cols"},{key:wt,value:"slide-left"}]},{id:"slides-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:fo,value:"true"},{key:be,value:"fact"},{key:wt,value:"zoom"}]},{id:"slides-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:fo,value:"true"},{key:be,value:"intro"},{key:wt,value:"slide-up"}]},{id:"slides-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:fo,value:"true"},{key:be,value:"quote"},{key:wt,value:"fade"}]},{id:"slides-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Oe,value:"+1"}]},{id:"slides-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Oe,value:"hide"}]},{id:"slides-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Me,value:"right"}]},{id:"slides-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Jo,value:"1-3"}]}];class gs{getPresetTemplates(){return Nw}buildScanSlidesBlocksSql(t="custom-slides-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${wt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,o,i,n){const s=`SELECT block_id FROM attributes WHERE name = '${wt}' AND value = '${t}'`,l=await i(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{[wt]:o}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,o,i,n){const s=`SELECT block_id FROM attributes WHERE name = '${be}' AND value = '${t}'`,l=await i(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{[be]:o}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置即现转场效果的块":`全库即现转场分布统计：${t.map(i=>`${i.value}: ${i.count} 个`).join("，")}`}}function Rw(e){if(e.addCommand({langKey:"slidesPresentation",langText:"即现: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),Ao("import")||e.addCommand({langKey:"slidesImport",langText:"即现: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{Pw()||ae.showMessage("请先在右侧栏打开「即现演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidesInitAttrs",langText:"即现: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await ze(e.currentDocId,{"custom-slides-theme":"default","custom-slides-aspect-ratio":"16/9","custom-slides-default-transition":"slide-left"}),ae.showMessage("已为当前文档初始化即现演示属性"),e.compileCurrentDocument(e.currentDocId))}}),Ao("aiScript")||(e.addCommand({langKey:"slidesAiSplit",langText:"即现: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:()=>fc(e)}),e.addCommand({langKey:"slidesClearDividers",langText:"即现: 清除当前文档分页线",hotkey:"",enabled:()=>!0,execute:()=>hc(e)})),Ao("aiScript")||e.addCommand({langKey:"slidesAiNotes",langText:"即现 AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,u,p;if(!e.currentDocId){const y=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(y==null?void 0:y.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ae.showMessage("请先打开一篇思源笔记文档");return}ae.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await bi(e.currentDocId).catch(()=>[]),o={startBlockId:e.currentDocId,blocks:t.map(y=>({id:y.id,type:y.type,content:y.content||"",rawMarkdown:y.markdown||""})),rawMarkdown:""},s=`> [!NOTE] 💡 演讲备注
${(await Zk(o,Cl)).split(/\r?\n/).map(y=>`> ${y}`).join(`
`)}
{: custom-slides-note="true"}`,l=await bs("markdown",s,e.currentDocId).catch(()=>null),r=((u=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:u.id)||((p=l==null?void 0:l[0])==null?void 0:p.id);r&&(await ze(r,{"custom-slides-note":"true"}),Be.setBlockAttrOverride(r,{"custom-slides-note":"true"}),Zo(r,e.app)),ae.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidesIdentifyNotes",langText:"即现演示: 识别正文讲稿块并规范化",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const o=document.querySelector(".protyle-content[data-doc-id]");t=(o==null?void 0:o.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ae.showMessage("请先在主编辑区打开幻灯片文档");return}await dc(t,{compileFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesAutoAnimate",langText:"即现演示: 智能配置演示动效",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const o=document.querySelector(".protyle-content[data-doc-id]");t=(o==null?void 0:o.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ae.showMessage("请先在主编辑区打开幻灯片文档");return}await uc(t,{compileCurrentDocFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesBatchTransitions",langText:"即现协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new gs,o=t.buildTransitionStatsSql(),i=await pi(o).catch(()=>[]),n=t.formatTransitionSummary(i||[]);ae.showMessage(n)}}),e.addCommand({langKey:"slidesExportTemplates",langText:"即现协同: 复制即现预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const o=new gs().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(o),ae.showMessage("已将即现属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ae.showMessage(`已生成模板数据（请在控制台查看）：
`+o)}}),e.addCommand({langKey:"slidesBatchReplaceTransition",langText:"即现协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const o=await new gs().batchUpdateTransitions("fade","slide-left",i=>pi(i).catch(()=>[]),(i,n)=>ze(i,n));ae.showMessage(`全库批量替换完成：已将 ${o.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),Ao("presenterMode")||e.addCommand({langKey:"slidesPresenterMode",langText:"即现: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),!Ao("exportImage")){let t=!1;e.addCommand({langKey:"slidesExportImagesZip",langText:"即现: 逐页导出幻灯片为高清图片包 (ZIP)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t){ae.showMessage("正在导出图片中，请稍候...",2e3);return}if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ae.showMessage("请先打开并放映一篇思源笔记文档");return}t=!0;try{ae.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const o=e.latestCompiledDoc,i=await Oo(o,e.currentDocId,e),n=await tc(o,{title:i,onProgress:(s,l)=>{ae.showMessage(`正在导出幻灯片图片 (${s} / ${l})...`,2e3)}});n.success?ae.showMessage(`🎉 成功导出 ${n.total||0} 张幻灯片高清图片并已保存为 ${i}.zip！`,4e3):ae.showMessage(`导出图片失败：${n.error||"未知异常"}`)}finally{t=!1}}})}}class zw{constructor(t=400){$e(this,"entries",new Map);this.ttlMs=t}get(t,o=Date.now()){if(!t)return;const i=this.entries.get(t);if(i){if(o-i.at>this.ttlMs){this.entries.delete(t);return}return i.attrs}}set(t,o,i=Date.now()){!t||!o||this.entries.set(t,{attrs:o,at:i})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function Hw(e){const t=new Map;if(!(e!=null&&e.slides))return t;const o=i=>{for(const n of i||[])n!=null&&n.id&&n.ial&&t.set(n.id,n.ial)};for(const i of e.slides)o(i.blocks),o(i.noteBlocks);return t}class Fw{constructor(t=150){$e(this,"lastBlockId","");$e(this,"lastAt",0);this.windowMs=t}shouldSkip(t,o=Date.now()){return t&&t===this.lastBlockId&&o-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=o,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class jw{constructor(){$e(this,"attrCache",new zw);$e(this,"compiledIalIndex",{doc:null,map:new Map});$e(this,"locatingLockUntil",0);$e(this,"lockedTargetBlockId","");$e(this,"lastKnownPageDividerId","");$e(this,"lastKnownDocId","")}isLocatingLocked(t){return Date.now()<this.locatingLockUntil?!(t&&t===this.lockedTargetBlockId):!1}async resolveBlockAttrs(t,o){if(!t)return{};const i=Be.getBlockAttrOverride(t),n=this.getCompiledIal(o,t);if(i||n)return{...n||{},...i||{}};const s=this.attrCache.get(t);if(s)return s;const l=await js(t).catch(()=>({}))||{};return this.attrCache.set(t,l),l}getCompiledIal(t,o){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:Hw(t)}),this.compiledIalIndex.map.get(o)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),o=t==null?void 0:t.getAttribute("data-node-id");if(o)return o;const i=document.querySelector(".protyle .protyle-title[data-node-id]"),n=i==null?void 0:i.getAttribute("data-node-id");if(n)return n;const s=document.querySelector("[data-doc-id]"),l=s==null?void 0:s.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(t,o=""){const i=t.closest(".protyle-title"),n=i==null?void 0:i.getAttribute("data-node-id");if(n)return n;const s=t.closest(".protyle"),l=s==null?void 0:s.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=t.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const u=this.getActiveDocumentId();return u||o}async switchToDocGlobalInspector(t,o){var s;if(!t)return;let i=o||"";if(!i&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");i=((s=l==null?void 0:l.innerText)==null?void 0:s.trim())||""}const n=await this.resolveBlockAttrs(t,null);oi({id:t,rootId:t,type:"doc",content:i,attrs:n,isDivider:!1,isCode:!1}),Hs(t)}handleBlockClickedFromSlide(t,o,i,n,s){var c,u,p,y;if(!t){Fi();const d=typeof s=="number"&&s>0?s:1,h=((c=n==null?void 0:n.slides)==null?void 0:c[d-1])||((u=n==null?void 0:n.slides)==null?void 0:u[0]);if(h){const m=h.startBlockId||"",g=((p=h.frontmatter)==null?void 0:p.layout)||"",b={"custom-slides-layout":g,...h.frontmatter};return oi({id:m,rootId:i,type:"NodeThematicBreak",attrs:b,isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:g}),this.resolveBlockAttrs(m,n).then(k=>{k&&Object.keys(k).length>0&&oi({id:m,rootId:i,type:"NodeThematicBreak",attrs:{...b,...k},isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:g})}),!0}else return this.switchToDocGlobalInspector(i),!0}this.lockedTargetBlockId=t,this.locatingLockUntil=Date.now()+500;const l=Zo(t,o),r=typeof document<"u"?document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`):null,a=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,t,a,i,n);else{let d="",h="";if(n!=null&&n.slides){const m=n.slides.find(g=>{var b,k,w;return g.startBlockId===t||((b=g.blocks)==null?void 0:b.some(C=>C.id===t))||((k=g.allBlockIds)==null?void 0:k.includes(t))||((w=g.noteBlocks)==null?void 0:w.some(C=>C.id===t))});m!=null&&m.startBlockId&&(d=m.startBlockId),(y=m==null?void 0:m.frontmatter)!=null&&y.layout&&(h=m.frontmatter.layout)}this.resolveBlockAttrs(t,n).then(async m=>{if(d&&!h){const g=Be.getBlockAttrOverride(d);if(g!=null&&g[be]||g!=null&&g["custom-slides-layout"])h=g[be]||g["custom-slides-layout"]||"";else{const b=await this.resolveBlockAttrs(d,n);h=b[be]||b["custom-slides-layout"]||"",b&&Object.keys(b).length>0&&Be.setBlockAttrOverride(d,b)}}oi({id:t,rootId:i,type:a||"NodeParagraph",attrs:m||{},pageDividerId:d,pageDividerLayout:h})}).catch(()=>{})}return l}async syncInspectorBlock(t,o,i,n,s){var K,j,$,T,O,te,Y,Z,ce;if(this.isLocatingLocked(o))return;let l=t,r=o,a=i;const c=typeof(t==null?void 0:t.closest)=="function"?t.closest('[data-type="NodeCallout"]'):null;if(c&&c!==t){const oe=c.getAttribute("data-node-id");if(oe){const ne=await this.resolveBlockAttrs(oe,s),Ce=Be.getBlockAttrOverride(oe)||{};({...ne,...Ce})[Ve]&&(l=c,r=oe,a="NodeCallout")}}const u=l.closest(".protyle-wysiwyg > [data-node-id]")||l,p=(u==null?void 0:u.getAttribute("data-node-id"))||r,y=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(u==null?void 0:u.getAttribute("data-type"))==="NodeThematicBreak"||(u==null?void 0:u.getAttribute("data-type"))==="tb"||!!((K=u==null?void 0:u.classList)!=null&&K.contains("hr")),d=a==="NodeCodeBlock",h=((j=l.innerText)==null?void 0:j.trim())||"",m=await this.resolveBlockAttrs(r,s),g=Be.getBlockAttrOverride(r)||{},b={...m,...g};let k="",w="";if(y)k=r,w=b[be]||b["custom-slides-layout"]||"";else{let oe=u.previousElementSibling;for(;oe;){const ne=oe.getAttribute("data-type");if(ne==="NodeThematicBreak"||ne==="tb"||($=oe.classList)!=null&&$.contains("hr")){k=oe.getAttribute("data-node-id")||"";break}oe=oe.previousElementSibling}}if(s!=null&&s.slides){const oe=[r,p];let ne=l.parentElement;for(;ne&&!ne.classList.contains("protyle-wysiwyg");){const _e=ne.getAttribute("data-node-id");_e&&!oe.includes(_e)&&oe.push(_e),ne=ne.parentElement}const Ce=s.slides.find(_e=>{var ke,Ie,R;return oe.includes(_e.startBlockId)||((ke=_e.blocks)==null?void 0:ke.some(ie=>oe.includes(ie.id)))||((Ie=_e.allBlockIds)==null?void 0:Ie.some(ie=>oe.includes(ie)))||((R=_e.noteBlocks)==null?void 0:R.some(ie=>oe.includes(ie.id)))});Ce&&(!k&&Ce.startBlockId&&(k=Ce.startBlockId),!w&&((T=Ce.frontmatter)!=null&&T.layout)&&(w=Ce.frontmatter.layout))}if(k?(this.lastKnownDocId=n,this.lastKnownPageDividerId=k):n&&this.lastKnownDocId===n&&this.lastKnownPageDividerId&&(!u.previousElementSibling&&(((O=u.parentElement)==null?void 0:O.scrollTop)||0)===0||(k=this.lastKnownPageDividerId)),k){const oe=Be.getBlockAttrOverride(k);if(oe&&(be in oe||"custom-slides-layout"in oe)&&(w=oe[be]||oe["custom-slides-layout"]||""),!w&&(s!=null&&s.slides)){const ne=s.slides.find(Ce=>Ce.startBlockId===k);(te=ne==null?void 0:ne.frontmatter)!=null&&te.layout&&(w=ne.frontmatter.layout)}if(!w){const ne=await this.resolveBlockAttrs(k,s);w=ne[be]||ne["custom-slides-layout"]||"",ne&&Object.keys(ne).length>0&&Be.setBlockAttrOverride(k,ne)}et(k,{[be]:w||""})}else if(n){const oe=Be.getBlockAttrOverride(n);oe&&(be in oe||"custom-slides-layout"in oe)?w=oe[be]||oe["custom-slides-layout"]||"":!w&&((ce=(Z=(Y=s==null?void 0:s.slides)==null?void 0:Y[0])==null?void 0:Z.frontmatter)!=null&&ce.layout)&&(w=s.slides[0].frontmatter.layout)}const C=l.getAttribute(be)||l.getAttribute("custom-slides-layout"),A=b[be]||b["custom-slides-layout"]||"";C&&C!==A&&et(r,{[be]:A});const M=l.getAttribute(Ye)||l.getAttribute("custom-slides-role"),I=b[Ye]||b["custom-slides-role"]||"";M&&M!==I&&et(r,{[Ye]:I});let N="",D="",U="";const W=l.closest('[data-type="NodeListItem"]');if(W&&W!==l){const oe=W.getAttribute("data-node-id");if(oe){N=oe;const ne=await this.resolveBlockAttrs(oe,s),Ce=Be.getBlockAttrOverride(oe)||{},_e={...ne,...Ce};D=_e[Me]||"",U=_e[Oe]||"";const ke=_e[be]||_e["custom-slides-layout"]||"",Ie=W.getAttribute(be)||W.getAttribute("custom-slides-layout");Ie&&Ie!==ke&&et(oe,{[be]:ke});const R=_e[Ye]||_e["custom-slides-role"]||"",ie=W.getAttribute(Ye)||W.getAttribute("custom-slides-role");ie&&ie!==R&&et(oe,{[Ye]:R})}}const E=!!l.querySelector("img, span[data-type='img']"),P=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),x=E&&P.length<=50;oi({id:r,rootId:n,type:a,content:h,attrs:b,isDivider:y,isCode:d,isImage:x,topBlockId:p,pageDividerId:k,pageDividerLayout:w,parentContainerId:N,parentContainerSlot:D,parentContainerClicks:U})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const o of t.data)if(Array.isArray(o==null?void 0:o.doOperations)){for(const i of o.doOperations)if((i==null?void 0:i.action)==="updateAttrs"&&i.id&&i.data){const n=i.data.old||{},s=i.data.new||{},l={};for(const r of Object.keys(n))r in s||(l[r]="");for(const[r,a]of Object.entries(s))l[r]=String(a??"");et(i.id,l),Be.setBlockAttrOverride(i.id,l)}}}}purgeStaleDomSlidesAttrs(t){var n,s,l;if(typeof document>"u"||!t)return;const o=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const a=o.get(r.startBlockId)||{};(n=r.frontmatter)!=null&&n.layout&&(a[be]=r.frontmatter.layout),o.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=o.get(a.id)||{};(s=a.ial)!=null&&s[be]&&(c[be]=a.ial[be]),(l=a.ial)!=null&&l[Ye]&&(c[Ye]=a.ial[Ye]),Object.keys(c).length>0&&o.set(a.id,c)}}}const i=Be.getAllAttrOverrides();for(const[r,a]of i.entries()){const c=o.get(r)||{};a[be]!==void 0&&(c[be]=a[be]),a[Ye]!==void 0&&(c[Ye]=a[Ye]),o.set(r,c)}Gk(o)}}const $o=new jw;class Ww{constructor(){$e(this,"state","IDLE");$e(this,"inFlightDocId",null);$e(this,"pendingDocs",new Set);$e(this,"lastPendingDocId",null);$e(this,"generation",0)}get currentState(){return this.state}get isRunning(){return this.state==="COMPILING"}get runningDocId(){return this.inFlightDocId}get pending(){return this.lastPendingDocId}get pendingList(){return Array.from(this.pendingDocs)}tryBegin(t){return this.state==="COMPILING"||this.inFlightDocId!==null?(this.pendingDocs.add(t),this.lastPendingDocId=t,null):(this.state="COMPILING",this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finishBatch(){this.state="IDLE",this.inFlightDocId=null,this.lastPendingDocId=null;const t=Array.from(this.pendingDocs);return this.pendingDocs.clear(),t}finish(){const t=this.finishBatch();return t.length>0?t[t.length-1]:null}reset(){this.state="IDLE",this.inFlightDocId=null,this.pendingDocs.clear(),this.lastPendingDocId=null,this.generation=0}}const Uw=150,Vw=`<symbol id="iconSlides" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,qw="slides-dock",ys="slides-preview-tab",wl="slides-presenter-tab",xl=jf;class Gw extends ae.Plugin{constructor(){super(...arguments);$e(this,"isMobile",!1);$e(this,"currentDocId","");$e(this,"previewTab",null);$e(this,"latestCompiledDoc",null);$e(this,"debounceTimer",null);$e(this,"activeCursorBlockId","");$e(this,"cancelledCursorBlockId","");$e(this,"compileScheduler",new Ww);$e(this,"dirtyDocId",null);$e(this,"inspectorSyncThrottle",new Fw);$e(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));$e(this,"onWsMainBound",this.onWsMain.bind(this));$e(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));$e(this,"onEditorClickBound",this.onEditorClick.bind(this));$e(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));$e(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));$e(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const o=ae.getFrontend();this.isMobile=o==="mobile"||o==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(Vw),this.addTopBar({id:"slides-topbar-play",icon:"iconSlides",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),Rw(this);const i=this;if(this.addTab({type:ys,init(n){var r;const s=this||n;i.previewTab=(s==null?void 0:s.tab)||null,Aw(s.element,i);const l=(r=s==null?void 0:s.data)==null?void 0:r.docId;l&&!i.getActiveDocumentId()&&i.compileCurrentDocument(l,{reason:"explicit"}),i.updatePreviewTabHeader()},destroy(){i.previewTab===(this==null?void 0:this.tab)&&(i.previewTab=null),mc(this.element)}}),this.addTab({type:wl,init(n){Bw((this||n).element,i)},destroy(){gc(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlides",title:"即现演示配置"},data:{},type:qw,init(){Lw(this.element,i)},destroy(){yc(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(n,s)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${n}`,{detail:s}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slides:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slides:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const n=()=>{const s=this.getActiveDocumentId();s&&(s!==this.currentDocId&&(this.currentDocId=s,this.updatePreviewTabHeader("",s)),this.latestCompiledDoc||this.markCompileDirty(s))};setTimeout(n,300),setTimeout(n,1e3)}}async onDataChanged(o){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const o=await this.loadData(xl),i=Wf(o);return uo(i),i}catch{return uo(Lo),Lo}}async saveGlobalSettings(o){const i=Yn(),n=uo({...i,...o||{}});try{await this.saveData(xl,n)}catch(l){console.error("保存即现全局配置失败",l)}const s=this.currentDocId||this.getActiveDocumentId();return s&&this.markCompileDirty(s),n}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,bn.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),Si.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const o=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",i=this.buildPreviewTabTitle(o);await ae.openTab({app:this.app,custom:{id:this.name+ys,title:i,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(o,this.currentDocId)}async openPresenterTab(){Ao("presenterMode")||(Ew()||await this.openBottomPreviewTab(),await ae.openTab({app:this.app,custom:{id:this.name+wl,title:"演讲者控制台",icon:"iconSlides",data:{}},position:"right"}))}async openStandalonePreviewWindow(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),this.currentDocId&&!this.latestCompiledDoc&&await this.compileCurrentDocument(this.currentDocId,{reason:"explicit"});const o=ae.getFrontend();if(o==="browser-desktop"||o==="browser-mobile"){typeof window<"u"&&typeof window.open=="function"&&window.open("/plugins/siyuan-live-slides/slides-client/index.html","SlidesBigScreenWindow","width=1280,height=760,menubar=no,toolbar=no,location=no,status=no");return}let i=this.previewTab;if(!i){const n=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",s=this.buildPreviewTabTitle(n),l=await ae.openTab({app:this.app,custom:{id:this.name+ys,title:s,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"});i=this.previewTab||l}i&&(this.currentDocId&&i.model&&(i.model.data={...i.model.data||{},docId:this.currentDocId}),ae.openWindow({tab:i,width:1280,height:760}))}async onSwitchProtyle(o){var l,r,a,c,u;const i=(l=o.detail)==null?void 0:l.protyle,n=(r=i==null?void 0:i.block)==null?void 0:r.rootID,s=((u=(c=(a=i==null?void 0:i.title)==null?void 0:a.editElement)==null?void 0:c.textContent)==null?void 0:u.trim())||"";if(n&&n!==this.currentDocId){this.cancelledCursorBlockId="",this.currentDocId=n,this.activeCursorBlockId=n;const p=await js(n).catch(()=>({}));oi({id:n,rootId:n,type:"doc",attrs:p}),this.markCompileDirty(n),this.updatePreviewTabHeader(s,n)}}onClickEditorContent(o){var s,l;const i=o==null?void 0:o.detail;if(!i)return;const n=(l=(s=i.protyle)==null?void 0:s.block)==null?void 0:l.rootID;n&&(!this.currentDocId||this.currentDocId!==n)&&(this.currentDocId=n),i.event&&this.onEditorClick(i.event)}buildPreviewTabTitle(o){return Xa(o)}async fetchDocumentTitle(o){return Qa(this,o)}async updatePreviewTabHeader(o,i){return og(this,o,i)}getActiveDocumentId(){return $o.getActiveDocumentId()}resolveDocIdFromElement(o){return $o.resolveDocIdFromElement(o,this.currentDocId)}async switchToDocGlobalInspector(o,i){o&&(this.activeCursorBlockId=o,this.currentDocId=o,await $o.switchToDocGlobalInspector(o,i))}onWsMain(o){const i=o.detail;i&&i.cmd==="transactions"&&($o.patchThematicBreakTransactions(i),this.markCompileDirty())}markCompileDirty(o){const i=o||this.currentDocId||this.getActiveDocumentId();i&&(this.currentDocId||(this.currentDocId=i),this.dirtyDocId=i,this.scheduleDirtyCompile())}scheduleDirtyCompile(o=Uw){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const i=bn.getVisibility();if(i==="none")return;const n=i==="visible"?o:Math.max(o,_w);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const s=this.dirtyDocId;this.dirtyDocId=null,s&&this.compileCurrentDocument(s,{reason:"auto"})},n)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(o,i){return o?(this.cancelledCursorBlockId="",this.activeCursorBlockId=o):(this.cancelledCursorBlockId=this.activeCursorBlockId,this.activeCursorBlockId=""),$o.handleBlockClickedFromSlide(o,this.app,this.currentDocId,this.latestCompiledDoc,i)}onBlockClickedFromSlide(o){const i=(o==null?void 0:o.detail)||o;i!=null&&i.blockId&&this.handleBlockClickedFromSlide(i.blockId,i.page)}onEditorClick(o){const i=o.target;if(!i)return;const n=i.closest(".protyle-title")||i.closest(".protyle-background");if(!!(n||i.closest(".protyle-content")&&!i.closest(".protyle-wysiwyg")&&!i.closest(".protyle-breadcrumb")&&!i.closest(".protyle-gutters"))){const u=this.resolveDocIdFromElement(i);if(u&&this.activeCursorBlockId!==u){const p=n||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),y=p==null?void 0:p.querySelector(".protyle-title__input"),d=((y==null?void 0:y.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(u,d)}return}if(!i.closest(".protyle-wysiwyg"))return;const r=i.closest("[data-node-id]");if(!r)return;const a=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";a&&(this.cancelledCursorBlockId="",this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(i)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Hs(a)),this.syncInspectorBlock(r,a,c))}onSelectionChange(){if(typeof window>"u")return;const o=window.getSelection();if(!o||o.rangeCount===0)return;const i=o.anchorNode;if(!i)return;const n=i.nodeType===Node.ELEMENT_NODE?i:i.parentElement;if(!n)return;const s=n.closest(".protyle-title");if(!!(s||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg"))){const u=this.resolveDocIdFromElement(n);if(u&&this.activeCursorBlockId!==u){const p=s||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),y=p==null?void 0:p.querySelector(".protyle-title__input"),d=((y==null?void 0:y.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(u,d)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]"),a=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";if(r&&a){if($o.isLocatingLocked(a))return;if(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId){if(a===this.cancelledCursorBlockId)return;this.activeCursorBlockId=a,Hs(a)}this.syncInspectorBlock(r,a,c)}}async syncInspectorBlock(o,i,n){this.inspectorSyncThrottle.shouldSkip(i)||await $o.syncInspectorBlock(o,i,n,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(o,i){const n=(i==null?void 0:i.reason)??"explicit";let s=o||this.currentDocId;if(!s){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,s=r;else return}if(n==="auto"&&bn.getVisibility()==="none"){this.dirtyDocId=s;return}const l=this.compileScheduler.tryBegin(s);if(l!==null){this.dirtyDocId===s&&(this.dirtyDocId=null);try{const r=await Be.compile(s),a=!!this.currentDocId&&s!==this.currentDocId;!this.compileScheduler.isStale(l)&&!a&&(this.currentDocId||(this.currentDocId=s),this.latestCompiledDoc=r,Ow(r,s),this.updatePreviewTabHeader("",s),this.purgeStaleDomSlidesAttrs(r))}catch(r){console.error("[SiYuanLiveSlides] Failed to compile document:",r)}finally{const r=this.compileScheduler.finishBatch(),a=r.length>0?r[0]:this.compileScheduler.finish();a&&this.markCompileDirty(a);for(let c=1;c<r.length;c++)this.markCompileDirty(r[c])}}}purgeStaleDomSlidesAttrs(o){$o.purgeStaleDomSlidesAttrs(o)}}module.exports=Gw;
