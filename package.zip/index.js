"use strict";var yc=Object.create;var Fs=Object.defineProperty;var kc=Object.getOwnPropertyDescriptor;var wc=Object.getOwnPropertyNames;var xc=Object.getPrototypeOf,Sc=Object.prototype.hasOwnProperty;var _c=(t,e,i)=>e in t?Fs(t,e,{enumerable:!0,configurable:!0,writable:!0,value:i}):t[e]=i;var Cc=(t,e,i,n)=>{if(e&&typeof e=="object"||typeof e=="function")for(let s of wc(e))!Sc.call(t,s)&&s!==i&&Fs(t,s,{get:()=>e[s],enumerable:!(n=kc(e,s))||n.enumerable});return t};var Vn=(t,e,i)=>(i=t!=null?yc(xc(t)):{},Cc(e||!t||!t.__esModule?Fs(i,"default",{value:t,enumerable:!0}):i,t));var kt=(t,e,i)=>_c(t,typeof e!="symbol"?e+"":e,i);const ht=require("siyuan");async function ge(t,e){const i=await ht.fetchSyncPost(t,e);return i.code===0?i.data:null}async function $c(){return ge("/api/notebook/lsNotebooks","")}async function Ic(t,e,i){return ge("/api/filetree/createDocWithMd",{notebook:t,path:e,markdown:i})}async function Zr(t,e){const i=new FormData;i.append("assetsDirPath",t);for(const s of e)i.append("file[]",s);return ge("/api/asset/upload",i)}async function Bi(t,e,i,n,s){return ge("/api/block/insertBlock",{dataType:t,data:e,nextID:i,previousID:n,parentID:s})}async function so(t,e,i){return ge("/api/block/appendBlock",{dataType:t,data:e,parentID:i})}async function ir(t,e,i){return ge("/api/block/updateBlock",{dataType:t,data:e,id:i})}async function nr(t){return ge("/api/block/deleteBlock",{id:t})}async function Ac(t){return ge("/api/block/getBlockKramdown",{id:t})}async function cs(t){return ge("/api/block/getChildBlocks",{id:t})}async function Tc(t){return ge("/api/block/getDocBlocksOrders",{id:t})}async function Dt(t,e){return ge("/api/attr/setBlockAttrs",{id:t,attrs:e})}async function _o(t){return ge("/api/attr/getBlockAttrs",{id:t})}async function tn(t){return ge("/api/query/sql",{stmt:t})}async function oo(t,e,i){const n=new FormData;return n.append("path",t),n.append("isDir",e.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",i),ge("/api/file/putFile",n)}async function Yr(t){const e="/api/ai/chatGPT";try{const i=await ge(e,{msg:t});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function Bc(){return ge("/api/storage/getInlineStyles","")}const Jr=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function Ec(t){const e=[];if(!t)return e;const i=new RegExp(Jr.source,"g");let n;for(;(n=i.exec(t))!==null;){const s=n[2]??n[3]??n[4];e.push({fullMatch:n[0],blockId:n[1],anchorText:s?s.trim():void 0})}return e}function Mc(t,e){if(!t)return"";const i=new RegExp(Jr.source,"g");return t.replace(i,(n,s,o,l,r)=>{const a=(o??l??r??"").trim();if(e&&e[s]){const d=e[s].trim();return`<div class="slidev-block-ref" data-ref-id="${s}">${d}</div>`}const c=a||`Ref(${s.slice(0,8)})`;return`<a href="siyuan://blocks/${s}" data-ref-id="${s}" class="slidev-ref-tag">🔗 ${c}</a>`})}const Cn="custom-slidev-theme",$n="custom-slidev-aspect-ratio",Xr="custom-slidev-highlighter",In="custom-slidev-default-transition",Qr="custom-slidev-color-schema",ro="custom-slidev-spacing",Mi="custom-slidev-slide",gt="custom-slidev-layout",ee="custom-slidev-transition",Ut="custom-slidev-background",Ee="custom-slidev-image",Ki="custom-slidev-notes",Gi="custom-slidev-class",gn="custom-slidev-spacing",le="custom-slidev-layout-ratio",vi="custom-slidev-mask",bi="custom-slidev-mask-ratio",yi="custom-slidev-mask-style",ki="custom-slidev-mask-initial",Wt="custom-slidev-click",Ve="custom-slidev-motion",Ni="custom-slidev-shiki-lines",At="custom-slidev-slot",ne="custom-slidev-note",Gt="custom-slidev-role",An="custom-slidev-max-height",Di="custom-slidev-autoplay",ds="custom-slidev-loop",qi="custom-slidev-muted",us="custom-slidev-controls",tl="background",fs="image-left",ps="image-right";function Tn(t){return t==="cols-header"||t==="two-cols-header"||t==="three-cols-header"}function Dc(t){return t.markdown&&t.markdown.trim()?t.markdown.trim():t.content&&t.content.trim()?t.content.trim():""}function Lc(t){const e={};if(!t)return e;const i=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(i))!==null;){const o=s[1],l=s[2]??s[3]??s[4]??"";e[o]=l}return e}function el(t){if(!t)return!1;const e=t.trim();return e.startsWith("assets/")||e.startsWith("./assets/")||e.startsWith("/assets/")}function il(t){const e=t.trim();return e.startsWith("./assets/")?e.slice(2):e.startsWith("/assets/")?e.slice(1):e}function Ae(t,e){if(!el(t))return t;const i=il(t);return e!=null&&e.base64Map&&e.base64Map[i]?e.base64Map[i]:e!=null&&e.baseUrl?`${e.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function Rc(t,e){if(!t)return"";let i=t;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,s,o)=>{const l=Ae(o,e);return`![${s}](${l})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,s,o,l)=>{const r=Ae(o,e);return`${s}${r}${l}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,s,o,l)=>{const r=Ae(o,e);return`${s}${r}${l}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Co(t){const e=Object.create(null);for(const i of t.split(","))e[i]=1;return i=>i in e}const Vt={},Zi=[],qe=()=>{},nl=()=>!1,_s=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&(t.charCodeAt(2)>122||t.charCodeAt(2)<97),Cs=t=>t.startsWith("onUpdate:"),ue=Object.assign,$o=(t,e)=>{const i=t.indexOf(e);i>-1&&t.splice(i,1)},Pc=Object.prototype.hasOwnProperty,zt=(t,e)=>Pc.call(t,e),Tt=Array.isArray,Yi=t=>zn(t)==="[object Map]",rn=t=>zn(t)==="[object Set]",sr=t=>zn(t)==="[object Date]",Bt=t=>typeof t=="function",ie=t=>typeof t=="string",Pe=t=>typeof t=="symbol",Ht=t=>t!==null&&typeof t=="object",sl=t=>(Ht(t)||Bt(t))&&Bt(t.then)&&Bt(t.catch),ol=Object.prototype.toString,zn=t=>ol.call(t),Oc=t=>zn(t).slice(8,-1),rl=t=>zn(t)==="[object Object]",Io=t=>ie(t)&&t!=="NaN"&&t[0]!=="-"&&""+parseInt(t,10)===t,vn=Co(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),$s=t=>{const e=Object.create(null);return(i=>e[i]||(e[i]=t(i)))},zc=/-\w/g,we=$s(t=>t.replace(zc,e=>e.slice(1).toUpperCase())),Nc=/\B([A-Z])/g,xi=$s(t=>t.replace(Nc,"-$1").toLowerCase()),Is=$s(t=>t.charAt(0).toUpperCase()+t.slice(1)),Hs=$s(t=>t?`on${Is(t)}`:""),Ue=(t,e)=>!Object.is(t,e),ts=(t,...e)=>{for(let i=0;i<t.length;i++)t[i](...e)},ll=(t,e,i,n=!1)=>{Object.defineProperty(t,e,{configurable:!0,enumerable:!1,writable:n,value:i})},As=t=>{const e=parseFloat(t);return isNaN(e)?t:e};let or;const Ts=()=>or||(or=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function Bn(t){if(Tt(t)){const e={};for(let i=0;i<t.length;i++){const n=t[i],s=ie(n)?Wc(n):Bn(n);if(s)for(const o in s)e[o]=s[o]}return e}else if(ie(t)||Ht(t))return t}const Fc=/;(?![^(]*\))/g,Hc=/:([^]+)/,jc=/\/\*[^]*?\*\//g;function Wc(t){const e={};return t.replace(jc,"").split(Fc).forEach(i=>{if(i){const n=i.split(Hc);n.length>1&&(e[n[0].trim()]=n[1].trim())}}),e}function It(t){let e="";if(ie(t))e=t;else if(Tt(t))for(let i=0;i<t.length;i++){const n=It(t[i]);n&&(e+=n+" ")}else if(Ht(t))for(const i in t)t[i]&&(e+=i+" ");return e.trim()}const Uc="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",Vc=Co(Uc);function al(t){return!!t||t===""}function qc(t,e){if(t.length!==e.length)return!1;let i=!0;for(let n=0;i&&n<t.length;n++)i=ln(t[n],e[n]);return i}function ln(t,e){if(t===e)return!0;let i=sr(t),n=sr(e);if(i||n)return i&&n?t.getTime()===e.getTime():!1;if(i=Pe(t),n=Pe(e),i||n)return t===e;if(i=Tt(t),n=Tt(e),i||n)return i&&n?qc(t,e):!1;if(i=Ht(t),n=Ht(e),i||n){if(!i||!n)return!1;const s=Object.keys(t).length,o=Object.keys(e).length;if(s!==o)return!1;for(const l in t){const r=t.hasOwnProperty(l),a=e.hasOwnProperty(l);if(r&&!a||!r&&a||!ln(t[l],e[l]))return!1}}return String(t)===String(e)}function Ao(t,e){return t.findIndex(i=>ln(i,e))}const cl=t=>!!(t&&t.__v_isRef===!0),St=t=>ie(t)?t:t==null?"":Tt(t)||Ht(t)&&(t.toString===ol||!Bt(t.toString))?cl(t)?St(t.value):JSON.stringify(t,dl,2):String(t),dl=(t,e)=>cl(e)?dl(t,e.value):Yi(e)?{[`Map(${e.size})`]:[...e.entries()].reduce((i,[n,s],o)=>(i[js(n,o)+" =>"]=s,i),{})}:rn(e)?{[`Set(${e.size})`]:[...e.values()].map(i=>js(i))}:Pe(e)?js(e):Ht(e)&&!Tt(e)&&!rl(e)?String(e):e,js=(t,e="")=>{var i;return Pe(t)?`Symbol(${(i=t.description)!=null?i:e})`:t};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let ae;class Kc{constructor(e=!1){this.detached=e,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!e&&ae&&(ae.active?(this.parent=ae,this.index=(ae.scopes||(ae.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let e,i;if(this.scopes){const n=this.scopes.slice();for(e=0,i=n.length;e<i;e++)n[e].pause()}for(e=0,i=this.effects.length;e<i;e++)this.effects[e].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let e,i;if(this.scopes){const s=this.scopes.slice();for(e=0,i=s.length;e<i;e++)s[e].resume()}const n=this.effects.slice();for(e=0,i=n.length;e<i;e++)n[e].resume()}}run(e){if(this._active){const i=ae;try{return ae=this,e()}finally{ae=i}}}on(){++this._on===1&&(this.prevScope=ae,ae=this)}off(){if(this._on>0&&--this._on===0){if(ae===this)ae=this.prevScope;else{let e=ae;for(;e;){if(e.prevScope===this){e.prevScope=this.prevScope;break}e=e.prevScope}}this.prevScope=void 0}}stop(e){if(this._active){this._active=!1;let i,n;for(i=0,n=this.effects.length;i<n;i++)this.effects[i].stop();for(this.effects.length=0,i=0,n=this.cleanups.length;i<n;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const s=this.scopes.slice();for(i=0,n=s.length;i<n;i++)s[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!e){const s=this.parent.scopes.pop();s&&s!==this&&(this.parent.scopes[this.index]=s,s.index=this.index)}this.parent=void 0}}}function Gc(){return ae}let Kt;const Ws=new WeakSet;class ul{constructor(e){this.fn=e,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,ae&&(ae.active?ae.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,Ws.has(this)&&(Ws.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||pl(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,rr(this),hl(this);const e=Kt,i=Re;Kt=this,Re=!0;try{return this.fn()}finally{ml(this),Kt=e,Re=i,this.flags&=-3}}stop(){if(this.flags&1){for(let e=this.deps;e;e=e.nextDep)Eo(e);this.deps=this.depsTail=void 0,rr(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?Ws.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){lo(this)&&this.run()}get dirty(){return lo(this)}}let fl=0,bn,yn;function pl(t,e=!1){if(t.flags|=8,e){t.next=yn,yn=t;return}t.next=bn,bn=t}function To(){fl++}function Bo(){if(--fl>0)return;if(yn){let e=yn;for(yn=void 0;e;){const i=e.next;e.next=void 0,e.flags&=-9,e=i}}let t;for(;bn;){let e=bn;for(bn=void 0;e;){const i=e.next;if(e.next=void 0,e.flags&=-9,e.flags&1)try{e.trigger()}catch(n){t||(t=n)}e=i}}if(t)throw t}function hl(t){for(let e=t.deps;e;e=e.nextDep)e.version=-1,e.prevActiveLink=e.dep.activeLink,e.dep.activeLink=e}function ml(t){let e,i=t.depsTail,n=i;for(;n;){const s=n.prevDep;n.version===-1?(n===i&&(i=s),Eo(n),Zc(n)):e=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=s}t.deps=e,t.depsTail=i}function lo(t){for(let e=t.deps;e;e=e.nextDep)if(e.dep.version!==e.version||e.dep.computed&&(gl(e.dep.computed)||e.dep.version!==e.version))return!0;return!!t._dirty}function gl(t){if(t.flags&4&&!(t.flags&16)||(t.flags&=-17,t.globalVersion===En)||(t.globalVersion=En,!t.isSSR&&t.flags&128&&(!t.deps&&!t._dirty||!lo(t))))return;t.flags|=2;const e=t.dep,i=Kt,n=Re;Kt=t,Re=!0;try{hl(t);const s=t.fn(t._value);(e.version===0||Ue(s,t._value))&&(t.flags|=128,t._value=s,e.version++)}catch(s){throw e.version++,s}finally{Kt=i,Re=n,ml(t),t.flags&=-3}}function Eo(t,e=!1){const{dep:i,prevSub:n,nextSub:s}=t;if(n&&(n.nextSub=s,t.prevSub=void 0),s&&(s.prevSub=n,t.nextSub=void 0),i.subs===t&&(i.subs=n,!n&&i.computed)){i.computed.flags&=-5;for(let o=i.computed.deps;o;o=o.nextDep)Eo(o,!0)}!e&&!--i.sc&&i.map&&i.map.delete(i.key)}function Zc(t){const{prevDep:e,nextDep:i}=t;e&&(e.nextDep=i,t.prevDep=void 0),i&&(i.prevDep=e,t.nextDep=void 0)}let Re=!0;const vl=[];function ni(){vl.push(Re),Re=!1}function si(){const t=vl.pop();Re=t===void 0?!0:t}function rr(t){const{cleanup:e}=t;if(t.cleanup=void 0,e){const i=Kt;Kt=void 0;try{e()}finally{Kt=i}}}let En=0;class Yc{constructor(e,i){this.sub=e,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class Mo{constructor(e){this.computed=e,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(e){if(!Kt||!Re||Kt===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==Kt)i=this.activeLink=new Yc(Kt,this),Kt.deps?(i.prevDep=Kt.depsTail,Kt.depsTail.nextDep=i,Kt.depsTail=i):Kt.deps=Kt.depsTail=i,bl(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const n=i.nextDep;n.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=n),i.prevDep=Kt.depsTail,i.nextDep=void 0,Kt.depsTail.nextDep=i,Kt.depsTail=i,Kt.deps===i&&(Kt.deps=n)}return i}trigger(e){this.version++,En++,this.notify(e)}notify(e){To();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{Bo()}}}function bl(t){if(t.dep.sc++,t.sub.flags&4){const e=t.dep.computed;if(e&&!t.dep.subs){e.flags|=20;for(let n=e.deps;n;n=n.nextDep)bl(n)}const i=t.dep.subs;i!==t&&(t.prevSub=i,i&&(i.nextSub=t)),t.dep.subs=t}}const ao=new WeakMap,Ri=Symbol(""),co=Symbol(""),Mn=Symbol("");function he(t,e,i){if(Re&&Kt){let n=ao.get(t);n||ao.set(t,n=new Map);let s=n.get(i);s||(n.set(i,s=new Mo),s.map=n,s.key=i),s.track()}}function Xe(t,e,i,n,s,o){const l=ao.get(t);if(!l){En++;return}const r=a=>{a&&a.trigger()};if(To(),e==="clear")l.forEach(r);else{const a=Tt(t),c=a&&Io(i);if(a&&i==="length"){const d=Number(n);l.forEach((m,b)=>{(b==="length"||b===Mn||!Pe(b)&&b>=d)&&r(m)})}else switch((i!==void 0||l.has(void 0))&&r(l.get(i)),c&&r(l.get(Mn)),e){case"add":a?c&&r(l.get("length")):(r(l.get(Ri)),Yi(t)&&r(l.get(co)));break;case"delete":a||(r(l.get(Ri)),Yi(t)&&r(l.get(co)));break;case"set":Yi(t)&&r(l.get(Ri));break}}Bo()}function Ui(t){const e=Ot(t);return e===t?e:(he(e,"iterate",Mn),Te(t)?e:e.map(Oe))}function Bs(t){return he(t=Ot(t),"iterate",Mn),t}function je(t,e){return oi(t)?en(Pi(t)?Oe(e):e):Oe(e)}const Jc={__proto__:null,[Symbol.iterator](){return Us(this,Symbol.iterator,t=>je(this,t))},concat(...t){return Ui(this).concat(...t.map(e=>Tt(e)?Ui(e):e))},entries(){return Us(this,"entries",t=>(t[1]=je(this,t[1]),t))},every(t,e){return Ze(this,"every",t,e,void 0,arguments)},filter(t,e){return Ze(this,"filter",t,e,i=>i.map(n=>je(this,n)),arguments)},find(t,e){return Ze(this,"find",t,e,i=>je(this,i),arguments)},findIndex(t,e){return Ze(this,"findIndex",t,e,void 0,arguments)},findLast(t,e){return Ze(this,"findLast",t,e,i=>je(this,i),arguments)},findLastIndex(t,e){return Ze(this,"findLastIndex",t,e,void 0,arguments)},forEach(t,e){return Ze(this,"forEach",t,e,void 0,arguments)},includes(...t){return Vs(this,"includes",t)},indexOf(...t){return Vs(this,"indexOf",t)},join(t){return Ui(this).join(t)},lastIndexOf(...t){return Vs(this,"lastIndexOf",t)},map(t,e){return Ze(this,"map",t,e,void 0,arguments)},pop(){return un(this,"pop")},push(...t){return un(this,"push",t)},reduce(t,...e){return lr(this,"reduce",t,e)},reduceRight(t,...e){return lr(this,"reduceRight",t,e)},shift(){return un(this,"shift")},some(t,e){return Ze(this,"some",t,e,void 0,arguments)},splice(...t){return un(this,"splice",t)},toReversed(){return Ui(this).toReversed()},toSorted(t){return Ui(this).toSorted(t)},toSpliced(...t){return Ui(this).toSpliced(...t)},unshift(...t){return un(this,"unshift",t)},values(){return Us(this,"values",t=>je(this,t))}};function Us(t,e,i){const n=Bs(t),s=n[e]();return n!==t&&!Te(t)&&(s._next=s.next,s.next=()=>{const o=s._next();return o.done||(o.value=i(o.value)),o}),s}const Xc=Array.prototype;function Ze(t,e,i,n,s,o){const l=Bs(t),r=l!==t&&!Te(t),a=l[e];if(a!==Xc[e]){const m=a.apply(t,o);return r?Oe(m):m}let c=i;l!==t&&(r?c=function(m,b){return i.call(this,je(t,m),b,t)}:i.length>2&&(c=function(m,b){return i.call(this,m,b,t)}));const d=a.call(l,c,n);return r&&s?s(d):d}function lr(t,e,i,n){const s=Bs(t),o=s!==t&&!Te(t);let l=i,r=!1;s!==t&&(o?(r=n.length===0,l=function(c,d,m){return r&&(r=!1,c=je(t,c)),i.call(this,c,je(t,d),m,t)}):i.length>3&&(l=function(c,d,m){return i.call(this,c,d,m,t)}));const a=s[e](l,...n);return r?je(t,a):a}function Vs(t,e,i){const n=Ot(t);he(n,"iterate",Mn);const s=n[e](...i);return(s===-1||s===!1)&&Ro(i[0])?(i[0]=Ot(i[0]),n[e](...i)):s}function un(t,e,i=[]){ni(),To();const n=Ot(t)[e].apply(t,i);return Bo(),si(),n}const Qc=Co("__proto__,__v_isRef,__isVue"),yl=new Set(Object.getOwnPropertyNames(Symbol).filter(t=>t!=="arguments"&&t!=="caller").map(t=>Symbol[t]).filter(Pe));function td(t){Pe(t)||(t=String(t));const e=Ot(this);return he(e,"has",t),e.hasOwnProperty(t)}class kl{constructor(e=!1,i=!1){this._isReadonly=e,this._isShallow=i}get(e,i,n){if(i==="__v_skip")return e.__v_skip;const s=this._isReadonly,o=this._isShallow;if(i==="__v_isReactive")return!s;if(i==="__v_isReadonly")return s;if(i==="__v_isShallow")return o;if(i==="__v_raw")return n===(s?o?dd:_l:o?Sl:xl).get(e)||Object.getPrototypeOf(e)===Object.getPrototypeOf(n)?e:void 0;const l=Tt(e);if(!s){let a;if(l&&(a=Jc[i]))return a;if(i==="hasOwnProperty")return td}const r=Reflect.get(e,i,Qt(e)?e:n);if((Pe(i)?yl.has(i):Qc(i))||(s||he(e,"get",i),o))return r;if(Qt(r)){const a=l&&Io(i)?r:r.value;return s&&Ht(a)?fo(a):a}return Ht(r)?s?fo(r):Es(r):r}}class wl extends kl{constructor(e=!1){super(!1,e)}set(e,i,n,s){let o=e[i];const l=Tt(e)&&Io(i);if(!this._isShallow){const c=oi(o);if(!Te(n)&&!oi(n)&&(o=Ot(o),n=Ot(n)),!l&&Qt(o)&&!Qt(n))return c||(o.value=n),!0}const r=l?Number(i)<e.length:zt(e,i),a=Reflect.set(e,i,n,Qt(e)?e:s);return e===Ot(s)&&a&&(r?Ue(n,o)&&Xe(e,"set",i,n):Xe(e,"add",i,n)),a}deleteProperty(e,i){const n=zt(e,i);e[i];const s=Reflect.deleteProperty(e,i);return s&&n&&Xe(e,"delete",i,void 0),s}has(e,i){const n=Reflect.has(e,i);return(!Pe(i)||!yl.has(i))&&he(e,"has",i),n}ownKeys(e){return he(e,"iterate",Tt(e)?"length":Ri),Reflect.ownKeys(e)}}class ed extends kl{constructor(e=!1){super(!0,e)}set(e,i){return!0}deleteProperty(e,i){return!0}}const id=new wl,nd=new ed,sd=new wl(!0);const uo=t=>t,qn=t=>Reflect.getPrototypeOf(t);function od(t,e,i){return function(...n){const s=this.__v_raw,o=Ot(s),l=Yi(o),r=t==="entries"||t===Symbol.iterator&&l,a=t==="keys"&&l,c=s[t](...n),d=i?uo:e?en:Oe;return!e&&he(o,"iterate",a?co:Ri),ue(Object.create(c),{next(){const{value:m,done:b}=c.next();return b?{value:m,done:b}:{value:r?[d(m[0]),d(m[1])]:d(m),done:b}}})}}function Kn(t){return function(...e){return t==="delete"?!1:t==="clear"?void 0:this}}function rd(t,e){const i={get(s){const o=this.__v_raw,l=Ot(o),r=Ot(s);t||(Ue(s,r)&&he(l,"get",s),he(l,"get",r));const{has:a}=qn(l),c=e?uo:t?en:Oe;if(a.call(l,s))return c(o.get(s));if(a.call(l,r))return c(o.get(r));o!==l&&o.get(s)},get size(){const s=this.__v_raw;return!t&&he(Ot(s),"iterate",Ri),s.size},has(s){const o=this.__v_raw,l=Ot(o),r=Ot(s);return t||(Ue(s,r)&&he(l,"has",s),he(l,"has",r)),s===r?o.has(s):o.has(s)||o.has(r)},forEach(s,o){const l=this,r=l.__v_raw,a=Ot(r),c=e?uo:t?en:Oe;return!t&&he(a,"iterate",Ri),r.forEach((d,m)=>s.call(o,c(d),c(m),l))}};return ue(i,t?{add:Kn("add"),set:Kn("set"),delete:Kn("delete"),clear:Kn("clear")}:{add(s){const o=Ot(this),l=qn(o),r=Ot(s),a=!e&&!Te(s)&&!oi(s)?r:s;return l.has.call(o,a)||Ue(s,a)&&l.has.call(o,s)||Ue(r,a)&&l.has.call(o,r)||(o.add(a),Xe(o,"add",a,a)),this},set(s,o){!e&&!Te(o)&&!oi(o)&&(o=Ot(o));const l=Ot(this),{has:r,get:a}=qn(l);let c=r.call(l,s);c||(s=Ot(s),c=r.call(l,s));const d=a.call(l,s);return l.set(s,o),c?Ue(o,d)&&Xe(l,"set",s,o):Xe(l,"add",s,o),this},delete(s){const o=Ot(this),{has:l,get:r}=qn(o);let a=l.call(o,s);a||(s=Ot(s),a=l.call(o,s)),r&&r.call(o,s);const c=o.delete(s);return a&&Xe(o,"delete",s,void 0),c},clear(){const s=Ot(this),o=s.size!==0,l=s.clear();return o&&Xe(s,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(s=>{i[s]=od(s,t,e)}),i}function Do(t,e){const i=rd(t,e);return(n,s,o)=>s==="__v_isReactive"?!t:s==="__v_isReadonly"?t:s==="__v_raw"?n:Reflect.get(zt(i,s)&&s in n?i:n,s,o)}const ld={get:Do(!1,!1)},ad={get:Do(!1,!0)},cd={get:Do(!0,!1)};const xl=new WeakMap,Sl=new WeakMap,_l=new WeakMap,dd=new WeakMap;function ud(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Es(t){return oi(t)?t:Lo(t,!1,id,ld,xl)}function fd(t){return Lo(t,!1,sd,ad,Sl)}function fo(t){return Lo(t,!0,nd,cd,_l)}function Lo(t,e,i,n,s){if(!Ht(t)||t.__v_raw&&!(e&&t.__v_isReactive)||t.__v_skip||!Object.isExtensible(t))return t;const o=s.get(t);if(o)return o;const l=ud(Oc(t));if(l===0)return t;const r=new Proxy(t,l===2?n:i);return s.set(t,r),r}function Pi(t){return oi(t)?Pi(t.__v_raw):!!(t&&t.__v_isReactive)}function oi(t){return!!(t&&t.__v_isReadonly)}function Te(t){return!!(t&&t.__v_isShallow)}function Ro(t){return t?!!t.__v_raw:!1}function Ot(t){const e=t&&t.__v_raw;return e?Ot(e):t}function pd(t){return!zt(t,"__v_skip")&&Object.isExtensible(t)&&ll(t,"__v_skip",!0),t}const Oe=t=>Ht(t)?Es(t):t,en=t=>Ht(t)?fo(t):t;function Qt(t){return t?t.__v_isRef===!0:!1}function bt(t){return hd(t,!1)}function hd(t,e){return Qt(t)?t:new md(t,e)}class md{constructor(e,i){this.dep=new Mo,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?e:Ot(e),this._value=i?e:Oe(e),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(e){const i=this._rawValue,n=this.__v_isShallow||Te(e)||oi(e);e=n?e:Ot(e),Ue(e,i)&&(this._rawValue=e,this._value=n?e:Oe(e),this.dep.trigger())}}function yt(t){return Qt(t)?t.value:t}const gd={get:(t,e,i)=>e==="__v_raw"?t:yt(Reflect.get(t,e,i)),set:(t,e,i,n)=>{const s=t[e];return Qt(s)&&!Qt(i)?(s.value=i,!0):Reflect.set(t,e,i,n)}};function Cl(t){return Pi(t)?t:new Proxy(t,gd)}class vd{constructor(e,i,n){this.fn=e,this.setter=i,this._value=void 0,this.dep=new Mo(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=En-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Kt!==this)return pl(this,!0),!0}get value(){const e=this.dep.track();return gl(this),e&&(e.version=this.dep.version),this._value}set value(e){this.setter&&this.setter(e)}}function bd(t,e,i=!1){let n,s;return Bt(t)?n=t:(n=t.get,s=t.set),new vd(n,s,i)}const Gn={},hs=new WeakMap;let Ei;function yd(t,e=!1,i=Ei){if(i){let n=hs.get(i);n||hs.set(i,n=[]),n.push(t)}}function kd(t,e,i=Vt){const{immediate:n,deep:s,once:o,scheduler:l,augmentJob:r,call:a}=i,c=B=>s?B:Te(B)||s===!1||s===0?Qe(B,1):Qe(B);let d,m,b,u,h=!1,f=!1;if(Qt(t)?(m=()=>t.value,h=Te(t)):Pi(t)?(m=()=>c(t),h=!0):Tt(t)?(f=!0,h=t.some(B=>Pi(B)||Te(B)),m=()=>t.map(B=>{if(Qt(B))return B.value;if(Pi(B))return c(B);if(Bt(B))return a?a(B,2):B()})):Bt(t)?e?m=a?()=>a(t,2):t:m=()=>{if(b){ni();try{b()}finally{si()}}const B=Ei;Ei=d;try{return a?a(t,3,[u]):t(u)}finally{Ei=B}}:m=qe,e&&s){const B=m,L=s===!0?1/0:s;m=()=>Qe(B(),L)}const v=Gc(),k=()=>{d.stop(),v&&v.active&&$o(v.effects,d)};if(o&&e){const B=e;e=(...L)=>{const T=B(...L);return k(),T}}let x=f?new Array(t.length).fill(Gn):Gn;const $=B=>{if(!(!(d.flags&1)||!d.dirty&&!B))if(e){const L=d.run();if(B||s||h||(f?L.some((T,w)=>Ue(T,x[w])):Ue(L,x))){b&&b();const T=Ei;Ei=d;try{const w=[L,x===Gn?void 0:f&&x[0]===Gn?[]:x,u];x=L,a?a(e,3,w):e(...w)}finally{Ei=T}}}else d.run()};return r&&r($),d=new ul(m),d.scheduler=l?()=>l($,!1):$,u=B=>yd(B,!1,d),b=d.onStop=()=>{const B=hs.get(d);if(B){if(a)a(B,4);else for(const L of B)L();hs.delete(d)}},e?n?$(!0):x=d.run():l?l($.bind(null,!0),!0):d.run(),k.pause=d.pause.bind(d),k.resume=d.resume.bind(d),k.stop=k,k}function Qe(t,e=1/0,i){if(e<=0||!Ht(t)||t.__v_skip||(i=i||new Map,(i.get(t)||0)>=e))return t;if(i.set(t,e),e--,Qt(t))Qe(t.value,e,i);else if(Tt(t))for(let n=0;n<t.length;n++)Qe(t[n],e,i);else if(rn(t)||Yi(t))t.forEach(n=>{Qe(n,e,i)});else if(rl(t)){for(const n in t)Qe(t[n],e,i);for(const n of Object.getOwnPropertySymbols(t))Object.prototype.propertyIsEnumerable.call(t,n)&&Qe(t[n],e,i)}return t}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Nn(t,e,i,n){try{return n?t(...n):t()}catch(s){Ms(s,e,i)}}function ze(t,e,i,n){if(Bt(t)){const s=Nn(t,e,i,n);return s&&sl(s)&&s.catch(o=>{Ms(o,e,i)}),s}if(Tt(t)){const s=[];for(let o=0;o<t.length;o++)s.push(ze(t[o],e,i,n));return s}}function Ms(t,e,i,n=!0){const s=e?e.vnode:null,{errorHandler:o,throwUnhandledErrorInProduction:l}=e&&e.appContext.config||Vt;if(e){let r=e.parent;const a=e.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const d=r.ec;if(d){for(let m=0;m<d.length;m++)if(d[m](t,a,c)===!1)return}r=r.parent}if(o){ni(),Nn(o,null,10,[t,a,c]),si();return}}wd(t,i,s,n,l)}function wd(t,e,i,n=!0,s=!1){if(s)throw t;console.error(t)}const ye=[];let He=-1;const Ji=[];let fi=null,Vi=0;const $l=Promise.resolve();let ms=null;function Il(t){const e=ms||$l;return t?e.then(this?t.bind(this):t):e}function xd(t){let e=He+1,i=ye.length;for(;e<i;){const n=e+i>>>1,s=ye[n],o=Dn(s);o<t||o===t&&s.flags&2?e=n+1:i=n}return e}function Po(t){if(!(t.flags&1)){const e=Dn(t),i=ye[ye.length-1];!i||!(t.flags&2)&&e>=Dn(i)?ye.push(t):ye.splice(xd(e),0,t),t.flags|=1,Al()}}function Al(){ms||(ms=$l.then(Bl))}function Sd(t){Tt(t)?Ji.push(...t):fi&&t.id===-1?fi.splice(Vi+1,0,t):t.flags&1||(Ji.push(t),t.flags|=1),Al()}function ar(t,e,i=He+1){for(;i<ye.length;i++){const n=ye[i];if(n&&n.flags&2){if(t&&n.id!==t.uid)continue;ye.splice(i,1),i--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function Tl(t){if(Ji.length){const e=[...new Set(Ji)].sort((i,n)=>Dn(i)-Dn(n));if(Ji.length=0,fi){fi.push(...e);return}for(fi=e,Vi=0;Vi<fi.length;Vi++){const i=fi[Vi];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}fi=null,Vi=0}}const Dn=t=>t.id==null?t.flags&2?-1:1/0:t.id;function Bl(t){try{for(He=0;He<ye.length;He++){const e=ye[He];e&&!(e.flags&8)&&(e.flags&4&&(e.flags&=-2),Nn(e,e.i,e.i?15:14),e.flags&4||(e.flags&=-2))}}finally{for(;He<ye.length;He++){const e=ye[He];e&&(e.flags&=-2)}He=-1,ye.length=0,Tl(),ms=null,(ye.length||Ji.length)&&Bl()}}let de=null,El=null;function gs(t){const e=de;return de=t,El=t&&t.type.__scopeId||null,e}function Ml(t,e=de,i){if(!e||t._n)return t;const n=(...s)=>{n._d&&kr(-1);const o=gs(e),l=ei.length;let r;try{r=t(...s)}finally{for(let a=ei.length;a>l;a--)jo();gs(o),n._d&&kr(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Be(t,e){if(de===null)return t;const i=Ps(de),n=t.dirs||(t.dirs=[]);for(let s=0;s<e.length;s++){let[o,l,r,a=Vt]=e[s];o&&(Bt(o)&&(o={mounted:o,updated:o}),o.deep&&Qe(l),n.push({dir:o,instance:i,value:l,oldValue:void 0,arg:r,modifiers:a}))}return t}function Ci(t,e,i,n){const s=t.dirs,o=e&&e.dirs;for(let l=0;l<s.length;l++){const r=s[l];o&&(r.oldValue=o[l].value);let a=r.dir[n];a&&(ni(),ze(a,i,8,[t.el,r,t,e]),si())}}function _d(t,e){if(me){let i=me.provides;const n=me.parent&&me.parent.provides;n===i&&(i=me.provides=Object.create(n)),i[t]=e}}function ti(t,e,i=!1){const n=xu();if(n||Qi){let s=Qi?Qi._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(s&&t in s)return s[t];if(arguments.length>1)return i&&Bt(e)?e.call(n&&n.proxy):e}}const Cd=Symbol.for("v-scx"),$d=()=>ti(Cd);function Oi(t,e,i){return Dl(t,e,i)}function Dl(t,e,i=Vt){const{immediate:n,deep:s,flush:o,once:l}=i,r=ue({},i),a=e&&n||!e&&o!=="post";let c;if(Rn){if(o==="sync"){const u=$d();c=u.__watcherHandles||(u.__watcherHandles=[])}else if(!a){const u=()=>{};return u.stop=qe,u.resume=qe,u.pause=qe,u}}const d=me;r.call=(u,h,f)=>ze(u,d,h,f);let m=!1;o==="post"?r.scheduler=u=>{xe(u,d&&d.suspense)}:o!=="sync"&&(m=!0,r.scheduler=(u,h)=>{h?u():Po(u)}),r.augmentJob=u=>{e&&(u.flags|=4),m&&(u.flags|=2,d&&(u.id=d.uid,u.i=d))};const b=kd(t,e,r);return Rn&&(c?c.push(b):a&&b()),b}function Id(t,e,i){const n=this.proxy,s=ie(t)?t.includes(".")?Ll(n,t):()=>n[t]:t.bind(n,n);let o;Bt(e)?o=e:(o=e.handler,i=e);const l=Hn(this),r=Dl(s,o.bind(n),i);return l(),r}function Ll(t,e){const i=e.split(".");return()=>{let n=t;for(let s=0;s<i.length&&n;s++)n=n[i[s]];return n}}const Ad=Symbol("_vte"),Td=t=>t.__isTeleport,qs=Symbol("_leaveCb");function Oo(t,e){t.shapeFlag&6&&t.component?(t.transition=e,Oo(t.component.subTree,e)):t.shapeFlag&128?(t.ssContent.transition=e.clone(t.ssContent),t.ssFallback.transition=e.clone(t.ssFallback)):t.transition=e}function Ce(t,e){return Bt(t)?ue({name:t.name},e,{setup:t}):t}function Rl(t){t.ids=[t.ids[0]+t.ids[2]+++"-",0,0]}function cr(t,e){let i;return!!((i=Object.getOwnPropertyDescriptor(t,e))&&!i.configurable)}const vs=new WeakMap;function kn(t,e,i,n,s=!1){if(Tt(t)){t.forEach((f,v)=>kn(f,e&&(Tt(e)?e[v]:e),i,n,s));return}if(Xi(n)&&!s){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&kn(t,e,i,n.component.subTree);return}const o=n.shapeFlag&4?Ps(n.component):n.el,l=s?null:o,{i:r,r:a}=t,c=e&&e.r,d=r.refs===Vt?r.refs={}:r.refs,m=r.setupState,b=Ot(m),u=m===Vt?nl:f=>cr(d,f)?!1:zt(b,f),h=(f,v)=>!(v&&cr(d,v));if(c!=null&&c!==a){if(dr(e),ie(c))d[c]=null,u(c)&&(m[c]=null);else if(Qt(c)){const f=e;h(c,f.k)&&(c.value=null),f.k&&(d[f.k]=null)}}if(Bt(a))Nn(a,r,12,[l,d]);else{const f=ie(a),v=Qt(a);if(f||v){const k=()=>{if(t.f){const x=f?u(a)?m[a]:d[a]:h()||!t.k?a.value:d[t.k];if(s)Tt(x)&&$o(x,o);else if(Tt(x))x.includes(o)||x.push(o);else if(f)d[a]=[o],u(a)&&(m[a]=d[a]);else{const $=[o];h(a,t.k)&&(a.value=$),t.k&&(d[t.k]=$)}}else f?(d[a]=l,u(a)&&(m[a]=l)):v&&(h(a,t.k)&&(a.value=l),t.k&&(d[t.k]=l))};if(l){const x=()=>{k(),vs.delete(t)};x.id=-1,vs.set(t,x),xe(x,i)}else dr(t),k()}}}function dr(t){const e=vs.get(t);e&&(e.flags|=8,vs.delete(t))}Ts().requestIdleCallback;Ts().cancelIdleCallback;const Xi=t=>!!t.type.__asyncLoader,Pl=t=>t.type.__isKeepAlive;function Bd(t,e){Ol(t,"a",e)}function Ed(t,e){Ol(t,"da",e)}function Ol(t,e,i=me){const n=t.__wdc||(t.__wdc=()=>{let s=i;for(;s;){if(s.isDeactivated)return;s=s.parent}return t()});if(Ds(e,n,i),i){let s=i.parent;for(;s&&s.parent;)Pl(s.parent.vnode)&&Md(n,e,i,s),s=s.parent}}function Md(t,e,i,n){const s=Ds(e,t,n,!0);No(()=>{$o(n[e],s)},i)}function Ds(t,e,i=me,n=!1){if(i){const s=i[t]||(i[t]=[]),o=e.__weh||(e.__weh=(...l)=>{ni();const r=Hn(i),a=ze(e,i,t,l);return r(),si(),a});return n?s.unshift(o):s.push(o),o}}const li=t=>(e,i=me)=>{(!Rn||t==="sp")&&Ds(t,(...n)=>e(...n),i)},Dd=li("bm"),Fn=li("m"),Ld=li("bu"),Rd=li("u"),zo=li("bum"),No=li("um"),Pd=li("sp"),Od=li("rtg"),zd=li("rtc");function Nd(t,e=me){Ds("ec",t,e)}const Fd="components";function Hd(t,e){return Wd(Fd,t,!0,e)||t}const jd=Symbol.for("v-ndc");function Wd(t,e,i=!0,n=!1){const s=de||me;if(s){const o=s.type;{const r=Iu(o,!1);if(r&&(r===e||r===we(e)||r===Is(we(e))))return o}const l=ur(s[t]||o[t],e)||ur(s.appContext[t],e);return!l&&n?o:l}}function ur(t,e){return t&&(t[e]||t[we(e)]||t[Is(we(e))])}function ke(t,e,i,n){let s;const o=i,l=Tt(t);if(l||ie(t)){const r=l&&Pi(t);let a=!1,c=!1;r&&(a=!Te(t),c=oi(t),t=Bs(t)),s=new Array(t.length);for(let d=0,m=t.length;d<m;d++)s[d]=e(a?c?en(Oe(t[d])):Oe(t[d]):t[d],d,void 0,o)}else if(typeof t=="number"){s=new Array(t);for(let r=0;r<t;r++)s[r]=e(r+1,r,void 0,o)}else if(Ht(t))if(t[Symbol.iterator])s=Array.from(t,(r,a)=>e(r,a,void 0,o));else{const r=Object.keys(t);s=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const d=r[a];s[a]=e(t[d],d,a,o)}}else s=[];return s}function Zn(t,e,i={},n,s,o){if(de.ce||de.parent&&Xi(de.parent)&&de.parent.ce){const c=i,d=Object.keys(c).length>0;return e!=="default"&&(c.name=e),st(),De(qt,null,[dt("slot",c,n&&n())],d?-2:64)}let l=t[e];l&&l._c&&(l._d=!1);const r=ei.length;st();let a;try{const c=l&&zl(l(i)),d=i.key||o||c&&c.key;a=De(qt,{key:(d&&!Pe(d)?d:`_${e}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&t._===1?64:-2)}catch(c){for(let d=ei.length;d>r;d--)jo();throw c}finally{l&&l._c&&(l._d=!0)}return a}function zl(t){return t.some(e=>Wo(e)?!(e.type===ri||e.type===qt&&!zl(e.children)):!0)?t:null}const po=t=>t?sa(t)?Ps(t):po(t.parent):null,wn=ue(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>po(t.parent),$root:t=>po(t.root),$host:t=>t.ce,$emit:t=>t.emit,$options:t=>Fl(t),$forceUpdate:t=>t.f||(t.f=()=>{Po(t.update)}),$nextTick:t=>t.n||(t.n=Il.bind(t.proxy)),$watch:t=>Id.bind(t)}),Ks=(t,e)=>t!==Vt&&!t.__isScriptSetup&&zt(t,e),Ud={get({_:t},e){if(e==="__v_skip")return!0;const{ctx:i,setupState:n,data:s,props:o,accessCache:l,type:r,appContext:a}=t;if(e[0]!=="$"){const b=l[e];if(b!==void 0)switch(b){case 1:return n[e];case 2:return s[e];case 4:return i[e];case 3:return o[e]}else{if(Ks(n,e))return l[e]=1,n[e];if(s!==Vt&&zt(s,e))return l[e]=2,s[e];if(zt(o,e))return l[e]=3,o[e];if(i!==Vt&&zt(i,e))return l[e]=4,i[e];ho&&(l[e]=0)}}const c=wn[e];let d,m;if(c)return e==="$attrs"&&he(t.attrs,"get",""),c(t);if((d=r.__cssModules)&&(d=d[e]))return d;if(i!==Vt&&zt(i,e))return l[e]=4,i[e];if(m=a.config.globalProperties,zt(m,e))return m[e]},set({_:t},e,i){const{data:n,setupState:s,ctx:o}=t;return Ks(s,e)?(s[e]=i,!0):n!==Vt&&zt(n,e)?(n[e]=i,!0):zt(t.props,e)||e[0]==="$"&&e.slice(1)in t?!1:(o[e]=i,!0)},has({_:{data:t,setupState:e,accessCache:i,ctx:n,appContext:s,props:o,type:l}},r){let a;return!!(i[r]||t!==Vt&&r[0]!=="$"&&zt(t,r)||Ks(e,r)||zt(o,r)||zt(n,r)||zt(wn,r)||zt(s.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(t,e,i){return i.get!=null?t._.accessCache[e]=0:zt(i,"value")&&this.set(t,e,i.value,null),Reflect.defineProperty(t,e,i)}};function fr(t){return Tt(t)?t.reduce((e,i)=>(e[i]=null,e),{}):t}let ho=!0;function Vd(t){const e=Fl(t),i=t.proxy,n=t.ctx;ho=!1,e.beforeCreate&&pr(e.beforeCreate,t,"bc");const{data:s,computed:o,methods:l,watch:r,provide:a,inject:c,created:d,beforeMount:m,mounted:b,beforeUpdate:u,updated:h,activated:f,deactivated:v,beforeDestroy:k,beforeUnmount:x,destroyed:$,unmounted:B,render:L,renderTracked:T,renderTriggered:w,errorCaptured:W,serverPrefetch:V,expose:q,inheritAttrs:X,components:C,directives:z,filters:y}=e;if(c&&qd(c,n,null),l)for(const E in l){const P=l[E];Bt(P)&&(n[E]=P.bind(i))}if(s){const E=s.call(i,i);Ht(E)&&(t.data=Es(E))}if(ho=!0,o)for(const E in o){const P=o[E],j=Bt(P)?P.bind(i,i):Bt(P.get)?P.get.bind(i,i):qe,tt=!Bt(P)&&Bt(P.set)?P.set.bind(i):qe,A=_t({get:j,set:tt});Object.defineProperty(n,E,{enumerable:!0,configurable:!0,get:()=>A.value,set:M=>A.value=M})}if(r)for(const E in r)Nl(r[E],n,i,E);if(a){const E=Bt(a)?a.call(i):a;Reflect.ownKeys(E).forEach(P=>{_d(P,E[P])})}d&&pr(d,t,"c");function U(E,P){Tt(P)?P.forEach(j=>E(j.bind(i))):P&&E(P.bind(i))}if(U(Dd,m),U(Fn,b),U(Ld,u),U(Rd,h),U(Bd,f),U(Ed,v),U(Nd,W),U(zd,T),U(Od,w),U(zo,x),U(No,B),U(Pd,V),Tt(q))if(q.length){const E=t.exposed||(t.exposed={});q.forEach(P=>{Object.defineProperty(E,P,{get:()=>i[P],set:j=>i[P]=j,enumerable:!0})})}else t.exposed||(t.exposed={});L&&t.render===qe&&(t.render=L),X!=null&&(t.inheritAttrs=X),C&&(t.components=C),z&&(t.directives=z),V&&Rl(t)}function qd(t,e,i=qe){Tt(t)&&(t=mo(t));for(const n in t){const s=t[n];let o;Ht(s)?"default"in s?o=ti(s.from||n,s.default,!0):o=ti(s.from||n):o=ti(s),Qt(o)?Object.defineProperty(e,n,{enumerable:!0,configurable:!0,get:()=>o.value,set:l=>o.value=l}):e[n]=o}}function pr(t,e,i){ze(Tt(t)?t.map(n=>n.bind(e.proxy)):t.bind(e.proxy),e,i)}function Nl(t,e,i,n){let s=n.includes(".")?Ll(i,n):()=>i[n];if(ie(t)){const o=e[t];Bt(o)&&Oi(s,o)}else if(Bt(t))Oi(s,t.bind(i));else if(Ht(t))if(Tt(t))t.forEach(o=>Nl(o,e,i,n));else{const o=Bt(t.handler)?t.handler.bind(i):e[t.handler];Bt(o)&&Oi(s,o,t)}}function Fl(t){const e=t.type,{mixins:i,extends:n}=e,{mixins:s,optionsCache:o,config:{optionMergeStrategies:l}}=t.appContext,r=o.get(e);let a;return r?a=r:!s.length&&!i&&!n?a=e:(a={},s.length&&s.forEach(c=>bs(a,c,l,!0)),bs(a,e,l)),Ht(e)&&o.set(e,a),a}function bs(t,e,i,n=!1){const{mixins:s,extends:o}=e;o&&bs(t,o,i,!0),s&&s.forEach(l=>bs(t,l,i,!0));for(const l in e)if(!(n&&l==="expose")){const r=Kd[l]||i&&i[l];t[l]=r?r(t[l],e[l]):e[l]}return t}const Kd={data:hr,props:mr,emits:mr,methods:hn,computed:hn,beforeCreate:be,created:be,beforeMount:be,mounted:be,beforeUpdate:be,updated:be,beforeDestroy:be,beforeUnmount:be,destroyed:be,unmounted:be,activated:be,deactivated:be,errorCaptured:be,serverPrefetch:be,components:hn,directives:hn,watch:Zd,provide:hr,inject:Gd};function hr(t,e){return e?t?function(){return ue(Bt(t)?t.call(this,this):t,Bt(e)?e.call(this,this):e)}:e:t}function Gd(t,e){return hn(mo(t),mo(e))}function mo(t){if(Tt(t)){const e={};for(let i=0;i<t.length;i++)e[t[i]]=t[i];return e}return t}function be(t,e){return t?[...new Set([].concat(t,e))]:e}function hn(t,e){return t?ue(Object.create(null),t,e):e}function mr(t,e){return t?Tt(t)&&Tt(e)?[...new Set([...t,...e])]:ue(Object.create(null),fr(t),fr(e??{})):e}function Zd(t,e){if(!t)return e;if(!e)return t;const i=ue(Object.create(null),t);for(const n in e)i[n]=be(t[n],e[n]);return i}function Hl(){return{app:null,config:{isNativeTag:nl,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Yd=0;function Jd(t,e){return function(n,s=null){Bt(n)||(n=ue({},n)),s!=null&&!Ht(s)&&(s=null);const o=Hl(),l=new WeakSet,r=[];let a=!1;const c=o.app={_uid:Yd++,_component:n,_props:s,_container:null,_context:o,_instance:null,version:Tu,get config(){return o.config},set config(d){},use(d,...m){return l.has(d)||(d&&Bt(d.install)?(l.add(d),d.install(c,...m)):Bt(d)&&(l.add(d),d(c,...m))),c},mixin(d){return o.mixins.includes(d)||o.mixins.push(d),c},component(d,m){return m?(o.components[d]=m,c):o.components[d]},directive(d,m){return m?(o.directives[d]=m,c):o.directives[d]},mount(d,m,b){if(!a){const u=c._ceVNode||dt(n,s);return u.appContext=o,b===!0?b="svg":b===!1&&(b=void 0),t(u,d,b),a=!0,c._container=d,d.__vue_app__=c,Ps(u.component)}},onUnmount(d){r.push(d)},unmount(){a&&(ze(r,c._instance,16),t(null,c._container),delete c._container.__vue_app__)},provide(d,m){return o.provides[d]=m,c},runWithContext(d){const m=Qi;Qi=c;try{return d()}finally{Qi=m}}};return c}}let Qi=null;const Xd=(t,e)=>e==="modelValue"||e==="model-value"?t.modelModifiers:t[`${e}Modifiers`]||t[`${we(e)}Modifiers`]||t[`${xi(e)}Modifiers`];function Qd(t,e,...i){if(t.isUnmounted)return;const n=t.vnode.props||Vt;let s=i;const o=e.startsWith("update:"),l=o&&Xd(n,e.slice(7));l&&(l.trim&&(s=i.map(d=>ie(d)?d.trim():d)),l.number&&(s=i.map(As)));let r,a=n[r=Hs(e)]||n[r=Hs(we(e))];!a&&o&&(a=n[r=Hs(xi(e))]),a&&ze(a,t,6,s);const c=n[r+"Once"];if(c){if(!t.emitted)t.emitted={};else if(t.emitted[r])return;t.emitted[r]=!0,ze(c,t,6,s)}}const tu=new WeakMap;function jl(t,e,i=!1){const n=i?tu:e.emitsCache,s=n.get(t);if(s!==void 0)return s;const o=t.emits;let l={},r=!1;if(!Bt(t)){const a=c=>{const d=jl(c,e,!0);d&&(r=!0,ue(l,d))};!i&&e.mixins.length&&e.mixins.forEach(a),t.extends&&a(t.extends),t.mixins&&t.mixins.forEach(a)}return!o&&!r?(Ht(t)&&n.set(t,null),null):(Tt(o)?o.forEach(a=>l[a]=null):ue(l,o),Ht(t)&&n.set(t,l),l)}function Ls(t,e){return!t||!_s(e)?!1:(e=e.slice(2),e=e==="Once"?e:e.replace(/Once$/,""),zt(t,e[0].toLowerCase()+e.slice(1))||zt(t,xi(e))||zt(t,e))}function gr(t){const{type:e,vnode:i,proxy:n,withProxy:s,propsOptions:[o],slots:l,attrs:r,emit:a,render:c,renderCache:d,props:m,data:b,setupState:u,ctx:h,inheritAttrs:f}=t,v=gs(t);let k,x;try{if(i.shapeFlag&4){const B=s||n,L=B;k=We(c.call(L,B,d,m,u,b,h)),x=r}else{const B=e;k=We(B.length>1?B(m,{attrs:r,slots:l,emit:a}):B(m,null)),x=e.props?r:eu(r)}}catch(B){ei.length=0,Ms(B,t,1),k=dt(ri)}let $=k;if(x&&f!==!1){const B=Object.keys(x),{shapeFlag:L}=$;B.length&&L&7&&(o&&B.some(Cs)&&(x=iu(x,o)),$=nn($,x,!1,!0))}return i.dirs&&($=nn($,null,!1,!0),$.dirs=$.dirs?$.dirs.concat(i.dirs):i.dirs),i.transition&&Oo($,i.transition),k=$,gs(v),k}const eu=t=>{let e;for(const i in t)(i==="class"||i==="style"||_s(i))&&((e||(e={}))[i]=t[i]);return e},iu=(t,e)=>{const i={};for(const n in t)(!Cs(n)||!(n.slice(9)in e))&&(i[n]=t[n]);return i};function nu(t,e,i){const{props:n,children:s,component:o}=t,{props:l,children:r,patchFlag:a}=e,c=o.emitsOptions;if(e.dirs||e.transition)return!0;if(i&&a>=0){if(a&1024)return!0;if(a&16)return n?vr(n,l,c):!!l;if(a&8){const d=e.dynamicProps;for(let m=0;m<d.length;m++){const b=d[m];if(Wl(l,n,b)&&!Ls(c,b))return!0}}}else return(s||r)&&(!r||!r.$stable)?!0:n===l?!1:n?l?vr(n,l,c):!0:!!l;return!1}function vr(t,e,i){const n=Object.keys(e);if(n.length!==Object.keys(t).length)return!0;for(let s=0;s<n.length;s++){const o=n[s];if(Wl(e,t,o)&&!Ls(i,o))return!0}return!1}function Wl(t,e,i){const n=t[i],s=e[i];return i==="style"&&Ht(n)&&Ht(s)?!ln(n,s):n!==s}function su({vnode:t,parent:e,suspense:i},n){for(;e;){const s=e.subTree;if(s.suspense&&s.suspense.activeBranch===t&&(s.suspense.vnode.el=s.el=n,t=s),s===t)(t=e.vnode).el=n,e=e.parent;else break}i&&i.activeBranch===t&&(i.vnode.el=n)}const Ul={},Vl=()=>Object.create(Ul),ql=t=>Object.getPrototypeOf(t)===Ul;function ou(t,e,i,n=!1){const s={},o=Vl();t.propsDefaults=Object.create(null),Kl(t,e,s,o);for(const l in t.propsOptions[0])l in s||(s[l]=void 0);i?t.props=n?s:fd(s):t.type.props?t.props=s:t.props=o,t.attrs=o}function ru(t,e,i,n){const{props:s,attrs:o,vnode:{patchFlag:l}}=t,r=Ot(s),[a]=t.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const d=t.vnode.dynamicProps;for(let m=0;m<d.length;m++){let b=d[m];if(Ls(t.emitsOptions,b))continue;const u=e[b];if(a)if(zt(o,b))u!==o[b]&&(o[b]=u,c=!0);else{const h=we(b);s[h]=go(a,r,h,u,t,!1)}else u!==o[b]&&(o[b]=u,c=!0)}}}else{Kl(t,e,s,o)&&(c=!0);let d;for(const m in r)(!e||!zt(e,m)&&((d=xi(m))===m||!zt(e,d)))&&(a?i&&(i[m]!==void 0||i[d]!==void 0)&&(s[m]=go(a,r,m,void 0,t,!0)):delete s[m]);if(o!==r)for(const m in o)(!e||!zt(e,m))&&(delete o[m],c=!0)}c&&Xe(t.attrs,"set","")}function Kl(t,e,i,n){const[s,o]=t.propsOptions;let l=!1,r;if(e)for(let a in e){if(vn(a))continue;const c=e[a];let d;s&&zt(s,d=we(a))?!o||!o.includes(d)?i[d]=c:(r||(r={}))[d]=c:Ls(t.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(o){const a=Ot(i),c=r||Vt;for(let d=0;d<o.length;d++){const m=o[d];i[m]=go(s,a,m,c[m],t,!zt(c,m))}}return l}function go(t,e,i,n,s,o){const l=t[i];if(l!=null){const r=zt(l,"default");if(r&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&Bt(a)){const{propsDefaults:c}=s;if(i in c)n=c[i];else{const d=Hn(s);n=c[i]=a.call(null,e),d()}}else n=a;s.ce&&s.ce._setProp(i,n)}l[0]&&(o&&!r?n=!1:l[1]&&(n===""||n===xi(i))&&(n=!0))}return n}const lu=new WeakMap;function Gl(t,e,i=!1){const n=i?lu:e.propsCache,s=n.get(t);if(s)return s;const o=t.props,l={},r=[];let a=!1;if(!Bt(t)){const d=m=>{a=!0;const[b,u]=Gl(m,e,!0);ue(l,b),u&&r.push(...u)};!i&&e.mixins.length&&e.mixins.forEach(d),t.extends&&d(t.extends),t.mixins&&t.mixins.forEach(d)}if(!o&&!a)return Ht(t)&&n.set(t,Zi),Zi;if(Tt(o))for(let d=0;d<o.length;d++){const m=we(o[d]);br(m)&&(l[m]=Vt)}else if(o)for(const d in o){const m=we(d);if(br(m)){const b=o[d],u=l[m]=Tt(b)||Bt(b)?{type:b}:ue({},b),h=u.type;let f=!1,v=!0;if(Tt(h))for(let k=0;k<h.length;++k){const x=h[k],$=Bt(x)&&x.name;if($==="Boolean"){f=!0;break}else $==="String"&&(v=!1)}else f=Bt(h)&&h.name==="Boolean";u[0]=f,u[1]=v,(f||zt(u,"default"))&&r.push(m)}}const c=[l,r];return Ht(t)&&n.set(t,c),c}function br(t){return t[0]!=="$"&&!vn(t)}const Fo=t=>t==="_"||t==="_ctx"||t==="$stable",Ho=t=>Tt(t)?t.map(We):[We(t)],au=(t,e,i)=>{if(e._n)return e;const n=Ml((...s)=>Ho(e(...s)),i);return n._c=!1,n},Zl=(t,e,i)=>{const n=t._ctx;for(const s in t){if(Fo(s))continue;const o=t[s];if(Bt(o))e[s]=au(s,o,n);else if(o!=null){const l=Ho(o);e[s]=()=>l}}},Yl=(t,e)=>{const i=Ho(e);t.slots.default=()=>i},Jl=(t,e,i)=>{for(const n in e)(i||!Fo(n))&&(t[n]=e[n])},cu=(t,e,i)=>{const n=t.slots=Vl();if(t.vnode.shapeFlag&32){const s=e._;s?(Jl(n,e,i),i&&ll(n,"_",s,!0)):Zl(e,n)}else e&&Yl(t,e)},du=(t,e,i)=>{const{vnode:n,slots:s}=t;let o=!0,l=Vt;if(n.shapeFlag&32){const r=e._;r?i&&r===1?o=!1:Jl(s,e,i):(o=!e.$stable,Zl(e,s)),l=e}else e&&(Yl(t,e),l={default:1});if(o)for(const r in s)!Fo(r)&&l[r]==null&&delete s[r]},xe=mu;function uu(t){return fu(t)}function fu(t,e){const i=Ts();i.__VUE__=!0;const{insert:n,remove:s,patchProp:o,createElement:l,createText:r,createComment:a,setText:c,setElementText:d,parentNode:m,nextSibling:b,setScopeId:u=qe,insertStaticContent:h}=t,f=(_,O,g,N=null,F=null,S=null,I=void 0,R=null,Z=!!O.dynamicChildren)=>{if(_===O)return;_&&!fn(_,O)&&(N=pt(_),M(_,F,S,!0),_=null),O.patchFlag===-2&&(Z=!1,O.dynamicChildren=null);const{type:G,ref:K,shapeFlag:nt}=O;switch(G){case Rs:v(_,O,g,N);break;case ri:k(_,O,g,N);break;case es:_==null&&x(O,g,N,I);break;case qt:C(_,O,g,N,F,S,I,R,Z);break;default:nt&1?L(_,O,g,N,F,S,I,R,Z):nt&6?z(_,O,g,N,F,S,I,R,Z):(nt&64||nt&128)&&G.process(_,O,g,N,F,S,I,R,Z,at)}K!=null&&F?kn(K,_&&_.ref,S,O||_,!O):K==null&&_&&_.ref!=null&&kn(_.ref,null,S,_,!0)},v=(_,O,g,N)=>{if(_==null)n(O.el=r(O.children),g,N);else{const F=O.el=_.el;O.children!==_.children&&c(F,O.children)}},k=(_,O,g,N)=>{_==null?n(O.el=a(O.children||""),g,N):O.el=_.el},x=(_,O,g,N)=>{[_.el,_.anchor]=h(_.children,O,g,N,_.el,_.anchor)},$=({el:_,anchor:O},g,N)=>{let F;for(;_&&_!==O;)F=b(_),n(_,g,N),_=F;n(O,g,N)},B=({el:_,anchor:O})=>{let g;for(;_&&_!==O;)g=b(_),s(_),_=g;s(O)},L=(_,O,g,N,F,S,I,R,Z)=>{if(O.type==="svg"?I="svg":O.type==="math"&&(I="mathml"),_==null)T(O,g,N,F,S,I,R,Z);else{const G=_.el&&_.el._isVueCE?_.el:null;try{G&&G._beginPatch(),V(_,O,F,S,I,R,Z)}finally{G&&G._endPatch()}}},T=(_,O,g,N,F,S,I,R)=>{let Z,G;const{props:K,shapeFlag:nt,transition:ct,dirs:rt}=_;if(Z=_.el=l(_.type,S,K&&K.is,K),nt&8?d(Z,_.children):nt&16&&W(_.children,Z,null,N,F,Gs(_,S),I,R),rt&&Ci(_,null,N,"created"),w(Z,_,_.scopeId,I,N),K){for(const $t in K)$t!=="value"&&!vn($t)&&o(Z,$t,null,K[$t],S,N);"value"in K&&o(Z,"value",null,K.value,S),(G=K.onVnodeBeforeMount)&&Fe(G,N,_)}rt&&Ci(_,null,N,"beforeMount");const mt=pu(F,ct);mt&&ct.beforeEnter(Z),n(Z,O,g),((G=K&&K.onVnodeMounted)||mt||rt)&&xe(()=>{try{G&&Fe(G,N,_),mt&&ct.enter(Z),rt&&Ci(_,null,N,"mounted")}finally{}},F)},w=(_,O,g,N,F)=>{if(g&&u(_,g),N)for(let S=0;S<N.length;S++)u(_,N[S]);if(F){let S=F.subTree;if(O===S||ea(S.type)&&(S.ssContent===O||S.ssFallback===O)){const I=F.vnode;w(_,I,I.scopeId,I.slotScopeIds,F.parent)}}},W=(_,O,g,N,F,S,I,R,Z=0)=>{for(let G=Z;G<_.length;G++){const K=_[G]=R?Je(_[G]):We(_[G]);f(null,K,O,g,N,F,S,I,R)}},V=(_,O,g,N,F,S,I)=>{const R=O.el=_.el;let{patchFlag:Z,dynamicChildren:G,dirs:K}=O;Z|=_.patchFlag&16;const nt=_.props||Vt,ct=O.props||Vt;let rt;if(g&&$i(g,!1),(rt=ct.onVnodeBeforeUpdate)&&Fe(rt,g,O,_),K&&Ci(O,_,g,"beforeUpdate"),g&&$i(g,!0),G&&(!_.dynamicChildren||_.dynamicChildren.length!==G.length)&&(Z=0,I=!1,G=null),(nt.innerHTML&&ct.innerHTML==null||nt.textContent&&ct.textContent==null)&&d(R,""),G?q(_.dynamicChildren,G,R,g,N,Gs(O,F),S):I||P(_,O,R,null,g,N,Gs(O,F),S,!1),Z>0){if(Z&16)X(R,nt,ct,g,F);else if(Z&2&&nt.class!==ct.class&&o(R,"class",null,ct.class,F),Z&4&&o(R,"style",nt.style,ct.style,F),Z&8){const mt=O.dynamicProps;for(let $t=0;$t<mt.length;$t++){const xt=mt[$t],Lt=nt[xt],Zt=ct[xt];(Zt!==Lt||xt==="value")&&o(R,xt,Lt,Zt,F,g)}}Z&1&&_.children!==O.children&&d(R,O.children)}else!I&&G==null&&X(R,nt,ct,g,F);((rt=ct.onVnodeUpdated)||K)&&xe(()=>{rt&&Fe(rt,g,O,_),K&&Ci(O,_,g,"updated")},N)},q=(_,O,g,N,F,S,I)=>{for(let R=0;R<O.length;R++){const Z=_[R],G=O[R],K=Z.el&&(Z.type===qt||!fn(Z,G)||Z.shapeFlag&198)?m(Z.el):g;f(Z,G,K,null,N,F,S,I,!0)}},X=(_,O,g,N,F)=>{if(O!==g){if(O!==Vt)for(const S in O)!vn(S)&&!(S in g)&&o(_,S,O[S],null,F,N);for(const S in g){if(vn(S))continue;const I=g[S],R=O[S];I!==R&&S!=="value"&&o(_,S,R,I,F,N)}"value"in g&&o(_,"value",O.value,g.value,F)}},C=(_,O,g,N,F,S,I,R,Z)=>{const G=O.el=_?_.el:r(""),K=O.anchor=_?_.anchor:r("");let{patchFlag:nt,dynamicChildren:ct,slotScopeIds:rt}=O;rt&&(R=R?R.concat(rt):rt),_==null?(n(G,g,N),n(K,g,N),W(O.children||[],g,K,F,S,I,R,Z)):nt>0&&nt&64&&ct&&_.dynamicChildren&&_.dynamicChildren.length===ct.length?(q(_.dynamicChildren,ct,g,F,S,I,R),(O.key!=null||F&&O===F.subTree)&&Xl(_,O,!0)):P(_,O,g,K,F,S,I,R,Z)},z=(_,O,g,N,F,S,I,R,Z)=>{O.slotScopeIds=R,_==null?O.shapeFlag&512?F.ctx.activate(O,g,N,I,Z):y(O,g,N,F,S,I,Z):D(_,O,Z)},y=(_,O,g,N,F,S,I)=>{const R=_.component=wu(_,N,F);if(Pl(_)&&(R.ctx.renderer=at),Su(R,!1,I),R.asyncDep){if(F&&F.registerDep(R,U,I),!_.el){const Z=R.subTree=dt(ri);k(null,Z,O,g),_.placeholder=Z.el}}else U(R,_,O,g,F,S,I)},D=(_,O,g)=>{const N=O.component=_.component;if(nu(_,O,g))if(N.asyncDep&&!N.asyncResolved){E(N,O,g);return}else N.next=O,N.update();else O.el=_.el,N.vnode=O},U=(_,O,g,N,F,S,I)=>{const R=()=>{if(_.isMounted){let{next:nt,bu:ct,u:rt,parent:mt,vnode:$t}=_;{const Xt=Ql(_);if(Xt){nt&&(nt.el=$t.el,E(_,nt,I)),Xt.asyncDep.then(()=>{xe(()=>{_.isUnmounted||G()},F)});return}}let xt=nt,Lt;$i(_,!1),nt?(nt.el=$t.el,E(_,nt,I)):nt=$t,ct&&ts(ct),(Lt=nt.props&&nt.props.onVnodeBeforeUpdate)&&Fe(Lt,mt,nt,$t),$i(_,!0);const Zt=gr(_),jt=_.subTree;_.subTree=Zt,f(jt,Zt,m(jt.el),pt(jt),_,F,S),nt.el=Zt.el,xt===null&&su(_,Zt.el),rt&&xe(rt,F),(Lt=nt.props&&nt.props.onVnodeUpdated)&&xe(()=>Fe(Lt,mt,nt,$t),F)}else{let nt;const{el:ct,props:rt}=O,{bm:mt,m:$t,parent:xt,root:Lt,type:Zt}=_,jt=Xi(O);$i(_,!1),mt&&ts(mt),!jt&&(nt=rt&&rt.onVnodeBeforeMount)&&Fe(nt,xt,O),$i(_,!0);{Lt.ce&&Lt.ce._hasShadowRoot()&&Lt.ce._injectChildStyle(Zt,_.parent?_.parent.type:void 0);const Xt=_.subTree=gr(_);f(null,Xt,g,N,_,F,S),O.el=Xt.el}if($t&&xe($t,F),!jt&&(nt=rt&&rt.onVnodeMounted)){const Xt=O;xe(()=>Fe(nt,xt,Xt),F)}(O.shapeFlag&256||xt&&Xi(xt.vnode)&&xt.vnode.shapeFlag&256)&&_.a&&xe(_.a,F),_.isMounted=!0,O=g=N=null}};_.scope.on();const Z=_.effect=new ul(R);_.scope.off();const G=_.update=Z.run.bind(Z),K=_.job=Z.runIfDirty.bind(Z);K.i=_,K.id=_.uid,Z.scheduler=()=>Po(K),$i(_,!0),G()},E=(_,O,g)=>{O.component=_;const N=_.vnode.props;_.vnode=O,_.next=null,ru(_,O.props,N,g),du(_,O.children,g),ni(),ar(_),si()},P=(_,O,g,N,F,S,I,R,Z=!1)=>{const G=_&&_.children,K=_?_.shapeFlag:0,nt=O.children,{patchFlag:ct,shapeFlag:rt}=O;if(ct>0){if(ct&128){tt(G,nt,g,N,F,S,I,R,Z);return}else if(ct&256){j(G,nt,g,N,F,S,I,R,Z);return}}rt&8?(K&16&&it(G,F,S),nt!==G&&d(g,nt)):K&16?rt&16?tt(G,nt,g,N,F,S,I,R,Z):it(G,F,S,!0):(K&8&&d(g,""),rt&16&&W(nt,g,N,F,S,I,R,Z))},j=(_,O,g,N,F,S,I,R,Z)=>{_=_||Zi,O=O||Zi;const G=_.length,K=O.length,nt=Math.min(G,K);let ct;for(ct=0;ct<nt;ct++){const rt=O[ct]=Z?Je(O[ct]):We(O[ct]);f(_[ct],rt,g,null,F,S,I,R,Z)}G>K?it(_,F,S,!0,!1,nt):W(O,g,N,F,S,I,R,Z,nt)},tt=(_,O,g,N,F,S,I,R,Z)=>{let G=0;const K=O.length;let nt=_.length-1,ct=K-1;for(;G<=nt&&G<=ct;){const rt=_[G],mt=O[G]=Z?Je(O[G]):We(O[G]);if(fn(rt,mt))f(rt,mt,g,null,F,S,I,R,Z);else break;G++}for(;G<=nt&&G<=ct;){const rt=_[nt],mt=O[ct]=Z?Je(O[ct]):We(O[ct]);if(fn(rt,mt))f(rt,mt,g,null,F,S,I,R,Z);else break;nt--,ct--}if(G>nt){if(G<=ct){const rt=ct+1,mt=rt<K?O[rt].el:N;for(;G<=ct;)f(null,O[G]=Z?Je(O[G]):We(O[G]),g,mt,F,S,I,R,Z),G++}}else if(G>ct)for(;G<=nt;)M(_[G],F,S,!0),G++;else{const rt=G,mt=G,$t=new Map;for(G=mt;G<=ct;G++){const oe=O[G]=Z?Je(O[G]):We(O[G]);oe.key!=null&&$t.set(oe.key,G)}let xt,Lt=0;const Zt=ct-mt+1;let jt=!1,Xt=0;const Nt=new Array(Zt);for(G=0;G<Zt;G++)Nt[G]=0;for(G=rt;G<=nt;G++){const oe=_[G];if(Lt>=Zt){M(oe,F,S,!0);continue}let Yt;if(oe.key!=null)Yt=$t.get(oe.key);else for(xt=mt;xt<=ct;xt++)if(Nt[xt-mt]===0&&fn(oe,O[xt])){Yt=xt;break}Yt===void 0?M(oe,F,S,!0):(Nt[Yt-mt]=G+1,Yt>=Xt?Xt=Yt:jt=!0,f(oe,O[Yt],g,null,F,S,I,R,Z),Lt++)}const Ge=jt?hu(Nt):Zi;for(xt=Ge.length-1,G=Zt-1;G>=0;G--){const oe=mt+G,Yt=O[oe],Si=O[oe+1],Hi=oe+1<K?Si.el||ta(Si):N;Nt[G]===0?f(null,Yt,g,Hi,F,S,I,R,Z):jt&&(xt<0||G!==Ge[xt]?A(Yt,g,Hi,2):xt--)}}},A=(_,O,g,N,F=null)=>{const{el:S,type:I,transition:R,children:Z,shapeFlag:G}=_;if(G&6){A(_.component.subTree,O,g,N);return}if(G&128){_.suspense.move(O,g,N);return}if(G&64){I.move(_,O,g,at);return}if(I===qt){n(S,O,g);for(let nt=0;nt<Z.length;nt++)A(Z[nt],O,g,N);n(_.anchor,O,g);return}if(I===es){$(_,O,g);return}if(N!==2&&G&1&&R)if(N===0)R.persisted&&!S[qs]?n(S,O,g):(R.beforeEnter(S),n(S,O,g),xe(()=>R.enter(S),F));else{const{leave:nt,delayLeave:ct,afterLeave:rt}=R,mt=()=>{_.ctx.isUnmounted?s(S):n(S,O,g)},$t=()=>{const xt=S._isLeaving||!!S[qs];S._isLeaving&&S[qs](!0),R.persisted&&!xt?mt():nt(S,()=>{mt(),rt&&rt()})};ct?ct(S,mt,$t):$t()}else n(S,O,g)},M=(_,O,g,N=!1,F=!1)=>{const{type:S,props:I,ref:R,children:Z,dynamicChildren:G,shapeFlag:K,patchFlag:nt,dirs:ct,cacheIndex:rt,memo:mt}=_;if(nt===-2&&(F=!1),R!=null&&(ni(),kn(R,null,g,_,!0),si()),rt!=null&&(O.renderCache[rt]=void 0),K&256){O.ctx.deactivate(_);return}const $t=K&1&&ct,xt=!Xi(_);let Lt;if(xt&&(Lt=I&&I.onVnodeBeforeUnmount)&&Fe(Lt,O,_),K&6)et(_.component,g,N);else{if(K&128){_.suspense.unmount(g,N);return}$t&&Ci(_,null,O,"beforeUnmount"),K&64?_.type.remove(_,O,g,at,N):G&&!G.hasOnce&&(S!==qt||nt>0&&nt&64)?it(G,O,g,!1,!0):(S===qt&&nt&384||!F&&K&16)&&it(Z,O,g),N&&Y(_)}const Zt=mt!=null&&rt==null;(xt&&(Lt=I&&I.onVnodeUnmounted)||$t||Zt)&&xe(()=>{Lt&&Fe(Lt,O,_),$t&&Ci(_,null,O,"unmounted"),Zt&&(_.el=null)},g)},Y=_=>{const{type:O,el:g,anchor:N,transition:F}=_;if(O===qt){J(g,N);return}if(O===es){B(_);return}const S=()=>{s(g),F&&!F.persisted&&F.afterLeave&&F.afterLeave()};if(_.shapeFlag&1&&F&&!F.persisted){const{leave:I,delayLeave:R}=F,Z=()=>I(g,S);R?R(_.el,S,Z):Z()}else S()},J=(_,O)=>{let g;for(;_!==O;)g=b(_),s(_),_=g;s(O)},et=(_,O,g)=>{const{bum:N,scope:F,job:S,subTree:I,um:R,m:Z,a:G}=_;yr(Z),yr(G),N&&ts(N),F.stop(),S&&(S.flags|=8,M(I,_,O,g)),R&&xe(R,O),xe(()=>{_.isUnmounted=!0},O)},it=(_,O,g,N=!1,F=!1,S=0)=>{for(let I=S;I<_.length;I++)M(_[I],O,g,N,F)},pt=_=>{if(_.shapeFlag&6)return pt(_.component.subTree);if(_.shapeFlag&128)return _.suspense.next();const O=b(_.anchor||_.el),g=O&&O[Ad];return g?b(g):O};let lt=!1;const H=(_,O,g)=>{let N;_==null?O._vnode&&(M(O._vnode,null,null,!0),N=O._vnode.component):f(O._vnode||null,_,O,null,null,null,g),O._vnode=_,lt||(lt=!0,ar(N),Tl(),lt=!1)},at={p:f,um:M,m:A,r:Y,mt:y,mc:W,pc:P,pbc:q,n:pt,o:t};return{render:H,hydrate:void 0,createApp:Jd(H)}}function Gs({type:t,props:e},i){return i==="svg"&&t==="foreignObject"||i==="mathml"&&t==="annotation-xml"&&e&&e.encoding&&e.encoding.includes("html")?void 0:i}function $i({effect:t,job:e},i){i?(t.flags|=32,e.flags|=4):(t.flags&=-33,e.flags&=-5)}function pu(t,e){return(!t||t&&!t.pendingBranch)&&e&&!e.persisted}function Xl(t,e,i=!1){const n=t.children,s=e.children;if(Tt(n)&&Tt(s))for(let o=0;o<n.length;o++){const l=n[o];let r=s[o];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=s[o]=Je(s[o]),r.el=l.el),!i&&r.patchFlag!==-2&&Xl(l,r)),r.type===Rs&&(r.patchFlag===-1&&(r=s[o]=Je(r)),r.el=l.el),r.type===ri&&!r.el&&(r.el=l.el)}}function hu(t){const e=t.slice(),i=[0];let n,s,o,l,r;const a=t.length;for(n=0;n<a;n++){const c=t[n];if(c!==0){if(s=i[i.length-1],t[s]<c){e[n]=s,i.push(n);continue}for(o=0,l=i.length-1;o<l;)r=o+l>>1,t[i[r]]<c?o=r+1:l=r;c<t[i[o]]&&(o>0&&(e[n]=i[o-1]),i[o]=n)}}for(o=i.length,l=i[o-1];o-- >0;)i[o]=l,l=e[l];return i}function Ql(t){const e=t.subTree.component;if(e)return e.asyncDep&&!e.asyncResolved?e:Ql(e)}function yr(t){if(t)for(let e=0;e<t.length;e++)t[e].flags|=8}function ta(t){if(t.placeholder)return t.placeholder;const e=t.component;return e?ta(e.subTree):null}const ea=t=>t.__isSuspense;function mu(t,e){e&&e.pendingBranch?Tt(t)?e.effects.push(...t):e.effects.push(t):Sd(t)}const qt=Symbol.for("v-fgt"),Rs=Symbol.for("v-txt"),ri=Symbol.for("v-cmt"),es=Symbol.for("v-stc"),ei=[];let Ie=null;function st(t=!1){ei.push(Ie=t?null:[])}function jo(){ei.pop(),Ie=ei[ei.length-1]||null}let Ln=1;function kr(t,e=!1){Ln+=t,t<0&&Ie&&e&&(Ie.hasOnce=!0)}function ia(t){return t.dynamicChildren=Ln>0?Ie||Zi:null,jo(),Ln>0&&Ie&&Ie.push(t),t}function ot(t,e,i,n,s,o){return ia(p(t,e,i,n,s,o,!0))}function De(t,e,i,n,s){return ia(dt(t,e,i,n,s,!0))}function Wo(t){return t?t.__v_isVNode===!0:!1}function fn(t,e){return t.type===e.type&&t.key===e.key}const na=({key:t})=>t??null,is=({ref:t,ref_key:e,ref_for:i})=>(typeof t=="number"&&(t=""+t),t!=null?ie(t)||Qt(t)||Bt(t)?{i:de,r:t,k:e,f:!!i}:t:null);function p(t,e=null,i=null,n=0,s=null,o=t===qt?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:t,props:e,key:e&&na(e),ref:e&&is(e),scopeId:El,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:o,patchFlag:n,dynamicProps:s,dynamicChildren:null,appContext:null,ctx:de};return r?(ys(a,i),o&128&&t.normalize(a)):i&&(a.shapeFlag|=ie(i)?8:16),Ln>0&&!l&&Ie&&(a.patchFlag>0||o&6)&&a.patchFlag!==32&&Ie.push(a),a}const dt=gu;function gu(t,e=null,i=null,n=0,s=null,o=!1){if((!t||t===jd)&&(t=ri),Wo(t)){const r=nn(t,e,!0);return i&&ys(r,i),Ln>0&&!o&&Ie&&(r.shapeFlag&6?Ie[Ie.indexOf(t)]=r:Ie.push(r)),r.patchFlag=-2,r}if(Au(t)&&(t=t.__vccOpts),e){e=vu(e);let{class:r,style:a}=e;r&&!ie(r)&&(e.class=It(r)),Ht(a)&&(Ro(a)&&!Tt(a)&&(a=ue({},a)),e.style=Bn(a))}const l=ie(t)?1:ea(t)?128:Td(t)?64:Ht(t)?4:Bt(t)?2:0;return p(t,e,i,n,s,l,o,!0)}function vu(t){return t?Ro(t)||ql(t)?ue({},t):t:null}function nn(t,e,i=!1,n=!1){const{props:s,ref:o,patchFlag:l,children:r,transition:a}=t,c=e?bu(s||{},e):s,d={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&na(c),ref:e&&e.ref?i&&o?Tt(o)?o.concat(is(e)):[o,is(e)]:is(e):o,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:r,target:t.target,targetStart:t.targetStart,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:e&&t.type!==qt?l===-1?16:l|16:l,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:a,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&nn(t.ssContent),ssFallback:t.ssFallback&&nn(t.ssFallback),placeholder:t.placeholder,el:t.el,anchor:t.anchor,ctx:t.ctx,ce:t.ce};return a&&n&&Oo(d,a.clone(d)),d}function $e(t=" ",e=0){return dt(Rs,null,t,e)}function ve(t,e){const i=dt(es,null,t);return i.staticCount=e,i}function Pt(t="",e=!1){return e?(st(),De(ri,null,t)):dt(ri,null,t)}function We(t){return t==null||typeof t=="boolean"?dt(ri):Tt(t)?dt(qt,null,t.slice()):Wo(t)?Je(t):dt(Rs,null,String(t))}function Je(t){return t.el===null&&t.patchFlag!==-1||t.memo?t:nn(t)}function ys(t,e){let i=0;const{shapeFlag:n}=t;if(e==null)e=null;else if(Tt(e))i=16;else if(typeof e=="object")if(n&65){const s=e.default;s&&(s._c&&(s._d=!1),ys(t,s()),s._c&&(s._d=!0));return}else{i=32;const s=e._;!s&&!ql(e)?e._ctx=de:s===3&&de&&(de.slots._===1?e._=1:(e._=2,t.patchFlag|=1024))}else if(Bt(e)){if(n&65){ys(t,{default:e});return}e={default:e,_ctx:de},i=32}else e=String(e),n&64?(i=16,e=[$e(e)]):i=8;t.children=e,t.shapeFlag|=i}function bu(...t){const e={};for(let i=0;i<t.length;i++){const n=t[i];for(const s in n)if(s==="class")e.class!==n.class&&(e.class=It([e.class,n.class]));else if(s==="style")e.style=Bn([e.style,n.style]);else if(_s(s)){const o=e[s],l=n[s];l&&o!==l&&!(Tt(o)&&o.includes(l))?e[s]=o?[].concat(o,l):l:l==null&&o==null&&!Cs(s)&&(e[s]=l)}else s!==""&&(e[s]=n[s])}return e}function Fe(t,e,i,n=null){ze(t,e,7,[i,n])}const yu=Hl();let ku=0;function wu(t,e,i){const n=t.type,s=(e?e.appContext:t.appContext)||yu,o={uid:ku++,vnode:t,type:n,parent:e,appContext:s,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Kc(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:e?e.provides:Object.create(s.provides),ids:e?e.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Gl(n,s),emitsOptions:jl(n,s),emit:null,emitted:null,propsDefaults:Vt,inheritAttrs:n.inheritAttrs,ctx:Vt,data:Vt,props:Vt,attrs:Vt,slots:Vt,refs:Vt,setupState:Vt,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return o.ctx={_:o},o.root=e?e.root:o,o.emit=Qd.bind(null,o),t.ce&&t.ce(o),o}let me=null;const xu=()=>me||de;let ks,vo;{const t=Ts(),e=(i,n)=>{let s;return(s=t[i])||(s=t[i]=[]),s.push(n),o=>{s.length>1?s.forEach(l=>l(o)):s[0](o)}};ks=e("__VUE_INSTANCE_SETTERS__",i=>me=i),vo=e("__VUE_SSR_SETTERS__",i=>Rn=i)}const Hn=t=>{const e=me;return ks(t),t.scope.on(),()=>{t.scope.off(),ks(e)}},wr=()=>{me&&me.scope.off(),ks(null)};function sa(t){return t.vnode.shapeFlag&4}let Rn=!1;function Su(t,e=!1,i=!1){e&&vo(e);const{props:n,children:s}=t.vnode,o=sa(t);ou(t,n,o,e),cu(t,s,i||e);const l=o?_u(t,e):void 0;return e&&vo(!1),l}function _u(t,e){const i=t.type;t.accessCache=Object.create(null),t.proxy=new Proxy(t.ctx,Ud);const{setup:n}=i;if(n){ni();const s=t.setupContext=n.length>1?$u(t):null,o=Hn(t),l=Nn(n,t,0,[t.props,s]),r=sl(l);if(si(),o(),(r||t.sp)&&!Xi(t)&&Rl(t),r){if(l.then(wr,wr),e)return l.then(a=>{xr(t,a)}).catch(a=>{Ms(a,t,0)});t.asyncDep=l}else xr(t,l)}else oa(t)}function xr(t,e,i){Bt(e)?t.type.__ssrInlineRender?t.ssrRender=e:t.render=e:Ht(e)&&(t.setupState=Cl(e)),oa(t)}function oa(t,e,i){const n=t.type;t.render||(t.render=n.render||qe);{const s=Hn(t);ni();try{Vd(t)}finally{si(),s()}}}const Cu={get(t,e){return he(t,"get",""),t[e]}};function $u(t){const e=i=>{t.exposed=i||{}};return{attrs:new Proxy(t.attrs,Cu),slots:t.slots,emit:t.emit,expose:e}}function Ps(t){return t.exposed?t.exposeProxy||(t.exposeProxy=new Proxy(Cl(pd(t.exposed)),{get(e,i){if(i in e)return e[i];if(i in wn)return wn[i](t)},has(e,i){return i in e||i in wn}})):t.proxy}function Iu(t,e=!0){return Bt(t)?t.displayName||t.name:t.name||e&&t.__name}function Au(t){return Bt(t)&&"__vccOpts"in t}const _t=(t,e)=>bd(t,e,Rn),Tu="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let bo;const Sr=typeof window<"u"&&window.trustedTypes;if(Sr)try{bo=Sr.createPolicy("vue",{createHTML:t=>t})}catch{}const ra=bo?t=>bo.createHTML(t):t=>t,Bu="http://www.w3.org/2000/svg",Eu="http://www.w3.org/1998/Math/MathML",Ye=typeof document<"u"?document:null,_r=Ye&&Ye.createElement("template"),Mu={insert:(t,e,i)=>{e.insertBefore(t,i||null)},remove:t=>{const e=t.parentNode;e&&e.removeChild(t)},createElement:(t,e,i,n)=>{const s=e==="svg"?Ye.createElementNS(Bu,t):e==="mathml"?Ye.createElementNS(Eu,t):i?Ye.createElement(t,{is:i}):Ye.createElement(t);return t==="select"&&n&&n.multiple!=null&&s.setAttribute("multiple",n.multiple),s},createText:t=>Ye.createTextNode(t),createComment:t=>Ye.createComment(t),setText:(t,e)=>{t.nodeValue=e},setElementText:(t,e)=>{t.textContent=e},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>Ye.querySelector(t),setScopeId(t,e){t.setAttribute(e,"")},insertStaticContent(t,e,i,n,s,o){const l=i?i.previousSibling:e.lastChild;if(s&&(s===o||s.nextSibling))for(;e.insertBefore(s.cloneNode(!0),i),!(s===o||!(s=s.nextSibling)););else{_r.innerHTML=ra(n==="svg"?`<svg>${t}</svg>`:n==="mathml"?`<math>${t}</math>`:t);const r=_r.content;if(n==="svg"||n==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}e.insertBefore(r,i)}return[l?l.nextSibling:e.firstChild,i?i.previousSibling:e.lastChild]}},Du=Symbol("_vtc");function Lu(t,e,i){const n=t[Du];n&&(e=(e?[e,...n]:[...n]).join(" ")),e==null?t.removeAttribute("class"):i?t.setAttribute("class",e):t.className=e}const ws=Symbol("_vod"),la=Symbol("_vsh"),aa={name:"show",beforeMount(t,{value:e},{transition:i}){t[ws]=t.style.display==="none"?"":t.style.display,i&&e?i.beforeEnter(t):pn(t,e)},mounted(t,{value:e},{transition:i}){i&&e&&i.enter(t)},updated(t,{value:e,oldValue:i},{transition:n}){!e!=!i&&(n?e?(n.beforeEnter(t),pn(t,!0),n.enter(t)):n.leave(t,()=>{pn(t,!1)}):pn(t,e))},beforeUnmount(t,{value:e}){pn(t,e)}};function pn(t,e){t.style.display=e?t[ws]:"none",t[la]=!e}const Ru=Symbol(""),Pu=/(?:^|;)\s*display\s*:/;function Ou(t,e,i){const n=t.style,s=ie(i);let o=!1;if(i&&!s){if(e)if(ie(e))for(const l of e.split(";")){const r=l.slice(0,l.indexOf(":")).trim();i[r]==null&&mn(n,r,"")}else for(const l in e)i[l]==null&&mn(n,l,"");for(const l in i){l==="display"&&(o=!0);const r=i[l];r!=null?Nu(t,l,!ie(e)&&e?e[l]:void 0,r)||mn(n,l,r):mn(n,l,"")}}else if(s){if(e!==i){const l=n[Ru];l&&(i+=";"+l),n.cssText=i,o=Pu.test(i)}}else e&&t.removeAttribute("style");ws in t&&(t[ws]=o?n.display:"",t[la]&&(n.display="none"))}const Cr=/\s*!important$/;function mn(t,e,i){if(Tt(i))i.forEach(n=>mn(t,e,n));else if(i==null&&(i=""),e.startsWith("--"))t.setProperty(e,i);else{const n=zu(t,e);Cr.test(i)?t.setProperty(xi(n),i.replace(Cr,""),"important"):t[n]=i}}const $r=["Webkit","Moz","ms"],Zs={};function zu(t,e){const i=Zs[e];if(i)return i;let n=we(e);if(n!=="filter"&&n in t)return Zs[e]=n;n=Is(n);for(let s=0;s<$r.length;s++){const o=$r[s]+n;if(o in t)return Zs[e]=o}return e}function Nu(t,e,i,n){return t.tagName==="TEXTAREA"&&(e==="width"||e==="height")&&ie(n)&&i===n}const Ir="http://www.w3.org/1999/xlink";function Ar(t,e,i,n,s,o=Vc(e)){n&&e.startsWith("xlink:")?i==null?t.removeAttributeNS(Ir,e.slice(6,e.length)):t.setAttributeNS(Ir,e,i):i==null||o&&!al(i)?t.removeAttribute(e):t.setAttribute(e,o?"":Pe(i)?String(i):i)}function Tr(t,e,i,n,s){if(e==="innerHTML"||e==="textContent"){i!=null&&(t[e]=e==="innerHTML"?ra(i):i);return}const o=t.tagName;if(e==="value"&&o!=="PROGRESS"&&!o.includes("-")){const r=o==="OPTION"?t.getAttribute("value")||"":t.value,a=i==null?t.type==="checkbox"?"on":"":String(i);(r!==a||!("_value"in t))&&(t.value=a),i==null&&t.removeAttribute(e),t._value=i;return}let l=!1;if(i===""||i==null){const r=typeof t[e];r==="boolean"?i=al(i):i==null&&r==="string"?(i="",l=!0):r==="number"&&(i=0,l=!0)}try{t[e]=i}catch{}l&&t.removeAttribute(s||e)}function pi(t,e,i,n){t.addEventListener(e,i,n)}function Fu(t,e,i,n){t.removeEventListener(e,i,n)}const Br=Symbol("_vei");function Hu(t,e,i,n,s=null){const o=t[Br]||(t[Br]={}),l=o[e];if(n&&l)l.value=n;else{const[r,a]=Uu(e);if(n){const c=o[e]=Ku(n,s);pi(t,r,c,a)}else l&&(Fu(t,r,l,a),o[e]=void 0)}}const ju=/(Once|Passive|Capture)$/,Wu=/^on:?(?:Once|Passive|Capture)$/;function Uu(t){let e,i;for(;(i=t.match(ju))&&!Wu.test(t);)e||(e={}),t=t.slice(0,t.length-i[1].length),e[i[1].toLowerCase()]=!0;return[t[2]===":"?t.slice(3):xi(t.slice(2)),e]}let Ys=0;const Vu=Promise.resolve(),qu=()=>Ys||(Vu.then(()=>Ys=0),Ys=Date.now());function Ku(t,e){const i=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=i.attached)return;const s=i.value;if(Tt(s)){const o=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{o.call(n),n._stopped=!0};const l=s.slice(),r=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&ze(c,e,5,r)}}else ze(s,e,5,[n])};return i.value=t,i.attached=qu(),i}const Er=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&t.charCodeAt(2)>96&&t.charCodeAt(2)<123,Gu=(t,e,i,n,s,o)=>{const l=s==="svg";e==="class"?Lu(t,n,l):e==="style"?Ou(t,i,n):_s(e)?Cs(e)||Hu(t,e,i,n,o):(e[0]==="."?(e=e.slice(1),!0):e[0]==="^"?(e=e.slice(1),!1):Zu(t,e,n,l))?(Tr(t,e,n),!t.tagName.includes("-")&&(e==="value"||e==="checked"||e==="selected")&&Ar(t,e,n,l,o,e!=="value")):t._isVueCE&&(Yu(t,e)||t._def.__asyncLoader&&(/[A-Z]/.test(e)||!ie(n)))?Tr(t,we(e),n,o,e):(e==="true-value"?t._trueValue=n:e==="false-value"&&(t._falseValue=n),Ar(t,e,n,l))};function Zu(t,e,i,n){if(n)return!!(e==="innerHTML"||e==="textContent"||e in t&&Er(e)&&Bt(i));if(e==="spellcheck"||e==="draggable"||e==="translate"||e==="autocorrect"||e==="sandbox"&&t.tagName==="IFRAME"||e==="form"||e==="list"&&t.tagName==="INPUT"||e==="type"&&t.tagName==="TEXTAREA")return!1;if(e==="width"||e==="height"){const s=t.tagName;if(s==="IMG"||s==="VIDEO"||s==="CANVAS"||s==="SOURCE")return!1}return Er(e)&&ie(i)?!1:e in t}function Yu(t,e){const i=t._def.props;if(!i)return!1;const n=we(e);return Array.isArray(i)?i.some(s=>we(s)===n):Object.keys(i).some(s=>we(s)===n)}const sn=t=>{const e=t.props["onUpdate:modelValue"]||!1;return Tt(e)?i=>ts(e,i):e};function Ju(t){t.target.composing=!0}function Mr(t){const e=t.target;e.composing&&(e.composing=!1,e.dispatchEvent(new Event("input")))}const ii=Symbol("_assign");function Dr(t,e,i){return e&&(t=t.trim()),i&&(t=As(t)),t}const xs={created(t,{modifiers:{lazy:e,trim:i,number:n}},s){t[ii]=sn(s);const o=n||s.props&&s.props.type==="number";pi(t,e?"change":"input",l=>{l.target.composing||t[ii](Dr(t.value,i,o))}),(i||o)&&pi(t,"change",()=>{t.value=Dr(t.value,i,o)}),e||(pi(t,"compositionstart",Ju),pi(t,"compositionend",Mr),pi(t,"change",Mr))},mounted(t,{value:e}){t.value=e??""},beforeUpdate(t,{value:e,oldValue:i,modifiers:{lazy:n,trim:s,number:o}},l){if(t[ii]=sn(l),t.composing)return;const r=(o||t.type==="number")&&!/^0\d/.test(t.value)?As(t.value):t.value,a=e??"";if(r===a)return;const c=t.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===t&&t.type!=="range"&&(n&&e===i||s&&t.value.trim()===a)||(t.value=a)}},Yn={deep:!0,created(t,e,i){t[ii]=sn(i),pi(t,"change",()=>{const n=t._modelValue,s=Pn(t),o=t.checked,l=t[ii];if(Tt(n)){const r=Ao(n,s),a=r!==-1;if(o&&!a)l(n.concat(s));else if(!o&&a){const c=[...n];c.splice(r,1),l(c)}}else if(rn(n)){const r=new Set(n);o?r.add(s):r.delete(s),l(r)}else l(ca(t,o))})},mounted:Lr,beforeUpdate(t,e,i){t[ii]=sn(i),Lr(t,e,i)}};function Lr(t,{value:e,oldValue:i},n){t._modelValue=e;let s;if(Tt(e))s=Ao(e,n.props.value)>-1;else if(rn(e))s=e.has(n.props.value);else{if(e===i)return;s=ln(e,ca(t,!0))}t.checked!==s&&(t.checked=s)}const Xu={deep:!0,created(t,{value:e,modifiers:{number:i}},n){t._modelValue=e,pi(t,"change",()=>{const s=Array.prototype.filter.call(t.options,o=>o.selected).map(o=>i?As(Pn(o)):Pn(o));t[ii](t.multiple?rn(t._modelValue)?new Set(s):s:s[0]),t._assigning=!0,Il(()=>{t._assigning=!1})}),t[ii]=sn(n)},mounted(t,{value:e}){Rr(t,e)},beforeUpdate(t,{value:e},i){t._modelValue=e,t[ii]=sn(i)},updated(t,{value:e}){t._assigning||Rr(t,e)}};function Rr(t,e){const i=t.multiple,n=Tt(e);if(!(i&&!n&&!rn(e))){for(let s=0,o=t.options.length;s<o;s++){const l=t.options[s],r=Pn(l);if(i)if(n){const a=typeof r;a==="string"||a==="number"?l.selected=e.some(c=>String(c)===String(r)):l.selected=Ao(e,r)>-1}else l.selected=e.has(r);else if(ln(Pn(l),e)){t.selectedIndex!==s&&(t.selectedIndex=s);return}}!i&&t.selectedIndex!==-1&&(t.selectedIndex=-1)}}function Pn(t){return"_value"in t?t._value:t.value}function ca(t,e){const i=e?"_trueValue":"_falseValue";return i in t?t[i]:e}const Qu=["ctrl","shift","alt","meta"],tf={stop:t=>t.stopPropagation(),prevent:t=>t.preventDefault(),self:t=>t.target!==t.currentTarget,ctrl:t=>!t.ctrlKey,shift:t=>!t.shiftKey,alt:t=>!t.altKey,meta:t=>!t.metaKey,left:t=>"button"in t&&t.button!==0,middle:t=>"button"in t&&t.button!==1,right:t=>"button"in t&&t.button!==2,exact:(t,e)=>Qu.some(i=>t[`${i}Key`]&&!e.includes(i))},Me=(t,e)=>{if(!t)return t;const i=t._withMods||(t._withMods={}),n=e.join(".");return i[n]||(i[n]=((s,...o)=>{for(let l=0;l<e.length;l++){const r=tf[e[l]];if(r&&r(s,e))return}return t(s,...o)}))},ef={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},nf=(t,e)=>{const i=t._withKeys||(t._withKeys={}),n=e.join(".");return i[n]||(i[n]=(s=>{if(!("key"in s))return;const o=xi(s.key);if(e.some(l=>l===o||ef[l]===o))return t(s)}))},sf=ue({patchProp:Gu},Mu);let Pr;function of(){return Pr||(Pr=uu(sf))}const da=((...t)=>{const e=of().createApp(...t),{mount:i}=e;return e.mount=n=>{const s=lf(n);if(!s)return;const o=e._component;!Bt(o)&&!o.render&&!o.template&&(o.template=s.innerHTML),s.nodeType===1&&(s.textContent="");const l=i(s,!1,rf(s));return s instanceof Element&&(s.removeAttribute("v-cloak"),s.setAttribute("data-v-app","")),l},e});function rf(t){if(t instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&t instanceof MathMLElement)return"mathml"}function lf(t){return ie(t)?document.querySelector(t):t}const af="slidev-config.json",on={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1},hi=Es({...on});function cf(t){if(!t||typeof t!="object")return{...on};const e=t;return{enableWebServeJump:!!e.enableWebServeJump,webServeUrl:typeof e.webServeUrl=="string"&&e.webServeUrl.trim()?e.webServeUrl.trim():on.webServeUrl,normalizeHeadingSizes:!!e.normalizeHeadingSizes}}function Li(t){if(!t||typeof t!="object")return{...hi};const e=t;return e.enableWebServeJump!==void 0&&(hi.enableWebServeJump=!!e.enableWebServeJump),e.webServeUrl!==void 0&&(hi.webServeUrl=String(e.webServeUrl)),e.normalizeHeadingSizes!==void 0&&(hi.normalizeHeadingSizes=!!e.normalizeHeadingSizes),{...hi}}function Os(){return{...hi}}function ua(t,e,i){const n=(t||on.webServeUrl).trim(),s=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,o=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(s);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",e),i!=null&&i.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",o),l.toString()}catch{const l=i!=null&&i.focus?"&focus=1":"";return`${s.replace(/\/+$/,"")}/stage/build/desktop/?id=${e}${l}&r=${o}`}}const Ii={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1};function df(t){var i,n,s,o,l,r;const e=Os();return t?{theme:((i=t[Cn])==null?void 0:i.trim())||Ii.theme,aspectRatio:((n=t[$n])==null?void 0:n.trim())||Ii.aspectRatio,highlighter:((s=t[Xr])==null?void 0:s.trim())||Ii.highlighter,defaultTransition:((o=t[In])==null?void 0:o.trim())||Ii.defaultTransition,colorSchema:((l=t[Qr])==null?void 0:l.trim())||Ii.colorSchema,spacing:((r=t[ro])==null?void 0:r.trim())||Ii.spacing,normalizeHeadingSizes:e.normalizeHeadingSizes}:{...Ii,normalizeHeadingSizes:e.normalizeHeadingSizes}}function Ss(t){var i,n,s,o,l;const e=(i=t.ial)==null?void 0:i[Mi];return!!(e&&(e==="true"||e==="page"||e==="cover"||e==="end")||t.type==="tb"||t.type==="thematic-break"||t.type==="NodeThematicBreak"||((n=t.markdown)==null?void 0:n.trim())==="---"||((s=t.markdown)==null?void 0:s.trim())==="***"||t.type==="b"&&(((o=t.markdown)==null?void 0:o.trim())==="---"||((l=t.content)==null?void 0:l.trim())==="---"))}function Or(t){const e={};let i="";if(!t)return{frontmatter:e,notes:i};t[gt]&&(e.layout=t[gt].trim()),t[ee]&&(e.transition=t[ee].trim()),t[Ut]&&(e.background=t[Ut].trim()),t[Ee]&&(e.image=t[Ee].trim()),t[Gi]&&(e.class=t[Gi].trim()),t[gn]&&(e.spacing=t[gn].trim()),t[le]&&(e.layoutRatio=t[le].trim()),t[vi]&&(e.mask=t[vi].trim()),t[bi]&&(e.maskRatio=t[bi].trim()),t[yi]&&(e.maskStyle=t[yi].trim()),t[ki]&&(e.maskInitial=t[ki].trim()),t[Ki]&&(i=t[Ki].trim());for(const[n,s]of Object.entries(t))if(n.startsWith("custom-slidev-")&&![gt,le,vi,bi,yi,ki,ee,Ut,Ee,Gi,gn,Ki,Mi].includes(n)){const o=n.replace(/^custom-slidev-/,"");try{e[o]=JSON.parse(s)}catch{e[o]=s}}return{frontmatter:e,notes:i}}function uf(t){const e={};if(!t)return e;const i=t[ne]??t["slidev-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(e.isNote=!0);const n=t[Gt]??t["slidev-role"],s=t[Ut]??t["slidev-background"];(n===tl||s==="true"||s==="1")&&(e.isBackground=!0);const o=t[gt]??t["slidev-layout"];o===fs||o===ps?e.imageLayout=o:(n===fs||n===ps)&&(e.imageLayout=n);const l=t[Wt]??t["custom-slidev-clicks"]??t["slidev-click"]??t["slidev-clicks"];if(l!=null&&(e.clicks=l.trim()),t[Ve])try{const r=JSON.parse(t[Ve]);typeof r=="object"&&r!==null?e.motion={preset:r.preset||r.type||"fade-in",...r}:e.motion={preset:String(r).trim()}}catch{e.motion={preset:t[Ve].trim()}}return t[Ni]&&(e.shikiLines=t[Ni].trim()),t[An]&&(e.maxHeight=t[An].trim()),t[At]&&(e.slot=t[At].trim()),t.style&&t.style.trim()&&(e.style=t.style.trim()),e}function wi(t,e){const i=(t||e||"").trim();if(!i)return null;const n=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const s=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(s)return s[1].trim();const o=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(o)?o:null}function xn(t){if(!t)return"";const e=t.split(/\r?\n/);if(e.length===0)return"";const i=e[0],n=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return t;const s=n[1].length,o=n[2].trim(),l=i.length-n[2].length;if(e.length===1)return o;const r=[o];for(let a=1;a<e.length;a++){const c=e[a];if(!c.trim()){r.push("");continue}const d=c.match(/^(\s*)/),m=d?d[1].length:0;m>=l?r.push(c.slice(l)):m>s?r.push(c.slice(m)):r.push(c)}return r.join(`
`)}function Fi(t){if(!t)return!1;const e=(t.type||"").toLowerCase();if(e==="i"||e==="nodelistitem"||e==="l"||e==="nodelist")return!0;const i=(t.markdown||t.rawMarkdown||t.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function Js(t,e=2){if(!t||typeof t!="string")return`repeat(${e}, 1fr)`;const i=t.trim();if(!i)return`repeat(${e}, 1fr)`;if(i.includes(":")){const s=i.split(":").map(o=>parseFloat(o.trim())).filter(o=>!isNaN(o)&&o>0);if(s.length>=2)return s.map(o=>`${o}fr`).join(" ")}const n=i.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${e}, 1fr)`}function Sn(t){if(!t)return[];if(se(t)&&Ke(t)&&!ai(t)){const n=an(t),s=[];for(const o of n)s.push(...Sn(o));return s}const e=(t.type||"").toLowerCase();if(e==="l"||e==="nodelist"||e==="list"){if(t.children&&t.children.length>0){const l=t.children.filter(Fi);if(l.length>0)return l}const s=(t.markdown||t.content||"").trim().split(/\r?\n/),o=[];for(let l=0;l<s.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(s[l])&&o.push(l);if(o.length>=2){const l=[];for(let r=0;r<o.length;r++){const a=o[r],c=r+1<o.length?o[r+1]:s.length,d=s.slice(a,c).join(`
`);l.push({id:`${t.id}-item-${r+1}`,type:"i",markdown:d,content:d,ial:{...t.ial||{}}})}return l}}return Fi(t)?[t]:[]}function Uo(t){var s;if(!t||!se(t)||!Ke(t)||ai(t))return null;const e=an(t);if(e.length===0)return null;if(e.length===1&&se(e[0])&&Ke(e[0])){const o=Uo(e[0]);return o?{items:o.items,nestedSuperBlocks:[e[0],...o.nestedSuperBlocks]}:null}const i=[];for(const o of e)if(se(o)){i.push(o);const l=((s=o.children)==null?void 0:s.filter(se))||[];i.push(...l)}const n=e.map(Sn);if(n.length>=2&&n.every(o=>o.length>0)){const o=n.flat();if(o.length>=2&&o.length<=6)return{items:o,nestedSuperBlocks:i}}if(e.length===2){const o=Sn(e[0]),l=Sn(e[1]);if(o.length+l.length>=2&&o.length+l.length<=6&&(o.length>0||l.length>0))return{items:[...o,...l],nestedSuperBlocks:i}}return null}function ff(t){if(!t||!se(t)||!Ke(t)||ai(t))return null;const e=Uo(t);if(!e)return null;const{items:i,nestedSuperBlocks:n}=e;if(i.length<2||i.length>6)return null;const s=Vo(t)||void 0,o=i.length;return{superBlockNode:t,nestedSuperBlocks:n,count:o,layout:"cols-header",items:i,slots:i.map((l,r)=>`col-${r+1}`),ratio:s}}function fa(t){if(!t||!se(t)||!Ke(t)||ai(t))return null;const e=an(t);if(e.length===0)return null;const i=[];for(const n of e){const s=Sn(n);if(s.length===0)return null;i.push(...s)}return i}function pf(t){if(!t||!se(t)||!Ke(t)||ai(t))return null;const e=fa(t);return!e||e.length===0||e.length>=2&&e.length<=6?null:{superBlockNode:t,items:e}}function hf(t){if(!t||!se(t)||!Ke(t)||ai(t))return null;const e=Uo(t);if(e&&e.items.length===4)return e.items;const i=fa(t);if(i&&i.length===4)return i;const n=an(t);return n.length===4?n:null}function mf(t,e){if(!t||t.length===0)return null;const i=[];function n(r,a){if(se(r)){const c=hf(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,a)}for(let r=0;r<t.length;r++)n(t[r],r);if(i.length===0)return null;let s=null;e&&(s=i.find(r=>{if(r.sbNode.id===e||r.items.some(c=>c.id===e))return!0;const a=c=>c.id===e?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),s||(s=i[0]);const l=t.slice(0,s.topLevelIndex).slice().reverse().find(r=>pa(r));return{superBlockNode:s.sbNode,items:s.items,headerNode:l}}function gf(t,e,i){var d,m,b,u,h;const n=[],s=[],o=(i==null?void 0:i.tracked)||[],l=[];let r={pageTargetId:t,blocks:[]};l.push(r);for(let f=0;f<e.length;f++){const v=e[f];if(Ss(v)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=v.id,r.blocks.push(v);continue}r={pageTargetId:v.id,blocks:[v]},l.push(r)}else r.blocks.push(v)}function a(f){const v=[];for(const k of f)se(k)&&v.push(k),k.children&&k.children.length>0&&v.push(...a(k.children));return v}function c(f,v,k){const x={blockId:f,attrs:v,previousAttrs:k};n.push(x),i!=null&&i.onTagChange&&i.onTagChange(x)}for(const f of l){const v=f.pageTargetId,k=e.find(T=>T.id===v),x=o.find(T=>T.pageTargetId===v);if(f.blocks.some(T=>{var w,W;return!!(ai(T)||yo(T)&&(((w=T.ial)==null?void 0:w[gt])==="image-left"||((W=T.ial)==null?void 0:W[gt])==="image-right"))})){if(x){const T=x.headerId;if(T){c(T,{[At]:""});const w=e.find(W=>W.id===T);w!=null&&w.ial&&(w.ial[At]="")}for(const w of x.itemIds){c(w,{[At]:""});const W=e.find(V=>V.id===w);W!=null&&W.ial&&(W.ial[At]="")}}continue}let B=null,L=-1;for(let T=0;T<f.blocks.length;T++){const w=f.blocks[T],W=se(w)?[w,...a(w.children||[])]:w.children?a(w.children):[];for(const V of W){const q=ff(V);if(q){B=q,L=T;break}}if(B)break}if(B){const{superBlockNode:T,layout:w,items:W,slots:V}=B,X=f.blocks.slice(0,L).find(E=>pa(E)),C=X==null?void 0:X.id,z=((d=k==null?void 0:k.ial)==null?void 0:d[gt])||"",y=z==="clover",D=y?"clover":w;if(z!==D&&(c(v,{[gt]:D},{[gt]:z}),k&&(k.ial||(k.ial={}),k.ial[gt]=D)),X){const E=((m=X.ial)==null?void 0:m[At])||"";E!=="header"&&(c(X.id,{[At]:"header"},{[At]:E}),X.ial||(X.ial={}),X.ial[At]="header")}if(x!=null&&x.headerId&&x.headerId!==C){c(x.headerId,{[At]:""});const E=e.find(P=>P.id===x.headerId);E&&(E.ial||(E.ial={}),E.ial[At]="")}const U=[];for(let E=0;E<W.length;E++){const P=W[E],j=V[E];U.push(P.id);const tt=((b=P.ial)==null?void 0:b[At])||"";if(tt!==j&&(c(P.id,{[At]:j},{[At]:tt}),P.ial||(P.ial={}),P.ial[At]=j),P.children&&P.children.length>0)for(const A of P.children)A.ial||(A.ial={}),A.ial[At]!==j&&(A.ial[At]=j)}if(x!=null&&x.itemIds){for(const E of x.itemIds)if(!U.includes(E)){c(E,{[At]:""});const P=e.find(j=>j.id===E);P&&(P.ial||(P.ial={}),P.ial[At]="")}}s.push({superBlockId:T.id,nestedSuperBlockIds:(u=B.nestedSuperBlocks)==null?void 0:u.map(E=>E.id),pageTargetId:v,headerId:C,itemIds:U,layout:y?"clover":w})}else{let T=!1;const w=[];for(const q of f.blocks){const X=se(q)?[q,...a(q.children||[])]:q.children?a(q.children):[];for(const C of X){const z=pf(C);if(z){T=!0;for(const y of z.items)w.push(y.id)}}}const W=((h=k==null?void 0:k.ial)==null?void 0:h[gt])||"",V=Tn(W);if(x||T&&V){c(v,{[gt]:""},{[gt]:W}),k&&(k.ial||(k.ial={}),k.ial[gt]="");const q=x==null?void 0:x.headerId;if(q){c(q,{[At]:""});const C=e.find(z=>z.id===q);C&&(C.ial||(C.ial={}),C.ial[At]="")}const X=new Set([...(x==null?void 0:x.itemIds)||[],...w]);for(const C of X){c(C,{[At]:""});const z=e.find(y=>y.id===C);z&&(z.ial||(z.ial={}),z.ial[At]="")}}}}return{changes:n,newTracked:s}}function se(t){if(!t)return!1;const e=(t.type||"").toLowerCase();return e==="s"||e==="sb"||e==="nodesuperblock"}function Ke(t){if(!se(t))return!1;const e=(t.subType||"").toLowerCase();if(e==="col"||e==="h"||e==="horizontal")return!0;if(e==="row"||e==="v"||e==="vertical")return!1;if(t.ial){const n=(t.ial["data-sb-layout"]||t.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(t.children&&t.children.length>0){for(const n of t.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const s=(n.content||n.markdown||"").trim().toLowerCase();if(s==="col"||s==="h")return!0;if(s==="row"||s==="v")return!1}}const i=(t.markdown||t.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function yo(t){return!t||Fi(t)||se(t)||!wi(t.markdown,t.content)?!1:(t.markdown||t.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function Vo(t){var b;if(!t||!se(t)||!Ke(t))return null;const e=an(t);if(!e||e.length<2)return null;const i=[];let n=!1;for(const u of e){const h=(((b=u.ial)==null?void 0:b.style)||u.style||"").trim();let f=null;if(h){const v=h.match(/calc\(\s*([\d.]+)%/i);if(v)f=parseFloat(v[1]);else{const k=h.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);k&&(f=parseFloat(k[1]))}}f!==null&&!isNaN(f)&&f>0?(i.push(f),n=!0):i.push(null)}if(!n)return null;const s=e.length,o=i.reduce((u,h)=>u+(h||0),0),l=i.filter(u=>u===null).length,r=Math.max(0,100-o),a=l>0?r/l:100/s,c=i.map(u=>u!==null?u:a),d=c.reduce((u,h)=>u+h,0);if(d<=0)return null;const m=c.map(u=>u/d*100);if(m.length===2){const[u]=m;if(u>=48&&u<=52)return"1:1";if(u>=31&&u<=35)return"1:2";if(u>=65&&u<=69)return"2:1";if(u>=28&&u<=32)return"3:7";if(u>=68&&u<=72)return"7:3";if(u>=38&&u<=42)return"4:6";if(u>=58&&u<=62)return"6:4";if(u>=23&&u<=27)return"1:3";if(u>=73&&u<=77)return"3:1";const h=Math.round(u),f=100-h;return`${h}:${f}`}if(m.length===3){const[u,h,f]=m;if(u>=31&&u<=35&&h>=31&&h<=35&&f>=31&&f<=35)return"1:1:1";if(u>=23&&u<=27&&h>=48&&h<=52&&f>=23&&f<=27)return"1:2:1";if(u>=48&&u<=52&&h>=23&&h<=27&&f>=23&&f<=27)return"2:1:1";if(u>=23&&u<=27&&h>=23&&h<=27&&f>=48&&f<=52)return"1:1:2";if(u>=18&&u<=22&&h>=58&&h<=62&&f>=18&&f<=22)return"1:3:1";const v=Math.round(u),k=Math.round(h),x=100-v-k;return`${v}:${k}:${x}`}return m.map(u=>Math.round(u)).join(":")}function ai(t){if(!t||!se(t)||!Ke(t))return null;const e=(t.children||[]).filter(o=>{const l=o.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(o.markdown||o.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(e.length<2)return null;const i=yo(e[0]),n=yo(e[e.length-1]),s=Vo(t)||void 0;if(i&&!n){const o=wi(e[0].markdown,e[0].content);if(o)return{imageNode:e[0],imageUrl:o,layout:fs,contentNodes:e.slice(1),ratio:s}}if(!i&&n){const o=wi(e[e.length-1].markdown,e[e.length-1].content);if(o)return{imageNode:e[e.length-1],imageUrl:o,layout:ps,contentNodes:e.slice(0,e.length-1),ratio:s}}return null}function vf(t,e){const i=[];function n(s){for(const o of s){const l=ai(o);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const d=r.ial[gt];if(d!==a){const b={blockId:r.id,layout:a,previousLayout:d,ratio:c};r.ial[gt]=a,i.push(b),e&&e(b)}}o.children&&o.children.length>0&&n(o.children)}}return n(t),i}function an(t){return(t.children||[]).filter(e=>{const i=e.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const n=(e.markdown||e.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function pa(t){if(!t)return!1;const e=(t.type||"").toLowerCase();if(e==="h"||e==="nodeheading"||/^h[1-6]$/i.test(t.subType||""))return!0;const i=(t.markdown||t.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function Ai(t,e,i){let n="",s=0;const o=/<div\b([^>]*)>/gi;for(;s<t.length;){o.lastIndex=s;let l,r=!1,a=-1,c=0;for(;(l=o.exec(t))!==null;){const k=l[1].match(/\bclass=["']([^"']*)["']/i);if(k){const x=k[1];if(typeof e=="string"?x.split(/\s+/).includes(e):e.test(x)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){n+=t.slice(s);break}n+=t.slice(s,a);const d=a+c;let m=1,b=-1,u=-1;const h=/<\/?div\b[^>]*>/gi;h.lastIndex=d;let f;for(;(f=h.exec(t))!==null;)if(f[0].startsWith("</")){if(m--,m===0){b=f.index,u=f.index+f[0].length;break}}else m++;if(b!==-1&&u!==-1){const v=t.slice(d,b);n+=i(v),s=u}else n+=t.slice(a,d),s=d}return n}function bf(t){const e=[];let i="",n=0;const s=/<div\b([^>]*)>/gi;for(;n<t.length;){s.lastIndex=n;let o,l=!1,r=-1,a=0;for(;(o=s.exec(t))!==null;){const f=o[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(f)){l=!0,r=o.index,a=o[0].length;break}}if(!l){i+=t.slice(n);break}i+=t.slice(n,r);const c=r+a;let d=1,m=-1,b=-1;const u=/<\/?div\b[^>]*>/gi;u.lastIndex=c;let h;for(;(h=u.exec(t))!==null;)if(h[0].startsWith("</")){if(d--,d===0){m=h.index,b=h.index+h[0].length;break}}else d++;if(m!==-1&&b!==-1){const f=t.slice(r,b),v=`__VUE_DIV_TOKEN_${e.length}__`;e.push(f),i+=v,n=b}else i+=t.slice(r,c),n=c}return{text:i,tokens:e}}function yf(t){const e=[];let i=t.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${e.length}__`;return e.push(r),a});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${e.length}__`;return e.push(r),a});const n=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),a});const{text:s,tokens:o}=bf(i);i=s;const l=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=Ai(i,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),m=c[3].trim();return`**${d}:**
\`\`\`yaml
${m}
\`\`\``}).join(`

`)+`
`:r}),i=Ai(i,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),i=Ai(i,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let m="-";return d.includes("warn")?m="- ⚠️":d.includes("bad")?m="- ❌":d.includes("ok")&&(m="- ✅"),`${m} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=Ai(i,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const b=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${b}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=Ai(i,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=Ai(i,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=Ai(i,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((m,b)=>Math.max(m,b.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,d,m)=>{const b=m.trim();return b.includes("<")||b.includes(`
`)?r:`[${b}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,l[r]);for(let r=0;r<o.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,o[r]);for(let r=0;r<n.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,n[r]);for(let r=0;r<e.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,e[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function ha(t){if(!t||typeof t!="string")return"";const e=[];let i=t.replace(/`([^`]+)`/g,n=>(e.push(n),`%%INLINE_CODE_${e.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(n,s)=>e[parseInt(s,10)]||""),i}function kf(t){const e=Object.entries(t).filter(([n,s])=>s!=null&&s!=="");return e.length===0?"":`---
${e.map(([n,s])=>typeof s=="string"?s.includes(":")||s.includes(`
`)||s.includes("#")?`${n}: "${s.replace(/"/g,'\\"')}"`:`${n}: ${s}`:`${n}: ${JSON.stringify(s)}`).join(`
`)}
---`}function wf(t,e){if(!e||!t.startsWith("```"))return t;const i=t.indexOf(`
`);if(i===-1)return t;const n=t.slice(0,i).trim(),s=t.slice(i);return n.includes("{")?t:`${n} {${e}}${s}`}function ma(t,e){if(e==null)return t;const i=e.trim();return i===""||i==="+1"?`<v-click>

${t}

</v-click>`:i==="hide"?`<v-click hide>

${t}

</v-click>`:`<v-click at="${i}">

${t}

</v-click>`}function xf(t){if(!t||!t.preset)return null;const e=t.preset.toLowerCase().trim();if(!e||e==="none")return null;let i={opacity:0},n={opacity:1};switch(e){case"slide-up":i={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},n={opacity:1};break}t.initial&&typeof t.initial=="object"&&(i={...i,...t.initial}),t.enter&&typeof t.enter=="object"&&(n={...n,...t.enter});const s={...n.transition||{}};return typeof t.duration=="number"&&t.duration>0&&(s.duration=t.duration),typeof t.delay=="number"&&t.delay>0&&(s.delay=t.delay),Object.keys(s).length>0&&(n.transition=s),{initial:i,enter:n}}function Jn(t,e,i,n){const s=e!=null&&e.trim()!=="",o=xf(i),l=n==null?void 0:n.trim(),r=l!==void 0&&l!=="",a=r?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!s&&!o)return r?`<div${a}>

${t}

</div>`:t;if(s&&!o){if(r){const h=e.trim();let f="v-click";return h==="hide"?f="v-click.hide":h!==""&&h!=="+1"&&(f=`v-click="${h}"`),`<div ${f}${a}>

${t}

</div>`}return ma(t,e)}const c=JSON.stringify(o.initial).replace(/"/g,"'"),d=JSON.stringify(o.enter).replace(/"/g,"'"),m=`v-motion :initial="${c}" :enter="${d}"`;if(!s)return`<div ${m}${a}>

${t}

</div>`;const b=e.trim();let u="v-click";return b==="hide"?u="v-click.hide":b!==""&&b!=="+1"&&(u=`v-click="${b}"`),`<div ${u} ${m}${a}>

${t}

</div>`}function ga(t){if(!t)return"";let e=t.trim();e=e.replace(/\{:[^}]*\}/g,"").trim(),e=e.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),e=e.replace(/\r?\n?:::\s*$/g,"");let s=e.split(/\r?\n/).map(o=>o.trim().replace(/^>\s*/,"")).join(`
`).trim();return s=s.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),s=s.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),s=s.replace(/^[-*+]\s+/,""),s=s.replace(/^\d+\.\s+/,""),s.trim()}function Sf(t){var n;if(t.subType&&/^h([1-6])$/i.test(t.subType))return parseInt(t.subType.slice(1),10);const i=(t.markdown||t.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:t.type==="h"?(n=t.ial)!=null&&n.subType&&/^h([1-6])$/i.test(t.ial.subType)?parseInt(t.ial.subType.slice(1),10):1:null}function va(t,e=2){const i=Math.max(2,e);if(!t||t.length===0)return Array.from({length:i},()=>[]);if(t.length===1&&t[0].children&&t[0].children.length>=2){const c=t[0].children,d=Array.from({length:i},()=>[]),m=Math.min(i,c.length),b=Math.floor(c.length/m),u=c.length%m;let h=0;for(let f=0;f<m;f++){const v=b+(f<u?1:0);d[f]=c.slice(h,h+v),h+=v}return d}const n=c=>{const d=(c.slot||"").trim();if(!d)return null;if(d==="left")return 1;if(d==="center")return 2;if(d==="right")return i===2?2:i;const m=d.match(/^col-(\d+)$/i);if(m){const b=parseInt(m[1],10);if(b>=1&&b<=i)return b}return null},s=t.map(n);if(s.some(c=>c!==null)){if(s.some(u=>u!==null&&u>=2)){const u=Array.from({length:i},()=>[]);let h=1;for(const f of t){const v=n(f);v!==null&&(h=v),u[h-1].push(f)}return u}const d=t.filter(u=>n(u)===1),m=t.filter(u=>n(u)===null),b=i-1;if(m.length>=b){const u=Math.floor(m.length/b),h=m.length%b,f=[d];let v=0;for(let k=0;k<b;k++){const x=u+(k<h?1:0);f.push(m.slice(v,v+x)),v+=x}return f}else if(m.length>0){const u=[d];for(let h=0;h<b;h++)u.push(h<m.length?[m[h]]:[]);return u}else return[d,...Array.from({length:b},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const d=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(d)},r=t.map((c,d)=>l(c)?d:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let d=0;d<i;d++){const m=r[d],b=d+1<i?r[d+1]:t.length;c[d]=t.slice(m,b)}return c}if(t.length>=i){const c=Array.from({length:i},()=>[]);let d=0;for(let m=0;m<i;m++){const b=i-m,u=t.length-d,h=Math.ceil(u/b);c[m]=t.slice(d,d+h),d+=h}return c}if(t.length>1&&t.length<i){const c=Array.from({length:i},()=>[]);for(let d=0;d<t.length;d++)c[d]=[t[d]];return c}if(t.length===1){const c=t[0],d=(c.rawMarkdown||c.content||"").trim(),m=d.split(/\r?\n/),b=[];for(let f=0;f<m.length;f++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(m[f])&&b.push(f);if(b.length>=i){const f=Array.from({length:i},()=>[]);let v=0;for(let k=0;k<i;k++){const x=i-k,$=b.length-v,B=Math.ceil($/x),L=b[v],T=v+B<b.length?b[v+B]:m.length,w=m.slice(L,T).join(`
`);f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:w,content:w}],v+=B}return f}const u=d.match(/<li[\s\S]*?<\/li>/gi);if(u&&u.length>=i){const f=Array.from({length:i},()=>[]);let v=0;for(let k=0;k<i;k++){const x=i-k,$=u.length-v,B=Math.ceil($/x),L=`<ul>
${u.slice(v,v+B).join(`
`)}
</ul>`;f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:L,content:L}],v+=B}return f}const h=d.split(/\r?\n\s*\r?\n/).filter(f=>f.trim()!=="");if(h.length>=i){const f=Array.from({length:i},()=>[]);let v=0;for(let k=0;k<i;k++){const x=i-k,$=h.length-v,B=Math.ceil($/x),L=h.slice(v,v+B).join(`

`);f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:L,content:L}],v+=B}return f}}const a=Array.from({length:i},()=>[]);return a[0]=t,a}function zr(t,e,i,n){var d;const s=df(e),o=[],l=Or(e);let r={pageIndex:1,startBlockId:t,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[t]};r.frontmatter.background&&(r.frontmatter.background=Ae(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ae(r.frontmatter.image,n)),o.push(r);let a=[];for(const m of i){if(Ss(m)){a=[];const u=Or(m.ial);if(o.length===1&&r.blocks.length===0){r.startBlockId=m.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(m.id)||r.allBlockIds.push(m.id),u.frontmatter.layout&&(r.frontmatter.layout=u.frontmatter.layout),Object.assign(r.frontmatter,u.frontmatter),!u.frontmatter.image&&l.frontmatter.image&&(r.frontmatter.image=l.frontmatter.image),!u.frontmatter.background&&l.frontmatter.background&&(r.frontmatter.background=l.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=Ae(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ae(r.frontmatter.image,n));continue}r={pageIndex:o.length+1,startBlockId:m.id,frontmatter:{layout:u.frontmatter.layout||"default",...u.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[m.id]},r.frontmatter.background&&(r.frontmatter.background=Ae(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ae(r.frontmatter.image,n)),o.push(r);continue}const b=(u,h)=>{var U,E,P,j;if(r.allBlockIds||(r.allBlockIds=[]),u.id&&!r.allBlockIds.includes(u.id)&&r.allBlockIds.push(u.id),u.children&&u.children.length>0){const tt=A=>{for(const M of A)M.id&&!r.allBlockIds.includes(M.id)&&r.allBlockIds.push(M.id),M.children&&M.children.length>0&&tt(M.children)};tt(u.children)}let f=Dc(u),v=u.ial?{...u.ial}:{};const k=f.match(/\{:\s*([^}]+)\s*\}\s*$/);k&&(v={...Lc(k[0]),...v},f=f.slice(0,k.index).trim()),u.type!=="c"&&!f.startsWith("```")&&(f=ha(f));let x=f.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(x)||x==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(x)&&/\r?\n\}\}\}$/.test(x)&&(f=x.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),x=f.trim());const $=uf(v);if(f=Rc(f,n),f=Mc(f,n==null?void 0:n.refContentMap),u.children&&u.children.length>0){const tt=["custom-slidev-autoplay","custom-slidev-loop","custom-slidev-muted","custom-slidev-controls"],A=M=>{for(const Y of M){if(Y.ial)for(const[J,et]of Object.entries(Y.ial))tt.includes(J)&&!v[J]&&(v[J]=et);Y.children&&Y.children.length>0&&A(Y.children)}};A(u.children)}const B=u.type==="video"||u.type==="NodeVideo"||/<video\b/i.test(f);if(B){const tt=v["custom-slidev-autoplay"]==="true",A=v["custom-slidev-loop"]==="true",M=v["custom-slidev-muted"]==="true"||tt,Y=v["custom-slidev-controls"]==="false";f=f.replace(/<video\b([^>]*)>/gi,(J,et)=>{let it=et;return Y?it=it.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(it)||(it+=" controls"),tt&&!/autoplay/i.test(it)?it+=" autoplay playsinline":!tt&&v["custom-slidev-autoplay"]==="false"&&(it=it.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),A&&!/loop/i.test(it)?it+=" loop":!A&&v["custom-slidev-loop"]==="false"&&(it=it.replace(/\bloop\b/gi,"").trim()),M&&!/muted/i.test(it)?it+=" muted":!M&&v["custom-slidev-muted"]==="false"&&(it=it.replace(/\bmuted\b/gi,"").trim()),`<video ${it.trim()}>`})}if($.isBackground){const tt=wi(f,u.content);if(tt){r.frontmatter.background=Ae(tt,n);return}}const L=ai(u);if(L){r.frontmatter.layout=L.layout,r.frontmatter.image=Ae(L.imageUrl,n),!r.frontmatter.layoutRatio&&L.ratio&&(r.frontmatter.layoutRatio=L.ratio);for(const tt of L.contentNodes)b(tt);return}if($.imageLayout==="image-left"||$.imageLayout==="image-right"){const tt=wi(f,u.content);if(tt){r.frontmatter.layout=$.imageLayout,r.frontmatter.image=Ae(tt,n),!r.frontmatter.layoutRatio&&((U=u.ial)!=null&&U[le])&&(r.frontmatter.layoutRatio=u.ial[le]);return}}if(se(u)&&u.children&&u.children.length>0){for(const tt of u.children)b(tt);return}const T=!!($.slot||h!=null&&h.defaultSlot||r.frontmatter.layout==="clover"||Tn(r.frontmatter.layout)||r.frontmatter.layout==="two-cols");if((u.type==="l"||u.type==="NodeList"||u.type==="list")&&u.children&&u.children.length>0&&(u.children.some(tt=>{var A,M;return((A=tt.ial)==null?void 0:A[At])||((M=tt.ial)==null?void 0:M[Wt])})||$.slot||$.clicks||T)){for(const tt of u.children)$.slot&&(!tt.ial||!tt.ial[At])&&(tt.ial||(tt.ial={}),tt.ial[At]=$.slot),b(tt,{...h,parentClicks:$.clicks||(h==null?void 0:h.parentClicks),defaultSlot:$.slot||(h==null?void 0:h.defaultSlot)});return}const w=!!(u.children&&u.children.length>=2)||!!$.clicks||!!((E=u.children)!=null&&E.some(tt=>{var A;return(A=tt.ial)==null?void 0:A[Wt]}))||!u.markdown&&!!(u.children&&u.children.length>0);if(Fi(u)&&u.children&&u.children.length>0&&(T||$.clicks||u.children.some(tt=>{var A;return(A=tt.ial)==null?void 0:A[Wt]}))&&w){const tt=!!(u.children&&u.children.length>=2),A=u.children.find(lt=>!!(lt.markdown||lt.content||"").trim())||u.children[0],M=((P=A==null?void 0:A.ial)==null?void 0:P[Wt])||((j=A==null?void 0:A.ial)==null?void 0:j["custom-slidev-click"]),Y=!!(!$.clicks&&tt&&M),J=$.clicks||(Y?M:void 0)||(h==null?void 0:h.parentClicks),et=u.id||(h==null?void 0:h.parentContainerId),it=$.slot||(h==null?void 0:h.defaultSlot);let pt=!0;for(const lt of u.children){it&&(!lt.ial||!lt.ial[At])&&(lt.ial||(lt.ial={}),lt.ial[At]=it);const H=!!(lt.markdown||lt.content||"").trim(),at=pt&&H;at&&(lt.markdown&&(lt.markdown=xn(lt.markdown)),lt.content&&(lt.content=xn(lt.content)),pt=!1);let ut=lt;at&&J&&tt&&(ut={...lt,ial:{...lt.ial||{}}},delete ut.ial[Wt],delete ut.ial["custom-slidev-click"]),b(ut,{parentClicks:J,parentContainerId:et,defaultSlot:it})}return}if($.isNote){const tt=ga(f);tt&&(r.notes?r.notes+=`

`+tt:r.notes=tt),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:u.id,type:u.type,content:tt||u.content||"",rawMarkdown:f,isNote:!0,attributes:u.ial});return}$.shikiLines&&(f=wf(f,$.shikiLines)),x=f.trim();const W=(u.content||"").trim();if(x==="::right::"||W==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(x)||x.startsWith("::right::")){r.blocks.push({id:u.id,type:u.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:u.ial});return}const q=Sf(u);let X=$.slot,C=$.clicks,z=$.motion,y={...u.ial||{}};if(q!==null){for(;a.length>0&&a[a.length-1].level>=q;)a.pop();const tt=a.length>0?a[a.length-1]:void 0;!X&&(tt!=null&&tt.slot)&&(X=tt.slot),!C&&(tt!=null&&tt.clicks)&&!(h!=null&&h.parentContainerId)&&(C=tt.clicks),!z&&(tt!=null&&tt.motion)&&(z=tt.motion);const A={...(tt==null?void 0:tt.customAttrs)||{}};if(u.ial)for(const[M,Y]of Object.entries(u.ial))M.startsWith("custom-slidev-")&&!M.startsWith("custom-slidev-slide")&&(A[M]=Y);h!=null&&h.parentContainerId||a.push({level:q,slot:X,clicks:C,motion:z,customAttrs:A})}else{const tt=a.length>0?a[a.length-1]:void 0;tt&&(!X&&tt.slot&&tt.slot!=="header"&&(X=tt.slot),!C&&tt.clicks&&!(h!=null&&h.parentContainerId)&&(C=tt.clicks),!z&&tt.motion&&(z=tt.motion),tt.customAttrs&&(y={...tt.customAttrs,...y}))}!X&&r.blocks.some(tt=>tt.slot==="slot-divider-right")&&(X="right"),!X&&(h!=null&&h.defaultSlot)&&(X=h.defaultSlot),X&&(y[At]=X),C&&!y[Wt]&&(y[Wt]=C),z&&!y[Ve]&&(y[Ve]=JSON.stringify(z)),(B||v["custom-slidev-autoplay"]||v["custom-slidev-muted"])&&(v["custom-slidev-autoplay"]&&(y["custom-slidev-autoplay"]=v["custom-slidev-autoplay"],v["custom-slidev-autoplay"]==="true"&&!v["custom-slidev-muted"]&&(y["custom-slidev-muted"]="true")),v["custom-slidev-loop"]&&(y["custom-slidev-loop"]=v["custom-slidev-loop"]),v["custom-slidev-muted"]&&(y["custom-slidev-muted"]=v["custom-slidev-muted"]),v["custom-slidev-controls"]&&(y["custom-slidev-controls"]=v["custom-slidev-controls"]));const D={id:u.id,type:u.type,content:u.content||"",rawMarkdown:f,clicks:C,parentClicks:h==null?void 0:h.parentClicks,parentContainerId:h==null?void 0:h.parentContainerId,motion:z,shikiLines:$.shikiLines,slot:X,attributes:y,rawNode:u};r.blocks.push(D)};b(m)}for(let m=0;m<o.length;m++){const b=o[m],u=[],h={...b.frontmatter};m===0&&(h.theme=s.theme,h.aspectRatio=s.aspectRatio,h.highlighter=s.highlighter,h.transition=b.frontmatter.transition||s.defaultTransition);const f=kf(h);f&&u.push(f);const v=b.blocks.filter(L=>L.slot!=="slot-divider-right"),k=L=>L.filter(T=>!!(T.rawMarkdown||T.content||"").trim()).map(T=>{var w;return Jn(T.rawMarkdown,T.clicks,T.motion,(w=T.attributes)==null?void 0:w.style)}).join(`

`),x=L=>{const T=L.filter(q=>!!(q.rawMarkdown||q.content||"").trim());if(T.length===0)return;const w=T[0],W=(w.rawMarkdown||w.content||"").trim();(Fi(w)||/^(?:[-*+]|\d+\.)\s+/.test(W))&&(w.rawMarkdown=xn(w.rawMarkdown||w.content||""),w.content=w.rawMarkdown)},$=L=>{var q,X;if(L.length===0)return"";x(L);const T=(q=L.find(C=>C.parentClicks))==null?void 0:q.parentClicks;if(!T)return L.filter(C=>!!(C.rawMarkdown||C.content||"").trim()).map(C=>{var z;return Jn(C.rawMarkdown,C.clicks,C.motion,(z=C.attributes)==null?void 0:z.style)}).join(`

`);const w=[];let W=[];const V=()=>{if(W.length===0)return;const C=W.map(z=>(z.rawMarkdown||z.content||"").trim()).filter(Boolean).join(`

`);C&&w.push(ma(C,T)),W=[]};for(const C of L){if(!(C.rawMarkdown||C.content||"").trim())continue;!!(C.clicks&&C.clicks.trim()!=="")?(V(),w.push(Jn(C.rawMarkdown,C.clicks,C.motion,(X=C.attributes)==null?void 0:X.style))):W.push(C)}return V(),w.join(`

`)},B=b.frontmatter.layout||"default";if(B==="clover"||Tn(B)){let L=[];const T=v.filter(C=>C.slot==="header");if(T.length>0)L=T;else if(v.length>0){const C=v.find(z=>z.type==="h"&&(!z.slot||z.slot==="default"));C&&(L=[C])}const w=v.filter(C=>!L.includes(C));let W=2;if(B==="clover")W=4;else if(B==="three-cols-header")W=3;else if(B==="two-cols-header")W=2;else{let C=0;for(const z of w){const y=(z.slot||"").match(/^col-(\d+)$/i);y&&(C=Math.max(C,parseInt(y[1],10)))}if(C>=2)W=C;else if(b.frontmatter.layoutRatio){const z=b.frontmatter.layoutRatio.trim();if(z.includes(":")){const y=z.split(":").map(D=>parseFloat(D.trim())).filter(D=>!isNaN(D)&&D>0);y.length>=2&&(W=y.length)}else{const y=z.split(/\s+/).filter(Boolean);y.length>=2&&(W=y.length)}}else w.length===1&&w[0].children&&w[0].children.length>=2&&(W=Math.min(6,w[0].children.length))}const V=va(w,W);V.forEach((C,z)=>{const y=`col-${z+1}`;for(const D of C)(!D.slot||D.slot==="default")&&(D.slot=y);x(C)});const q=V.flat();if(w.length===1&&q.length>1){const C=b.blocks.findIndex(z=>z.id===w[0].id);C!==-1&&b.blocks.splice(C,1,...q)}const X=k(L);if(X&&u.push(X),B==="two-cols-header"&&W===2){const C=$(V[0]||[]),z=$(V[1]||[]);C&&u.push(`::left::

${C}`),z&&u.push(`::right::

${z}`)}else V.forEach((C,z)=>{const y=$(C);y&&u.push(`::col-${z+1}::

${y}`)})}else if(B==="two-cols"){const L=v.filter(V=>V.slot==="left"),T=v.filter(V=>V.slot==="right");x(L),x(T);const w=k(L.length>0?L:v.filter(V=>V.slot!=="right")),W=k(T);u.push(w),W&&u.push(`::right::

${W}`)}else for(const L of v)u.push(Jn(L.rawMarkdown,L.clicks,L.motion,(d=L.attributes)==null?void 0:d.style));b.notes&&u.push(`<!--
${b.notes}
-->`),b.rawMarkdown=u.join(`

`).trim()}const c=o.map(m=>m.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:t,config:s,slides:o,fullMarkdown:c}}const ko=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function _f(t){var s,o,l,r,a,c,d,m,b,u,h,f;if(!t||typeof t!="object")return"";const e=[],i=[];if(Array.isArray(t.styles))for(const v of t.styles){if(!v||!v.id)continue;const k=`--b3-inline-style-${v.id}`;(s=v.light)!=null&&s.color&&e.push(`  ${k}-color: ${v.light.color};`),(o=v.light)!=null&&o.backgroundColor&&e.push(`  ${k}-background-color: ${v.light.backgroundColor};`),(l=v.dark)!=null&&l.color&&i.push(`  ${k}-color: ${v.dark.color};`),(r=v.dark)!=null&&r.backgroundColor&&i.push(`  ${k}-background-color: ${v.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.colors))for(const v of t.builtin.colors){if(!v||typeof v.index!="number")continue;const k=v.index;(a=v.light)!=null&&a.color&&e.push(`  --b3-font-color${k}: ${v.light.color};`),(c=v.light)!=null&&c.backgroundColor&&e.push(`  --b3-font-background${k}: ${v.light.backgroundColor};`),(d=v.dark)!=null&&d.color&&i.push(`  --b3-font-color${k}: ${v.dark.color};`),(m=v.dark)!=null&&m.backgroundColor&&i.push(`  --b3-font-background${k}: ${v.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.styles))for(const v of t.builtin.styles){if(!v||!v.id)continue;const k=v.id;(b=v.light)!=null&&b.color&&e.push(`  --b3-card-${k}-color: ${v.light.color};`),(u=v.light)!=null&&u.backgroundColor&&e.push(`  --b3-card-${k}-background: ${v.light.backgroundColor};`),(h=v.dark)!=null&&h.color&&i.push(`  --b3-card-${k}-color: ${v.dark.color};`),(f=v.dark)!=null&&f.backgroundColor&&i.push(`  --b3-card-${k}-background: ${v.dark.backgroundColor};`)}if(e.length===0&&i.length===0)return"";const n=[];return e.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${e.join(`
`)}
}`),i.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),n.join(`

`)}function _n(t){const e=_f(t);return e?`${ko}

/* Custom Workspace Inline Styles */
${e}`:ko}function Xs(t){const e={};if(!t||typeof t!="string")return e;const i=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(i))!==null;){const o=s[1],l=s[2]??s[3]??s[4]??"";e[o]=l}return e}function Cf(t){const e=String((t==null?void 0:t.type)||"").toLowerCase();return e==="s"||e==="sb"||e==="nodesuperblock"||e==="l"||e==="nodelist"||e==="i"||e==="nodelistitem"||e==="b"||e==="nodeblockquote"}function $f(t,e){const i=new Map,n=[];if(!Array.isArray(e)||e.length===0)return{usable:!1,reason:"索引无行",leafPatch:i,rebuildRoots:n};const s=new Map;for(const o of e)o!=null&&o.id&&s.set(o.id,o);for(const o of t||[]){if(!(o!=null&&o.id))continue;const l=s.get(o.id);if(!l)continue;const r=o.content??"",a=o.markdown??"";(l.content??"")===r&&(l.markdown??"")===a||(Cf(l)?n.push(o.id):i.set(o.id,{content:r,markdown:a}))}return{usable:!0,reason:"",leafPatch:i,rebuildRoots:n}}function If(t){const e=String((t==null?void 0:t.type)||"").toLowerCase();return e==="h"||e==="nodeheading"}function wo(t){return se(t)||t.type==="l"||t.type==="NodeList"||t.type==="i"||t.type==="NodeListItem"||t.type==="b"||t.type==="NodeBlockquote"}function Af(t,e,i,n=8,s){const o=new Map;for(const b of e)b!=null&&b.id&&o.set(b.id,b);const l=b=>({id:b.id,parent_id:b.parent_id,root_id:b.root_id||t,type:b.type,subType:b.subtype??b.subType??"",content:b.content||"",markdown:b.markdown||"",ial:i(b.id,b.ial),children:[]}),r=b=>{let u=b.parent_id,h=0;for(;u&&u!==t&&h++<16;){const f=o.get(u);if(!f||!If(f))return u;u=f.parent_id}return u||t},a=new Map;for(const b of e){if(!(b!=null&&b.id)||b.id===t||s&&s.size>0&&!s.has(b.id))continue;const u=r(b),h=a.get(u);h?h.push(b):a.set(u,[b])}if(s&&s.size>0)for(const b of a.values())b.sort((u,h)=>(s.get(u.id)??Number.MAX_SAFE_INTEGER)-(s.get(h.id)??Number.MAX_SAFE_INTEGER));const c=new Map,d=(b,u)=>{const h=l(b);if(c.set(h.id,h),u>=n||!wo(h))return h;const f=a.get(h.id);return f&&f.length>0&&(h.children=f.map(v=>d(v,u+1))),h};return{topLevel:(a.get(t)||[]).map(b=>d(b,0)),byId:c}}const Tf={getBlockAttrs:_o,getChildBlocks:cs,getDocBlocksOrders:Tc,setBlockAttrs:Dt,sql:tn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:Bc};class Bf{constructor(e){kt(this,"deps");kt(this,"attrOverrides",new Map);kt(this,"trackedListSuperBlocks",new Map);kt(this,"fallbackWarnedDocId","");this.deps={...Tf,...e||{}}}setBlockAttrOverride(e,i){if(!e||!i)return;const s={...this.attrOverrides.get(e)||{}};for(const[o,l]of Object.entries(i))l===""||l===null||l===void 0?delete s[o]:s[o]=String(l);Object.keys(s).length===0?this.attrOverrides.delete(e):this.attrOverrides.set(e,s)}getBlockAttrOverride(e){return this.attrOverrides.get(e)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(e){return this.trackedListSuperBlocks.get(e)||[]}clearBlockAttrOverride(e,i){if(!e)return;if(!i){this.attrOverrides.delete(e);return}const n=this.attrOverrides.get(e);n&&(delete n[i],Object.keys(n).length===0&&this.attrOverrides.delete(e))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(e){try{const i=await this.deps.getBlockAttrs(e).catch(()=>({}))||{},n=this.attrOverrides.get(e);n&&Object.assign(i,n);const s=await this.deps.getChildBlocks(e).catch(()=>[])||[],o=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(e).catch(()=>[])||[]:[],l=new Map;for(let D=0;D<o.length;D++)o[D]&&l.set(o[D],D);const r=l.size>0,a=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${e}' AND id != '${e}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[],d=$f(s,c),m=new Map;if(Array.isArray(c))for(const D of c)D.id&&D.ial&&m.set(D.id,Xs(D.ial));const b=`SELECT block_id, name, value FROM attributes WHERE root_id = '${e}' AND type = 'b' LIMIT 99999`,u=await this.deps.sql(b).catch(()=>[])||[];if(Array.isArray(u)){for(const D of u)if(D.block_id&&D.name){let U=m.get(D.block_id);U||(U={},m.set(D.block_id,U)),U[D.name]=D.value||""}}const h=(D,U)=>{const E={...m.get(D)||(U?Xs(U):{})},P=this.attrOverrides.get(D);return P&&Object.assign(E,P),E},f=Array.isArray(c)&&c.length>0?Af(e,c,h,8,l):null,v=s.map(D=>D.id).filter(Boolean),k=D=>({id:D.id,parent_id:D.parent_id,root_id:D.root_id||e,type:D.type,subType:D.subType,content:D.content||"",markdown:D.markdown||"",ial:h(D.id,D.ial),children:D.children}),x=async(D,U=0)=>{if(!D||U>8||!wo(D))return;const E=await this.deps.getChildBlocks(D.id).catch(()=>[])||[];if(!(!Array.isArray(E)||E.length===0)){D.children=E.filter(P=>P==null?void 0:P.id).map(P=>({id:P.id,parent_id:D.id,root_id:e,type:P.type,subType:P.subType,content:P.content||"",markdown:P.markdown||"",ial:h(P.id,P.ial),children:[]}));for(const P of D.children)await x(P,U+1)}},$=new Map;for(const D of c)D!=null&&D.id&&$.set(D.id,D);const B=v.every(D=>{const U=$.get(D);return!U||!!U.type});let L=[],T=!1;if(f&&d.usable&&r&&B){this.fallbackWarnedDocId="";for(const[U,E]of d.leafPatch){const P=f.byId.get(U);P&&(P.content=E.content,P.markdown=E.markdown)}const D=new Map;for(const U of s)U!=null&&U.id&&D.set(U.id,U);for(const U of d.rebuildRoots){const E=f.byId.get(U),P=D.get(U);E&&P&&(E.content=P.content||"",E.markdown=P.markdown||""),await x(E)}for(const U of s){if(!(U!=null&&U.id)||f.byId.has(U.id))continue;const E=k(U);await x(E),f.byId.set(E.id,E),f.topLevel.push(E)}L=f.topLevel.filter(U=>l.has(U.id)).sort((U,E)=>(l.get(U.id)??0)-(l.get(E.id)??0))}else v.length>0?(T=!0,this.fallbackWarnedDocId!==e&&(this.fallbackWarnedDocId=e,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${e} 实时顶层=${v.length} 索引行=${c.length} 文档序=${o.length} 原因=${d.reason||"缺少实时文档序"}`)),L=s.map(D=>k(D))):f&&(L=f.topLevel);const w=async(D,U=0)=>{if(!(!D||D.length===0||U>8))for(const E of D){if(wo(E)&&(!E.children||E.children.length===0)){let j=await this.deps.getChildBlocks(E.id).catch(()=>[]);if(!j||j.length===0){const tt=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${E.id}' ORDER BY sort ASC, created ASC`;j=await this.deps.sql(tt).catch(()=>[])||[]}if(Array.isArray(j)&&j.length>0){const tt=new Set(L.map(M=>M.id)),A=j.filter(M=>M.id!==E.id&&!tt.has(M.id));A.length>0&&(E.children=A.map(M=>{const Y=m.get(M.id)||(M.ial?Xs(M.ial):{}),J=this.attrOverrides.get(M.id);return J&&Object.assign(Y,J),{id:M.id,parent_id:M.parent_id||E.id,root_id:M.root_id||e,type:M.type,subType:M.subType,content:M.content||"",markdown:M.markdown||"",ial:Y}}))}}E.children&&E.children.length>0&&await w(E.children,U+1)}};T&&await w(L);const W=D=>{var U,E;for(const P of D)if(P.children&&P.children.length>0){W(P.children);for(const j of P.children)if(j.ial)for(const[tt,A]of Object.entries(j.ial))tt.startsWith("custom-slidev-")&&!((U=P.ial)!=null&&U[tt])&&(P.ial||(P.ial={}),P.ial[tt]=A);if(P.ial){for(const[j,tt]of Object.entries(P.ial))if(j.startsWith("custom-slidev-"))for(const A of P.children)(A.type==="video"||A.type==="NodeVideo"||/<video\b/i.test(A.markdown||A.content||""))&&!((E=A.ial)!=null&&E[j])&&(A.ial||(A.ial={}),A.ial[j]=tt)}}};W(L),vf(L,D=>{const U={[gt]:D.layout};this.setBlockAttrOverride(D.blockId,U),(this.deps.setBlockAttrs||Dt)(D.blockId,U).catch(P=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",P)})});const V=this.trackedListSuperBlocks.get(e)||[],q=gf(e,L,{tracked:V,onTagChange:D=>{this.setBlockAttrOverride(D.blockId,D.attrs),D.blockId===e&&Object.assign(i,D.attrs);const U=P=>{for(const j of P)j.id===D.blockId&&(j.ial||(j.ial={}),Object.assign(j.ial,D.attrs)),j.children&&j.children.length>0&&U(j.children)};U(L),(this.deps.setBlockAttrs||Dt)(D.blockId,D.attrs).catch(P=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",P)})}});this.trackedListSuperBlocks.set(e,q.newTracked);const X=new Set;for(const D of L){const U=D.markdown||D.content||"";if(U.includes("((")){const E=Ec(U);for(const P of E)X.add(P.blockId)}}const C={};if(X.size>0){const D=Array.from(X).map(E=>`'${E}'`).join(","),U=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${D})`).catch(()=>[])||[];if(Array.isArray(U))for(const E of U)E.id&&(C[E.id]=E.markdown||E.content||"")}const z=this.deps.getBaseUrl?this.deps.getBaseUrl():"",y=zr(e,i,L,{baseUrl:z,refContentMap:C});try{const D=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;y.customThemeCss=_n(D)}catch{y.customThemeCss=_n(null)}return y}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const n=zr(e,{},[],{});return n.customThemeCss=_n(null),n}}}const Et=new Bf;class qo{constructor(e){kt(this,"devServerUrl","http://localhost:3030");kt(this,"isConnected",!1);kt(this,"lastSyncTime",null);e&&(this.devServerUrl=e)}getUrl(){return this.devServerUrl}setUrl(e){this.devServerUrl=e.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(e=1500){try{const i=new AbortController,n=setTimeout(()=>i.abort(),e),s=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!s,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(e){const i=e.config,n=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.colorSchema&&i.colorSchema!=="auto"&&n.push(`colorSchema: ${i.colorSchema}`),n.push("drawings:","  persist: false","---","");const s=n.join(`
`),o=e.slides.map((r,a)=>{const c=r.frontmatter||{},d=[],m=a===0;c.layout&&c.layout!=="default"&&d.push(`layout: ${c.layout}`),c.transition&&d.push(`transition: ${c.transition}`),c.background&&d.push(`background: ${c.background}`),c.class&&d.push(`class: "${c.class}"`);let b="";d.length>0?b=m?"":`---
${d.join(`
`)}
---

`:m||(b=`---

`);let u="";if(c.layout==="two-cols"){const f=r.blocks.filter($=>$.slot!=="right"),v=r.blocks.filter($=>$.slot==="right"),k=f.map($=>$.rawMarkdown||$.content||"").join(`

`),x=v.map($=>$.rawMarkdown||$.content||"").join(`

`);u=`${k}

::right::

${x}`}else u=r.blocks.map(f=>f.rawMarkdown||f.content||"").join(`

`);let h="";return r.notes&&r.notes.trim()&&(h=`

<!--
${r.notes.trim()}
-->`),`${b}${u}${h}`}).join(`

`);let l="";return e.config.normalizeHeadingSizes&&(l=`

<style>
/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}
</style>`),`${s}${o}${l}
`}async syncToWorkspaceFile(e,i="/data/storage/petal/siyuan-slidev/slides.md",n){const s=this.buildStandardSlidevMarkdown(e);if(this.lastSyncTime=Date.now(),n)try{const o=typeof Blob<"u"?new Blob([s],{type:"text/markdown;charset=utf-8"}):Buffer.from(s,"utf-8");return await n(i,!1,o),{success:!0,path:i}}catch(o){return{success:!1,path:i,error:String(o)}}return{success:!0,path:i}}downloadSlidesMd(e,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(e),s=new Blob([n],{type:"text/markdown;charset=utf-8"}),o=URL.createObjectURL(s),l=document.createElement("a");return l.href=o,l.download=i,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(o),!0}}function Ef(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function _e(t){const e=Ef();if(e)try{return e(t)}catch{try{const i=t.startsWith("node:")?t.slice(5):`node:${t}`;return e(i)}catch{}}}function Ko(){var e;if(typeof window<"u"&&window.process)return window.process;const t=_e("process");return t&&t.versions?t:typeof process<"u"&&((e=process.versions)!=null&&e.node)?process:globalThis.process}function ba(){var e,i;const t=Ko();if(t&&((e=t.versions)!=null&&e.node))return!0;if(typeof window<"u"&&window.siyuan){const n=_e("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function Mf(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function On(){const t=Ko();if(t!=null&&t.platform)return t.platform;if(typeof process<"u"&&process.platform)return process.platform;const e=_e("os");if(e&&typeof e.platform=="function")return e.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function ya(){var n,s;const t=Ko(),e={...(t==null?void 0:t.env)||{}};if(On()==="win32"){const o=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=t==null?void 0:t.env)!=null&&n.APPDATA?`${t.env.APPDATA}\\npm`:"",(s=t==null?void 0:t.env)!=null&&s.USERPROFILE?`${t.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(e).find(c=>c.toLowerCase()==="path")||"PATH",a=(e[l]||"").split(";").filter(Boolean);for(const c of o)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);e[l]=a.join(";")}return e}function xo(t){var i,n,s;if(!t)return"";if(/^[a-zA-Z]:[/\\]/.test(t))return t.replace(/\\/g,"/");let e="";if(typeof window<"u"&&((s=(n=(i=window.siyuan)==null?void 0:i.config)==null?void 0:n.system)!=null&&s.dataDir)&&(e=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),e&&t.startsWith("/data/")){const o=t.slice(6);return`${e}/${o}`.replace(/\\/g,"/")}return t}function Df(){const t=_e("os"),e=_e("path");if(t&&typeof t.tmpdir=="function"){const i=t.tmpdir();return e&&typeof e.join=="function"?e.join(i,"siyuan-slidev-pro").replace(/\\/g,"/"):`${i}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class Go{constructor(e){kt(this,"runner");this.runner=e||Go.defaultRunner}static async defaultRunner(e,i){var n;try{let s=(n=_e("child_process"))==null?void 0:n.execFile;if(!s){const a=await import("node:child_process").catch(()=>({}));s=a==null?void 0:a.execFile}if(!s)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=On()==="win32",r=ya();return await new Promise(a=>{s(e,i,{timeout:5e3,shell:l,env:r},(c,d,m)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:m?String(m).trim():""})})})}catch(s){return{code:-1,stdout:"",stderr:String(s)}}}async detect(){const e=ba(),i=On();if(!e)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,s,o=!1,l;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,s=r.stdout)}catch{}if(n){try{const r=i==="win32"?"slidev.cmd":"slidev",a=await this.runner(r,["--version"]);a.code===0&&a.stdout&&(o=!0,l=a.stdout)}catch{}if(!o)try{const r=i==="win32"?"npx.cmd":"npx",a=await this.runner(r,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(o=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:s,hasSlidevCli:o,slidevVersion:l,platform:i,isDesktop:e}}}class Lf{constructor(){kt(this,"iframe",null);kt(this,"isReady",!1);kt(this,"pageChangedHandlers",[]);kt(this,"readyHandlers",[]);kt(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(e){this.detach(),this.iframe=e,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(e,i){var s;if(!((s=this.iframe)!=null&&s.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:e,...i};try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[NativeSlidevBridge] postMessage error:",o)}}navigateToPage(e){this.postMessage("navigate",{no:e})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(e){return this.pageChangedHandlers.push(e),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==e)}}onReady(e){return this.readyHandlers.push(e),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==e)}}handleWindowMessage(e){const i=e.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(i.type==="update-state"&&i.navState){const n=i.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const s of this.pageChangedHandlers)s(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const n of this.pageChangedHandlers)n(i.no,this.currentState.total||1,this.currentState)}}}}class Rf{constructor(e){kt(this,"childProcess",null);kt(this,"activePort",null);kt(this,"isRunning",!1);kt(this,"defaultPort");kt(this,"maxPortRetries");kt(this,"probeTimeoutMs");kt(this,"customSpawner");kt(this,"customPortChecker");this.defaultPort=(e==null?void 0:e.defaultPort)||3030,this.maxPortRetries=(e==null?void 0:e.maxPortRetries)||20,this.probeTimeoutMs=(e==null?void 0:e.probeTimeoutMs)||1e4,this.customSpawner=e==null?void 0:e.customSpawner,this.customPortChecker=e==null?void 0:e.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(e){if(this.customPortChecker)return this.customPortChecker(e);try{let i=_e("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(n=>{const s=i.createServer();s.once("error",()=>n(!1)),s.once("listening",()=>{s.close(()=>n(!0))}),s.listen(e,"127.0.0.1")}):!0}catch{return!0}}async allocPort(e){const i=e||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const s=i+n;if(await this.isPortAvailable(s))return s}return i}async pollServerReady(e,i=8e3,n=300){const s=Date.now();for(;Date.now()-s<i;){try{const o=new AbortController,l=setTimeout(()=>o.abort(),n),r=await fetch(e,{method:"HEAD",mode:"no-cors",signal:o.signal}).catch(()=>null);if(clearTimeout(l),r)return!0}catch{}await new Promise(o=>setTimeout(o,n))}return!1}async startServer(e,i){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(i);this.activePort=n;const o=On()==="win32"?"npx.cmd":"npx",l=xo(e),r=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(o,r,{detached:!1});else{let m=(a=_e("child_process"))==null?void 0:a.spawn;if(!m){const h=await import("node:child_process").catch(()=>({}));m=h==null?void 0:h.spawn}if(!m)throw new Error("child_process spawn not available in current runtime");const b=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,u=ya();this.childProcess=m(o,r,{cwd:b,detached:!1,shell:!0,env:{...u,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var e;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),On()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(e=_e("child_process"))==null?void 0:e.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:s})=>{var o;s(`taskkill /pid ${(o=this.childProcess)==null?void 0:o.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Zo{constructor(){kt(this,"iframe",null);kt(this,"isReady",!1);kt(this,"pendingMessages",[]);kt(this,"slideChangedHandlers",[]);kt(this,"blockClickedHandlers",[]);kt(this,"openInEditorHandlers",[]);kt(this,"clientReadyHandlers",[]);kt(this,"openPeekDrawerHandlers",[]);kt(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(e){this.detach(),this.iframe=e,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(e,i){var s;const n={source:"siyuan-slidev-host",action:e,payload:i};if(!((s=this.iframe)!=null&&s.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[WebSandboxBridge] postMessage error:",o)}}updateSlides(e,i,n,s){this.postMessage("UPDATE_SLIDES",{slides:e,config:i,fullMarkdown:n,customThemeCss:s})}navigatePage(e){this.postMessage("NAVIGATE_PAGE",{pageIndex:e})}highlightElement(e){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:e})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(e){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:e})}onSlideChanged(e){return this.slideChangedHandlers.push(e),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==e)}}onBlockClicked(e){return this.blockClickedHandlers.push(e),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==e)}}onOpenInEditor(e){return this.openInEditorHandlers.push(e),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==e)}}onOpenPeekDrawer(e){return this.openPeekDrawerHandlers.push(e),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==e)}}onRequestToggleFullscreen(e){return this.toggleFullscreenHandlers.push(e),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==e)}}onClientReady(e){return this.clientReadyHandlers.push(e),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==e)}}handleWindowMessage(e){var n;const i=e.data;if(!(!i||i.source!=="siyuan-slidev-client"))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const s=this.pendingMessages.shift();s&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(s,"*")}for(const s of this.clientReadyHandlers)s();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const s of this.slideChangedHandlers)s(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const s of this.blockClickedHandlers)s(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const s=i.payload.blockId||i.payload.clickedBlockId||"";for(const o of this.openInEditorHandlers)o(s,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const s=i.payload.blockId||i.payload.url||"",o={peekType:i.payload.peekType,target:s,title:i.payload.title};for(const l of this.openPeekDrawerHandlers)l(o)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const s of this.toggleFullscreenHandlers)s();break}}}const ka={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},Pf=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,Of=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,zf=`<script setup lang="ts">
import { useSlots } from 'vue'

const slots = useSlots()
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-2 grid-rows-2 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
    </div>
  </div>
</template>
`,Nf=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slidev-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,Ff=`${ko}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function Hf(t){var s;const e=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=i.exec(t))!==null;){const o=(s=n[1])==null?void 0:s.trim();o&&!e.includes(o)&&e.push(o)}return e}class jf{constructor(e){kt(this,"workspacePath");kt(this,"slidesFileName");kt(this,"cliBridge",new qo);const i=Df();!(e!=null&&e.workspacePath)||e.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=i:this.workspacePath=e.workspacePath,this.slidesFileName=(e==null?void 0:e.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(e="default"){const i={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return e&&e!=="default"&&(i.dependencies[`@slidev/theme-${e}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(e){return this.cliBridge.buildStandardSlidevMarkdown(e)}async scaffold(e,i){const n=this.buildSlidesMarkdown(e),s=this.generatePackageJson(e.config.theme),o=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,r=xo(o),a=xo(l),c=Hf(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const $ of c){const B=ka[$]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${$}
// #endregion snippet
`;d.set($,B)}e.slides.some($=>{var B;return((B=$.frontmatter)==null?void 0:B.layout)==="cols-header"})&&d.set("layouts/cols-header.vue",Pf),e.slides.some($=>{var B;return((B=$.frontmatter)==null?void 0:B.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",Of),e.slides.some($=>{var B;return((B=$.frontmatter)==null?void 0:B.layout)==="clover"})&&d.set("layouts/clover.vue",zf),d.set("setup/root.ts",Nf),d.set("styles/index.css",Ff);const h=_e("fs"),f=_e("path");let v=!1;const k=f!=null&&f.dirname?f.dirname(r):"",x=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-slidev-pro");if(h&&f&&x)try{h.existsSync(k)||h.mkdirSync(k,{recursive:!0}),h.writeFileSync(a,s,"utf-8"),h.writeFileSync(r,n,"utf-8");for(const[$,B]of d.entries()){const L=f.join(k,$),T=f.dirname(L);h.existsSync(T)||h.mkdirSync(T,{recursive:!0}),h.existsSync(L)||h.writeFileSync(L,B,"utf-8")}v=!0}catch{}if(!v&&i)try{const $=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),B=typeof Blob<"u"?new Blob([s],{type:"application/json;charset=utf-8"}):Buffer.from(s,"utf-8");await i(l,!1,B),await i(o,!1,$);for(const[L,T]of d.entries()){const w=`${this.workspacePath}/${L}`,W=typeof Blob<"u"?new Blob([T],{type:"text/plain;charset=utf-8"}):Buffer.from(T,"utf-8");await i(w,!1,W).catch(()=>{})}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:l}}catch($){return{success:!1,slidesPath:o,physicalSlidesPath:r,packageJsonPath:l,error:String($)}}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:l}}}class Wf{constructor(){kt(this,"mode","web-sandbox");kt(this,"webBridge");kt(this,"cliBridge");kt(this,"nativeBridge");kt(this,"processManager");kt(this,"scaffolder");kt(this,"envDetector");this.webBridge=new Zo,this.cliBridge=new qo,this.nativeBridge=new Lf,this.processManager=new Rf,this.scaffolder=new jf,this.envDetector=new Go}getMode(){return this.mode}setMode(e){this.mode=e}async startProMode(e,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const s=await this.scaffolder.scaffold(e,i);if(!s.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${s.error}`};const o=s.physicalSlidesPath||s.slidesPath,l=await this.processManager.startServer(o);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const Uf={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Vf={key:0},qf={key:1},Kf={key:2},Gf={key:3},Zf={key:4},Yf={key:5},Jf={key:6},Xf={key:7},Qf={key:8},tp={key:9},ep={key:10},ip={key:11},np={key:12},sp={key:13},op={key:14},rp={key:15},lp={key:16},ap={key:17},cp={key:18},dp={key:19},up={key:20},fp={key:21},pp={key:22},hp={key:23},mp={key:24},gp={key:25},vp={key:26},bp={key:27},yp={key:28},kp={key:29},wp={key:30},xp={key:31},Sp={key:32},_p={key:33},Cp={key:34},$p={key:35},Ip={key:36},Ap={key:37},Tp={key:38},Bp={key:39},Ep={key:40},Mp={key:41},Dp={key:42},Lp={key:43},Rp={key:44},Pp={key:45},Op={key:46},zp={key:47},Np={key:48},Fp={key:49},Hp={key:50},jp={key:51},Wp={key:52},Up={key:53},Vp={key:54},qp={key:55},Kp={key:56},Gp={key:57},Zp={key:58},Yp={key:59},Jp={key:60},Xp={key:61},Qp={key:62},th={key:63},eh={key:64},ih={key:65},nh={key:66},sh=Ce({__name:"SlidevIcon",props:{name:{}},setup(t){return(e,i)=>(st(),ot("svg",Uf,[t.name==="fullscreen"||t.name==="maximize"?(st(),ot("g",Vf,[...i[0]||(i[0]=[p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("polyline",{points:"9 21 3 21 3 15"},null,-1),p("polyline",{points:"21 15 21 21 15 21"},null,-1),p("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):t.name==="minimize"?(st(),ot("g",qf,[...i[1]||(i[1]=[p("polyline",{points:"4 14 10 14 10 20"},null,-1),p("polyline",{points:"20 10 14 10 14 4"},null,-1),p("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),p("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):t.name==="close"||t.name==="x"?(st(),ot("g",Kf,[...i[2]||(i[2]=[p("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),p("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):t.name==="edit"?(st(),ot("g",Gf,[...i[3]||(i[3]=[p("path",{d:"M12 20h9"},null,-1),p("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):t.name==="eye"?(st(),ot("g",Zf,[...i[4]||(i[4]=[p("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),p("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):t.name==="external-link"||t.name==="window"?(st(),ot("g",Yf,[...i[5]||(i[5]=[p("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):t.name==="arrow-left"?(st(),ot("g",Jf,[...i[6]||(i[6]=[p("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),p("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):t.name==="arrow-right"?(st(),ot("g",Xf,[...i[7]||(i[7]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),p("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):t.name==="plus"?(st(),ot("g",Qf,[...i[8]||(i[8]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="minus"?(st(),ot("g",tp,[...i[9]||(i[9]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="split-preview"?(st(),ot("g",ep,[...i[10]||(i[10]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),p("path",{d:"M12 3v18"},null,-1)])])):t.name==="import"?(st(),ot("g",ip,[...i[11]||(i[11]=[p("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),p("polyline",{points:"7 9 12 14 17 9"},null,-1),p("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):t.name==="presenter"?(st(),ot("g",np,[...i[12]||(i[12]=[p("path",{d:"M2 3h20"},null,-1),p("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),p("path",{d:"m7 21 5-5 5 5"},null,-1)])])):t.name==="video"?(st(),ot("g",sp,[...i[13]||(i[13]=[p("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),p("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):t.name==="step"?(st(),ot("g",op,[...i[14]||(i[14]=[p("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):t.name==="motion"?(st(),ot("g",rp,[...i[15]||(i[15]=[p("path",{d:"M5 12h14"},null,-1),p("path",{d:"m12 5 7 7-7 7"},null,-1),p("path",{d:"M5 6h4"},null,-1),p("path",{d:"M5 18h4"},null,-1)])])):t.name==="columns"?(st(),ot("g",lp,[...i[16]||(i[16]=[p("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),p("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):t.name==="code"?(st(),ot("g",ap,[...i[17]||(i[17]=[p("polyline",{points:"16 18 22 12 16 6"},null,-1),p("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):t.name==="insert-above"?(st(),ot("g",cp,[...i[18]||(i[18]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),p("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),p("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):t.name==="insert-below"?(st(),ot("g",dp,[...i[19]||(i[19]=[p("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),p("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),p("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="broom"?(st(),ot("g",up,[...i[20]||(i[20]=[p("path",{d:"m18 15-6-6"},null,-1),p("path",{d:"M4 20h16"},null,-1),p("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):t.name==="trash"?(st(),ot("g",fp,[...i[21]||(i[21]=[p("path",{d:"M3 6h18"},null,-1),p("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),p("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):t.name==="ai"||t.name==="sparkles"?(st(),ot("g",pp,[...i[22]||(i[22]=[p("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):t.name==="palette"?(st(),ot("g",hp,[...i[23]||(i[23]=[ve('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-57969535></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-57969535></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-57969535></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-57969535></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-57969535></path>',5)])])):t.name==="ratio"?(st(),ot("g",mp,[...i[24]||(i[24]=[p("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):t.name==="transition"?(st(),ot("g",gp,[...i[25]||(i[25]=[p("path",{d:"M8 3 4 7l4 4"},null,-1),p("path",{d:"M4 7h16"},null,-1),p("path",{d:"m16 21 4-4-4-4"},null,-1),p("path",{d:"M20 17H4"},null,-1)])])):t.name==="export-html"?(st(),ot("g",vp,[...i[26]||(i[26]=[p("polyline",{points:"16 16 12 12 8 16"},null,-1),p("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),p("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):t.name==="export-pdf"?(st(),ot("g",bp,[...i[27]||(i[27]=[p("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),p("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),p("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):t.name==="pin"?(st(),ot("g",yp,[...i[28]||(i[28]=[p("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),p("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):t.name==="refresh"?(st(),ot("g",kp,[...i[29]||(i[29]=[p("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),p("path",{d:"M21 3v5h-5"},null,-1),p("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),p("path",{d:"M8 16H3v5"},null,-1)])])):t.name==="alert"||t.name==="warning"?(st(),ot("g",wp,[...i[30]||(i[30]=[p("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),p("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),p("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):t.name==="outline"?(st(),ot("g",xp,[...i[31]||(i[31]=[p("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),p("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),p("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):t.name==="chevron-left"?(st(),ot("g",Sp,[...i[32]||(i[32]=[p("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):t.name==="chevron-right"?(st(),ot("g",_p,[...i[33]||(i[33]=[p("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):t.name==="copy"?(st(),ot("g",Cp,[...i[34]||(i[34]=[p("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),p("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):t.name==="image"?(st(),ot("g",$p,[...i[35]||(i[35]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),p("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),p("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):t.name==="search"?(st(),ot("g",Ip,[...i[36]||(i[36]=[p("circle",{cx:"11",cy:"11",r:"7"},null,-1),p("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):t.name==="settings"||t.name==="gear"?(st(),ot("g",Ap,[...i[37]||(i[37]=[p("circle",{cx:"12",cy:"12",r:"3"},null,-1),p("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):t.name==="notes"||t.name==="file-text"?(st(),ot("g",Tp,[...i[38]||(i[38]=[ve('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-57969535></path><polyline points="14 2 14 8 20 8" data-v-57969535></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-57969535></line><line x1="16" y1="17" x2="8" y2="17" data-v-57969535></line><line x1="10" y1="9" x2="8" y2="9" data-v-57969535></line>',5)])])):t.name==="focus"||t.name==="target"?(st(),ot("g",Bp,[...i[39]||(i[39]=[p("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),p("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),p("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):t.name==="layout-cover"||t.name==="cover"?(st(),ot("g",Ep,[...i[40]||(i[40]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),p("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),p("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):t.name==="layout-default"||t.name==="default"?(st(),ot("g",Mp,[...i[41]||(i[41]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-57969535></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-57969535></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-57969535></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-57969535></line>',5)])])):t.name==="layout-two-cols"||t.name==="two-cols"?(st(),ot("g",Dp,[...i[42]||(i[42]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-57969535></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-57969535></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-57969535></line><line x1="5" y1="15" x2="8" y2="15" data-v-57969535></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-57969535></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-57969535></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-57969535></line>',8)])])):t.name==="layout-two-cols-header"||t.name==="two-cols-header"?(st(),ot("g",Lp,[...i[43]||(i[43]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-57969535></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-57969535></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-57969535></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-57969535></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-57969535></line>',7)])])):t.name==="layout-cols-header"||t.name==="cols-header"||t.name==="layout-three-cols-header"||t.name==="three-cols-header"?(st(),ot("g",Rp,[...i[44]||(i[44]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-57969535></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-57969535></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-57969535></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-57969535></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-57969535></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-57969535></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-57969535></line>',10)])])):t.name==="layout-clover"||t.name==="clover"?(st(),ot("g",Pp,[...i[45]||(i[45]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="7" x2="13" y2="7" data-v-57969535></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-57969535></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-57969535></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-57969535></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-57969535></line>',8)])])):t.name==="layout-image-right"||t.name==="image-right"?(st(),ot("g",Op,[...i[46]||(i[46]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="12" y1="4" x2="12" y2="20" data-v-57969535></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-57969535></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-57969535></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-57969535></line><circle cx="15.5" cy="8.5" r="1.2" data-v-57969535></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-57969535></polyline>',7)])])):t.name==="layout-image-left"||t.name==="image-left"?(st(),ot("g",zp,[...i[47]||(i[47]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="12" y1="4" x2="12" y2="20" data-v-57969535></line><circle cx="6" cy="8.5" r="1.2" data-v-57969535></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-57969535></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-57969535></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-57969535></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-57969535></line>',7)])])):t.name==="layout-center"||t.name==="center"?(st(),ot("g",Np,[...i[48]||(i[48]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),p("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="layout-fact"||t.name==="fact"?(st(),ot("g",Fp,[...i[49]||(i[49]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><circle cx="8" cy="9" r="1.5" data-v-57969535></circle><line x1="14" y1="8" x2="9" y2="14" data-v-57969535></line><circle cx="15" cy="13" r="1.5" data-v-57969535></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-57969535></line>',5)])])):t.name==="layout-intro"||t.name==="intro"?(st(),ot("g",Hp,[...i[50]||(i[50]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><circle cx="7.5" cy="9.5" r="2" data-v-57969535></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-57969535></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-57969535></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-57969535></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-57969535></line>',6)])])):t.name==="layout-quote"||t.name==="quote"?(st(),ot("g",jp,[...i[51]||(i[51]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-57969535></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-57969535></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-57969535></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-57969535></line>',5)])])):t.name==="desktop"||t.name==="monitor"?(st(),ot("g",Wp,[...i[52]||(i[52]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):t.name==="mobile"||t.name==="smartphone"||t.name==="phone"?(st(),ot("g",Up,[...i[53]||(i[53]=[p("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),p("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):t.name==="type"||t.name==="heading"?(st(),ot("g",Vp,[...i[54]||(i[54]=[p("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),p("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),p("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):t.name==="reset"||t.name==="undo"?(st(),ot("g",qp,[...i[55]||(i[55]=[p("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),p("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):t.name==="repeat"||t.name==="loop"?(st(),ot("g",Kp,[...i[56]||(i[56]=[p("path",{d:"m17 1 4 4-4 4"},null,-1),p("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),p("path",{d:"m7 23-4-4 4-4"},null,-1),p("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):t.name==="volume-x"||t.name==="mute"?(st(),ot("g",Gp,[...i[57]||(i[57]=[p("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),p("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),p("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):t.name==="sliders"||t.name==="controls"?(st(),ot("g",Zp,[...i[58]||(i[58]=[ve('<line x1="4" y1="21" x2="4" y2="14" data-v-57969535></line><line x1="4" y1="10" x2="4" y2="3" data-v-57969535></line><line x1="12" y1="21" x2="12" y2="12" data-v-57969535></line><line x1="12" y1="8" x2="12" y2="3" data-v-57969535></line><line x1="20" y1="21" x2="20" y2="16" data-v-57969535></line><line x1="20" y1="12" x2="20" y2="3" data-v-57969535></line><line x1="1" y1="14" x2="7" y2="14" data-v-57969535></line><line x1="9" y1="8" x2="15" y2="8" data-v-57969535></line><line x1="17" y1="16" x2="23" y2="16" data-v-57969535></line>',9)])])):t.name==="package"||t.name==="zip"||t.name==="archive"?(st(),ot("g",Yp,[...i[59]||(i[59]=[p("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),p("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),p("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),p("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):t.name==="folder"?(st(),ot("g",Jp,[...i[60]||(i[60]=[p("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):t.name==="rocket"?(st(),ot("g",Xp,[...i[61]||(i[61]=[p("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),p("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),p("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),p("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):t.name==="wand"||t.name==="magic"?(st(),ot("g",Qp,[...i[62]||(i[62]=[p("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),p("path",{d:"m13 8 2 2"},null,-1),p("path",{d:"m3 21 9-9"},null,-1)])])):t.name==="image-left"?(st(),ot("g",th,[...i[63]||(i[63]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-57969535></rect><line x1="13" y1="8" x2="19" y2="8" data-v-57969535></line><line x1="13" y1="12" x2="19" y2="12" data-v-57969535></line><line x1="13" y1="16" x2="17" y2="16" data-v-57969535></line>',5)])])):t.name==="image-right"?(st(),ot("g",eh,[...i[64]||(i[64]=[ve('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-57969535></rect><line x1="5" y1="8" x2="11" y2="8" data-v-57969535></line><line x1="5" y1="12" x2="11" y2="12" data-v-57969535></line><line x1="5" y1="16" x2="9" y2="16" data-v-57969535></line>',5)])])):t.name==="help"||t.name==="question"||t.name==="info"?(st(),ot("g",ih,[...i[65]||(i[65]=[p("circle",{cx:"12",cy:"12",r:"10"},null,-1),p("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),p("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(st(),ot("g",nh,[...i[66]||(i[66]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Ne=(t,e)=>{const i=t.__vccOpts||t;for(const[n,s]of e)i[n]=s;return i},ft=Ne(sh,[["__scopeId","data-v-57969535"]]);function Jt(t,e){var s;if(typeof document>"u"||!t)return;const i=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${i}"]`);!n||n.length===0||n.forEach(o=>{for(const[l,r]of Object.entries(e))r!=null&&r!==""?o.setAttribute(l,String(r)):o.removeAttribute(l)})}function oh(t){if(typeof document>"u")return;const e=`.protyle-wysiwyg [${gt}], .protyle-wysiwyg [${Gt}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,i=document.querySelectorAll(e);!i||i.length===0||i.forEach(n=>{const s=n.getAttribute("data-node-id");if(!s){n.removeAttribute(gt),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(Gt),n.removeAttribute("custom-slidev-role");return}const o=t.get(s),l=(o==null?void 0:o[gt])||(o==null?void 0:o["custom-slidev-layout"])||"",r=n.getAttribute(gt)||n.getAttribute("custom-slidev-layout");r&&r!==l&&(l?n.setAttribute(gt,l):(n.removeAttribute(gt),n.removeAttribute("custom-slidev-layout")));const a=(o==null?void 0:o[Gt])||(o==null?void 0:o["custom-slidev-role"])||"",c=n.getAttribute(Gt)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(Gt,a):(n.removeAttribute(Gt),n.removeAttribute("custom-slidev-role")))})}const rh={class:"spm-layout-picker"},lh={class:"spm-layout-picker__grid"},ah=["title","onClick"],ch={class:"spm-layout-icon"},dh={class:"spm-layout-label"},uh=Ce({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(t,{emit:e}){const i=t,n=e,s=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"4 项超级块 2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function o(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function l(r){n("update:modelValue",r),n("change",r)}return(r,a)=>(st(),ot("div",rh,[a[0]||(a[0]=p("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),p("div",lh,[(st(),ot(qt,null,ke(s,c=>p("div",{key:c.name,class:It(["spm-layout-item",{active:o(c.name)}]),title:c.desc,onClick:d=>l(c.name)},[p("div",ch,[dt(ft,{name:"layout-"+c.name},null,8,["name"])]),p("span",dh,St(c.label),1)],10,ah)),64))])]))}}),wa=Ne(uh,[["__scopeId","data-v-1964d02c"]]),fh={key:0,class:"spm-transition-selector__header"},ph={class:"spm-transition-list"},hh=["onClick"],mh={class:"spm-transition-meta"},gh={class:"spm-transition-label"},vh={class:"spm-transition-name"},bh={class:"spm-transition-preview-box"},yh=Ce({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(t,{emit:e}){const i=e,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function s(o){i("update:modelValue",o),i("change",o)}return(o,l)=>(st(),ot("div",{class:It(["spm-transition-selector",{"spm-transition-selector--no-header":t.hideHeader}])},[t.hideHeader?Pt("",!0):(st(),ot("div",fh,St(t.title||"转场动效"),1)),p("div",ph,[(st(),ot(qt,null,ke(n,r=>p("div",{key:r.name,class:It(["spm-transition-item",{active:t.modelValue===r.name}]),onClick:a=>s(r.name)},[p("div",mh,[p("span",gh,St(r.label),1),p("span",vh,"("+St(r.name)+")",1)]),p("div",bh,[p("div",{class:It(["spm-anim-cube","anim-"+r.name])},null,2)])],10,hh)),64))])],2))}}),Yo=Ne(yh,[["__scopeId","data-v-8597e99e"]]),kh={class:"spm-divider-popover"},wh={class:"spm-divider-popover__title"},xh={class:"spm-form-item"},Sh={class:"spm-popover-footer"},_h={class:"spm-save-hint"},Ch=Ce({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(t,{emit:e}){var b,u,h;const i=t,n=e,s=bt(((b=i.initialAttrs)==null?void 0:b[gt])||"default"),o=bt(((u=i.initialAttrs)==null?void 0:u[ee])||"slide-left"),l=bt(((h=i.initialAttrs)==null?void 0:h[Ut])||""),r=bt("");Oi(()=>i.initialAttrs,f=>{s.value=(f==null?void 0:f[gt])||"default",o.value=(f==null?void 0:f[ee])||"slide-left",l.value=(f==null?void 0:f[Ut])||""},{deep:!0});async function a(f,v){if(i.blockId){r.value="正在同步...",Et.setBlockAttrOverride(i.blockId,{[f]:v}),Jt(i.blockId,{[f]:v});try{await Dt(i.blockId,{[f]:v}),r.value="已同步至块属性",n("updated",{[f]:v}),setTimeout(()=>{r.value=""},1500)}catch{r.value="同步失败"}}}function c(f){a(gt,f)}function d(f){a(ee,f)}function m(){a(Ut,l.value.trim())}return(f,v)=>(st(),ot("div",kh,[p("div",wh,[v[4]||(v[4]=p("span",null,"幻灯片页面设置",-1)),p("button",{class:"spm-close-btn",onClick:v[0]||(v[0]=k=>n("close"))},"✕")]),dt(wa,{modelValue:s.value,"onUpdate:modelValue":v[1]||(v[1]=k=>s.value=k),onChange:c},null,8,["modelValue"]),dt(Yo,{modelValue:o.value,"onUpdate:modelValue":v[2]||(v[2]=k=>o.value=k),onChange:d},null,8,["modelValue"]),p("div",xh,[v[5]||(v[5]=p("label",{class:"spm-form-label"},"页面背景",-1)),Be(p("input",{"onUpdate:modelValue":v[3]||(v[3]=k=>l.value=k),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:m},null,544),[[xs,l.value]])]),p("div",Sh,[p("span",_h,St(r.value),1)])]))}}),$h=Ne(Ch,[["__scopeId","data-v-e4871368"]]),Ih={class:"spm-slide-inspector"},Ah={class:"spm-inspector-header"},Th={class:"spm-inspector-list"},Bh=["onClick"],Eh={class:"spm-card-top"},Mh={class:"spm-card-badge"},Dh={class:"spm-card-layout"},Lh=["onClick"],Rh={class:"spm-card-preview"},Ph={key:0,class:"spm-card-notes",title:"演讲备忘录"},Oh={class:"spm-inspector-modal-content"},zh=Ce({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(t,{emit:e}){const i=e,n=bt(null);function s(c){n.value=c}function o(c){const d={};return c.frontmatter.layout&&(d[gt]=c.frontmatter.layout),c.frontmatter.transition&&(d[ee]=c.frontmatter.transition),c.frontmatter.background&&(d[Ut]=c.frontmatter.background),c.notes&&(d[Ki]=c.notes),d}function l(c){n.value&&(c[gt]&&(n.value.frontmatter.layout=c[gt]),c[ee]&&(n.value.frontmatter.transition=c[ee]),c[Ut]&&(n.value.frontmatter.background=c[Ut]),c[Ki]&&(n.value.notes=c[Ki]),i("refresh"))}function r(c){i("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const d=c.blocks[0],m=d.content||d.rawMarkdown||"";return m.slice(0,40)+(m.length>40?"...":"")}return(c,d)=>(st(),ot("div",Ih,[p("div",Ah,[p("span",null,"幻灯片大纲 ("+St(t.slides.length)+" 页)",1)]),p("div",Th,[(st(!0),ot(qt,null,ke(t.slides,m=>(st(),ot("div",{key:m.pageIndex,class:It(["spm-card",{active:t.currentActivePage===m.pageIndex}]),onClick:b=>r(m.pageIndex)},[p("div",Eh,[p("span",Mh,"P"+St(m.pageIndex),1),p("span",Dh,St(m.frontmatter.layout||"default"),1),p("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Me(b=>s(m),["stop"])},[dt(ft,{name:"settings"})],8,Lh)]),p("div",Rh,St(a(m)),1),m.notes?(st(),ot("div",Ph,[dt(ft,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),p("span",null,St(m.notes),1)])):Pt("",!0)],10,Bh))),128))]),n.value?(st(),ot("div",{key:0,class:"spm-inspector-modal-mask",onClick:d[1]||(d[1]=Me(m=>n.value=null,["self"]))},[p("div",Oh,[dt($h,{"block-id":n.value.startBlockId,"initial-attrs":o(n.value),onClose:d[0]||(d[0]=m=>n.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Pt("",!0)]))}}),Nh=Ne(zh,[["__scopeId","data-v-68b25edd"]]),Fh={class:"spm-immersion-header"},Hh={class:"spm-immersion-header__left"},jh={class:"spm-immersion-title"},Wh={class:"spm-immersion-header__center"},Uh={class:"spm-immersion-header__actions"},Vh=["aria-label"],qh={class:"spm-immersion-body"},Kh=Ce({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(t,{emit:e}){const i=t,n=e;function s(){n("update:visible",!1),n("close")}function o(){i.closeOnClickMask&&s()}function l(){n("update:isMaximized",!i.isMaximized),n("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),s())}return(a,c)=>Be((st(),ot("div",{class:It(["spm-immersion-container",{"is-maximized":t.isMaximized}]),onKeydown:Me(r,["stop"])},[p("div",{class:"spm-immersion-mask",onClick:o}),p("div",{class:It(["spm-immersion-drawer",{"is-maximized":t.isMaximized}])},[p("div",Fh,[p("div",Hh,[Zn(a.$slots,"header-left",{},()=>[p("span",jh,St(t.title),1)])]),p("div",Wh,[Zn(a.$slots,"header-center",{},void 0)]),p("div",Uh,[Zn(a.$slots,"header-actions",{},void 0),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":t.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[dt(ft,{name:t.isMaximized?"minimize":"maximize"},null,8,["name"])],8,Vh),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:s},[dt(ft,{name:"close"})])])]),p("div",qh,[Zn(a.$slots,"default",{},void 0)])],2)],34)),[[aa,t.visible]])}}),Gh=Ne(Kh,[["__scopeId","data-v-3f1665db"]]),Zh={class:"spm-protyle-drawer"},Yh={class:"spm-protyle-drawer__subbar"},Jh={class:"spm-protyle-drawer__nav"},Xh=["title"],Qh={class:"spm-protyle-drawer__actions"},tm=["aria-label"],em=["aria-label"],im=Ce({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(t,{emit:e}){const i=e,n=t,s=bt(n.blockId),o=bt(n.title||""),l=bt(!1),r=bt(!0),a=bt(!1),c=bt(""),d=hi,m=bt([]),b=bt(null);let u=null;Oi(()=>n.blockId,w=>{w&&w!==s.value&&(s.value=w,o.value=n.title||"",m.value=[],f(w))}),Fn(()=>{s.value&&f(s.value)}),zo(()=>{v()});async function h(w){try{const W=await tn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${w}' LIMIT 1`);if(Array.isArray(W)&&W.length>0){const V=W[0];c.value=V.root_id||"";const q=V.id===V.root_id||V.type==="d";a.value=q,r.value=!q,!o.value&&V.content&&(o.value=V.content.trim().slice(0,30));return}}catch(W){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",W)}a.value=!1,r.value=!0}async function f(w,W){if(!b.value||!w)return;v(),await h(w),typeof W=="boolean"&&(r.value=!a.value&&W);let V,q;r.value&&!a.value?(V=["cb-get-all","cb-get-hl","cb-get-focus"],q={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(V=["cb-get-context","cb-get-hl"],q={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{u=new ht.Protyle(n.plugin.app,b.value,{blockId:w,action:V,render:q}),!l.value&&u&&typeof u.disable=="function"&&u.disable()}catch(X){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",X)}}function v(){if(u){try{typeof u.destroy=="function"&&u.destroy()}catch(w){console.warn("[ProtylePeekDrawer] Error destroying protyle:",w)}u=null}b.value&&(b.value.innerHTML="")}function k(){a.value||(r.value=!r.value,f(s.value,r.value))}function x(){l.value=!l.value,u&&(l.value?(typeof u.enable=="function"&&u.enable(),typeof u.focus=="function"&&u.focus()):typeof u.disable=="function"&&u.disable())}function $(){if(s.value)try{ht.openWindow({doc:{id:s.value},alwaysOnTop:!0})}catch(w){console.warn("[ProtylePeekDrawer] openWindow failed:",w)}}function B(){var V;if(!s.value)return;const w=Os(),W=ua(w.webServeUrl,s.value,{focus:!a.value});if(typeof window<"u"){const q=_e("electron");(V=q==null?void 0:q.shell)!=null&&V.openExternal?q.shell.openExternal(W).catch(()=>{window.open(W,"_blank")}):window.open(W,"_blank")}i("external-jump",W)}function L(){if(m.value.length>0){const w=m.value.pop();w&&(s.value=w.blockId,o.value=w.title,r.value=w.isFocusMode,a.value=w.isDoc,f(w.blockId,w.isFocusMode))}}function T(w){const W=w.target;if(!W)return;const V=W.closest('[data-type="block-ref"]');if(V){const X=V.getAttribute("data-id");if(X&&X!==s.value){w.preventDefault(),w.stopPropagation(),m.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:a.value}),s.value=X,o.value=V.innerText.trim()||X,f(X);return}}const q=W.closest("a");if(q&&q.href&&q.href.startsWith("siyuan://blocks/")){w.preventDefault(),w.stopPropagation();const X=q.href.replace("siyuan://blocks/","").split("?")[0];X&&X!==s.value&&(m.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:a.value}),s.value=X,o.value=q.innerText.trim()||X,f(X))}}return(w,W)=>(st(),ot("div",Zh,[p("div",Yh,[p("div",Jh,[m.value.length>0?(st(),ot("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:L},[dt(ft,{name:"arrow-left"}),W[0]||(W[0]=p("span",null,"返回",-1))])):Pt("",!0),p("span",{class:It(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},St(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),p("span",{class:"spm-protyle-id",title:o.value||s.value},St(o.value||s.value),9,Xh)]),p("div",Qh,[a.value?Pt("",!0):(st(),ot("button",{key:0,class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:k},[dt(ft,{name:r.value?"focus":"file-text"},null,8,["name"]),p("span",null,St(r.value?"块聚焦":"展开全文"),1)],10,tm)),p("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:x},[dt(ft,{name:l.value?"edit":"eye"},null,8,["name"]),p("span",null,St(l.value?"编辑中":"只读"),1)],10,em),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:$},[dt(ft,{name:"window"}),W[1]||(W[1]=p("span",null,"独立窗口",-1))]),yt(d).enableWebServeJump?(st(),ot("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:B},[dt(ft,{name:"external-link"}),W[2]||(W[2]=p("span",null,"外跳",-1))])):Pt("",!0)])]),p("div",{ref_key:"mountEl",ref:b,class:It(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:T},null,2)]))}}),nm=Ne(im,[["__scopeId","data-v-7e586ef3"]]),sm=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,om=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function Nr(t){let e=t||"";try{e=decodeURIComponent(e)}catch{}e=e.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(e);if(i)return`/assets/${i[1]}`;const n=/(?:^|\/)data\/plugins\/(.+)$/i.exec(e);return n?`/plugins/${n[1]}`:null}function xa(t){const e=(t||"").replace(/^file:\/\//i,"");let i=e;try{i=decodeURIComponent(e)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const n=i.indexOf("/");return n>=0?i.slice(n):i}function rm(t){const e=t.split(/[/?#]/)[0];return!e||om.test(e)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(e)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(e)}function lm(t){const e=t.indexOf("#"),i=e>=0?t.slice(e):"",n=e>=0?t.slice(0,e):t,s=n.indexOf("?"),o=s>=0?n.slice(0,s):n,l=s>=0?n.slice(s+1):"";if(!/^\/?assets\/.+\.html?$/i.test(o))return t;const r=new URLSearchParams(l);return r.get("iframe")==="true"||r.get("download")==="true"?t:(r.set("iframe","true"),`${o}?${r.toString()}${i}`)}function Sa(t){const e=am(t);return e.external||!e.url?e:{url:lm(e.url),external:!1}}function am(t){const e=(t||"").trim();if(!e)return{url:"",external:!1};if(/^https?:\/\//i.test(e))return{url:e,external:!1};if(e.startsWith("//"))return{url:`https:${e}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(e))return{url:e,external:!1};if(el(e))return{url:`/${il(e)}`,external:!1};if(/^file:/i.test(e)){const n=Nr(xa(e));return n?{url:n,external:!1}:{url:e,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(e)||e.startsWith("\\\\")){const n=Nr(e);return n?{url:n,external:!1}:{url:e,external:!0}}return sm.test(e)?{url:e,external:!0}:rm(e)?{url:`https://${e}`,external:!1}:{url:`/${e.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const cm={class:"spm-webview-drawer"},dm={class:"spm-webview-toolbar"},um={class:"spm-webview-toolbar__nav"},fm=["disabled"],pm=["disabled"],hm=["aria-label"],mm={class:"spm-webview-toolbar__address"},gm=["aria-label"],vm={class:"spm-webview-toolbar__actions"},bm=["aria-label"],ym={class:"spm-zoom-controller"},km=["disabled"],wm=["disabled"],xm={key:1,class:"spm-webview-fallback"},Sm=["src"],_m={key:2,class:"spm-load-error"},Cm={class:"spm-load-error__code"},$m={class:"spm-load-error__code-num"},Im={class:"spm-load-error__url"},Am={class:"spm-load-error__hint"},Tm={class:"spm-load-error__actions"},Fr="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",_a="siyuan-slidev-peek-view-mode";let Ca="desktop";function Bm(){if(typeof window<"u"&&window.localStorage)try{const t=window.localStorage.getItem(_a);if(t==="mobile"||t==="desktop")return t}catch{}return Ca}function Em(t){if(Ca=t,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(_a,t)}catch{}}function Mm(t){switch((t||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const Dm=Ce({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(t,{emit:e}){const i=e,n=t,s=bt(ba()&&!Mf()),o=bt(n.url),l=bt(n.url),r=bt(!1),a=bt(null),c=bt(!1),d=bt(!1),m=bt(1),b=bt(!1),u=bt(Bm());let h=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const f=_t(()=>u.value==="mobile"?Fr:h||void 0),v=bt(null),k=bt(null);let x=null,$=null,B=null;Oi(()=>n.url,H=>{H&&H!==o.value&&(o.value=H,l.value=H,u.value==="mobile"&&V(!1),v.value&&typeof v.value.loadURL=="function"&&v.value.loadURL(H))}),Oi(()=>n.visible,H=>{if(H)M(),u.value==="mobile"&&V(!1);else if(v.value)try{typeof v.value.stop=="function"&&v.value.stop()}catch{}}),Fn(()=>{L(),k.value&&typeof ResizeObserver<"u"&&(x=new ResizeObserver(()=>{const H=v.value;if(H&&typeof H.invalidate=="function")try{H.invalidate()}catch{}}),x.observe(k.value)),$=H=>{var ut;const at=H.message||((ut=H.error)==null?void 0:ut.message);if(typeof at=="string"&&at.includes("Invalid guestInstanceId"))return H.preventDefault(),H.stopImmediatePropagation(),!0},window.addEventListener("error",$,!0),B=H=>{const at=H.reason,ut=typeof at=="string"?at:at==null?void 0:at.message;typeof ut=="string"&&ut.includes("Invalid guestInstanceId")&&H.preventDefault()},window.addEventListener("unhandledrejection",B)}),zo(()=>{if(T(),x&&(x.disconnect(),x=null),$&&(window.removeEventListener("error",$,!0),$=null),B&&(window.removeEventListener("unhandledrejection",B),B=null),v.value)try{typeof v.value.stop=="function"&&v.value.stop()}catch{}});function L(){const H=v.value;H&&(H.addEventListener("dom-ready",w),H.addEventListener("did-start-loading",q),H.addEventListener("did-stop-loading",z),H.addEventListener("did-navigate",y),H.addEventListener("did-navigate-in-page",D),H.addEventListener("new-window",U),H.addEventListener("did-fail-load",X),H.addEventListener("did-fail-provisional-load",X))}function T(){const H=v.value;if(H)try{H.removeEventListener("dom-ready",w),H.removeEventListener("did-start-loading",q),H.removeEventListener("did-stop-loading",z),H.removeEventListener("did-navigate",y),H.removeEventListener("did-navigate-in-page",D),H.removeEventListener("new-window",U),H.removeEventListener("did-fail-load",X),H.removeEventListener("did-fail-provisional-load",X)}catch{}}function w(){const H=v.value;if(H&&typeof H.getUserAgent=="function"&&!h)try{const at=H.getUserAgent();at&&!at.includes("iPhone")&&(h=at)}catch{}u.value==="mobile"&&V(!1),M(),E()}function W(){const H=u.value==="mobile"?"desktop":"mobile";u.value=H,Em(H),V(!0)}function V(H=!1){const at=v.value;if(!at)return;const ut=u.value==="mobile"?Fr:h;if(typeof at.setUserAgent=="function"&&ut)try{at.setUserAgent(ut)}catch(_){console.warn("[WebviewPeekDrawer] setUserAgent error:",_)}if(H&&typeof at.reload=="function")try{at.reload()}catch(_){console.warn("[WebviewPeekDrawer] reload error:",_)}}function q(){r.value=!0,a.value=null}function X(H){if(H&&H.isMainFrame===!1||H&&Number(H.errorCode)===-3)return;const at=String((H==null?void 0:H.errorDescription)||"ERR_FAILED");a.value={errorCode:Number((H==null?void 0:H.errorCode)??0),description:at,validatedURL:String((H==null?void 0:H.validatedURL)||o.value),hint:Mm(at)},r.value=!1}function C(){a.value=null,tt()}function z(){if(r.value=!1,E(),v.value&&typeof v.value.getURL=="function"){const H=v.value.getURL();H&&H!=="about:blank"&&(o.value=H,l.value=H)}}function y(H){H!=null&&H.url&&(o.value=H.url,l.value=H.url),E()}function D(H){H!=null&&H.url&&(o.value=H.url,l.value=H.url),E()}function U(H){H&&H.url&&(H.preventDefault(),v.value&&typeof v.value.loadURL=="function"&&v.value.loadURL(H.url))}function E(){const H=v.value;H&&(typeof H.canGoBack=="function"&&(c.value=H.canGoBack()),typeof H.canGoForward=="function"&&(d.value=H.canGoForward()))}function P(){v.value&&typeof v.value.goBack=="function"&&v.value.goBack()}function j(){v.value&&typeof v.value.goForward=="function"&&v.value.goForward()}function tt(){v.value&&typeof v.value.reload=="function"&&v.value.reload()}function A(){const H=Sa(l.value);if(H.url){if(H.external){o.value=H.url,lt();return}o.value=H.url,l.value=H.url,v.value&&typeof v.value.loadURL=="function"&&v.value.loadURL(H.url)}}function M(){const H=v.value;if(H&&typeof H.setZoomFactor=="function")try{H.setZoomFactor(m.value)}catch(at){console.warn("[WebviewPeekDrawer] setZoomFactor error:",at)}}function Y(){m.value=Math.min(2.5,Math.round((m.value+.1)*10)/10),M()}function J(){m.value=Math.max(.5,Math.round((m.value-.1)*10)/10),M()}function et(){m.value=1,M()}function it(H){H.preventDefault(),H.deltaY<0?Y():H.deltaY>0&&J()}async function pt(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(o.value),b.value=!0,setTimeout(()=>{b.value=!1},2e3)}catch(H){console.warn("Copy url failed:",H)}}function lt(){var at;const H=o.value;if(typeof window<"u"){const ut=_e("electron");(at=ut==null?void 0:ut.shell)!=null&&at.openExternal?ut.shell.openExternal(H).catch(()=>{window.open(H,"_blank")}):window.open(H,"_blank")}i("external-jump",H)}return(H,at)=>{const ut=Hd("webview");return st(),ot("div",cm,[p("div",dm,[p("div",um,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"后退",onClick:P},[dt(ft,{name:"arrow-left"})],8,fm),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!d.value,"aria-label":"前进",onClick:j},[dt(ft,{name:"arrow-right"})],8,pm),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":r.value?"正在加载...":"刷新页面",onClick:tt},[dt(ft,{name:"refresh"})],8,hm)]),p("div",mm,[Be(p("input",{"onUpdate:modelValue":at[0]||(at[0]=_=>l.value=_),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:nf(A,["enter"])},null,544),[[xs,l.value]]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":b.value?"已复制地址！":"复制网址",onClick:pt},[dt(ft,{name:"copy"})],8,gm)]),p("div",vm,[p("button",{class:It(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":u.value==="mobile"}]),"aria-label":u.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:W},[dt(ft,{name:u.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,bm),p("div",ym,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:m.value<=.5,onClick:J},[dt(ft,{name:"minus"})],8,km),p("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:et},St(Math.round(m.value*100))+"% ",1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:m.value>=2.5,onClick:Y},[dt(ft,{name:"plus"})],8,wm)]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:lt},[dt(ft,{name:"external-link"}),at[1]||(at[1]=p("span",null,"外跳",-1))])])]),p("div",{ref_key:"containerEl",ref:k,class:It(["spm-webview-body",{"is-mobile":u.value==="mobile"}]),onWheel:Me(it,["ctrl"])},[p("div",{class:It(["spm-webview-viewport",{"is-mobile":u.value==="mobile"}])},[s.value?(st(),De(ut,{key:0,ref_key:"webviewRef",ref:v,class:"spm-webview-frame",src:o.value,useragent:f.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(st(),ot("div",xm,[p("iframe",{class:"spm-webview-fallback-frame",src:o.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Sm),p("div",{class:"spm-fallback-bar"},[at[2]||(at[2]=p("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),p("button",{class:"spm-icon-btn is-primary",onClick:lt}," 在新标签页中打开 ↗ ")])])),a.value?(st(),ot("div",_m,[dt(ft,{name:"alert",class:"spm-load-error__icon"}),at[5]||(at[5]=p("div",{class:"spm-load-error__title"},"页面加载失败",-1)),p("div",Cm,[$e(St(a.value.description)+" ",1),p("span",$m,"("+St(a.value.errorCode)+")",1)]),p("div",Im,St(a.value.validatedURL),1),p("p",Am,St(a.value.hint),1),p("div",Tm,[p("button",{class:"spm-icon-btn","aria-label":"重试",onClick:C},[dt(ft,{name:"refresh"}),at[3]||(at[3]=p("span",null,"重试",-1))]),p("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:lt},[dt(ft,{name:"external-link"}),at[4]||(at[4]=p("span",null,"用系统浏览器打开 ↗",-1))])])])):Pt("",!0)],2)],34)])}}}),Lm=Ne(Dm,[["__scopeId","data-v-6c82ca68"]]);class Rm{constructor(){kt(this,"timers",new Map)}debounce(e,i,n=150){this.cancel(e);const s=setTimeout(()=>{this.timers.delete(e),i()},n);this.timers.set(e,s)}cancel(e){this.timers.has(e)&&(clearTimeout(this.timers.get(e)),this.timers.delete(e))}cancelAll(){for(const e of this.timers.values())clearTimeout(e);this.timers.clear()}hasPending(e){return this.timers.has(e)}}class Pm{constructor(e){kt(this,"blockToPageMap",new Map);kt(this,"debounceCtrl",new Rm);kt(this,"activeBlockId","");kt(this,"activePageIndex",1);kt(this,"currentDocId","");kt(this,"bridge",null);e&&(this.bridge=e)}setBridge(e){this.bridge=e}setDocId(e){this.currentDocId=e}updateSlidesIndex(e){this.blockToPageMap.clear();for(const i of e){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const n of i.blocks)this.blockToPageMap.set(n.id,i.pageIndex)}}getPageByBlockId(e){return this.blockToPageMap.get(e)??null}onCursorFocusBlock(e){if(!e||e===this.activeBlockId)return;this.activeBlockId=e;let i=this.getPageByBlockId(e);!i&&(e===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(e))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(e){this.activeBlockId=e;const i=this.getPageByBlockId(e);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function zi(t,e){var o,l;if(!t||typeof document>"u")return!1;const i=(o=globalThis.CSS)!=null&&o.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!n){if(e)try{return ht.openTab({app:e,doc:{id:t,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(r){console.warn("[SelectionMirror] openTab fallback failed:",r)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const s=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=s},1200),!0}function Om(t){if(!t)return"";const e=t.split(`
`).map(l=>l.trim()).filter(Boolean);if(e.length===0)return"";if(!e.some(l=>/^#{1,6}\s+/.test(l)))return e.map(l=>re(l)).join("<br/>");const n=[];let s=[];const o=()=>{if(s.length>0){const l=s.map(r=>re(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${l}</p>`),s=[]}};for(const l of e){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){o();const a=r[1].length,c=r[2].trim();n.push(`<h${a} class="slide-list-item-title">${re(c)}</h${a}>`)}else s.push(l)}return o(),n.join(`
`)}function zm(t){if(t.length===0)return"";const e=[],i=t[0],n=i.match(/^(#{1,6})\s+(.*)$/);if(n){const s=n[1].length,o=n[2].trim();e.push(`<h${s} class="slide-list-item-title">${re(o)}</h${s}>`)}else e.push(`<p class="slide-list-item-title">${re(i)}</p>`);if(t.length>1){const s=t.slice(1);let o=[];const l=()=>{if(o.length>0){const r=o.map(a=>re(a)).join("<br/>");e.push(`<p class="slide-list-item-desc">${r}</p>`),o=[]}};for(const r of s){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,d=a[2].trim();e.push(`<h${c} class="slide-list-item-title">${re(d)}</h${c}>`)}else o.push(r)}l()}return e.join(`
`)+(e.length>0?`
`:"")}function $a(t,e,i){var b,u,h,f;const n=t.split(`
`);if(!n.some(v=>/^(\s*)([-*+]|\d+\.)\s+/.test(v)))return null;const o=[],l=[];let r=!1;for(let v=0;v<n.length;v++){const k=n[v];if(!k.trim())continue;const x=k.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(x){const T=x[1].length,w=Math.floor(T/2);l.push({type:"task",level:w,checked:x[2].toLowerCase()==="x",text:x[3],media:[]});continue}const $=k.match(/^(\s*)[-*+]\s+(.*)$/);if($){const T=$[1].length,w=Math.floor(T/2);l.push({type:"unordered",level:w,text:$[2],media:[]});continue}const B=k.match(/^(\s*)\d+\.\s+(.*)$/);if(B){l.length===0&&(r=!0);const T=B[1].length,w=Math.floor(T/2);l.push({type:"ordered",level:w,text:B[2],media:[]});continue}const L=k.trim();if(!(!L||/^\{:.*?\}$/.test(L)))if(l.length>0){const T=L.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(T){const V=/\.gif(?:\?|$)/i.test(T[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${ce(T[1])}" src="${T[2]}" class="${V}" /></div>`);continue}if(L.match(/^<img\b[\s\S]*?\/?>$/i)){const W=L.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${W}</div>`);continue}if(/<video\b/i.test(L)){let W=L;if(!/<\/video>/i.test(W))for(;v+1<n.length&&!/<\/video>/i.test(W);)v++,W+=" "+n[v].trim();const V=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slidev-autoplay"])==="true"||/autoplay/i.test(W),q=((u=i==null?void 0:i.attributes)==null?void 0:u["custom-slidev-loop"])==="true"||/loop/i.test(W),X=((h=i==null?void 0:i.attributes)==null?void 0:h["custom-slidev-muted"])==="true"||V||/muted/i.test(W),C=((f=i==null?void 0:i.attributes)==null?void 0:f["custom-slidev-controls"])==="false",z=W.match(/\bsrc=["']([^"']+)["']/i),y=z?z[1]:"",D=['class="slide-video-player"'];C||D.push("controls"),V&&(D.push("autoplay"),D.push("playsinline")),q&&D.push("loop"),X&&D.push("muted"),D.push('preload="metadata"'),y&&D.push(`src="${y}"`);const U=W.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let E=U?U[1].trim():"";!E&&y&&(E=`<source src="${y}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${V?"true":"false"}" data-muted="${X?"true":"false"}"><video ${D.join(" ")}>${E}</video></div>`);continue}l[l.length-1].text+=`
`+L}else o.push(L)}if(l.length===0)return null;const a=r?"ol":"ul",c=(e==null?void 0:e.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),d=l.map(v=>{const k=Om(v.text),x=v.media&&v.media.length>0?`
${v.media.join(`
`)}`:"",$=v.level||0,B=$>0?` style="margin-left:${($*1.25).toFixed(2)}em;${v.type==="unordered"?`list-style-type:${$%2===1?"circle":"square"} !important;`:""}"`:"",L=$>0?" slide-list-item--nested":"";if(v.type==="task"){const w=v.checked?' checked=""':"";return`<li class="pdf-task-item${L}"${B}><label><input type="checkbox" disabled=""${w}/> <span>${k}</span></label>${x}</li>`}return`<li${L?` class="${L.trim()}"`:""}${B}>${k}${x}</li>`}).join(`
`);return`${zm(o)}<${a} class="${c}">
${d}
</${a}>`}function Nm(t,e,i){const n=(e==null?void 0:e.containerClassName)||"pdf-block",s=t.split(/\r?\n/),o=[];let l=[];for(let c=0;c<s.length;c++){const d=s[c],m=d.trim();if(/^#{1,6}\s+/.test(m)){l.length>0&&(o.push(l.join(`
`)),l=[]),o.push(m);continue}if(!m){l.length>0&&(o.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(m)){l.length>0&&(o.push(l.join(`
`)),l=[]),o.push(m);continue}if(/<video\b/i.test(m)){l.length>0&&(o.push(l.join(`
`)),l=[]);let b=m;if(!/<\/video>/i.test(b))for(;c+1<s.length&&!/<\/video>/i.test(b);)c++,b+=`
`+s[c];o.push(b);continue}l.push(d)}l.length>0&&o.push(l.join(`
`));let r=!0;return o.map(c=>{var h,f,v,k;const d=c.trim();if(!d)return"";const m=d.match(/^(#{1,6})\s+(.*)$/);if(m){r=!1;const x=m[1].length;return`<h${x} class="slide-list-item-title">${re(m[2].trim())}</h${x}>`}const b=d.match(/^!\[(.*?)\]\((.*?)\)$/);if(b){const x=/\.gif(?:\?|$)/i.test(b[2]),$=(e==null?void 0:e.imageClassName)||(x?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${ce(b[1])}" src="${b[2]}" class="${$}" /></div>`}if(/<video\b/i.test(d)){const x=((h=i==null?void 0:i.attributes)==null?void 0:h["custom-slidev-autoplay"])==="true"||/autoplay/i.test(d),$=((f=i==null?void 0:i.attributes)==null?void 0:f["custom-slidev-loop"])==="true"||/loop/i.test(d),B=((v=i==null?void 0:i.attributes)==null?void 0:v["custom-slidev-muted"])==="true"||x||/muted/i.test(d),L=((k=i==null?void 0:i.attributes)==null?void 0:k["custom-slidev-controls"])==="false",T=d.match(/\bsrc=["']([^"']+)["']/i),w=T?T[1]:"",W=['class="slide-video-player"'];L||W.push("controls"),x&&W.push("autoplay playsinline"),$&&W.push("loop"),B&&W.push("muted"),W.push('preload="metadata"'),w&&W.push(`src="${w}"`);const V=d.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let q=V?V[1].trim():"";return!q&&w&&(q=`<source src="${w}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${x?"true":"false"}" data-muted="${B?"true":"false"}"><video ${W.join(" ")}>${q}</video></div>`}const u=$a(d,e,i);if(u)return r=!1,u;if(r){r=!1;const x=d.split(/\r?\n/).map(T=>T.trim()).filter(Boolean);if(x.length===1)return`<p class="slide-list-item-title">${re(x[0])}</p>`;const $=x[0],L=x.slice(1).map(T=>re(T)).join("<br/>");return`<p class="slide-list-item-title">${re($)}</p>
<p class="slide-list-item-desc">${L}</p>`}return`<p class="slide-list-item-desc">${re(d)}</p>`}).filter(Boolean).join(`
`)}function Qs(t){if(!t)return!1;if(t.type==="h"||t.type==="NodeHeading")return!0;const e=(t.rawMarkdown||t.content||"").trim();return/^#{1,6}\s+/.test(e)}function Fm(t,e){var r,a,c,d,m,b,u,h;const i=((r=t.frontmatter)==null?void 0:r.layout)||"default",s=(t.blocks||[]).filter(f=>f.slot!=="slot-divider-right"),l=i==="cover"?null:s.find(Qs);if(i==="two-cols"){const f=s.some(X=>X.slot==="right");let v=[],k=[];if(f)v=s.filter(X=>X.slot!=="right"),k=s.filter(X=>X.slot==="right");else{const X=Math.ceil(s.length/2);v=s.slice(0,X),k=s.slice(X)}const x=X=>{const C=X.filter(z=>!!(z.rawMarkdown||z.content||"").trim());if(C.length>0){const z=C[0],y=(z.rawMarkdown||z.content||"").trim();(Fi(z)||/^(?:[-*+]|\d+\.)\s+/.test(y))&&(z.rawMarkdown=xn(z.rawMarkdown||z.content||""),z.content=z.rawMarkdown)}};x(v),x(k);const $=v.map(X=>ui(X,e)).join(`
`),B=k.map(X=>ui(X,e)).join(`
`),L="pdf-two-cols-wrapper layout-two-cols-grid",T=(a=t.frontmatter)!=null&&a.layoutClass?` ${t.frontmatter.layoutClass}`:"",w="pdf-col pdf-col--left",W="pdf-col pdf-col--right",q=`style="grid-template-columns: ${Js((c=t.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${L}${T}" ${q}>
        <div class="${w}">${$}</div>
        <div class="${W}">${B}</div>
      </div>
    `}if(i==="clover"||Tn(i)){const f=i==="clover";let v=[];const k=s.filter(D=>D.slot==="header");if(k.length>0)v=k;else if(s.length>0){const D=s.find(U=>U.type==="h"&&(!U.slot||U.slot==="default"));D&&(v=[D])}const x=s.filter(D=>!v.includes(D));let $=2;if(f)$=4;else if(i==="three-cols-header")$=3;else if(i==="two-cols-header")$=2;else{let D=0;for(const U of x){const E=(U.slot||"").match(/^col-(\d+)$/i);E&&(D=Math.max(D,parseInt(E[1],10)))}if(D>=2)$=D;else if((d=t.frontmatter)!=null&&d.layoutRatio){const U=t.frontmatter.layoutRatio.trim();if(U.includes(":")){const E=U.split(":").map(P=>parseFloat(P.trim())).filter(P=>!isNaN(P)&&P>0);E.length>=2&&($=E.length)}else{const E=U.split(/\s+/).filter(Boolean);E.length>=2&&($=E.length)}}else x.length===1&&x[0].children&&x[0].children.length>=2&&($=Math.min(6,x[0].children.length))}const B=va(x,$),L=x.some(D=>D.slot&&/^(?:col-\d+|left|right)$/i.test(D.slot)),T=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||Tn(i)&&L,w=D=>{const U=D.filter(P=>!!(P.rawMarkdown||P.content||"").trim());if(T&&U.length>0){const P=U[0],j=(P.rawMarkdown||P.content||"").trim();(Fi(P)||/^(?:[-*+]|\d+\.)\s+/.test(j))&&(P.rawMarkdown=xn(P.rawMarkdown||P.content||""),P.content=P.rawMarkdown),P.isColFirst=!0}const E=T?U.find(Qs):null;return U.map(P=>ui(P,{...e,extraClassName:P===E?"slidev-col-first-heading-block":""})).join(`
`)},W=v.find(Qs),V=v.map(D=>ui(D,{...e,extraClassName:D===W?"slidev-page-first-heading-block":""})).join(`
`),q=f?"repeat(2, minmax(0, 1fr))":Js((m=t.frontmatter)==null?void 0:m.layoutRatio,$),X=f?`style="grid-template-columns: ${q}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${q};"`,C=[f?"layout-clover-container":"layout-cols-header-container",$===2?"layout-two-cols-header-container":"",$===3?"layout-three-cols-header-container":"",`layout-${i}-container`,T?"has-superblock-cols":""].filter(Boolean).join(" "),z=[f?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",$===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",$===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",T?"has-superblock-cols":""].filter(Boolean).join(" "),y=B.map((D,U)=>{const E=U+1;return`<div class="${["pdf-col",$===2&&E===1?"pdf-col--left":"",$===2&&E===2?"pdf-col--right":"",`pdf-col--${E}`,`col-${E}`].filter(Boolean).join(" ")}">${w(D)}</div>`}).join(`
`);return`
      <div class="${C}">
        <div class="layout-header-section">${V}</div>
        <div class="${z}" ${X}>
          ${y}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const f=i==="image-right",v=s.map(T=>ui(T,e)).join(`
`),k=((b=t.frontmatter)==null?void 0:b.image)||((u=t.frontmatter)==null?void 0:u.background)||"",x=`<div class="pdf-image-col" style="background-image:url('${ce(k)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${ce(k)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,$=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${v}</div>`,B=f?`${$}
${x}`:`${x}
${$}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${Js((h=t.frontmatter)==null?void 0:h.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${B}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${s.map(v=>ui(v,e)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${s.map(v=>ui(v,e)).join(`
`)}</div>`:s.map(f=>ui(f,{...e,extraClassName:f===l?"slidev-page-first-heading-block":""})).join(`
`)}function ce(t){return t?t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Hm(t){if(!t||t.trim()===""||t.trim()==="all")return"all";const e=new Set,i=t.split("|");for(const n of i){const s=n.trim();if(s==="all")return"all";if(s.includes("-")){const[o,l]=s.split("-"),r=parseInt(o,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)e.add(c)}else{const o=parseInt(s,10);isNaN(o)||e.add(o)}}return e}const jm=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function re(t){if(!t)return"";const e=ha(t),i=[],n=e.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(o,l)=>{const r=l.toLowerCase();if(!jm.has(r)||/on\w+\s*=|javascript:/i.test(o))return o;if(r==="v-mark"){const a=o.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return o.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(o),`%%SAFE_HTML_${i.length-1}%%`});let s=ce(n);return s=s.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(o,l,r,a,c,d,m)=>{const u=(r??a??c??d??m??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${u}</a>`}),s=s.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(o,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),s=s.replace(/\[(.*?)\]\((.*?)\)/g,(o,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),s=s.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(o,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${r}</a>`),s=s.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),s=s.replace(/\*(.*?)\*/g,"<em>$1</em>"),s=s.replace(/~~(.*?)~~/g,"<del>$1</del>"),s=s.replace(/`([^`]+)`/g,"<code>$1</code>"),s=s.replace(/%%SAFE_HTML_(\d+)%%/g,(o,l)=>{const r=parseInt(l,10);return i[r]||""}),s}function Wm(t,e="pdf-table"){if(t.length<2)return"";const i=t.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=i[0];let s=[],o=1;t.length>=2&&i[1].every(a=>/^:?-+:?$/.test(a))&&(s=i[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),o=2);const l=`<thead><tr>${n.map((a,c)=>`<th${s[c]?` style="text-align: ${s[c]}"`:""}>${re(a)}</th>`).join("")}</tr></thead>`,r=i.slice(o).map(a=>`<tr>${a.map((c,d)=>`<td${s[d]?` style="text-align: ${s[d]}"`:""}>${re(c)}</td>`).join("")}</tr>`).join("");return`<table class="${e}">${l}<tbody>${r}</tbody></table>`}function to(t){return String(t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Hr(t,e="ts"){if(!t)return"";if(t.trim().startsWith("//"))return`<span class="token-comment">${to(t)}</span>`;const i=[];function n(o,l){return i.push(`<span class="${o}">${to(l)}</span>`),`__TOK_${i.length-1}__`}let s=t.replace(/(['"`])(.*?)\1/g,(o,l,r)=>n("token-string",`${l}${r}${l}`));return s=s.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,o=>n("token-keyword",o)),s=s.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,o=>n("token-type",o)),s=s.replace(/\b(\d+)\b/g,o=>n("token-number",o)),s=to(s),s=s.replace(/__TOK_(\d+)__/g,(o,l)=>i[parseInt(l,10)]||""),s}function Um(t,e){if(!t)return null;const i=t.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let n=(i.title||"").trim(),s=i.level?parseInt(i.level,10):0;if(!n){const o=t.blocks||[];for(const l of o){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){s||(s=a[1].length),n=a[2].trim();break}}}return n?((!s||isNaN(s))&&(s=1),{pageIndex:t.pageIndex||e,title:n,level:s}):null}function Vm(t,e=1,i={}){const n=i.minDepth!==void 0?Number(i.minDepth):1,s=i.maxDepth!==void 0?Number(i.maxDepth):1/0,o=[];Array.isArray(t)&&t.forEach((c,d)=>{const m=Um(c,d+1);m&&o.push(m)});const l=[];let r=null;for(const c of o){const d={...c,active:c.pageIndex===e,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),r=d):r?(d.active&&(r.hasActiveChild=!0),r.children.push(d)):l.push(d)}function a(c,d=1){if(d>s)return[];const m=[];for(const b of c){const u=a(b.children,d+1);d>=n?m.push({...b,children:u}):m.push(...u)}return m}return a(l,1)}function qm(t,e=1,i={}){const n=Vm(t,e,i),s=i.columns?Number(i.columns):1,o=s>1?` style="column-count: ${s};"`:"",l=i.textSm?" text-sm":"";function r(c,d=1){if(!c||c.length===0)return"";const m=`slidev-toc-list slidev-toc-list-level-${d}`,b=c.map(u=>{const h=u.active?" slidev-toc-item-active":u.hasActiveChild?" slidev-toc-item-parent-active":"",f=u.children&&u.children.length>0?r(u.children,d+1):"";let v=re(u.title);return v.includes("LaTeX")&&(v=v.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${h}" data-page="${u.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${v}</span>
          </a>
          ${f}
        </li>
      `}).join("");return`<ol class="${m}">${b}</ol>`}const a=r(n,1);return`<div class="slidev-toc${l}"${o}>${a}</div>`}function ui(t,e){var $,B,L,T,w,W,V,q,X,C;let i="",n="",s="";const o=[];($=t.motion)!=null&&$.preset&&t.motion.preset!=="none"&&(i=` slidev-motion-${t.motion.preset.toLowerCase()}`,typeof t.motion.duration=="number"&&t.motion.duration>0&&o.push(`--motion-duration:${t.motion.duration}ms`),typeof t.motion.delay=="number"&&t.motion.delay>0&&o.push(`--motion-delay:${t.motion.delay}ms`));const l=((B=t.attributes)==null?void 0:B.style)||"";l&&(o.push(l),s=" slide-styled-block"),o.length>0&&(n=` style="${ce(o.join(";"))}"`);const r=(e==null?void 0:e.containerClassName)||"pdf-block",a=e!=null&&e.extraClassName?` ${e.extraClassName}`:"",c=`${r}${i}${s}${a}`,d=(t.rawMarkdown||t.content||"").trim();if(!d)return`<div class="${c}"${n}></div>`;if(d.includes('class="slidev-block-ref"')||d.includes('class="slidev-ref-tag"'))return`<div class="${c}"${n}>${d}</div>`;if(d.startsWith("$$")&&d.endsWith("$$")){const z=d.slice(2,-2).trim();return`<div class="${c} katex-display-container"${n}><div class="katex-display font-math"><em>${ce(z)}</em></div></div>`}const m=d.match(/^(#{1,6})\s+(.*)$/);if(m){const z=m[1].length,y=re(m[2]),U=!!(t.isColFirst||t.type==="i"&&((L=e==null?void 0:e.extraClassName)!=null&&L.includes("slidev-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><h${z}${U}>${y}</h${z}></div>`}if(d.startsWith(":::")){const z=d.split(`
`),D=z[0].replace(/^:::\s*/,"").trim()||"info",U=z.slice(1,z[z.length-1].startsWith(":::")?-1:void 0).join(`
`),E=(e==null?void 0:e.calloutClassName)||"pdf-callout";return`<div class="${c}"${n}><div class="${E} ${E}--${D}"><div class="${E}-title">${D.toUpperCase()}</div><div class="${E}-body">${re(U)}</div></div></div>`}if(d.startsWith("<<<")){const D=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((j,tt)=>`<span class="code-line shiki-focus"><span class="line-no">${tt+1}</span><span class="line-content">${Hr(j,"ts")}</span></span>`).join(`
`),U=(e==null?void 0:e.codeClassName)||"pdf-code shiki-container",E=((T=t.attrs)==null?void 0:T["custom-slidev-max-height"])||t.maxHeight||"",P=E?` style="max-height:${ce(E)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${U}"${P}><span class="lang-badge">TS</span><code>${D}</code></pre></div>`}if(d.startsWith("<style")||d.startsWith("<!-- Inline style -->")||d.startsWith(`<!--
Notes`))return"";if(d.startsWith("```")){const z=d.split(`
`),y=z[0].slice(3).trim(),D=y.match(/^([^\s{\[]+)/),U=D?D[1]:"",E=y.match(/\[([^\]]+)\]/),P=E?E[1]:"",j=y.includes("twoslash"),tt=t.shikiLines||((w=y.match(/\{([^}]+)\}/))==null?void 0:w[1])||"",A=Hm(tt),M=z.length>2?z[z.length-1]==="```"?z.slice(1,-1):z.slice(1):[d.slice(3).replace(/```$/,"")],Y=(e==null?void 0:e.codeClassName)||"pdf-code shiki-container",J=P?`${Y} has-filename`:Y,et=A!=="all",it=M.map((ut,_)=>{const O=_+1,N=A==="all"||A.has(O)?"code-line shiki-focus":et?"code-line shiki-dimmed":"code-line";let S=(e==null?void 0:e.highlight)===!0?Hr(ut,U):ce(ut);return j&&ut.includes("doubled.value = 2")?(S=S.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${N}"><span class="line-no">${O}</span><span class="line-content">${S}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${N}"><span class="line-no">${O}</span><span class="line-content">${S}</span></span>`}).join(`
`),pt=U?`<span class="lang-badge">${ce(U)}</span>`:"",lt=P?`<span class="code-filename">${ce(P)}</span>`:"",H=((W=t.attrs)==null?void 0:W["custom-slidev-max-height"])||t.maxHeight||"",at=H?` style="max-height:${ce(H)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${J}"${at}>${lt}${pt}<code>${it}</code></pre></div>`}if(d.includes("|")&&d.split(`
`).filter(z=>z.trim().startsWith("|")).length>=2){const z=d.split(`
`).filter(D=>D.trim().startsWith("|")),y=Wm(z,e==null?void 0:e.tableClassName);return`<div class="${c}"${n}>${y}</div>`}if(d.startsWith("> ")){const z=(e==null?void 0:e.quoteClassName)||"pdf-quote";return`<div class="${c}"${n}><blockquote class="${z}"><p>${re(d.slice(2))}</p></blockquote></div>`}const b=/<video\b/i.test(d)||t.type==="video"||t.type==="NodeVideo",u=/^(\s*)([-*+]|\d+\.)\s+/m.test(d),h=/(?:^|\n)\s*#{1,6}\s+/.test(d);if(b&&!u&&!h&&!d.includes(`
`)){const z=((V=t.attributes)==null?void 0:V["custom-slidev-autoplay"])==="true"||/autoplay/i.test(d),y=((q=t.attributes)==null?void 0:q["custom-slidev-loop"])==="true"||/loop/i.test(d),D=((X=t.attributes)==null?void 0:X["custom-slidev-muted"])==="true"||z||/muted/i.test(d),U=((C=t.attributes)==null?void 0:C["custom-slidev-controls"])==="false",E=d.match(/\bsrc=["']([^"']+)["']/i),P=E?E[1]:"",j=['class="slide-video-player"'];U||j.push("controls"),z&&(j.push("autoplay"),j.push("playsinline")),y&&j.push("loop"),D&&j.push("muted"),j.push('preload="metadata"'),P&&j.push(`src="${P}"`);const tt=d.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let A=tt?tt[1].trim():"";return!A&&P&&(A=`<source src="${P}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${c} ${c}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${z?"true":"false"}" data-muted="${D?"true":"false"}"${n}><video ${j.join(" ")}>${A}</video></div>`}const f=d.match(/^!\[(.*?)\]\((.*?)\)$/);if(f){const z=(e==null?void 0:e.imageClassName)||"pdf-image slide-media-img";return`<div class="${c} ${c}--image slide-media-block slide-media-container"${n}><img alt="${ce(f[1])}" src="${f[2]}" class="${z}" /></div>`}const v=$a(d,e,t);if(v)return`<div class="${c} pdf-list-item"${n}>${v}</div>`;if(/<(?:Toc|toc)\b/i.test(d)&&!d.startsWith("```")){const z=d.match(/minDepth=["']?(\d+)["']?/i),y=d.match(/maxDepth=["']?(\d+)["']?/i),D=d.match(/columns=["']?(\d+)["']?/i),U=(e==null?void 0:e.allSlides)||[];return`<div class="${c}"${n}>${qm(U,(e==null?void 0:e.currentPageIndex)||1,{minDepth:z?parseInt(z[1],10):1,maxDepth:y?parseInt(y[1],10):1/0,columns:D?parseInt(D[1],10):1,textSm:d.includes("text-sm")})}</div>`}if(d.includes(`
`)||h){const z=Nm(d,e,t);if(z)return`<div class="${c}"${n}>${z}</div>`}const x=!!t.isColFirst?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><p${x}>${re(d)}</p></div>`}function Km(t){return`
    ${_n(t)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slidev-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slidev-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slidev-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slidev-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slidev-padding-y, 32px)) !important;
      padding-left: var(--slidev-padding-x, 48px) !important;
      padding-right: var(--slidev-padding-x, 48px) !important;
      padding-bottom: var(--slidev-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slidev-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slidev-mask-body-container--has-mask:first-child,
    .slide-content > .slidev-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slidev-padding-y, 32px)) !important;
      padding-top: var(--slidev-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slidev-padding-x: 0px !important;
      --slidev-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slidev-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slidev-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slidev-mask-layer--solid .slidev-mask-overlay,
    .slidev-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slidev-mask-layer--solid .slidev-mask-overlay,
    [data-theme="dark"] .slidev-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slidev-mask-layer--blur .slidev-mask-overlay,
    .slidev-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slidev-mask-layer--blur .slidev-mask-overlay,
    [data-theme="dark"] .slidev-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slidev-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slidev-mask-layer--down .slidev-mask-divider-line,
    .slidev-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slidev-mask-layer--right .slidev-mask-divider-line,
    .slidev-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }`}function Gm(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr) {
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: 2, breakpoints: [50, 100] };
        }
        const clean = ratioStr.trim();
        if (!clean) return { steps: 2, breakpoints: [50, 100] };
        const parts = clean.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
        if (parts.length === 0) return { steps: 2, breakpoints: [50, 100] };
        if (parts.length === 1) {
          const val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        const isMonotonic = parts.every((val, idx) => idx === 0 || val > parts[idx - 1]);
        const maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(p => p > 10))) {
          const bps = parts.map(p => Math.min(100, Math.round(p * 100) / 100));
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        const totalWeight = parts.reduce((acc, cur) => acc + cur, 0);
        if (totalWeight <= 0) return { steps: 2, breakpoints: [50, 100] };
        let accumulated = 0;
        const bps = [];
        for (let i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex - 1);
      }

      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        if (maskDir === "down" || maskDir === "right") {
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: maskDir,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          currentMaskStep = 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slidev-mask-layer slidev-mask-layer--" + currentMaskConfig.style + " slidev-mask-layer--" + currentMaskConfig.direction;
          const overlay = document.createElement("div");
          overlay.className = "slidev-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slidev-mask-divider-line";
          divider.style.opacity = "0";
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slidev-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slidev-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slidev-mask-body-container slidev-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slidev-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slidev-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slidev-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slidev-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slidev-viewport") || cur.classList.contains("slidev-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slidev-lightbox-img, .slidev-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function Ia(t,e){const i="Slidev 演示文稿";let n=t.slides;const s=JSON.stringify(n),o=JSON.stringify(t.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${ce(i)}</title>
  <style>
${Km(e==null?void 0:e.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(t.docId)},
      slides: ${s},
      config: ${o}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${t.config.normalizeHeadingSizes?"true":"false"}">
    <div class="slide-viewport slidev-theme-${t.config.theme||"default"}" id="viewport" data-slidev-theme="${t.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${Gm()}
  <\/script>
</body>
</html>`}function Aa(t,e){if(typeof document>"u")return!1;const i=new Blob([e],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(i),s=document.createElement("a");return s.href=n,s.download=t.endsWith(".html")?t:`${t}.html`,document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(n),!0}function Zm(t){switch(t){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function Ym(t){const e=Zm(t==null?void 0:t.pageRatio);return`
    ${_n(t==null?void 0:t.customInlineStyles)}

    @page {
      ${e}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slidev-mask-layer,
      .slidev-mask-overlay,
      .slidev-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
      }
      .slidev-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function Jm(t,e){const i="Slidev 演示讲义",n="16:9",s="light",o=t.slides.map((l,r)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,d=c&&c!=="inherit"?c:t.config.spacing||"normal",m=Fm(l),b=`${r+1} / ${t.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${s} spacing-${d}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${ce(i)}</span>
          ${`<span class="pdf-page-badge">P. ${b}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${m}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${ce(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${ce(i)} - 高保真讲义</title>
  <style>
    ${Ym({pageRatio:n,customInlineStyles:e==null?void 0:e.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${t.config.normalizeHeadingSizes?"true":"false"}">
  ${o}
</body>
</html>`}function Ta(t,e){var s;if(typeof window>"u"||typeof document>"u")return!1;const i=Jm(t,e);try{const o=document.createElement("iframe");o.style.position="fixed",o.style.right="0",o.style.bottom="0",o.style.width="0",o.style.height="0",o.style.border="none",o.style.visibility="hidden",document.body.appendChild(o);const l=(s=o.contentWindow)==null?void 0:s.document;if(l)return l.open(),l.write(i),l.close(),setTimeout(()=>{var r,a;try{(r=o.contentWindow)==null||r.focus(),(a=o.contentWindow)==null||a.print()}finally{setTimeout(()=>{o.remove()},2e3)}},350),!0}catch(o){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",o)}const n=window.open("","_blank");return n?(n.document.write(i),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const Xm={class:"spm-slidev-preview-tab"},Qm={class:"spm-slidev-tab__toolbar"},tg={class:"spm-slidev-tab__nav"},eg=["disabled"],ig={class:"spm-page-badge"},ng=["disabled"],sg=["aria-label"],og=["aria-label"],rg={class:"spm-slidev-tab__tools"},lg=["src"],ag=Ce({__name:"SlidevPreviewTab",setup(t,{expose:e}){const i=ti("plugin"),n=ti("sandboxBridge",new Zo),s=new Pm(n),o=new Wf,l=bt("web-sandbox"),r=bt(3030),a=bt(null),c=bt(!1),d=bt(null),m=bt(1),b=bt(1),u=bt([]),h=bt(!1),f=bt(!1),v=bt(!1),k=bt("siyuan"),x=bt(""),$=bt(""),B=bt(""),L=bt(!1),T=bt(!1),w=bt(""),W=bt("/plugins/siyuan-slidev/slidev-client/index.html");let V=null,q=null,X=null,C=null,z=null,y=null,D=null;Fn(()=>{d.value&&(n.attach(d.value),o.nativeBridge.attach(d.value)),V=n.onSlideChanged((_,O)=>{m.value=_,b.value=O}),q=n.onBlockClicked((_,O)=>{m.value=O,s.setActiveBlockId(_),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide(_,O):zi(_,i==null?void 0:i.app)}),X=n.onOpenInEditor((_,O)=>{m.value=O,s.setActiveBlockId(_),zi(_,i==null?void 0:i.app)}),C=o.nativeBridge.onPageChanged((_,O)=>{m.value=_,b.value=O}),z=n.onOpenPeekDrawer(async _=>{const O=Os();if(_.peekType==="siyuan"&&O.enableWebServeJump){let g=!1;if(D&&D.docId===_.target)g=!0;else if(D&&D.slides&&D.slides.some(N=>{var F;return(F=N.blocks)==null?void 0:F.some(S=>S.id===_.target)}))g=!1;else try{const N=await tn(`SELECT id, root_id, type FROM blocks WHERE id = '${_.target}' LIMIT 1`);N&&N.length>0&&(g=N[0].type==="d"||N[0].id===N[0].root_id)}catch(N){console.warn("[SlidevPreviewTab] detect block type failed:",N)}k.value="web",L.value=!0,$.value=ua(O.webServeUrl,_.target,{focus:!g}),B.value=_.title||`${g?"思源文档":"思源块"}: ${_.target.slice(0,8)}`,f.value=!0,n.freezeKeyboardNav(!0)}else{if(k.value=_.peekType,_.peekType==="siyuan")x.value=_.target,B.value=_.title||`块速览: ${_.target.slice(0,8)}`;else{const g=Sa(_.target);if(g.external){it(_.target);return}L.value=!0,$.value=g.url,B.value=_.title||g.url}f.value=!0,n.freezeKeyboardNav(!0)}}),y=n.onRequestToggleFullscreen(()=>{lt()}),typeof document<"u"&&document.addEventListener("fullscreenchange",pt)}),No(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",pt),z&&z(),y&&y(),V&&V(),q&&q(),X&&X(),C&&C(),n.detach(),s.destroy(),o.destroy()});async function U(){if(l.value==="web-sandbox"){if(!D){ht.showMessage("请先在主编辑区打开演示文档");return}ht.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const _=await o.startProMode(D,oo);if(!_.success){ht.showMessage(`无法启动官方 Pro 模式：${_.error}`);return}l.value="pro-cli",r.value=_.port||3030,W.value=_.url,d.value&&o.nativeBridge.attach(d.value),ht.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else o.stopProMode(),l.value="web-sandbox",W.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&n.attach(d.value),ht.showMessage("已切回内置高保真沙箱")}function E(){T.value=!T.value,T.value?(w.value=(D==null?void 0:D.docId)||"",i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",w.value)):(w.value="",Y(),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader())}let P=0;function j(_){if(f.value||Math.abs(_.deltaY)<Math.abs(_.deltaX)||Math.abs(_.deltaY)<15)return;const O=Date.now();O-P<280||(P=O,_.deltaY>0?A():tt())}function tt(){if(m.value>1){const _=m.value-1;m.value=_,l.value==="pro-cli"?o.nativeBridge.navigateToPage(_):n.navigatePage(_)}}function A(){if(m.value<b.value){const _=m.value+1;m.value=_,l.value==="pro-cli"?o.nativeBridge.navigateToPage(_):n.navigatePage(_)}}function M(_){m.value=_,l.value==="pro-cli"?o.nativeBridge.navigateToPage(_):n.navigatePage(_)}function Y(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slidev:request-compile")}function J(){f.value=!1,n.freezeKeyboardNav(!1)}function et(){J()}function it(_){var F,S;const O=/^file:/i.test(_),g=O||/^[a-zA-Z]:[\\/]/.test(_),N=_e("electron");if(g&&typeof((F=N==null?void 0:N.shell)==null?void 0:F.openPath)=="function"){N.shell.openPath(O?xa(_):_),ht.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((S=N==null?void 0:N.shell)==null?void 0:S.openExternal)=="function"?N.shell.openExternal(_).catch(()=>{typeof window<"u"&&window.open(_,"_blank")}):typeof window<"u"&&window.open(_,"_blank"),ht.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function pt(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function lt(){const _=a.value||d.value;_&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):_.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function H(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function at(){if(!D){ht.showMessage("请先在主编辑区打开幻灯片文档");return}const _=Ia(D);Aa("presentation.html",_)&&ht.showMessage("已开始下载单文件离线 HTML 演示包")}function ut(){if(!D){ht.showMessage("请先在主编辑区打开幻灯片文档");return}Ta(D)&&ht.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return e({updateDocument(_,O){T.value&&w.value&&O&&O!==w.value||(D=_,T.value&&!w.value&&(w.value=_.docId),u.value=_.slides,b.value=_.slides.length,s.setDocId(_.docId),s.updateSlidesIndex(_.slides),l.value==="pro-cli"?o.scaffolder.scaffold(_,oo).catch(()=>{}):n.updateSlides(_.slides,_.config,_.fullMarkdown,_.customThemeCss),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",_.docId))},navigateToBlock(_){s.onCursorFocusBlock(_)},isPinned:T,pinnedDocId:w,engineMode:l,toggleEngineMode:U}),(_,O)=>(st(),ot("div",Xm,[p("div",Qm,[p("div",tg,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:m.value<=1,"aria-label":"上一页",onClick:tt},[dt(ft,{name:"chevron-left"})],8,eg),p("span",ig,St(m.value)+" / "+St(b.value||1),1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:m.value>=b.value,"aria-label":"下一页",onClick:A},[dt(ft,{name:"chevron-right"})],8,ng),p("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":T.value}]),"aria-label":T.value?"已锁定当前文档（点击解除）："+w.value:"点击锁定当前文档（不随主编辑区切换）",onClick:E},[dt(ft,{name:"pin"}),p("span",null,St(T.value?"已锁定":"跟随"),1)],10,sg),p("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:U},[dt(ft,{name:"rocket"}),p("span",null,St(l.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,og)]),p("div",rg,[p("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":h.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:O[0]||(O[0]=g=>h.value=!h.value)},[dt(ft,{name:"outline"})],2),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:H},[dt(ft,{name:"presenter"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:at},[dt(ft,{name:"export-html"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:ut},[dt(ft,{name:"export-pdf"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:Y},[dt(ft,{name:"refresh"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:lt},[dt(ft,{name:"fullscreen"})])])]),p("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container",onWheel:j},[p("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:W.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,lg),dt(Gh,{visible:f.value,"onUpdate:visible":O[1]||(O[1]=g=>f.value=g),"is-maximized":v.value,"onUpdate:isMaximized":O[2]||(O[2]=g=>v.value=g),title:B.value,onClose:J},{default:Ml(()=>[k.value==="siyuan"&&x.value?(st(),De(nm,{key:0,"block-id":x.value,title:B.value,plugin:yt(i),onExternalJump:et},null,8,["block-id","title","plugin"])):Pt("",!0),L.value?Be((st(),De(Lm,{key:1,visible:f.value&&k.value==="web",url:$.value,title:B.value,onExternalJump:et},null,8,["visible","url","title"])),[[aa,k.value==="web"]]):Pt("",!0)]),_:1},8,["visible","is-maximized","title"])],544),h.value&&u.value.length>0?(st(),De(Nh,{key:0,slides:u.value,"current-active-page":m.value,onNavigate:M,onRefresh:Y},null,8,["slides","current-active-page"])):Pt("",!0)]))}}),cg=Ne(ag,[["__scopeId","data-v-c828ed48"]]),dg={class:"spm-section spm-section--page"},ug={class:"spm-section-header"},fg={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},pg={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},hg={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},mg={key:1,class:"spm-card-control"},gg={class:"spm-control-header"},vg={class:"spm-control-title-group"},bg={class:"spm-control-title"},yg={class:"spm-quick-chips"},kg=["onClick"],wg={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},xg=["value"],Sg=["aria-label"],_g={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__w",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},Cg={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},$g={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},Ig={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Ag={class:"spm-card-control"},Tg={class:"spm-control-header"},Bg={class:"spm-control-title-group"},Eg={class:"spm-control-title"},Mg={class:"spm-segmented-group"},Dg={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},Lg={style:{display:"flex","align-items":"center","justify-content":"space-between"}},Rg={class:"b3-tooltips b3-tooltips__w","aria-label":`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},Pg={class:"spm-quick-chips"},Og=["onClick"],zg={class:"b3-tooltips b3-tooltips__n",style:{width:"100%",display:"block"},"aria-label":"输入权重比例（如 1:2:1）或绝对累计百分比断点（如 25:75:100），冒号项数决定点击步数"},Ng=["value"],Fg={style:{display:"flex",gap:"8px","margin-top":"2px"}},Hg={style:{flex:"1"}},jg={class:"spm-segmented-group"},Wg={style:{flex:"1"}},Ug={class:"spm-segmented-group"},Vg={class:"spm-card-control"},qg={class:"spm-control-header"},Kg={class:"spm-control-title-group"},Gg={class:"spm-control-title"},Zg={class:"spm-segmented-group"},Yg={class:"spm-card-control"},Jg={class:"spm-control-header"},Xg={class:"spm-control-title-group"},Qg={class:"spm-control-title"},tv={class:"spm-quick-chips"},ev=["onClick"],iv=["value"],nv={key:2,class:"spm-card-control"},sv={class:"spm-control-header"},ov={class:"spm-control-title-group"},rv={class:"spm-control-title"},lv={class:"spm-quick-chips"},av=["onClick"],cv=["value"],dv={class:"spm-card-control"},uv={class:"spm-control-header"},fv={class:"spm-control-title-group"},pv={class:"spm-control-title"},hv={key:0,class:"spm-note-status-box"},mv=["title"],gv={class:"spm-action-grid",style:{"margin-top":"6px"}},vv={key:1,class:"spm-note-empty-box"},bv={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},yv={class:"spm-action-grid"},kv=["disabled"],wv=["disabled"],xv={class:"spm-card-control"},Sv={class:"spm-action-grid"},_v=Ce({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(t,{emit:e}){const i=t,n=e,s=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],o=_t(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),l=_t(()=>{var f,v;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const u=(i.pageLayoutRatio||"").trim();if(u.includes(":")){const k=u.split(":").filter(Boolean).length;if(k>=2&&k<=6)return k}const h=(i.detectedSbRatio||"").trim();if(h.includes(":")){const k=h.split(":").filter(Boolean).length;if(k>=2&&k<=6)return k}if((f=i.detectedSbInfo)!=null&&f.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((v=i.detectedSbInfo)!=null&&v.slots&&Array.isArray(i.detectedSbInfo.slots)){const k=i.detectedSbInfo.slots.length;if(k>=2&&k<=6)return k}return 2}),r=_t(()=>{const u=l.value;return u===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:u===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:u===5?[{label:"默认 1:1:1:1:1",value:""}]:u===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),a=_t(()=>i.pageLayoutRatio||"");function c(){const u=l.value||2,h=Array(u).fill("1").join(":");n("update:pageLayoutRatio",h),n("resetSuperblockRatio")}const d=_t(()=>{if(!i.pageNotes)return"";const u=i.pageNotes.replace(/[\r\n]+/g," ").trim();return u.length>50?u.slice(0,50)+"...":u}),m=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],b=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(u,h)=>(st(),ot("div",dg,[p("div",ug,[p("span",null,"幻灯片页面设置"+St(t.pageIndex?` (第 ${t.pageIndex} 页)`:""),1)]),dt(wa,{"model-value":t.pageLayout,onChange:h[0]||(h[0]=f=>u.$emit("update:pageLayout",f))},null,8,["model-value"]),!o.value&&t.pageLayout!=="clover"&&t.detectedSbRatio?(st(),ot("div",fg,[p("div",pg,[p("div",hg,[dt(ft,{name:"sparkles"}),p("span",null,[h[31]||(h[31]=$e("检测到本页横向超级块列宽比例：",-1)),p("b",null,St(t.detectedSbRatio),1)])]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__w","aria-label":"一键将本页版式设为分栏并应用超级块列宽",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:h[1]||(h[1]=f=>u.$emit("applySuperBlockLayout",t.detectedSbInfo||{recommendedLayout:"two-cols",ratio:t.detectedSbRatio}))},[dt(ft,{name:"columns"}),h[32]||(h[32]=p("span",null,"设为分栏",-1))])])])):Pt("",!0),o.value?(st(),ot("div",mg,[p("div",gg,[p("div",vg,[p("div",bg,[dt(ft,{name:"ratio"}),h[33]||(h[33]=p("span",null,"分栏比例 (Ratio)",-1))]),h[34]||(h[34]=p("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),p("div",yg,[(st(!0),ot(qt,null,ke(r.value,f=>(st(),ot("button",{key:f.value,class:It(["spm-chip",{active:a.value===f.value}]),onClick:v=>u.$emit("update:pageLayoutRatio",f.value)},St(f.label),11,kg))),128))]),p("div",wg,[p("input",{value:t.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:h[2]||(h[2]=f=>u.$emit("update:pageLayoutRatio",f.target.value)),onChange:h[3]||(h[3]=f=>u.$emit("update:pageLayoutRatio",f.target.value))},null,40,xg),t.detectedSbRatio?(st(),ot("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":`从当前页思源超级块读取实际宽度比例 (${t.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:h[4]||(h[4]=f=>u.$emit("update:pageLayoutRatio",t.detectedSbRatio))},[dt(ft,{name:"sparkles"}),h[35]||(h[35]=p("span",null,"读取",-1))],8,Sg)):(st(),ot("button",_g,[dt(ft,{name:"sparkles"}),h[36]||(h[36]=p("span",null,"读取",-1))])),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":"重置渲染比例为平均分布，并立即重置文档中超级块内容分布比例",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:c},[dt(ft,{name:"reset"}),h[37]||(h[37]=p("span",null,"重置",-1))])]),t.detectedSbRatio?(st(),ot("div",Cg,[dt(ft,{name:"ratio"}),h[38]||(h[38]=p("span",null,"检测到思源超级块宽度：",-1)),p("code",$g,St(t.detectedSbRatio),1)])):(st(),ot("div",Ig,[dt(ft,{name:"ratio"}),h[39]||(h[39]=p("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Pt("",!0),dt(Yo,{"model-value":t.pageTransition,onChange:h[5]||(h[5]=f=>u.$emit("update:pageTransition",f))},null,8,["model-value"]),p("div",Ag,[p("div",Tg,[p("div",Bg,[p("div",Eg,[dt(ft,{name:"sparkles"}),h[40]||(h[40]=p("span",null,"页面动态蒙版 (Dynamic Mask)",-1))]),h[41]||(h[41]=p("span",{class:"spm-control-desc"},"随着点击操作分段展露正文内容",-1))])]),p("div",Mg,[p("button",{class:It(["spm-segmented-item",{active:!t.pageMask}]),onClick:h[6]||(h[6]=f=>u.$emit("update:pageMask",""))}," 关闭 ",2),p("button",{class:It(["spm-segmented-item",{active:t.pageMask==="down"}]),onClick:h[7]||(h[7]=f=>u.$emit("update:pageMask","down"))}," 从上至下 ",2),p("button",{class:It(["spm-segmented-item",{active:t.pageMask==="right"}]),onClick:h[8]||(h[8]=f=>u.$emit("update:pageMask","right"))}," 从左至右 ",2)]),t.pageMask?(st(),ot("div",Dg,[p("div",Lg,[h[43]||(h[43]=p("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),p("span",Rg,[dt(ft,{name:"help"}),h[42]||(h[42]=p("span",null,"输入规则",-1))])]),p("div",Pg,[(st(),ot(qt,null,ke(s,f=>p("button",{key:f.value,class:It(["spm-chip",{active:(t.pageMaskRatio||"1:1")===f.value}]),onClick:v=>u.$emit("update:pageMaskRatio",f.value)},St(f.label),11,Og)),64))]),p("div",zg,[p("input",{value:t.pageMaskRatio||"1:1",class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:h[9]||(h[9]=f=>u.$emit("update:pageMaskRatio",f.target.value)),onChange:h[10]||(h[10]=f=>u.$emit("update:pageMaskRatio",f.target.value))},null,40,Ng)]),h[46]||(h[46]=p("div",{style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}}," 提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数 ",-1)),p("div",Fg,[p("div",Hg,[h[44]||(h[44]=p("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),p("div",jg,[p("button",{class:It(["spm-segmented-item",{active:!t.pageMaskStyle||t.pageMaskStyle==="solid"}]),onClick:h[11]||(h[11]=f=>u.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),p("button",{class:It(["spm-segmented-item",{active:t.pageMaskStyle==="blur"}]),onClick:h[12]||(h[12]=f=>u.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),p("div",Wg,[h[45]||(h[45]=p("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),p("div",Ug,[p("button",{class:It(["spm-segmented-item",{active:!t.pageMaskInitial||t.pageMaskInitial==="hidden"}]),onClick:h[13]||(h[13]=f=>u.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),p("button",{class:It(["spm-segmented-item",{active:t.pageMaskInitial==="revealed"}]),onClick:h[14]||(h[14]=f=>u.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Pt("",!0)]),p("div",Vg,[p("div",qg,[p("div",Kg,[p("div",Gg,[dt(ft,{name:"ratio"}),h[47]||(h[47]=p("span",null,"页面间距 (Spacing)",-1))]),h[48]||(h[48]=p("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),p("div",Zg,[p("button",{class:It(["spm-segmented-item",{active:!t.pageSpacing||t.pageSpacing==="inherit"}]),onClick:h[15]||(h[15]=f=>u.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),p("button",{class:It(["spm-segmented-item",{active:t.pageSpacing==="compact"}]),onClick:h[16]||(h[16]=f=>u.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),p("button",{class:It(["spm-segmented-item",{active:t.pageSpacing==="normal"}]),onClick:h[17]||(h[17]=f=>u.$emit("update:pageSpacing","normal"))}," 标准 ",2),p("button",{class:It(["spm-segmented-item",{active:t.pageSpacing==="loose"}]),onClick:h[18]||(h[18]=f=>u.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),p("div",Yg,[p("div",Jg,[p("div",Xg,[p("div",Qg,[dt(ft,{name:"palette"}),h[49]||(h[49]=p("span",null,"页面背景 (Background)",-1))]),h[50]||(h[50]=p("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),p("div",tv,[(st(),ot(qt,null,ke(m,f=>p("button",{key:f.value,class:It(["spm-chip",{active:t.pageBackground===f.value}]),onClick:v=>u.$emit("update:pageBackground",f.value)},St(f.label),11,ev)),64))]),p("input",{value:t.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:h[19]||(h[19]=f=>u.$emit("update:pageBackground",f.target.value)),onChange:h[20]||(h[20]=f=>u.$emit("update:pageBackground",f.target.value))},null,40,iv)]),t.pageLayout==="image-right"||t.pageLayout==="image-left"||t.pageImage?(st(),ot("div",nv,[p("div",sv,[p("div",ov,[p("div",rv,[dt(ft,{name:"image"}),h[51]||(h[51]=p("span",null,"页面图片 (Image)",-1))]),h[52]||(h[52]=p("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),p("div",lv,[(st(),ot(qt,null,ke(b,f=>p("button",{key:f.value,class:It(["spm-chip",{active:t.pageImage===f.value}]),onClick:v=>u.$emit("update:pageImage",f.value)},St(f.label),11,av)),64))]),p("input",{value:t.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:h[21]||(h[21]=f=>u.$emit("update:pageImage",f.target.value)),onChange:h[22]||(h[22]=f=>u.$emit("update:pageImage",f.target.value))},null,40,cv)])):Pt("",!0),p("div",dv,[p("div",uv,[p("div",fv,[p("div",pv,[dt(ft,{name:"presenter"}),h[53]||(h[53]=p("span",null,"演讲者提词 (Notes)",-1))]),h[54]||(h[54]=p("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),p("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:h[23]||(h[23]=f=>u.$emit("generateNotes"))},[dt(ft,{name:"sparkles"}),h[55]||(h[55]=p("span",null,"AI 讲稿",-1))])]),t.pageNotes?(st(),ot("div",hv,[h[58]||(h[58]=p("div",{class:"spm-note-status-badge"},[p("span",{class:"spm-badge-dot"}),p("span",null,"已配置正文讲稿")],-1)),p("div",{class:"spm-note-preview-text",title:t.pageNotes},St(d.value),9,mv),p("div",gv,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:h[24]||(h[24]=f=>u.$emit("locateNoteBlock"))},[dt(ft,{name:"search"}),h[56]||(h[56]=p("span",null,"定位讲稿块",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:h[25]||(h[25]=f=>u.$emit("addNoteBlock"))},[dt(ft,{name:"insert-below"}),h[57]||(h[57]=p("span",null,"追加讲稿块",-1))])])])):(st(),ot("div",vv,[h[60]||(h[60]=p("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:h[26]||(h[26]=f=>u.$emit("addNoteBlock"))},[dt(ft,{name:"insert-below"}),h[59]||(h[59]=p("span",null,"添加讲稿备注块",-1))])])),p("div",bv,[p("div",yv,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",disabled:t.isBatchProcessing,style:Bn(t.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:h[27]||(h[27]=f=>u.$emit("batchAppendNotes"))},[dt(ft,{name:"insert-below"}),h[61]||(h[61]=p("span",null,"全部追加",-1))],12,kv),p("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s",disabled:t.isBatchProcessing,style:Bn(t.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:h[28]||(h[28]=f=>u.$emit("batchDeleteNotes"))},[dt(ft,{name:"trash"}),h[62]||(h[62]=p("span",null,"全部删除",-1))],12,wv)])])]),p("div",xv,[h[65]||(h[65]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),p("div",Sv,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:h[29]||(h[29]=f=>u.$emit("insertDividerAfter"))},[dt(ft,{name:"insert-below"}),h[63]||(h[63]=p("span",null,"插入新页",-1))]),p("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:h[30]||(h[30]=f=>u.$emit("deleteDivider"))},[dt(ft,{name:"trash"}),h[64]||(h[64]=p("span",null,"删除此页",-1))])])])]))}}),Cv=Ne(_v,[["__scopeId","data-v-1f9d4630"]]),$v={class:"spm-section spm-section--block"},Iv={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},Av={class:"spm-control-header"},Tv={class:"spm-control-title-group"},Bv={class:"spm-control-title"},Ev={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},Mv={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},Dv={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},Lv={key:0},Rv={key:1},Pv={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},Ov={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},zv={class:"spm-action-grid"},Nv={class:"spm-card-control"},Fv={class:"spm-control-header"},Hv={class:"spm-control-title-group"},jv={class:"spm-control-title"},Wv=["aria-label"],Uv=["checked"],Vv={key:1,class:"spm-card-control"},qv={class:"spm-control-header"},Kv={class:"spm-control-title-group"},Gv={class:"spm-control-title"},Zv={class:"spm-quick-chips"},Yv={key:2,class:"spm-card-control"},Jv={class:"spm-control-header"},Xv={class:"spm-control-title-group"},Qv={class:"spm-control-title"},t1={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},e1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},i1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},n1=["aria-label"],s1=["checked"],o1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},r1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},l1=["aria-label"],a1=["checked"],c1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},d1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},u1=["aria-label"],f1=["checked"],p1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},h1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},m1=["aria-label"],g1=["checked"],v1={class:"spm-card-control"},b1={class:"spm-control-header"},y1={class:"spm-control-title-group"},k1={class:"spm-control-title"},w1=["aria-label"],x1=["checked"],S1={key:0,class:"spm-quick-chips"},_1=["onClick"],C1={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},$1={class:"spm-card-control"},I1={class:"spm-control-header"},A1={class:"spm-control-title-group"},T1={class:"spm-control-title"},B1=["aria-label"],E1=["checked"],M1={key:0,class:"spm-quick-chips"},D1=["onClick"],L1={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},R1={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},P1={style:{display:"flex",gap:"6px"}},O1=["value"],z1=["value"],N1={key:3,class:"spm-card-control"},F1={class:"spm-control-header"},H1={class:"spm-control-title-group"},j1={class:"spm-control-title"},W1={class:"spm-control-desc"},U1={class:"spm-segmented-group"},V1=["onClick"],q1={key:4,class:"spm-card-control"},K1={class:"spm-control-header"},G1={class:"spm-control-title-group"},Z1={class:"spm-control-title"},Y1={class:"spm-quick-chips"},J1=["onClick"],X1=["value"],Q1={key:5,class:"spm-card-control"},tb={class:"spm-control-header"},eb={class:"spm-control-title-group"},ib={class:"spm-control-title"},nb={class:"spm-quick-chips"},sb=["onClick"],ob=["value"],rb={class:"spm-card-control"},lb={class:"spm-action-grid"},ab=["aria-label"],cb=Ce({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(t,{emit:e}){const i=t,n=_t(()=>{const T=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":T}),s=_t(()=>{const T=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(T)}),o=_t(()=>{var w,W,V,q;if((w=i.detectedSbInfo)!=null&&w.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const T=(W=i.elemSlot)==null?void 0:W.match(/^col-(\d+)$/);if(T){const X=parseInt(T[1],10);if(X>=2&&X<=6)return Math.max(X,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((q=(V=i.detectedSbInfo)==null?void 0:V.ratio)!=null&&q.includes(":")){const X=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(X.length>=2)return Math.min(X.length,6)}return 3}),l=_t(()=>{const T=n.value;return T==="cols-header"?"多栏插槽归属 (Slot)":T==="three-cols-header"?"三栏插槽归属 (Slot)":T==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),r=_t(()=>{const T=n.value;return T==="cols-header"?`在 cols-header 表头多栏（${o.value} 栏）中的内容块位置`:T==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":T==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":T==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=_t(()=>{const T=n.value;if(T==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(T==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(T==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const w=o.value,W=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let V=1;V<=w;V++)W.push({value:`col-${V}`,label:`第 ${V} 栏`});return W});function c(T){const w=i.elemSlot||"";return T?w===T||T==="col-1"&&w==="left"||T==="col-2"&&w==="center"||T==="col-3"&&w==="right"&&o.value===3||T==="col-2"&&w==="right"&&o.value===2||T==="left"&&w==="col-1"||T==="right"&&(w==="col-2"||w==="col-3"):!w||w==="default"}const d=e,m=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],b=_t(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const T=JSON.parse(i.elemMotion);if(typeof T=="object"&&T!==null)return{preset:T.preset||T.type||"slide-up",duration:typeof T.duration=="number"?T.duration:0,delay:typeof T.delay=="number"?T.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),u=_t(()=>!!b.value),h=_t(()=>{var T;return((T=b.value)==null?void 0:T.preset)||"slide-up"}),f=_t(()=>{var T;return((T=b.value)==null?void 0:T.duration)||0}),v=_t(()=>{var T;return((T=b.value)==null?void 0:T.delay)||0});function k(){u.value?d("update:elemMotion",""):d("update:elemMotion","slide-up")}function x(T){L(T,f.value,v.value)}function $(T){L(h.value,T,v.value)}function B(T){L(h.value,f.value,T)}function L(T,w,W){if(!T||T==="none"){d("update:elemMotion","");return}if(!w&&!W){d("update:elemMotion",T);return}const V={preset:T};w>0&&(V.duration=w),W>0&&(V.delay=W),d("update:elemMotion",JSON.stringify(V))}return(T,w)=>{var W,V,q,X,C,z;return st(),ot("div",$v,[w[62]||(w[62]=p("div",{class:"spm-section-header"},[p("span",null,"元素动效与排版")],-1)),t.isSuperBlock||(W=t.detectedSbInfo)!=null&&W.hasSuperBlock?(st(),ot("div",Iv,[p("div",Av,[p("div",Tv,[p("div",Bv,[dt(ft,{name:"ratio"}),w[24]||(w[24]=p("span",null,"超级块列宽与布局",-1))]),w[25]||(w[25]=p("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),p("div",Ev,[p("div",Mv,[p("div",Dv,[dt(ft,{name:"ratio"}),(V=t.detectedSbInfo)!=null&&V.isCustomWidth?(st(),ot("span",Lv,"已识别自定义列宽比例")):(st(),ot("span",Rv,"识别到 "+St(((q=t.detectedSbInfo)==null?void 0:q.colCount)||2)+" 列超级块分栏",1))]),p("code",Pv,St(((X=t.detectedSbInfo)==null?void 0:X.ratio)||"1:1"),1)]),p("div",Ov,St((C=t.detectedSbInfo)!=null&&C.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),p("div",zv,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:w[0]||(w[0]=y=>T.$emit("applySuperBlockLayout",t.detectedSbInfo))},[dt(ft,{name:"sparkles"}),w[26]||(w[26]=p("span",null,"应用版式与比例",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:w[1]||(w[1]=y=>{var D;return T.$emit("applySuperBlockRatio",((D=t.detectedSbInfo)==null?void 0:D.ratio)||"1:1")})},[dt(ft,{name:"check"}),p("span",null,"应用比例 ("+St(((z=t.detectedSbInfo)==null?void 0:z.ratio)||"1:1")+")",1)])])])):Pt("",!0),p("div",Nv,[p("div",Fv,[p("div",Hv,[p("div",jv,[dt(ft,{name:"presenter"}),w[27]||(w[27]=p("span",null,"设为讲稿备注 (slidev-note)",-1))]),w[28]||(w[28]=p("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.isNote?"取消讲稿备注":"设为讲稿备注"},[p("input",{type:"checkbox",checked:!!t.isNote,onChange:w[2]||(w[2]=y=>T.$emit("toggleNote"))},null,40,Uv),w[29]||(w[29]=p("span",{class:"spm-switch-slider"},null,-1))],8,Wv)])]),t.isImage||t.imageRole?(st(),ot("div",Vv,[p("div",qv,[p("div",Kv,[p("div",Gv,[dt(ft,{name:"image"}),w[30]||(w[30]=p("span",null,"图片角色与分栏 (Image & Layout)",-1))]),w[31]||(w[31]=p("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),p("div",Zv,[p("button",{class:It(["spm-chip",{active:!t.imageRole}]),onClick:w[3]||(w[3]=y=>T.$emit("update:imageRole",""))}," 普通内容 ",2),p("button",{class:It(["spm-chip",{active:t.imageRole==="background"}]),onClick:w[4]||(w[4]=y=>T.$emit("update:imageRole","background"))},[dt(ft,{name:"image"}),w[32]||(w[32]=p("span",null,"背景图",-1))],2),p("button",{class:It(["spm-chip",{active:t.imageRole==="image-left"}]),onClick:w[5]||(w[5]=y=>T.$emit("update:imageRole","image-left"))},[dt(ft,{name:"image-left"}),w[33]||(w[33]=p("span",null,"图左",-1))],2),p("button",{class:It(["spm-chip",{active:t.imageRole==="image-right"}]),onClick:w[6]||(w[6]=y=>T.$emit("update:imageRole","image-right"))},[dt(ft,{name:"image-right"}),w[34]||(w[34]=p("span",null,"图右",-1))],2)])])):Pt("",!0),t.isVideo?(st(),ot("div",Yv,[p("div",Jv,[p("div",Xv,[p("div",Qv,[dt(ft,{name:"video"}),w[35]||(w[35]=p("span",null,"视频播放设置 (Video Playback)",-1))]),w[36]||(w[36]=p("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),p("div",t1,[p("div",e1,[p("span",i1,[dt(ft,{name:"sliders"}),w[37]||(w[37]=$e(" 控制条",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoControls?"关闭控制条":"开启控制条"},[p("input",{type:"checkbox",checked:!!t.videoControls,onChange:w[7]||(w[7]=y=>T.$emit("toggleVideoControls"))},null,40,s1),w[38]||(w[38]=p("span",{class:"spm-switch-slider"},null,-1))],8,n1)]),p("div",o1,[p("span",r1,[dt(ft,{name:"video"}),w[39]||(w[39]=$e(" 自动播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoAutoplay?"关闭自动播放":"开启自动播放"},[p("input",{type:"checkbox",checked:!!t.videoAutoplay,onChange:w[8]||(w[8]=y=>T.$emit("toggleVideoAutoplay"))},null,40,a1),w[40]||(w[40]=p("span",{class:"spm-switch-slider"},null,-1))],8,l1)]),p("div",c1,[p("span",d1,[dt(ft,{name:"repeat"}),w[41]||(w[41]=$e(" 循环播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoLoop?"关闭循环播放":"开启循环播放"},[p("input",{type:"checkbox",checked:!!t.videoLoop,onChange:w[9]||(w[9]=y=>T.$emit("toggleVideoLoop"))},null,40,f1),w[42]||(w[42]=p("span",{class:"spm-switch-slider"},null,-1))],8,u1)]),p("div",p1,[p("span",h1,[dt(ft,{name:"volume-x"}),w[43]||(w[43]=$e(" 静音播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoMuted?"关闭静音":"开启静音"},[p("input",{type:"checkbox",checked:!!t.videoMuted,onChange:w[10]||(w[10]=y=>T.$emit("toggleVideoMuted"))},null,40,g1),w[44]||(w[44]=p("span",{class:"spm-switch-slider"},null,-1))],8,m1)])])])):Pt("",!0),p("div",v1,[p("div",b1,[p("div",y1,[p("div",k1,[dt(ft,{name:"step"}),w[45]||(w[45]=p("span",null,"逐步呈现 (v-click)",-1))]),w[46]||(w[46]=p("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[p("input",{type:"checkbox",checked:!!t.elemClick,onChange:w[11]||(w[11]=y=>T.$emit("toggleElemClick"))},null,40,x1),w[47]||(w[47]=p("span",{class:"spm-switch-slider"},null,-1))],8,w1)]),t.elemClick?(st(),ot("div",S1,[(st(),ot(qt,null,ke(["+1","1","2","hide"],y=>p("button",{key:y,class:It(["spm-chip",{active:t.elemClick===y}]),onClick:D=>T.$emit("update:elemClick",y)},St(y==="+1"?"顺延 (+1)":y==="hide"?"隐藏 (hide)":"第 "+y+" 步"),11,_1)),64))])):t.parentElemClick?(st(),ot("div",C1,[dt(ft,{name:"check"}),w[48]||(w[48]=p("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Pt("",!0)]),p("div",$1,[p("div",I1,[p("div",A1,[p("div",T1,[dt(ft,{name:"motion"}),w[49]||(w[49]=p("span",null,"入场微动效 (v-motion)",-1))]),w[50]||(w[50]=p("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":u.value?"关闭微动效":"开启微动效 (slide-up)"},[p("input",{type:"checkbox",checked:u.value,onChange:k},null,40,E1),w[51]||(w[51]=p("span",{class:"spm-switch-slider"},null,-1))],8,B1)]),u.value?(st(),ot("div",M1,[(st(),ot(qt,null,ke(m,y=>p("button",{key:y.value,class:It(["spm-chip",{active:h.value===y.value}]),onClick:D=>x(y.value)},St(y.label),11,D1)),64))])):Pt("",!0),u.value?(st(),ot("div",L1,[p("div",R1,[p("span",null,"时长: "+St(f.value?f.value+"ms":"默认 (450ms)"),1),p("span",null,"延迟: "+St(v.value?v.value+"ms":"0ms"),1)]),p("div",P1,[p("select",{class:"spm-select",style:{flex:"1"},value:f.value,onChange:w[12]||(w[12]=y=>$(Number(y.target.value)))},[...w[52]||(w[52]=[p("option",{value:0},"默认耗时",-1),p("option",{value:200},"极速 (200ms)",-1),p("option",{value:350},"较快 (350ms)",-1),p("option",{value:500},"平滑 (500ms)",-1),p("option",{value:800},"缓慢 (800ms)",-1)])],40,O1),p("select",{class:"spm-select",style:{flex:"1"},value:v.value,onChange:w[13]||(w[13]=y=>B(Number(y.target.value)))},[...w[53]||(w[53]=[p("option",{value:0},"无延迟",-1),p("option",{value:150},"延迟 150ms",-1),p("option",{value:300},"延迟 300ms",-1),p("option",{value:500},"延迟 500ms",-1)])],40,z1)])])):Pt("",!0)]),s.value||t.elemSlot?(st(),ot("div",N1,[p("div",F1,[p("div",H1,[p("div",j1,[dt(ft,{name:"columns"}),p("span",null,St(l.value),1)]),p("span",W1,St(r.value),1)])]),p("div",U1,[(st(!0),ot(qt,null,ke(a.value,y=>(st(),ot("button",{key:y.value,class:It(["spm-segmented-item",{active:c(y.value)}]),onClick:D=>T.$emit("update:elemSlot",y.value)},St(y.label),11,V1))),128))])])):Pt("",!0),t.isCodeBlock?(st(),ot("div",q1,[p("div",K1,[p("div",G1,[p("div",Z1,[dt(ft,{name:"code"}),w[54]||(w[54]=p("span",null,"代码逐行聚光 (Shiki)",-1))]),w[55]||(w[55]=p("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),p("div",Y1,[(st(),ot(qt,null,ke(["1-3","all","1|2|3","2-5"],y=>p("button",{key:y,class:It(["spm-chip",{active:t.elemShikiLines===y}]),onClick:D=>T.$emit("update:elemShikiLines",y)},St(y),11,J1)),64)),t.elemShikiLines?(st(),ot("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[14]||(w[14]=y=>T.$emit("update:elemShikiLines",""))}," 清空 ")):Pt("",!0)]),p("input",{value:t.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:w[15]||(w[15]=y=>T.$emit("update:elemShikiLines",y.target.value)),onChange:w[16]||(w[16]=y=>T.$emit("update:elemShikiLines",y.target.value))},null,40,X1)])):Pt("",!0),t.isCodeBlock?(st(),ot("div",Q1,[p("div",tb,[p("div",eb,[p("div",ib,[dt(ft,{name:"code"}),w[56]||(w[56]=p("span",null,"代码块限高 (Max Height)",-1))]),w[57]||(w[57]=p("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),p("div",nb,[(st(),ot(qt,null,ke(["240px","320px","400px","50vh"],y=>p("button",{key:y,class:It(["spm-chip",{active:t.elemMaxHeight===y}]),onClick:D=>T.$emit("update:elemMaxHeight",y)},St(y),11,sb)),64)),t.elemMaxHeight?(st(),ot("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[17]||(w[17]=y=>T.$emit("update:elemMaxHeight",""))}," 自适应 ")):Pt("",!0)]),p("input",{value:t.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:w[18]||(w[18]=y=>T.$emit("update:elemMaxHeight",y.target.value)),onChange:w[19]||(w[19]=y=>T.$emit("update:elemMaxHeight",y.target.value))},null,40,ob)])):Pt("",!0),p("div",rb,[w[61]||(w[61]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"快捷操作")])],-1)),p("div",lb,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:w[20]||(w[20]=y=>T.$emit("insertDividerBefore"))},[dt(ft,{name:"insert-above"}),w[58]||(w[58]=p("span",null,"上方分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:w[21]||(w[21]=y=>T.$emit("insertDividerAfter"))},[dt(ft,{name:"insert-below"}),w[59]||(w[59]=p("span",null,"下方分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:w[22]||(w[22]=y=>T.$emit("setTwoColsContrast"))},[dt(ft,{name:"columns"}),p("span",null,St(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,ab),t.hasBlockAttrs?(st(),ot("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:w[23]||(w[23]=y=>T.$emit("clearBlockAttrs"))},[dt(ft,{name:"broom"}),w[60]||(w[60]=p("span",null,"清除属性",-1))])):Pt("",!0)])])])}}}),db={class:"spm-section spm-section--doc"},ub={class:"spm-card-control"},fb={class:"spm-control-header"},pb={class:"spm-control-title-group"},hb={class:"spm-control-title"},mb={class:"spm-segmented-group"},gb=["aria-label","onClick"],vb={class:"spm-card-control"},bb={class:"spm-control-header"},yb={class:"spm-control-title-group"},kb={class:"spm-control-title"},wb={class:"spm-segmented-group"},xb={class:"spm-card-control"},Sb={class:"spm-control-header"},_b={class:"spm-control-title-group"},Cb={class:"spm-control-title"},$b={class:"spm-segmented-group"},Ib={class:"spm-card-control"},Ab={class:"spm-control-header"},Tb={class:"spm-control-title-group"},Bb={class:"spm-control-title"},Eb={class:"spm-card-control"},Mb={class:"spm-control-header"},Db={class:"spm-control-title-group"},Lb={class:"spm-control-title"},Rb=["aria-label"],Pb=["checked"],Ob={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},zb=["value"],Nb={class:"spm-card-control"},Fb={class:"spm-control-header"},Hb={class:"spm-control-title-group"},jb={class:"spm-control-title"},Wb=["aria-label"],Ub=["checked"],Vb={class:"spm-card-control"},qb={class:"spm-action-grid"},Kb=Ce({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(t){const e=ti("plugin"),i=hi,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function s(a){Li({enableWebServeJump:a}),e&&typeof e.saveGlobalSettings=="function"&&e.saveGlobalSettings({enableWebServeJump:a})}async function o(a){var c;Li({normalizeHeadingSizes:a}),e&&typeof e.saveGlobalSettings=="function"&&await e.saveGlobalSettings({normalizeHeadingSizes:a}),e&&typeof e.compileCurrentDocument=="function"&&e.compileCurrentDocument(e.currentDocId||((c=e.getActiveDocumentId)==null?void 0:c.call(e)))}function l(a){Li({webServeUrl:a})}function r(a){Li({webServeUrl:a}),e&&typeof e.saveGlobalSettings=="function"&&e.saveGlobalSettings({webServeUrl:a})}return(a,c)=>(st(),ot("div",db,[c[39]||(c[39]=p("div",{class:"spm-section-header"},[p("span",null,"全局演示配置")],-1)),p("div",ub,[p("div",fb,[p("div",pb,[p("div",hb,[dt(ft,{name:"palette"}),c[18]||(c[18]=p("span",null,"幻灯片主题 (Theme)",-1))]),c[19]||(c[19]=p("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),p("div",mb,[(st(),ot(qt,null,ke(n,d=>p("button",{key:d.value,class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:t.docTheme===d.value}]),"aria-label":d.desc,onClick:m=>a.$emit("update:docTheme",d.value)},St(d.label),11,gb)),64))])]),p("div",vb,[p("div",bb,[p("div",yb,[p("div",kb,[dt(ft,{name:"ratio"}),c[20]||(c[20]=p("span",null,"画幅比例 (Aspect Ratio)",-1))]),c[21]||(c[21]=p("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),p("div",wb,[p("button",{class:It(["spm-segmented-item",{active:t.docAspectRatio==="16/9"}]),onClick:c[0]||(c[0]=d=>a.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),p("button",{class:It(["spm-segmented-item",{active:t.docAspectRatio==="4/3"}]),onClick:c[1]||(c[1]=d=>a.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),p("button",{class:It(["spm-segmented-item",{active:t.docAspectRatio==="16/10"}]),onClick:c[2]||(c[2]=d=>a.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),p("div",xb,[p("div",Sb,[p("div",_b,[p("div",Cb,[dt(ft,{name:"ratio"}),c[22]||(c[22]=p("span",null,"间距风格 (Spacing)",-1))]),c[23]||(c[23]=p("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),p("div",$b,[p("button",{class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:c[3]||(c[3]=d=>a.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),p("button",{class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:c[4]||(c[4]=d=>a.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),p("button",{class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:c[5]||(c[5]=d=>a.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),p("div",Ib,[p("div",Ab,[p("div",Tb,[p("div",Bb,[dt(ft,{name:"transition"}),c[24]||(c[24]=p("span",null,"全局默认转场",-1))]),c[25]||(c[25]=p("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),dt(Yo,{"model-value":t.docDefaultTransition,"hide-header":!0,onChange:c[6]||(c[6]=d=>a.$emit("update:docDefaultTransition",d))},null,8,["model-value"])]),p("div",Eb,[p("div",Mb,[p("div",Db,[p("div",Lb,[dt(ft,{name:"external-link"}),c[26]||(c[26]=p("span",null,"本地网络伺服预览 (Web Serve)",-1))]),c[27]||(c[27]=p("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":yt(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[p("input",{type:"checkbox",checked:yt(i).enableWebServeJump,onChange:c[7]||(c[7]=d=>s(d.target.checked))},null,40,Pb),c[28]||(c[28]=p("span",{class:"spm-switch-slider"},null,-1))],8,Rb)]),yt(i).enableWebServeJump?(st(),ot("div",Ob,[p("input",{value:yt(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:c[8]||(c[8]=Me(()=>{},["stop"])),onKeyup:c[9]||(c[9]=Me(()=>{},["stop"])),onInput:c[10]||(c[10]=d=>l(d.target.value)),onChange:c[11]||(c[11]=d=>r(d.target.value))},null,40,zb),c[29]||(c[29]=p("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Pt("",!0)]),p("div",Nb,[p("div",Fb,[p("div",Hb,[p("div",jb,[dt(ft,{name:"type"}),c[30]||(c[30]=p("span",null,"固定特定标题大小",-1))]),c[31]||(c[31]=p("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":yt(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[p("input",{type:"checkbox",checked:yt(i).normalizeHeadingSizes,onChange:c[12]||(c[12]=d=>o(d.target.checked))},null,40,Ub),c[32]||(c[32]=p("span",{class:"spm-switch-slider"},null,-1))],8,Wb)])]),p("div",Vb,[c[38]||(c[38]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"演示全局操作")])],-1)),p("div",qb,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:c[13]||(c[13]=d=>a.$emit("openBottomPreview"))},[dt(ft,{name:"split-preview"}),c[33]||(c[33]=p("span",null,"分屏预览",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:c[14]||(c[14]=d=>a.$emit("openPresenter"))},[dt(ft,{name:"presenter"}),c[34]||(c[34]=p("span",null,"演讲者视图",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:c[15]||(c[15]=d=>a.$emit("aiAutoSplit"))},[dt(ft,{name:"sparkles"}),c[35]||(c[35]=p("span",null,"AI 智能分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:c[16]||(c[16]=d=>a.$emit("exportHtml"))},[dt(ft,{name:"export-html"}),c[36]||(c[36]=p("span",null,"导出 HTML",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:c[17]||(c[17]=d=>a.$emit("exportPdf"))},[dt(ft,{name:"export-pdf"}),c[37]||(c[37]=p("span",null,"导出 PDF",-1))])])])]))}});var Xn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function Gb(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}function Qn(t){throw new Error('Could not dynamically require "'+t+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var eo={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var jr;function Zb(){return jr||(jr=1,(function(t,e){(function(i){t.exports=i()})(function(){return(function i(n,s,o){function l(c,d){if(!s[c]){if(!n[c]){var m=typeof Qn=="function"&&Qn;if(!d&&m)return m(c,!0);if(r)return r(c,!0);var b=new Error("Cannot find module '"+c+"'");throw b.code="MODULE_NOT_FOUND",b}var u=s[c]={exports:{}};n[c][0].call(u.exports,function(h){var f=n[c][1][h];return l(f||h)},u,u.exports,i,n,s,o)}return s[c].exports}for(var r=typeof Qn=="function"&&Qn,a=0;a<o.length;a++)l(o[a]);return l})({1:[function(i,n,s){var o=i("./utils"),l=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";s.encode=function(a){for(var c,d,m,b,u,h,f,v=[],k=0,x=a.length,$=x,B=o.getTypeOf(a)!=="string";k<a.length;)$=x-k,m=B?(c=a[k++],d=k<x?a[k++]:0,k<x?a[k++]:0):(c=a.charCodeAt(k++),d=k<x?a.charCodeAt(k++):0,k<x?a.charCodeAt(k++):0),b=c>>2,u=(3&c)<<4|d>>4,h=1<$?(15&d)<<2|m>>6:64,f=2<$?63&m:64,v.push(r.charAt(b)+r.charAt(u)+r.charAt(h)+r.charAt(f));return v.join("")},s.decode=function(a){var c,d,m,b,u,h,f=0,v=0,k="data:";if(a.substr(0,k.length)===k)throw new Error("Invalid base64 input, it looks like a data url.");var x,$=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&$--,a.charAt(a.length-2)===r.charAt(64)&&$--,$%1!=0)throw new Error("Invalid base64 input, bad content length.");for(x=l.uint8array?new Uint8Array(0|$):new Array(0|$);f<a.length;)c=r.indexOf(a.charAt(f++))<<2|(b=r.indexOf(a.charAt(f++)))>>4,d=(15&b)<<4|(u=r.indexOf(a.charAt(f++)))>>2,m=(3&u)<<6|(h=r.indexOf(a.charAt(f++))),x[v++]=c,u!==64&&(x[v++]=d),h!==64&&(x[v++]=m);return x}},{"./support":30,"./utils":32}],2:[function(i,n,s){var o=i("./external"),l=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),a=i("./stream/DataLengthProbe");function c(d,m,b,u,h){this.compressedSize=d,this.uncompressedSize=m,this.crc32=b,this.compression=u,this.compressedContent=h}c.prototype={getContentWorker:function(){var d=new l(o.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),m=this;return d.on("end",function(){if(this.streamInfo.data_length!==m.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(o.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,m,b){return d.pipe(new r).pipe(new a("uncompressedSize")).pipe(m.compressWorker(b)).pipe(new a("compressedSize")).withStreamInfo("compression",m)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,n,s){var o=i("./stream/GenericWorker");s.STORE={magic:"\0\0",compressWorker:function(){return new o("STORE compression")},uncompressWorker:function(){return new o("STORE decompression")}},s.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,n,s){var o=i("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var d=0;d<8;d++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();n.exports=function(r,a){return r!==void 0&&r.length?o.getTypeOf(r)!=="string"?(function(c,d,m,b){var u=l,h=b+m;c^=-1;for(var f=b;f<h;f++)c=c>>>8^u[255&(c^d[f])];return-1^c})(0|a,r,r.length,0):(function(c,d,m,b){var u=l,h=b+m;c^=-1;for(var f=b;f<h;f++)c=c>>>8^u[255&(c^d.charCodeAt(f))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(i,n,s){s.base64=!1,s.binary=!1,s.dir=!1,s.createFolders=!0,s.date=null,s.compression=null,s.compressionOptions=null,s.comment=null,s.unixPermissions=null,s.dosPermissions=null},{}],6:[function(i,n,s){var o=null;o=typeof Promise<"u"?Promise:i("lie"),n.exports={Promise:o}},{lie:37}],7:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=i("pako"),r=i("./utils"),a=i("./stream/GenericWorker"),c=o?"uint8array":"array";function d(m,b){a.call(this,"FlateWorker/"+m),this._pako=null,this._pakoAction=m,this._pakoOptions=b,this.meta={}}s.magic="\b\0",r.inherits(d,a),d.prototype.processChunk=function(m){this.meta=m.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,m.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var m=this;this._pako.onData=function(b){m.push({data:b,meta:m.meta})}},s.compressWorker=function(m){return new d("Deflate",m)},s.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,n,s){function o(u,h){var f,v="";for(f=0;f<h;f++)v+=String.fromCharCode(255&u),u>>>=8;return v}function l(u,h,f,v,k,x){var $,B,L=u.file,T=u.compression,w=x!==c.utf8encode,W=r.transformTo("string",x(L.name)),V=r.transformTo("string",c.utf8encode(L.name)),q=L.comment,X=r.transformTo("string",x(q)),C=r.transformTo("string",c.utf8encode(q)),z=V.length!==L.name.length,y=C.length!==q.length,D="",U="",E="",P=L.dir,j=L.date,tt={crc32:0,compressedSize:0,uncompressedSize:0};h&&!f||(tt.crc32=u.crc32,tt.compressedSize=u.compressedSize,tt.uncompressedSize=u.uncompressedSize);var A=0;h&&(A|=8),w||!z&&!y||(A|=2048);var M=0,Y=0;P&&(M|=16),k==="UNIX"?(Y=798,M|=(function(et,it){var pt=et;return et||(pt=it?16893:33204),(65535&pt)<<16})(L.unixPermissions,P)):(Y=20,M|=(function(et){return 63&(et||0)})(L.dosPermissions)),$=j.getUTCHours(),$<<=6,$|=j.getUTCMinutes(),$<<=5,$|=j.getUTCSeconds()/2,B=j.getUTCFullYear()-1980,B<<=4,B|=j.getUTCMonth()+1,B<<=5,B|=j.getUTCDate(),z&&(U=o(1,1)+o(d(W),4)+V,D+="up"+o(U.length,2)+U),y&&(E=o(1,1)+o(d(X),4)+C,D+="uc"+o(E.length,2)+E);var J="";return J+=`
\0`,J+=o(A,2),J+=T.magic,J+=o($,2),J+=o(B,2),J+=o(tt.crc32,4),J+=o(tt.compressedSize,4),J+=o(tt.uncompressedSize,4),J+=o(W.length,2),J+=o(D.length,2),{fileRecord:m.LOCAL_FILE_HEADER+J+W+D,dirRecord:m.CENTRAL_FILE_HEADER+o(Y,2)+J+o(X.length,2)+"\0\0\0\0"+o(M,4)+o(v,4)+W+D+X}}var r=i("../utils"),a=i("../stream/GenericWorker"),c=i("../utf8"),d=i("../crc32"),m=i("../signature");function b(u,h,f,v){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=h,this.zipPlatform=f,this.encodeFileName=v,this.streamFiles=u,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(b,a),b.prototype.push=function(u){var h=u.meta.percent||0,f=this.entriesCount,v=this._sources.length;this.accumulate?this.contentBuffer.push(u):(this.bytesWritten+=u.data.length,a.prototype.push.call(this,{data:u.data,meta:{currentFile:this.currentFile,percent:f?(h+100*(f-v-1))/f:100}}))},b.prototype.openedSource=function(u){this.currentSourceOffset=this.bytesWritten,this.currentFile=u.file.name;var h=this.streamFiles&&!u.file.dir;if(h){var f=l(u,h,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:f.fileRecord,meta:{percent:0}})}else this.accumulate=!0},b.prototype.closedSource=function(u){this.accumulate=!1;var h=this.streamFiles&&!u.file.dir,f=l(u,h,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(f.dirRecord),h)this.push({data:(function(v){return m.DATA_DESCRIPTOR+o(v.crc32,4)+o(v.compressedSize,4)+o(v.uncompressedSize,4)})(u),meta:{percent:100}});else for(this.push({data:f.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},b.prototype.flush=function(){for(var u=this.bytesWritten,h=0;h<this.dirRecords.length;h++)this.push({data:this.dirRecords[h],meta:{percent:100}});var f=this.bytesWritten-u,v=(function(k,x,$,B,L){var T=r.transformTo("string",L(B));return m.CENTRAL_DIRECTORY_END+"\0\0\0\0"+o(k,2)+o(k,2)+o(x,4)+o($,4)+o(T.length,2)+T})(this.dirRecords.length,f,u,this.zipComment,this.encodeFileName);this.push({data:v,meta:{percent:100}})},b.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},b.prototype.registerPrevious=function(u){this._sources.push(u);var h=this;return u.on("data",function(f){h.processChunk(f)}),u.on("end",function(){h.closedSource(h.previous.streamInfo),h._sources.length?h.prepareNextSource():h.end()}),u.on("error",function(f){h.error(f)}),this},b.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},b.prototype.error=function(u){var h=this._sources;if(!a.prototype.error.call(this,u))return!1;for(var f=0;f<h.length;f++)try{h[f].error(u)}catch{}return!0},b.prototype.lock=function(){a.prototype.lock.call(this);for(var u=this._sources,h=0;h<u.length;h++)u[h].lock()},n.exports=b},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,n,s){var o=i("../compressions"),l=i("./ZipFileWorker");s.generateWorker=function(r,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),m=0;try{r.forEach(function(b,u){m++;var h=(function(x,$){var B=x||$,L=o[B];if(!L)throw new Error(B+" is not a valid compression method !");return L})(u.options.compression,a.compression),f=u.options.compressionOptions||a.compressionOptions||{},v=u.dir,k=u.date;u._compressWorker(h,f).withStreamInfo("file",{name:b,dir:v,date:k,comment:u.comment||"",unixPermissions:u.unixPermissions,dosPermissions:u.dosPermissions}).pipe(d)}),d.entriesCount=m}catch(b){d.error(b)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,n,s){function o(){if(!(this instanceof o))return new o;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new o;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(o.prototype=i("./object")).loadAsync=i("./load"),o.support=i("./support"),o.defaults=i("./defaults"),o.version="3.10.1",o.loadAsync=function(l,r){return new o().loadAsync(l,r)},o.external=i("./external"),n.exports=o},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,n,s){var o=i("./utils"),l=i("./external"),r=i("./utf8"),a=i("./zipEntries"),c=i("./stream/Crc32Probe"),d=i("./nodejsUtils");function m(b){return new l.Promise(function(u,h){var f=b.decompressed.getContentWorker().pipe(new c);f.on("error",function(v){h(v)}).on("end",function(){f.streamInfo.crc32!==b.decompressed.crc32?h(new Error("Corrupted zip : CRC32 mismatch")):u()}).resume()})}n.exports=function(b,u){var h=this;return u=o.extend(u||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),d.isNode&&d.isStream(b)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):o.prepareContent("the loaded zip file",b,!0,u.optimizedBinaryString,u.base64).then(function(f){var v=new a(u);return v.load(f),v}).then(function(f){var v=[l.Promise.resolve(f)],k=f.files;if(u.checkCRC32)for(var x=0;x<k.length;x++)v.push(m(k[x]));return l.Promise.all(v)}).then(function(f){for(var v=f.shift(),k=v.files,x=0;x<k.length;x++){var $=k[x],B=$.fileNameStr,L=o.resolve($.fileNameStr);h.file(L,$.decompressed,{binary:!0,optimizedBinaryString:!0,date:$.date,dir:$.dir,comment:$.fileCommentStr.length?$.fileCommentStr:null,unixPermissions:$.unixPermissions,dosPermissions:$.dosPermissions,createFolders:u.createFolders}),$.dir||(h.file(L).unsafeOriginalName=B)}return v.zipComment.length&&(h.comment=v.zipComment),h})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,n,s){var o=i("../utils"),l=i("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}o.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,n,s){var o=i("readable-stream").Readable;function l(r,a,c){o.call(this,a),this._helper=r;var d=this;r.on("data",function(m,b){d.push(m)||d._helper.pause(),c&&c(b)}).on("error",function(m){d.emit("error",m)}).on("end",function(){d.push(null)})}i("../utils").inherits(l,o),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(i,n,s){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(o,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(o,l);if(typeof o=="number")throw new Error('The "data" argument must not be a number');return new Buffer(o,l)},allocBuffer:function(o){if(Buffer.alloc)return Buffer.alloc(o);var l=new Buffer(o);return l.fill(0),l},isBuffer:function(o){return Buffer.isBuffer(o)},isStream:function(o){return o&&typeof o.on=="function"&&typeof o.pause=="function"&&typeof o.resume=="function"}}},{}],15:[function(i,n,s){function o(L,T,w){var W,V=r.getTypeOf(T),q=r.extend(w||{},d);q.date=q.date||new Date,q.compression!==null&&(q.compression=q.compression.toUpperCase()),typeof q.unixPermissions=="string"&&(q.unixPermissions=parseInt(q.unixPermissions,8)),q.unixPermissions&&16384&q.unixPermissions&&(q.dir=!0),q.dosPermissions&&16&q.dosPermissions&&(q.dir=!0),q.dir&&(L=k(L)),q.createFolders&&(W=v(L))&&x.call(this,W,!0);var X=V==="string"&&q.binary===!1&&q.base64===!1;w&&w.binary!==void 0||(q.binary=!X),(T instanceof m&&T.uncompressedSize===0||q.dir||!T||T.length===0)&&(q.base64=!1,q.binary=!0,T="",q.compression="STORE",V="string");var C=null;C=T instanceof m||T instanceof a?T:h.isNode&&h.isStream(T)?new f(L,T):r.prepareContent(L,T,q.binary,q.optimizedBinaryString,q.base64);var z=new b(L,C,q);this.files[L]=z}var l=i("./utf8"),r=i("./utils"),a=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),d=i("./defaults"),m=i("./compressedObject"),b=i("./zipObject"),u=i("./generate"),h=i("./nodejsUtils"),f=i("./nodejs/NodejsStreamInputAdapter"),v=function(L){L.slice(-1)==="/"&&(L=L.substring(0,L.length-1));var T=L.lastIndexOf("/");return 0<T?L.substring(0,T):""},k=function(L){return L.slice(-1)!=="/"&&(L+="/"),L},x=function(L,T){return T=T!==void 0?T:d.createFolders,L=k(L),this.files[L]||o.call(this,L,null,{dir:!0,createFolders:T}),this.files[L]};function $(L){return Object.prototype.toString.call(L)==="[object RegExp]"}var B={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(L){var T,w,W;for(T in this.files)W=this.files[T],(w=T.slice(this.root.length,T.length))&&T.slice(0,this.root.length)===this.root&&L(w,W)},filter:function(L){var T=[];return this.forEach(function(w,W){L(w,W)&&T.push(W)}),T},file:function(L,T,w){if(arguments.length!==1)return L=this.root+L,o.call(this,L,T,w),this;if($(L)){var W=L;return this.filter(function(q,X){return!X.dir&&W.test(q)})}var V=this.files[this.root+L];return V&&!V.dir?V:null},folder:function(L){if(!L)return this;if($(L))return this.filter(function(V,q){return q.dir&&L.test(V)});var T=this.root+L,w=x.call(this,T),W=this.clone();return W.root=w.name,W},remove:function(L){L=this.root+L;var T=this.files[L];if(T||(L.slice(-1)!=="/"&&(L+="/"),T=this.files[L]),T&&!T.dir)delete this.files[L];else for(var w=this.filter(function(V,q){return q.name.slice(0,L.length)===L}),W=0;W<w.length;W++)delete this.files[w[W].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(L){var T,w={};try{if((w=r.extend(L||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=w.type.toLowerCase(),w.compression=w.compression.toUpperCase(),w.type==="binarystring"&&(w.type="string"),!w.type)throw new Error("No output type specified.");r.checkSupport(w.type),w.platform!=="darwin"&&w.platform!=="freebsd"&&w.platform!=="linux"&&w.platform!=="sunos"||(w.platform="UNIX"),w.platform==="win32"&&(w.platform="DOS");var W=w.comment||this.comment||"";T=u.generateWorker(this,w,W)}catch(V){(T=new a("error")).error(V)}return new c(T,w.type||"string",w.mimeType)},generateAsync:function(L,T){return this.generateInternalStream(L).accumulate(T)},generateNodeStream:function(L,T){return(L=L||{}).type||(L.type="nodebuffer"),this.generateInternalStream(L).toNodejsStream(T)}};n.exports=B},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,n,s){n.exports=i("stream")},{stream:void 0}],17:[function(i,n,s){var o=i("./DataReader");function l(r){o.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}i("../utils").inherits(l,o),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),m=r.charCodeAt(3),b=this.length-4;0<=b;--b)if(this.data[b]===a&&this.data[b+1]===c&&this.data[b+2]===d&&this.data[b+3]===m)return b-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),m=r.charCodeAt(3),b=this.readData(4);return a===b[0]&&c===b[1]&&d===b[2]&&m===b[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(i,n,s){var o=i("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return o.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=l},{"../utils":32}],19:[function(i,n,s){var o=i("./Uint8ArrayReader");function l(r){o.call(this,r)}i("../utils").inherits(l,o),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,n,s){var o=i("./DataReader");function l(r){o.call(this,r)}i("../utils").inherits(l,o),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(i,n,s){var o=i("./ArrayReader");function l(r){o.call(this,r)}i("../utils").inherits(l,o),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(i,n,s){var o=i("../utils"),l=i("../support"),r=i("./ArrayReader"),a=i("./StringReader"),c=i("./NodeBufferReader"),d=i("./Uint8ArrayReader");n.exports=function(m){var b=o.getTypeOf(m);return o.checkSupport(b),b!=="string"||l.uint8array?b==="nodebuffer"?new c(m):l.uint8array?new d(o.transformTo("uint8array",m)):new r(o.transformTo("array",m)):new a(m)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,n,s){s.LOCAL_FILE_HEADER="PK",s.CENTRAL_FILE_HEADER="PK",s.CENTRAL_DIRECTORY_END="PK",s.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",s.ZIP64_CENTRAL_DIRECTORY_END="PK",s.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,n,s){var o=i("./GenericWorker"),l=i("../utils");function r(a){o.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,o),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,n,s){var o=i("./GenericWorker"),l=i("../crc32");function r(){o.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,o),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,n,s){var o=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}o.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,n,s){var o=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=o.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}o.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,o.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(o.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,n,s){function o(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}o.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=o},{}],29:[function(i,n,s){var o=i("../utils"),l=i("./ConvertWorker"),r=i("./GenericWorker"),a=i("../base64"),c=i("../support"),d=i("../external"),m=null;if(c.nodestream)try{m=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function b(h,f){return new d.Promise(function(v,k){var x=[],$=h._internalType,B=h._outputType,L=h._mimeType;h.on("data",function(T,w){x.push(T),f&&f(w)}).on("error",function(T){x=[],k(T)}).on("end",function(){try{var T=(function(w,W,V){switch(w){case"blob":return o.newBlob(o.transformTo("arraybuffer",W),V);case"base64":return a.encode(W);default:return o.transformTo(w,W)}})(B,(function(w,W){var V,q=0,X=null,C=0;for(V=0;V<W.length;V++)C+=W[V].length;switch(w){case"string":return W.join("");case"array":return Array.prototype.concat.apply([],W);case"uint8array":for(X=new Uint8Array(C),V=0;V<W.length;V++)X.set(W[V],q),q+=W[V].length;return X;case"nodebuffer":return Buffer.concat(W);default:throw new Error("concat : unsupported type '"+w+"'")}})($,x),L);v(T)}catch(w){k(w)}x=[]}).resume()})}function u(h,f,v){var k=f;switch(f){case"blob":case"arraybuffer":k="uint8array";break;case"base64":k="string"}try{this._internalType=k,this._outputType=f,this._mimeType=v,o.checkSupport(k),this._worker=h.pipe(new l(k)),h.lock()}catch(x){this._worker=new r("error"),this._worker.error(x)}}u.prototype={accumulate:function(h){return b(this,h)},on:function(h,f){var v=this;return h==="data"?this._worker.on(h,function(k){f.call(v,k.data,k.meta)}):this._worker.on(h,function(){o.delay(f,arguments,v)}),this},resume:function(){return o.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(h){if(o.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new m(this,{objectMode:this._outputType!=="nodebuffer"},h)}},n.exports=u},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,n,s){if(s.base64=!0,s.array=!0,s.string=!0,s.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",s.nodebuffer=typeof Buffer<"u",s.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")s.blob=!1;else{var o=new ArrayBuffer(0);try{s.blob=new Blob([o],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(o),s.blob=l.getBlob("application/zip").size===0}catch{s.blob=!1}}}try{s.nodestream=!!i("readable-stream").Readable}catch{s.nodestream=!1}},{"readable-stream":16}],31:[function(i,n,s){for(var o=i("./utils"),l=i("./support"),r=i("./nodejsUtils"),a=i("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function m(){a.call(this,"utf-8 decode"),this.leftOver=null}function b(){a.call(this,"utf-8 encode")}s.utf8encode=function(u){return l.nodebuffer?r.newBufferFrom(u,"utf-8"):(function(h){var f,v,k,x,$,B=h.length,L=0;for(x=0;x<B;x++)(64512&(v=h.charCodeAt(x)))==55296&&x+1<B&&(64512&(k=h.charCodeAt(x+1)))==56320&&(v=65536+(v-55296<<10)+(k-56320),x++),L+=v<128?1:v<2048?2:v<65536?3:4;for(f=l.uint8array?new Uint8Array(L):new Array(L),x=$=0;$<L;x++)(64512&(v=h.charCodeAt(x)))==55296&&x+1<B&&(64512&(k=h.charCodeAt(x+1)))==56320&&(v=65536+(v-55296<<10)+(k-56320),x++),v<128?f[$++]=v:(v<2048?f[$++]=192|v>>>6:(v<65536?f[$++]=224|v>>>12:(f[$++]=240|v>>>18,f[$++]=128|v>>>12&63),f[$++]=128|v>>>6&63),f[$++]=128|63&v);return f})(u)},s.utf8decode=function(u){return l.nodebuffer?o.transformTo("nodebuffer",u).toString("utf-8"):(function(h){var f,v,k,x,$=h.length,B=new Array(2*$);for(f=v=0;f<$;)if((k=h[f++])<128)B[v++]=k;else if(4<(x=c[k]))B[v++]=65533,f+=x-1;else{for(k&=x===2?31:x===3?15:7;1<x&&f<$;)k=k<<6|63&h[f++],x--;1<x?B[v++]=65533:k<65536?B[v++]=k:(k-=65536,B[v++]=55296|k>>10&1023,B[v++]=56320|1023&k)}return B.length!==v&&(B.subarray?B=B.subarray(0,v):B.length=v),o.applyFromCharCode(B)})(u=o.transformTo(l.uint8array?"uint8array":"array",u))},o.inherits(m,a),m.prototype.processChunk=function(u){var h=o.transformTo(l.uint8array?"uint8array":"array",u.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var f=h;(h=new Uint8Array(f.length+this.leftOver.length)).set(this.leftOver,0),h.set(f,this.leftOver.length)}else h=this.leftOver.concat(h);this.leftOver=null}var v=(function(x,$){var B;for(($=$||x.length)>x.length&&($=x.length),B=$-1;0<=B&&(192&x[B])==128;)B--;return B<0||B===0?$:B+c[x[B]]>$?B:$})(h),k=h;v!==h.length&&(l.uint8array?(k=h.subarray(0,v),this.leftOver=h.subarray(v,h.length)):(k=h.slice(0,v),this.leftOver=h.slice(v,h.length))),this.push({data:s.utf8decode(k),meta:u.meta})},m.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:s.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},s.Utf8DecodeWorker=m,o.inherits(b,a),b.prototype.processChunk=function(u){this.push({data:s.utf8encode(u.data),meta:u.meta})},s.Utf8EncodeWorker=b},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,n,s){var o=i("./support"),l=i("./base64"),r=i("./nodejsUtils"),a=i("./external");function c(f){return f}function d(f,v){for(var k=0;k<f.length;++k)v[k]=255&f.charCodeAt(k);return v}i("setimmediate"),s.newBlob=function(f,v){s.checkSupport("blob");try{return new Blob([f],{type:v})}catch{try{var k=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return k.append(f),k.getBlob(v)}catch{throw new Error("Bug : can't construct the Blob.")}}};var m={stringifyByChunk:function(f,v,k){var x=[],$=0,B=f.length;if(B<=k)return String.fromCharCode.apply(null,f);for(;$<B;)v==="array"||v==="nodebuffer"?x.push(String.fromCharCode.apply(null,f.slice($,Math.min($+k,B)))):x.push(String.fromCharCode.apply(null,f.subarray($,Math.min($+k,B)))),$+=k;return x.join("")},stringifyByChar:function(f){for(var v="",k=0;k<f.length;k++)v+=String.fromCharCode(f[k]);return v},applyCanBeUsed:{uint8array:(function(){try{return o.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return o.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function b(f){var v=65536,k=s.getTypeOf(f),x=!0;if(k==="uint8array"?x=m.applyCanBeUsed.uint8array:k==="nodebuffer"&&(x=m.applyCanBeUsed.nodebuffer),x)for(;1<v;)try{return m.stringifyByChunk(f,k,v)}catch{v=Math.floor(v/2)}return m.stringifyByChar(f)}function u(f,v){for(var k=0;k<f.length;k++)v[k]=f[k];return v}s.applyFromCharCode=b;var h={};h.string={string:c,array:function(f){return d(f,new Array(f.length))},arraybuffer:function(f){return h.string.uint8array(f).buffer},uint8array:function(f){return d(f,new Uint8Array(f.length))},nodebuffer:function(f){return d(f,r.allocBuffer(f.length))}},h.array={string:b,array:c,arraybuffer:function(f){return new Uint8Array(f).buffer},uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return r.newBufferFrom(f)}},h.arraybuffer={string:function(f){return b(new Uint8Array(f))},array:function(f){return u(new Uint8Array(f),new Array(f.byteLength))},arraybuffer:c,uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return r.newBufferFrom(new Uint8Array(f))}},h.uint8array={string:b,array:function(f){return u(f,new Array(f.length))},arraybuffer:function(f){return f.buffer},uint8array:c,nodebuffer:function(f){return r.newBufferFrom(f)}},h.nodebuffer={string:b,array:function(f){return u(f,new Array(f.length))},arraybuffer:function(f){return h.nodebuffer.uint8array(f).buffer},uint8array:function(f){return u(f,new Uint8Array(f.length))},nodebuffer:c},s.transformTo=function(f,v){if(v=v||"",!f)return v;s.checkSupport(f);var k=s.getTypeOf(v);return h[k][f](v)},s.resolve=function(f){for(var v=f.split("/"),k=[],x=0;x<v.length;x++){var $=v[x];$==="."||$===""&&x!==0&&x!==v.length-1||($===".."?k.pop():k.push($))}return k.join("/")},s.getTypeOf=function(f){return typeof f=="string"?"string":Object.prototype.toString.call(f)==="[object Array]"?"array":o.nodebuffer&&r.isBuffer(f)?"nodebuffer":o.uint8array&&f instanceof Uint8Array?"uint8array":o.arraybuffer&&f instanceof ArrayBuffer?"arraybuffer":void 0},s.checkSupport=function(f){if(!o[f.toLowerCase()])throw new Error(f+" is not supported by this platform")},s.MAX_VALUE_16BITS=65535,s.MAX_VALUE_32BITS=-1,s.pretty=function(f){var v,k,x="";for(k=0;k<(f||"").length;k++)x+="\\x"+((v=f.charCodeAt(k))<16?"0":"")+v.toString(16).toUpperCase();return x},s.delay=function(f,v,k){setImmediate(function(){f.apply(k||null,v||[])})},s.inherits=function(f,v){function k(){}k.prototype=v.prototype,f.prototype=new k},s.extend=function(){var f,v,k={};for(f=0;f<arguments.length;f++)for(v in arguments[f])Object.prototype.hasOwnProperty.call(arguments[f],v)&&k[v]===void 0&&(k[v]=arguments[f][v]);return k},s.prepareContent=function(f,v,k,x,$){return a.Promise.resolve(v).then(function(B){return o.blob&&(B instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(B))!==-1)&&typeof FileReader<"u"?new a.Promise(function(L,T){var w=new FileReader;w.onload=function(W){L(W.target.result)},w.onerror=function(W){T(W.target.error)},w.readAsArrayBuffer(B)}):B}).then(function(B){var L=s.getTypeOf(B);return L?(L==="arraybuffer"?B=s.transformTo("uint8array",B):L==="string"&&($?B=l.decode(B):k&&x!==!0&&(B=(function(T){return d(T,o.uint8array?new Uint8Array(T.length):new Array(T.length))})(B))),B):a.Promise.reject(new Error("Can't read the data of '"+f+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,n,s){var o=i("./reader/readerFor"),l=i("./utils"),r=i("./signature"),a=i("./zipEntry"),c=i("./support");function d(m){this.files=[],this.loadOptions=m}d.prototype={checkSignature:function(m){if(!this.reader.readAndCheckSignature(m)){this.reader.index-=4;var b=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(b)+", expected "+l.pretty(m)+")")}},isSignature:function(m,b){var u=this.reader.index;this.reader.setIndex(m);var h=this.reader.readString(4)===b;return this.reader.setIndex(u),h},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var m=this.reader.readData(this.zipCommentLength),b=c.uint8array?"uint8array":"array",u=l.transformTo(b,m);this.zipComment=this.loadOptions.decodeFileName(u)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var m,b,u,h=this.zip64EndOfCentralSize-44;0<h;)m=this.reader.readInt(2),b=this.reader.readInt(4),u=this.reader.readData(b),this.zip64ExtensibleData[m]={id:m,length:b,value:u}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var m,b;for(m=0;m<this.files.length;m++)b=this.files[m],this.reader.setIndex(b.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),b.readLocalPart(this.reader),b.handleUTF8(),b.processAttributes()},readCentralDir:function(){var m;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(m=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(m);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var m=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(m<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(m);var b=m;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(m=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(m),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var u=this.centralDirOffset+this.centralDirSize;this.zip64&&(u+=20,u+=12+this.zip64EndOfCentralSize);var h=b-u;if(0<h)this.isSignature(b,r.CENTRAL_FILE_HEADER)||(this.reader.zero=h);else if(h<0)throw new Error("Corrupted zip: missing "+Math.abs(h)+" bytes.")},prepareReader:function(m){this.reader=o(m)},load:function(m){this.prepareReader(m),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,n,s){var o=i("./reader/readerFor"),l=i("./utils"),r=i("./compressedObject"),a=i("./crc32"),c=i("./utf8"),d=i("./compressions"),m=i("./support");function b(u,h){this.options=u,this.loadOptions=h}b.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(u){var h,f;if(u.skip(22),this.fileNameLength=u.readInt(2),f=u.readInt(2),this.fileName=u.readData(this.fileNameLength),u.skip(f),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((h=(function(v){for(var k in d)if(Object.prototype.hasOwnProperty.call(d,k)&&d[k].magic===v)return d[k];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,h,u.readData(this.compressedSize))},readCentralPart:function(u){this.versionMadeBy=u.readInt(2),u.skip(2),this.bitFlag=u.readInt(2),this.compressionMethod=u.readString(2),this.date=u.readDate(),this.crc32=u.readInt(4),this.compressedSize=u.readInt(4),this.uncompressedSize=u.readInt(4);var h=u.readInt(2);if(this.extraFieldsLength=u.readInt(2),this.fileCommentLength=u.readInt(2),this.diskNumberStart=u.readInt(2),this.internalFileAttributes=u.readInt(2),this.externalFileAttributes=u.readInt(4),this.localHeaderOffset=u.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");u.skip(h),this.readExtraFields(u),this.parseZIP64ExtraField(u),this.fileComment=u.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var u=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),u==0&&(this.dosPermissions=63&this.externalFileAttributes),u==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var u=o(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=u.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=u.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=u.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=u.readInt(4))}},readExtraFields:function(u){var h,f,v,k=u.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});u.index+4<k;)h=u.readInt(2),f=u.readInt(2),v=u.readData(f),this.extraFields[h]={id:h,length:f,value:v};u.setIndex(k)},handleUTF8:function(){var u=m.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var h=this.findExtraFieldUnicodePath();if(h!==null)this.fileNameStr=h;else{var f=l.transformTo(u,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(f)}var v=this.findExtraFieldUnicodeComment();if(v!==null)this.fileCommentStr=v;else{var k=l.transformTo(u,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(k)}}},findExtraFieldUnicodePath:function(){var u=this.extraFields[28789];if(u){var h=o(u.value);return h.readInt(1)!==1||a(this.fileName)!==h.readInt(4)?null:c.utf8decode(h.readData(u.length-5))}return null},findExtraFieldUnicodeComment:function(){var u=this.extraFields[25461];if(u){var h=o(u.value);return h.readInt(1)!==1||a(this.fileComment)!==h.readInt(4)?null:c.utf8decode(h.readData(u.length-5))}return null}},n.exports=b},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,n,s){function o(h,f,v){this.name=h,this.dir=v.dir,this.date=v.date,this.comment=v.comment,this.unixPermissions=v.unixPermissions,this.dosPermissions=v.dosPermissions,this._data=f,this._dataBinary=v.binary,this.options={compression:v.compression,compressionOptions:v.compressionOptions}}var l=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),a=i("./utf8"),c=i("./compressedObject"),d=i("./stream/GenericWorker");o.prototype={internalStream:function(h){var f=null,v="string";try{if(!h)throw new Error("No output type specified.");var k=(v=h.toLowerCase())==="string"||v==="text";v!=="binarystring"&&v!=="text"||(v="string"),f=this._decompressWorker();var x=!this._dataBinary;x&&!k&&(f=f.pipe(new a.Utf8EncodeWorker)),!x&&k&&(f=f.pipe(new a.Utf8DecodeWorker))}catch($){(f=new d("error")).error($)}return new l(f,v,"")},async:function(h,f){return this.internalStream(h).accumulate(f)},nodeStream:function(h,f){return this.internalStream(h||"nodebuffer").toNodejsStream(f)},_compressWorker:function(h,f){if(this._data instanceof c&&this._data.compression.magic===h.magic)return this._data.getCompressedWorker();var v=this._decompressWorker();return this._dataBinary||(v=v.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(v,h,f)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new r(this._data)}};for(var m=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],b=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},u=0;u<m.length;u++)o.prototype[m[u]]=b;n.exports=o},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,n,s){(function(o){var l,r,a=o.MutationObserver||o.WebKitMutationObserver;if(a){var c=0,d=new a(h),m=o.document.createTextNode("");d.observe(m,{characterData:!0}),l=function(){m.data=c=++c%2}}else if(o.setImmediate||o.MessageChannel===void 0)l="document"in o&&"onreadystatechange"in o.document.createElement("script")?function(){var f=o.document.createElement("script");f.onreadystatechange=function(){h(),f.onreadystatechange=null,f.parentNode.removeChild(f),f=null},o.document.documentElement.appendChild(f)}:function(){setTimeout(h,0)};else{var b=new o.MessageChannel;b.port1.onmessage=h,l=function(){b.port2.postMessage(0)}}var u=[];function h(){var f,v;r=!0;for(var k=u.length;k;){for(v=u,u=[],f=-1;++f<k;)v[f]();k=u.length}r=!1}n.exports=function(f){u.push(f)!==1||r||l()}}).call(this,typeof Xn<"u"?Xn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,n,s){var o=i("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function m(k){if(typeof k!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,k!==l&&f(this,k)}function b(k,x,$){this.promise=k,typeof x=="function"&&(this.onFulfilled=x,this.callFulfilled=this.otherCallFulfilled),typeof $=="function"&&(this.onRejected=$,this.callRejected=this.otherCallRejected)}function u(k,x,$){o(function(){var B;try{B=x($)}catch(L){return r.reject(k,L)}B===k?r.reject(k,new TypeError("Cannot resolve promise with itself")):r.resolve(k,B)})}function h(k){var x=k&&k.then;if(k&&(typeof k=="object"||typeof k=="function")&&typeof x=="function")return function(){x.apply(k,arguments)}}function f(k,x){var $=!1;function B(w){$||($=!0,r.reject(k,w))}function L(w){$||($=!0,r.resolve(k,w))}var T=v(function(){x(L,B)});T.status==="error"&&B(T.value)}function v(k,x){var $={};try{$.value=k(x),$.status="success"}catch(B){$.status="error",$.value=B}return $}(n.exports=m).prototype.finally=function(k){if(typeof k!="function")return this;var x=this.constructor;return this.then(function($){return x.resolve(k()).then(function(){return $})},function($){return x.resolve(k()).then(function(){throw $})})},m.prototype.catch=function(k){return this.then(null,k)},m.prototype.then=function(k,x){if(typeof k!="function"&&this.state===c||typeof x!="function"&&this.state===a)return this;var $=new this.constructor(l);return this.state!==d?u($,this.state===c?k:x,this.outcome):this.queue.push(new b($,k,x)),$},b.prototype.callFulfilled=function(k){r.resolve(this.promise,k)},b.prototype.otherCallFulfilled=function(k){u(this.promise,this.onFulfilled,k)},b.prototype.callRejected=function(k){r.reject(this.promise,k)},b.prototype.otherCallRejected=function(k){u(this.promise,this.onRejected,k)},r.resolve=function(k,x){var $=v(h,x);if($.status==="error")return r.reject(k,$.value);var B=$.value;if(B)f(k,B);else{k.state=c,k.outcome=x;for(var L=-1,T=k.queue.length;++L<T;)k.queue[L].callFulfilled(x)}return k},r.reject=function(k,x){k.state=a,k.outcome=x;for(var $=-1,B=k.queue.length;++$<B;)k.queue[$].callRejected(x);return k},m.resolve=function(k){return k instanceof this?k:r.resolve(new this(l),k)},m.reject=function(k){var x=new this(l);return r.reject(x,k)},m.all=function(k){var x=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var $=k.length,B=!1;if(!$)return this.resolve([]);for(var L=new Array($),T=0,w=-1,W=new this(l);++w<$;)V(k[w],w);return W;function V(q,X){x.resolve(q).then(function(C){L[X]=C,++T!==$||B||(B=!0,r.resolve(W,L))},function(C){B||(B=!0,r.reject(W,C))})}},m.race=function(k){var x=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var $=k.length,B=!1;if(!$)return this.resolve([]);for(var L=-1,T=new this(l);++L<$;)w=k[L],x.resolve(w).then(function(W){B||(B=!0,r.resolve(T,W))},function(W){B||(B=!0,r.reject(T,W))});var w;return T}},{immediate:36}],38:[function(i,n,s){var o={};(0,i("./lib/utils/common").assign)(o,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),n.exports=o},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,n,s){var o=i("./zlib/deflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/messages"),c=i("./zlib/zstream"),d=Object.prototype.toString,m=0,b=-1,u=0,h=8;function f(k){if(!(this instanceof f))return new f(k);this.options=l.assign({level:b,method:h,chunkSize:16384,windowBits:15,memLevel:8,strategy:u,to:""},k||{});var x=this.options;x.raw&&0<x.windowBits?x.windowBits=-x.windowBits:x.gzip&&0<x.windowBits&&x.windowBits<16&&(x.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var $=o.deflateInit2(this.strm,x.level,x.method,x.windowBits,x.memLevel,x.strategy);if($!==m)throw new Error(a[$]);if(x.header&&o.deflateSetHeader(this.strm,x.header),x.dictionary){var B;if(B=typeof x.dictionary=="string"?r.string2buf(x.dictionary):d.call(x.dictionary)==="[object ArrayBuffer]"?new Uint8Array(x.dictionary):x.dictionary,($=o.deflateSetDictionary(this.strm,B))!==m)throw new Error(a[$]);this._dict_set=!0}}function v(k,x){var $=new f(x);if($.push(k,!0),$.err)throw $.msg||a[$.err];return $.result}f.prototype.push=function(k,x){var $,B,L=this.strm,T=this.options.chunkSize;if(this.ended)return!1;B=x===~~x?x:x===!0?4:0,typeof k=="string"?L.input=r.string2buf(k):d.call(k)==="[object ArrayBuffer]"?L.input=new Uint8Array(k):L.input=k,L.next_in=0,L.avail_in=L.input.length;do{if(L.avail_out===0&&(L.output=new l.Buf8(T),L.next_out=0,L.avail_out=T),($=o.deflate(L,B))!==1&&$!==m)return this.onEnd($),!(this.ended=!0);L.avail_out!==0&&(L.avail_in!==0||B!==4&&B!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(L.output,L.next_out))):this.onData(l.shrinkBuf(L.output,L.next_out)))}while((0<L.avail_in||L.avail_out===0)&&$!==1);return B===4?($=o.deflateEnd(this.strm),this.onEnd($),this.ended=!0,$===m):B!==2||(this.onEnd(m),!(L.avail_out=0))},f.prototype.onData=function(k){this.chunks.push(k)},f.prototype.onEnd=function(k){k===m&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=k,this.msg=this.strm.msg},s.Deflate=f,s.deflate=v,s.deflateRaw=function(k,x){return(x=x||{}).raw=!0,v(k,x)},s.gzip=function(k,x){return(x=x||{}).gzip=!0,v(k,x)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,n,s){var o=i("./zlib/inflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/constants"),c=i("./zlib/messages"),d=i("./zlib/zstream"),m=i("./zlib/gzheader"),b=Object.prototype.toString;function u(f){if(!(this instanceof u))return new u(f);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},f||{});var v=this.options;v.raw&&0<=v.windowBits&&v.windowBits<16&&(v.windowBits=-v.windowBits,v.windowBits===0&&(v.windowBits=-15)),!(0<=v.windowBits&&v.windowBits<16)||f&&f.windowBits||(v.windowBits+=32),15<v.windowBits&&v.windowBits<48&&(15&v.windowBits)==0&&(v.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var k=o.inflateInit2(this.strm,v.windowBits);if(k!==a.Z_OK)throw new Error(c[k]);this.header=new m,o.inflateGetHeader(this.strm,this.header)}function h(f,v){var k=new u(v);if(k.push(f,!0),k.err)throw k.msg||c[k.err];return k.result}u.prototype.push=function(f,v){var k,x,$,B,L,T,w=this.strm,W=this.options.chunkSize,V=this.options.dictionary,q=!1;if(this.ended)return!1;x=v===~~v?v:v===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof f=="string"?w.input=r.binstring2buf(f):b.call(f)==="[object ArrayBuffer]"?w.input=new Uint8Array(f):w.input=f,w.next_in=0,w.avail_in=w.input.length;do{if(w.avail_out===0&&(w.output=new l.Buf8(W),w.next_out=0,w.avail_out=W),(k=o.inflate(w,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&V&&(T=typeof V=="string"?r.string2buf(V):b.call(V)==="[object ArrayBuffer]"?new Uint8Array(V):V,k=o.inflateSetDictionary(this.strm,T)),k===a.Z_BUF_ERROR&&q===!0&&(k=a.Z_OK,q=!1),k!==a.Z_STREAM_END&&k!==a.Z_OK)return this.onEnd(k),!(this.ended=!0);w.next_out&&(w.avail_out!==0&&k!==a.Z_STREAM_END&&(w.avail_in!==0||x!==a.Z_FINISH&&x!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?($=r.utf8border(w.output,w.next_out),B=w.next_out-$,L=r.buf2string(w.output,$),w.next_out=B,w.avail_out=W-B,B&&l.arraySet(w.output,w.output,$,B,0),this.onData(L)):this.onData(l.shrinkBuf(w.output,w.next_out)))),w.avail_in===0&&w.avail_out===0&&(q=!0)}while((0<w.avail_in||w.avail_out===0)&&k!==a.Z_STREAM_END);return k===a.Z_STREAM_END&&(x=a.Z_FINISH),x===a.Z_FINISH?(k=o.inflateEnd(this.strm),this.onEnd(k),this.ended=!0,k===a.Z_OK):x!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(w.avail_out=0))},u.prototype.onData=function(f){this.chunks.push(f)},u.prototype.onEnd=function(f){f===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=f,this.msg=this.strm.msg},s.Inflate=u,s.inflate=h,s.inflateRaw=function(f,v){return(v=v||{}).raw=!0,h(f,v)},s.ungzip=h},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";s.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var m in d)d.hasOwnProperty(m)&&(a[m]=d[m])}}return a},s.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,m,b){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+m),b);else for(var u=0;u<m;u++)a[b+u]=c[d+u]},flattenChunks:function(a){var c,d,m,b,u,h;for(c=m=0,d=a.length;c<d;c++)m+=a[c].length;for(h=new Uint8Array(m),c=b=0,d=a.length;c<d;c++)u=a[c],h.set(u,b),b+=u.length;return h}},r={arraySet:function(a,c,d,m,b){for(var u=0;u<m;u++)a[b+u]=c[d+u]},flattenChunks:function(a){return[].concat.apply([],a)}};s.setTyped=function(a){a?(s.Buf8=Uint8Array,s.Buf16=Uint16Array,s.Buf32=Int32Array,s.assign(s,l)):(s.Buf8=Array,s.Buf16=Array,s.Buf32=Array,s.assign(s,r))},s.setTyped(o)},{}],42:[function(i,n,s){var o=i("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new o.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(m,b){if(b<65537&&(m.subarray&&r||!m.subarray&&l))return String.fromCharCode.apply(null,o.shrinkBuf(m,b));for(var u="",h=0;h<b;h++)u+=String.fromCharCode(m[h]);return u}a[254]=a[254]=1,s.string2buf=function(m){var b,u,h,f,v,k=m.length,x=0;for(f=0;f<k;f++)(64512&(u=m.charCodeAt(f)))==55296&&f+1<k&&(64512&(h=m.charCodeAt(f+1)))==56320&&(u=65536+(u-55296<<10)+(h-56320),f++),x+=u<128?1:u<2048?2:u<65536?3:4;for(b=new o.Buf8(x),f=v=0;v<x;f++)(64512&(u=m.charCodeAt(f)))==55296&&f+1<k&&(64512&(h=m.charCodeAt(f+1)))==56320&&(u=65536+(u-55296<<10)+(h-56320),f++),u<128?b[v++]=u:(u<2048?b[v++]=192|u>>>6:(u<65536?b[v++]=224|u>>>12:(b[v++]=240|u>>>18,b[v++]=128|u>>>12&63),b[v++]=128|u>>>6&63),b[v++]=128|63&u);return b},s.buf2binstring=function(m){return d(m,m.length)},s.binstring2buf=function(m){for(var b=new o.Buf8(m.length),u=0,h=b.length;u<h;u++)b[u]=m.charCodeAt(u);return b},s.buf2string=function(m,b){var u,h,f,v,k=b||m.length,x=new Array(2*k);for(u=h=0;u<k;)if((f=m[u++])<128)x[h++]=f;else if(4<(v=a[f]))x[h++]=65533,u+=v-1;else{for(f&=v===2?31:v===3?15:7;1<v&&u<k;)f=f<<6|63&m[u++],v--;1<v?x[h++]=65533:f<65536?x[h++]=f:(f-=65536,x[h++]=55296|f>>10&1023,x[h++]=56320|1023&f)}return d(x,h)},s.utf8border=function(m,b){var u;for((b=b||m.length)>m.length&&(b=m.length),u=b-1;0<=u&&(192&m[u])==128;)u--;return u<0||u===0?b:u+a[m[u]]>b?u:b}},{"./common":41}],43:[function(i,n,s){n.exports=function(o,l,r,a){for(var c=65535&o|0,d=o>>>16&65535|0,m=0;r!==0;){for(r-=m=2e3<r?2e3:r;d=d+(c=c+l[a++]|0)|0,--m;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(i,n,s){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,n,s){var o=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();n.exports=function(l,r,a,c){var d=o,m=c+a;l^=-1;for(var b=c;b<m;b++)l=l>>>8^d[255&(l^r[b])];return-1^l}},{}],46:[function(i,n,s){var o,l=i("../utils/common"),r=i("./trees"),a=i("./adler32"),c=i("./crc32"),d=i("./messages"),m=0,b=4,u=0,h=-2,f=-1,v=4,k=2,x=8,$=9,B=286,L=30,T=19,w=2*B+1,W=15,V=3,q=258,X=q+V+1,C=42,z=113,y=1,D=2,U=3,E=4;function P(g,N){return g.msg=d[N],N}function j(g){return(g<<1)-(4<g?9:0)}function tt(g){for(var N=g.length;0<=--N;)g[N]=0}function A(g){var N=g.state,F=N.pending;F>g.avail_out&&(F=g.avail_out),F!==0&&(l.arraySet(g.output,N.pending_buf,N.pending_out,F,g.next_out),g.next_out+=F,N.pending_out+=F,g.total_out+=F,g.avail_out-=F,N.pending-=F,N.pending===0&&(N.pending_out=0))}function M(g,N){r._tr_flush_block(g,0<=g.block_start?g.block_start:-1,g.strstart-g.block_start,N),g.block_start=g.strstart,A(g.strm)}function Y(g,N){g.pending_buf[g.pending++]=N}function J(g,N){g.pending_buf[g.pending++]=N>>>8&255,g.pending_buf[g.pending++]=255&N}function et(g,N){var F,S,I=g.max_chain_length,R=g.strstart,Z=g.prev_length,G=g.nice_match,K=g.strstart>g.w_size-X?g.strstart-(g.w_size-X):0,nt=g.window,ct=g.w_mask,rt=g.prev,mt=g.strstart+q,$t=nt[R+Z-1],xt=nt[R+Z];g.prev_length>=g.good_match&&(I>>=2),G>g.lookahead&&(G=g.lookahead);do if(nt[(F=N)+Z]===xt&&nt[F+Z-1]===$t&&nt[F]===nt[R]&&nt[++F]===nt[R+1]){R+=2,F++;do;while(nt[++R]===nt[++F]&&nt[++R]===nt[++F]&&nt[++R]===nt[++F]&&nt[++R]===nt[++F]&&nt[++R]===nt[++F]&&nt[++R]===nt[++F]&&nt[++R]===nt[++F]&&nt[++R]===nt[++F]&&R<mt);if(S=q-(mt-R),R=mt-q,Z<S){if(g.match_start=N,G<=(Z=S))break;$t=nt[R+Z-1],xt=nt[R+Z]}}while((N=rt[N&ct])>K&&--I!=0);return Z<=g.lookahead?Z:g.lookahead}function it(g){var N,F,S,I,R,Z,G,K,nt,ct,rt=g.w_size;do{if(I=g.window_size-g.lookahead-g.strstart,g.strstart>=rt+(rt-X)){for(l.arraySet(g.window,g.window,rt,rt,0),g.match_start-=rt,g.strstart-=rt,g.block_start-=rt,N=F=g.hash_size;S=g.head[--N],g.head[N]=rt<=S?S-rt:0,--F;);for(N=F=rt;S=g.prev[--N],g.prev[N]=rt<=S?S-rt:0,--F;);I+=rt}if(g.strm.avail_in===0)break;if(Z=g.strm,G=g.window,K=g.strstart+g.lookahead,nt=I,ct=void 0,ct=Z.avail_in,nt<ct&&(ct=nt),F=ct===0?0:(Z.avail_in-=ct,l.arraySet(G,Z.input,Z.next_in,ct,K),Z.state.wrap===1?Z.adler=a(Z.adler,G,ct,K):Z.state.wrap===2&&(Z.adler=c(Z.adler,G,ct,K)),Z.next_in+=ct,Z.total_in+=ct,ct),g.lookahead+=F,g.lookahead+g.insert>=V)for(R=g.strstart-g.insert,g.ins_h=g.window[R],g.ins_h=(g.ins_h<<g.hash_shift^g.window[R+1])&g.hash_mask;g.insert&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[R+V-1])&g.hash_mask,g.prev[R&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=R,R++,g.insert--,!(g.lookahead+g.insert<V)););}while(g.lookahead<X&&g.strm.avail_in!==0)}function pt(g,N){for(var F,S;;){if(g.lookahead<X){if(it(g),g.lookahead<X&&N===m)return y;if(g.lookahead===0)break}if(F=0,g.lookahead>=V&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+V-1])&g.hash_mask,F=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),F!==0&&g.strstart-F<=g.w_size-X&&(g.match_length=et(g,F)),g.match_length>=V)if(S=r._tr_tally(g,g.strstart-g.match_start,g.match_length-V),g.lookahead-=g.match_length,g.match_length<=g.max_lazy_match&&g.lookahead>=V){for(g.match_length--;g.strstart++,g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+V-1])&g.hash_mask,F=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart,--g.match_length!=0;);g.strstart++}else g.strstart+=g.match_length,g.match_length=0,g.ins_h=g.window[g.strstart],g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+1])&g.hash_mask;else S=r._tr_tally(g,0,g.window[g.strstart]),g.lookahead--,g.strstart++;if(S&&(M(g,!1),g.strm.avail_out===0))return y}return g.insert=g.strstart<V-1?g.strstart:V-1,N===b?(M(g,!0),g.strm.avail_out===0?U:E):g.last_lit&&(M(g,!1),g.strm.avail_out===0)?y:D}function lt(g,N){for(var F,S,I;;){if(g.lookahead<X){if(it(g),g.lookahead<X&&N===m)return y;if(g.lookahead===0)break}if(F=0,g.lookahead>=V&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+V-1])&g.hash_mask,F=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),g.prev_length=g.match_length,g.prev_match=g.match_start,g.match_length=V-1,F!==0&&g.prev_length<g.max_lazy_match&&g.strstart-F<=g.w_size-X&&(g.match_length=et(g,F),g.match_length<=5&&(g.strategy===1||g.match_length===V&&4096<g.strstart-g.match_start)&&(g.match_length=V-1)),g.prev_length>=V&&g.match_length<=g.prev_length){for(I=g.strstart+g.lookahead-V,S=r._tr_tally(g,g.strstart-1-g.prev_match,g.prev_length-V),g.lookahead-=g.prev_length-1,g.prev_length-=2;++g.strstart<=I&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+V-1])&g.hash_mask,F=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),--g.prev_length!=0;);if(g.match_available=0,g.match_length=V-1,g.strstart++,S&&(M(g,!1),g.strm.avail_out===0))return y}else if(g.match_available){if((S=r._tr_tally(g,0,g.window[g.strstart-1]))&&M(g,!1),g.strstart++,g.lookahead--,g.strm.avail_out===0)return y}else g.match_available=1,g.strstart++,g.lookahead--}return g.match_available&&(S=r._tr_tally(g,0,g.window[g.strstart-1]),g.match_available=0),g.insert=g.strstart<V-1?g.strstart:V-1,N===b?(M(g,!0),g.strm.avail_out===0?U:E):g.last_lit&&(M(g,!1),g.strm.avail_out===0)?y:D}function H(g,N,F,S,I){this.good_length=g,this.max_lazy=N,this.nice_length=F,this.max_chain=S,this.func=I}function at(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=x,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*w),this.dyn_dtree=new l.Buf16(2*(2*L+1)),this.bl_tree=new l.Buf16(2*(2*T+1)),tt(this.dyn_ltree),tt(this.dyn_dtree),tt(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(W+1),this.heap=new l.Buf16(2*B+1),tt(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*B+1),tt(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ut(g){var N;return g&&g.state?(g.total_in=g.total_out=0,g.data_type=k,(N=g.state).pending=0,N.pending_out=0,N.wrap<0&&(N.wrap=-N.wrap),N.status=N.wrap?C:z,g.adler=N.wrap===2?0:1,N.last_flush=m,r._tr_init(N),u):P(g,h)}function _(g){var N=ut(g);return N===u&&(function(F){F.window_size=2*F.w_size,tt(F.head),F.max_lazy_match=o[F.level].max_lazy,F.good_match=o[F.level].good_length,F.nice_match=o[F.level].nice_length,F.max_chain_length=o[F.level].max_chain,F.strstart=0,F.block_start=0,F.lookahead=0,F.insert=0,F.match_length=F.prev_length=V-1,F.match_available=0,F.ins_h=0})(g.state),N}function O(g,N,F,S,I,R){if(!g)return h;var Z=1;if(N===f&&(N=6),S<0?(Z=0,S=-S):15<S&&(Z=2,S-=16),I<1||$<I||F!==x||S<8||15<S||N<0||9<N||R<0||v<R)return P(g,h);S===8&&(S=9);var G=new at;return(g.state=G).strm=g,G.wrap=Z,G.gzhead=null,G.w_bits=S,G.w_size=1<<G.w_bits,G.w_mask=G.w_size-1,G.hash_bits=I+7,G.hash_size=1<<G.hash_bits,G.hash_mask=G.hash_size-1,G.hash_shift=~~((G.hash_bits+V-1)/V),G.window=new l.Buf8(2*G.w_size),G.head=new l.Buf16(G.hash_size),G.prev=new l.Buf16(G.w_size),G.lit_bufsize=1<<I+6,G.pending_buf_size=4*G.lit_bufsize,G.pending_buf=new l.Buf8(G.pending_buf_size),G.d_buf=1*G.lit_bufsize,G.l_buf=3*G.lit_bufsize,G.level=N,G.strategy=R,G.method=F,_(g)}o=[new H(0,0,0,0,function(g,N){var F=65535;for(F>g.pending_buf_size-5&&(F=g.pending_buf_size-5);;){if(g.lookahead<=1){if(it(g),g.lookahead===0&&N===m)return y;if(g.lookahead===0)break}g.strstart+=g.lookahead,g.lookahead=0;var S=g.block_start+F;if((g.strstart===0||g.strstart>=S)&&(g.lookahead=g.strstart-S,g.strstart=S,M(g,!1),g.strm.avail_out===0)||g.strstart-g.block_start>=g.w_size-X&&(M(g,!1),g.strm.avail_out===0))return y}return g.insert=0,N===b?(M(g,!0),g.strm.avail_out===0?U:E):(g.strstart>g.block_start&&(M(g,!1),g.strm.avail_out),y)}),new H(4,4,8,4,pt),new H(4,5,16,8,pt),new H(4,6,32,32,pt),new H(4,4,16,16,lt),new H(8,16,32,32,lt),new H(8,16,128,128,lt),new H(8,32,128,256,lt),new H(32,128,258,1024,lt),new H(32,258,258,4096,lt)],s.deflateInit=function(g,N){return O(g,N,x,15,8,0)},s.deflateInit2=O,s.deflateReset=_,s.deflateResetKeep=ut,s.deflateSetHeader=function(g,N){return g&&g.state?g.state.wrap!==2?h:(g.state.gzhead=N,u):h},s.deflate=function(g,N){var F,S,I,R;if(!g||!g.state||5<N||N<0)return g?P(g,h):h;if(S=g.state,!g.output||!g.input&&g.avail_in!==0||S.status===666&&N!==b)return P(g,g.avail_out===0?-5:h);if(S.strm=g,F=S.last_flush,S.last_flush=N,S.status===C)if(S.wrap===2)g.adler=0,Y(S,31),Y(S,139),Y(S,8),S.gzhead?(Y(S,(S.gzhead.text?1:0)+(S.gzhead.hcrc?2:0)+(S.gzhead.extra?4:0)+(S.gzhead.name?8:0)+(S.gzhead.comment?16:0)),Y(S,255&S.gzhead.time),Y(S,S.gzhead.time>>8&255),Y(S,S.gzhead.time>>16&255),Y(S,S.gzhead.time>>24&255),Y(S,S.level===9?2:2<=S.strategy||S.level<2?4:0),Y(S,255&S.gzhead.os),S.gzhead.extra&&S.gzhead.extra.length&&(Y(S,255&S.gzhead.extra.length),Y(S,S.gzhead.extra.length>>8&255)),S.gzhead.hcrc&&(g.adler=c(g.adler,S.pending_buf,S.pending,0)),S.gzindex=0,S.status=69):(Y(S,0),Y(S,0),Y(S,0),Y(S,0),Y(S,0),Y(S,S.level===9?2:2<=S.strategy||S.level<2?4:0),Y(S,3),S.status=z);else{var Z=x+(S.w_bits-8<<4)<<8;Z|=(2<=S.strategy||S.level<2?0:S.level<6?1:S.level===6?2:3)<<6,S.strstart!==0&&(Z|=32),Z+=31-Z%31,S.status=z,J(S,Z),S.strstart!==0&&(J(S,g.adler>>>16),J(S,65535&g.adler)),g.adler=1}if(S.status===69)if(S.gzhead.extra){for(I=S.pending;S.gzindex<(65535&S.gzhead.extra.length)&&(S.pending!==S.pending_buf_size||(S.gzhead.hcrc&&S.pending>I&&(g.adler=c(g.adler,S.pending_buf,S.pending-I,I)),A(g),I=S.pending,S.pending!==S.pending_buf_size));)Y(S,255&S.gzhead.extra[S.gzindex]),S.gzindex++;S.gzhead.hcrc&&S.pending>I&&(g.adler=c(g.adler,S.pending_buf,S.pending-I,I)),S.gzindex===S.gzhead.extra.length&&(S.gzindex=0,S.status=73)}else S.status=73;if(S.status===73)if(S.gzhead.name){I=S.pending;do{if(S.pending===S.pending_buf_size&&(S.gzhead.hcrc&&S.pending>I&&(g.adler=c(g.adler,S.pending_buf,S.pending-I,I)),A(g),I=S.pending,S.pending===S.pending_buf_size)){R=1;break}R=S.gzindex<S.gzhead.name.length?255&S.gzhead.name.charCodeAt(S.gzindex++):0,Y(S,R)}while(R!==0);S.gzhead.hcrc&&S.pending>I&&(g.adler=c(g.adler,S.pending_buf,S.pending-I,I)),R===0&&(S.gzindex=0,S.status=91)}else S.status=91;if(S.status===91)if(S.gzhead.comment){I=S.pending;do{if(S.pending===S.pending_buf_size&&(S.gzhead.hcrc&&S.pending>I&&(g.adler=c(g.adler,S.pending_buf,S.pending-I,I)),A(g),I=S.pending,S.pending===S.pending_buf_size)){R=1;break}R=S.gzindex<S.gzhead.comment.length?255&S.gzhead.comment.charCodeAt(S.gzindex++):0,Y(S,R)}while(R!==0);S.gzhead.hcrc&&S.pending>I&&(g.adler=c(g.adler,S.pending_buf,S.pending-I,I)),R===0&&(S.status=103)}else S.status=103;if(S.status===103&&(S.gzhead.hcrc?(S.pending+2>S.pending_buf_size&&A(g),S.pending+2<=S.pending_buf_size&&(Y(S,255&g.adler),Y(S,g.adler>>8&255),g.adler=0,S.status=z)):S.status=z),S.pending!==0){if(A(g),g.avail_out===0)return S.last_flush=-1,u}else if(g.avail_in===0&&j(N)<=j(F)&&N!==b)return P(g,-5);if(S.status===666&&g.avail_in!==0)return P(g,-5);if(g.avail_in!==0||S.lookahead!==0||N!==m&&S.status!==666){var G=S.strategy===2?(function(K,nt){for(var ct;;){if(K.lookahead===0&&(it(K),K.lookahead===0)){if(nt===m)return y;break}if(K.match_length=0,ct=r._tr_tally(K,0,K.window[K.strstart]),K.lookahead--,K.strstart++,ct&&(M(K,!1),K.strm.avail_out===0))return y}return K.insert=0,nt===b?(M(K,!0),K.strm.avail_out===0?U:E):K.last_lit&&(M(K,!1),K.strm.avail_out===0)?y:D})(S,N):S.strategy===3?(function(K,nt){for(var ct,rt,mt,$t,xt=K.window;;){if(K.lookahead<=q){if(it(K),K.lookahead<=q&&nt===m)return y;if(K.lookahead===0)break}if(K.match_length=0,K.lookahead>=V&&0<K.strstart&&(rt=xt[mt=K.strstart-1])===xt[++mt]&&rt===xt[++mt]&&rt===xt[++mt]){$t=K.strstart+q;do;while(rt===xt[++mt]&&rt===xt[++mt]&&rt===xt[++mt]&&rt===xt[++mt]&&rt===xt[++mt]&&rt===xt[++mt]&&rt===xt[++mt]&&rt===xt[++mt]&&mt<$t);K.match_length=q-($t-mt),K.match_length>K.lookahead&&(K.match_length=K.lookahead)}if(K.match_length>=V?(ct=r._tr_tally(K,1,K.match_length-V),K.lookahead-=K.match_length,K.strstart+=K.match_length,K.match_length=0):(ct=r._tr_tally(K,0,K.window[K.strstart]),K.lookahead--,K.strstart++),ct&&(M(K,!1),K.strm.avail_out===0))return y}return K.insert=0,nt===b?(M(K,!0),K.strm.avail_out===0?U:E):K.last_lit&&(M(K,!1),K.strm.avail_out===0)?y:D})(S,N):o[S.level].func(S,N);if(G!==U&&G!==E||(S.status=666),G===y||G===U)return g.avail_out===0&&(S.last_flush=-1),u;if(G===D&&(N===1?r._tr_align(S):N!==5&&(r._tr_stored_block(S,0,0,!1),N===3&&(tt(S.head),S.lookahead===0&&(S.strstart=0,S.block_start=0,S.insert=0))),A(g),g.avail_out===0))return S.last_flush=-1,u}return N!==b?u:S.wrap<=0?1:(S.wrap===2?(Y(S,255&g.adler),Y(S,g.adler>>8&255),Y(S,g.adler>>16&255),Y(S,g.adler>>24&255),Y(S,255&g.total_in),Y(S,g.total_in>>8&255),Y(S,g.total_in>>16&255),Y(S,g.total_in>>24&255)):(J(S,g.adler>>>16),J(S,65535&g.adler)),A(g),0<S.wrap&&(S.wrap=-S.wrap),S.pending!==0?u:1)},s.deflateEnd=function(g){var N;return g&&g.state?(N=g.state.status)!==C&&N!==69&&N!==73&&N!==91&&N!==103&&N!==z&&N!==666?P(g,h):(g.state=null,N===z?P(g,-3):u):h},s.deflateSetDictionary=function(g,N){var F,S,I,R,Z,G,K,nt,ct=N.length;if(!g||!g.state||(R=(F=g.state).wrap)===2||R===1&&F.status!==C||F.lookahead)return h;for(R===1&&(g.adler=a(g.adler,N,ct,0)),F.wrap=0,ct>=F.w_size&&(R===0&&(tt(F.head),F.strstart=0,F.block_start=0,F.insert=0),nt=new l.Buf8(F.w_size),l.arraySet(nt,N,ct-F.w_size,F.w_size,0),N=nt,ct=F.w_size),Z=g.avail_in,G=g.next_in,K=g.input,g.avail_in=ct,g.next_in=0,g.input=N,it(F);F.lookahead>=V;){for(S=F.strstart,I=F.lookahead-(V-1);F.ins_h=(F.ins_h<<F.hash_shift^F.window[S+V-1])&F.hash_mask,F.prev[S&F.w_mask]=F.head[F.ins_h],F.head[F.ins_h]=S,S++,--I;);F.strstart=S,F.lookahead=V-1,it(F)}return F.strstart+=F.lookahead,F.block_start=F.strstart,F.insert=F.lookahead,F.lookahead=0,F.match_length=F.prev_length=V-1,F.match_available=0,g.next_in=G,g.input=K,g.avail_in=Z,F.wrap=R,u},s.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,n,s){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,n,s){n.exports=function(o,l){var r,a,c,d,m,b,u,h,f,v,k,x,$,B,L,T,w,W,V,q,X,C,z,y,D;r=o.state,a=o.next_in,y=o.input,c=a+(o.avail_in-5),d=o.next_out,D=o.output,m=d-(l-o.avail_out),b=d+(o.avail_out-257),u=r.dmax,h=r.wsize,f=r.whave,v=r.wnext,k=r.window,x=r.hold,$=r.bits,B=r.lencode,L=r.distcode,T=(1<<r.lenbits)-1,w=(1<<r.distbits)-1;t:do{$<15&&(x+=y[a++]<<$,$+=8,x+=y[a++]<<$,$+=8),W=B[x&T];e:for(;;){if(x>>>=V=W>>>24,$-=V,(V=W>>>16&255)===0)D[d++]=65535&W;else{if(!(16&V)){if((64&V)==0){W=B[(65535&W)+(x&(1<<V)-1)];continue e}if(32&V){r.mode=12;break t}o.msg="invalid literal/length code",r.mode=30;break t}q=65535&W,(V&=15)&&($<V&&(x+=y[a++]<<$,$+=8),q+=x&(1<<V)-1,x>>>=V,$-=V),$<15&&(x+=y[a++]<<$,$+=8,x+=y[a++]<<$,$+=8),W=L[x&w];i:for(;;){if(x>>>=V=W>>>24,$-=V,!(16&(V=W>>>16&255))){if((64&V)==0){W=L[(65535&W)+(x&(1<<V)-1)];continue i}o.msg="invalid distance code",r.mode=30;break t}if(X=65535&W,$<(V&=15)&&(x+=y[a++]<<$,($+=8)<V&&(x+=y[a++]<<$,$+=8)),u<(X+=x&(1<<V)-1)){o.msg="invalid distance too far back",r.mode=30;break t}if(x>>>=V,$-=V,(V=d-m)<X){if(f<(V=X-V)&&r.sane){o.msg="invalid distance too far back",r.mode=30;break t}if(z=k,(C=0)===v){if(C+=h-V,V<q){for(q-=V;D[d++]=k[C++],--V;);C=d-X,z=D}}else if(v<V){if(C+=h+v-V,(V-=v)<q){for(q-=V;D[d++]=k[C++],--V;);if(C=0,v<q){for(q-=V=v;D[d++]=k[C++],--V;);C=d-X,z=D}}}else if(C+=v-V,V<q){for(q-=V;D[d++]=k[C++],--V;);C=d-X,z=D}for(;2<q;)D[d++]=z[C++],D[d++]=z[C++],D[d++]=z[C++],q-=3;q&&(D[d++]=z[C++],1<q&&(D[d++]=z[C++]))}else{for(C=d-X;D[d++]=D[C++],D[d++]=D[C++],D[d++]=D[C++],2<(q-=3););q&&(D[d++]=D[C++],1<q&&(D[d++]=D[C++]))}break}}break}}while(a<c&&d<b);a-=q=$>>3,x&=(1<<($-=q<<3))-1,o.next_in=a,o.next_out=d,o.avail_in=a<c?c-a+5:5-(a-c),o.avail_out=d<b?b-d+257:257-(d-b),r.hold=x,r.bits=$}},{}],49:[function(i,n,s){var o=i("../utils/common"),l=i("./adler32"),r=i("./crc32"),a=i("./inffast"),c=i("./inftrees"),d=1,m=2,b=0,u=-2,h=1,f=852,v=592;function k(C){return(C>>>24&255)+(C>>>8&65280)+((65280&C)<<8)+((255&C)<<24)}function x(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new o.Buf16(320),this.work=new o.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function $(C){var z;return C&&C.state?(z=C.state,C.total_in=C.total_out=z.total=0,C.msg="",z.wrap&&(C.adler=1&z.wrap),z.mode=h,z.last=0,z.havedict=0,z.dmax=32768,z.head=null,z.hold=0,z.bits=0,z.lencode=z.lendyn=new o.Buf32(f),z.distcode=z.distdyn=new o.Buf32(v),z.sane=1,z.back=-1,b):u}function B(C){var z;return C&&C.state?((z=C.state).wsize=0,z.whave=0,z.wnext=0,$(C)):u}function L(C,z){var y,D;return C&&C.state?(D=C.state,z<0?(y=0,z=-z):(y=1+(z>>4),z<48&&(z&=15)),z&&(z<8||15<z)?u:(D.window!==null&&D.wbits!==z&&(D.window=null),D.wrap=y,D.wbits=z,B(C))):u}function T(C,z){var y,D;return C?(D=new x,(C.state=D).window=null,(y=L(C,z))!==b&&(C.state=null),y):u}var w,W,V=!0;function q(C){if(V){var z;for(w=new o.Buf32(512),W=new o.Buf32(32),z=0;z<144;)C.lens[z++]=8;for(;z<256;)C.lens[z++]=9;for(;z<280;)C.lens[z++]=7;for(;z<288;)C.lens[z++]=8;for(c(d,C.lens,0,288,w,0,C.work,{bits:9}),z=0;z<32;)C.lens[z++]=5;c(m,C.lens,0,32,W,0,C.work,{bits:5}),V=!1}C.lencode=w,C.lenbits=9,C.distcode=W,C.distbits=5}function X(C,z,y,D){var U,E=C.state;return E.window===null&&(E.wsize=1<<E.wbits,E.wnext=0,E.whave=0,E.window=new o.Buf8(E.wsize)),D>=E.wsize?(o.arraySet(E.window,z,y-E.wsize,E.wsize,0),E.wnext=0,E.whave=E.wsize):(D<(U=E.wsize-E.wnext)&&(U=D),o.arraySet(E.window,z,y-D,U,E.wnext),(D-=U)?(o.arraySet(E.window,z,y-D,D,0),E.wnext=D,E.whave=E.wsize):(E.wnext+=U,E.wnext===E.wsize&&(E.wnext=0),E.whave<E.wsize&&(E.whave+=U))),0}s.inflateReset=B,s.inflateReset2=L,s.inflateResetKeep=$,s.inflateInit=function(C){return T(C,15)},s.inflateInit2=T,s.inflate=function(C,z){var y,D,U,E,P,j,tt,A,M,Y,J,et,it,pt,lt,H,at,ut,_,O,g,N,F,S,I=0,R=new o.Buf8(4),Z=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!C||!C.state||!C.output||!C.input&&C.avail_in!==0)return u;(y=C.state).mode===12&&(y.mode=13),P=C.next_out,U=C.output,tt=C.avail_out,E=C.next_in,D=C.input,j=C.avail_in,A=y.hold,M=y.bits,Y=j,J=tt,N=b;t:for(;;)switch(y.mode){case h:if(y.wrap===0){y.mode=13;break}for(;M<16;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if(2&y.wrap&&A===35615){R[y.check=0]=255&A,R[1]=A>>>8&255,y.check=r(y.check,R,2,0),M=A=0,y.mode=2;break}if(y.flags=0,y.head&&(y.head.done=!1),!(1&y.wrap)||(((255&A)<<8)+(A>>8))%31){C.msg="incorrect header check",y.mode=30;break}if((15&A)!=8){C.msg="unknown compression method",y.mode=30;break}if(M-=4,g=8+(15&(A>>>=4)),y.wbits===0)y.wbits=g;else if(g>y.wbits){C.msg="invalid window size",y.mode=30;break}y.dmax=1<<g,C.adler=y.check=1,y.mode=512&A?10:12,M=A=0;break;case 2:for(;M<16;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if(y.flags=A,(255&y.flags)!=8){C.msg="unknown compression method",y.mode=30;break}if(57344&y.flags){C.msg="unknown header flags set",y.mode=30;break}y.head&&(y.head.text=A>>8&1),512&y.flags&&(R[0]=255&A,R[1]=A>>>8&255,y.check=r(y.check,R,2,0)),M=A=0,y.mode=3;case 3:for(;M<32;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}y.head&&(y.head.time=A),512&y.flags&&(R[0]=255&A,R[1]=A>>>8&255,R[2]=A>>>16&255,R[3]=A>>>24&255,y.check=r(y.check,R,4,0)),M=A=0,y.mode=4;case 4:for(;M<16;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}y.head&&(y.head.xflags=255&A,y.head.os=A>>8),512&y.flags&&(R[0]=255&A,R[1]=A>>>8&255,y.check=r(y.check,R,2,0)),M=A=0,y.mode=5;case 5:if(1024&y.flags){for(;M<16;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}y.length=A,y.head&&(y.head.extra_len=A),512&y.flags&&(R[0]=255&A,R[1]=A>>>8&255,y.check=r(y.check,R,2,0)),M=A=0}else y.head&&(y.head.extra=null);y.mode=6;case 6:if(1024&y.flags&&(j<(et=y.length)&&(et=j),et&&(y.head&&(g=y.head.extra_len-y.length,y.head.extra||(y.head.extra=new Array(y.head.extra_len)),o.arraySet(y.head.extra,D,E,et,g)),512&y.flags&&(y.check=r(y.check,D,et,E)),j-=et,E+=et,y.length-=et),y.length))break t;y.length=0,y.mode=7;case 7:if(2048&y.flags){if(j===0)break t;for(et=0;g=D[E+et++],y.head&&g&&y.length<65536&&(y.head.name+=String.fromCharCode(g)),g&&et<j;);if(512&y.flags&&(y.check=r(y.check,D,et,E)),j-=et,E+=et,g)break t}else y.head&&(y.head.name=null);y.length=0,y.mode=8;case 8:if(4096&y.flags){if(j===0)break t;for(et=0;g=D[E+et++],y.head&&g&&y.length<65536&&(y.head.comment+=String.fromCharCode(g)),g&&et<j;);if(512&y.flags&&(y.check=r(y.check,D,et,E)),j-=et,E+=et,g)break t}else y.head&&(y.head.comment=null);y.mode=9;case 9:if(512&y.flags){for(;M<16;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if(A!==(65535&y.check)){C.msg="header crc mismatch",y.mode=30;break}M=A=0}y.head&&(y.head.hcrc=y.flags>>9&1,y.head.done=!0),C.adler=y.check=0,y.mode=12;break;case 10:for(;M<32;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}C.adler=y.check=k(A),M=A=0,y.mode=11;case 11:if(y.havedict===0)return C.next_out=P,C.avail_out=tt,C.next_in=E,C.avail_in=j,y.hold=A,y.bits=M,2;C.adler=y.check=1,y.mode=12;case 12:if(z===5||z===6)break t;case 13:if(y.last){A>>>=7&M,M-=7&M,y.mode=27;break}for(;M<3;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}switch(y.last=1&A,M-=1,3&(A>>>=1)){case 0:y.mode=14;break;case 1:if(q(y),y.mode=20,z!==6)break;A>>>=2,M-=2;break t;case 2:y.mode=17;break;case 3:C.msg="invalid block type",y.mode=30}A>>>=2,M-=2;break;case 14:for(A>>>=7&M,M-=7&M;M<32;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if((65535&A)!=(A>>>16^65535)){C.msg="invalid stored block lengths",y.mode=30;break}if(y.length=65535&A,M=A=0,y.mode=15,z===6)break t;case 15:y.mode=16;case 16:if(et=y.length){if(j<et&&(et=j),tt<et&&(et=tt),et===0)break t;o.arraySet(U,D,E,et,P),j-=et,E+=et,tt-=et,P+=et,y.length-=et;break}y.mode=12;break;case 17:for(;M<14;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if(y.nlen=257+(31&A),A>>>=5,M-=5,y.ndist=1+(31&A),A>>>=5,M-=5,y.ncode=4+(15&A),A>>>=4,M-=4,286<y.nlen||30<y.ndist){C.msg="too many length or distance symbols",y.mode=30;break}y.have=0,y.mode=18;case 18:for(;y.have<y.ncode;){for(;M<3;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}y.lens[Z[y.have++]]=7&A,A>>>=3,M-=3}for(;y.have<19;)y.lens[Z[y.have++]]=0;if(y.lencode=y.lendyn,y.lenbits=7,F={bits:y.lenbits},N=c(0,y.lens,0,19,y.lencode,0,y.work,F),y.lenbits=F.bits,N){C.msg="invalid code lengths set",y.mode=30;break}y.have=0,y.mode=19;case 19:for(;y.have<y.nlen+y.ndist;){for(;H=(I=y.lencode[A&(1<<y.lenbits)-1])>>>16&255,at=65535&I,!((lt=I>>>24)<=M);){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if(at<16)A>>>=lt,M-=lt,y.lens[y.have++]=at;else{if(at===16){for(S=lt+2;M<S;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if(A>>>=lt,M-=lt,y.have===0){C.msg="invalid bit length repeat",y.mode=30;break}g=y.lens[y.have-1],et=3+(3&A),A>>>=2,M-=2}else if(at===17){for(S=lt+3;M<S;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}M-=lt,g=0,et=3+(7&(A>>>=lt)),A>>>=3,M-=3}else{for(S=lt+7;M<S;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}M-=lt,g=0,et=11+(127&(A>>>=lt)),A>>>=7,M-=7}if(y.have+et>y.nlen+y.ndist){C.msg="invalid bit length repeat",y.mode=30;break}for(;et--;)y.lens[y.have++]=g}}if(y.mode===30)break;if(y.lens[256]===0){C.msg="invalid code -- missing end-of-block",y.mode=30;break}if(y.lenbits=9,F={bits:y.lenbits},N=c(d,y.lens,0,y.nlen,y.lencode,0,y.work,F),y.lenbits=F.bits,N){C.msg="invalid literal/lengths set",y.mode=30;break}if(y.distbits=6,y.distcode=y.distdyn,F={bits:y.distbits},N=c(m,y.lens,y.nlen,y.ndist,y.distcode,0,y.work,F),y.distbits=F.bits,N){C.msg="invalid distances set",y.mode=30;break}if(y.mode=20,z===6)break t;case 20:y.mode=21;case 21:if(6<=j&&258<=tt){C.next_out=P,C.avail_out=tt,C.next_in=E,C.avail_in=j,y.hold=A,y.bits=M,a(C,J),P=C.next_out,U=C.output,tt=C.avail_out,E=C.next_in,D=C.input,j=C.avail_in,A=y.hold,M=y.bits,y.mode===12&&(y.back=-1);break}for(y.back=0;H=(I=y.lencode[A&(1<<y.lenbits)-1])>>>16&255,at=65535&I,!((lt=I>>>24)<=M);){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if(H&&(240&H)==0){for(ut=lt,_=H,O=at;H=(I=y.lencode[O+((A&(1<<ut+_)-1)>>ut)])>>>16&255,at=65535&I,!(ut+(lt=I>>>24)<=M);){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}A>>>=ut,M-=ut,y.back+=ut}if(A>>>=lt,M-=lt,y.back+=lt,y.length=at,H===0){y.mode=26;break}if(32&H){y.back=-1,y.mode=12;break}if(64&H){C.msg="invalid literal/length code",y.mode=30;break}y.extra=15&H,y.mode=22;case 22:if(y.extra){for(S=y.extra;M<S;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}y.length+=A&(1<<y.extra)-1,A>>>=y.extra,M-=y.extra,y.back+=y.extra}y.was=y.length,y.mode=23;case 23:for(;H=(I=y.distcode[A&(1<<y.distbits)-1])>>>16&255,at=65535&I,!((lt=I>>>24)<=M);){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if((240&H)==0){for(ut=lt,_=H,O=at;H=(I=y.distcode[O+((A&(1<<ut+_)-1)>>ut)])>>>16&255,at=65535&I,!(ut+(lt=I>>>24)<=M);){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}A>>>=ut,M-=ut,y.back+=ut}if(A>>>=lt,M-=lt,y.back+=lt,64&H){C.msg="invalid distance code",y.mode=30;break}y.offset=at,y.extra=15&H,y.mode=24;case 24:if(y.extra){for(S=y.extra;M<S;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}y.offset+=A&(1<<y.extra)-1,A>>>=y.extra,M-=y.extra,y.back+=y.extra}if(y.offset>y.dmax){C.msg="invalid distance too far back",y.mode=30;break}y.mode=25;case 25:if(tt===0)break t;if(et=J-tt,y.offset>et){if((et=y.offset-et)>y.whave&&y.sane){C.msg="invalid distance too far back",y.mode=30;break}it=et>y.wnext?(et-=y.wnext,y.wsize-et):y.wnext-et,et>y.length&&(et=y.length),pt=y.window}else pt=U,it=P-y.offset,et=y.length;for(tt<et&&(et=tt),tt-=et,y.length-=et;U[P++]=pt[it++],--et;);y.length===0&&(y.mode=21);break;case 26:if(tt===0)break t;U[P++]=y.length,tt--,y.mode=21;break;case 27:if(y.wrap){for(;M<32;){if(j===0)break t;j--,A|=D[E++]<<M,M+=8}if(J-=tt,C.total_out+=J,y.total+=J,J&&(C.adler=y.check=y.flags?r(y.check,U,J,P-J):l(y.check,U,J,P-J)),J=tt,(y.flags?A:k(A))!==y.check){C.msg="incorrect data check",y.mode=30;break}M=A=0}y.mode=28;case 28:if(y.wrap&&y.flags){for(;M<32;){if(j===0)break t;j--,A+=D[E++]<<M,M+=8}if(A!==(4294967295&y.total)){C.msg="incorrect length check",y.mode=30;break}M=A=0}y.mode=29;case 29:N=1;break t;case 30:N=-3;break t;case 31:return-4;case 32:default:return u}return C.next_out=P,C.avail_out=tt,C.next_in=E,C.avail_in=j,y.hold=A,y.bits=M,(y.wsize||J!==C.avail_out&&y.mode<30&&(y.mode<27||z!==4))&&X(C,C.output,C.next_out,J-C.avail_out)?(y.mode=31,-4):(Y-=C.avail_in,J-=C.avail_out,C.total_in+=Y,C.total_out+=J,y.total+=J,y.wrap&&J&&(C.adler=y.check=y.flags?r(y.check,U,J,C.next_out-J):l(y.check,U,J,C.next_out-J)),C.data_type=y.bits+(y.last?64:0)+(y.mode===12?128:0)+(y.mode===20||y.mode===15?256:0),(Y==0&&J===0||z===4)&&N===b&&(N=-5),N)},s.inflateEnd=function(C){if(!C||!C.state)return u;var z=C.state;return z.window&&(z.window=null),C.state=null,b},s.inflateGetHeader=function(C,z){var y;return C&&C.state?(2&(y=C.state).wrap)==0?u:((y.head=z).done=!1,b):u},s.inflateSetDictionary=function(C,z){var y,D=z.length;return C&&C.state?(y=C.state).wrap!==0&&y.mode!==11?u:y.mode===11&&l(1,z,D,0)!==y.check?-3:X(C,z,D,D)?(y.mode=31,-4):(y.havedict=1,b):u},s.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,n,s){var o=i("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(d,m,b,u,h,f,v,k){var x,$,B,L,T,w,W,V,q,X=k.bits,C=0,z=0,y=0,D=0,U=0,E=0,P=0,j=0,tt=0,A=0,M=null,Y=0,J=new o.Buf16(16),et=new o.Buf16(16),it=null,pt=0;for(C=0;C<=15;C++)J[C]=0;for(z=0;z<u;z++)J[m[b+z]]++;for(U=X,D=15;1<=D&&J[D]===0;D--);if(D<U&&(U=D),D===0)return h[f++]=20971520,h[f++]=20971520,k.bits=1,0;for(y=1;y<D&&J[y]===0;y++);for(U<y&&(U=y),C=j=1;C<=15;C++)if(j<<=1,(j-=J[C])<0)return-1;if(0<j&&(d===0||D!==1))return-1;for(et[1]=0,C=1;C<15;C++)et[C+1]=et[C]+J[C];for(z=0;z<u;z++)m[b+z]!==0&&(v[et[m[b+z]]++]=z);if(w=d===0?(M=it=v,19):d===1?(M=l,Y-=257,it=r,pt-=257,256):(M=a,it=c,-1),C=y,T=f,P=z=A=0,B=-1,L=(tt=1<<(E=U))-1,d===1&&852<tt||d===2&&592<tt)return 1;for(;;){for(W=C-P,q=v[z]<w?(V=0,v[z]):v[z]>w?(V=it[pt+v[z]],M[Y+v[z]]):(V=96,0),x=1<<C-P,y=$=1<<E;h[T+(A>>P)+($-=x)]=W<<24|V<<16|q|0,$!==0;);for(x=1<<C-1;A&x;)x>>=1;if(x!==0?(A&=x-1,A+=x):A=0,z++,--J[C]==0){if(C===D)break;C=m[b+v[z]]}if(U<C&&(A&L)!==B){for(P===0&&(P=U),T+=y,j=1<<(E=C-P);E+P<D&&!((j-=J[E+P])<=0);)E++,j<<=1;if(tt+=1<<E,d===1&&852<tt||d===2&&592<tt)return 1;h[B=A&L]=U<<24|E<<16|T-f|0}}return A!==0&&(h[T+A]=C-P<<24|64<<16|0),k.bits=U,0}},{"../utils/common":41}],51:[function(i,n,s){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,n,s){var o=i("../utils/common"),l=0,r=1;function a(I){for(var R=I.length;0<=--R;)I[R]=0}var c=0,d=29,m=256,b=m+1+d,u=30,h=19,f=2*b+1,v=15,k=16,x=7,$=256,B=16,L=17,T=18,w=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],W=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],V=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],q=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],X=new Array(2*(b+2));a(X);var C=new Array(2*u);a(C);var z=new Array(512);a(z);var y=new Array(256);a(y);var D=new Array(d);a(D);var U,E,P,j=new Array(u);function tt(I,R,Z,G,K){this.static_tree=I,this.extra_bits=R,this.extra_base=Z,this.elems=G,this.max_length=K,this.has_stree=I&&I.length}function A(I,R){this.dyn_tree=I,this.max_code=0,this.stat_desc=R}function M(I){return I<256?z[I]:z[256+(I>>>7)]}function Y(I,R){I.pending_buf[I.pending++]=255&R,I.pending_buf[I.pending++]=R>>>8&255}function J(I,R,Z){I.bi_valid>k-Z?(I.bi_buf|=R<<I.bi_valid&65535,Y(I,I.bi_buf),I.bi_buf=R>>k-I.bi_valid,I.bi_valid+=Z-k):(I.bi_buf|=R<<I.bi_valid&65535,I.bi_valid+=Z)}function et(I,R,Z){J(I,Z[2*R],Z[2*R+1])}function it(I,R){for(var Z=0;Z|=1&I,I>>>=1,Z<<=1,0<--R;);return Z>>>1}function pt(I,R,Z){var G,K,nt=new Array(v+1),ct=0;for(G=1;G<=v;G++)nt[G]=ct=ct+Z[G-1]<<1;for(K=0;K<=R;K++){var rt=I[2*K+1];rt!==0&&(I[2*K]=it(nt[rt]++,rt))}}function lt(I){var R;for(R=0;R<b;R++)I.dyn_ltree[2*R]=0;for(R=0;R<u;R++)I.dyn_dtree[2*R]=0;for(R=0;R<h;R++)I.bl_tree[2*R]=0;I.dyn_ltree[2*$]=1,I.opt_len=I.static_len=0,I.last_lit=I.matches=0}function H(I){8<I.bi_valid?Y(I,I.bi_buf):0<I.bi_valid&&(I.pending_buf[I.pending++]=I.bi_buf),I.bi_buf=0,I.bi_valid=0}function at(I,R,Z,G){var K=2*R,nt=2*Z;return I[K]<I[nt]||I[K]===I[nt]&&G[R]<=G[Z]}function ut(I,R,Z){for(var G=I.heap[Z],K=Z<<1;K<=I.heap_len&&(K<I.heap_len&&at(R,I.heap[K+1],I.heap[K],I.depth)&&K++,!at(R,G,I.heap[K],I.depth));)I.heap[Z]=I.heap[K],Z=K,K<<=1;I.heap[Z]=G}function _(I,R,Z){var G,K,nt,ct,rt=0;if(I.last_lit!==0)for(;G=I.pending_buf[I.d_buf+2*rt]<<8|I.pending_buf[I.d_buf+2*rt+1],K=I.pending_buf[I.l_buf+rt],rt++,G===0?et(I,K,R):(et(I,(nt=y[K])+m+1,R),(ct=w[nt])!==0&&J(I,K-=D[nt],ct),et(I,nt=M(--G),Z),(ct=W[nt])!==0&&J(I,G-=j[nt],ct)),rt<I.last_lit;);et(I,$,R)}function O(I,R){var Z,G,K,nt=R.dyn_tree,ct=R.stat_desc.static_tree,rt=R.stat_desc.has_stree,mt=R.stat_desc.elems,$t=-1;for(I.heap_len=0,I.heap_max=f,Z=0;Z<mt;Z++)nt[2*Z]!==0?(I.heap[++I.heap_len]=$t=Z,I.depth[Z]=0):nt[2*Z+1]=0;for(;I.heap_len<2;)nt[2*(K=I.heap[++I.heap_len]=$t<2?++$t:0)]=1,I.depth[K]=0,I.opt_len--,rt&&(I.static_len-=ct[2*K+1]);for(R.max_code=$t,Z=I.heap_len>>1;1<=Z;Z--)ut(I,nt,Z);for(K=mt;Z=I.heap[1],I.heap[1]=I.heap[I.heap_len--],ut(I,nt,1),G=I.heap[1],I.heap[--I.heap_max]=Z,I.heap[--I.heap_max]=G,nt[2*K]=nt[2*Z]+nt[2*G],I.depth[K]=(I.depth[Z]>=I.depth[G]?I.depth[Z]:I.depth[G])+1,nt[2*Z+1]=nt[2*G+1]=K,I.heap[1]=K++,ut(I,nt,1),2<=I.heap_len;);I.heap[--I.heap_max]=I.heap[1],(function(xt,Lt){var Zt,jt,Xt,Nt,Ge,oe,Yt=Lt.dyn_tree,Si=Lt.max_code,Hi=Lt.stat_desc.static_tree,zs=Lt.stat_desc.has_stree,Ns=Lt.stat_desc.extra_bits,Wn=Lt.stat_desc.extra_base,_i=Lt.stat_desc.max_length,ji=0;for(Nt=0;Nt<=v;Nt++)xt.bl_count[Nt]=0;for(Yt[2*xt.heap[xt.heap_max]+1]=0,Zt=xt.heap_max+1;Zt<f;Zt++)_i<(Nt=Yt[2*Yt[2*(jt=xt.heap[Zt])+1]+1]+1)&&(Nt=_i,ji++),Yt[2*jt+1]=Nt,Si<jt||(xt.bl_count[Nt]++,Ge=0,Wn<=jt&&(Ge=Ns[jt-Wn]),oe=Yt[2*jt],xt.opt_len+=oe*(Nt+Ge),zs&&(xt.static_len+=oe*(Hi[2*jt+1]+Ge)));if(ji!==0){do{for(Nt=_i-1;xt.bl_count[Nt]===0;)Nt--;xt.bl_count[Nt]--,xt.bl_count[Nt+1]+=2,xt.bl_count[_i]--,ji-=2}while(0<ji);for(Nt=_i;Nt!==0;Nt--)for(jt=xt.bl_count[Nt];jt!==0;)Si<(Xt=xt.heap[--Zt])||(Yt[2*Xt+1]!==Nt&&(xt.opt_len+=(Nt-Yt[2*Xt+1])*Yt[2*Xt],Yt[2*Xt+1]=Nt),jt--)}})(I,R),pt(nt,$t,I.bl_count)}function g(I,R,Z){var G,K,nt=-1,ct=R[1],rt=0,mt=7,$t=4;for(ct===0&&(mt=138,$t=3),R[2*(Z+1)+1]=65535,G=0;G<=Z;G++)K=ct,ct=R[2*(G+1)+1],++rt<mt&&K===ct||(rt<$t?I.bl_tree[2*K]+=rt:K!==0?(K!==nt&&I.bl_tree[2*K]++,I.bl_tree[2*B]++):rt<=10?I.bl_tree[2*L]++:I.bl_tree[2*T]++,nt=K,$t=(rt=0)===ct?(mt=138,3):K===ct?(mt=6,3):(mt=7,4))}function N(I,R,Z){var G,K,nt=-1,ct=R[1],rt=0,mt=7,$t=4;for(ct===0&&(mt=138,$t=3),G=0;G<=Z;G++)if(K=ct,ct=R[2*(G+1)+1],!(++rt<mt&&K===ct)){if(rt<$t)for(;et(I,K,I.bl_tree),--rt!=0;);else K!==0?(K!==nt&&(et(I,K,I.bl_tree),rt--),et(I,B,I.bl_tree),J(I,rt-3,2)):rt<=10?(et(I,L,I.bl_tree),J(I,rt-3,3)):(et(I,T,I.bl_tree),J(I,rt-11,7));nt=K,$t=(rt=0)===ct?(mt=138,3):K===ct?(mt=6,3):(mt=7,4)}}a(j);var F=!1;function S(I,R,Z,G){J(I,(c<<1)+(G?1:0),3),(function(K,nt,ct,rt){H(K),Y(K,ct),Y(K,~ct),o.arraySet(K.pending_buf,K.window,nt,ct,K.pending),K.pending+=ct})(I,R,Z)}s._tr_init=function(I){F||((function(){var R,Z,G,K,nt,ct=new Array(v+1);for(K=G=0;K<d-1;K++)for(D[K]=G,R=0;R<1<<w[K];R++)y[G++]=K;for(y[G-1]=K,K=nt=0;K<16;K++)for(j[K]=nt,R=0;R<1<<W[K];R++)z[nt++]=K;for(nt>>=7;K<u;K++)for(j[K]=nt<<7,R=0;R<1<<W[K]-7;R++)z[256+nt++]=K;for(Z=0;Z<=v;Z++)ct[Z]=0;for(R=0;R<=143;)X[2*R+1]=8,R++,ct[8]++;for(;R<=255;)X[2*R+1]=9,R++,ct[9]++;for(;R<=279;)X[2*R+1]=7,R++,ct[7]++;for(;R<=287;)X[2*R+1]=8,R++,ct[8]++;for(pt(X,b+1,ct),R=0;R<u;R++)C[2*R+1]=5,C[2*R]=it(R,5);U=new tt(X,w,m+1,b,v),E=new tt(C,W,0,u,v),P=new tt(new Array(0),V,0,h,x)})(),F=!0),I.l_desc=new A(I.dyn_ltree,U),I.d_desc=new A(I.dyn_dtree,E),I.bl_desc=new A(I.bl_tree,P),I.bi_buf=0,I.bi_valid=0,lt(I)},s._tr_stored_block=S,s._tr_flush_block=function(I,R,Z,G){var K,nt,ct=0;0<I.level?(I.strm.data_type===2&&(I.strm.data_type=(function(rt){var mt,$t=4093624447;for(mt=0;mt<=31;mt++,$t>>>=1)if(1&$t&&rt.dyn_ltree[2*mt]!==0)return l;if(rt.dyn_ltree[18]!==0||rt.dyn_ltree[20]!==0||rt.dyn_ltree[26]!==0)return r;for(mt=32;mt<m;mt++)if(rt.dyn_ltree[2*mt]!==0)return r;return l})(I)),O(I,I.l_desc),O(I,I.d_desc),ct=(function(rt){var mt;for(g(rt,rt.dyn_ltree,rt.l_desc.max_code),g(rt,rt.dyn_dtree,rt.d_desc.max_code),O(rt,rt.bl_desc),mt=h-1;3<=mt&&rt.bl_tree[2*q[mt]+1]===0;mt--);return rt.opt_len+=3*(mt+1)+5+5+4,mt})(I),K=I.opt_len+3+7>>>3,(nt=I.static_len+3+7>>>3)<=K&&(K=nt)):K=nt=Z+5,Z+4<=K&&R!==-1?S(I,R,Z,G):I.strategy===4||nt===K?(J(I,2+(G?1:0),3),_(I,X,C)):(J(I,4+(G?1:0),3),(function(rt,mt,$t,xt){var Lt;for(J(rt,mt-257,5),J(rt,$t-1,5),J(rt,xt-4,4),Lt=0;Lt<xt;Lt++)J(rt,rt.bl_tree[2*q[Lt]+1],3);N(rt,rt.dyn_ltree,mt-1),N(rt,rt.dyn_dtree,$t-1)})(I,I.l_desc.max_code+1,I.d_desc.max_code+1,ct+1),_(I,I.dyn_ltree,I.dyn_dtree)),lt(I),G&&H(I)},s._tr_tally=function(I,R,Z){return I.pending_buf[I.d_buf+2*I.last_lit]=R>>>8&255,I.pending_buf[I.d_buf+2*I.last_lit+1]=255&R,I.pending_buf[I.l_buf+I.last_lit]=255&Z,I.last_lit++,R===0?I.dyn_ltree[2*Z]++:(I.matches++,R--,I.dyn_ltree[2*(y[Z]+m+1)]++,I.dyn_dtree[2*M(R)]++),I.last_lit===I.lit_bufsize-1},s._tr_align=function(I){J(I,2,3),et(I,$,X),(function(R){R.bi_valid===16?(Y(R,R.bi_buf),R.bi_buf=0,R.bi_valid=0):8<=R.bi_valid&&(R.pending_buf[R.pending++]=255&R.bi_buf,R.bi_buf>>=8,R.bi_valid-=8)})(I)}},{"../utils/common":41}],53:[function(i,n,s){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,n,s){(function(o){(function(l,r){if(!l.setImmediate){var a,c,d,m,b=1,u={},h=!1,f=l.document,v=Object.getPrototypeOf&&Object.getPrototypeOf(l);v=v&&v.setTimeout?v:l,a={}.toString.call(l.process)==="[object process]"?function(B){process.nextTick(function(){x(B)})}:(function(){if(l.postMessage&&!l.importScripts){var B=!0,L=l.onmessage;return l.onmessage=function(){B=!1},l.postMessage("","*"),l.onmessage=L,B}})()?(m="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",$,!1):l.attachEvent("onmessage",$),function(B){l.postMessage(m+B,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(B){x(B.data)},function(B){d.port2.postMessage(B)}):f&&"onreadystatechange"in f.createElement("script")?(c=f.documentElement,function(B){var L=f.createElement("script");L.onreadystatechange=function(){x(B),L.onreadystatechange=null,c.removeChild(L),L=null},c.appendChild(L)}):function(B){setTimeout(x,0,B)},v.setImmediate=function(B){typeof B!="function"&&(B=new Function(""+B));for(var L=new Array(arguments.length-1),T=0;T<L.length;T++)L[T]=arguments[T+1];var w={callback:B,args:L};return u[b]=w,a(b),b++},v.clearImmediate=k}function k(B){delete u[B]}function x(B){if(h)setTimeout(x,0,B);else{var L=u[B];if(L){h=!0;try{(function(T){var w=T.callback,W=T.args;switch(W.length){case 0:w();break;case 1:w(W[0]);break;case 2:w(W[0],W[1]);break;case 3:w(W[0],W[1],W[2]);break;default:w.apply(r,W)}})(L)}finally{k(B),h=!1}}}}function $(B){B.source===l&&typeof B.data=="string"&&B.data.indexOf(m)===0&&x(+B.data.slice(m.length))}})(typeof self>"u"?o===void 0?this:o:self)}).call(this,typeof Xn<"u"?Xn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(eo)),eo.exports}var Yb=Zb();const Jb=Gb(Yb),Xb=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,Qb=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function ty(t){const e=await Jb.loadAsync(t),i={},n=[];let s="",o="";const l=[];e.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(s=await r.file.async("string"),o=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||Qb.test(c)||c.includes("snippets/")){const d=await a.file.async("string");i[c]=d;const m=c.split("/");m.length>1&&(i[m.slice(1).join("/")]=d)}else if(Xb.test(c)){const d=await a.file.async("uint8array"),m=c.split("/").pop()||c,b=typeof Blob<"u"?new Blob([d]):void 0;n.push({zipPath:c,fileName:m,data:d,blob:b})}}return{entryMarkdown:s,entryMarkdownPath:o,virtualFiles:i,assets:n}}function ey(t,e){if(Object.keys(e).length===0)return t;function i(s){const o=s.trim().replace(/^['"]|['"]$/g,""),l=o.split("/").pop()||o;if(e[o])return e[o];const r=o.replace(/^\.?\//,"");return e[r]?e[r]:e[l]?e[l]:null}function n(s){let o=s;return o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=i(a);return c?`![${r}](${c})`:l}),o=o.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=i(r);return a?`src="${a}"`:l}),o}for(const s of t.slides)if(s.rawMarkdown=n(s.rawMarkdown),s.pageAttrs["custom-slidev-background"]){const o=s.pageAttrs["custom-slidev-background"],l=i(o);l&&(s.pageAttrs["custom-slidev-background"]=l)}if(t.flattenedMarkdown=n(t.flattenedMarkdown),t.docRootAttrs["custom-slidev-background"]){const s=t.docRootAttrs["custom-slidev-background"],o=i(s);o&&(t.docRootAttrs["custom-slidev-background"]=o)}return t}function Ba(t){try{if(typeof process<"u"&&typeof require<"u"){const e=require("fs");if(e.existsSync(t))return e.readFileSync(t,"utf-8")}}catch{}return null}function iy(t,e){const i=t.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const n=i[1].trim(),s=n.indexOf("#"),o=s!==-1?n.slice(0,s):n,l=s!==-1?n.slice(s+1):"",r=o.replace(/^@\//,"").replace(/^\.\//,""),a=(e==null?void 0:e.virtualFiles)||{};let c=a[o]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const u=r.split("/").pop();for(const[h,f]of Object.entries(a))if(h.endsWith(`/${r}`)||u&&h.endsWith(`/${u}`)){c=f;break}}if(!c){const u=[];if(e!=null&&e.baseDir)try{const h=require("path");u.push(h.resolve(e.baseDir,r)),u.push(h.resolve(e.baseDir,o))}catch{}try{const h=require("path");u.push(h.resolve(process.cwd(),r))}catch{}for(const h of u){const f=Ba(h);if(f!==null){c=f;break}}}if(!c){const u=ka||{};if(c=u[o]||u[r]||u[`snippets/${r}`],!c){const h=r.split("/").pop();for(const[f,v]of Object.entries(u))if(f.endsWith(`/${r}`)||h&&f.endsWith(`/${h}`)){c=v;break}}}if(!c)return null;let d=c;if(l){const u=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),h=c.match(u);if(h){const f=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(f?f[1]:"")+h[1].trimEnd()}}const m=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${m?m[1]:""}
${d}
\`\`\``}function ny(t){let e=!1,i=!1;for(let n=0;n<t.length;n++){const s=t[n];if(s==="'"&&!i)e=!e;else if(s==='"'&&!e)i=!i;else if(s==="#"&&!e&&!i)return t.slice(0,n).trim()}return t.trim()}function ns(t){const e={},i=t.split(/\r?\n/);let n=0;for(;n<i.length;){const s=i[n],o=s.trim();if(!o||o.startsWith("#")){n++;continue}const l=s.indexOf(":");if(l>0){const r=s.slice(0,l).trim();let a=s.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let d=-1;for(;n<i.length;){const m=i[n];if(!m.trim()){c.push(""),n++;continue}const u=m.match(/^(\s+)/),h=u?u[1].length:0;if(d===-1&&(d=h),h<d)break;c.push(m.slice(d)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();e[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=ny(a),!a){let c=n+1;const d=[];let m=-1;for(;c<i.length;){const b=i[c],u=b.trim();if(!u||u.startsWith("#")){m!==-1&&d.push(""),c++;continue}const h=b.match(/^(\s+)/),f=h?h[1].length:0;if(m===-1)if(f>0)m=f;else break;if(f<m)break;d.push(b.slice(m)),c++}if(d.length>0){e[r]=ns(d.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),e[r]=a}n++}return e}const sy=/^\s*```ya?ml([\s\S]*?)```/;function Wr(t){let e={},i=t.trim();const n=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const o=ns(n[1]);if(Object.keys(o).length>0||!n[1].trim())return e=o,i=i.slice(n[0].length).trim(),{frontmatter:e,content:i}}if(i.startsWith("---")){const o=i.match(/^---[^\n\r]*(?:\r?\n|$)/);o&&(i=i.slice(o[0].length).trim())}const s=i.match(sy);if(s)e=ns(s[1]),i=i.slice(s[0].length).trim();else{const o=i.split(/\r?\n/),l=[];let r=0;for(let a=0;a<o.length;a++){const c=o[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(e=ns(l.join(`
`)),i=o.slice(r).join(`
`).trim())}return{frontmatter:e,content:i}}function oy(t){const e=t.split(/\r?\n/),i=[];let n=0,s=!1;function o(l){if(n>=l)return;const r=e.slice(n,l).join(`
`).trim();r&&i.push(r),n=l+1}for(let l=0;l<e.length;l++){const a=e[l].trimEnd();if(s){a.includes("-->")&&(s=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(s=!0);continue}if(a.startsWith("---")){o(l);const c=e[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<e.length&&e[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let m=l+1;for(;m<e.length&&!e[m].trimStart().startsWith(d);m++);m<e.length&&(l=m)}}return n<e.length&&o(e.length),i}function ss(t,e={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:n=!0,cleanShikiLines:s=!0,cleanSlots:o=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=e;let d=t;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const m=oy(d),b={};let u="",h="",f=0;if(m.length>0){const q=m[0],X=Wr(q),C=Object.keys(X.frontmatter).length>0,z=X.content.length>0;C&&!z&&m.length>1?(f=1,v(X.frontmatter)):C&&v(X.frontmatter)}function v(q){u=q.title||"",q.theme&&(b[Cn]=String(q.theme)),q.aspectRatio&&(b[$n]=String(q.aspectRatio)),q.highlighter&&(b[Xr]=String(q.highlighter)),q.transition&&(b[In]=String(q.transition)),q.colorSchema&&(b[Qr]=String(q.colorSchema)),q.layout&&(b[gt]=String(q.layout)),q.background&&(b[Ut]=String(q.background)),q.image&&(b[Ee]=String(q.image)),q.class&&(b[Gi]=String(q.class));for(const[X,C]of Object.entries(q))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(X)||(b[`custom-slidev-${X}`]=typeof C=="object"?JSON.stringify(C):String(C))}const k=[];let x=0,$=0,B=0,L=0;const T=new Set,w={};let W=1;for(let q=f;q<m.length;q++){const X=m[q],{frontmatter:C,content:z}=Wr(X),y=X.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),D=C.src||(y?y[1]:void 0);if(D){const H=String(D).trim().replace(/^['"]|['"]$/g,"");let at=c[H]||c[H.replace(/^\.\//,"")]||c[`pages/${H.replace(/^.*pages\//,"")}`];if(!at){const _=H.replace(/^\.\//,""),O=[];if(e.baseDir)try{const g=require("path");O.push(g.resolve(e.baseDir,_)),O.push(g.resolve(e.baseDir,H))}catch{}try{const g=require("path");O.push(g.resolve(process.cwd(),_)),O.push(g.resolve(process.cwd(),H))}catch{}for(const g of O){const N=Ba(g);if(N!==null){at=N;break}}}const ut={};C.layout&&(ut[gt]=String(C.layout)),C.transition&&(ut[ee]=String(C.transition)),C.background&&(ut[Ut]=String(C.background)),C.image&&(ut[Ee]=String(C.image)),C.class&&(ut[Gi]=String(C.class));for(const[_,O]of Object.entries(C))["src","layout","transition","background","image","class"].includes(_)||(ut[`custom-slidev-${_}`]=typeof O=="object"?JSON.stringify(O):String(O));if(at){const _=ss(at,{...e,virtualFiles:c});for(const O of _.slides){O.pageIndex=W++,O.pageAttrs={...ut,...O.pageAttrs},k.push(O);const g=O.pageAttrs[gt]||"default";w[g]=(w[g]||0)+1}continue}else{k.push({pageIndex:W++,pageAttrs:{...ut,"custom-slidev-src":H},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${H}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const _=ut[gt]||"default";w[_]=(w[_]||0)+1;continue}}const U={};C.layout&&(U[gt]=String(C.layout)),C.transition&&(U[ee]=String(C.transition)),C.background&&(U[Ut]=String(C.background)),C.image&&(U[Ee]=String(C.image)),C.class&&(U[Gi]=String(C.class)),C.mask&&(U[vi]=String(C.mask)),(C.maskRatio||C["mask-ratio"])&&(U[bi]=String(C.maskRatio||C["mask-ratio"])),(C.maskStyle||C["mask-style"])&&(U[yi]=String(C.maskStyle||C["mask-style"])),(C.maskInitial||C["mask-initial"])&&(U[ki]=String(C.maskInitial||C["mask-initial"]));for(const[H,at]of Object.entries(C))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(H)||(U[`custom-slidev-${H}`]=typeof at=="object"?JSON.stringify(at):String(at));let E=z;const P=[];let j=E.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,H=>{const at=`__CODE_TOKEN_NOTE_${P.length}__`;return P.push(H),at});j=j.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,H=>{const at=`__CODE_TOKEN_NOTE_${P.length}__`;return P.push(H),at});let tt="";const A=Array.from(j.matchAll(/<!--([\s\S]*?)-->/g));if(A.length>0){const H=A[A.length-1],at=j.slice(H.index+H[0].length).trim();if(!at||!at.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const _=H[1].trim();_.startsWith("TODO:")||(tt=_,x++),i&&(j=j.slice(0,H.index).trimEnd()+j.slice(H.index+H[0].length))}}i&&(j=j.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let H=0;H<P.length;H++)j=j.replace(`__CODE_TOKEN_NOTE_${H}__`,P[H]);if(E=j,tt){for(let ut=0;ut<P.length;ut++)tt=tt.replace(`__CODE_TOKEN_NOTE_${ut}__`,P[ut]);const at=`> [!NOTE] 💡 演讲备注
${tt.split(/\r?\n/).map(ut=>`> ${ut}`).join(`
`)}
{: custom-slidev-note="true"}`;E=E?`${E}

${at}`:at}let M=!1;if(/<style\b/i.test(E)){M=!0;const H=E.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(H){for(const at of H){const ut=at.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();h=h?`${h}

${ut}`:ut}l&&(E=E.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const Y=E.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);Y&&($+=Y.length);const J=E.match(/```\w+\s+\{[^}]+\}/g);J&&(B+=J.length);const et=E.match(/::\w+::|<template\s+#[^>]+>/g);if(et&&(L+=et.length),E=E.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,H=>iy(H,{...e,virtualFiles:c})||H),n&&(E=E.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),s&&(E=E.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),E=E.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),o&&(E=E.replace(/^::\w+::\s*$/gm,"")),r&&(E=yf(E)),a){let H=E.trim(),at="";const ut=H.lastIndexOf("> [!NOTE] 💡 演讲备注");if(ut!==-1&&(at=H.slice(ut),H=H.slice(0,ut).trim()),(C.layout==="image-left"||C.layout==="image-right")&&C.image){const _=String(C.image).trim(),O=C.layout==="image-left"?"image-left":"image-right",g=`![配图](${_})
{: custom-slidev-layout="${O}" }`;C.layout==="image-left"?H=`{{{col

${g}

${H}

}}}`:H=`{{{col

${H}

${g}

}}}`}if(C.background){const O=`![背景图](${String(C.background).trim()})
{: custom-slidev-role="background" }`;H=H?`${O}

${H}`:O}E=at?`${H}

${at}`:H}const it=ry(E);U[Ut]&&it.push(U[Ut]),U[Ee]&&it.push(U[Ee]);for(const H of it)T.add(H);const pt=/<[A-Z][a-zA-Z0-9]+/.test(E),lt=U[gt]||(W===1?b[gt]||"cover":"default");w[lt]=(w[lt]||0)+1,k.push({pageIndex:W++,pageAttrs:U,notes:tt,rawMarkdown:E,hasVueComponent:pt,hasStyleTag:M,assetReferences:it})}if(!u&&k.length>0){const q=k[0].rawMarkdown.match(/^#\s+(.+)$/m);q&&(u=q[1].trim())}h&&(b["custom-slidev-custom-css"]=h);let V=k.map(q=>`---

${q.rawMarkdown}`).join(`

`);return V.trimStart().startsWith("---")||(V=`---

${V.trimStart()}`),{docTitle:u||"Slidev 演示文稿",docRootAttrs:b,slides:k,totalSlides:k.length,stats:{totalNotes:x,totalVClicks:$,totalShikiHighlights:B,totalSlots:L,discoveredAssets:Array.from(T),layoutDistribution:w},flattenedMarkdown:V,customCss:h}}function ry(t){const e=[],i=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=i.exec(t))!==null;){const o=n[1].split(/\s+/)[0].trim();o&&e.push(o)}const s=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=s.exec(t))!==null;){const o=n[1].trim();o&&e.push(o)}return e}function Ea(t){if(!t)return!1;const e=String(t.type||"").toLowerCase(),i=String(t.markdown||"").trim(),n=String(t.content||"").trim();return e==="tb"||e==="thematic-break"||e==="nodethematicbreak"||i==="---"||i==="***"||n==="---"||n==="***"}function ly(t){return(t.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function ay(t,e,i=Dt){const n=t.filter(Ea);let s=0;if(n.length>=e.length)for(let o=0;o<e.length;o++){const l=e[o],r=n[o];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),s++)}else for(let o=1;o<e.length;o++){const l=e[o],r=n[o-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),s++)}return s}async function cy(t,e=Dt){let i=!1,n=0;for(const s of t){if(Ea(s)){i=!1;continue}const o=(s.markdown||s.content||"").trim();if(o==="::right::"||o.startsWith("::right::")){i=!0;continue}i&&s.id&&(await e(s.id,{[At]:"right"}).catch(()=>{}),n++)}return n}async function dy(t,e,i=Zr){const n={};if(!e||e.length===0)return n;const s=[];for(const o of e){const l=new File([o.data],o.fileName,{type:"application/octet-stream"});s.push(l)}try{const o=await i("/data/assets",s);if(o!=null&&o.succMap)for(const[l,r]of Object.entries(o.succMap))n[l]=String(r)}catch(o){console.warn("上传本地静态资产失败，保留原路径:",o)}return Object.keys(n).length>0&&ey(t,n),n}async function uy(t){var B;const{presentation:e,notebookId:i,docTitle:n,extractedAssets:s=[],uploadAssets:o=!0,autoPreview:l=!0,plugin:r,api:a={}}=t,c=a.uploadFn||Zr,d=a.createDocFn||Ic,m=a.setAttrsFn||Dt,b=a.getChildBlocksFn||cs,u=a.openTabFn||ht.openTab,h=a.showMessageFn||ht.showMessage;o&&s.length>0&&await dy(e,s,c);const f=ly(n),v=`/${f}`,k=await d(i,v,e.flattenedMarkdown);if(!k)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const x=((B=e.slides[0])==null?void 0:B.pageAttrs)||{};await m(k,{...x,...e.docRootAttrs});const $=await b(k).catch(()=>[]);return Array.isArray($)&&$.length>0&&(await ay($,e.slides,m),await cy($,m)),h(`🎉 成功导入 Slidev 演示文档《${f}》！`),l&&r&&(r.currentDocId=k,await u({app:r.app,doc:{id:k}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),k}function fy(t){const e=bt("file"),i=bt(!1),n=bt(!1),s=bt(""),o=bt(null),l=bt(null),r=bt(""),a=bt(0),c=bt(""),d=bt([]),m=bt(null),b=bt(""),u=bt([]),h=bt(""),f=bt(!0),v=bt(!0),k=bt(!0),x=bt(!0),$=_t(()=>{const U=a.value;if(U===0)return"0 B";const E=1024,P=["B","KB","MB","GB"],j=Math.floor(Math.log(U)/Math.log(E));return`${(U/E**j).toFixed(1)} ${P[j]}`}),B=_t(()=>{var U;return((U=m.value)==null?void 0:U.docRootAttrs["custom-slidev-theme"])||"default"}),L=_t(()=>{var U;return d.value.length>0?d.value.length:((U=m.value)==null?void 0:U.stats.discoveredAssets.length)||0}),T=_t(()=>{var E;const U=((E=m.value)==null?void 0:E.stats.layoutDistribution)||{};return Object.entries(U).map(([P,j])=>({name:P,count:j}))});async function w(U=$c){try{const E=await U();E!=null&&E.notebooks&&Array.isArray(E.notebooks)&&(u.value=E.notebooks.filter(P=>!P.closed),u.value.length>0&&!h.value&&(h.value=u.value[0].id))}catch(E){console.warn("获取笔记本列表失败:",E)}}function W(){var U;(U=o.value)==null||U.click()}function V(){l.value=null,r.value="",a.value=0,m.value=null,d.value=[],s.value=""}async function q(U){s.value="",l.value=U,r.value=U.name,a.value=U.size;try{if(U.name.toLowerCase().endsWith(".zip")){const P=await U.arrayBuffer(),j=await ty(P);if(!j.entryMarkdown){s.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}d.value=j.assets;const tt=ss(j.entryMarkdown,{stripNotesFromMarkdown:v.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1,virtualFiles:j.virtualFiles});m.value=tt,b.value=tt.docTitle||U.name.replace(/\.zip$/i,"")}else{const P=await U.text();d.value=[];const j=U.path||"",tt=j?j.replace(/[\\/][^\\/]+$/,""):"",A=ss(P,{stripNotesFromMarkdown:v.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1,baseDir:tt||void 0});m.value=A,b.value=A.docTitle||U.name.replace(/\.md$/i,"")}}catch(E){console.error("解析文件失败:",E),s.value=`解析文件失败: ${E.message||String(E)}`}}function X(){if(s.value="",!c.value.trim()){m.value=null;return}try{const U=ss(c.value,{stripNotesFromMarkdown:v.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1});m.value=U,b.value=U.docTitle||"Slidev 演示文稿"}catch(U){s.value=`解析 Markdown 源码失败: ${U.message||String(U)}`}}async function C(){l.value?await q(l.value):c.value&&X()}async function z(U){const E=U.target;E.files&&E.files[0]&&await q(E.files[0])}async function y(U){var E;i.value=!1,(E=U.dataTransfer)!=null&&E.files&&U.dataTransfer.files[0]&&await q(U.dataTransfer.files[0])}async function D(U=t){if(m.value){if(!h.value&&u.value.length>0&&(h.value=u.value[0].id),!h.value){s.value="请先选择目标笔记本";return}n.value=!0,s.value="";try{return await uy({presentation:m.value,notebookId:h.value,docTitle:b.value,extractedAssets:d.value,uploadAssets:k.value,autoPreview:x.value,plugin:U})}catch(E){console.error("导入 Slidev 演示失败:",E),s.value=`导入执行失败: ${E.message||String(E)}`}finally{n.value=!1}}}return{inputMode:e,isDragging:i,isImporting:n,errorMessage:s,fileInputRef:o,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:d,parsedPresentation:m,customDocTitle:b,notebooks:u,selectedNotebookId:h,optCleanHtml:f,optStripNotes:v,optUploadAssets:k,optAutoPreview:x,formattedFileSize:$,currentTheme:B,extractedAssetsCount:L,layoutChips:T,fetchNotebooks:w,triggerFileInput:W,clearFile:V,processFile:q,onFileSelected:z,onFileDrop:y,onTextChange:X,reprocessCurrentInput:C,handleConfirmImport:D}}const py={class:"spm-import-dialog"},hy={class:"spm-tabs-header"},my={class:"spm-dialog-body"},gy={key:0,class:"spm-file-section"},vy={key:0,class:"spm-dropzone-prompt"},by={class:"spm-dropzone-icon"},yy={key:1,class:"spm-dropzone-active"},ky={class:"spm-file-badge"},wy={class:"spm-file-size"},xy={key:1,class:"spm-text-section"},Sy={key:2,class:"spm-error-banner"},_y={key:3,class:"spm-preview-card"},Cy={class:"spm-preview-card__header"},$y={style:{display:"inline-flex","align-items":"center",gap:"4px"}},Iy={class:"spm-config-grid"},Ay={class:"spm-form-item"},Ty={class:"spm-form-item"},By=["value"],Ey={class:"spm-stats-grid"},My={class:"spm-stat-box"},Dy={class:"spm-stat-value"},Ly={class:"spm-stat-box"},Ry={class:"spm-stat-value"},Py={class:"spm-stat-box"},Oy={class:"spm-stat-value"},zy={class:"spm-stat-box"},Ny={class:"spm-stat-value"},Fy={key:0,class:"spm-chips-row"},Hy={class:"spm-options-group"},jy={class:"spm-checkbox-label"},Wy={class:"spm-checkbox-label"},Uy={class:"spm-checkbox-label"},Vy={class:"spm-checkbox-label"},qy={class:"spm-dialog-footer"},Ky=["disabled"],Gy=["disabled"],Zy={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Yy={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Jy=Ce({__name:"SlidevImportDialog",emits:["close","success"],setup(t,{emit:e}){const i=e,n=ti("plugin"),{inputMode:s,isDragging:o,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:d,extractedAssetsCount:m,parsedPresentation:b,customDocTitle:u,notebooks:h,selectedNotebookId:f,optCleanHtml:v,optStripNotes:k,optUploadAssets:x,optAutoPreview:$,formattedFileSize:B,currentTheme:L,layoutChips:T,fetchNotebooks:w,triggerFileInput:W,clearFile:V,onFileSelected:q,onFileDrop:X,onTextChange:C,reprocessCurrentInput:z,handleConfirmImport:y}=fy(n);Fn(async()=>{await w()});async function D(){const E=await y();E&&(i("success",{docId:E}),i("close"))}function U(){i("close")}return(E,P)=>(st(),ot("div",{class:"spm-modal-overlay",onClick:Me(U,["self"])},[p("div",py,[p("div",{class:"spm-dialog-header"},[P[18]||(P[18]=p("div",{class:"spm-dialog-title"},[p("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[p("use",{"xlink:href":"#iconSlidev"})]),p("span",null,"导入 Slidev 演示文档")],-1)),p("button",{class:"spm-close-btn",title:"关闭",onClick:U},"✕")]),p("div",hy,[p("button",{class:It(["spm-tab-btn",{active:yt(s)==="file"}]),onClick:P[0]||(P[0]=j=>s.value="file")},[dt(ft,{name:"package"}),P[19]||(P[19]=p("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),p("button",{class:It(["spm-tab-btn",{active:yt(s)==="text"}]),onClick:P[1]||(P[1]=j=>s.value="text")},[dt(ft,{name:"notes"}),P[20]||(P[20]=p("span",null,"粘贴 Markdown 源码",-1))],2)]),p("div",my,[yt(s)==="file"?(st(),ot("div",gy,[p("div",{class:It(["spm-dropzone",{dragover:yt(o),"has-file":!!yt(c)}]),onDragover:P[4]||(P[4]=Me(j=>o.value=!0,["prevent"])),onDragleave:P[5]||(P[5]=Me(j=>o.value=!1,["prevent"])),onDrop:P[6]||(P[6]=Me((...j)=>yt(X)&&yt(X)(...j),["prevent"])),onClick:P[7]||(P[7]=(...j)=>yt(W)&&yt(W)(...j))},[p("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:P[2]||(P[2]=(...j)=>yt(q)&&yt(q)(...j))},null,544),yt(c)?(st(),ot("div",yy,[p("span",ky,[dt(ft,{name:"notes"}),$e(" "+St(yt(c)),1)]),p("span",wy,"("+St(yt(B))+")",1),p("button",{class:"spm-btn-text",onClick:P[3]||(P[3]=Me((...j)=>yt(V)&&yt(V)(...j),["stop"]))},"更换文件")])):(st(),ot("div",vy,[p("span",by,[dt(ft,{name:"folder",style:{"font-size":"32px"}})]),P[21]||(P[21]=p("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),P[22]||(P[22]=p("p",{class:"spm-dropzone-hint"},[$e(" 支持 Slidev 完整工程 "),p("strong",null,".zip"),$e("（自动解包 public/ 静态素材）或单文件 "),p("strong",null,".md")],-1))]))],34)])):(st(),ot("div",xy,[Be(p("textarea",{"onUpdate:modelValue":P[8]||(P[8]=j=>Qt(d)?d.value=j:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:P[9]||(P[9]=(...j)=>yt(C)&&yt(C)(...j))},null,544),[[xs,yt(d)]])])),yt(r)?(st(),ot("div",Sy," ⚠️ "+St(yt(r)),1)):Pt("",!0),yt(b)?(st(),ot("div",_y,[p("div",Cy,[p("span",$y,[dt(ft,{name:"sparkles"}),P[23]||(P[23]=$e(" 演示解析摘要",-1))]),P[24]||(P[24]=p("span",{class:"spm-badge-success"},"预检就绪",-1))]),p("div",Iy,[p("div",Ay,[P[25]||(P[25]=p("label",{class:"spm-form-label"},"笔记文档标题",-1)),Be(p("input",{"onUpdate:modelValue":P[10]||(P[10]=j=>Qt(u)?u.value=j:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[xs,yt(u)]])]),p("div",Ty,[P[26]||(P[26]=p("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Be(p("select",{"onUpdate:modelValue":P[11]||(P[11]=j=>Qt(f)?f.value=j:null),class:"spm-select"},[(st(!0),ot(qt,null,ke(yt(h),j=>(st(),ot("option",{key:j.id,value:j.id},St(j.name),9,By))),128))],512),[[Xu,yt(f)]])])]),p("div",Ey,[p("div",My,[p("span",Dy,St(yt(b).totalSlides),1),P[27]||(P[27]=p("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),p("div",Ly,[p("span",Ry,St(yt(L)),1),P[28]||(P[28]=p("span",{class:"spm-stat-label"},"演示主题",-1))]),p("div",Py,[p("span",Oy,St(yt(b).stats.totalNotes),1),P[29]||(P[29]=p("span",{class:"spm-stat-label"},"演讲者提词",-1))]),p("div",zy,[p("span",Ny,St(yt(m)),1),P[30]||(P[30]=p("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),yt(T).length>0?(st(),ot("div",Fy,[P[31]||(P[31]=p("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(st(!0),ot(qt,null,ke(yt(T),j=>(st(),ot("span",{key:j.name,class:"spm-chip-badge"},St(j.name)+": "+St(j.count),1))),128))])):Pt("",!0),p("div",Hy,[p("label",jy,[Be(p("input",{"onUpdate:modelValue":P[12]||(P[12]=j=>Qt(v)?v.value=j:null),type:"checkbox",onChange:P[13]||(P[13]=(...j)=>yt(z)&&yt(z)(...j))},null,544),[[Yn,yt(v)]]),P[32]||(P[32]=p("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),p("label",Wy,[Be(p("input",{"onUpdate:modelValue":P[14]||(P[14]=j=>Qt(k)?k.value=j:null),type:"checkbox",onChange:P[15]||(P[15]=(...j)=>yt(z)&&yt(z)(...j))},null,544),[[Yn,yt(k)]]),P[33]||(P[33]=p("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),p("label",Uy,[Be(p("input",{"onUpdate:modelValue":P[16]||(P[16]=j=>Qt(x)?x.value=j:null),type:"checkbox"},null,512),[[Yn,yt(x)]]),P[34]||(P[34]=p("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),p("label",Vy,[Be(p("input",{"onUpdate:modelValue":P[17]||(P[17]=j=>Qt($)?$.value=j:null),type:"checkbox"},null,512),[[Yn,yt($)]]),P[35]||(P[35]=p("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Pt("",!0)]),p("div",qy,[p("button",{class:"spm-btn-secondary",disabled:yt(l),onClick:U}," 取消 ",8,Ky),p("button",{class:"spm-btn-primary",disabled:!yt(b)||yt(l),onClick:D},[yt(l)?(st(),ot("span",Zy,[dt(ft,{name:"refresh"}),P[36]||(P[36]=$e(" 正在导入生成中...",-1))])):(st(),ot("span",Yy,[dt(ft,{name:"rocket"}),P[37]||(P[37]=$e(" 确认导入思源笔记",-1))]))],8,Gy)])])]))}}),Xy=Ne(Jy,[["__scopeId","data-v-2eff6f1e"]]);function Ma(t){return t?t==="NodeThematicBreak"||t==="tb"||t==="thematic-break":!1}function Qy(t,e){var r;if(!t||t.length===0)return null;const i=e.activeBlockId||"",n=e.currentTopBlockId||i,s=e.currentPageDividerId||"",o=e.activeBlockType||"";if(Ma(o)&&i){let a=t.find(c=>c.startBlockId===i);if(a||(a=t.find(c=>{var d,m;return((m=(d=c.blocks)==null?void 0:d[0])==null?void 0:m.id)===i}),a)||(a=t.find(c=>{var d;return(d=c.allBlockIds)==null?void 0:d.includes(i)}),a))return a}if(s){let a=t.find(c=>c.startBlockId===s);if(a||(a=t.find(c=>{var d,m;return((m=(d=c.blocks)==null?void 0:d[0])==null?void 0:m.id)===s}),a))return a}if(i){let a=t.find(d=>d.startBlockId===i);if(a||(a=t.find(d=>{var m,b;return((m=d.blocks)==null?void 0:m.some(u=>u.id===i))||((b=d.allBlockIds)==null?void 0:b.includes(i))}),a)||n&&n!==i&&(a=t.find(d=>{var m,b;return((m=d.blocks)==null?void 0:m.some(u=>u.id===n))||((b=d.allBlockIds)==null?void 0:b.includes(n))}),a)||(a=t.find(d=>{var m;return(m=d.noteBlocks)==null?void 0:m.some(b=>b.id===i||b.id===n)}),a))return a;const c=(r=e.activeBlockAttrs)==null?void 0:r[At];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=t.find(d=>{var m,b;return((m=d.frontmatter)==null?void 0:m.layout)==="three-cols-header"||((b=d.blocks)==null?void 0:b.some(u=>u.slot==="col-1"||u.slot==="col-2"||u.slot==="col-3"))}),a))return a}return t[0]||null}function Ur(t,e){const i=(t.blocks||[]).filter(l=>{const r=(l.content||l.rawMarkdown||"").trim();return r&&r!=="---"});if(i.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],s=[];for(const l of i){const r=(l.content||l.rawMarkdown||"").trim();r&&(l.type==="h"||r.startsWith("#")?n.push(r.replace(/^#+\s*/,"")):s.push(r.slice(0,50)))}const o=[];return n.length>0&&o.push(`【核心重点】：${n.join("、")}`),s.length>0&&(o.push("【口播要点】："),s.slice(0,3).forEach((l,r)=>{o.push(`${r+1}. 讲解 ${l}`)})),o.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),o.join(`
`)}async function Da(t,e){const i=t.blocks&&t.blocks.length>0?t.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(t.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(e&&i){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const s=await e(n);if(s&&s.trim())return{notes:s.trim(),isAiGenerated:!0}}catch(s){return{notes:Ur(t),isAiGenerated:!1,error:(s==null?void 0:s.message)||"AI 调用异常"}}}return{notes:Ur(t),isAiGenerated:!1}}async function t0(t,e){return(await Da(t,e)).notes}function Vr(t,e){if(!e)return!1;if(t===e||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`);if(!i)return!1;const n=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===t}function e0(t){const e=bt(!1);let i=null;function n(A="已同步"){t.saveStatus.value=A,i&&(typeof window<"u"?window.clearTimeout(i):clearTimeout(i));const M=()=>{t.saveStatus.value=""};typeof window<"u"?i=window.setTimeout(M,1200):i=setTimeout(M,1200)}async function s(A){var et;const M=t.activeBlockId.value||t.currentDocId.value;if(!M)return;for(const[it,pt]of Object.entries(A))t.activeBlockAttrs.value[it]=pt;Et.setBlockAttrOverride(M,A),Jt(M,A);const Y=(et=t.parentContainerId)==null?void 0:et.value,J=!!(Y&&Vr(M,Y));if(Wt in A&&J&&Y){const it=A[Wt];t.parentContainerClicks&&(t.parentContainerClicks.value=it),Et.setBlockAttrOverride(Y,{[Wt]:it}),Jt(Y,{[Wt]:it}),Dt(Y,{[Wt]:it}).catch(()=>{})}if(gt in A){const it=A[gt];t.currentPageDividerLayout.value=it,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=it)}if(le in A){const it=A[le];t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=it)}n("保存中...");try{await Dt(M,A),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}async function o(A,M){var it;const Y=t.activeBlockId.value||t.currentDocId.value;if(!Y)return;t.activeBlockAttrs.value[A]=M,Et.setBlockAttrOverride(Y,{[A]:M}),Jt(Y,{[A]:M});const J=(it=t.parentContainerId)==null?void 0:it.value,et=!!(J&&Vr(Y,J));A===Wt&&et&&J&&(t.parentContainerClicks&&(t.parentContainerClicks.value=M),Et.setBlockAttrOverride(J,{[Wt]:M}),Jt(J,{[Wt]:M}),Dt(J,{[Wt]:M}).catch(()=>{})),A===gt&&(t.currentPageDividerLayout.value=M,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=M)),A===le&&t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=M),n("保存中...");try{await Dt(Y,{[A]:M}),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}function l(){const A=t.activeBlockType.value==="NodeThematicBreak"||t.activeBlockType.value==="NodeThematicBreakBlock"||t.activeBlockType.value==="hr"||t.activeBlockType.value==="thematicbreak";return t.currentPageDividerId.value||(A?t.activeBlockId.value:"")||t.currentDocId.value}async function r(A,M){const Y=l();if(Y){Y===t.activeBlockId.value&&(t.activeBlockAttrs.value[A]=M),Et.setBlockAttrOverride(Y,{[A]:M}),Jt(Y,{[A]:M}),A===gt&&(t.currentPageDividerLayout.value=M,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=M)),A===le&&t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=M),n("保存中...");try{await Dt(Y,{[A]:M}),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}}async function a(A,M){const Y=l();if(!Y)return;const J={[gt]:A,[le]:M};Y===t.activeBlockId.value&&(t.activeBlockAttrs.value[gt]=A,t.activeBlockAttrs.value[le]=M),t.currentPageDividerLayout.value=A,Et.setBlockAttrOverride(Y,J),Jt(Y,J),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=A,t.targetSlide.value.frontmatter.layoutRatio=M),n("应用排版中...");try{await Dt(Y,J),n("已应用分栏与比例"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("应用失败")}}async function c(A,M){var J;const Y=t.currentDocId.value||t.activeBlockId.value;if(Y){t.activeBlockAttrs.value[A]=M,Et.setBlockAttrOverride(Y,{[A]:M}),Jt(Y,{[A]:M}),(J=t.latestDoc.value)!=null&&J.config&&(A===Cn&&(t.latestDoc.value.config.theme=M),A===$n&&(t.latestDoc.value.config.aspectRatio=M),A===In&&(t.latestDoc.value.config.defaultTransition=M)),n("更新中...");try{await Dt(Y,{[A]:M}),n("已更新"),t.plugin&&await t.plugin.compileCurrentDocument(Y)}catch{n("更新失败")}}}async function d(){(t.videoAutoplay.value?"false":"true")==="true"?(await s({[Di]:"true",[qi]:"true"}),t.activeBlockAttrs.value[Di]="true",t.activeBlockAttrs.value[qi]="true"):(await o(Di,"false"),t.activeBlockAttrs.value[Di]="false")}async function m(){const A=t.videoLoop.value?"false":"true";await o(ds,A)}async function b(){const A=t.videoMuted.value?"false":"true";await o(qi,A)}async function u(){const A=t.videoControls.value?"false":"true";await o(us,A)}async function h(A){var it;const M=t.activeBlockId.value;if(!M)return;const Y=t.rawSnippet.value||"",J=wi(Y)||"",et=t.currentPageDividerId.value||t.currentDocId.value;if(A)if(A==="background"){const pt={[Gt]:"background",[gt]:""};et&&J&&(t.pageBackground.value=J,await Dt(et,{[Ut]:J}).catch(()=>{}),Et.setBlockAttrOverride(et,{[Ut]:J}),Jt(et,{[Ut]:J}),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.background=J)),await s(pt)}else(A===fs||A===ps)&&await s({[gt]:A,[Gt]:""});else{const pt={[Gt]:"",[gt]:""};if(t.activeBlockAttrs.value[Ut]==="true"&&(pt[Ut]=""),et&&J&&t.pageBackground.value===J&&(t.pageBackground.value="",await Dt(et,{[Ut]:""}).catch(()=>{}),Et.setBlockAttrOverride(et,{[Ut]:""}),Jt(et,{[Ut]:""}),(it=t.targetSlide.value)!=null&&it.frontmatter&&delete t.targetSlide.value.frontmatter.background),await s(pt),typeof document<"u"){const lt=document.querySelector(`.protyle-wysiwyg [data-node-id="${M}"]`),H=lt==null?void 0:lt.closest('[data-type="NodeListItem"]'),at=H==null?void 0:H.getAttribute("data-node-id");if(at&&at!==M){const ut={[gt]:"",[Gt]:""};Jt(at,ut),Et.setBlockAttrOverride(at,ut),await Dt(at,ut).catch(()=>{})}}}}async function f(A){var at,ut,_,O,g,N,F,S;const J=`> [!NOTE] 💡 演讲备注
${(A||"在此输入本页讲稿提词...").split(/\r?\n/).map(I=>`> ${I}`).join(`
`)}
{: custom-slidev-note="true"}`,et=((at=t.latestDoc.value)==null?void 0:at.slides)||[],it=t.targetSlide.value,pt=it?et.findIndex(I=>I===it):-1;let lt=null;if(pt!==-1&&pt<et.length-1){const I=et[pt+1];lt=await Bi("markdown",J,I.startBlockId)}else{const I=((ut=it==null?void 0:it.noteBlocks)==null?void 0:ut.slice(-1)[0])||((_=it==null?void 0:it.blocks)==null?void 0:_.slice(-1)[0]),R=(I==null?void 0:I.id)||(it==null?void 0:it.startBlockId);R?lt=await Bi("markdown",J,void 0,R):lt=await so("markdown",J,t.currentDocId.value)}const H=((N=(g=(O=lt==null?void 0:lt[0])==null?void 0:O.doOperations)==null?void 0:g[0])==null?void 0:N.id)||((F=lt==null?void 0:lt[0])==null?void 0:F.id);return H&&(await Dt(H,{[ne]:"true"}),Et.setBlockAttrOverride(H,{[ne]:"true"}),zi(H,(S=t.plugin)==null?void 0:S.app)),t.plugin&&await t.plugin.compileCurrentDocument(),H}async function v(){const A=t.activeBlockId.value;if(A)if(t.isNoteBlock.value){n("取消中...");try{await Dt(A,{[ne]:"","slidev-note":""}),Et.setBlockAttrOverride(A,{[ne]:"","slidev-note":""}),Jt(A,{[ne]:"","slidev-note":""}),delete t.activeBlockAttrs.value[ne],delete t.activeBlockAttrs.value["slidev-note"],n("已取消备注"),ht.showMessage("已取消讲稿备注"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(M){console.error("[SiYuanSlidev] 取消讲稿备注失败:",M),n("取消失败"),ht.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let M=t.rawSnippet.value;try{const it=await Ac(A);it!=null&&it.kramdown&&(M=it.kramdown)}catch{}const et=`> [!NOTE] 💡 演讲备注
${(ga(M)||M.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(it=>`> ${it}`).join(`
`)}
{: custom-slidev-note="true"}`;await ir("markdown",et,A),await Dt(A,{[ne]:"true"}),Et.setBlockAttrOverride(A,{[ne]:"true"}),Jt(A,{[ne]:"true"}),t.activeBlockAttrs.value[ne]="true",t.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),ht.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(M){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",M),n("设置失败"),ht.showMessage("转为讲稿备注提示块失败")}}}async function k(){try{await f(),ht.showMessage("已在正文末尾插入讲稿备注提示块")}catch(A){ht.showMessage("插入讲稿备注块失败"),console.error(A)}}function x(){var Y;const A=t.currentSlideNoteBlockId.value;if(!A){ht.showMessage("未找到本页关联的讲稿备注块");return}zi(A,(Y=t.plugin)==null?void 0:Y.app)?ht.showMessage("已在编辑区定位讲稿备注块"):ht.showMessage("定位讲稿备注块失败")}async function $(){var Y;if(!t.currentDocId.value)return;const A=t.targetSlide.value||{startBlockId:t.activeBlockId.value||t.currentDocId.value,blocks:t.rawSnippet.value&&t.rawSnippet.value!=="---"?[{id:t.activeBlockId.value,type:t.activeBlockType.value,content:t.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:t.rawSnippet.value&&t.rawSnippet.value!=="---"?t.rawSnippet.value:""};ht.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const M=await Da(A,Yr);if(M.notes){const J=t.currentSlideNoteBlockId.value;if(J){const et=`> [!NOTE] 💡 演讲备注
${M.notes.split(/\r?\n/).map(it=>`> ${it}`).join(`
`)}
{: custom-slidev-note="true"}`;await ir("markdown",et,J),await Dt(J,{[ne]:"true"}),Et.setBlockAttrOverride(J,{[ne]:"true"}),zi(J,(Y=t.plugin)==null?void 0:Y.app)}else await f(M.notes);M.isAiGenerated?ht.showMessage("思源 AI 演讲提词卡生成成功！"):ht.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),t.plugin&&await t.plugin.compileCurrentDocument()}}async function B(){var J;if(e.value)return;const A=((J=t.latestDoc.value)==null?void 0:J.slides)||[];if(A.length===0){ht.showMessage("当前文档无幻灯片页面");return}const M=A.map((et,it)=>({slide:et,idx:it})).filter(({slide:et})=>{var lt;const it=Array.isArray(et.noteBlocks)&&et.noteBlocks.length>0,pt=!!((lt=et.notes)!=null&&lt.trim());return!it&&!pt});if(M.length===0){ht.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const Y=M.length;ht.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${Y} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var it,pt,lt,H,at,ut;if(e.value)return;e.value=!0,ht.showMessage("正在批量追加讲稿块...");let et=0;try{const g=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(N=>`> ${N}`).join(`
`)}
{: custom-slidev-note="true"}`;for(const{slide:N,idx:F}of M)try{let S=null;if(F<A.length-1){const R=A[F+1];S=await Bi("markdown",g,R.startBlockId)}else{const R=((it=N==null?void 0:N.noteBlocks)==null?void 0:it.slice(-1)[0])||((pt=N==null?void 0:N.blocks)==null?void 0:pt.slice(-1)[0]),Z=(R==null?void 0:R.id)||(N==null?void 0:N.startBlockId);Z?S=await Bi("markdown",g,void 0,Z):S=await so("markdown",g,t.currentDocId.value)}const I=((at=(H=(lt=S==null?void 0:S[0])==null?void 0:lt.doOperations)==null?void 0:H[0])==null?void 0:at.id)||((ut=S==null?void 0:S[0])==null?void 0:ut.id);I&&(await Dt(I,{[ne]:"true"}),Et.setBlockAttrOverride(I,{[ne]:"true"})),et++}catch(S){console.error(`[SiYuanSlidev] 为第 ${F+1} 页追加讲稿块失败:`,S)}t.plugin&&await t.plugin.compileCurrentDocument(),ht.showMessage(`已成功为 ${et} 页追加讲稿备注块`)}catch(_){console.error("[SiYuanSlidev] 批量追加讲稿块失败:",_),ht.showMessage("批量追加讲稿块时出现异常")}finally{e.value=!1}})}async function L(){var et;if(e.value)return;const A=((et=t.latestDoc.value)==null?void 0:et.slides)||[];if(A.length===0){ht.showMessage("当前文档无幻灯片页面");return}const M=[];for(const it of A)if(it.noteBlocks&&it.noteBlocks.length>0)for(const pt of it.noteBlocks)pt.id&&M.push({id:pt.id,pageIndex:it.pageIndex});if(M.length===0){ht.showMessage("当前文档中没有讲稿备注块，无需删除");return}const Y=new Set(M.map(it=>it.pageIndex)).size,J=M.length;ht.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${J} 个讲稿备注块（涉及 ${Y} 页），删除后无法撤销。是否确认继续？`,async()=>{if(e.value)return;e.value=!0,ht.showMessage("正在批量删除讲稿块...");let it=0;try{for(const pt of M)try{await nr(pt.id),Et.clearBlockAttrOverride(pt.id),it++}catch(lt){console.error(`[SiYuanSlidev] 删除讲稿块 ${pt.id} 失败:`,lt)}t.activeBlockId.value&&M.some(pt=>pt.id===t.activeBlockId.value)&&(delete t.activeBlockAttrs.value[ne],delete t.activeBlockAttrs.value["slidev-note"]),t.plugin&&await t.plugin.compileCurrentDocument(),ht.showMessage(`已成功删除全部 ${it} 个讲稿备注块`)}catch(pt){console.error("[SiYuanSlidev] 批量删除讲稿块失败:",pt),ht.showMessage("批量删除讲稿块时出现异常")}finally{e.value=!1}})}function T(){t.elemClick.value?o(Wt,""):o(Wt,"+1")}function w(A){o(Wt,A)}function W(A){o(Ve,A)}function V(A){(t.activeBlockAttrs.value[At]||"")===A?o(At,""):o(At,A)}function q(A){t.elemShikiLines.value=A,o(Ni,A)}function X(A){t.elemMaxHeight.value=A,o(An,A)}async function C(){const A=t.currentSlideLayout.value==="three-cols-header";await o(At,A?"col-1":"left"),ht.showMessage(A?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function z(){const A=t.activeBlockId.value;if(!A)return;const M={[Wt]:"",[Ve]:"",[At]:"",[Ni]:"",[An]:"",[ne]:"","slidev-note":"",[gt]:"",[le]:"",[Gt]:"",[ee]:"",[Ut]:"",[Ee]:"",[Di]:"",[ds]:"",[qi]:"",[us]:""};if(Jt(A,M),await Dt(A,M),Et.clearBlockAttrOverride(A),typeof document<"u"){const Y=document.querySelector(`.protyle-wysiwyg [data-node-id="${A}"]`),J=Y==null?void 0:Y.closest('[data-type="NodeListItem"]'),et=J==null?void 0:J.getAttribute("data-node-id");et&&et!==A&&(Jt(et,M),await Dt(et,M).catch(()=>{}),Et.clearBlockAttrOverride(et))}t.activeBlockAttrs.value={},t.elemShikiLines.value="",t.elemMaxHeight.value="",t.pageBackground.value="",t.pageImage.value="",ht.showMessage("已清除本块演示属性"),t.plugin&&await t.plugin.compileCurrentDocument()}async function y(){if(t.activeBlockId.value)try{await Bi("markdown","---",t.activeBlockId.value,void 0),ht.showMessage("已在上方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{ht.showMessage("插入分页符失败")}}async function D(){const A=t.activeBlockId.value||t.currentDocId.value;if(A)try{await Bi("markdown","---",void 0,A),ht.showMessage("已在下方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{ht.showMessage("插入分页符失败")}}async function U(){if(t.activeBlockId.value)try{await nr(t.activeBlockId.value),ht.showMessage("已删除该分页符"),t.activeBlockId.value="",t.activeBlockType.value="",t.plugin&&t.plugin.compileCurrentDocument()}catch{ht.showMessage("删除失败")}}function E(){if(!t.latestDoc.value){ht.showMessage("请先在主编辑区打开幻灯片文档");return}const A=Ia(t.latestDoc.value);Aa("presentation.html",A)&&ht.showMessage("已开始下载单文件离线 HTML 演示包")}function P(){if(!t.latestDoc.value){ht.showMessage("请先在主编辑区打开幻灯片文档");return}Ta(t.latestDoc.value)&&ht.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}async function j(){var A,M;try{let Y=null;if(typeof document<"u"){const et=t.activeBlockId.value;if(et){const it=document.querySelector(`.protyle-wysiwyg [data-node-id="${et}"]`);it&&(Y=it.getAttribute("data-type")==="NodeSuperBlock"?it:it.closest('[data-type="NodeSuperBlock"]'))}if(!Y){const it=t.currentPageDividerId.value||(t.activeBlockType.value==="hr"||t.activeBlockType.value==="NodeThematicBreak"?t.activeBlockId.value:"");if(it){const pt=document.querySelector(`.protyle-wysiwyg [data-node-id="${it}"]`);if(pt){let lt=pt.nextElementSibling;for(;lt&&!(lt.getAttribute("data-type")==="NodeThematicBreak"||(A=lt.classList)!=null&&A.contains("protyle-wysiwyg__block--hr"));){const H=lt.getAttribute("data-type")==="NodeSuperBlock"?lt:lt.querySelector('[data-type="NodeSuperBlock"]');if(H){Y=H;break}lt=lt.nextElementSibling}}}else{const pt=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),lt=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const H of lt)if(!pt||H.compareDocumentPosition(pt)&Node.DOCUMENT_POSITION_FOLLOWING){Y=H;break}}}}const J=[];if(Y){const et=Array.from(Y.querySelectorAll(":scope > [data-node-id]"));for(const it of et){const pt=it.getAttribute("data-node-id");pt&&(J.push(pt),it.removeAttribute("style"))}}else if((M=t.targetSlide.value)!=null&&M.blocks){for(const et of t.targetSlide.value.blocks)if(et.children&&et.children.length>=2){for(const it of et.children)it.id&&J.push(it.id);break}}if(J.length>0)for(const et of J)await Dt(et,{style:""}).catch(()=>{});await r(le,""),ht.showMessage("已重置超级块为平均分布比例"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(Y){console.error("[useInspectorActions] resetSuperBlockWidth error:",Y),ht.showMessage("重置超级块比例失败")}}async function tt(){var A,M,Y;try{let J=null;if(typeof document<"u"){const it=t.currentPageDividerId.value||(t.activeBlockType.value==="hr"||t.activeBlockType.value==="NodeThematicBreak"?t.activeBlockId.value:""),pt=t.activeBlockId.value;let lt=[];if(it){const ut=document.querySelector(`.protyle-wysiwyg [data-node-id="${it}"]`);if(ut){let _=ut.nextElementSibling;for(;_&&!(_.getAttribute("data-type")==="NodeThematicBreak"||(A=_.classList)!=null&&A.contains("protyle-wysiwyg__block--hr"));)lt.push(_),_=_.nextElementSibling}}else{const ut=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),_=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const O of _)if(!ut||O.compareDocumentPosition(ut)&Node.DOCUMENT_POSITION_FOLLOWING)lt.push(O);else break}const H=[];let at;for(const ut of lt){const _=ut.getAttribute("data-type");_==="NodeHeading"&&(at=ut.getAttribute("data-node-id")||void 0);const O=[];_==="NodeSuperBlock"?O.push(ut):O.push(...Array.from(ut.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const g of O){if((g.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const F=g.getAttribute("data-node-id")||"";let S=[];const I=Array.from(g.querySelectorAll('[data-type="NodeListItem"]'));if(I.length===4&&(S=I.map(R=>R.getAttribute("data-node-id")).filter(Boolean)),S.length!==4){const R=Array.from(g.querySelectorAll(":scope > [data-node-id]"));R.length===4&&(S=R.map(Z=>Z.getAttribute("data-node-id")).filter(Boolean))}S.length===4&&H.push({sbId:F,itemIds:S,headerId:at})}}H.length>0&&(pt&&(J=H.find(ut=>{if(ut.sbId===pt||ut.itemIds.includes(pt))return!0;const _=document.querySelector(`.protyle-wysiwyg [data-node-id="${ut.sbId}"]`),O=document.querySelector(`.protyle-wysiwyg [data-node-id="${pt}"]`);return!!(_&&O&&_.contains(O))})||null),J||(J=H[0]))}if(!J&&((M=t.targetSlide.value)!=null&&M.blocks)){const it=t.targetSlide.value,pt=[];for(const H of it.blocks)H.rawNode?pt.push(H.rawNode):pt.push({id:H.id,type:H.type,content:H.content,markdown:H.rawMarkdown,children:H.children,ial:H.attributes||H.ial||{}});const lt=mf(pt,t.activeBlockId.value);lt&&lt.items.length===4&&(J={sbId:lt.superBlockNode.id,itemIds:lt.items.map(H=>H.id),headerId:(Y=lt.headerNode)==null?void 0:Y.id})}if(!J||J.itemIds.length!==4)return ht.showMessage("当前页面未找到包含 4 个组件的超级块（需包含 4 个列表项或 4 个子块）",4e3,"info"),!1;const et=t.currentPageDividerId.value||t.currentDocId.value;et&&(t.currentPageDividerLayout.value="clover",t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout="clover"),Et.setBlockAttrOverride(et,{[gt]:"clover"}),Jt(et,{[gt]:"clover"}),await Dt(et,{[gt]:"clover"}).catch(()=>{})),J.headerId&&(Et.setBlockAttrOverride(J.headerId,{[At]:"header"}),Jt(J.headerId,{[At]:"header"}),await Dt(J.headerId,{[At]:"header"}).catch(()=>{}));for(let it=0;it<4;it++){const pt=J.itemIds[it],lt=`col-${it+1}`;Et.setBlockAttrOverride(pt,{[At]:lt}),Jt(pt,{[At]:lt}),await Dt(pt,{[At]:lt}).catch(()=>{})}return ht.showMessage("已将本页版式设为四叶草（田字型）布局"),t.plugin&&await t.plugin.compileCurrentDocument(),!0}catch(J){return console.error("[useInspectorActions] applyCloverLayout error:",J),ht.showMessage("配置四叶草布局失败",4e3,"error"),!1}}return{triggerSaveNotice:n,saveAttrs:s,saveAttr:o,savePageAttr:r,applyPageLayoutAndRatio:a,applyCloverLayout:tt,resetSuperBlockWidth:j,saveDocAttr:c,onToggleVideoAutoplay:d,onToggleVideoLoop:m,onToggleVideoMuted:b,onToggleVideoControls:u,onImageRoleChange:h,onToggleNoteBlock:v,createNoteBlockOnCurrentSlide:f,onAddNoteBlock:k,onLocateNoteBlock:x,onGenerateNotesWithAI:$,isBatchProcessing:e,onBatchAppendNotes:B,onBatchDeleteNotes:L,toggleElemClick:T,onElemClickStepChange:w,onElemMotionChange:W,onElemSlotChange:V,onElemShikiLinesChange:q,onElemMaxHeightChange:X,onSetTwoColsContrast:C,onClearBlockAttrs:z,onInsertDividerBefore:y,onInsertDividerAfter:D,onDeleteCurrentBlock:U,onExportHtml:E,onExportPdf:P}}const i0={class:"spm-slidev-inspector"},n0={class:"spm-inspector-topbar"},s0={class:"spm-inspector-title"},o0={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},r0={class:"spm-inspector-topbar-actions"},l0={class:"spm-target-banner"},a0={class:"spm-target-info"},c0=["aria-label"],d0={key:0,class:"spm-save-status"},u0=["title"],f0={class:"spm-inspector-body"},p0=Ce({__name:"SlidevInspectorDockView",setup(t,{expose:e}){const i=ti("plugin"),n=bt(!1);function s(Q){n.value=!1,c.value=Q.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(Q.docId)}const o=bt(""),l=bt(""),r=bt({}),a=bt(""),c=bt(""),d=bt(""),m=bt(""),b=bt(""),u=bt(""),h=bt(""),f=bt(""),v=bt(null),k=bt(""),x=bt("");function $(){var vt;const Q=o.value||c.value;Q&&typeof navigator<"u"&&(vt=navigator==null?void 0:navigator.clipboard)!=null&&vt.writeText&&navigator.clipboard.writeText(Q).then(()=>{x.value="已复制！",setTimeout(()=>{x.value=""},1500)}).catch(()=>{})}const B=_t(()=>Ma(l.value)),L=_t(()=>l.value==="NodeCodeBlock"),T=bt(!1),w=_t(()=>{if(T.value||Lt.value)return!0;const Q=a.value||"";return!!wi(Q)}),W=_t(()=>{const Q=l.value||"";if(Q==="NodeVideo"||Q==="video")return!0;const vt=a.value||"";return!!(/<video\b/i.test(vt)||/\.mp4\b/i.test(vt))}),V=_t(()=>!o.value||o.value===c.value||l.value==="doc"||l.value==="NodeDocument"),q=_t(()=>{const Q=o.value||c.value||"";return Q.length>8?Q.slice(-8):Q||"无"}),X=_t(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),C=_t(()=>{if(B.value)return"分页符 (---)";if(V.value)return"全局文档";if(W.value)return"视频块";let Q="内容块";switch(l.value){case"NodeHeading":Q="标题块";break;case"NodeParagraph":Q="段落块";break;case"NodeCodeBlock":Q="代码块";break;case"NodeVideo":Q="视频块";break;case"NodeList":case"NodeListItem":Q="列表项";break;case"NodeBlockquote":Q="引述块";break;case"NodeTable":Q="表格块";break;case"NodeSuperBlock":case"s":case"sb":Q="超级块";break;default:Q="内容块";break}return u.value?h.value?`${h.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${Q}`:`分栏容器 › ${Q}`:Q}),z=_t(()=>B.value?"tag-divider":V.value?"tag-doc":"tag-block"),y=_t(()=>r.value[gt]||"default"),D=_t(()=>r.value[ee]||"slide-left"),U=bt(""),E=bt(""),P=_t(()=>r.value[gn]||"inherit"),j=_t(()=>{var Q;return Qy((Q=v.value)==null?void 0:Q.slides,{activeBlockId:o.value,activeBlockType:l.value,currentTopBlockId:d.value,currentPageDividerId:m.value,activeBlockAttrs:r.value})}),tt=_t(()=>{var Q;return((Q=j.value)==null?void 0:Q.notes)||""}),A=_t(()=>{var Q,vt,Ct;return((Ct=(vt=(Q=j.value)==null?void 0:Q.noteBlocks)==null?void 0:vt[0])==null?void 0:Ct.id)||""}),M=_t(()=>{var wt,Ft,Rt,fe,Un,ci;if(B.value){const te=r.value[gt]||r.value["custom-slidev-layout"];if(te)return te}const Q=r.value[At]||r.value["custom-slidev-slot"];if(Q&&(["col-1","col-2","col-3"].includes(Q)||/^col-\d+$/.test(Q)))return"cols-header";if(b.value)return b.value;const vt=m.value||(B.value?o.value:"");if(vt){const te=Et.getBlockAttrOverride(vt);if(te!=null&&te[gt])return te[gt]}if(vt&&((wt=v.value)!=null&&wt.slides)){const te=v.value.slides.find(Wi=>Wi.startBlockId===vt);if((Ft=te==null?void 0:te.frontmatter)!=null&&Ft.layout)return te.frontmatter.layout}if((fe=(Rt=j.value)==null?void 0:Rt.frontmatter)!=null&&fe.layout)return j.value.frontmatter.layout;if((ci=(Un=j.value)==null?void 0:Un.blocks)!=null&&ci.some(te=>te.slot&&(["col-1","col-2","col-3"].includes(te.slot)||/^col-\d+$/.test(te.slot))))return"cols-header";const Ct=Et.getBlockAttrOverride(c.value);return Ct!=null&&Ct[gt]?Ct[gt]:"default"}),Y=_t(()=>{var vt,Ct;if(B.value){const wt=r.value[le]||r.value["custom-slidev-layout-ratio"];if(wt)return wt}const Q=m.value||(B.value?o.value:"");if(Q){const wt=Et.getBlockAttrOverride(Q);if(wt!=null&&wt[le])return wt[le]}return((Ct=(vt=j.value)==null?void 0:vt.frontmatter)==null?void 0:Ct.layoutRatio)||""}),J=_t(()=>{var vt,Ct;if(B.value){const wt=r.value[vi]||r.value["custom-slidev-mask"];if(wt!==void 0)return wt}const Q=m.value||(B.value?o.value:"");if(Q){const wt=Et.getBlockAttrOverride(Q);if((wt==null?void 0:wt[vi])!==void 0)return wt[vi]}return((Ct=(vt=j.value)==null?void 0:vt.frontmatter)==null?void 0:Ct.mask)||""}),et=_t(()=>{var vt,Ct;if(B.value){const wt=r.value[bi]||r.value["custom-slidev-mask-ratio"];if(wt!==void 0)return wt}const Q=m.value||(B.value?o.value:"");if(Q){const wt=Et.getBlockAttrOverride(Q);if((wt==null?void 0:wt[bi])!==void 0)return wt[bi]}return((Ct=(vt=j.value)==null?void 0:vt.frontmatter)==null?void 0:Ct.maskRatio)||""}),it=_t(()=>{var vt,Ct;if(B.value){const wt=r.value[yi]||r.value["custom-slidev-mask-style"];if(wt!==void 0)return wt}const Q=m.value||(B.value?o.value:"");if(Q){const wt=Et.getBlockAttrOverride(Q);if((wt==null?void 0:wt[yi])!==void 0)return wt[yi]}return((Ct=(vt=j.value)==null?void 0:vt.frontmatter)==null?void 0:Ct.maskStyle)||"solid"}),pt=_t(()=>{var vt,Ct;if(B.value){const wt=r.value[ki]||r.value["custom-slidev-mask-initial"];if(wt!==void 0)return wt}const Q=m.value||(B.value?o.value:"");if(Q){const wt=Et.getBlockAttrOverride(Q);if((wt==null?void 0:wt[ki])!==void 0)return wt[ki]}return((Ct=(vt=j.value)==null?void 0:vt.frontmatter)==null?void 0:Ct.maskInitial)||"hidden"});function lt(Q){if(!Q||(Q.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Ct=Array.from(Q.querySelectorAll(":scope > [data-node-id]"));if(Ct.length<2)return null;const wt=Ct.length,Ft=Ct.map(ci=>{const te=ci.getAttribute("style")||"",Wi=te.match(/calc\(\s*([\d.]+)%/);if(Wi)return parseFloat(Wi[1]);const cn=te.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return cn?parseFloat(cn[1]):null});let Rt="",fe=!1;if(Ft.some(ci=>ci!==null)){fe=!0;const ci=Ft.reduce((Mt,pe)=>Mt+(pe||0),0),te=Ft.filter(Mt=>Mt===null).length,Wi=te>0?Math.max(0,100-ci)/te:100/Ct.length,cn=Ft.map(Mt=>Mt!==null?Mt:Wi),bc=cn.reduce((Mt,pe)=>Mt+pe,0)||1,dn=cn.map(Mt=>Mt/bc*100);if(dn.length===2){const[Mt]=dn;if(Mt>=48&&Mt<=52)Rt="1:1";else if(Mt>=31&&Mt<=35)Rt="1:2";else if(Mt>=65&&Mt<=69)Rt="2:1";else if(Mt>=28&&Mt<=32)Rt="3:7";else if(Mt>=68&&Mt<=72)Rt="7:3";else if(Mt>=38&&Mt<=42)Rt="4:6";else if(Mt>=58&&Mt<=62)Rt="6:4";else{const pe=Math.round(Mt);Rt=`${pe}:${100-pe}`}}else if(dn.length===3){const[Mt,pe,di]=dn;if(Mt>=31&&Mt<=35&&pe>=31&&pe<=35&&di>=31&&di<=35)Rt="1:1:1";else if(Mt>=23&&Mt<=27&&pe>=48&&pe<=52&&di>=23&&di<=27)Rt="1:2:1";else if(Mt>=48&&Mt<=52&&pe>=23&&pe<=27&&di>=23&&di<=27)Rt="2:1:1";else if(Mt>=23&&Mt<=27&&pe>=23&&pe<=27&&di>=48&&di<=52)Rt="1:1:2";else{const tr=Math.round(Mt),er=Math.round(pe);Rt=`${tr}:${er}:${100-tr-er}`}}else Rt=dn.map(Mt=>Math.round(Mt)).join(":")}else fe=!1,Rt=Array.from({length:wt},()=>1).join(":");const Un=wt>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:wt,ratio:Rt,isCustomWidth:fe,recommendedLayout:Un}}function H(Q){if(!(Q!=null&&Q.blocks))return null;for(const vt of Q.blocks){const Ct=vt.rawNode;if(Ct&&se(Ct)&&Ke(Ct)){const Ft=an(Ct).length,Rt=Vo(Ct);return{hasSuperBlock:!0,colCount:Ft,ratio:Rt||Array.from({length:Ft},()=>1).join(":"),isCustomWidth:!!Rt,recommendedLayout:Ft>=2?"cols-header":"two-cols"}}}return null}const at=_t(()=>{var Q;if(typeof document<"u"){const vt=o.value;if(vt){const wt=document.querySelector(`.protyle-wysiwyg [data-node-id="${vt}"]`);if(wt){const Ft=wt.getAttribute("data-type")==="NodeSuperBlock"?wt:wt.closest('[data-type="NodeSuperBlock"]');if(Ft){const Rt=lt(Ft);if(Rt)return Rt}}}const Ct=m.value||(B.value?o.value:"");if(Ct){const wt=document.querySelector(`.protyle-wysiwyg [data-node-id="${Ct}"]`);if(wt){let Ft=wt.nextElementSibling;for(;Ft&&!(Ft.getAttribute("data-type")==="NodeThematicBreak"||(Q=Ft.classList)!=null&&Q.contains("protyle-wysiwyg__block--hr"));){const Rt=Ft.getAttribute("data-type")==="NodeSuperBlock"?Ft:Ft.querySelector('[data-type="NodeSuperBlock"]');if(Rt){const fe=lt(Rt);if(fe)return fe}Ft=Ft.nextElementSibling}}}else{const wt=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Ft=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Rt of Ft)if(!wt||Rt.compareDocumentPosition(wt)&Node.DOCUMENT_POSITION_FOLLOWING){const fe=lt(Rt);if(fe)return fe}}}return H(j.value)}),ut=_t(()=>{var Q;return((Q=at.value)==null?void 0:Q.ratio)||""}),_=_t(()=>{const Q=l.value||"";if(Q==="NodeSuperBlock"||Q==="s"||Q==="sb")return!0;if(typeof document<"u"&&o.value){const vt=document.querySelector(`.protyle-wysiwyg [data-node-id="${o.value}"]`);if(vt!=null&&vt.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),O=_t(()=>{var Q;return((Q=j.value)==null?void 0:Q.pageIndex)||1}),g=_t(()=>!!(r.value[ne]||r.value["slidev-note"]));function N(){if(!u.value)return!1;if(o.value===u.value||typeof document>"u")return!0;const Q=document.querySelector(`.protyle-wysiwyg [data-node-id="${u.value}"]`)||document.querySelector(`[data-node-id="${u.value}"]`);if(!Q)return!1;const vt=Q.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(vt==null?void 0:vt.getAttribute("data-node-id"))===o.value}const F=_t(()=>{var vt;if(r.value[Wt]!==void 0)return r.value[Wt]||"";if(u.value&&N())return f.value||"";if(u.value)return"";const Q=o.value;if(Q&&((vt=j.value)!=null&&vt.blocks)){const Ct=j.value.blocks.find(wt=>wt.id===Q);if(Ct!=null&&Ct.clicks)return Ct.clicks}return""}),S=_t(()=>{var vt;if(r.value[Ve])return r.value[Ve];const Q=o.value;if(Q&&((vt=j.value)!=null&&vt.blocks)){const Ct=j.value.blocks.find(wt=>wt.id===Q);if(Ct!=null&&Ct.motion)return typeof Ct.motion=="string"?Ct.motion:JSON.stringify(Ct.motion)}return""}),I=_t(()=>{var vt;if(r.value[At])return r.value[At];const Q=o.value;if(Q&&((vt=j.value)!=null&&vt.blocks)){const Ct=j.value.blocks.find(wt=>wt.id===Q);if(Ct!=null&&Ct.slot)return Ct.slot}return""}),R=bt(""),Z=bt(""),G=_t(()=>r.value[Di]==="true"),K=_t(()=>r.value[ds]==="true"),nt=_t(()=>r.value[qi]==="true"),ct=_t(()=>r.value[us]!=="false"),rt=_t(()=>{var Q,vt;return((vt=(Q=v.value)==null?void 0:Q.config)==null?void 0:vt.theme)||r.value[Cn]||"default"}),mt=_t(()=>{var Q,vt;return((vt=(Q=v.value)==null?void 0:Q.config)==null?void 0:vt.aspectRatio)||r.value[$n]||"16/9"}),$t=_t(()=>{var Q,vt;return((vt=(Q=v.value)==null?void 0:Q.config)==null?void 0:vt.defaultTransition)||r.value[In]||"slide-left"}),xt=_t(()=>{var Q,vt;return((vt=(Q=v.value)==null?void 0:Q.config)==null?void 0:vt.spacing)||r.value[ro]||"normal"}),Lt=_t(()=>{var Ft,Rt;if((r.value[Gt]||r.value["slidev-role"])===tl||r.value[Ut]==="true")return"background";const vt=r.value[gt]||r.value["slidev-layout"];if(vt==="image-left"||vt==="image-right")return vt;const Ct=a.value||"",wt=wi(Ct);if(wt&&((Rt=(Ft=j.value)==null?void 0:Ft.frontmatter)!=null&&Rt.background)){const fe=j.value.frontmatter.background;if(fe===wt||fe.endsWith(wt)||wt.endsWith(fe))return"background"}return""}),Zt=_t(()=>!!(r.value[Wt]||r.value[Ve]||r.value[At]||r.value[Ni]||r.value[ne]||r.value["slidev-note"]||r.value[Gt]||r.value[gt]||r.value[Di]||r.value[ds]||r.value[qi]||r.value[us])),{saveAttr:jt,savePageAttr:Xt,applyPageLayoutAndRatio:Nt,applyCloverLayout:Ge,resetSuperBlockWidth:oe,saveDocAttr:Yt,onToggleVideoAutoplay:Si,onToggleVideoLoop:Hi,onToggleVideoMuted:zs,onToggleVideoControls:Ns,onImageRoleChange:Wn,onToggleNoteBlock:_i,onAddNoteBlock:ji,onLocateNoteBlock:Oa,onGenerateNotesWithAI:za,isBatchProcessing:Na,onBatchAppendNotes:Fa,onBatchDeleteNotes:Ha,toggleElemClick:ja,onElemClickStepChange:Wa,onElemMotionChange:Ua,onElemSlotChange:Va,onElemShikiLinesChange:qa,onElemMaxHeightChange:Ka,onSetTwoColsContrast:Ga,onClearBlockAttrs:Za,onInsertDividerBefore:Ya,onInsertDividerAfter:Jo,onDeleteCurrentBlock:Ja,onExportHtml:Xa,onExportPdf:Qa}=e0({activeBlockId:o,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:m,currentPageDividerLayout:b,parentContainerId:u,parentContainerClicks:f,latestDoc:v,targetSlide:j,currentSlideNoteBlockId:A,currentSlideLayout:M,isNoteBlock:g,elemClick:F,videoAutoplay:G,videoLoop:K,videoMuted:nt,videoControls:ct,pageBackground:U,pageImage:E,elemShikiLines:R,elemMaxHeight:Z,saveStatus:k,plugin:i});async function tc(Q){if(Q==="clover"){if(!await Ge())return}else jt(gt,Q)}function ec(Q){Xt(le,Q)}function ic(Q){Xt(vi,Q)}function nc(Q){Xt(bi,Q)}function sc(Q){Xt(yi,Q)}function oc(Q){Xt(ki,Q)}function Xo(Q){if(!Q)return;const vt=Q.recommendedLayout||(Q.colCount&&Q.colCount>=2?"cols-header":"two-cols"),Ct=Q.ratio||(Q.colCount?Array(Q.colCount).fill(1).join(":"):"1:1");Nt(vt,Ct)}function rc(Q){Xt(le,Q)}async function lc(){await oe()}function ac(Q){jt(ee,Q)}function cc(Q){U.value=Q,jt(Ut,Q)}function dc(Q){E.value=Q,jt(Ee,Q)}function uc(Q){jt(gn,Q==="inherit"?"":Q)}function fc(Q){Yt(Cn,Q)}function pc(Q){Yt($n,Q)}function hc(Q){Yt(In,Q)}function mc(Q){Yt(ro,Q)}function Qo(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function gc(){typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function vc(){i!=null&&i.executeCommand&&i.executeCommand("slidevAiSplit")}return e({setActiveBlock(Q){o.value=Q.id,l.value=Q.type,r.value={...Q.attrs},a.value=Q.content||Q.markdown||"",d.value=Q.topBlockId||Q.id,m.value=Q.pageDividerId||"",b.value=Q.pageDividerLayout||"",u.value=Q.parentContainerId||"",h.value=Q.parentContainerSlot||"",f.value=Q.parentContainerClicks||"",Q.rootId?c.value=Q.rootId:(Q.type==="doc"||Q.type==="NodeDocument")&&Q.id&&(c.value=Q.id),U.value=Q.attrs[Ut]||"",E.value=Q.attrs[Ee]||"",R.value=Q.attrs[Ni]||"",Z.value=Q.attrs[An]||"",T.value=!!Q.isImage},updateDocument(Q){v.value=Q,c.value=Q.docId},openImportDialog(){n.value=!0},setCurrentDocId(Q){c.value=Q}}),(Q,vt)=>(st(),ot("div",i0,[p("div",n0,[p("div",s0,[(st(),ot("svg",o0,[...vt[2]||(vt[2]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),vt[3]||(vt[3]=p("span",null,"演示配置",-1))]),p("div",r0,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:vt[0]||(vt[0]=Ct=>n.value=!0)},[dt(ft,{name:"import"}),vt[4]||(vt[4]=p("span",null,"导入",-1))]),p("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:Qo},[dt(ft,{name:"split-preview"}),vt[5]||(vt[5]=p("span",null,"分屏预览",-1))])])]),p("div",l0,[p("div",a0,[p("span",{class:It(["spm-target-tag",z.value])},St(C.value),3),p("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":x.value||"点击复制 ID: "+(o.value||c.value),onClick:$},[dt(ft,{name:"copy"}),p("span",null,"#"+St(q.value),1)],8,c0)]),k.value?(st(),ot("span",d0,"● "+St(k.value),1)):Pt("",!0)]),X.value?(st(),ot("div",{key:0,class:"spm-context-quote",title:a.value},St(X.value),9,u0)):Pt("",!0),p("div",f0,[B.value?(st(),De(Cv,{key:0,"page-layout":y.value,"page-layout-ratio":Y.value,"page-mask":J.value,"page-mask-ratio":et.value,"page-mask-style":it.value,"page-mask-initial":pt.value,"detected-sb-ratio":ut.value,"detected-sb-info":at.value,"page-transition":D.value,"page-background":U.value,"page-spacing":P.value,"page-image":E.value,"page-notes":tt.value,"page-index":O.value,"onUpdate:pageLayout":tc,"onUpdate:pageLayoutRatio":ec,"onUpdate:pageMask":ic,"onUpdate:pageMaskRatio":nc,"onUpdate:pageMaskStyle":sc,"onUpdate:pageMaskInitial":oc,onApplySuperBlockLayout:Xo,onResetSuperblockRatio:lc,"onUpdate:pageTransition":ac,"onUpdate:pageBackground":cc,"onUpdate:pageSpacing":uc,"onUpdate:pageImage":dc,onAddNoteBlock:yt(ji),onLocateNoteBlock:yt(Oa),onGenerateNotes:yt(za),onBatchAppendNotes:yt(Fa),onBatchDeleteNotes:yt(Ha),"is-batch-processing":yt(Na),onInsertDividerAfter:yt(Jo),onDeleteDivider:yt(Ja)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):o.value&&!V.value?(st(),De(cb,{key:1,"elem-click":F.value,"elem-motion":S.value,"elem-slot":I.value,"elem-shiki-lines":R.value,"elem-max-height":Z.value,"is-code-block":L.value,"is-image":w.value,"is-video":W.value,"is-super-block":_.value,"detected-sb-info":at.value,"video-autoplay":G.value,"video-loop":K.value,"video-muted":nt.value,"video-controls":ct.value,"has-block-attrs":Zt.value,"is-note":g.value,"image-role":Lt.value,"current-slide-layout":M.value,"parent-elem-click":f.value,"parent-container-slot":h.value,"parent-container-id":u.value,onToggleNote:yt(_i),onToggleElemClick:yt(ja),onToggleVideoAutoplay:yt(Si),onToggleVideoLoop:yt(Hi),onToggleVideoMuted:yt(zs),onToggleVideoControls:yt(Ns),"onUpdate:imageRole":yt(Wn),"onUpdate:elemClick":yt(Wa),"onUpdate:elemMotion":yt(Ua),"onUpdate:elemSlot":yt(Va),"onUpdate:elemShikiLines":yt(qa),"onUpdate:elemMaxHeight":yt(Ka),onApplySuperBlockLayout:Xo,onApplySuperBlockRatio:rc,onInsertDividerBefore:yt(Ya),onInsertDividerAfter:yt(Jo),onSetTwoColsContrast:yt(Ga),onClearBlockAttrs:yt(Za)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(st(),De(Kb,{key:2,"doc-theme":rt.value,"doc-aspect-ratio":mt.value,"doc-default-transition":$t.value,"doc-spacing":xt.value,"onUpdate:docTheme":fc,"onUpdate:docAspectRatio":pc,"onUpdate:docDefaultTransition":hc,"onUpdate:docSpacing":mc,onOpenBottomPreview:Qo,onOpenPresenter:gc,onAiAutoSplit:vc,onExportHtml:yt(Xa),onExportPdf:yt(Qa)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf"]))]),n.value?(st(),De(Xy,{key:1,onClose:vt[1]||(vt[1]=Ct=>n.value=!1),onSuccess:s})):Pt("",!0)]))}}),h0=2e3,m0=600;function g0(t){return!t||typeof t.closest!="function"?!1:!!t.closest(".fn__none")}function io(t){if(!t||typeof t.isConnected=="boolean"&&!t.isConnected)return!1;if(qr(t))return!0;const e=t.firstElementChild;return!!(e&&qr(e))}function qr(t){return typeof t.getClientRects=="function"&&t.getClientRects().length>0?!0:typeof t.offsetWidth=="number"&&t.offsetWidth>0&&t.offsetHeight>0}function v0(){const t=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof t=="function"?t:void 0}class b0{constructor(){kt(this,"consumers",new Map);kt(this,"seq",0);kt(this,"verifyTimer",null)}register(e,i,n){if(!i)return()=>{};const s=++this.seq,o=v0(),l={kind:e,element:i,visible:!1,measureOnDemand:!o,observer:null,onVisible:n};return o?(l.observer=new o(r=>{var d;const a=r[r.length-1];if(!a)return;const c=a.isIntersecting&&!l.visible;l.visible=a.isIntersecting,c&&((d=l.onVisible)==null||d.call(l))}),l.observer.observe(i)):l.visible=io(i),this.consumers.set(s,l),()=>{var r;(r=l.observer)==null||r.disconnect(),this.consumers.delete(s),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var e;for(const i of this.consumers.values())(e=i.observer)==null||e.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const e of this.consumers.values())if(e.measureOnDemand?io(e.element):this.isRecordVisible(e))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(e){return e.visible?!0:!g0(e.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let e=!1;for(const i of this.consumers.values())if(!i.measureOnDemand){e=!0;break}e&&(this.verifyTimer=setTimeout(()=>{var i;this.verifyTimer=null;for(const n of this.consumers.values())if(!n.visible&&io(n.element)){n.visible=!0,(i=n.onVisible)==null||i.call(n);return}},h0))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const os=new b0,jn=new Zo;function La(t,e,i){const n=()=>{var o;try{(o=i==null?void 0:i.flushDirtyCompile)==null||o.call(i)}catch{}},s=os.register(t,e,n);return n(),s}let mi=null,Le=null,rs=null;function y0(){return Le}function k0(t,e){mi&&Ra(),mi=da(cg),mi.provide("plugin",e),mi.provide("sandboxBridge",jn);const i=mi.mount(t);return Le=i,rs=La("preview",t,e),i}function Ra(t){rs&&(rs(),rs=null),mi&&(mi.unmount(),mi=null,Le=null)}let gi=null,Se=null,ls=null;function w0(t,e){gi&&Pa(),gi=da(p0),gi.provide("plugin",e),gi.provide("sandboxBridge",jn);const i=gi.mount(t);return Se=i,ls=La("dock",t,e),i}function Pa(t){ls&&(ls(),ls=null),gi&&(gi.unmount(),gi=null,Se=null)}function x0(t,e){Se!=null&&Se.updateDocument&&Se.updateDocument(t),Le!=null&&Le.updateDocument?Le.updateDocument(t,e):jn.updateSlides(t.slides,t.config,t.fullMarkdown)}function So(t){Le!=null&&Le.navigateToBlock?Le.navigateToBlock(t):jn.highlightElement(t)}function as(t){Se!=null&&Se.setActiveBlock&&Se.setActiveBlock(t)}function S0(){return Se!=null&&Se.openImportDialog?(Se.openImportDialog(),!0):!1}function _0(t,e){const i=[];let s=0;for(let o=0;o<t.length;o++){const l=t[o];if(Ss(l)){s=0;continue}const r=l.markdown||l.content||"";if(!(o===0)){if(l.type==="h"&&(l.subType==="h1"||r.startsWith("# "))){i.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),s=0;continue}if(l.type==="h"&&(l.subType==="h2"||r.startsWith("## "))){i.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),s=0;continue}}if(s++,s>=6&&o<t.length-1){const c=t[o+1];Ss(c)||(i.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),s=0)}}return i}const C0=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Mi,value:"true"},{key:gt,value:"cover"},{key:ee,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Mi,value:"true"},{key:gt,value:"two-cols"},{key:ee,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Mi,value:"true"},{key:gt,value:"fact"},{key:ee,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Mi,value:"true"},{key:gt,value:"intro"},{key:ee,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Mi,value:"true"},{key:gt,value:"quote"},{key:ee,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Wt,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Wt,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:At,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Ni,value:"1-3"}]}];class no{getPresetTemplates(){return C0}buildScanSlidevBlocksSql(e="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${e}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${ee}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(e,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = '${ee}' AND value = '${e}'`,l=await n(o);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await s(c,{[ee]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(e,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${e}'`,l=await n(o);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await s(c,{"custom-slidev-layout":i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const e=this.getPresetTemplates();return JSON.stringify({templates:e,counter:e.length},null,2)}formatTransitionSummary(e){return!e||e.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${e.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function $0(t){t.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{t.openBottomPreviewTab()}}),t.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{S0()||ht.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),t.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const e=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(e==null?void 0:e.getAttribute("data-doc-id"))||""}t.currentDocId&&(await Dt(t.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),ht.showMessage("已为当前文档初始化 Slidev 演示属性"),t.compileCurrentDocument(t.currentDocId))}}),t.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const o=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(o==null?void 0:o.getAttribute("data-doc-id"))||""}if(!t.currentDocId){ht.showMessage("请先打开一篇思源笔记文档");return}const e=await cs(t.currentDocId).catch(()=>[]);if(!e||e.length===0){ht.showMessage("当前文档无内容，无需断页");return}const i=e.map(o=>({id:o.id,type:o.type,subType:o.subType,content:o.content||"",markdown:o.markdown||""})),n=_0(i);if(n.length===0){ht.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}ht.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let s=0;for(const o of n)try{await Bi("markdown","---",void 0,o.blockId),await Dt(o.blockId,{"custom-slidev-layout":o.recommendedLayout}),s++}catch(l){console.warn("Failed to insert divider:",l)}ht.showMessage(`已成功在 ${s} 处插入分页线并重新编译`),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,d,m;if(!t.currentDocId){const b=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(b==null?void 0:b.getAttribute("data-doc-id"))||""}if(!t.currentDocId){ht.showMessage("请先打开一篇思源笔记文档");return}ht.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const e=await cs(t.currentDocId).catch(()=>[]),i={startBlockId:t.currentDocId,blocks:e.map(b=>({id:b.id,type:b.type,content:b.content||"",rawMarkdown:b.markdown||""})),rawMarkdown:""},o=`> [!NOTE] 💡 演讲备注
${(await t0(i,Yr)).split(/\r?\n/).map(b=>`> ${b}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await so("markdown",o,t.currentDocId).catch(()=>null),r=((d=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:d.id)||((m=l==null?void 0:l[0])==null?void 0:m.id);r&&(await Dt(r,{"custom-slidev-note":"true"}),Et.setBlockAttrOverride(r,{"custom-slidev-note":"true"}),zi(r,t.app)),ht.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const e=new no,i=e.buildTransitionStatsSql(),n=await tn(i).catch(()=>[]),s=e.formatTransitionSummary(n||[]);ht.showMessage(s)}}),t.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new no().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),ht.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ht.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),t.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new no().batchUpdateTransitions("fade","slide-left",n=>tn(n).catch(()=>[]),(n,s)=>Dt(n,s));ht.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),t.compileCurrentDocument()}}),t.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),t.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){ht.showMessage("请先打开并放映一篇思源笔记文档");return}t.cliBridge.downloadSlidesMd(t.latestCompiledDoc,`slides-${t.currentDocId||"demo"}.md`)&&ht.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),t.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{ht.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await t.cliBridge.probeServer(1500)?ht.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):ht.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),t.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){ht.showMessage("请先打开并放映一篇思源笔记文档");return}const e=await t.cliBridge.syncToWorkspaceFile(t.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",oo);e.success?ht.showMessage(`已成功同步最新 slides.md 至工作空间：${e.path}`):ht.showMessage(`同步失败：${e.error}`)}})}class I0{constructor(e=400){kt(this,"entries",new Map);this.ttlMs=e}get(e,i=Date.now()){if(!e)return;const n=this.entries.get(e);if(n){if(i-n.at>this.ttlMs){this.entries.delete(e);return}return n.attrs}}set(e,i,n=Date.now()){!e||!i||this.entries.set(e,{attrs:i,at:n})}invalidate(e){e?this.entries.delete(e):this.entries.clear()}get size(){return this.entries.size}}function A0(t){const e=new Map;if(!(t!=null&&t.slides))return e;const i=n=>{for(const s of n||[])s!=null&&s.id&&s.ial&&e.set(s.id,s.ial)};for(const n of t.slides)i(n.blocks),i(n.noteBlocks);return e}class T0{constructor(e=150){kt(this,"lastBlockId","");kt(this,"lastAt",0);this.windowMs=e}shouldSkip(e,i=Date.now()){return e&&e===this.lastBlockId&&i-this.lastAt<this.windowMs?!0:(this.lastBlockId=e,this.lastAt=i,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class B0{constructor(){kt(this,"attrCache",new I0);kt(this,"compiledIalIndex",{doc:null,map:new Map})}async resolveBlockAttrs(e,i){if(!e)return{};const n=Et.getBlockAttrOverride(e),s=this.getCompiledIal(i,e);if(n||s)return{...s||{},...n||{}};const o=this.attrCache.get(e);if(o)return o;const l=await _o(e).catch(()=>({}))||{};return this.attrCache.set(e,l),l}getCompiledIal(e,i){if(e)return this.compiledIalIndex.doc!==e&&(this.compiledIalIndex={doc:e,map:A0(e)}),this.compiledIalIndex.map.get(i)}invalidateAttrCache(e){this.attrCache.invalidate(e)}getActiveDocumentId(){if(typeof document>"u")return"";const e=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=e==null?void 0:e.getAttribute("data-node-id");if(i)return i;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=document.querySelector("[data-doc-id]"),l=o==null?void 0:o.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(e,i=""){const n=e.closest(".protyle-title"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=e.closest(".protyle"),l=o==null?void 0:o.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=e.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||i}async switchToDocGlobalInspector(e,i){var o;if(!e)return;let n=i||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${e}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${e}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((o=l==null?void 0:l.innerText)==null?void 0:o.trim())||""}const s=await this.resolveBlockAttrs(e,null);as({id:e,rootId:e,type:"doc",content:n,attrs:s,isDivider:!1,isCode:!1}),So(e)}handleBlockClickedFromSlide(e,i,n,s){var a;if(!e)return!1;const o=zi(e,i),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`),r=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,e,r,n,s);else{let c="",d="";if(s!=null&&s.slides){const m=s.slides.find(b=>{var u,h,f;return b.startBlockId===e||((u=b.blocks)==null?void 0:u.some(v=>v.id===e))||((h=b.allBlockIds)==null?void 0:h.includes(e))||((f=b.noteBlocks)==null?void 0:f.some(v=>v.id===e))});m!=null&&m.startBlockId&&(c=m.startBlockId),(a=m==null?void 0:m.frontmatter)!=null&&a.layout&&(d=m.frontmatter.layout)}this.resolveBlockAttrs(e,s).then(async m=>{if(c&&!d){const b=Et.getBlockAttrOverride(c);if(b!=null&&b[gt]||b!=null&&b["custom-slidev-layout"])d=b[gt]||b["custom-slidev-layout"]||"";else{const u=await this.resolveBlockAttrs(c,s);d=u[gt]||u["custom-slidev-layout"]||"",u&&Object.keys(u).length>0&&Et.setBlockAttrOverride(c,u)}}as({id:e,rootId:n,type:r||"NodeParagraph",attrs:m||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return o}async syncInspectorBlock(e,i,n,s,o){var D,U,E,P,j,tt,A,M;let l=e,r=i,a=n;const c=e.closest('[data-type="NodeCallout"]');if(c&&c!==e){const Y=c.getAttribute("data-node-id");if(Y){const J=await this.resolveBlockAttrs(Y,o),et=Et.getBlockAttrOverride(Y)||{},it={...J,...et};(it[ne]||it["slidev-note"])&&(l=c,r=Y,a="NodeCallout")}}const d=l.closest(".protyle-wysiwyg > [data-node-id]")||l,m=(d==null?void 0:d.getAttribute("data-node-id"))||r,b=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(d==null?void 0:d.getAttribute("data-type"))==="NodeThematicBreak"||(d==null?void 0:d.getAttribute("data-type"))==="tb"||!!((D=d==null?void 0:d.classList)!=null&&D.contains("hr")),u=a==="NodeCodeBlock",h=((U=l.innerText)==null?void 0:U.trim())||"",f=await this.resolveBlockAttrs(r,o),v=Et.getBlockAttrOverride(r)||{},k={...f,...v};let x="",$="";if(b)x=r,$=k[gt]||k["custom-slidev-layout"]||"";else{let Y=d.previousElementSibling;for(;Y;){const J=Y.getAttribute("data-type");if(J==="NodeThematicBreak"||J==="tb"||(E=Y.classList)!=null&&E.contains("hr")){x=Y.getAttribute("data-node-id")||"";break}Y=Y.previousElementSibling}}if(o!=null&&o.slides){const Y=[r,m];let J=l.parentElement;for(;J&&!J.classList.contains("protyle-wysiwyg");){const it=J.getAttribute("data-node-id");it&&!Y.includes(it)&&Y.push(it),J=J.parentElement}const et=o.slides.find(it=>{var pt,lt,H;return Y.includes(it.startBlockId)||((pt=it.blocks)==null?void 0:pt.some(at=>Y.includes(at.id)))||((lt=it.allBlockIds)==null?void 0:lt.some(at=>Y.includes(at)))||((H=it.noteBlocks)==null?void 0:H.some(at=>Y.includes(at.id)))});et&&(!x&&et.startBlockId&&(x=et.startBlockId),!$&&((P=et.frontmatter)!=null&&P.layout)&&($=et.frontmatter.layout))}if(x){const Y=Et.getBlockAttrOverride(x);if(Y&&(gt in Y||"custom-slidev-layout"in Y)&&($=Y[gt]||Y["custom-slidev-layout"]||""),!$&&(o!=null&&o.slides)){const J=o.slides.find(et=>et.startBlockId===x);(j=J==null?void 0:J.frontmatter)!=null&&j.layout&&($=J.frontmatter.layout)}if(!$){const J=await this.resolveBlockAttrs(x,o);$=J[gt]||J["custom-slidev-layout"]||"",J&&Object.keys(J).length>0&&Et.setBlockAttrOverride(x,J)}Jt(x,{[gt]:$||""})}else if(s){const Y=Et.getBlockAttrOverride(s);Y&&(gt in Y||"custom-slidev-layout"in Y)?$=Y[gt]||Y["custom-slidev-layout"]||"":!$&&((M=(A=(tt=o==null?void 0:o.slides)==null?void 0:tt[0])==null?void 0:A.frontmatter)!=null&&M.layout)&&($=o.slides[0].frontmatter.layout)}const B=l.getAttribute(gt)||l.getAttribute("custom-slidev-layout"),L=k[gt]||k["custom-slidev-layout"]||"";B&&B!==L&&Jt(r,{[gt]:L});const T=l.getAttribute(Gt)||l.getAttribute("custom-slidev-role"),w=k[Gt]||k["custom-slidev-role"]||"";T&&T!==w&&Jt(r,{[Gt]:w});let W="",V="",q="";const X=l.closest('[data-type="NodeListItem"]');if(X&&X!==l){const Y=X.getAttribute("data-node-id");if(Y){W=Y;const J=await this.resolveBlockAttrs(Y,o),et=Et.getBlockAttrOverride(Y)||{},it={...J,...et};V=it[At]||"",q=it[Wt]||"";const pt=it[gt]||it["custom-slidev-layout"]||"",lt=X.getAttribute(gt)||X.getAttribute("custom-slidev-layout");lt&&lt!==pt&&Jt(Y,{[gt]:pt});const H=it[Gt]||it["custom-slidev-role"]||"",at=X.getAttribute(Gt)||X.getAttribute("custom-slidev-role");at&&at!==H&&Jt(Y,{[Gt]:H})}}const C=!!l.querySelector("img, span[data-type='img']"),z=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),y=C&&z.length<=50;as({id:r,rootId:s,type:a,content:h,attrs:k,isDivider:b,isCode:u,isImage:y,topBlockId:m,pageDividerId:x,pageDividerLayout:$,parentContainerId:W,parentContainerSlot:V,parentContainerClicks:q})}patchThematicBreakTransactions(e){if((e==null?void 0:e.cmd)==="transactions"&&Array.isArray(e.data)){for(const i of e.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const n of i.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const s=n.data.old||{},o=n.data.new||{},l={};for(const r of Object.keys(s))r in o||(l[r]="");for(const[r,a]of Object.entries(o))l[r]=String(a??"");Jt(n.id,l),Et.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidevAttrs(e){var s,o,l;if(typeof document>"u"||!e)return;const i=new Map;if(Array.isArray(e.slides))for(const r of e.slides){if(r.startBlockId){const a=i.get(r.startBlockId)||{};(s=r.frontmatter)!=null&&s.layout&&(a[gt]=r.frontmatter.layout),i.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=i.get(a.id)||{};(o=a.ial)!=null&&o[gt]&&(c[gt]=a.ial[gt]),(l=a.ial)!=null&&l[Gt]&&(c[Gt]=a.ial[Gt]),Object.keys(c).length>0&&i.set(a.id,c)}}}const n=Et.getAllAttrOverrides();for(const[r,a]of n.entries()){const c=i.get(r)||{};a[gt]!==void 0&&(c[gt]=a[gt]),a[Gt]!==void 0&&(c[Gt]=a[Gt]),i.set(r,c)}oh(i)}}const Ti=new B0;class E0{constructor(){kt(this,"inFlightDocId",null);kt(this,"pendingDocId",null);kt(this,"generation",0)}get isRunning(){return this.inFlightDocId!==null}get runningDocId(){return this.inFlightDocId}get pending(){return this.pendingDocId}tryBegin(e){return this.inFlightDocId!==null?(this.pendingDocId=e,null):(this.inFlightDocId=e,++this.generation)}isStale(e){return e!==this.generation}finish(){this.inFlightDocId=null;const e=this.pendingDocId;return this.pendingDocId=null,e}reset(){this.inFlightDocId=null,this.pendingDocId=null,this.generation=0}}const M0=150,D0=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,L0="slidev-dock",Kr="slidev-preview-tab",Gr=af;class R0 extends ht.Plugin{constructor(){super(...arguments);kt(this,"isMobile",!1);kt(this,"currentDocId","");kt(this,"previewTab",null);kt(this,"latestCompiledDoc",null);kt(this,"cliBridge",new qo);kt(this,"debounceTimer",null);kt(this,"activeCursorBlockId","");kt(this,"compileScheduler",new E0);kt(this,"dirtyDocId",null);kt(this,"inspectorSyncThrottle",new T0);kt(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));kt(this,"onWsMainBound",this.onWsMain.bind(this));kt(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));kt(this,"onClickEditorTitleIconBound",this.onClickEditorTitleIcon.bind(this));kt(this,"onEditorClickBound",this.onEditorClick.bind(this));kt(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));kt(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));kt(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const i=ht.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(D0),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"Slidev 演示 (下方分屏)",position:"right",callback:()=>{this.openBottomPreviewTab()}}),$0(this);const n=this;if(this.addTab({type:Kr,init(s){const o=this||s;n.previewTab=(o==null?void 0:o.tab)||null,k0(o.element,n),n.updatePreviewTabHeader()},destroy(){n.previewTab===(this==null?void 0:this.tab)&&(n.previewTab=null),Ra(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:L0,init(){w0(this.element,n)},destroy(){Pa(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(s,o)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${s}`,{detail:o}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const s=()=>{const o=this.getActiveDocumentId();o&&(o!==this.currentDocId&&(this.currentDocId=o,this.updatePreviewTabHeader("",o)),this.latestCompiledDoc||this.markCompileDirty(o))};setTimeout(s,300),setTimeout(s,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(Gr),n=cf(i);return Li(n),n}catch{return Li(on),on}}async saveGlobalSettings(i){const n=Os(),s=Li({...n,...i||{}});try{await this.saveData(Gr,s)}catch(l){console.error("保存 Slidev 全局配置失败",l)}const o=this.currentDocId||this.getActiveDocumentId();return o&&this.markCompileDirty(o),s}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,os.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),jn.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const i=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",n=this.buildPreviewTabTitle(i);await ht.openTab({app:this.app,custom:{id:this.name+Kr,title:n,icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(i,this.currentDocId)}onClickEditorTitleIcon(i){var l;const n=i.detail,s=n==null?void 0:n.menu,o=((l=n==null?void 0:n.data)==null?void 0:l.id)||this.currentDocId;!s||!o||s.addItem({icon:"iconSlidev",label:"Slidev 全局演示配置",submenu:[{label:"初始化演示属性 (custom-slidev-*)",click:async()=>{await Dt(o,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),ht.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(o)}},{type:"separator"},{label:"主题: 默认 (default)",click:async()=>{await Dt(o,{"custom-slidev-theme":"default"}),ht.showMessage("已切换为 default 主题"),this.compileCurrentDocument(o)}},{label:"主题: 优雅衬线 (seriph)",click:async()=>{await Dt(o,{"custom-slidev-theme":"seriph"}),ht.showMessage("已切换为 seriph 主题"),this.compileCurrentDocument(o)}},{label:"主题: 苹果极简 (apple-basic)",click:async()=>{await Dt(o,{"custom-slidev-theme":"apple-basic"}),ht.showMessage("已切换为 apple-basic 主题"),this.compileCurrentDocument(o)}},{type:"separator"},{label:"画幅: 16 / 9 (宽屏)",click:async()=>{await Dt(o,{"custom-slidev-aspect-ratio":"16/9"}),ht.showMessage("已切换画幅为 16/9"),this.compileCurrentDocument(o)}},{label:"画幅: 4 / 3 (标屏)",click:async()=>{await Dt(o,{"custom-slidev-aspect-ratio":"4/3"}),ht.showMessage("已切换画幅为 4/3"),this.compileCurrentDocument(o)}}]})}async onSwitchProtyle(i){var l,r,a,c,d;const n=(l=i.detail)==null?void 0:l.protyle,s=(r=n==null?void 0:n.block)==null?void 0:r.rootID,o=((d=(c=(a=n==null?void 0:n.title)==null?void 0:a.editElement)==null?void 0:c.textContent)==null?void 0:d.trim())||"";if(s&&s!==this.currentDocId){this.currentDocId=s,this.activeCursorBlockId=s;const m=await _o(s).catch(()=>({}));as({id:s,rootId:s,type:"doc",attrs:m}),this.markCompileDirty(s),this.updatePreviewTabHeader(o,s)}}onClickEditorContent(i){var o,l;const n=i==null?void 0:i.detail;if(!n)return;const s=(l=(o=n.protyle)==null?void 0:o.block)==null?void 0:l.rootID;s&&(!this.currentDocId||this.currentDocId!==s)&&(this.currentDocId=s),n.event&&this.onEditorClick(n.event)}buildPreviewTabTitle(i){const n=(i||"").trim();return n?`即现（${n}）`:"即现"}async fetchDocumentTitle(i){var n,s,o;if(!i)return"";if(typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${i}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${i}"] .protyle-title__input`)||(this.getActiveDocumentId()===i?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),r=((l==null?void 0:l.innerText)||(l==null?void 0:l.textContent)||"").trim();if(r)return r}if(this.latestCompiledDoc&&this.latestCompiledDoc.docId===i){const l=(n=this.latestCompiledDoc.slides)==null?void 0:n[0],r=(s=l==null?void 0:l.blocks)==null?void 0:s.find(a=>a.type==="h"||a.type==="NodeHeading");if(r!=null&&r.content)return r.content.trim()}try{const l=await tn(`SELECT content FROM blocks WHERE id = '${i}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(l)&&l.length>0&&((o=l[0])!=null&&o.content))return String(l[0].content).trim()}catch{}return""}async updatePreviewTabHeader(i,n){var d,m,b;const s=y0(),o=!!((d=s==null?void 0:s.isPinned)!=null&&d.value),l=String(((m=s==null?void 0:s.pinnedDocId)==null?void 0:m.value)||"");if(o&&l&&n&&n!==l)return;const r=n||(o&&l?l:this.currentDocId||this.getActiveDocumentId());let a=(i||"").trim();!a&&r&&(a=await this.fetchDocumentTitle(r));const c=this.buildPreviewTabTitle(a);if(this.previewTab&&typeof this.previewTab.updateTitle=="function"){this.previewTab.updateTitle(c),this.previewTab.headElement&&this.previewTab.headElement.setAttribute("title",c);return}if(typeof document<"u"){const u=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const h of u){const f=h.querySelector(".item__text"),v=((b=f==null?void 0:f.textContent)==null?void 0:b.trim())||"";if(v.includes("Slidev 演示预览")||v.startsWith("即现")){f&&(f.textContent=c),h.setAttribute("title",c);break}}}}getActiveDocumentId(){return Ti.getActiveDocumentId()}resolveDocIdFromElement(i){return Ti.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,n){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await Ti.switchToDocGlobalInspector(i,n))}onWsMain(i){const n=i.detail;n&&n.cmd==="transactions"&&(Ti.patchThematicBreakTransactions(n),this.markCompileDirty())}markCompileDirty(i){const n=i||this.currentDocId||this.getActiveDocumentId();n&&(this.currentDocId||(this.currentDocId=n),this.dirtyDocId=n,this.scheduleDirtyCompile())}scheduleDirtyCompile(i=M0){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const n=os.getVisibility();if(n==="none")return;const s=n==="visible"?i:Math.max(i,m0);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const o=this.dirtyDocId;this.dirtyDocId=null,o&&this.compileCurrentDocument(o,{reason:"auto"})},s)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(i,n){return i?(this.activeCursorBlockId=i,Ti.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(i){const n=(i==null?void 0:i.detail)||i;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(i){const n=i.target;if(!n)return;const s=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(s||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const m=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),b=m==null?void 0:m.querySelector(".protyle-title__input"),u=((b==null?void 0:b.innerText)||(m==null?void 0:m.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const a=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,So(a)),this.syncInspectorBlock(r,a,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const n=i.anchorNode;if(!n)return;const s=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!s)return;const o=s.closest(".protyle-title");if(!!(o||s.closest(".protyle-content")&&!s.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(s);if(d&&this.activeCursorBlockId!==d){const m=o||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),b=m==null?void 0:m.querySelector(".protyle-title__input"),u=((b==null?void 0:b.innerText)||(m==null?void 0:m.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!s.closest(".protyle-wysiwyg"))return;const r=s.closest("[data-node-id]"),a=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";r&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(s)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,So(a)),this.syncInspectorBlock(r,a,c))}async syncInspectorBlock(i,n,s){this.inspectorSyncThrottle.shouldSkip(n)||await Ti.syncInspectorBlock(i,n,s,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i,n){const s=(n==null?void 0:n.reason)??"explicit";let o=i||this.currentDocId;if(!o){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,o=r;else return}if(s==="auto"&&os.getVisibility()==="none"){this.dirtyDocId=o;return}const l=this.compileScheduler.tryBegin(o);if(l!==null){this.dirtyDocId===o&&(this.dirtyDocId=null);try{const r=await Et.compile(o),a=!!this.currentDocId&&o!==this.currentDocId;!this.compileScheduler.isStale(l)&&!a&&(this.currentDocId||(this.currentDocId=o),this.latestCompiledDoc=r,x0(r,o),this.updatePreviewTabHeader("",o),this.purgeStaleDomSlidevAttrs(r))}catch(r){console.error("[SiYuanSlidev] Failed to compile document:",r)}finally{const r=this.compileScheduler.finish();r&&this.markCompileDirty(r)}}}purgeStaleDomSlidevAttrs(i){Ti.purgeStaleDomSlidevAttrs(i)}}module.exports=R0;
