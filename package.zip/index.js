"use strict";var ca=Object.create;var bs=Object.defineProperty;var da=Object.getOwnPropertyDescriptor;var ua=Object.getOwnPropertyNames;var fa=Object.getPrototypeOf,pa=Object.prototype.hasOwnProperty;var ha=(t,i,e)=>i in t?bs(t,i,{enumerable:!0,configurable:!0,writable:!0,value:e}):t[i]=e;var ma=(t,i,e,s)=>{if(i&&typeof i=="object"||typeof i=="function")for(let n of ua(i))!pa.call(t,n)&&n!==e&&bs(t,n,{get:()=>i[n],enumerable:!(s=da(i,n))||s.enumerable});return t};var En=(t,i,e)=>(e=t!=null?ca(fa(t)):{},ma(i||!t||!t.__esModule?bs(e,"default",{value:t,enumerable:!0}):e,t));var wt=(t,i,e)=>ha(t,typeof i!="symbol"?i+"":i,e);const vt=require("siyuan");async function me(t,i){const e=await vt.fetchSyncPost(t,i);return e.code===0?e.data:null}async function ga(){return me("/api/notebook/lsNotebooks","")}async function va(t,i,e){return me("/api/filetree/createDocWithMd",{notebook:t,path:i,markdown:e})}async function ba(t,i){const e=new FormData;e.append("assetsDirPath",t);for(const n of i)e.append("file[]",n);return me("/api/asset/upload",e)}async function nn(t,i,e,s,n){return me("/api/block/insertBlock",{dataType:t,data:i,nextID:e,previousID:s,parentID:n})}async function _r(t,i,e){return me("/api/block/appendBlock",{dataType:t,data:i,parentID:e})}async function Lo(t,i,e){return me("/api/block/updateBlock",{dataType:t,data:i,id:e})}async function ya(t){return me("/api/block/deleteBlock",{id:t})}async function ka(t){return me("/api/block/getBlockKramdown",{id:t})}async function Kn(t){return me("/api/block/getChildBlocks",{id:t})}async function zt(t,i){return me("/api/attr/setBlockAttrs",{id:t,attrs:i})}async function Ge(t){return me("/api/attr/getBlockAttrs",{id:t})}async function gn(t){return me("/api/query/sql",{stmt:t})}async function Ls(t,i,e){const s=new FormData;return s.append("path",t),s.append("isDir",i.toString()),s.append("modTime",Math.floor(Date.now()/1e3).toString()),s.append("file",e),me("/api/file/putFile",s)}async function Sr(t){const i="/api/ai/chatGPT";try{const e=await me(i,{msg:t});return typeof e=="string"&&e.trim().length>0?e.trim():e&&typeof e.content=="string"&&e.content.trim().length>0?e.content.trim():null}catch{return null}}async function wa(){return me("/api/storage/getInlineStyles","")}const rn="custom-slidev-theme",ln="custom-slidev-aspect-ratio",Cr="custom-slidev-highlighter",an="custom-slidev-default-transition",$r="custom-slidev-color-schema",xi="custom-slidev-slide",ft="custom-slidev-layout",Xt="custom-slidev-transition",Ut="custom-slidev-background",Ae="custom-slidev-image",zi="custom-slidev-notes",Ni="custom-slidev-class",Se="custom-slidev-click",He="custom-slidev-motion",Si="custom-slidev-shiki-lines",Tt="custom-slidev-slot",ie="custom-slidev-note",qt="custom-slidev-role",cn="custom-slidev-max-height",vi="custom-slidev-autoplay",Mn="custom-slidev-loop",Li="custom-slidev-muted",Bn="custom-slidev-controls",Ir="background",Os="image-left",Ps="image-right",Oi={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto"};function xa(t){var i,e,s,n,r;return t?{theme:((i=t[rn])==null?void 0:i.trim())||Oi.theme,aspectRatio:((e=t[ln])==null?void 0:e.trim())||Oi.aspectRatio,highlighter:((s=t[Cr])==null?void 0:s.trim())||Oi.highlighter,defaultTransition:((n=t[an])==null?void 0:n.trim())||Oi.defaultTransition,colorSchema:((r=t[$r])==null?void 0:r.trim())||Oi.colorSchema}:{...Oi}}function qn(t){var e,s,n,r,l;const i=(e=t.ial)==null?void 0:e[xi];return!!(i&&(i==="true"||i==="page"||i==="cover"||i==="end")||t.type==="tb"||t.type==="thematic-break"||t.type==="NodeThematicBreak"||((s=t.markdown)==null?void 0:s.trim())==="---"||((n=t.markdown)==null?void 0:n.trim())==="***"||t.type==="b"&&(((r=t.markdown)==null?void 0:r.trim())==="---"||((l=t.content)==null?void 0:l.trim())==="---"))}function Oo(t){const i={};let e="";if(!t)return{frontmatter:i,notes:e};t[ft]&&(i.layout=t[ft].trim()),t[Xt]&&(i.transition=t[Xt].trim()),t[Ut]&&(i.background=t[Ut].trim()),t[Ae]&&(i.image=t[Ae].trim()),t[Ni]&&(i.class=t[Ni].trim()),t[zi]&&(e=t[zi].trim());for(const[s,n]of Object.entries(t))if(s.startsWith("custom-slidev-")&&![ft,Xt,Ut,Ae,Ni,zi,xi].includes(s)){const r=s.replace(/^custom-slidev-/,"");try{i[r]=JSON.parse(n)}catch{i[r]=n}}return{frontmatter:i,notes:e}}function _a(t){const i={};if(!t)return i;const e=t[ie]??t["slidev-note"];e!=null&&e!==""&&e!=="false"&&e!=="0"&&(i.isNote=!0);const s=t[qt]??t["slidev-role"],n=t[Ut]??t["slidev-background"];(s===Ir||n==="true"||n==="1")&&(i.isBackground=!0);const r=t[ft]??t["slidev-layout"];r===Os||r===Ps?i.imageLayout=r:(s===Os||s===Ps)&&(i.imageLayout=s);const l=t[Se]??t["custom-slidev-clicks"]??t["slidev-click"]??t["slidev-clicks"];if(l!=null&&(i.clicks=l.trim()),t[He])try{const o=JSON.parse(t[He]);typeof o=="object"&&o!==null?i.motion={preset:o.preset||o.type||"fade-in",...o}:i.motion={preset:String(o).trim()}}catch{i.motion={preset:t[He].trim()}}return t[Si]&&(i.shikiLines=t[Si].trim()),t[cn]&&(i.maxHeight=t[cn].trim()),t[Tt]&&(i.slot=t[Tt].trim()),t.style&&t.style.trim()&&(i.style=t.style.trim()),i}function Sa(t,i){const e=[];let n=0;for(let r=0;r<t.length;r++){const l=t[r];if(qn(l)){n=0;continue}const o=l.markdown||l.content||"";if(!(r===0)){if(l.type==="h"&&(l.subType==="h1"||o.startsWith("# "))){e.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),n=0;continue}if(l.type==="h"&&(l.subType==="h2"||o.startsWith("## "))){e.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),n=0;continue}}if(n++,n>=6&&r<t.length-1){const c=t[r+1];qn(c)||(e.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),n=0)}}return e}function Po(t,i){const e=(t.blocks||[]).filter(l=>{const o=(l.content||l.rawMarkdown||"").trim();return o&&o!=="---"});if(e.length===0)return"本页暂无内容，建议过渡承接上下文。";const s=[],n=[];for(const l of e){const o=(l.content||l.rawMarkdown||"").trim();o&&(l.type==="h"||o.startsWith("#")?s.push(o.replace(/^#+\s*/,"")):n.push(o.slice(0,50)))}const r=[];return s.length>0&&r.push(`【核心重点】：${s.join("、")}`),n.length>0&&(r.push("【口播要点】："),n.slice(0,3).forEach((l,o)=>{r.push(`${o+1}. 讲解 ${l}`)})),r.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),r.join(`
`)}async function Ar(t,i){const e=t.blocks&&t.blocks.length>0?t.blocks.map(s=>(s.content||s.rawMarkdown||"").trim()).filter(s=>s&&s!=="---").join(`
`):(t.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(i&&e){const s=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${e}`;try{const n=await i(s);if(n&&n.trim())return{notes:n.trim(),isAiGenerated:!0}}catch(n){return{notes:Po(t),isAiGenerated:!1,error:(n==null?void 0:n.message)||"AI 调用异常"}}}return{notes:Po(t),isAiGenerated:!1}}async function Ca(t,i){return(await Ar(t,i)).notes}const Tr=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function $a(t){const i=[];if(!t)return i;const e=new RegExp(Tr.source,"g");let s;for(;(s=e.exec(t))!==null;){const n=s[2]??s[3]??s[4];i.push({fullMatch:s[0],blockId:s[1],anchorText:n?n.trim():void 0})}return i}function Ia(t,i){if(!t)return"";const e=new RegExp(Tr.source,"g");return t.replace(e,(s,n,r,l,o)=>{const a=(r??l??o??"").trim();if(i&&i[n]){const d=i[n].trim();return`<div class="slidev-block-ref" data-ref-id="${n}">${d}</div>`}const c=a||`Ref(${n.slice(0,8)})`;return`<a href="siyuan://blocks/${n}" data-ref-id="${n}" class="slidev-ref-tag">🔗 ${c}</a>`})}function Aa(t){return t.markdown&&t.markdown.trim()?t.markdown.trim():t.content&&t.content.trim()?t.content.trim():""}function Ta(t){const i={};if(!t)return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),s=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let n;for(;(n=s.exec(e))!==null;){const r=n[1],l=n[2]??n[3]??n[4]??"";i[r]=l}return i}function Ea(t){if(!t)return!1;const i=t.trim();return i.startsWith("assets/")||i.startsWith("./assets/")||i.startsWith("/assets/")}function Ma(t){const i=t.trim();return i.startsWith("./assets/")?i.slice(2):i.startsWith("/assets/")?i.slice(1):i}function _e(t,i){if(!Ea(t))return t;const e=Ma(t);return i!=null&&i.base64Map&&i.base64Map[e]?i.base64Map[e]:i!=null&&i.baseUrl?`${i.baseUrl.replace(/\/+$/,"")}/${e}`:`/${e}`}function Ba(t,i){if(!t)return"";let e=t;return e=e.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(s,n,r)=>{const l=_e(r,i);return`![${n}](${l})`}),e=e.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(s,n,r,l)=>{const o=_e(r,i);return`${n}${o}${l}`}),e=e.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(s,n,r,l)=>{const o=_e(r,i);return`${n}${o}${l}`}),e}function fi(t,i){const e=(t||i||"").trim();if(!e)return null;const s=e.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(s)return s[1].trim();const n=e.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(n)return n[1].trim();const r=e.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(r)?r:null}function de(t){if(!t)return!1;const i=(t.type||"").toLowerCase();return i==="s"||i==="sb"||i==="nodesuperblock"}function Mi(t){if(!de(t))return!1;const i=(t.subType||"").toLowerCase();if(i==="col"||i==="h"||i==="horizontal")return!0;if(i==="row"||i==="v"||i==="vertical")return!1;if(t.ial){const s=(t.ial["data-sb-layout"]||t.ial.layout||"").toLowerCase();if(s==="col"||s==="h")return!0;if(s==="row"||s==="v")return!1}if(t.children&&t.children.length>0){for(const s of t.children)if(s.type==="NodeSuperBlockLayoutMarker"||s.type==="layout-marker"){const n=(s.content||s.markdown||"").trim().toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}}const e=(t.markdown||t.content||"").trim();return/^\{\{\{col\b/i.test(e)?!0:!/^\{\{\{row\b/i.test(e)}function Ki(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="i"||i==="nodelistitem"||i==="l"||i==="nodelist")return!0;const e=(t.markdown||t.rawMarkdown||t.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(e)}function Rs(t){return!t||Ki(t)||de(t)||!fi(t.markdown,t.content)?!1:(t.markdown||t.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function pi(t){if(!t||!de(t)||!Mi(t))return null;const i=(t.children||[]).filter(n=>{const r=n.type||"";if(r==="NodeSuperBlockOpenMarker"||r==="NodeSuperBlockLayoutMarker"||r==="NodeSuperBlockCloseMarker"||r==="open-marker"||r==="layout-marker"||r==="close-marker")return!1;const l=(n.markdown||n.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(l)||l==="}}}")});if(i.length<2)return null;const e=Rs(i[0]),s=Rs(i[i.length-1]);if(e&&!s){const n=fi(i[0].markdown,i[0].content);if(n)return{imageNode:i[0],imageUrl:n,layout:Os,contentNodes:i.slice(1)}}if(!e&&s){const n=fi(i[i.length-1].markdown,i[i.length-1].content);if(n)return{imageNode:i[i.length-1],imageUrl:n,layout:Ps,contentNodes:i.slice(0,i.length-1)}}return null}function Da(t,i){const e=[];function s(n){for(const r of n){const l=pi(r);if(l){const{imageNode:o,layout:a}=l;o.ial||(o.ial={});const c=o.ial[ft];if(c!==a){const d={blockId:o.id,layout:a,previousLayout:c};o.ial[ft]=a,e.push(d),i&&i(d)}}r.children&&r.children.length>0&&s(r.children)}}return s(t),e}function Qs(t){return(t.children||[]).filter(i=>{const e=i.type||"";if(e==="NodeSuperBlockOpenMarker"||e==="NodeSuperBlockLayoutMarker"||e==="NodeSuperBlockCloseMarker"||e==="open-marker"||e==="layout-marker"||e==="close-marker")return!1;const s=(i.markdown||i.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(s)||s==="}}}")})}function La(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="h"||i==="nodeheading"||/^h[1-6]$/i.test(t.subType||""))return!0;const e=(t.markdown||t.content||"").trim();return!!/^#{1,6}\s+/.test(e)}function zs(t){if(!t)return"";const i=t.split(/\r?\n/);if(i.length===0)return"";const e=i[0],s=e.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!s)return t;const n=s[1].length,r=s[2].trim(),l=e.length-s[2].length;if(i.length===1)return r;const o=[r];for(let a=1;a<i.length;a++){const c=i[a];if(!c.trim()){o.push("");continue}const d=c.match(/^(\s*)/),h=d?d[1].length:0;h>=l?o.push(c.slice(l)):h>n?o.push(c.slice(h)):o.push(c)}return o.join(`
`)}function _i(t){if(!t)return[];if(de(t)&&Mi(t)&&!pi(t)){const s=Qs(t),n=[];for(const r of s)n.push(..._i(r));return n}const i=(t.type||"").toLowerCase();if(i==="l"||i==="nodelist"||i==="list"){if(t.children&&t.children.length>0){const l=t.children.filter(Ki);if(l.length>0)return l}const n=(t.markdown||t.content||"").trim().split(/\r?\n/),r=[];for(let l=0;l<n.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(n[l])&&r.push(l);if(r.length>=2){const l=[];for(let o=0;o<r.length;o++){const a=r[o],c=o+1<r.length?r[o+1]:n.length,d=n.slice(a,c).join(`
`);l.push({id:`${t.id}-item-${o+1}`,type:"i",markdown:d,content:d,ial:{...t.ial||{}}})}return l}}return Ki(t)?[t]:[]}function Er(t){var s;if(!t||!de(t)||!Mi(t)||pi(t))return null;const i=Qs(t);if(i.length===0)return null;if(i.length===1&&de(i[0])&&Mi(i[0])){const n=Er(i[0]);return n?{items:n.items,nestedSuperBlocks:[i[0],...n.nestedSuperBlocks]}:null}const e=[];for(const n of i)if(de(n)){e.push(n);const r=((s=n.children)==null?void 0:s.filter(de))||[];e.push(...r)}if(i.length===3){const n=_i(i[0]),r=_i(i[1]),l=_i(i[2]);if(n.length===1&&r.length===1&&l.length===1)return{items:[n[0],r[0],l[0]],nestedSuperBlocks:e}}if(i.length===2){const n=_i(i[0]),r=_i(i[1]);if(n.length===2&&r.length===1)return{items:[n[0],n[1],r[0]],nestedSuperBlocks:e};if(n.length===1&&r.length===2)return{items:[n[0],r[0],r[1]],nestedSuperBlocks:e};if(n.length===1&&r.length===1)return{items:[n[0],r[0]],nestedSuperBlocks:e}}return null}function Oa(t){if(!t||!de(t)||!Mi(t)||pi(t))return null;const i=Er(t);if(!i)return null;const{items:e,nestedSuperBlocks:s}=i;return e.length!==2&&e.length!==3?null:e.length===2?{superBlockNode:t,nestedSuperBlocks:s,count:2,layout:"two-cols-header",items:e,slots:["left","right"]}:{superBlockNode:t,nestedSuperBlocks:s,count:3,layout:"three-cols-header",items:e,slots:["col-1","col-2","col-3"]}}function Pa(t){if(!t||!de(t)||!Mi(t)||pi(t))return null;const i=Qs(t);if(i.length===0)return null;const e=[];for(const s of i){const n=_i(s);if(n.length===0)return null;e.push(...n)}return e}function Ra(t){if(!t||!de(t)||!Mi(t)||pi(t))return null;const i=Pa(t);return!i||i.length===0||i.length===2||i.length===3?null:{superBlockNode:t,items:i}}function za(t,i,e){var d,h,g,u,y;const s=[],n=[],r=(e==null?void 0:e.tracked)||[],l=[];let o={pageTargetId:t,blocks:[]};l.push(o);for(let p=0;p<i.length;p++){const b=i[p];if(qn(b)){if(l.length===1&&o.blocks.length===0){o.pageTargetId=b.id,o.blocks.push(b);continue}o={pageTargetId:b.id,blocks:[b]},l.push(o)}else o.blocks.push(b)}function a(p){const b=[];for(const v of p)de(v)&&b.push(v),v.children&&v.children.length>0&&b.push(...a(v.children));return b}function c(p,b,v){const k={blockId:p,attrs:b,previousAttrs:v};s.push(k),e!=null&&e.onTagChange&&e.onTagChange(k)}for(const p of l){const b=p.pageTargetId,v=i.find(_=>_.id===b),k=r.find(_=>_.pageTargetId===b);if(p.blocks.some(_=>{var C,B;return!!(pi(_)||Rs(_)&&(((C=_.ial)==null?void 0:C[ft])==="image-left"||((B=_.ial)==null?void 0:B[ft])==="image-right"))})){if(k){const _=k.headerId;if(_){c(_,{[Tt]:""});const C=i.find(B=>B.id===_);C!=null&&C.ial&&(C.ial[Tt]="")}for(const C of k.itemIds){c(C,{[Tt]:""});const B=i.find(M=>M.id===C);B!=null&&B.ial&&(B.ial[Tt]="")}}continue}let A=null,x=-1;for(let _=0;_<p.blocks.length;_++){const C=p.blocks[_],B=de(C)?[C,...a(C.children||[])]:C.children?a(C.children):[];for(const M of B){const R=Oa(M);if(R){A=R,x=_;break}}if(A)break}if(A){const{superBlockNode:_,layout:C,items:B,slots:M}=A,J=p.blocks.slice(0,x).find(j=>La(j)),T=J==null?void 0:J.id,L=((d=v==null?void 0:v.ial)==null?void 0:d[ft])||"";if(L!==C&&(c(b,{[ft]:C},{[ft]:L}),v&&(v.ial||(v.ial={}),v.ial[ft]=C)),J){const j=((h=J.ial)==null?void 0:h[Tt])||"";j!=="header"&&(c(J.id,{[Tt]:"header"},{[Tt]:j}),J.ial||(J.ial={}),J.ial[Tt]="header")}if(k!=null&&k.headerId&&k.headerId!==T){c(k.headerId,{[Tt]:""});const j=i.find(Q=>Q.id===k.headerId);j&&(j.ial||(j.ial={}),j.ial[Tt]="")}const w=[];for(let j=0;j<B.length;j++){const Q=B[j],z=M[j];w.push(Q.id);const at=((g=Q.ial)==null?void 0:g[Tt])||"";if(at!==z&&(c(Q.id,{[Tt]:z},{[Tt]:at}),Q.ial||(Q.ial={}),Q.ial[Tt]=z),Q.children&&Q.children.length>0)for(const W of Q.children)W.ial||(W.ial={}),W.ial[Tt]!==z&&(W.ial[Tt]=z)}if(k!=null&&k.itemIds){for(const j of k.itemIds)if(!w.includes(j)){c(j,{[Tt]:""});const Q=i.find(z=>z.id===j);Q&&(Q.ial||(Q.ial={}),Q.ial[Tt]="")}}n.push({superBlockId:_.id,nestedSuperBlockIds:(u=A.nestedSuperBlocks)==null?void 0:u.map(j=>j.id),pageTargetId:b,headerId:T,itemIds:w,layout:C})}else{let _=!1;const C=[];for(const R of p.blocks){const J=de(R)?[R,...a(R.children||[])]:R.children?a(R.children):[];for(const T of J){const L=Ra(T);if(L){_=!0;for(const w of L.items)C.push(w.id)}}}const B=((y=v==null?void 0:v.ial)==null?void 0:y[ft])||"";if(k||_&&(B==="two-cols-header"||B==="three-cols-header")){c(b,{[ft]:""},{[ft]:B}),v&&(v.ial||(v.ial={}),v.ial[ft]="");const R=k==null?void 0:k.headerId;if(R){c(R,{[Tt]:""});const T=i.find(L=>L.id===R);T&&(T.ial||(T.ial={}),T.ial[Tt]="")}const J=new Set([...(k==null?void 0:k.itemIds)||[],...C]);for(const T of J){c(T,{[Tt]:""});const L=i.find(w=>w.id===T);L&&(L.ial||(L.ial={}),L.ial[Tt]="")}}}}return{changes:s,newTracked:n}}function bi(t,i,e){let s="",n=0;const r=/<div\b([^>]*)>/gi;for(;n<t.length;){r.lastIndex=n;let l,o=!1,a=-1,c=0;for(;(l=r.exec(t))!==null;){const v=l[1].match(/\bclass=["']([^"']*)["']/i);if(v){const k=v[1];if(typeof i=="string"?k.split(/\s+/).includes(i):i.test(k)){o=!0,a=l.index,c=l[0].length;break}}}if(!o){s+=t.slice(n);break}s+=t.slice(n,a);const d=a+c;let h=1,g=-1,u=-1;const y=/<\/?div\b[^>]*>/gi;y.lastIndex=d;let p;for(;(p=y.exec(t))!==null;)if(p[0].startsWith("</")){if(h--,h===0){g=p.index,u=p.index+p[0].length;break}}else h++;if(g!==-1&&u!==-1){const b=t.slice(d,g);s+=e(b),n=u}else s+=t.slice(a,d),n=d}return s}function Na(t){const i=[];let e="",s=0;const n=/<div\b([^>]*)>/gi;for(;s<t.length;){n.lastIndex=s;let r,l=!1,o=-1,a=0;for(;(r=n.exec(t))!==null;){const p=r[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(p)){l=!0,o=r.index,a=r[0].length;break}}if(!l){e+=t.slice(s);break}e+=t.slice(s,o);const c=o+a;let d=1,h=-1,g=-1;const u=/<\/?div\b[^>]*>/gi;u.lastIndex=c;let y;for(;(y=u.exec(t))!==null;)if(y[0].startsWith("</")){if(d--,d===0){h=y.index,g=y.index+y[0].length;break}}else d++;if(h!==-1&&g!==-1){const p=t.slice(o,g),b=`__VUE_DIV_TOKEN_${i.length}__`;i.push(p),e+=b,s=g}else e+=t.slice(o,c),s=c}return{text:e,tokens:i}}function Fa(t){const i=[];let e=t.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,o=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(o),a});e=e.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,o=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(o),a});const s=[];e=e.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,o=>{const a=`__SCRIPT_TOKEN_${s.length}__`;return s.push(o),a});const{text:n,tokens:r}=Na(e);e=n;const l=[];e=e.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),e=e.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),e=e.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),e=e.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),e=e.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),e=e.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),e=e.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),e=e.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(o,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),e=e.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(o,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),e=e.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(o,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),e=e.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(o,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=bi(e,"diff-grid",o=>{const a=Array.from(o.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),h=c[3].trim();return`**${d}:**
\`\`\`yaml
${h}
\`\`\``}).join(`

`)+`
`:o}),e=bi(e,"before-after",o=>{const a=o.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=o.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:o}),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(o,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),e=bi(e,"timeline",o=>{const a=Array.from(o.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let h="-";return d.includes("warn")?h="- ⚠️":d.includes("bad")?h="- ❌":d.includes("ok")&&(h="- ✅"),`${h} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:o}),e=bi(e,"pipeline",o=>{const a=Array.from(o.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const g=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${g}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:o}),e=bi(e,"check-grid",o=>{const a=Array.from(o.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:o}),e=bi(e,"manifesto",o=>{const a=Array.from(o.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:o}),e=bi(e,"split-note",o=>{const a=Array.from(o.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:o}),e=e.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(o,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),e=e.replace(/<pre>([\s\S]*?)<\/pre>/gi,(o,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=e.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),e=e.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),e=e.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),e=e.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),e=e.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),e=e.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),e=e.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),e=e.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),e=e.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(o,a,c)=>/@|v-|:|class=/i.test(a)?o:`
${c.trim()}

`),e=e.replace(/<br\s*\/?>/gi,`
`),e=e.replace(/<hr\s*\/?>/gi,`
---
`),e=e.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),e=e.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),e=e.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),e=e.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(o,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((h,g)=>Math.max(h,g.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),e=e.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),e=e.replace(/\*{4}/g,"** **"),e=e.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),e=e.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),e=e.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(o,a,c,d,h)=>{const g=h.trim();return g.includes("<")||g.includes(`
`)?o:`[${g}](${c})`}),e=e.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(o,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),e=e.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(o,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),e=e.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(o,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),e=e.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),e=e.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),e=e.replace(/<\/?span\b[^>]*>/gi,"");for(let o=0;o<l.length;o++)e=e.replace(`__VUE_COMP_TOKEN_${o}__`,l[o]);for(let o=0;o<r.length;o++)e=e.replace(`__VUE_DIV_TOKEN_${o}__`,r[o]);for(let o=0;o<s.length;o++)e=e.replace(`__SCRIPT_TOKEN_${o}__`,s[o]);for(let o=0;o<i.length;o++)e=e.replace(`__CODE_TOKEN_${o}__`,i[o]);return e=e.replace(/\n{3,}/g,`

`).trim(),e}function Mr(t){if(!t||typeof t!="string")return"";const i=[];let e=t.replace(/`([^`]+)`/g,s=>(i.push(s),`%%INLINE_CODE_${i.length-1}%%`));return e=e.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),e=e.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),e=e.replace(/\{:[^}]*\}/g,""),e=e.replace(/%%INLINE_CODE_(\d+)%%/g,(s,n)=>i[parseInt(n,10)]||""),e}function ja(t){const i=Object.entries(t).filter(([s,n])=>n!=null&&n!=="");return i.length===0?"":`---
${i.map(([s,n])=>typeof n=="string"?n.includes(":")||n.includes(`
`)||n.includes("#")?`${s}: "${n.replace(/"/g,'\\"')}"`:`${s}: ${n}`:`${s}: ${JSON.stringify(n)}`).join(`
`)}
---`}function Ha(t,i){if(!i||!t.startsWith("```"))return t;const e=t.indexOf(`
`);if(e===-1)return t;const s=t.slice(0,e).trim(),n=t.slice(e);return s.includes("{")?t:`${s} {${i}}${n}`}function Ua(t,i){if(i==null)return t;const e=i.trim();return e===""||e==="+1"?`<v-click>

${t}

</v-click>`:e==="hide"?`<v-click hide>

${t}

</v-click>`:`<v-click at="${e}">

${t}

</v-click>`}function Wa(t){if(!t||!t.preset)return null;const i=t.preset.toLowerCase().trim();if(!i||i==="none")return null;let e={opacity:0},s={opacity:1};switch(i){case"slide-up":e={y:40,opacity:0},s={y:0,opacity:1};break;case"slide-down":e={y:-40,opacity:0},s={y:0,opacity:1};break;case"slide-left":e={x:40,opacity:0},s={x:0,opacity:1};break;case"slide-right":e={x:-40,opacity:0},s={x:0,opacity:1};break;case"zoom-in":case"pop":e={scale:.8,opacity:0},s={scale:1,opacity:1};break;case"bounce":e={y:40,opacity:0},s={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:e={opacity:0},s={opacity:1};break}t.initial&&typeof t.initial=="object"&&(e={...e,...t.initial}),t.enter&&typeof t.enter=="object"&&(s={...s,...t.enter});const n={...s.transition||{}};return typeof t.duration=="number"&&t.duration>0&&(n.duration=t.duration),typeof t.delay=="number"&&t.delay>0&&(n.delay=t.delay),Object.keys(n).length>0&&(s.transition=n),{initial:e,enter:s}}function Ro(t,i,e,s){const n=i!=null&&i.trim()!=="",r=Wa(e),l=s==null?void 0:s.trim(),o=l!==void 0&&l!=="",a=o?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!n&&!r)return o?`<div${a}>

${t}

</div>`:t;if(n&&!r){if(o){const y=i.trim();let p="v-click";return y==="hide"?p="v-click.hide":y!==""&&y!=="+1"&&(p=`v-click="${y}"`),`<div ${p}${a}>

${t}

</div>`}return Ua(t,i)}const c=JSON.stringify(r.initial).replace(/"/g,"'"),d=JSON.stringify(r.enter).replace(/"/g,"'"),h=`v-motion :initial="${c}" :enter="${d}"`;if(!n)return`<div ${h}${a}>

${t}

</div>`;const g=i.trim();let u="v-click";return g==="hide"?u="v-click.hide":g!==""&&g!=="+1"&&(u=`v-click="${g}"`),`<div ${u} ${h}${a}>

${t}

</div>`}function Br(t){if(!t)return"";let i=t.trim();i=i.replace(/\{:[^}]*\}/g,"").trim(),i=i.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),i=i.replace(/\r?\n?:::\s*$/g,"");let n=i.split(/\r?\n/).map(r=>r.trim().replace(/^>\s*/,"")).join(`
`).trim();return n=n.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),n=n.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),n=n.replace(/^[-*+]\s+/,""),n=n.replace(/^\d+\.\s+/,""),n.trim()}function Va(t){var s;if(t.subType&&/^h([1-6])$/i.test(t.subType))return parseInt(t.subType.slice(1),10);const e=(t.markdown||t.content||"").trim().match(/^(#{1,6})\s+/);return e?e[1].length:t.type==="h"?(s=t.ial)!=null&&s.subType&&/^h([1-6])$/i.test(t.ial.subType)?parseInt(t.ial.subType.slice(1),10):1:null}function Dr(t){if(!t||t.length===0)return{col1:[],col2:[],col3:[]};if(t.length===1&&t[0].children&&t[0].children.length>=2){const l=t[0].children;if(l.length>=3){const o=Math.ceil(l.length/3),a=Math.ceil((l.length-o)/2);return{col1:l.slice(0,o),col2:l.slice(o,o+a),col3:l.slice(o+a)}}else return{col1:[l[0]],col2:[l[1]],col3:[]}}const i=l=>{const o=l.slot||"";return o==="col-1"||o==="left"?1:o==="col-2"||o==="center"?2:o==="col-3"||o==="right"?3:null},e=t.map(i);if(e.some(l=>l!==null)){const l=e.includes(2),o=e.includes(3);if(l||o){const d=[],h=[],g=[];let u=1;for(const y of t){const p=i(y);p!==null&&(u=p),u===1?d.push(y):u===2?h.push(y):g.push(y)}return{col1:d,col2:h,col3:g}}const a=t.filter(d=>i(d)===1),c=t.filter(d=>i(d)===null);if(c.length>=2){const d=Math.ceil(c.length/2);return{col1:a,col2:c.slice(0,d),col3:c.slice(d)}}else return c.length===1?{col1:a,col2:c,col3:[]}:{col1:a,col2:[],col3:[]}}const n=l=>{if(l.type==="h"||l.subType&&/^h[1-6]$/i.test(l.subType))return!0;const o=(l.rawMarkdown||l.content||"").trim();return/^#{1,6}\s+/.test(o)},r=t.map((l,o)=>n(l)?o:-1).filter(l=>l!==-1);if(r.length>=3)return{col1:t.slice(0,r[1]),col2:t.slice(r[1],r[2]),col3:t.slice(r[2])};if(t.length>=3){const l=Math.ceil(t.length/3),o=Math.ceil((t.length-l)/2);return{col1:t.slice(0,l),col2:t.slice(l,l+o),col3:t.slice(l+o)}}if(t.length===2)return{col1:[t[0]],col2:[t[1]],col3:[]};if(t.length===1){const l=t[0],o=(l.rawMarkdown||l.content||"").trim(),a=o.split(/\r?\n/),c=[];for(let g=0;g<a.length;g++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(a[g])&&c.push(g);if(c.length>=3){const g=Math.ceil(c.length/3),u=Math.ceil((c.length-g)/2),y=a.slice(c[0],c[g]).join(`
`),p=a.slice(c[g],c[g+u]).join(`
`),b=a.slice(c[g+u]).join(`
`);return{col1:[{...l,rawMarkdown:y,content:y}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:p,content:p}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:b,content:b}]}}const d=o.match(/<li[\s\S]*?<\/li>/gi);if(d&&d.length>=3){const g=Math.ceil(d.length/3),u=Math.ceil((d.length-g)/2),y=`<ul>
${d.slice(0,g).join(`
`)}
</ul>`,p=`<ul>
${d.slice(g,g+u).join(`
`)}
</ul>`,b=`<ul>
${d.slice(g+u).join(`
`)}
</ul>`;return{col1:[{...l,rawMarkdown:y,content:y}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:p,content:p}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:b,content:b}]}}const h=o.split(/\r?\n\s*\r?\n/).filter(g=>g.trim()!=="");if(h.length>=3){const g=Math.ceil(h.length/3),u=Math.ceil((h.length-g)/2);return{col1:[{...l,rawMarkdown:h.slice(0,g).join(`

`),content:h.slice(0,g).join(`

`)}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:h.slice(g,g+u).join(`

`),content:h.slice(g,g+u).join(`

`)}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:h.slice(g+u).join(`

`),content:h.slice(g+u).join(`

`)}]}}}return{col1:t,col2:[],col3:[]}}function zo(t,i,e,s){var d;const n=xa(i),r=[],l=Oo(i);let o={pageIndex:1,startBlockId:t,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[t]};o.frontmatter.background&&(o.frontmatter.background=_e(o.frontmatter.background,s)),o.frontmatter.image&&(o.frontmatter.image=_e(o.frontmatter.image,s)),r.push(o);let a=[];for(const h of e){if(qn(h)){a=[];const u=Oo(h.ial);if(r.length===1&&o.blocks.length===0){o.startBlockId=h.id,o.allBlockIds||(o.allBlockIds=[]),o.allBlockIds.includes(h.id)||o.allBlockIds.push(h.id),u.frontmatter.layout&&(o.frontmatter.layout=u.frontmatter.layout),Object.assign(o.frontmatter,u.frontmatter),!u.frontmatter.image&&l.frontmatter.image&&(o.frontmatter.image=l.frontmatter.image),!u.frontmatter.background&&l.frontmatter.background&&(o.frontmatter.background=l.frontmatter.background),o.frontmatter.background&&(o.frontmatter.background=_e(o.frontmatter.background,s)),o.frontmatter.image&&(o.frontmatter.image=_e(o.frontmatter.image,s));continue}o={pageIndex:r.length+1,startBlockId:h.id,frontmatter:{layout:u.frontmatter.layout||"default",...u.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[h.id]},o.frontmatter.background&&(o.frontmatter.background=_e(o.frontmatter.background,s)),o.frontmatter.image&&(o.frontmatter.image=_e(o.frontmatter.image,s)),r.push(o);continue}const g=u=>{if(o.allBlockIds||(o.allBlockIds=[]),u.id&&!o.allBlockIds.includes(u.id)&&o.allBlockIds.push(u.id),u.children&&u.children.length>0){const L=w=>{for(const j of w)j.id&&!o.allBlockIds.includes(j.id)&&o.allBlockIds.push(j.id),j.children&&j.children.length>0&&L(j.children)};L(u.children)}let y=Aa(u),p=u.ial?{...u.ial}:{};const b=y.match(/\{:\s*([^}]+)\s*\}\s*$/);b&&(p={...Ta(b[0]),...p},y=y.slice(0,b.index).trim()),u.type!=="c"&&!y.startsWith("```")&&(y=Mr(y));let v=y.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(v)||v==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(v)&&/\r?\n\}\}\}$/.test(v)&&(y=v.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),v=y.trim());const k=_a(p);if(y=Ba(y,s),y=Ia(y,s==null?void 0:s.refContentMap),u.children&&u.children.length>0){const L=w=>{for(const j of w){if(j.ial)for(const[Q,z]of Object.entries(j.ial))Q.startsWith("custom-slidev-")&&!p[Q]&&(p[Q]=z);j.children&&j.children.length>0&&L(j.children)}};L(u.children)}const S=u.type==="video"||u.type==="NodeVideo"||/<video\b/i.test(y);if(S){const L=p["custom-slidev-autoplay"]==="true",w=p["custom-slidev-loop"]==="true",j=p["custom-slidev-muted"]==="true"||L,Q=p["custom-slidev-controls"]==="false";y=y.replace(/<video\b([^>]*)>/gi,(z,at)=>{let W=at;return Q?W=W.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(W)||(W+=" controls"),L&&!/autoplay/i.test(W)?W+=" autoplay playsinline":!L&&p["custom-slidev-autoplay"]==="false"&&(W=W.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),w&&!/loop/i.test(W)?W+=" loop":!w&&p["custom-slidev-loop"]==="false"&&(W=W.replace(/\bloop\b/gi,"").trim()),j&&!/muted/i.test(W)?W+=" muted":!j&&p["custom-slidev-muted"]==="false"&&(W=W.replace(/\bmuted\b/gi,"").trim()),`<video ${W.trim()}>`})}if(k.isBackground){const L=fi(y,u.content);if(L){o.frontmatter.background=_e(L,s);return}}const A=pi(u);if(A){o.frontmatter.layout=A.layout,o.frontmatter.image=_e(A.imageUrl,s);for(const L of A.contentNodes)g(L);return}if(k.imageLayout==="image-left"||k.imageLayout==="image-right"){const L=fi(y,u.content);if(L){o.frontmatter.layout=k.imageLayout,o.frontmatter.image=_e(L,s);return}}if(de(u)&&u.children&&u.children.length>0){for(const L of u.children)g(L);return}if((u.type==="l"||u.type==="NodeList"||u.type==="list")&&u.children&&u.children.length>0&&(u.children.some(L=>{var w;return(w=L.ial)==null?void 0:w[Tt]})||k.slot)){for(const L of u.children)k.slot&&(!L.ial||!L.ial[Tt])&&(L.ial||(L.ial={}),L.ial[Tt]=k.slot),g(L);return}if(k.isNote){const L=Br(y);L&&(o.notes?o.notes+=`

`+L:o.notes=L),o.noteBlocks||(o.noteBlocks=[]),o.noteBlocks.push({id:u.id,type:u.type,content:L||u.content||"",rawMarkdown:y,isNote:!0,attributes:u.ial});return}k.shikiLines&&(y=Ha(y,k.shikiLines)),v=y.trim();const x=(u.content||"").trim();if(v==="::right::"||x==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(v)||v.startsWith("::right::")){o.blocks.push({id:u.id,type:u.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:u.ial});return}const C=Va(u);let B=k.slot,M=k.clicks,R=k.motion,J={...u.ial||{}};if(C!==null){for(;a.length>0&&a[a.length-1].level>=C;)a.pop();const L=a.length>0?a[a.length-1]:void 0;!B&&(L!=null&&L.slot)&&(B=L.slot),!M&&(L!=null&&L.clicks)&&(M=L.clicks),!R&&(L!=null&&L.motion)&&(R=L.motion);const w={...(L==null?void 0:L.customAttrs)||{}};if(u.ial)for(const[j,Q]of Object.entries(u.ial))j.startsWith("custom-slidev-")&&!j.startsWith("custom-slidev-slide")&&(w[j]=Q);a.push({level:C,slot:B,clicks:M,motion:R,customAttrs:w})}else{const L=a.length>0?a[a.length-1]:void 0;L&&(!B&&L.slot&&L.slot!=="header"&&(B=L.slot),!M&&L.clicks&&(M=L.clicks),!R&&L.motion&&(R=L.motion),L.customAttrs&&(J={...L.customAttrs,...J}))}!B&&o.blocks.some(L=>L.slot==="slot-divider-right")&&(B="right"),B&&(J[Tt]=B),M&&!J[Se]&&(J[Se]=M),R&&!J[He]&&(J[He]=JSON.stringify(R)),(S||p["custom-slidev-autoplay"]||p["custom-slidev-muted"])&&(p["custom-slidev-autoplay"]&&(J["custom-slidev-autoplay"]=p["custom-slidev-autoplay"],p["custom-slidev-autoplay"]==="true"&&!p["custom-slidev-muted"]&&(J["custom-slidev-muted"]="true")),p["custom-slidev-loop"]&&(J["custom-slidev-loop"]=p["custom-slidev-loop"]),p["custom-slidev-muted"]&&(J["custom-slidev-muted"]=p["custom-slidev-muted"]),p["custom-slidev-controls"]&&(J["custom-slidev-controls"]=p["custom-slidev-controls"]));const T={id:u.id,type:u.type,content:u.content||"",rawMarkdown:y,clicks:M,motion:R,shikiLines:k.shikiLines,slot:B,attributes:J};o.blocks.push(T)};g(h)}for(let h=0;h<r.length;h++){const g=r[h],u=[],y={...g.frontmatter};h===0&&(y.theme=n.theme,y.aspectRatio=n.aspectRatio,y.highlighter=n.highlighter,y.transition=g.frontmatter.transition||n.defaultTransition);const p=ja(y);p&&u.push(p);const b=g.blocks.filter(x=>x.slot!=="slot-divider-right"),v=x=>x.filter(_=>!!(_.rawMarkdown||_.content||"").trim()).map(_=>{var C;return Ro(_.rawMarkdown,_.clicks,_.motion,(C=_.attributes)==null?void 0:C.style)}).join(`

`),k=x=>{const _=x.filter(R=>!!(R.rawMarkdown||R.content||"").trim());if(_.length===0)return;const C=_[0],B=(C.rawMarkdown||C.content||"").trim();(Ki(C)||/^(?:[-*+]|\d+\.)\s+/.test(B))&&(C.rawMarkdown=zs(C.rawMarkdown||C.content||""),C.content=C.rawMarkdown)},S=x=>x.length===0?"":(k(x),v(x)),A=g.frontmatter.layout||"default";if(A==="two-cols-header"){let x=[];const _=b.filter(L=>L.slot==="header");if(_.length>0)x=_;else if(b.length>0){const L=b.find(w=>w.type==="h"&&(!w.slot||w.slot==="default"));L&&(x=[L])}const C=b.filter(L=>!x.includes(L)),B=C.filter(L=>L.slot==="right"||L.slot==="col-2"),M=C.filter(L=>!B.includes(L));k(M),k(B);const R=v(x),J=S(M),T=S(B);R&&u.push(R),J&&u.push(`::left::

${J}`),T&&u.push(`::right::

${T}`)}else if(A==="three-cols-header"){let x=[];const _=b.filter(Q=>Q.slot==="header");if(_.length>0)x=_;else if(b.length>0){const Q=b.find(z=>z.type==="h"&&(!z.slot||z.slot==="default"));Q&&(x=[Q])}const C=b.filter(Q=>!x.includes(Q)),B=Dr(C),M=B.col1,R=B.col2,J=B.col3;for(const Q of M)Q.slot||(Q.slot="col-1");for(const Q of R)Q.slot||(Q.slot="col-2");for(const Q of J)Q.slot||(Q.slot="col-3");if(k(M),k(R),k(J),C.length===1&&(R.length>0||J.length>0)){const Q=g.blocks.findIndex(z=>z.id===C[0].id);Q!==-1&&g.blocks.splice(Q,1,...M,...R,...J)}const T=v(x),L=S(M),w=S(R),j=S(J);T&&u.push(T),L&&u.push(`::col-1::

${L}`),w&&u.push(`::col-2::

${w}`),j&&u.push(`::col-3::

${j}`)}else if(A==="two-cols"){const x=b.filter(M=>M.slot==="left"),_=b.filter(M=>M.slot==="right");k(x),k(_);const C=v(x.length>0?x:b.filter(M=>M.slot!=="right")),B=v(_);u.push(C),B&&u.push(`::right::

${B}`)}else for(const x of b)u.push(Ro(x.rawMarkdown,x.clicks,x.motion,(d=x.attributes)==null?void 0:d.style));g.notes&&u.push(`<!--
${g.notes}
-->`),g.rawMarkdown=u.join(`

`).trim()}const c=r.map(h=>h.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:t,config:n,slides:r,fullMarkdown:c}}const Ns=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function Ka(t){var n,r,l,o,a,c,d,h,g,u,y,p;if(!t||typeof t!="object")return"";const i=[],e=[];if(Array.isArray(t.styles))for(const b of t.styles){if(!b||!b.id)continue;const v=`--b3-inline-style-${b.id}`;(n=b.light)!=null&&n.color&&i.push(`  ${v}-color: ${b.light.color};`),(r=b.light)!=null&&r.backgroundColor&&i.push(`  ${v}-background-color: ${b.light.backgroundColor};`),(l=b.dark)!=null&&l.color&&e.push(`  ${v}-color: ${b.dark.color};`),(o=b.dark)!=null&&o.backgroundColor&&e.push(`  ${v}-background-color: ${b.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.colors))for(const b of t.builtin.colors){if(!b||typeof b.index!="number")continue;const v=b.index;(a=b.light)!=null&&a.color&&i.push(`  --b3-font-color${v}: ${b.light.color};`),(c=b.light)!=null&&c.backgroundColor&&i.push(`  --b3-font-background${v}: ${b.light.backgroundColor};`),(d=b.dark)!=null&&d.color&&e.push(`  --b3-font-color${v}: ${b.dark.color};`),(h=b.dark)!=null&&h.backgroundColor&&e.push(`  --b3-font-background${v}: ${b.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.styles))for(const b of t.builtin.styles){if(!b||!b.id)continue;const v=b.id;(g=b.light)!=null&&g.color&&i.push(`  --b3-card-${v}-color: ${b.light.color};`),(u=b.light)!=null&&u.backgroundColor&&i.push(`  --b3-card-${v}-background: ${b.light.backgroundColor};`),(y=b.dark)!=null&&y.color&&e.push(`  --b3-card-${v}-color: ${b.dark.color};`),(p=b.dark)!=null&&p.backgroundColor&&e.push(`  --b3-card-${v}-background: ${b.dark.backgroundColor};`)}if(i.length===0&&e.length===0)return"";const s=[];return i.length>0&&s.push(`:root, html:not(.dark), [data-theme="light"] {
${i.join(`
`)}
}`),e.length>0&&s.push(`html.dark, [data-theme="dark"], .dark {
${e.join(`
`)}
}`),s.join(`

`)}function dn(t){const i=Ka(t);return i?`${Ns}

/* Custom Workspace Inline Styles */
${i}`:Ns}function ys(t){const i={};if(!t||typeof t!="string")return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),s=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let n;for(;(n=s.exec(e))!==null;){const r=n[1],l=n[2]??n[3]??n[4]??"";i[r]=l}return i}const qa={getBlockAttrs:Ge,getChildBlocks:Kn,setBlockAttrs:zt,sql:gn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:wa};class Ga{constructor(i){wt(this,"deps");wt(this,"attrOverrides",new Map);wt(this,"trackedListSuperBlocks",new Map);this.deps={...qa,...i||{}}}setBlockAttrOverride(i,e){if(!i||!e)return;const n={...this.attrOverrides.get(i)||{}};for(const[r,l]of Object.entries(e))l===""||l===null||l===void 0?delete n[r]:n[r]=String(l);Object.keys(n).length===0?this.attrOverrides.delete(i):this.attrOverrides.set(i,n)}getBlockAttrOverride(i){return this.attrOverrides.get(i)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(i){return this.trackedListSuperBlocks.get(i)||[]}clearBlockAttrOverride(i,e){if(!i)return;if(!e){this.attrOverrides.delete(i);return}const s=this.attrOverrides.get(i);s&&(delete s[e],Object.keys(s).length===0&&this.attrOverrides.delete(i))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(i){try{const e=await this.deps.getBlockAttrs(i).catch(()=>({}))||{},s=this.attrOverrides.get(i);s&&Object.assign(e,s);let n=await this.deps.getChildBlocks(i).catch(()=>[]);const r=`SELECT id, ial FROM blocks WHERE root_id = '${i}' LIMIT 99999`,l=await this.deps.sql(r).catch(()=>[])||[],o=new Map;if(Array.isArray(l))for(const S of l)S.id&&S.ial&&o.set(S.id,ys(S.ial));const a=`SELECT block_id, name, value FROM attributes WHERE root_id = '${i}' AND type = 'b' LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[];if(Array.isArray(c)){for(const S of c)if(S.block_id&&S.name){let A=o.get(S.block_id);A||(A={},o.set(S.block_id,A)),A[S.name]=S.value||""}}if(!n||n.length===0){const S=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE root_id = '${i}' AND id != '${i}' ORDER BY created ASC LIMIT 99999`;n=await this.deps.sql(S).catch(()=>[])||[]}const d=(n||[]).map(S=>{const A=o.get(S.id)||(S.ial?ys(S.ial):{}),x=this.attrOverrides.get(S.id);return x&&Object.assign(A,x),{id:S.id,parent_id:S.parent_id,root_id:S.root_id||i,type:S.type,subType:S.subType,content:S.content||"",markdown:S.markdown||"",ial:A,children:S.children}}),h=async(S,A=0)=>{if(!(!S||S.length===0||A>8))for(const x of S){if((de(x)||x.type==="l"||x.type==="NodeList"||x.type==="i"||x.type==="NodeListItem"||x.type==="b"||x.type==="NodeBlockquote")&&(!x.children||x.children.length===0)){let C=await this.deps.getChildBlocks(x.id).catch(()=>[]);if(!C||C.length===0){const B=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE parent_id = '${x.id}' ORDER BY sort ASC, created ASC`;C=await this.deps.sql(B).catch(()=>[])||[]}Array.isArray(C)&&C.length>0&&(x.children=C.map(B=>{const M=o.get(B.id)||(B.ial?ys(B.ial):{}),R=this.attrOverrides.get(B.id);return R&&Object.assign(M,R),{id:B.id,parent_id:B.parent_id||x.id,root_id:B.root_id||i,type:B.type,subType:B.subType,content:B.content||"",markdown:B.markdown||"",ial:M}}))}x.children&&x.children.length>0&&await h(x.children,A+1)}};await h(d);const g=S=>{var A,x;for(const _ of S)if(_.children&&_.children.length>0){g(_.children);for(const C of _.children)if(C.ial)for(const[B,M]of Object.entries(C.ial))B.startsWith("custom-slidev-")&&!((A=_.ial)!=null&&A[B])&&(_.ial||(_.ial={}),_.ial[B]=M);if(_.ial){for(const[C,B]of Object.entries(_.ial))if(C.startsWith("custom-slidev-"))for(const M of _.children)(M.type==="video"||M.type==="NodeVideo"||/<video\b/i.test(M.markdown||M.content||""))&&!((x=M.ial)!=null&&x[C])&&(M.ial||(M.ial={}),M.ial[C]=B)}}};g(d),Da(d,S=>{this.setBlockAttrOverride(S.blockId,{[ft]:S.layout}),(this.deps.setBlockAttrs||zt)(S.blockId,{[ft]:S.layout}).catch(x=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",x)})});const u=this.trackedListSuperBlocks.get(i)||[],y=za(i,d,{tracked:u,onTagChange:S=>{this.setBlockAttrOverride(S.blockId,S.attrs),S.blockId===i&&Object.assign(e,S.attrs);const A=_=>{for(const C of _)C.id===S.blockId&&(C.ial||(C.ial={}),Object.assign(C.ial,S.attrs)),C.children&&C.children.length>0&&A(C.children)};A(d),(this.deps.setBlockAttrs||zt)(S.blockId,S.attrs).catch(_=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",_)})}});this.trackedListSuperBlocks.set(i,y.newTracked);const p=new Set;for(const S of d){const A=S.markdown||S.content||"";if(A.includes("((")){const x=$a(A);for(const _ of x)p.add(_.blockId)}}const b={};if(p.size>0){const S=Array.from(p).map(x=>`'${x}'`).join(","),A=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${S})`).catch(()=>[])||[];if(Array.isArray(A))for(const x of A)x.id&&(b[x.id]=x.markdown||x.content||"")}const v=this.deps.getBaseUrl?this.deps.getBaseUrl():"",k=zo(i,e,d,{baseUrl:v,refContentMap:b});try{const S=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;k.customThemeCss=dn(S)}catch{k.customThemeCss=dn(null)}return k}catch(e){console.error("[DocumentCompilerService] Failed to compile document:",e);const s=zo(i,{},[],{});return s.customThemeCss=dn(null),s}}}const Ht=new Ga;class to{constructor(i){wt(this,"devServerUrl","http://localhost:3030");wt(this,"isConnected",!1);wt(this,"lastSyncTime",null);i&&(this.devServerUrl=i)}getUrl(){return this.devServerUrl}setUrl(i){this.devServerUrl=i.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(i=1500){try{const e=new AbortController,s=setTimeout(()=>e.abort(),i),n=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:e.signal}).catch(()=>null);return clearTimeout(s),this.isConnected=!!n,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(i){const e=i.config,s=["---",`theme: ${e.theme||"default"}`,`aspectRatio: "${e.aspectRatio||"16/9"}"`,`highlighter: ${e.highlighter||"shiki"}`,`transition: ${e.defaultTransition||"slide-left"}`];e.colorSchema&&e.colorSchema!=="auto"&&s.push(`colorSchema: ${e.colorSchema}`),s.push("drawings:","  persist: false","---","");const n=s.join(`
`),r=i.slides.map((l,o)=>{const a=l.frontmatter||{},c=[],d=o===0;a.layout&&a.layout!=="default"&&c.push(`layout: ${a.layout}`),a.transition&&c.push(`transition: ${a.transition}`),a.background&&c.push(`background: ${a.background}`),a.class&&c.push(`class: "${a.class}"`);let h="";c.length>0?h=d?"":`---
${c.join(`
`)}
---

`:d||(h=`---

`);let g="";if(a.layout==="two-cols"){const y=l.blocks.filter(k=>k.slot!=="right"),p=l.blocks.filter(k=>k.slot==="right"),b=y.map(k=>k.rawMarkdown||k.content||"").join(`

`),v=p.map(k=>k.rawMarkdown||k.content||"").join(`

`);g=`${b}

::right::

${v}`}else g=l.blocks.map(y=>y.rawMarkdown||y.content||"").join(`

`);let u="";return l.notes&&l.notes.trim()&&(u=`

<!--
${l.notes.trim()}
-->`),`${h}${g}${u}`}).join(`

`);return`${n}${r}
`}async syncToWorkspaceFile(i,e="/data/storage/petal/siyuan-slidev/slides.md",s){const n=this.buildStandardSlidevMarkdown(i);if(this.lastSyncTime=Date.now(),s)try{const r=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8");return await s(e,!1,r),{success:!0,path:e}}catch(r){return{success:!1,path:e,error:String(r)}}return{success:!0,path:e}}downloadSlidesMd(i,e="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const s=this.buildStandardSlidevMarkdown(i),n=new Blob([s],{type:"text/markdown;charset=utf-8"}),r=URL.createObjectURL(n),l=document.createElement("a");return l.href=r,l.download=e,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(r),!0}}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function eo(t){const i=Object.create(null);for(const e of t.split(","))i[e]=1;return e=>e in i}const Wt={},Fi=[],Ve=()=>{},Lr=()=>!1,ns=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&(t.charCodeAt(2)>122||t.charCodeAt(2)<97),ss=t=>t.startsWith("onUpdate:"),le=Object.assign,io=(t,i)=>{const e=t.indexOf(i);e>-1&&t.splice(e,1)},Za=Object.prototype.hasOwnProperty,Rt=(t,i)=>Za.call(t,i),Ct=Array.isArray,ji=t=>Sn(t)==="[object Map]",Ji=t=>Sn(t)==="[object Set]",No=t=>Sn(t)==="[object Date]",It=t=>typeof t=="function",Qt=t=>typeof t=="string",Be=t=>typeof t=="symbol",jt=t=>t!==null&&typeof t=="object",Or=t=>(jt(t)||It(t))&&It(t.then)&&It(t.catch),Pr=Object.prototype.toString,Sn=t=>Pr.call(t),Ya=t=>Sn(t).slice(8,-1),Rr=t=>Sn(t)==="[object Object]",no=t=>Qt(t)&&t!=="NaN"&&t[0]!=="-"&&""+parseInt(t,10)===t,un=eo(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),os=t=>{const i=Object.create(null);return(e=>i[e]||(i[e]=t(e)))},Ja=/-\w/g,he=os(t=>t.replace(Ja,i=>i.slice(1).toUpperCase())),Xa=/\B([A-Z])/g,hi=os(t=>t.replace(Xa,"-$1").toLowerCase()),rs=os(t=>t.charAt(0).toUpperCase()+t.slice(1)),ks=os(t=>t?`on${rs(t)}`:""),Ue=(t,i)=>!Object.is(t,i),jn=(t,...i)=>{for(let e=0;e<t.length;e++)t[e](...i)},zr=(t,i,e,s=!1)=>{Object.defineProperty(t,i,{configurable:!0,enumerable:!1,writable:s,value:e})},ls=t=>{const i=parseFloat(t);return isNaN(i)?t:i};let Fo;const as=()=>Fo||(Fo=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function so(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++){const s=t[e],n=Qt(s)?ic(s):so(s);if(n)for(const r in n)i[r]=n[r]}return i}else if(Qt(t)||jt(t))return t}const Qa=/;(?![^(]*\))/g,tc=/:([^]+)/,ec=/\/\*[^]*?\*\//g;function ic(t){const i={};return t.replace(ec,"").split(Qa).forEach(e=>{if(e){const s=e.split(tc);s.length>1&&(i[s[0].trim()]=s[1].trim())}}),i}function Et(t){let i="";if(Qt(t))i=t;else if(Ct(t))for(let e=0;e<t.length;e++){const s=Et(t[e]);s&&(i+=s+" ")}else if(jt(t))for(const e in t)t[e]&&(i+=e+" ");return i.trim()}const nc="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",sc=eo(nc);function Nr(t){return!!t||t===""}function oc(t,i){if(t.length!==i.length)return!1;let e=!0;for(let s=0;e&&s<t.length;s++)e=Xi(t[s],i[s]);return e}function Xi(t,i){if(t===i)return!0;let e=No(t),s=No(i);if(e||s)return e&&s?t.getTime()===i.getTime():!1;if(e=Be(t),s=Be(i),e||s)return t===i;if(e=Ct(t),s=Ct(i),e||s)return e&&s?oc(t,i):!1;if(e=jt(t),s=jt(i),e||s){if(!e||!s)return!1;const n=Object.keys(t).length,r=Object.keys(i).length;if(n!==r)return!1;for(const l in t){const o=t.hasOwnProperty(l),a=i.hasOwnProperty(l);if(o&&!a||!o&&a||!Xi(t[l],i[l]))return!1}}return String(t)===String(i)}function oo(t,i){return t.findIndex(e=>Xi(e,i))}const Fr=t=>!!(t&&t.__v_isRef===!0),St=t=>Qt(t)?t:t==null?"":Ct(t)||jt(t)&&(t.toString===Pr||!It(t.toString))?Fr(t)?St(t.value):JSON.stringify(t,jr,2):String(t),jr=(t,i)=>Fr(i)?jr(t,i.value):ji(i)?{[`Map(${i.size})`]:[...i.entries()].reduce((e,[s,n],r)=>(e[ws(s,r)+" =>"]=n,e),{})}:Ji(i)?{[`Set(${i.size})`]:[...i.values()].map(e=>ws(e))}:Be(i)?ws(i):jt(i)&&!Ct(i)&&!Rr(i)?String(i):i,ws=(t,i="")=>{var e;return Be(t)?`Symbol(${(e=t.description)!=null?e:i})`:t};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let ne;class rc{constructor(i=!1){this.detached=i,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!i&&ne&&(ne.active?(this.parent=ne,this.index=(ne.scopes||(ne.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let i,e;if(this.scopes){const s=this.scopes.slice();for(i=0,e=s.length;i<e;i++)s[i].pause()}for(i=0,e=this.effects.length;i<e;i++)this.effects[i].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let i,e;if(this.scopes){const n=this.scopes.slice();for(i=0,e=n.length;i<e;i++)n[i].resume()}const s=this.effects.slice();for(i=0,e=s.length;i<e;i++)s[i].resume()}}run(i){if(this._active){const e=ne;try{return ne=this,i()}finally{ne=e}}}on(){++this._on===1&&(this.prevScope=ne,ne=this)}off(){if(this._on>0&&--this._on===0){if(ne===this)ne=this.prevScope;else{let i=ne;for(;i;){if(i.prevScope===this){i.prevScope=this.prevScope;break}i=i.prevScope}}this.prevScope=void 0}}stop(i){if(this._active){this._active=!1;let e,s;for(e=0,s=this.effects.length;e<s;e++)this.effects[e].stop();for(this.effects.length=0,e=0,s=this.cleanups.length;e<s;e++)this.cleanups[e]();if(this.cleanups.length=0,this.scopes){const n=this.scopes.slice();for(e=0,s=n.length;e<s;e++)n[e].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!i){const n=this.parent.scopes.pop();n&&n!==this&&(this.parent.scopes[this.index]=n,n.index=this.index)}this.parent=void 0}}}function lc(){return ne}let Kt;const xs=new WeakSet;class Hr{constructor(i){this.fn=i,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,ne&&(ne.active?ne.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,xs.has(this)&&(xs.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Wr(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,jo(this),Vr(this);const i=Kt,e=Me;Kt=this,Me=!0;try{return this.fn()}finally{Kr(this),Kt=i,Me=e,this.flags&=-3}}stop(){if(this.flags&1){for(let i=this.deps;i;i=i.nextDep)ao(i);this.deps=this.depsTail=void 0,jo(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?xs.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){Fs(this)&&this.run()}get dirty(){return Fs(this)}}let Ur=0,fn,pn;function Wr(t,i=!1){if(t.flags|=8,i){t.next=pn,pn=t;return}t.next=fn,fn=t}function ro(){Ur++}function lo(){if(--Ur>0)return;if(pn){let i=pn;for(pn=void 0;i;){const e=i.next;i.next=void 0,i.flags&=-9,i=e}}let t;for(;fn;){let i=fn;for(fn=void 0;i;){const e=i.next;if(i.next=void 0,i.flags&=-9,i.flags&1)try{i.trigger()}catch(s){t||(t=s)}i=e}}if(t)throw t}function Vr(t){for(let i=t.deps;i;i=i.nextDep)i.version=-1,i.prevActiveLink=i.dep.activeLink,i.dep.activeLink=i}function Kr(t){let i,e=t.depsTail,s=e;for(;s;){const n=s.prevDep;s.version===-1?(s===e&&(e=n),ao(s),ac(s)):i=s,s.dep.activeLink=s.prevActiveLink,s.prevActiveLink=void 0,s=n}t.deps=i,t.depsTail=e}function Fs(t){for(let i=t.deps;i;i=i.nextDep)if(i.dep.version!==i.version||i.dep.computed&&(qr(i.dep.computed)||i.dep.version!==i.version))return!0;return!!t._dirty}function qr(t){if(t.flags&4&&!(t.flags&16)||(t.flags&=-17,t.globalVersion===vn)||(t.globalVersion=vn,!t.isSSR&&t.flags&128&&(!t.deps&&!t._dirty||!Fs(t))))return;t.flags|=2;const i=t.dep,e=Kt,s=Me;Kt=t,Me=!0;try{Vr(t);const n=t.fn(t._value);(i.version===0||Ue(n,t._value))&&(t.flags|=128,t._value=n,i.version++)}catch(n){throw i.version++,n}finally{Kt=e,Me=s,Kr(t),t.flags&=-3}}function ao(t,i=!1){const{dep:e,prevSub:s,nextSub:n}=t;if(s&&(s.nextSub=n,t.prevSub=void 0),n&&(n.prevSub=s,t.nextSub=void 0),e.subs===t&&(e.subs=s,!s&&e.computed)){e.computed.flags&=-5;for(let r=e.computed.deps;r;r=r.nextDep)ao(r,!0)}!i&&!--e.sc&&e.map&&e.map.delete(e.key)}function ac(t){const{prevDep:i,nextDep:e}=t;i&&(i.nextDep=e,t.prevDep=void 0),e&&(e.prevDep=i,t.nextDep=void 0)}let Me=!0;const Gr=[];function ii(){Gr.push(Me),Me=!1}function ni(){const t=Gr.pop();Me=t===void 0?!0:t}function jo(t){const{cleanup:i}=t;if(t.cleanup=void 0,i){const e=Kt;Kt=void 0;try{i()}finally{Kt=e}}}let vn=0;class cc{constructor(i,e){this.sub=i,this.dep=e,this.version=e.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class co{constructor(i){this.computed=i,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(i){if(!Kt||!Me||Kt===this.computed)return;let e=this.activeLink;if(e===void 0||e.sub!==Kt)e=this.activeLink=new cc(Kt,this),Kt.deps?(e.prevDep=Kt.depsTail,Kt.depsTail.nextDep=e,Kt.depsTail=e):Kt.deps=Kt.depsTail=e,Zr(e);else if(e.version===-1&&(e.version=this.version,e.nextDep)){const s=e.nextDep;s.prevDep=e.prevDep,e.prevDep&&(e.prevDep.nextDep=s),e.prevDep=Kt.depsTail,e.nextDep=void 0,Kt.depsTail.nextDep=e,Kt.depsTail=e,Kt.deps===e&&(Kt.deps=s)}return e}trigger(i){this.version++,vn++,this.notify(i)}notify(i){ro();try{for(let e=this.subs;e;e=e.prevSub)e.sub.notify()&&e.sub.dep.notify()}finally{lo()}}}function Zr(t){if(t.dep.sc++,t.sub.flags&4){const i=t.dep.computed;if(i&&!t.dep.subs){i.flags|=20;for(let s=i.deps;s;s=s.nextDep)Zr(s)}const e=t.dep.subs;e!==t&&(t.prevSub=e,e&&(e.nextSub=t)),t.dep.subs=t}}const js=new WeakMap,Ii=Symbol(""),Hs=Symbol(""),bn=Symbol("");function ae(t,i,e){if(Me&&Kt){let s=js.get(t);s||js.set(t,s=new Map);let n=s.get(e);n||(s.set(e,n=new co),n.map=s,n.key=e),n.track()}}function Je(t,i,e,s,n,r){const l=js.get(t);if(!l){vn++;return}const o=a=>{a&&a.trigger()};if(ro(),i==="clear")l.forEach(o);else{const a=Ct(t),c=a&&no(e);if(a&&e==="length"){const d=Number(s);l.forEach((h,g)=>{(g==="length"||g===bn||!Be(g)&&g>=d)&&o(h)})}else switch((e!==void 0||l.has(void 0))&&o(l.get(e)),c&&o(l.get(bn)),i){case"add":a?c&&o(l.get("length")):(o(l.get(Ii)),ji(t)&&o(l.get(Hs)));break;case"delete":a||(o(l.get(Ii)),ji(t)&&o(l.get(Hs)));break;case"set":ji(t)&&o(l.get(Ii));break}}lo()}function Pi(t){const i=Pt(t);return i===t?i:(ae(i,"iterate",bn),Ce(t)?i:i.map(De))}function cs(t){return ae(t=Pt(t),"iterate",bn),t}function Fe(t,i){return si(t)?qi(Ai(t)?De(i):i):De(i)}const dc={__proto__:null,[Symbol.iterator](){return _s(this,Symbol.iterator,t=>Fe(this,t))},concat(...t){return Pi(this).concat(...t.map(i=>Ct(i)?Pi(i):i))},entries(){return _s(this,"entries",t=>(t[1]=Fe(this,t[1]),t))},every(t,i){return qe(this,"every",t,i,void 0,arguments)},filter(t,i){return qe(this,"filter",t,i,e=>e.map(s=>Fe(this,s)),arguments)},find(t,i){return qe(this,"find",t,i,e=>Fe(this,e),arguments)},findIndex(t,i){return qe(this,"findIndex",t,i,void 0,arguments)},findLast(t,i){return qe(this,"findLast",t,i,e=>Fe(this,e),arguments)},findLastIndex(t,i){return qe(this,"findLastIndex",t,i,void 0,arguments)},forEach(t,i){return qe(this,"forEach",t,i,void 0,arguments)},includes(...t){return Ss(this,"includes",t)},indexOf(...t){return Ss(this,"indexOf",t)},join(t){return Pi(this).join(t)},lastIndexOf(...t){return Ss(this,"lastIndexOf",t)},map(t,i){return qe(this,"map",t,i,void 0,arguments)},pop(){return Qi(this,"pop")},push(...t){return Qi(this,"push",t)},reduce(t,...i){return Ho(this,"reduce",t,i)},reduceRight(t,...i){return Ho(this,"reduceRight",t,i)},shift(){return Qi(this,"shift")},some(t,i){return qe(this,"some",t,i,void 0,arguments)},splice(...t){return Qi(this,"splice",t)},toReversed(){return Pi(this).toReversed()},toSorted(t){return Pi(this).toSorted(t)},toSpliced(...t){return Pi(this).toSpliced(...t)},unshift(...t){return Qi(this,"unshift",t)},values(){return _s(this,"values",t=>Fe(this,t))}};function _s(t,i,e){const s=cs(t),n=s[i]();return s!==t&&!Ce(t)&&(n._next=n.next,n.next=()=>{const r=n._next();return r.done||(r.value=e(r.value)),r}),n}const uc=Array.prototype;function qe(t,i,e,s,n,r){const l=cs(t),o=l!==t&&!Ce(t),a=l[i];if(a!==uc[i]){const h=a.apply(t,r);return o?De(h):h}let c=e;l!==t&&(o?c=function(h,g){return e.call(this,Fe(t,h),g,t)}:e.length>2&&(c=function(h,g){return e.call(this,h,g,t)}));const d=a.call(l,c,s);return o&&n?n(d):d}function Ho(t,i,e,s){const n=cs(t),r=n!==t&&!Ce(t);let l=e,o=!1;n!==t&&(r?(o=s.length===0,l=function(c,d,h){return o&&(o=!1,c=Fe(t,c)),e.call(this,c,Fe(t,d),h,t)}):e.length>3&&(l=function(c,d,h){return e.call(this,c,d,h,t)}));const a=n[i](l,...s);return o?Fe(t,a):a}function Ss(t,i,e){const s=Pt(t);ae(s,"iterate",bn);const n=s[i](...e);return(n===-1||n===!1)&&po(e[0])?(e[0]=Pt(e[0]),s[i](...e)):n}function Qi(t,i,e=[]){ii(),ro();const s=Pt(t)[i].apply(t,e);return lo(),ni(),s}const fc=eo("__proto__,__v_isRef,__isVue"),Yr=new Set(Object.getOwnPropertyNames(Symbol).filter(t=>t!=="arguments"&&t!=="caller").map(t=>Symbol[t]).filter(Be));function pc(t){Be(t)||(t=String(t));const i=Pt(this);return ae(i,"has",t),i.hasOwnProperty(t)}class Jr{constructor(i=!1,e=!1){this._isReadonly=i,this._isShallow=e}get(i,e,s){if(e==="__v_skip")return i.__v_skip;const n=this._isReadonly,r=this._isShallow;if(e==="__v_isReactive")return!n;if(e==="__v_isReadonly")return n;if(e==="__v_isShallow")return r;if(e==="__v_raw")return s===(n?r?_c:el:r?tl:Qr).get(i)||Object.getPrototypeOf(i)===Object.getPrototypeOf(s)?i:void 0;const l=Ct(i);if(!n){let a;if(l&&(a=dc[e]))return a;if(e==="hasOwnProperty")return pc}const o=Reflect.get(i,e,ue(i)?i:s);if((Be(e)?Yr.has(e):fc(e))||(n||ae(i,"get",e),r))return o;if(ue(o)){const a=l&&no(e)?o:o.value;return n&&jt(a)?Ws(a):a}return jt(o)?n?Ws(o):ds(o):o}}class Xr extends Jr{constructor(i=!1){super(!1,i)}set(i,e,s,n){let r=i[e];const l=Ct(i)&&no(e);if(!this._isShallow){const c=si(r);if(!Ce(s)&&!si(s)&&(r=Pt(r),s=Pt(s)),!l&&ue(r)&&!ue(s))return c||(r.value=s),!0}const o=l?Number(e)<i.length:Rt(i,e),a=Reflect.set(i,e,s,ue(i)?i:n);return i===Pt(n)&&a&&(o?Ue(s,r)&&Je(i,"set",e,s):Je(i,"add",e,s)),a}deleteProperty(i,e){const s=Rt(i,e);i[e];const n=Reflect.deleteProperty(i,e);return n&&s&&Je(i,"delete",e,void 0),n}has(i,e){const s=Reflect.has(i,e);return(!Be(e)||!Yr.has(e))&&ae(i,"has",e),s}ownKeys(i){return ae(i,"iterate",Ct(i)?"length":Ii),Reflect.ownKeys(i)}}class hc extends Jr{constructor(i=!1){super(!0,i)}set(i,e){return!0}deleteProperty(i,e){return!0}}const mc=new Xr,gc=new hc,vc=new Xr(!0);const Us=t=>t,Dn=t=>Reflect.getPrototypeOf(t);function bc(t,i,e){return function(...s){const n=this.__v_raw,r=Pt(n),l=ji(r),o=t==="entries"||t===Symbol.iterator&&l,a=t==="keys"&&l,c=n[t](...s),d=e?Us:i?qi:De;return!i&&ae(r,"iterate",a?Hs:Ii),le(Object.create(c),{next(){const{value:h,done:g}=c.next();return g?{value:h,done:g}:{value:o?[d(h[0]),d(h[1])]:d(h),done:g}}})}}function Ln(t){return function(...i){return t==="delete"?!1:t==="clear"?void 0:this}}function yc(t,i){const e={get(n){const r=this.__v_raw,l=Pt(r),o=Pt(n);t||(Ue(n,o)&&ae(l,"get",n),ae(l,"get",o));const{has:a}=Dn(l),c=i?Us:t?qi:De;if(a.call(l,n))return c(r.get(n));if(a.call(l,o))return c(r.get(o));r!==l&&r.get(n)},get size(){const n=this.__v_raw;return!t&&ae(Pt(n),"iterate",Ii),n.size},has(n){const r=this.__v_raw,l=Pt(r),o=Pt(n);return t||(Ue(n,o)&&ae(l,"has",n),ae(l,"has",o)),n===o?r.has(n):r.has(n)||r.has(o)},forEach(n,r){const l=this,o=l.__v_raw,a=Pt(o),c=i?Us:t?qi:De;return!t&&ae(a,"iterate",Ii),o.forEach((d,h)=>n.call(r,c(d),c(h),l))}};return le(e,t?{add:Ln("add"),set:Ln("set"),delete:Ln("delete"),clear:Ln("clear")}:{add(n){const r=Pt(this),l=Dn(r),o=Pt(n),a=!i&&!Ce(n)&&!si(n)?o:n;return l.has.call(r,a)||Ue(n,a)&&l.has.call(r,n)||Ue(o,a)&&l.has.call(r,o)||(r.add(a),Je(r,"add",a,a)),this},set(n,r){!i&&!Ce(r)&&!si(r)&&(r=Pt(r));const l=Pt(this),{has:o,get:a}=Dn(l);let c=o.call(l,n);c||(n=Pt(n),c=o.call(l,n));const d=a.call(l,n);return l.set(n,r),c?Ue(r,d)&&Je(l,"set",n,r):Je(l,"add",n,r),this},delete(n){const r=Pt(this),{has:l,get:o}=Dn(r);let a=l.call(r,n);a||(n=Pt(n),a=l.call(r,n)),o&&o.call(r,n);const c=r.delete(n);return a&&Je(r,"delete",n,void 0),c},clear(){const n=Pt(this),r=n.size!==0,l=n.clear();return r&&Je(n,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(n=>{e[n]=bc(n,t,i)}),e}function uo(t,i){const e=yc(t,i);return(s,n,r)=>n==="__v_isReactive"?!t:n==="__v_isReadonly"?t:n==="__v_raw"?s:Reflect.get(Rt(e,n)&&n in s?e:s,n,r)}const kc={get:uo(!1,!1)},wc={get:uo(!1,!0)},xc={get:uo(!0,!1)};const Qr=new WeakMap,tl=new WeakMap,el=new WeakMap,_c=new WeakMap;function Sc(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function ds(t){return si(t)?t:fo(t,!1,mc,kc,Qr)}function Cc(t){return fo(t,!1,vc,wc,tl)}function Ws(t){return fo(t,!0,gc,xc,el)}function fo(t,i,e,s,n){if(!jt(t)||t.__v_raw&&!(i&&t.__v_isReactive)||t.__v_skip||!Object.isExtensible(t))return t;const r=n.get(t);if(r)return r;const l=Sc(Ya(t));if(l===0)return t;const o=new Proxy(t,l===2?s:e);return n.set(t,o),o}function Ai(t){return si(t)?Ai(t.__v_raw):!!(t&&t.__v_isReactive)}function si(t){return!!(t&&t.__v_isReadonly)}function Ce(t){return!!(t&&t.__v_isShallow)}function po(t){return t?!!t.__v_raw:!1}function Pt(t){const i=t&&t.__v_raw;return i?Pt(i):t}function $c(t){return!Rt(t,"__v_skip")&&Object.isExtensible(t)&&zr(t,"__v_skip",!0),t}const De=t=>jt(t)?ds(t):t,qi=t=>jt(t)?Ws(t):t;function ue(t){return t?t.__v_isRef===!0:!1}function ht(t){return Ic(t,!1)}function Ic(t,i){return ue(t)?t:new Ac(t,i)}class Ac{constructor(i,e){this.dep=new co,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=e?i:Pt(i),this._value=e?i:De(i),this.__v_isShallow=e}get value(){return this.dep.track(),this._value}set value(i){const e=this._rawValue,s=this.__v_isShallow||Ce(i)||si(i);i=s?i:Pt(i),Ue(i,e)&&(this._rawValue=i,this._value=s?i:De(i),this.dep.trigger())}}function Ci(t){return ue(t)?t.value:t}const Tc={get:(t,i,e)=>i==="__v_raw"?t:Ci(Reflect.get(t,i,e)),set:(t,i,e,s)=>{const n=t[i];return ue(n)&&!ue(e)?(n.value=e,!0):Reflect.set(t,i,e,s)}};function il(t){return Ai(t)?t:new Proxy(t,Tc)}class Ec{constructor(i,e,s){this.fn=i,this.setter=e,this._value=void 0,this.dep=new co(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=vn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!e,this.isSSR=s}notify(){if(this.flags|=16,!(this.flags&8)&&Kt!==this)return Wr(this,!0),!0}get value(){const i=this.dep.track();return qr(this),i&&(i.version=this.dep.version),this._value}set value(i){this.setter&&this.setter(i)}}function Mc(t,i,e=!1){let s,n;return It(t)?s=t:(s=t.get,n=t.set),new Ec(s,n,e)}const On={},Gn=new WeakMap;let wi;function Bc(t,i=!1,e=wi){if(e){let s=Gn.get(e);s||Gn.set(e,s=[]),s.push(t)}}function Dc(t,i,e=Wt){const{immediate:s,deep:n,once:r,scheduler:l,augmentJob:o,call:a}=e,c=A=>n?A:Ce(A)||n===!1||n===0?Xe(A,1):Xe(A);let d,h,g,u,y=!1,p=!1;if(ue(t)?(h=()=>t.value,y=Ce(t)):Ai(t)?(h=()=>c(t),y=!0):Ct(t)?(p=!0,y=t.some(A=>Ai(A)||Ce(A)),h=()=>t.map(A=>{if(ue(A))return A.value;if(Ai(A))return c(A);if(It(A))return a?a(A,2):A()})):It(t)?i?h=a?()=>a(t,2):t:h=()=>{if(g){ii();try{g()}finally{ni()}}const A=wi;wi=d;try{return a?a(t,3,[u]):t(u)}finally{wi=A}}:h=Ve,i&&n){const A=h,x=n===!0?1/0:n;h=()=>Xe(A(),x)}const b=lc(),v=()=>{d.stop(),b&&b.active&&io(b.effects,d)};if(r&&i){const A=i;i=(...x)=>{const _=A(...x);return v(),_}}let k=p?new Array(t.length).fill(On):On;const S=A=>{if(!(!(d.flags&1)||!d.dirty&&!A))if(i){const x=d.run();if(A||n||y||(p?x.some((_,C)=>Ue(_,k[C])):Ue(x,k))){g&&g();const _=wi;wi=d;try{const C=[x,k===On?void 0:p&&k[0]===On?[]:k,u];k=x,a?a(i,3,C):i(...C)}finally{wi=_}}}else d.run()};return o&&o(S),d=new Hr(h),d.scheduler=l?()=>l(S,!1):S,u=A=>Bc(A,!1,d),g=d.onStop=()=>{const A=Gn.get(d);if(A){if(a)a(A,4);else for(const x of A)x();Gn.delete(d)}},i?s?S(!0):k=d.run():l?l(S.bind(null,!0),!0):d.run(),v.pause=d.pause.bind(d),v.resume=d.resume.bind(d),v.stop=v,v}function Xe(t,i=1/0,e){if(i<=0||!jt(t)||t.__v_skip||(e=e||new Map,(e.get(t)||0)>=i))return t;if(e.set(t,i),i--,ue(t))Xe(t.value,i,e);else if(Ct(t))for(let s=0;s<t.length;s++)Xe(t[s],i,e);else if(Ji(t)||ji(t))t.forEach(s=>{Xe(s,i,e)});else if(Rr(t)){for(const s in t)Xe(t[s],i,e);for(const s of Object.getOwnPropertySymbols(t))Object.prototype.propertyIsEnumerable.call(t,s)&&Xe(t[s],i,e)}return t}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Cn(t,i,e,s){try{return s?t(...s):t()}catch(n){us(n,i,e)}}function Le(t,i,e,s){if(It(t)){const n=Cn(t,i,e,s);return n&&Or(n)&&n.catch(r=>{us(r,i,e)}),n}if(Ct(t)){const n=[];for(let r=0;r<t.length;r++)n.push(Le(t[r],i,e,s));return n}}function us(t,i,e,s=!0){const n=i?i.vnode:null,{errorHandler:r,throwUnhandledErrorInProduction:l}=i&&i.appContext.config||Wt;if(i){let o=i.parent;const a=i.proxy,c=`https://vuejs.org/error-reference/#runtime-${e}`;for(;o;){const d=o.ec;if(d){for(let h=0;h<d.length;h++)if(d[h](t,a,c)===!1)return}o=o.parent}if(r){ii(),Cn(r,null,10,[t,a,c]),ni();return}}Lc(t,e,n,s,l)}function Lc(t,i,e,s=!0,n=!1){if(n)throw t;console.error(t)}const pe=[];let Ne=-1;const Hi=[];let ai=null,Ri=0;const nl=Promise.resolve();let Zn=null;function sl(t){const i=Zn||nl;return t?i.then(this?t.bind(this):t):i}function Oc(t){let i=Ne+1,e=pe.length;for(;i<e;){const s=i+e>>>1,n=pe[s],r=yn(n);r<t||r===t&&n.flags&2?i=s+1:e=s}return i}function ho(t){if(!(t.flags&1)){const i=yn(t),e=pe[pe.length-1];!e||!(t.flags&2)&&i>=yn(e)?pe.push(t):pe.splice(Oc(i),0,t),t.flags|=1,ol()}}function ol(){Zn||(Zn=nl.then(ll))}function Pc(t){Ct(t)?Hi.push(...t):ai&&t.id===-1?ai.splice(Ri+1,0,t):t.flags&1||(Hi.push(t),t.flags|=1),ol()}function Uo(t,i,e=Ne+1){for(;e<pe.length;e++){const s=pe[e];if(s&&s.flags&2){if(t&&s.id!==t.uid)continue;pe.splice(e,1),e--,s.flags&4&&(s.flags&=-2),s(),s.flags&4||(s.flags&=-2)}}}function rl(t){if(Hi.length){const i=[...new Set(Hi)].sort((e,s)=>yn(e)-yn(s));if(Hi.length=0,ai){ai.push(...i);return}for(ai=i,Ri=0;Ri<ai.length;Ri++){const e=ai[Ri];e.flags&4&&(e.flags&=-2),e.flags&8||e(),e.flags&=-2}ai=null,Ri=0}}const yn=t=>t.id==null?t.flags&2?-1:1/0:t.id;function ll(t){try{for(Ne=0;Ne<pe.length;Ne++){const i=pe[Ne];i&&!(i.flags&8)&&(i.flags&4&&(i.flags&=-2),Cn(i,i.i,i.i?15:14),i.flags&4||(i.flags&=-2))}}finally{for(;Ne<pe.length;Ne++){const i=pe[Ne];i&&(i.flags&=-2)}Ne=-1,pe.length=0,rl(),Zn=null,(pe.length||Hi.length)&&ll()}}let re=null,al=null;function Yn(t){const i=re;return re=t,al=t&&t.type.__scopeId||null,i}function cl(t,i=re,e){if(!i||t._n)return t;const s=(...n)=>{s._d&&er(-1);const r=Yn(i),l=ti.length;let o;try{o=t(...n)}finally{for(let a=ti.length;a>l;a--)ko();Yn(r),s._d&&er(1)}return o};return s._n=!0,s._c=!0,s._d=!0,s}function Ie(t,i){if(re===null)return t;const e=ms(re),s=t.dirs||(t.dirs=[]);for(let n=0;n<i.length;n++){let[r,l,o,a=Wt]=i[n];r&&(It(r)&&(r={mounted:r,updated:r}),r.deep&&Xe(l),s.push({dir:r,instance:e,value:l,oldValue:void 0,arg:o,modifiers:a}))}return t}function yi(t,i,e,s){const n=t.dirs,r=i&&i.dirs;for(let l=0;l<n.length;l++){const o=n[l];r&&(o.oldValue=r[l].value);let a=o.dir[s];a&&(ii(),Le(a,e,8,[t.el,o,t,i]),ni())}}function Rc(t,i){if(ce){let e=ce.provides;const s=ce.parent&&ce.parent.provides;s===e&&(e=ce.provides=Object.create(s)),e[t]=i}}function Qe(t,i,e=!1){const s=Od();if(s||Wi){let n=Wi?Wi._context.provides:s?s.parent==null||s.ce?s.vnode.appContext&&s.vnode.appContext.provides:s.parent.provides:void 0;if(n&&t in n)return n[t];if(arguments.length>1)return e&&It(i)?i.call(s&&s.proxy):i}}const zc=Symbol.for("v-scx"),Nc=()=>Qe(zc);function Ti(t,i,e){return dl(t,i,e)}function dl(t,i,e=Wt){const{immediate:s,deep:n,flush:r,once:l}=e,o=le({},e),a=i&&s||!i&&r!=="post";let c;if(wn){if(r==="sync"){const u=Nc();c=u.__watcherHandles||(u.__watcherHandles=[])}else if(!a){const u=()=>{};return u.stop=Ve,u.resume=Ve,u.pause=Ve,u}}const d=ce;o.call=(u,y,p)=>Le(u,d,y,p);let h=!1;r==="post"?o.scheduler=u=>{ge(u,d&&d.suspense)}:r!=="sync"&&(h=!0,o.scheduler=(u,y)=>{y?u():ho(u)}),o.augmentJob=u=>{i&&(u.flags|=4),h&&(u.flags|=2,d&&(u.id=d.uid,u.i=d))};const g=Dc(t,i,o);return wn&&(c?c.push(g):a&&g()),g}function Fc(t,i,e){const s=this.proxy,n=Qt(t)?t.includes(".")?ul(s,t):()=>s[t]:t.bind(s,s);let r;It(i)?r=i:(r=i.handler,e=i);const l=In(this),o=dl(n,r.bind(s),e);return l(),o}function ul(t,i){const e=i.split(".");return()=>{let s=t;for(let n=0;n<e.length&&s;n++)s=s[e[n]];return s}}const jc=Symbol("_vte"),Hc=t=>t.__isTeleport,Cs=Symbol("_leaveCb");function mo(t,i){t.shapeFlag&6&&t.component?(t.transition=i,mo(t.component.subTree,i)):t.shapeFlag&128?(t.ssContent.transition=i.clone(t.ssContent),t.ssFallback.transition=i.clone(t.ssFallback)):t.transition=i}function ye(t,i){return It(t)?le({name:t.name},i,{setup:t}):t}function fl(t){t.ids=[t.ids[0]+t.ids[2]+++"-",0,0]}function Wo(t,i){let e;return!!((e=Object.getOwnPropertyDescriptor(t,i))&&!e.configurable)}const Jn=new WeakMap;function hn(t,i,e,s,n=!1){if(Ct(t)){t.forEach((p,b)=>hn(p,i&&(Ct(i)?i[b]:i),e,s,n));return}if(Ui(s)&&!n){s.shapeFlag&512&&s.type.__asyncResolved&&s.component.subTree.component&&hn(t,i,e,s.component.subTree);return}const r=s.shapeFlag&4?ms(s.component):s.el,l=n?null:r,{i:o,r:a}=t,c=i&&i.r,d=o.refs===Wt?o.refs={}:o.refs,h=o.setupState,g=Pt(h),u=h===Wt?Lr:p=>Wo(d,p)?!1:Rt(g,p),y=(p,b)=>!(b&&Wo(d,b));if(c!=null&&c!==a){if(Vo(i),Qt(c))d[c]=null,u(c)&&(h[c]=null);else if(ue(c)){const p=i;y(c,p.k)&&(c.value=null),p.k&&(d[p.k]=null)}}if(It(a))Cn(a,o,12,[l,d]);else{const p=Qt(a),b=ue(a);if(p||b){const v=()=>{if(t.f){const k=p?u(a)?h[a]:d[a]:y()||!t.k?a.value:d[t.k];if(n)Ct(k)&&io(k,r);else if(Ct(k))k.includes(r)||k.push(r);else if(p)d[a]=[r],u(a)&&(h[a]=d[a]);else{const S=[r];y(a,t.k)&&(a.value=S),t.k&&(d[t.k]=S)}}else p?(d[a]=l,u(a)&&(h[a]=l)):b&&(y(a,t.k)&&(a.value=l),t.k&&(d[t.k]=l))};if(l){const k=()=>{v(),Jn.delete(t)};k.id=-1,Jn.set(t,k),ge(k,e)}else Vo(t),v()}}}function Vo(t){const i=Jn.get(t);i&&(i.flags|=8,Jn.delete(t))}as().requestIdleCallback;as().cancelIdleCallback;const Ui=t=>!!t.type.__asyncLoader,pl=t=>t.type.__isKeepAlive;function Uc(t,i){hl(t,"a",i)}function Wc(t,i){hl(t,"da",i)}function hl(t,i,e=ce){const s=t.__wdc||(t.__wdc=()=>{let n=e;for(;n;){if(n.isDeactivated)return;n=n.parent}return t()});if(fs(i,s,e),e){let n=e.parent;for(;n&&n.parent;)pl(n.parent.vnode)&&Vc(s,i,e,n),n=n.parent}}function Vc(t,i,e,s){const n=fs(i,t,s,!0);vo(()=>{io(s[i],n)},e)}function fs(t,i,e=ce,s=!1){if(e){const n=e[t]||(e[t]=[]),r=i.__weh||(i.__weh=(...l)=>{ii();const o=In(e),a=Le(i,e,t,l);return o(),ni(),a});return s?n.unshift(r):n.push(r),r}}const ri=t=>(i,e=ce)=>{(!wn||t==="sp")&&fs(t,(...s)=>i(...s),e)},Kc=ri("bm"),$n=ri("m"),qc=ri("bu"),Gc=ri("u"),go=ri("bum"),vo=ri("um"),Zc=ri("sp"),Yc=ri("rtg"),Jc=ri("rtc");function Xc(t,i=ce){fs("ec",t,i)}const Qc="components";function td(t,i){return id(Qc,t,!0,i)||t}const ed=Symbol.for("v-ndc");function id(t,i,e=!0,s=!1){const n=re||ce;if(n){const r=n.type;{const o=Fd(r,!1);if(o&&(o===i||o===he(i)||o===rs(he(i))))return r}const l=Ko(n[t]||r[t],i)||Ko(n.appContext[t],i);return!l&&s?r:l}}function Ko(t,i){return t&&(t[i]||t[he(i)]||t[rs(he(i))])}function ke(t,i,e,s){let n;const r=e,l=Ct(t);if(l||Qt(t)){const o=l&&Ai(t);let a=!1,c=!1;o&&(a=!Ce(t),c=si(t),t=cs(t)),n=new Array(t.length);for(let d=0,h=t.length;d<h;d++)n[d]=i(a?c?qi(De(t[d])):De(t[d]):t[d],d,void 0,r)}else if(typeof t=="number"){n=new Array(t);for(let o=0;o<t;o++)n[o]=i(o+1,o,void 0,r)}else if(jt(t))if(t[Symbol.iterator])n=Array.from(t,(o,a)=>i(o,a,void 0,r));else{const o=Object.keys(t);n=new Array(o.length);for(let a=0,c=o.length;a<c;a++){const d=o[a];n[a]=i(t[d],d,a,r)}}else n=[];return n}function Pn(t,i,e={},s,n,r){if(re.ce||re.parent&&Ui(re.parent)&&re.parent.ce){const c=e,d=Object.keys(c).length>0;return i!=="default"&&(c.name=i),et(),Ee(Gt,null,[pt("slot",c,s&&s())],d?-2:64)}let l=t[i];l&&l._c&&(l._d=!1);const o=ti.length;et();let a;try{const c=l&&ml(l(e)),d=e.key||r||c&&c.key;a=Ee(Gt,{key:(d&&!Be(d)?d:`_${i}`)+(!c&&s?"_fb":"")},c||(s?s():[]),c&&t._===1?64:-2)}catch(c){for(let d=ti.length;d>o;d--)ko();throw c}finally{l&&l._c&&(l._d=!0)}return a}function ml(t){return t.some(i=>wo(i)?!(i.type===oi||i.type===Gt&&!ml(i.children)):!0)?t:null}const Vs=t=>t?Ol(t)?ms(t):Vs(t.parent):null,mn=le(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>Vs(t.parent),$root:t=>Vs(t.root),$host:t=>t.ce,$emit:t=>t.emit,$options:t=>vl(t),$forceUpdate:t=>t.f||(t.f=()=>{ho(t.update)}),$nextTick:t=>t.n||(t.n=sl.bind(t.proxy)),$watch:t=>Fc.bind(t)}),$s=(t,i)=>t!==Wt&&!t.__isScriptSetup&&Rt(t,i),nd={get({_:t},i){if(i==="__v_skip")return!0;const{ctx:e,setupState:s,data:n,props:r,accessCache:l,type:o,appContext:a}=t;if(i[0]!=="$"){const g=l[i];if(g!==void 0)switch(g){case 1:return s[i];case 2:return n[i];case 4:return e[i];case 3:return r[i]}else{if($s(s,i))return l[i]=1,s[i];if(n!==Wt&&Rt(n,i))return l[i]=2,n[i];if(Rt(r,i))return l[i]=3,r[i];if(e!==Wt&&Rt(e,i))return l[i]=4,e[i];Ks&&(l[i]=0)}}const c=mn[i];let d,h;if(c)return i==="$attrs"&&ae(t.attrs,"get",""),c(t);if((d=o.__cssModules)&&(d=d[i]))return d;if(e!==Wt&&Rt(e,i))return l[i]=4,e[i];if(h=a.config.globalProperties,Rt(h,i))return h[i]},set({_:t},i,e){const{data:s,setupState:n,ctx:r}=t;return $s(n,i)?(n[i]=e,!0):s!==Wt&&Rt(s,i)?(s[i]=e,!0):Rt(t.props,i)||i[0]==="$"&&i.slice(1)in t?!1:(r[i]=e,!0)},has({_:{data:t,setupState:i,accessCache:e,ctx:s,appContext:n,props:r,type:l}},o){let a;return!!(e[o]||t!==Wt&&o[0]!=="$"&&Rt(t,o)||$s(i,o)||Rt(r,o)||Rt(s,o)||Rt(mn,o)||Rt(n.config.globalProperties,o)||(a=l.__cssModules)&&a[o])},defineProperty(t,i,e){return e.get!=null?t._.accessCache[i]=0:Rt(e,"value")&&this.set(t,i,e.value,null),Reflect.defineProperty(t,i,e)}};function qo(t){return Ct(t)?t.reduce((i,e)=>(i[e]=null,i),{}):t}let Ks=!0;function sd(t){const i=vl(t),e=t.proxy,s=t.ctx;Ks=!1,i.beforeCreate&&Go(i.beforeCreate,t,"bc");const{data:n,computed:r,methods:l,watch:o,provide:a,inject:c,created:d,beforeMount:h,mounted:g,beforeUpdate:u,updated:y,activated:p,deactivated:b,beforeDestroy:v,beforeUnmount:k,destroyed:S,unmounted:A,render:x,renderTracked:_,renderTriggered:C,errorCaptured:B,serverPrefetch:M,expose:R,inheritAttrs:J,components:T,directives:L,filters:w}=i;if(c&&od(c,s,null),l)for(const z in l){const at=l[z];It(at)&&(s[z]=at.bind(e))}if(n){const z=n.call(e,e);jt(z)&&(t.data=ds(z))}if(Ks=!0,r)for(const z in r){const at=r[z],W=It(at)?at.bind(e,e):It(at.get)?at.get.bind(e,e):Ve,Y=!It(at)&&It(at.set)?at.set.bind(e):Ve,V=$t({get:W,set:Y});Object.defineProperty(s,z,{enumerable:!0,configurable:!0,get:()=>V.value,set:N=>V.value=N})}if(o)for(const z in o)gl(o[z],s,e,z);if(a){const z=It(a)?a.call(e):a;Reflect.ownKeys(z).forEach(at=>{Rc(at,z[at])})}d&&Go(d,t,"c");function Q(z,at){Ct(at)?at.forEach(W=>z(W.bind(e))):at&&z(at.bind(e))}if(Q(Kc,h),Q($n,g),Q(qc,u),Q(Gc,y),Q(Uc,p),Q(Wc,b),Q(Xc,B),Q(Jc,_),Q(Yc,C),Q(go,k),Q(vo,A),Q(Zc,M),Ct(R))if(R.length){const z=t.exposed||(t.exposed={});R.forEach(at=>{Object.defineProperty(z,at,{get:()=>e[at],set:W=>e[at]=W,enumerable:!0})})}else t.exposed||(t.exposed={});x&&t.render===Ve&&(t.render=x),J!=null&&(t.inheritAttrs=J),T&&(t.components=T),L&&(t.directives=L),M&&fl(t)}function od(t,i,e=Ve){Ct(t)&&(t=qs(t));for(const s in t){const n=t[s];let r;jt(n)?"default"in n?r=Qe(n.from||s,n.default,!0):r=Qe(n.from||s):r=Qe(n),ue(r)?Object.defineProperty(i,s,{enumerable:!0,configurable:!0,get:()=>r.value,set:l=>r.value=l}):i[s]=r}}function Go(t,i,e){Le(Ct(t)?t.map(s=>s.bind(i.proxy)):t.bind(i.proxy),i,e)}function gl(t,i,e,s){let n=s.includes(".")?ul(e,s):()=>e[s];if(Qt(t)){const r=i[t];It(r)&&Ti(n,r)}else if(It(t))Ti(n,t.bind(e));else if(jt(t))if(Ct(t))t.forEach(r=>gl(r,i,e,s));else{const r=It(t.handler)?t.handler.bind(e):i[t.handler];It(r)&&Ti(n,r,t)}}function vl(t){const i=t.type,{mixins:e,extends:s}=i,{mixins:n,optionsCache:r,config:{optionMergeStrategies:l}}=t.appContext,o=r.get(i);let a;return o?a=o:!n.length&&!e&&!s?a=i:(a={},n.length&&n.forEach(c=>Xn(a,c,l,!0)),Xn(a,i,l)),jt(i)&&r.set(i,a),a}function Xn(t,i,e,s=!1){const{mixins:n,extends:r}=i;r&&Xn(t,r,e,!0),n&&n.forEach(l=>Xn(t,l,e,!0));for(const l in i)if(!(s&&l==="expose")){const o=rd[l]||e&&e[l];t[l]=o?o(t[l],i[l]):i[l]}return t}const rd={data:Zo,props:Yo,emits:Yo,methods:sn,computed:sn,beforeCreate:fe,created:fe,beforeMount:fe,mounted:fe,beforeUpdate:fe,updated:fe,beforeDestroy:fe,beforeUnmount:fe,destroyed:fe,unmounted:fe,activated:fe,deactivated:fe,errorCaptured:fe,serverPrefetch:fe,components:sn,directives:sn,watch:ad,provide:Zo,inject:ld};function Zo(t,i){return i?t?function(){return le(It(t)?t.call(this,this):t,It(i)?i.call(this,this):i)}:i:t}function ld(t,i){return sn(qs(t),qs(i))}function qs(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++)i[t[e]]=t[e];return i}return t}function fe(t,i){return t?[...new Set([].concat(t,i))]:i}function sn(t,i){return t?le(Object.create(null),t,i):i}function Yo(t,i){return t?Ct(t)&&Ct(i)?[...new Set([...t,...i])]:le(Object.create(null),qo(t),qo(i??{})):i}function ad(t,i){if(!t)return i;if(!i)return t;const e=le(Object.create(null),t);for(const s in i)e[s]=fe(t[s],i[s]);return e}function bl(){return{app:null,config:{isNativeTag:Lr,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let cd=0;function dd(t,i){return function(s,n=null){It(s)||(s=le({},s)),n!=null&&!jt(n)&&(n=null);const r=bl(),l=new WeakSet,o=[];let a=!1;const c=r.app={_uid:cd++,_component:s,_props:n,_container:null,_context:r,_instance:null,version:Hd,get config(){return r.config},set config(d){},use(d,...h){return l.has(d)||(d&&It(d.install)?(l.add(d),d.install(c,...h)):It(d)&&(l.add(d),d(c,...h))),c},mixin(d){return r.mixins.includes(d)||r.mixins.push(d),c},component(d,h){return h?(r.components[d]=h,c):r.components[d]},directive(d,h){return h?(r.directives[d]=h,c):r.directives[d]},mount(d,h,g){if(!a){const u=c._ceVNode||pt(s,n);return u.appContext=r,g===!0?g="svg":g===!1&&(g=void 0),t(u,d,g),a=!0,c._container=d,d.__vue_app__=c,ms(u.component)}},onUnmount(d){o.push(d)},unmount(){a&&(Le(o,c._instance,16),t(null,c._container),delete c._container.__vue_app__)},provide(d,h){return r.provides[d]=h,c},runWithContext(d){const h=Wi;Wi=c;try{return d()}finally{Wi=h}}};return c}}let Wi=null;const ud=(t,i)=>i==="modelValue"||i==="model-value"?t.modelModifiers:t[`${i}Modifiers`]||t[`${he(i)}Modifiers`]||t[`${hi(i)}Modifiers`];function fd(t,i,...e){if(t.isUnmounted)return;const s=t.vnode.props||Wt;let n=e;const r=i.startsWith("update:"),l=r&&ud(s,i.slice(7));l&&(l.trim&&(n=e.map(d=>Qt(d)?d.trim():d)),l.number&&(n=e.map(ls)));let o,a=s[o=ks(i)]||s[o=ks(he(i))];!a&&r&&(a=s[o=ks(hi(i))]),a&&Le(a,t,6,n);const c=s[o+"Once"];if(c){if(!t.emitted)t.emitted={};else if(t.emitted[o])return;t.emitted[o]=!0,Le(c,t,6,n)}}const pd=new WeakMap;function yl(t,i,e=!1){const s=e?pd:i.emitsCache,n=s.get(t);if(n!==void 0)return n;const r=t.emits;let l={},o=!1;if(!It(t)){const a=c=>{const d=yl(c,i,!0);d&&(o=!0,le(l,d))};!e&&i.mixins.length&&i.mixins.forEach(a),t.extends&&a(t.extends),t.mixins&&t.mixins.forEach(a)}return!r&&!o?(jt(t)&&s.set(t,null),null):(Ct(r)?r.forEach(a=>l[a]=null):le(l,r),jt(t)&&s.set(t,l),l)}function ps(t,i){return!t||!ns(i)?!1:(i=i.slice(2),i=i==="Once"?i:i.replace(/Once$/,""),Rt(t,i[0].toLowerCase()+i.slice(1))||Rt(t,hi(i))||Rt(t,i))}function Jo(t){const{type:i,vnode:e,proxy:s,withProxy:n,propsOptions:[r],slots:l,attrs:o,emit:a,render:c,renderCache:d,props:h,data:g,setupState:u,ctx:y,inheritAttrs:p}=t,b=Yn(t);let v,k;try{if(e.shapeFlag&4){const A=n||s,x=A;v=je(c.call(x,A,d,h,u,g,y)),k=o}else{const A=i;v=je(A.length>1?A(h,{attrs:o,slots:l,emit:a}):A(h,null)),k=i.props?o:hd(o)}}catch(A){ti.length=0,us(A,t,1),v=pt(oi)}let S=v;if(k&&p!==!1){const A=Object.keys(k),{shapeFlag:x}=S;A.length&&x&7&&(r&&A.some(ss)&&(k=md(k,r)),S=Gi(S,k,!1,!0))}return e.dirs&&(S=Gi(S,null,!1,!0),S.dirs=S.dirs?S.dirs.concat(e.dirs):e.dirs),e.transition&&mo(S,e.transition),v=S,Yn(b),v}const hd=t=>{let i;for(const e in t)(e==="class"||e==="style"||ns(e))&&((i||(i={}))[e]=t[e]);return i},md=(t,i)=>{const e={};for(const s in t)(!ss(s)||!(s.slice(9)in i))&&(e[s]=t[s]);return e};function gd(t,i,e){const{props:s,children:n,component:r}=t,{props:l,children:o,patchFlag:a}=i,c=r.emitsOptions;if(i.dirs||i.transition)return!0;if(e&&a>=0){if(a&1024)return!0;if(a&16)return s?Xo(s,l,c):!!l;if(a&8){const d=i.dynamicProps;for(let h=0;h<d.length;h++){const g=d[h];if(kl(l,s,g)&&!ps(c,g))return!0}}}else return(n||o)&&(!o||!o.$stable)?!0:s===l?!1:s?l?Xo(s,l,c):!0:!!l;return!1}function Xo(t,i,e){const s=Object.keys(i);if(s.length!==Object.keys(t).length)return!0;for(let n=0;n<s.length;n++){const r=s[n];if(kl(i,t,r)&&!ps(e,r))return!0}return!1}function kl(t,i,e){const s=t[e],n=i[e];return e==="style"&&jt(s)&&jt(n)?!Xi(s,n):s!==n}function vd({vnode:t,parent:i,suspense:e},s){for(;i;){const n=i.subTree;if(n.suspense&&n.suspense.activeBranch===t&&(n.suspense.vnode.el=n.el=s,t=n),n===t)(t=i.vnode).el=s,i=i.parent;else break}e&&e.activeBranch===t&&(e.vnode.el=s)}const wl={},xl=()=>Object.create(wl),_l=t=>Object.getPrototypeOf(t)===wl;function bd(t,i,e,s=!1){const n={},r=xl();t.propsDefaults=Object.create(null),Sl(t,i,n,r);for(const l in t.propsOptions[0])l in n||(n[l]=void 0);e?t.props=s?n:Cc(n):t.type.props?t.props=n:t.props=r,t.attrs=r}function yd(t,i,e,s){const{props:n,attrs:r,vnode:{patchFlag:l}}=t,o=Pt(n),[a]=t.propsOptions;let c=!1;if((s||l>0)&&!(l&16)){if(l&8){const d=t.vnode.dynamicProps;for(let h=0;h<d.length;h++){let g=d[h];if(ps(t.emitsOptions,g))continue;const u=i[g];if(a)if(Rt(r,g))u!==r[g]&&(r[g]=u,c=!0);else{const y=he(g);n[y]=Gs(a,o,y,u,t,!1)}else u!==r[g]&&(r[g]=u,c=!0)}}}else{Sl(t,i,n,r)&&(c=!0);let d;for(const h in o)(!i||!Rt(i,h)&&((d=hi(h))===h||!Rt(i,d)))&&(a?e&&(e[h]!==void 0||e[d]!==void 0)&&(n[h]=Gs(a,o,h,void 0,t,!0)):delete n[h]);if(r!==o)for(const h in r)(!i||!Rt(i,h))&&(delete r[h],c=!0)}c&&Je(t.attrs,"set","")}function Sl(t,i,e,s){const[n,r]=t.propsOptions;let l=!1,o;if(i)for(let a in i){if(un(a))continue;const c=i[a];let d;n&&Rt(n,d=he(a))?!r||!r.includes(d)?e[d]=c:(o||(o={}))[d]=c:ps(t.emitsOptions,a)||(!(a in s)||c!==s[a])&&(s[a]=c,l=!0)}if(r){const a=Pt(e),c=o||Wt;for(let d=0;d<r.length;d++){const h=r[d];e[h]=Gs(n,a,h,c[h],t,!Rt(c,h))}}return l}function Gs(t,i,e,s,n,r){const l=t[e];if(l!=null){const o=Rt(l,"default");if(o&&s===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&It(a)){const{propsDefaults:c}=n;if(e in c)s=c[e];else{const d=In(n);s=c[e]=a.call(null,i),d()}}else s=a;n.ce&&n.ce._setProp(e,s)}l[0]&&(r&&!o?s=!1:l[1]&&(s===""||s===hi(e))&&(s=!0))}return s}const kd=new WeakMap;function Cl(t,i,e=!1){const s=e?kd:i.propsCache,n=s.get(t);if(n)return n;const r=t.props,l={},o=[];let a=!1;if(!It(t)){const d=h=>{a=!0;const[g,u]=Cl(h,i,!0);le(l,g),u&&o.push(...u)};!e&&i.mixins.length&&i.mixins.forEach(d),t.extends&&d(t.extends),t.mixins&&t.mixins.forEach(d)}if(!r&&!a)return jt(t)&&s.set(t,Fi),Fi;if(Ct(r))for(let d=0;d<r.length;d++){const h=he(r[d]);Qo(h)&&(l[h]=Wt)}else if(r)for(const d in r){const h=he(d);if(Qo(h)){const g=r[d],u=l[h]=Ct(g)||It(g)?{type:g}:le({},g),y=u.type;let p=!1,b=!0;if(Ct(y))for(let v=0;v<y.length;++v){const k=y[v],S=It(k)&&k.name;if(S==="Boolean"){p=!0;break}else S==="String"&&(b=!1)}else p=It(y)&&y.name==="Boolean";u[0]=p,u[1]=b,(p||Rt(u,"default"))&&o.push(h)}}const c=[l,o];return jt(t)&&s.set(t,c),c}function Qo(t){return t[0]!=="$"&&!un(t)}const bo=t=>t==="_"||t==="_ctx"||t==="$stable",yo=t=>Ct(t)?t.map(je):[je(t)],wd=(t,i,e)=>{if(i._n)return i;const s=cl((...n)=>yo(i(...n)),e);return s._c=!1,s},$l=(t,i,e)=>{const s=t._ctx;for(const n in t){if(bo(n))continue;const r=t[n];if(It(r))i[n]=wd(n,r,s);else if(r!=null){const l=yo(r);i[n]=()=>l}}},Il=(t,i)=>{const e=yo(i);t.slots.default=()=>e},Al=(t,i,e)=>{for(const s in i)(e||!bo(s))&&(t[s]=i[s])},xd=(t,i,e)=>{const s=t.slots=xl();if(t.vnode.shapeFlag&32){const n=i._;n?(Al(s,i,e),e&&zr(s,"_",n,!0)):$l(i,s)}else i&&Il(t,i)},_d=(t,i,e)=>{const{vnode:s,slots:n}=t;let r=!0,l=Wt;if(s.shapeFlag&32){const o=i._;o?e&&o===1?r=!1:Al(n,i,e):(r=!i.$stable,$l(i,n)),l=i}else i&&(Il(t,i),l={default:1});if(r)for(const o in n)!bo(o)&&l[o]==null&&delete n[o]},ge=Ad;function Sd(t){return Cd(t)}function Cd(t,i){const e=as();e.__VUE__=!0;const{insert:s,remove:n,patchProp:r,createElement:l,createText:o,createComment:a,setText:c,setElementText:d,parentNode:h,nextSibling:g,setScopeId:u=Ve,insertStaticContent:y}=t,p=(E,P,f,F=null,O=null,$=null,I=void 0,D=null,K=!!P.dynamicChildren)=>{if(E===P)return;E&&!tn(E,P)&&(F=mt(E),N(E,O,$,!0),E=null),P.patchFlag===-2&&(K=!1,P.dynamicChildren=null);const{type:H,ref:U,shapeFlag:G}=P;switch(H){case hs:b(E,P,f,F);break;case oi:v(E,P,f,F);break;case Hn:E==null&&k(P,f,F,I);break;case Gt:T(E,P,f,F,O,$,I,D,K);break;default:G&1?x(E,P,f,F,O,$,I,D,K):G&6?L(E,P,f,F,O,$,I,D,K):(G&64||G&128)&&H.process(E,P,f,F,O,$,I,D,K,ot)}U!=null&&O?hn(U,E&&E.ref,$,P||E,!P):U==null&&E&&E.ref!=null&&hn(E.ref,null,$,E,!0)},b=(E,P,f,F)=>{if(E==null)s(P.el=o(P.children),f,F);else{const O=P.el=E.el;P.children!==E.children&&c(O,P.children)}},v=(E,P,f,F)=>{E==null?s(P.el=a(P.children||""),f,F):P.el=E.el},k=(E,P,f,F)=>{[E.el,E.anchor]=y(E.children,P,f,F,E.el,E.anchor)},S=({el:E,anchor:P},f,F)=>{let O;for(;E&&E!==P;)O=g(E),s(E,f,F),E=O;s(P,f,F)},A=({el:E,anchor:P})=>{let f;for(;E&&E!==P;)f=g(E),n(E),E=f;n(P)},x=(E,P,f,F,O,$,I,D,K)=>{if(P.type==="svg"?I="svg":P.type==="math"&&(I="mathml"),E==null)_(P,f,F,O,$,I,D,K);else{const H=E.el&&E.el._isVueCE?E.el:null;try{H&&H._beginPatch(),M(E,P,O,$,I,D,K)}finally{H&&H._endPatch()}}},_=(E,P,f,F,O,$,I,D)=>{let K,H;const{props:U,shapeFlag:G,transition:it,dirs:tt}=E;if(K=E.el=l(E.type,$,U&&U.is,U),G&8?d(K,E.children):G&16&&B(E.children,K,null,F,O,Is(E,$),I,D),tt&&yi(E,null,F,"created"),C(K,E,E.scopeId,I,F),U){for(const xt in U)xt!=="value"&&!un(xt)&&r(K,xt,null,U[xt],$,F);"value"in U&&r(K,"value",null,U.value,$),(H=U.onVnodeBeforeMount)&&Re(H,F,E)}tt&&yi(E,null,F,"beforeMount");const dt=$d(O,it);dt&&it.beforeEnter(K),s(K,P,f),((H=U&&U.onVnodeMounted)||dt||tt)&&ge(()=>{try{H&&Re(H,F,E),dt&&it.enter(K),tt&&yi(E,null,F,"mounted")}finally{}},O)},C=(E,P,f,F,O)=>{if(f&&u(E,f),F)for(let $=0;$<F.length;$++)u(E,F[$]);if(O){let $=O.subTree;if(P===$||Bl($.type)&&($.ssContent===P||$.ssFallback===P)){const I=O.vnode;C(E,I,I.scopeId,I.slotScopeIds,O.parent)}}},B=(E,P,f,F,O,$,I,D,K=0)=>{for(let H=K;H<E.length;H++){const U=E[H]=D?Ye(E[H]):je(E[H]);p(null,U,P,f,F,O,$,I,D)}},M=(E,P,f,F,O,$,I)=>{const D=P.el=E.el;let{patchFlag:K,dynamicChildren:H,dirs:U}=P;K|=E.patchFlag&16;const G=E.props||Wt,it=P.props||Wt;let tt;if(f&&ki(f,!1),(tt=it.onVnodeBeforeUpdate)&&Re(tt,f,P,E),U&&yi(P,E,f,"beforeUpdate"),f&&ki(f,!0),H&&(!E.dynamicChildren||E.dynamicChildren.length!==H.length)&&(K=0,I=!1,H=null),(G.innerHTML&&it.innerHTML==null||G.textContent&&it.textContent==null)&&d(D,""),H?R(E.dynamicChildren,H,D,f,F,Is(P,O),$):I||at(E,P,D,null,f,F,Is(P,O),$,!1),K>0){if(K&16)J(D,G,it,f,O);else if(K&2&&G.class!==it.class&&r(D,"class",null,it.class,O),K&4&&r(D,"style",G.style,it.style,O),K&8){const dt=P.dynamicProps;for(let xt=0;xt<dt.length;xt++){const bt=dt[xt],Mt=G[bt],Vt=it[bt];(Vt!==Mt||bt==="value")&&r(D,bt,Mt,Vt,O,f)}}K&1&&E.children!==P.children&&d(D,P.children)}else!I&&H==null&&J(D,G,it,f,O);((tt=it.onVnodeUpdated)||U)&&ge(()=>{tt&&Re(tt,f,P,E),U&&yi(P,E,f,"updated")},F)},R=(E,P,f,F,O,$,I)=>{for(let D=0;D<P.length;D++){const K=E[D],H=P[D],U=K.el&&(K.type===Gt||!tn(K,H)||K.shapeFlag&198)?h(K.el):f;p(K,H,U,null,F,O,$,I,!0)}},J=(E,P,f,F,O)=>{if(P!==f){if(P!==Wt)for(const $ in P)!un($)&&!($ in f)&&r(E,$,P[$],null,O,F);for(const $ in f){if(un($))continue;const I=f[$],D=P[$];I!==D&&$!=="value"&&r(E,$,D,I,O,F)}"value"in f&&r(E,"value",P.value,f.value,O)}},T=(E,P,f,F,O,$,I,D,K)=>{const H=P.el=E?E.el:o(""),U=P.anchor=E?E.anchor:o("");let{patchFlag:G,dynamicChildren:it,slotScopeIds:tt}=P;tt&&(D=D?D.concat(tt):tt),E==null?(s(H,f,F),s(U,f,F),B(P.children||[],f,U,O,$,I,D,K)):G>0&&G&64&&it&&E.dynamicChildren&&E.dynamicChildren.length===it.length?(R(E.dynamicChildren,it,f,O,$,I,D),(P.key!=null||O&&P===O.subTree)&&Tl(E,P,!0)):at(E,P,f,U,O,$,I,D,K)},L=(E,P,f,F,O,$,I,D,K)=>{P.slotScopeIds=D,E==null?P.shapeFlag&512?O.ctx.activate(P,f,F,I,K):w(P,f,F,O,$,I,K):j(E,P,K)},w=(E,P,f,F,O,$,I)=>{const D=E.component=Ld(E,F,O);if(pl(E)&&(D.ctx.renderer=ot),Pd(D,!1,I),D.asyncDep){if(O&&O.registerDep(D,Q,I),!E.el){const K=D.subTree=pt(oi);v(null,K,P,f),E.placeholder=K.el}}else Q(D,E,P,f,O,$,I)},j=(E,P,f)=>{const F=P.component=E.component;if(gd(E,P,f))if(F.asyncDep&&!F.asyncResolved){z(F,P,f);return}else F.next=P,F.update();else P.el=E.el,F.vnode=P},Q=(E,P,f,F,O,$,I)=>{const D=()=>{if(E.isMounted){let{next:G,bu:it,u:tt,parent:dt,vnode:xt}=E;{const ee=El(E);if(ee){G&&(G.el=xt.el,z(E,G,I)),ee.asyncDep.then(()=>{ge(()=>{E.isUnmounted||H()},O)});return}}let bt=G,Mt;ki(E,!1),G?(G.el=xt.el,z(E,G,I)):G=xt,it&&jn(it),(Mt=G.props&&G.props.onVnodeBeforeUpdate)&&Re(Mt,dt,G,xt),ki(E,!0);const Vt=Jo(E),Yt=E.subTree;E.subTree=Vt,p(Yt,Vt,h(Yt.el),mt(Yt),E,O,$),G.el=Vt.el,bt===null&&vd(E,Vt.el),tt&&ge(tt,O),(Mt=G.props&&G.props.onVnodeUpdated)&&ge(()=>Re(Mt,dt,G,xt),O)}else{let G;const{el:it,props:tt}=P,{bm:dt,m:xt,parent:bt,root:Mt,type:Vt}=E,Yt=Ui(P);ki(E,!1),dt&&jn(dt),!Yt&&(G=tt&&tt.onVnodeBeforeMount)&&Re(G,bt,P),ki(E,!0);{Mt.ce&&Mt.ce._hasShadowRoot()&&Mt.ce._injectChildStyle(Vt,E.parent?E.parent.type:void 0);const ee=E.subTree=Jo(E);p(null,ee,f,F,E,O,$),P.el=ee.el}if(xt&&ge(xt,O),!Yt&&(G=tt&&tt.onVnodeMounted)){const ee=P;ge(()=>Re(G,bt,ee),O)}(P.shapeFlag&256||bt&&Ui(bt.vnode)&&bt.vnode.shapeFlag&256)&&E.a&&ge(E.a,O),E.isMounted=!0,P=f=F=null}};E.scope.on();const K=E.effect=new Hr(D);E.scope.off();const H=E.update=K.run.bind(K),U=E.job=K.runIfDirty.bind(K);U.i=E,U.id=E.uid,K.scheduler=()=>ho(U),ki(E,!0),H()},z=(E,P,f)=>{P.component=E;const F=E.vnode.props;E.vnode=P,E.next=null,yd(E,P.props,F,f),_d(E,P.children,f),ii(),Uo(E),ni()},at=(E,P,f,F,O,$,I,D,K=!1)=>{const H=E&&E.children,U=E?E.shapeFlag:0,G=P.children,{patchFlag:it,shapeFlag:tt}=P;if(it>0){if(it&128){Y(H,G,f,F,O,$,I,D,K);return}else if(it&256){W(H,G,f,F,O,$,I,D,K);return}}tt&8?(U&16&&X(H,O,$),G!==H&&d(f,G)):U&16?tt&16?Y(H,G,f,F,O,$,I,D,K):X(H,O,$,!0):(U&8&&d(f,""),tt&16&&B(G,f,F,O,$,I,D,K))},W=(E,P,f,F,O,$,I,D,K)=>{E=E||Fi,P=P||Fi;const H=E.length,U=P.length,G=Math.min(H,U);let it;for(it=0;it<G;it++){const tt=P[it]=K?Ye(P[it]):je(P[it]);p(E[it],tt,f,null,O,$,I,D,K)}H>U?X(E,O,$,!0,!1,G):B(P,f,F,O,$,I,D,K,G)},Y=(E,P,f,F,O,$,I,D,K)=>{let H=0;const U=P.length;let G=E.length-1,it=U-1;for(;H<=G&&H<=it;){const tt=E[H],dt=P[H]=K?Ye(P[H]):je(P[H]);if(tn(tt,dt))p(tt,dt,f,null,O,$,I,D,K);else break;H++}for(;H<=G&&H<=it;){const tt=E[G],dt=P[it]=K?Ye(P[it]):je(P[it]);if(tn(tt,dt))p(tt,dt,f,null,O,$,I,D,K);else break;G--,it--}if(H>G){if(H<=it){const tt=it+1,dt=tt<U?P[tt].el:F;for(;H<=it;)p(null,P[H]=K?Ye(P[H]):je(P[H]),f,dt,O,$,I,D,K),H++}}else if(H>it)for(;H<=G;)N(E[H],O,$,!0),H++;else{const tt=H,dt=H,xt=new Map;for(H=dt;H<=it;H++){const te=P[H]=K?Ye(P[H]):je(P[H]);te.key!=null&&xt.set(te.key,H)}let bt,Mt=0;const Vt=it-dt+1;let Yt=!1,ee=0;const Nt=new Array(Vt);for(H=0;H<Vt;H++)Nt[H]=0;for(H=tt;H<=G;H++){const te=E[H];if(Mt>=Vt){N(te,O,$,!0);continue}let Jt;if(te.key!=null)Jt=xt.get(te.key);else for(bt=dt;bt<=it;bt++)if(Nt[bt-dt]===0&&tn(te,P[bt])){Jt=bt;break}Jt===void 0?N(te,O,$,!0):(Nt[Jt-dt]=H+1,Jt>=ee?ee=Jt:Yt=!0,p(te,P[Jt],f,null,O,$,I,D,K),Mt++)}const Ke=Yt?Id(Nt):Fi;for(bt=Ke.length-1,H=Vt-1;H>=0;H--){const te=dt+H,Jt=P[te],mi=P[te+1],Bi=te+1<U?mi.el||Ml(mi):F;Nt[H]===0?p(null,Jt,f,Bi,O,$,I,D,K):Yt&&(bt<0||H!==Ke[bt]?V(Jt,f,Bi,2):bt--)}}},V=(E,P,f,F,O=null)=>{const{el:$,type:I,transition:D,children:K,shapeFlag:H}=E;if(H&6){V(E.component.subTree,P,f,F);return}if(H&128){E.suspense.move(P,f,F);return}if(H&64){I.move(E,P,f,ot);return}if(I===Gt){s($,P,f);for(let G=0;G<K.length;G++)V(K[G],P,f,F);s(E.anchor,P,f);return}if(I===Hn){S(E,P,f);return}if(F!==2&&H&1&&D)if(F===0)D.persisted&&!$[Cs]?s($,P,f):(D.beforeEnter($),s($,P,f),ge(()=>D.enter($),O));else{const{leave:G,delayLeave:it,afterLeave:tt}=D,dt=()=>{E.ctx.isUnmounted?n($):s($,P,f)},xt=()=>{const bt=$._isLeaving||!!$[Cs];$._isLeaving&&$[Cs](!0),D.persisted&&!bt?dt():G($,()=>{dt(),tt&&tt()})};it?it($,dt,xt):xt()}else s($,P,f)},N=(E,P,f,F=!1,O=!1)=>{const{type:$,props:I,ref:D,children:K,dynamicChildren:H,shapeFlag:U,patchFlag:G,dirs:it,cacheIndex:tt,memo:dt}=E;if(G===-2&&(O=!1),D!=null&&(ii(),hn(D,null,f,E,!0),ni()),tt!=null&&(P.renderCache[tt]=void 0),U&256){P.ctx.deactivate(E);return}const xt=U&1&&it,bt=!Ui(E);let Mt;if(bt&&(Mt=I&&I.onVnodeBeforeUnmount)&&Re(Mt,P,E),U&6)st(E.component,f,F);else{if(U&128){E.suspense.unmount(f,F);return}xt&&yi(E,null,P,"beforeUnmount"),U&64?E.type.remove(E,P,f,ot,F):H&&!H.hasOnce&&($!==Gt||G>0&&G&64)?X(H,P,f,!1,!0):($===Gt&&G&384||!O&&U&16)&&X(K,P,f),F&&ct(E)}const Vt=dt!=null&&tt==null;(bt&&(Mt=I&&I.onVnodeUnmounted)||xt||Vt)&&ge(()=>{Mt&&Re(Mt,P,E),xt&&yi(E,null,P,"unmounted"),Vt&&(E.el=null)},f)},ct=E=>{const{type:P,el:f,anchor:F,transition:O}=E;if(P===Gt){rt(f,F);return}if(P===Hn){A(E);return}const $=()=>{n(f),O&&!O.persisted&&O.afterLeave&&O.afterLeave()};if(E.shapeFlag&1&&O&&!O.persisted){const{leave:I,delayLeave:D}=O,K=()=>I(f,$);D?D(E.el,$,K):K()}else $()},rt=(E,P)=>{let f;for(;E!==P;)f=g(E),n(E),E=f;n(P)},st=(E,P,f)=>{const{bum:F,scope:O,job:$,subTree:I,um:D,m:K,a:H}=E;tr(K),tr(H),F&&jn(F),O.stop(),$&&($.flags|=8,N(I,E,P,f)),D&&ge(D,P),ge(()=>{E.isUnmounted=!0},P)},X=(E,P,f,F=!1,O=!1,$=0)=>{for(let I=$;I<E.length;I++)N(E[I],P,f,F,O)},mt=E=>{if(E.shapeFlag&6)return mt(E.component.subTree);if(E.shapeFlag&128)return E.suspense.next();const P=g(E.anchor||E.el),f=P&&P[jc];return f?g(f):P};let gt=!1;const Z=(E,P,f)=>{let F;E==null?P._vnode&&(N(P._vnode,null,null,!0),F=P._vnode.component):p(P._vnode||null,E,P,null,null,null,f),P._vnode=E,gt||(gt=!0,Uo(F),rl(),gt=!1)},ot={p,um:N,m:V,r:ct,mt:w,mc:B,pc:at,pbc:R,n:mt,o:t};return{render:Z,hydrate:void 0,createApp:dd(Z)}}function Is({type:t,props:i},e){return e==="svg"&&t==="foreignObject"||e==="mathml"&&t==="annotation-xml"&&i&&i.encoding&&i.encoding.includes("html")?void 0:e}function ki({effect:t,job:i},e){e?(t.flags|=32,i.flags|=4):(t.flags&=-33,i.flags&=-5)}function $d(t,i){return(!t||t&&!t.pendingBranch)&&i&&!i.persisted}function Tl(t,i,e=!1){const s=t.children,n=i.children;if(Ct(s)&&Ct(n))for(let r=0;r<s.length;r++){const l=s[r];let o=n[r];o.shapeFlag&1&&!o.dynamicChildren&&((o.patchFlag<=0||o.patchFlag===32)&&(o=n[r]=Ye(n[r]),o.el=l.el),!e&&o.patchFlag!==-2&&Tl(l,o)),o.type===hs&&(o.patchFlag===-1&&(o=n[r]=Ye(o)),o.el=l.el),o.type===oi&&!o.el&&(o.el=l.el)}}function Id(t){const i=t.slice(),e=[0];let s,n,r,l,o;const a=t.length;for(s=0;s<a;s++){const c=t[s];if(c!==0){if(n=e[e.length-1],t[n]<c){i[s]=n,e.push(s);continue}for(r=0,l=e.length-1;r<l;)o=r+l>>1,t[e[o]]<c?r=o+1:l=o;c<t[e[r]]&&(r>0&&(i[s]=e[r-1]),e[r]=s)}}for(r=e.length,l=e[r-1];r-- >0;)e[r]=l,l=i[l];return e}function El(t){const i=t.subTree.component;if(i)return i.asyncDep&&!i.asyncResolved?i:El(i)}function tr(t){if(t)for(let i=0;i<t.length;i++)t[i].flags|=8}function Ml(t){if(t.placeholder)return t.placeholder;const i=t.component;return i?Ml(i.subTree):null}const Bl=t=>t.__isSuspense;function Ad(t,i){i&&i.pendingBranch?Ct(t)?i.effects.push(...t):i.effects.push(t):Pc(t)}const Gt=Symbol.for("v-fgt"),hs=Symbol.for("v-txt"),oi=Symbol.for("v-cmt"),Hn=Symbol.for("v-stc"),ti=[];let we=null;function et(t=!1){ti.push(we=t?null:[])}function ko(){ti.pop(),we=ti[ti.length-1]||null}let kn=1;function er(t,i=!1){kn+=t,t<0&&we&&i&&(we.hasOnce=!0)}function Dl(t){return t.dynamicChildren=kn>0?we||Fi:null,ko(),kn>0&&we&&we.push(t),t}function nt(t,i,e,s,n,r){return Dl(m(t,i,e,s,n,r,!0))}function Ee(t,i,e,s,n){return Dl(pt(t,i,e,s,n,!0))}function wo(t){return t?t.__v_isVNode===!0:!1}function tn(t,i){return t.type===i.type&&t.key===i.key}const Ll=({key:t})=>t??null,Un=({ref:t,ref_key:i,ref_for:e})=>(typeof t=="number"&&(t=""+t),t!=null?Qt(t)||ue(t)||It(t)?{i:re,r:t,k:i,f:!!e}:t:null);function m(t,i=null,e=null,s=0,n=null,r=t===Gt?0:1,l=!1,o=!1){const a={__v_isVNode:!0,__v_skip:!0,type:t,props:i,key:i&&Ll(i),ref:i&&Un(i),scopeId:al,slotScopeIds:null,children:e,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:r,patchFlag:s,dynamicProps:n,dynamicChildren:null,appContext:null,ctx:re};return o?(Qn(a,e),r&128&&t.normalize(a)):e&&(a.shapeFlag|=Qt(e)?8:16),kn>0&&!l&&we&&(a.patchFlag>0||r&6)&&a.patchFlag!==32&&we.push(a),a}const pt=Td;function Td(t,i=null,e=null,s=0,n=null,r=!1){if((!t||t===ed)&&(t=oi),wo(t)){const o=Gi(t,i,!0);return e&&Qn(o,e),kn>0&&!r&&we&&(o.shapeFlag&6?we[we.indexOf(t)]=o:we.push(o)),o.patchFlag=-2,o}if(jd(t)&&(t=t.__vccOpts),i){i=Ed(i);let{class:o,style:a}=i;o&&!Qt(o)&&(i.class=Et(o)),jt(a)&&(po(a)&&!Ct(a)&&(a=le({},a)),i.style=so(a))}const l=Qt(t)?1:Bl(t)?128:Hc(t)?64:jt(t)?4:It(t)?2:0;return m(t,i,e,s,n,l,r,!0)}function Ed(t){return t?po(t)||_l(t)?le({},t):t:null}function Gi(t,i,e=!1,s=!1){const{props:n,ref:r,patchFlag:l,children:o,transition:a}=t,c=i?Md(n||{},i):n,d={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&Ll(c),ref:i&&i.ref?e&&r?Ct(r)?r.concat(Un(i)):[r,Un(i)]:Un(i):r,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:o,target:t.target,targetStart:t.targetStart,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:i&&t.type!==Gt?l===-1?16:l|16:l,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:a,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&Gi(t.ssContent),ssFallback:t.ssFallback&&Gi(t.ssFallback),placeholder:t.placeholder,el:t.el,anchor:t.anchor,ctx:t.ctx,ce:t.ce};return a&&s&&mo(d,a.clone(d)),d}function Zs(t=" ",i=0){return pt(hs,null,t,i)}function $e(t,i){const e=pt(Hn,null,t);return e.staticCount=i,e}function Ft(t="",i=!1){return i?(et(),Ee(oi,null,t)):pt(oi,null,t)}function je(t){return t==null||typeof t=="boolean"?pt(oi):Ct(t)?pt(Gt,null,t.slice()):wo(t)?Ye(t):pt(hs,null,String(t))}function Ye(t){return t.el===null&&t.patchFlag!==-1||t.memo?t:Gi(t)}function Qn(t,i){let e=0;const{shapeFlag:s}=t;if(i==null)i=null;else if(Ct(i))e=16;else if(typeof i=="object")if(s&65){const n=i.default;n&&(n._c&&(n._d=!1),Qn(t,n()),n._c&&(n._d=!0));return}else{e=32;const n=i._;!n&&!_l(i)?i._ctx=re:n===3&&re&&(re.slots._===1?i._=1:(i._=2,t.patchFlag|=1024))}else if(It(i)){if(s&65){Qn(t,{default:i});return}i={default:i,_ctx:re},e=32}else i=String(i),s&64?(e=16,i=[Zs(i)]):e=8;t.children=i,t.shapeFlag|=e}function Md(...t){const i={};for(let e=0;e<t.length;e++){const s=t[e];for(const n in s)if(n==="class")i.class!==s.class&&(i.class=Et([i.class,s.class]));else if(n==="style")i.style=so([i.style,s.style]);else if(ns(n)){const r=i[n],l=s[n];l&&r!==l&&!(Ct(r)&&r.includes(l))?i[n]=r?[].concat(r,l):l:l==null&&r==null&&!ss(n)&&(i[n]=l)}else n!==""&&(i[n]=s[n])}return i}function Re(t,i,e,s=null){Le(t,i,7,[e,s])}const Bd=bl();let Dd=0;function Ld(t,i,e){const s=t.type,n=(i?i.appContext:t.appContext)||Bd,r={uid:Dd++,vnode:t,type:s,parent:i,appContext:n,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new rc(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:i?i.provides:Object.create(n.provides),ids:i?i.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Cl(s,n),emitsOptions:yl(s,n),emit:null,emitted:null,propsDefaults:Wt,inheritAttrs:s.inheritAttrs,ctx:Wt,data:Wt,props:Wt,attrs:Wt,slots:Wt,refs:Wt,setupState:Wt,setupContext:null,suspense:e,suspenseId:e?e.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return r.ctx={_:r},r.root=i?i.root:r,r.emit=fd.bind(null,r),t.ce&&t.ce(r),r}let ce=null;const Od=()=>ce||re;let ts,Ys;{const t=as(),i=(e,s)=>{let n;return(n=t[e])||(n=t[e]=[]),n.push(s),r=>{n.length>1?n.forEach(l=>l(r)):n[0](r)}};ts=i("__VUE_INSTANCE_SETTERS__",e=>ce=e),Ys=i("__VUE_SSR_SETTERS__",e=>wn=e)}const In=t=>{const i=ce;return ts(t),t.scope.on(),()=>{t.scope.off(),ts(i)}},ir=()=>{ce&&ce.scope.off(),ts(null)};function Ol(t){return t.vnode.shapeFlag&4}let wn=!1;function Pd(t,i=!1,e=!1){i&&Ys(i);const{props:s,children:n}=t.vnode,r=Ol(t);bd(t,s,r,i),xd(t,n,e||i);const l=r?Rd(t,i):void 0;return i&&Ys(!1),l}function Rd(t,i){const e=t.type;t.accessCache=Object.create(null),t.proxy=new Proxy(t.ctx,nd);const{setup:s}=e;if(s){ii();const n=t.setupContext=s.length>1?Nd(t):null,r=In(t),l=Cn(s,t,0,[t.props,n]),o=Or(l);if(ni(),r(),(o||t.sp)&&!Ui(t)&&fl(t),o){if(l.then(ir,ir),i)return l.then(a=>{nr(t,a)}).catch(a=>{us(a,t,0)});t.asyncDep=l}else nr(t,l)}else Pl(t)}function nr(t,i,e){It(i)?t.type.__ssrInlineRender?t.ssrRender=i:t.render=i:jt(i)&&(t.setupState=il(i)),Pl(t)}function Pl(t,i,e){const s=t.type;t.render||(t.render=s.render||Ve);{const n=In(t);ii();try{sd(t)}finally{ni(),n()}}}const zd={get(t,i){return ae(t,"get",""),t[i]}};function Nd(t){const i=e=>{t.exposed=e||{}};return{attrs:new Proxy(t.attrs,zd),slots:t.slots,emit:t.emit,expose:i}}function ms(t){return t.exposed?t.exposeProxy||(t.exposeProxy=new Proxy(il($c(t.exposed)),{get(i,e){if(e in i)return i[e];if(e in mn)return mn[e](t)},has(i,e){return e in i||e in mn}})):t.proxy}function Fd(t,i=!0){return It(t)?t.displayName||t.name:t.name||i&&t.__name}function jd(t){return It(t)&&"__vccOpts"in t}const $t=(t,i)=>Mc(t,i,wn),Hd="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Js;const sr=typeof window<"u"&&window.trustedTypes;if(sr)try{Js=sr.createPolicy("vue",{createHTML:t=>t})}catch{}const Rl=Js?t=>Js.createHTML(t):t=>t,Ud="http://www.w3.org/2000/svg",Wd="http://www.w3.org/1998/Math/MathML",Ze=typeof document<"u"?document:null,or=Ze&&Ze.createElement("template"),Vd={insert:(t,i,e)=>{i.insertBefore(t,e||null)},remove:t=>{const i=t.parentNode;i&&i.removeChild(t)},createElement:(t,i,e,s)=>{const n=i==="svg"?Ze.createElementNS(Ud,t):i==="mathml"?Ze.createElementNS(Wd,t):e?Ze.createElement(t,{is:e}):Ze.createElement(t);return t==="select"&&s&&s.multiple!=null&&n.setAttribute("multiple",s.multiple),n},createText:t=>Ze.createTextNode(t),createComment:t=>Ze.createComment(t),setText:(t,i)=>{t.nodeValue=i},setElementText:(t,i)=>{t.textContent=i},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>Ze.querySelector(t),setScopeId(t,i){t.setAttribute(i,"")},insertStaticContent(t,i,e,s,n,r){const l=e?e.previousSibling:i.lastChild;if(n&&(n===r||n.nextSibling))for(;i.insertBefore(n.cloneNode(!0),e),!(n===r||!(n=n.nextSibling)););else{or.innerHTML=Rl(s==="svg"?`<svg>${t}</svg>`:s==="mathml"?`<math>${t}</math>`:t);const o=or.content;if(s==="svg"||s==="mathml"){const a=o.firstChild;for(;a.firstChild;)o.appendChild(a.firstChild);o.removeChild(a)}i.insertBefore(o,e)}return[l?l.nextSibling:i.firstChild,e?e.previousSibling:i.lastChild]}},Kd=Symbol("_vtc");function qd(t,i,e){const s=t[Kd];s&&(i=(i?[i,...s]:[...s]).join(" ")),i==null?t.removeAttribute("class"):e?t.setAttribute("class",i):t.className=i}const es=Symbol("_vod"),zl=Symbol("_vsh"),Nl={name:"show",beforeMount(t,{value:i},{transition:e}){t[es]=t.style.display==="none"?"":t.style.display,e&&i?e.beforeEnter(t):en(t,i)},mounted(t,{value:i},{transition:e}){e&&i&&e.enter(t)},updated(t,{value:i,oldValue:e},{transition:s}){!i!=!e&&(s?i?(s.beforeEnter(t),en(t,!0),s.enter(t)):s.leave(t,()=>{en(t,!1)}):en(t,i))},beforeUnmount(t,{value:i}){en(t,i)}};function en(t,i){t.style.display=i?t[es]:"none",t[zl]=!i}const Gd=Symbol(""),Zd=/(?:^|;)\s*display\s*:/;function Yd(t,i,e){const s=t.style,n=Qt(e);let r=!1;if(e&&!n){if(i)if(Qt(i))for(const l of i.split(";")){const o=l.slice(0,l.indexOf(":")).trim();e[o]==null&&on(s,o,"")}else for(const l in i)e[l]==null&&on(s,l,"");for(const l in e){l==="display"&&(r=!0);const o=e[l];o!=null?Xd(t,l,!Qt(i)&&i?i[l]:void 0,o)||on(s,l,o):on(s,l,"")}}else if(n){if(i!==e){const l=s[Gd];l&&(e+=";"+l),s.cssText=e,r=Zd.test(e)}}else i&&t.removeAttribute("style");es in t&&(t[es]=r?s.display:"",t[zl]&&(s.display="none"))}const rr=/\s*!important$/;function on(t,i,e){if(Ct(e))e.forEach(s=>on(t,i,s));else if(e==null&&(e=""),i.startsWith("--"))t.setProperty(i,e);else{const s=Jd(t,i);rr.test(e)?t.setProperty(hi(s),e.replace(rr,""),"important"):t[s]=e}}const lr=["Webkit","Moz","ms"],As={};function Jd(t,i){const e=As[i];if(e)return e;let s=he(i);if(s!=="filter"&&s in t)return As[i]=s;s=rs(s);for(let n=0;n<lr.length;n++){const r=lr[n]+s;if(r in t)return As[i]=r}return i}function Xd(t,i,e,s){return t.tagName==="TEXTAREA"&&(i==="width"||i==="height")&&Qt(s)&&e===s}const ar="http://www.w3.org/1999/xlink";function cr(t,i,e,s,n,r=sc(i)){s&&i.startsWith("xlink:")?e==null?t.removeAttributeNS(ar,i.slice(6,i.length)):t.setAttributeNS(ar,i,e):e==null||r&&!Nr(e)?t.removeAttribute(i):t.setAttribute(i,r?"":Be(e)?String(e):e)}function dr(t,i,e,s,n){if(i==="innerHTML"||i==="textContent"){e!=null&&(t[i]=i==="innerHTML"?Rl(e):e);return}const r=t.tagName;if(i==="value"&&r!=="PROGRESS"&&!r.includes("-")){const o=r==="OPTION"?t.getAttribute("value")||"":t.value,a=e==null?t.type==="checkbox"?"on":"":String(e);(o!==a||!("_value"in t))&&(t.value=a),e==null&&t.removeAttribute(i),t._value=e;return}let l=!1;if(e===""||e==null){const o=typeof t[i];o==="boolean"?e=Nr(e):e==null&&o==="string"?(e="",l=!0):o==="number"&&(e=0,l=!0)}try{t[i]=e}catch{}l&&t.removeAttribute(n||i)}function ci(t,i,e,s){t.addEventListener(i,e,s)}function Qd(t,i,e,s){t.removeEventListener(i,e,s)}const ur=Symbol("_vei");function tu(t,i,e,s,n=null){const r=t[ur]||(t[ur]={}),l=r[i];if(s&&l)l.value=s;else{const[o,a]=nu(i);if(s){const c=r[i]=ru(s,n);ci(t,o,c,a)}else l&&(Qd(t,o,l,a),r[i]=void 0)}}const eu=/(Once|Passive|Capture)$/,iu=/^on:?(?:Once|Passive|Capture)$/;function nu(t){let i,e;for(;(e=t.match(eu))&&!iu.test(t);)i||(i={}),t=t.slice(0,t.length-e[1].length),i[e[1].toLowerCase()]=!0;return[t[2]===":"?t.slice(3):hi(t.slice(2)),i]}let Ts=0;const su=Promise.resolve(),ou=()=>Ts||(su.then(()=>Ts=0),Ts=Date.now());function ru(t,i){const e=s=>{if(!s._vts)s._vts=Date.now();else if(s._vts<=e.attached)return;const n=e.value;if(Ct(n)){const r=s.stopImmediatePropagation;s.stopImmediatePropagation=()=>{r.call(s),s._stopped=!0};const l=n.slice(),o=[s];for(let a=0;a<l.length&&!s._stopped;a++){const c=l[a];c&&Le(c,i,5,o)}}else Le(n,i,5,[s])};return e.value=t,e.attached=ou(),e}const fr=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&t.charCodeAt(2)>96&&t.charCodeAt(2)<123,lu=(t,i,e,s,n,r)=>{const l=n==="svg";i==="class"?qd(t,s,l):i==="style"?Yd(t,e,s):ns(i)?ss(i)||tu(t,i,e,s,r):(i[0]==="."?(i=i.slice(1),!0):i[0]==="^"?(i=i.slice(1),!1):au(t,i,s,l))?(dr(t,i,s),!t.tagName.includes("-")&&(i==="value"||i==="checked"||i==="selected")&&cr(t,i,s,l,r,i!=="value")):t._isVueCE&&(cu(t,i)||t._def.__asyncLoader&&(/[A-Z]/.test(i)||!Qt(s)))?dr(t,he(i),s,r,i):(i==="true-value"?t._trueValue=s:i==="false-value"&&(t._falseValue=s),cr(t,i,s,l))};function au(t,i,e,s){if(s)return!!(i==="innerHTML"||i==="textContent"||i in t&&fr(i)&&It(e));if(i==="spellcheck"||i==="draggable"||i==="translate"||i==="autocorrect"||i==="sandbox"&&t.tagName==="IFRAME"||i==="form"||i==="list"&&t.tagName==="INPUT"||i==="type"&&t.tagName==="TEXTAREA")return!1;if(i==="width"||i==="height"){const n=t.tagName;if(n==="IMG"||n==="VIDEO"||n==="CANVAS"||n==="SOURCE")return!1}return fr(i)&&Qt(e)?!1:i in t}function cu(t,i){const e=t._def.props;if(!e)return!1;const s=he(i);return Array.isArray(e)?e.some(n=>he(n)===s):Object.keys(e).some(n=>he(n)===s)}const Zi=t=>{const i=t.props["onUpdate:modelValue"]||!1;return Ct(i)?e=>jn(i,e):i};function du(t){t.target.composing=!0}function pr(t){const i=t.target;i.composing&&(i.composing=!1,i.dispatchEvent(new Event("input")))}const ei=Symbol("_assign");function hr(t,i,e){return i&&(t=t.trim()),e&&(t=ls(t)),t}const is={created(t,{modifiers:{lazy:i,trim:e,number:s}},n){t[ei]=Zi(n);const r=s||n.props&&n.props.type==="number";ci(t,i?"change":"input",l=>{l.target.composing||t[ei](hr(t.value,e,r))}),(e||r)&&ci(t,"change",()=>{t.value=hr(t.value,e,r)}),i||(ci(t,"compositionstart",du),ci(t,"compositionend",pr),ci(t,"change",pr))},mounted(t,{value:i}){t.value=i??""},beforeUpdate(t,{value:i,oldValue:e,modifiers:{lazy:s,trim:n,number:r}},l){if(t[ei]=Zi(l),t.composing)return;const o=(r||t.type==="number")&&!/^0\d/.test(t.value)?ls(t.value):t.value,a=i??"";if(o===a)return;const c=t.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===t&&t.type!=="range"&&(s&&i===e||n&&t.value.trim()===a)||(t.value=a)}},Rn={deep:!0,created(t,i,e){t[ei]=Zi(e),ci(t,"change",()=>{const s=t._modelValue,n=xn(t),r=t.checked,l=t[ei];if(Ct(s)){const o=oo(s,n),a=o!==-1;if(r&&!a)l(s.concat(n));else if(!r&&a){const c=[...s];c.splice(o,1),l(c)}}else if(Ji(s)){const o=new Set(s);r?o.add(n):o.delete(n),l(o)}else l(Fl(t,r))})},mounted:mr,beforeUpdate(t,i,e){t[ei]=Zi(e),mr(t,i,e)}};function mr(t,{value:i,oldValue:e},s){t._modelValue=i;let n;if(Ct(i))n=oo(i,s.props.value)>-1;else if(Ji(i))n=i.has(s.props.value);else{if(i===e)return;n=Xi(i,Fl(t,!0))}t.checked!==n&&(t.checked=n)}const uu={deep:!0,created(t,{value:i,modifiers:{number:e}},s){t._modelValue=i,ci(t,"change",()=>{const n=Array.prototype.filter.call(t.options,r=>r.selected).map(r=>e?ls(xn(r)):xn(r));t[ei](t.multiple?Ji(t._modelValue)?new Set(n):n:n[0]),t._assigning=!0,sl(()=>{t._assigning=!1})}),t[ei]=Zi(s)},mounted(t,{value:i}){gr(t,i)},beforeUpdate(t,{value:i},e){t._modelValue=i,t[ei]=Zi(e)},updated(t,{value:i}){t._assigning||gr(t,i)}};function gr(t,i){const e=t.multiple,s=Ct(i);if(!(e&&!s&&!Ji(i))){for(let n=0,r=t.options.length;n<r;n++){const l=t.options[n],o=xn(l);if(e)if(s){const a=typeof o;a==="string"||a==="number"?l.selected=i.some(c=>String(c)===String(o)):l.selected=oo(i,o)>-1}else l.selected=i.has(o);else if(Xi(xn(l),i)){t.selectedIndex!==n&&(t.selectedIndex=n);return}}!e&&t.selectedIndex!==-1&&(t.selectedIndex=-1)}}function xn(t){return"_value"in t?t._value:t.value}function Fl(t,i){const e=i?"_trueValue":"_falseValue";return e in t?t[e]:i}const fu=["ctrl","shift","alt","meta"],pu={stop:t=>t.stopPropagation(),prevent:t=>t.preventDefault(),self:t=>t.target!==t.currentTarget,ctrl:t=>!t.ctrlKey,shift:t=>!t.shiftKey,alt:t=>!t.altKey,meta:t=>!t.metaKey,left:t=>"button"in t&&t.button!==0,middle:t=>"button"in t&&t.button!==1,right:t=>"button"in t&&t.button!==2,exact:(t,i)=>fu.some(e=>t[`${e}Key`]&&!i.includes(e))},Te=(t,i)=>{if(!t)return t;const e=t._withMods||(t._withMods={}),s=i.join(".");return e[s]||(e[s]=((n,...r)=>{for(let l=0;l<i.length;l++){const o=pu[i[l]];if(o&&o(n,i))return}return t(n,...r)}))},hu={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},mu=(t,i)=>{const e=t._withKeys||(t._withKeys={}),s=i.join(".");return e[s]||(e[s]=(n=>{if(!("key"in n))return;const r=hi(n.key);if(i.some(l=>l===r||hu[l]===r))return t(n)}))},gu=le({patchProp:lu},Vd);let vr;function vu(){return vr||(vr=Sd(gu))}const jl=((...t)=>{const i=vu().createApp(...t),{mount:e}=i;return i.mount=s=>{const n=yu(s);if(!n)return;const r=i._component;!It(r)&&!r.render&&!r.template&&(r.template=n.innerHTML),n.nodeType===1&&(n.textContent="");const l=e(n,!1,bu(n));return n instanceof Element&&(n.removeAttribute("v-cloak"),n.setAttribute("data-v-app","")),l},i});function bu(t){if(t instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&t instanceof MathMLElement)return"mathml"}function yu(t){return Qt(t)?document.querySelector(t):t}function ku(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function xe(t){const i=ku();if(i)try{return i(t)}catch{try{const e=t.startsWith("node:")?t.slice(5):`node:${t}`;return i(e)}catch{}}}function xo(){var i;if(typeof window<"u"&&window.process)return window.process;const t=xe("process");return t&&t.versions?t:typeof process<"u"&&((i=process.versions)!=null&&i.node)?process:globalThis.process}function Hl(){var i,e;const t=xo();if(t&&((i=t.versions)!=null&&i.node))return!0;if(typeof window<"u"&&window.siyuan){const s=xe("child_process");if(s&&typeof s.spawn=="function")return!0}return!!(typeof process<"u"&&((e=process.versions)!=null&&e.node))}function _n(){const t=xo();if(t!=null&&t.platform)return t.platform;if(typeof process<"u"&&process.platform)return process.platform;const i=xe("os");if(i&&typeof i.platform=="function")return i.platform();if(typeof navigator<"u"){const e=navigator.userAgent.toLowerCase();if(e.includes("win"))return"win32";if(e.includes("mac"))return"darwin";if(e.includes("linux"))return"linux"}return"web"}function Ul(){var s,n;const t=xo(),i={...(t==null?void 0:t.env)||{}};if(_n()==="win32"){const r=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(s=t==null?void 0:t.env)!=null&&s.APPDATA?`${t.env.APPDATA}\\npm`:"",(n=t==null?void 0:t.env)!=null&&n.USERPROFILE?`${t.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(i).find(c=>c.toLowerCase()==="path")||"PATH",a=(i[l]||"").split(";").filter(Boolean);for(const c of r)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);i[l]=a.join(";")}return i}function Xs(t){var e,s,n;if(!t)return"";if(/^[a-zA-Z]:[/\\]/.test(t))return t.replace(/\\/g,"/");let i="";if(typeof window<"u"&&((n=(s=(e=window.siyuan)==null?void 0:e.config)==null?void 0:s.system)!=null&&n.dataDir)&&(i=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),i&&t.startsWith("/data/")){const r=t.slice(6);return`${i}/${r}`.replace(/\\/g,"/")}return t}function wu(){const t=xe("os"),i=xe("path");if(t&&typeof t.tmpdir=="function"){const e=t.tmpdir();return i&&typeof i.join=="function"?i.join(e,"siyuan-slidev-pro").replace(/\\/g,"/"):`${e}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class _o{constructor(i){wt(this,"runner");this.runner=i||_o.defaultRunner}static async defaultRunner(i,e){var s;try{let n=(s=xe("child_process"))==null?void 0:s.execFile;if(!n){const a=await import("node:child_process").catch(()=>({}));n=a==null?void 0:a.execFile}if(!n)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=_n()==="win32",o=Ul();return await new Promise(a=>{n(i,e,{timeout:5e3,shell:l,env:o},(c,d,h)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:h?String(h).trim():""})})})}catch(n){return{code:-1,stdout:"",stderr:String(n)}}}async detect(){const i=Hl(),e=_n();if(!i)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let s=!1,n,r=!1,l;try{const o=await this.runner("node",["-v"]);o.code===0&&o.stdout.startsWith("v")&&(s=!0,n=o.stdout)}catch{}if(s){try{const o=e==="win32"?"slidev.cmd":"slidev",a=await this.runner(o,["--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}if(!r)try{const o=e==="win32"?"npx.cmd":"npx",a=await this.runner(o,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}}return{hasNode:s,nodeVersion:n,hasSlidevCli:r,slidevVersion:l,platform:e,isDesktop:i}}}class xu{constructor(){wt(this,"iframe",null);wt(this,"isReady",!1);wt(this,"pageChangedHandlers",[]);wt(this,"readyHandlers",[]);wt(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(i,e){var n;if(!((n=this.iframe)!=null&&n.contentWindow))return;const s={target:"slidev",sender:"siyuan",type:i,...e};try{this.iframe.contentWindow.postMessage(s,"*")}catch(r){console.warn("[NativeSlidevBridge] postMessage error:",r)}}navigateToPage(i){this.postMessage("navigate",{no:i})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(i){return this.pageChangedHandlers.push(i),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(e=>e!==i)}}onReady(i){return this.readyHandlers.push(i),()=>{this.readyHandlers=this.readyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){const e=i.data;if(!(!e||e.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const s of this.readyHandlers)s()}if(e.type==="update-state"&&e.navState){const s=e.navState;this.currentState={no:s.no??this.currentState.no,clicks:s.clicks??this.currentState.clicks,total:s.total??this.currentState.total,hasNext:s.hasNext,hasPrev:s.hasPrev};for(const n of this.pageChangedHandlers)n(this.currentState.no,this.currentState.total||1,this.currentState)}else if(e.type==="navigate"&&typeof e.no=="number"){this.currentState.no=e.no;for(const s of this.pageChangedHandlers)s(e.no,this.currentState.total||1,this.currentState)}}}}class _u{constructor(i){wt(this,"childProcess",null);wt(this,"activePort",null);wt(this,"isRunning",!1);wt(this,"defaultPort");wt(this,"maxPortRetries");wt(this,"probeTimeoutMs");wt(this,"customSpawner");wt(this,"customPortChecker");this.defaultPort=(i==null?void 0:i.defaultPort)||3030,this.maxPortRetries=(i==null?void 0:i.maxPortRetries)||20,this.probeTimeoutMs=(i==null?void 0:i.probeTimeoutMs)||1e4,this.customSpawner=i==null?void 0:i.customSpawner,this.customPortChecker=i==null?void 0:i.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(i){if(this.customPortChecker)return this.customPortChecker(i);try{let e=xe("net");return e||(e=await import("node:net").catch(()=>({}))),e!=null&&e.createServer?await new Promise(s=>{const n=e.createServer();n.once("error",()=>s(!1)),n.once("listening",()=>{n.close(()=>s(!0))}),n.listen(i,"127.0.0.1")}):!0}catch{return!0}}async allocPort(i){const e=i||this.defaultPort;for(let s=0;s<this.maxPortRetries;s++){const n=e+s;if(await this.isPortAvailable(n))return n}return e}async pollServerReady(i,e=8e3,s=300){const n=Date.now();for(;Date.now()-n<e;){try{const r=new AbortController,l=setTimeout(()=>r.abort(),s),o=await fetch(i,{method:"HEAD",mode:"no-cors",signal:r.signal}).catch(()=>null);if(clearTimeout(l),o)return!0}catch{}await new Promise(r=>setTimeout(r,s))}return!1}async startServer(i,e){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const s=await this.allocPort(e);this.activePort=s;const r=_n()==="win32"?"npx.cmd":"npx",l=Xs(i),o=["@slidev/cli",l,"--port",String(s),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(r,o,{detached:!1});else{let h=(a=xe("child_process"))==null?void 0:a.spawn;if(!h){const y=await import("node:child_process").catch(()=>({}));h=y==null?void 0:y.spawn}if(!h)throw new Error("child_process spawn not available in current runtime");const g=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,u=Ul();this.childProcess=h(r,o,{cwd:g,detached:!1,shell:!0,env:{...u,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${s}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:s,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${s})`}):{success:!0,port:s,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:s,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var i;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),_n()==="win32"&&this.childProcess.pid&&!this.customSpawner){const s=(i=xe("child_process"))==null?void 0:i.exec;s?s(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:n})=>{var r;n(`taskkill /pid ${(r=this.childProcess)==null?void 0:r.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class So{constructor(){wt(this,"iframe",null);wt(this,"isReady",!1);wt(this,"pendingMessages",[]);wt(this,"slideChangedHandlers",[]);wt(this,"blockClickedHandlers",[]);wt(this,"openInEditorHandlers",[]);wt(this,"clientReadyHandlers",[]);wt(this,"openPeekDrawerHandlers",[]);wt(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(i,e){var n;const s={source:"siyuan-slidev-host",action:i,payload:e};if(!((n=this.iframe)!=null&&n.contentWindow)||!this.isReady){this.pendingMessages.push(s);return}try{this.iframe.contentWindow.postMessage(s,"*")}catch(r){console.warn("[WebSandboxBridge] postMessage error:",r)}}updateSlides(i,e,s,n){this.postMessage("UPDATE_SLIDES",{slides:i,config:e,fullMarkdown:s,customThemeCss:n})}navigatePage(i){this.postMessage("NAVIGATE_PAGE",{pageIndex:i})}highlightElement(i){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:i})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(i){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:i})}onSlideChanged(i){return this.slideChangedHandlers.push(i),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(e=>e!==i)}}onBlockClicked(i){return this.blockClickedHandlers.push(i),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(e=>e!==i)}}onOpenInEditor(i){return this.openInEditorHandlers.push(i),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(e=>e!==i)}}onOpenPeekDrawer(i){return this.openPeekDrawerHandlers.push(i),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(e=>e!==i)}}onRequestToggleFullscreen(i){return this.toggleFullscreenHandlers.push(i),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(e=>e!==i)}}onClientReady(i){return this.clientReadyHandlers.push(i),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){var s;const e=i.data;if(!(!e||e.source!=="siyuan-slidev-client"))switch(e.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const n=this.pendingMessages.shift();n&&((s=this.iframe)!=null&&s.contentWindow)&&this.iframe.contentWindow.postMessage(n,"*")}for(const n of this.clientReadyHandlers)n();break;case"SLIDE_CHANGED":if(e.payload.currentPage!==void 0)for(const n of this.slideChangedHandlers)n(e.payload.currentPage,e.payload.totalPages||1,e.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(e.payload.clickedBlockId)for(const n of this.blockClickedHandlers)n(e.payload.clickedBlockId,e.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(e.payload.blockId||e.payload.clickedBlockId){const n=e.payload.blockId||e.payload.clickedBlockId||"";for(const r of this.openInEditorHandlers)r(n,e.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(e.payload.peekType){const n=e.payload.blockId||e.payload.url||"",r={peekType:e.payload.peekType,target:n,title:e.payload.title};for(const l of this.openPeekDrawerHandlers)l(r)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const n of this.toggleFullscreenHandlers)n();break}}}const Wl={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},Su=`<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-3 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,Cu=`// Auto-generated by SiYuan Slidev Studio
export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,$u=`${Ns}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: 100% !important;
  height: 100% !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
}
.slide-list-media {
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: 100% !important;
  height: 100% !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
}
.slide-video-container {
  display: flex !important;
  justify-content: center !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function Iu(t){var n;const i=[],e=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let s;for(;(s=e.exec(t))!==null;){const r=(n=s[1])==null?void 0:n.trim();r&&!i.includes(r)&&i.push(r)}return i}class Au{constructor(i){wt(this,"workspacePath");wt(this,"slidesFileName");wt(this,"cliBridge",new to);const e=wu();!(i!=null&&i.workspacePath)||i.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=e:this.workspacePath=i.workspacePath,this.slidesFileName=(i==null?void 0:i.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(i="default"){const e={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return i&&i!=="default"&&(e.dependencies[`@slidev/theme-${i}`]="latest"),JSON.stringify(e,null,2)}buildSlidesMarkdown(i){return this.cliBridge.buildStandardSlidevMarkdown(i)}async scaffold(i,e){const s=this.buildSlidesMarkdown(i),n=this.generatePackageJson(i.config.theme),r=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,o=Xs(r),a=Xs(l),c=Iu(s);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const v of c){const k=Wl[v]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${v}
// #endregion snippet
`;d.set(v,k)}i.slides.some(v=>{var k;return((k=v.frontmatter)==null?void 0:k.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",Su),d.set("setup/root.ts",Cu),d.set("styles/index.css",$u);const g=xe("fs"),u=xe("path");let y=!1;const p=u!=null&&u.dirname?u.dirname(o):"",b=/^[a-zA-Z]:[/\\]/.test(o)||o.includes("siyuan-slidev-pro");if(g&&u&&b)try{g.existsSync(p)||g.mkdirSync(p,{recursive:!0}),g.writeFileSync(a,n,"utf-8"),g.writeFileSync(o,s,"utf-8");for(const[v,k]of d.entries()){const S=u.join(p,v),A=u.dirname(S);g.existsSync(A)||g.mkdirSync(A,{recursive:!0}),g.existsSync(S)||g.writeFileSync(S,k,"utf-8")}y=!0}catch{}if(!y&&e)try{const v=typeof Blob<"u"?new Blob([s],{type:"text/markdown;charset=utf-8"}):Buffer.from(s,"utf-8"),k=typeof Blob<"u"?new Blob([n],{type:"application/json;charset=utf-8"}):Buffer.from(n,"utf-8");await e(l,!1,k),await e(r,!1,v);for(const[S,A]of d.entries()){const x=`${this.workspacePath}/${S}`,_=typeof Blob<"u"?new Blob([A],{type:"text/plain;charset=utf-8"}):Buffer.from(A,"utf-8");await e(x,!1,_).catch(()=>{})}return{success:!0,slidesPath:r,physicalSlidesPath:o,packageJsonPath:l}}catch(v){return{success:!1,slidesPath:r,physicalSlidesPath:o,packageJsonPath:l,error:String(v)}}return{success:!0,slidesPath:r,physicalSlidesPath:o,packageJsonPath:l}}}class Tu{constructor(){wt(this,"mode","web-sandbox");wt(this,"webBridge");wt(this,"cliBridge");wt(this,"nativeBridge");wt(this,"processManager");wt(this,"scaffolder");wt(this,"envDetector");this.webBridge=new So,this.cliBridge=new to,this.nativeBridge=new xu,this.processManager=new _u,this.scaffolder=new Au,this.envDetector=new _o}getMode(){return this.mode}setMode(i){this.mode=i}async startProMode(i,e){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const n=await this.scaffolder.scaffold(i,e);if(!n.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${n.error}`};const r=n.physicalSlidesPath||n.slidesPath,l=await this.processManager.startServer(r);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const Eu={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Mu={key:0},Bu={key:1},Du={key:2},Lu={key:3},Ou={key:4},Pu={key:5},Ru={key:6},zu={key:7},Nu={key:8},Fu={key:9},ju={key:10},Hu={key:11},Uu={key:12},Wu={key:13},Vu={key:14},Ku={key:15},qu={key:16},Gu={key:17},Zu={key:18},Yu={key:19},Ju={key:20},Xu={key:21},Qu={key:22},tf={key:23},ef={key:24},nf={key:25},sf={key:26},of={key:27},rf={key:28},lf={key:29},af={key:30},cf={key:31},df={key:32},uf={key:33},ff={key:34},pf={key:35},hf={key:36},mf={key:37},gf={key:38},vf={key:39},bf={key:40},yf={key:41},kf={key:42},wf={key:43},xf={key:44},_f={key:45},Sf={key:46},Cf={key:47},$f={key:48},If={key:49},Af={key:50},Tf={key:51},Ef={key:52},Mf=ye({__name:"SlidevIcon",props:{name:{}},setup(t){return(i,e)=>(et(),nt("svg",Eu,[t.name==="fullscreen"||t.name==="maximize"?(et(),nt("g",Mu,[...e[0]||(e[0]=[m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("polyline",{points:"9 21 3 21 3 15"},null,-1),m("polyline",{points:"21 15 21 21 15 21"},null,-1),m("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):t.name==="minimize"?(et(),nt("g",Bu,[...e[1]||(e[1]=[m("polyline",{points:"4 14 10 14 10 20"},null,-1),m("polyline",{points:"20 10 14 10 14 4"},null,-1),m("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),m("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):t.name==="close"||t.name==="x"?(et(),nt("g",Du,[...e[2]||(e[2]=[m("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),m("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):t.name==="edit"?(et(),nt("g",Lu,[...e[3]||(e[3]=[m("path",{d:"M12 20h9"},null,-1),m("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):t.name==="eye"?(et(),nt("g",Ou,[...e[4]||(e[4]=[m("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),m("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):t.name==="external-link"||t.name==="window"?(et(),nt("g",Pu,[...e[5]||(e[5]=[m("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):t.name==="arrow-left"?(et(),nt("g",Ru,[...e[6]||(e[6]=[m("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),m("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):t.name==="arrow-right"?(et(),nt("g",zu,[...e[7]||(e[7]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):t.name==="plus"?(et(),nt("g",Nu,[...e[8]||(e[8]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="minus"?(et(),nt("g",Fu,[...e[9]||(e[9]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="split-preview"?(et(),nt("g",ju,[...e[10]||(e[10]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),m("path",{d:"M12 3v18"},null,-1)])])):t.name==="import"?(et(),nt("g",Hu,[...e[11]||(e[11]=[m("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),m("polyline",{points:"7 9 12 14 17 9"},null,-1),m("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):t.name==="presenter"?(et(),nt("g",Uu,[...e[12]||(e[12]=[m("path",{d:"M2 3h20"},null,-1),m("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),m("path",{d:"m7 21 5-5 5 5"},null,-1)])])):t.name==="video"?(et(),nt("g",Wu,[...e[13]||(e[13]=[m("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),m("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):t.name==="step"?(et(),nt("g",Vu,[...e[14]||(e[14]=[m("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):t.name==="motion"?(et(),nt("g",Ku,[...e[15]||(e[15]=[m("path",{d:"M5 12h14"},null,-1),m("path",{d:"m12 5 7 7-7 7"},null,-1),m("path",{d:"M5 6h4"},null,-1),m("path",{d:"M5 18h4"},null,-1)])])):t.name==="columns"?(et(),nt("g",qu,[...e[16]||(e[16]=[m("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),m("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):t.name==="code"?(et(),nt("g",Gu,[...e[17]||(e[17]=[m("polyline",{points:"16 18 22 12 16 6"},null,-1),m("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):t.name==="insert-above"?(et(),nt("g",Zu,[...e[18]||(e[18]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),m("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),m("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):t.name==="insert-below"?(et(),nt("g",Yu,[...e[19]||(e[19]=[m("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),m("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="broom"?(et(),nt("g",Ju,[...e[20]||(e[20]=[m("path",{d:"m18 15-6-6"},null,-1),m("path",{d:"M4 20h16"},null,-1),m("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):t.name==="trash"?(et(),nt("g",Xu,[...e[21]||(e[21]=[m("path",{d:"M3 6h18"},null,-1),m("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),m("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):t.name==="ai"||t.name==="sparkles"?(et(),nt("g",Qu,[...e[22]||(e[22]=[m("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):t.name==="palette"?(et(),nt("g",tf,[...e[23]||(e[23]=[$e('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-b8552023></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-b8552023></path>',5)])])):t.name==="ratio"?(et(),nt("g",ef,[...e[24]||(e[24]=[m("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):t.name==="transition"?(et(),nt("g",nf,[...e[25]||(e[25]=[m("path",{d:"M8 3 4 7l4 4"},null,-1),m("path",{d:"M4 7h16"},null,-1),m("path",{d:"m16 21 4-4-4-4"},null,-1),m("path",{d:"M20 17H4"},null,-1)])])):t.name==="export-html"?(et(),nt("g",sf,[...e[26]||(e[26]=[m("polyline",{points:"16 16 12 12 8 16"},null,-1),m("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),m("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):t.name==="export-pdf"?(et(),nt("g",of,[...e[27]||(e[27]=[m("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),m("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),m("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):t.name==="pin"?(et(),nt("g",rf,[...e[28]||(e[28]=[m("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),m("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):t.name==="refresh"?(et(),nt("g",lf,[...e[29]||(e[29]=[m("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),m("path",{d:"M21 3v5h-5"},null,-1),m("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),m("path",{d:"M8 16H3v5"},null,-1)])])):t.name==="outline"?(et(),nt("g",af,[...e[30]||(e[30]=[m("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),m("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),m("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):t.name==="chevron-left"?(et(),nt("g",cf,[...e[31]||(e[31]=[m("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):t.name==="chevron-right"?(et(),nt("g",df,[...e[32]||(e[32]=[m("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):t.name==="copy"?(et(),nt("g",uf,[...e[33]||(e[33]=[m("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),m("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):t.name==="image"?(et(),nt("g",ff,[...e[34]||(e[34]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),m("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),m("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):t.name==="search"?(et(),nt("g",pf,[...e[35]||(e[35]=[m("circle",{cx:"11",cy:"11",r:"7"},null,-1),m("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):t.name==="settings"||t.name==="gear"?(et(),nt("g",hf,[...e[36]||(e[36]=[m("circle",{cx:"12",cy:"12",r:"3"},null,-1),m("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):t.name==="notes"||t.name==="file-text"?(et(),nt("g",mf,[...e[37]||(e[37]=[$e('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-b8552023></path><polyline points="14 2 14 8 20 8" data-v-b8552023></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-b8552023></line><line x1="16" y1="17" x2="8" y2="17" data-v-b8552023></line><line x1="10" y1="9" x2="8" y2="9" data-v-b8552023></line>',5)])])):t.name==="focus"||t.name==="target"?(et(),nt("g",gf,[...e[38]||(e[38]=[m("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),m("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),m("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):t.name==="layout-cover"||t.name==="cover"?(et(),nt("g",vf,[...e[39]||(e[39]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),m("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),m("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):t.name==="layout-default"||t.name==="default"?(et(),nt("g",bf,[...e[40]||(e[40]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-b8552023></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-b8552023></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-b8552023></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-b8552023></line>',5)])])):t.name==="layout-two-cols"||t.name==="two-cols"?(et(),nt("g",yf,[...e[41]||(e[41]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-b8552023></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-b8552023></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-b8552023></line><line x1="5" y1="15" x2="8" y2="15" data-v-b8552023></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-b8552023></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-b8552023></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-b8552023></line>',8)])])):t.name==="layout-two-cols-header"||t.name==="two-cols-header"?(et(),nt("g",kf,[...e[42]||(e[42]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b8552023></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-b8552023></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-b8552023></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-b8552023></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-b8552023></line>',7)])])):t.name==="layout-three-cols-header"||t.name==="three-cols-header"?(et(),nt("g",wf,[...e[43]||(e[43]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b8552023></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-b8552023></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-b8552023></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-b8552023></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-b8552023></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-b8552023></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-b8552023></line>',10)])])):t.name==="layout-image-right"||t.name==="image-right"?(et(),nt("g",xf,[...e[44]||(e[44]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b8552023></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-b8552023></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-b8552023></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-b8552023></line><circle cx="15.5" cy="8.5" r="1.2" data-v-b8552023></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-b8552023></polyline>',7)])])):t.name==="layout-image-left"||t.name==="image-left"?(et(),nt("g",_f,[...e[45]||(e[45]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b8552023></line><circle cx="6" cy="8.5" r="1.2" data-v-b8552023></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-b8552023></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-b8552023></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-b8552023></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-b8552023></line>',7)])])):t.name==="layout-center"||t.name==="center"?(et(),nt("g",Sf,[...e[46]||(e[46]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="layout-fact"||t.name==="fact"?(et(),nt("g",Cf,[...e[47]||(e[47]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><circle cx="8" cy="9" r="1.5" data-v-b8552023></circle><line x1="14" y1="8" x2="9" y2="14" data-v-b8552023></line><circle cx="15" cy="13" r="1.5" data-v-b8552023></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-b8552023></line>',5)])])):t.name==="layout-intro"||t.name==="intro"?(et(),nt("g",$f,[...e[48]||(e[48]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><circle cx="7.5" cy="9.5" r="2" data-v-b8552023></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-b8552023></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-b8552023></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-b8552023></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-b8552023></line>',6)])])):t.name==="layout-quote"||t.name==="quote"?(et(),nt("g",If,[...e[49]||(e[49]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-b8552023></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-b8552023></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-b8552023></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-b8552023></line>',5)])])):t.name==="desktop"||t.name==="monitor"?(et(),nt("g",Af,[...e[50]||(e[50]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):t.name==="mobile"||t.name==="smartphone"||t.name==="phone"?(et(),nt("g",Tf,[...e[51]||(e[51]=[m("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),m("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):(et(),nt("g",Ef,[...e[52]||(e[52]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Oe=(t,i)=>{const e=t.__vccOpts||t;for(const[s,n]of i)e[s]=n;return e},kt=Oe(Mf,[["__scopeId","data-v-b8552023"]]);function se(t,i){var n;if(typeof document>"u"||!t)return;const e=(n=globalThis.CSS)!=null&&n.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),s=document.querySelectorAll(`[data-node-id="${e}"]`);!s||s.length===0||s.forEach(r=>{for(const[l,o]of Object.entries(i))o!=null&&o!==""?r.setAttribute(l,String(o)):r.removeAttribute(l)})}function Bf(t){if(typeof document>"u")return;const i=`.protyle-wysiwyg [${ft}], .protyle-wysiwyg [${qt}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,e=document.querySelectorAll(i);!e||e.length===0||e.forEach(s=>{const n=s.getAttribute("data-node-id");if(!n){s.removeAttribute(ft),s.removeAttribute("custom-slidev-layout"),s.removeAttribute(qt),s.removeAttribute("custom-slidev-role");return}const r=t.get(n),l=(r==null?void 0:r[ft])||(r==null?void 0:r["custom-slidev-layout"])||"",o=s.getAttribute(ft)||s.getAttribute("custom-slidev-layout");o&&o!==l&&(l?s.setAttribute(ft,l):(s.removeAttribute(ft),s.removeAttribute("custom-slidev-layout")));const a=(r==null?void 0:r[qt])||(r==null?void 0:r["custom-slidev-role"])||"",c=s.getAttribute(qt)||s.getAttribute("custom-slidev-role");c&&c!==a&&(a?s.setAttribute(qt,a):(s.removeAttribute(qt),s.removeAttribute("custom-slidev-role")))})}const Df={class:"spm-layout-picker"},Lf={class:"spm-layout-picker__grid"},Of=["title","onClick"],Pf={class:"spm-layout-icon"},Rf={class:"spm-layout-label"},zf=ye({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,s=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"two-cols-header",label:"表头双栏",desc:"顶部通栏标题，下方左右双栏"},{name:"three-cols-header",label:"表头三栏",desc:"顶部通栏标题，下方等宽三栏"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function n(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(et(),nt("div",Df,[l[0]||(l[0]=m("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),m("div",Lf,[(et(),nt(Gt,null,ke(s,o=>m("div",{key:o.name,class:Et(["spm-layout-item",{active:t.modelValue===o.name}]),title:o.desc,onClick:a=>n(o.name)},[m("div",Pf,[pt(kt,{name:"layout-"+o.name},null,8,["name"])]),m("span",Rf,St(o.label),1)],10,Of)),64))])]))}}),Vl=Oe(zf,[["__scopeId","data-v-c57441d5"]]),Nf={key:0,class:"spm-transition-selector__header"},Ff={class:"spm-transition-list"},jf=["onClick"],Hf={class:"spm-transition-meta"},Uf={class:"spm-transition-label"},Wf={class:"spm-transition-name"},Vf={class:"spm-transition-preview-box"},Kf=ye({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,s=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function n(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(et(),nt("div",{class:Et(["spm-transition-selector",{"spm-transition-selector--no-header":t.hideHeader}])},[t.hideHeader?Ft("",!0):(et(),nt("div",Nf,St(t.title||"转场动效"),1)),m("div",Ff,[(et(),nt(Gt,null,ke(s,o=>m("div",{key:o.name,class:Et(["spm-transition-item",{active:t.modelValue===o.name}]),onClick:a=>n(o.name)},[m("div",Hf,[m("span",Uf,St(o.label),1),m("span",Wf,"("+St(o.name)+")",1)]),m("div",Vf,[m("div",{class:Et(["spm-anim-cube","anim-"+o.name])},null,2)])],10,jf)),64))])],2))}}),Co=Oe(Kf,[["__scopeId","data-v-b0aa61ff"]]),qf={class:"spm-divider-popover"},Gf={class:"spm-divider-popover__title"},Zf={class:"spm-form-item"},Yf={class:"spm-popover-footer"},Jf={class:"spm-save-hint"},Xf=ye({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(t,{emit:i}){var g,u,y;const e=t,s=i,n=ht(((g=e.initialAttrs)==null?void 0:g[ft])||"default"),r=ht(((u=e.initialAttrs)==null?void 0:u[Xt])||"slide-left"),l=ht(((y=e.initialAttrs)==null?void 0:y[Ut])||""),o=ht("");Ti(()=>e.initialAttrs,p=>{n.value=(p==null?void 0:p[ft])||"default",r.value=(p==null?void 0:p[Xt])||"slide-left",l.value=(p==null?void 0:p[Ut])||""},{deep:!0});async function a(p,b){if(e.blockId){o.value="正在同步...",Ht.setBlockAttrOverride(e.blockId,{[p]:b}),se(e.blockId,{[p]:b});try{await zt(e.blockId,{[p]:b}),o.value="已同步至块属性",s("updated",{[p]:b}),setTimeout(()=>{o.value=""},1500)}catch{o.value="同步失败"}}}function c(p){a(ft,p)}function d(p){a(Xt,p)}function h(){a(Ut,l.value.trim())}return(p,b)=>(et(),nt("div",qf,[m("div",Gf,[b[4]||(b[4]=m("span",null,"幻灯片页面设置",-1)),m("button",{class:"spm-close-btn",onClick:b[0]||(b[0]=v=>s("close"))},"✕")]),pt(Vl,{modelValue:n.value,"onUpdate:modelValue":b[1]||(b[1]=v=>n.value=v),onChange:c},null,8,["modelValue"]),pt(Co,{modelValue:r.value,"onUpdate:modelValue":b[2]||(b[2]=v=>r.value=v),onChange:d},null,8,["modelValue"]),m("div",Zf,[b[5]||(b[5]=m("label",{class:"spm-form-label"},"页面背景",-1)),Ie(m("input",{"onUpdate:modelValue":b[3]||(b[3]=v=>l.value=v),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:h},null,544),[[is,l.value]])]),m("div",Yf,[m("span",Jf,St(o.value),1)])]))}}),Qf=Oe(Xf,[["__scopeId","data-v-e4871368"]]),tp={class:"spm-slide-inspector"},ep={class:"spm-inspector-header"},ip={class:"spm-inspector-list"},np=["onClick"],sp={class:"spm-card-top"},op={class:"spm-card-badge"},rp={class:"spm-card-layout"},lp=["onClick"],ap={class:"spm-card-preview"},cp={key:0,class:"spm-card-notes",title:"演讲备忘录"},dp={class:"spm-inspector-modal-content"},up=ye({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(t,{emit:i}){const e=i,s=ht(null);function n(c){s.value=c}function r(c){const d={};return c.frontmatter.layout&&(d[ft]=c.frontmatter.layout),c.frontmatter.transition&&(d[Xt]=c.frontmatter.transition),c.frontmatter.background&&(d[Ut]=c.frontmatter.background),c.notes&&(d[zi]=c.notes),d}function l(c){s.value&&(c[ft]&&(s.value.frontmatter.layout=c[ft]),c[Xt]&&(s.value.frontmatter.transition=c[Xt]),c[Ut]&&(s.value.frontmatter.background=c[Ut]),c[zi]&&(s.value.notes=c[zi]),e("refresh"))}function o(c){e("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const d=c.blocks[0],h=d.content||d.rawMarkdown||"";return h.slice(0,40)+(h.length>40?"...":"")}return(c,d)=>(et(),nt("div",tp,[m("div",ep,[m("span",null,"幻灯片大纲 ("+St(t.slides.length)+" 页)",1)]),m("div",ip,[(et(!0),nt(Gt,null,ke(t.slides,h=>(et(),nt("div",{key:h.pageIndex,class:Et(["spm-card",{active:t.currentActivePage===h.pageIndex}]),onClick:g=>o(h.pageIndex)},[m("div",sp,[m("span",op,"P"+St(h.pageIndex),1),m("span",rp,St(h.frontmatter.layout||"default"),1),m("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Te(g=>n(h),["stop"])},[pt(kt,{name:"settings"})],8,lp)]),m("div",ap,St(a(h)),1),h.notes?(et(),nt("div",cp,[pt(kt,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),m("span",null,St(h.notes),1)])):Ft("",!0)],10,np))),128))]),s.value?(et(),nt("div",{key:0,class:"spm-inspector-modal-mask",onClick:d[1]||(d[1]=Te(h=>s.value=null,["self"]))},[m("div",dp,[pt(Qf,{"block-id":s.value.startBlockId,"initial-attrs":r(s.value),onClose:d[0]||(d[0]=h=>s.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Ft("",!0)]))}}),fp=Oe(up,[["__scopeId","data-v-68b25edd"]]),pp={class:"spm-immersion-header"},hp={class:"spm-immersion-header__left"},mp={class:"spm-immersion-title"},gp={class:"spm-immersion-header__center"},vp={class:"spm-immersion-header__actions"},bp=["aria-label"],yp={class:"spm-immersion-body"},kp=ye({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(t,{emit:i}){const e=t,s=i;function n(){s("update:visible",!1),s("close")}function r(){e.closeOnClickMask&&n()}function l(){s("update:isMaximized",!e.isMaximized),s("toggle-maximize")}function o(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),n())}return(a,c)=>Ie((et(),nt("div",{class:Et(["spm-immersion-container",{"is-maximized":t.isMaximized}]),onKeydown:Te(o,["stop"])},[m("div",{class:"spm-immersion-mask",onClick:r}),m("div",{class:Et(["spm-immersion-drawer",{"is-maximized":t.isMaximized}])},[m("div",pp,[m("div",hp,[Pn(a.$slots,"header-left",{},()=>[m("span",mp,St(t.title),1)])]),m("div",gp,[Pn(a.$slots,"header-center",{},void 0)]),m("div",vp,[Pn(a.$slots,"header-actions",{},void 0),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":t.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[pt(kt,{name:t.isMaximized?"minimize":"maximize"},null,8,["name"])],8,bp),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:n},[pt(kt,{name:"close"})])])]),m("div",yp,[Pn(a.$slots,"default",{},void 0)])],2)],34)),[[Nl,t.visible]])}}),wp=Oe(kp,[["__scopeId","data-v-3f1665db"]]),xp="slidev-config.json",Yi={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806"},$i=ds({...Yi});function _p(t){if(!t||typeof t!="object")return{...Yi};const i=t;return{enableWebServeJump:!!i.enableWebServeJump,webServeUrl:typeof i.webServeUrl=="string"&&i.webServeUrl.trim()?i.webServeUrl.trim():Yi.webServeUrl}}function Vi(t){if(!t||typeof t!="object")return{...$i};const i=t;return i.enableWebServeJump!==void 0&&($i.enableWebServeJump=!!i.enableWebServeJump),i.webServeUrl!==void 0&&($i.webServeUrl=String(i.webServeUrl)),{...$i}}function $o(){return{...$i}}function Kl(t,i,e){const s=(t||Yi.webServeUrl).trim(),n=s.startsWith("http://")||s.startsWith("https://")?s:`http://${s}`,r=(e==null?void 0:e.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(n);let o=l.pathname.replace(/\/+$/,"");return o.endsWith("/stage/build/desktop")||(o=o?`${o}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${o}/`,l.searchParams.set("id",i),e!=null&&e.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",r),l.toString()}catch{const l=e!=null&&e.focus?"&focus=1":"";return`${n.replace(/\/+$/,"")}/stage/build/desktop/?id=${i}${l}&r=${r}`}}const Sp={class:"spm-protyle-drawer"},Cp={class:"spm-protyle-drawer__subbar"},$p={class:"spm-protyle-drawer__nav"},Ip=["title"],Ap={class:"spm-protyle-drawer__actions"},Tp=["aria-label"],Ep=["aria-label"],Mp=ye({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(t,{emit:i}){const e=i,s=t,n=ht(s.blockId),r=ht(s.title||""),l=ht(!1),o=ht(!0),a=ht(!1),c=ht(""),d=$i,h=ht([]),g=ht(null);let u=null;Ti(()=>s.blockId,C=>{C&&C!==n.value&&(n.value=C,r.value=s.title||"",h.value=[],p(C))}),$n(()=>{n.value&&p(n.value)}),go(()=>{b()});async function y(C){try{const B=await gn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${C}' LIMIT 1`);if(Array.isArray(B)&&B.length>0){const M=B[0];c.value=M.root_id||"";const R=M.id===M.root_id||M.type==="d";a.value=R,o.value=!R,!r.value&&M.content&&(r.value=M.content.trim().slice(0,30));return}}catch(B){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",B)}a.value=!1,o.value=!0}async function p(C,B){if(!g.value||!C)return;b(),await y(C),typeof B=="boolean"&&(o.value=!a.value&&B);let M,R;o.value&&!a.value?(M=["cb-get-all","cb-get-hl","cb-get-focus"],R={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(M=["cb-get-context","cb-get-hl"],R={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{u=new vt.Protyle(s.plugin.app,g.value,{blockId:C,action:M,render:R}),!l.value&&u&&typeof u.disable=="function"&&u.disable()}catch(J){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",J)}}function b(){if(u){try{typeof u.destroy=="function"&&u.destroy()}catch(C){console.warn("[ProtylePeekDrawer] Error destroying protyle:",C)}u=null}g.value&&(g.value.innerHTML="")}function v(){a.value||(o.value=!o.value,p(n.value,o.value))}function k(){l.value=!l.value,u&&(l.value?(typeof u.enable=="function"&&u.enable(),typeof u.focus=="function"&&u.focus()):typeof u.disable=="function"&&u.disable())}function S(){if(n.value)try{vt.openWindow({doc:{id:n.value},alwaysOnTop:!0})}catch(C){console.warn("[ProtylePeekDrawer] openWindow failed:",C)}}function A(){var M;if(!n.value)return;const C=$o(),B=Kl(C.webServeUrl,n.value,{focus:!a.value});if(typeof window<"u"){const R=xe("electron");(M=R==null?void 0:R.shell)!=null&&M.openExternal?R.shell.openExternal(B).catch(()=>{window.open(B,"_blank")}):window.open(B,"_blank")}e("external-jump",B)}function x(){if(h.value.length>0){const C=h.value.pop();C&&(n.value=C.blockId,r.value=C.title,o.value=C.isFocusMode,a.value=C.isDoc,p(C.blockId,C.isFocusMode))}}function _(C){const B=C.target;if(!B)return;const M=B.closest('[data-type="block-ref"]');if(M){const J=M.getAttribute("data-id");if(J&&J!==n.value){C.preventDefault(),C.stopPropagation(),h.value.push({blockId:n.value,title:r.value||n.value,isFocusMode:o.value,isDoc:a.value}),n.value=J,r.value=M.innerText.trim()||J,p(J);return}}const R=B.closest("a");if(R&&R.href&&R.href.startsWith("siyuan://blocks/")){C.preventDefault(),C.stopPropagation();const J=R.href.replace("siyuan://blocks/","").split("?")[0];J&&J!==n.value&&(h.value.push({blockId:n.value,title:r.value||n.value,isFocusMode:o.value,isDoc:a.value}),n.value=J,r.value=R.innerText.trim()||J,p(J))}}return(C,B)=>(et(),nt("div",Sp,[m("div",Cp,[m("div",$p,[h.value.length>0?(et(),nt("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:x},[pt(kt,{name:"arrow-left"}),B[0]||(B[0]=m("span",null,"返回",-1))])):Ft("",!0),m("span",{class:Et(["spm-protyle-badge",{"is-focus":o.value&&!a.value}])},St(o.value&&!a.value?"思源块聚焦":"思源文档速览"),3),m("span",{class:"spm-protyle-id",title:r.value||n.value},St(r.value||n.value),9,Ip)]),m("div",Ap,[a.value?Ft("",!0):(et(),nt("button",{key:0,class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":o.value}]),"aria-label":o.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:v},[pt(kt,{name:o.value?"focus":"file-text"},null,8,["name"]),m("span",null,St(o.value?"块聚焦":"展开全文"),1)],10,Tp)),m("button",{class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:k},[pt(kt,{name:l.value?"edit":"eye"},null,8,["name"]),m("span",null,St(l.value?"编辑中":"只读"),1)],10,Ep),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:S},[pt(kt,{name:"window"}),B[1]||(B[1]=m("span",null,"独立窗口",-1))]),Ci(d).enableWebServeJump?(et(),nt("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:A},[pt(kt,{name:"external-link"}),B[2]||(B[2]=m("span",null,"外跳",-1))])):Ft("",!0)])]),m("div",{ref_key:"mountEl",ref:g,class:Et(["spm-protyle-mount",{"is-focus-mode":o.value&&!a.value}]),onClick:_},null,2)]))}}),Bp=Oe(Mp,[["__scopeId","data-v-7e586ef3"]]),Dp={class:"spm-webview-drawer"},Lp={class:"spm-webview-toolbar"},Op={class:"spm-webview-toolbar__nav"},Pp=["disabled"],Rp=["disabled"],zp=["aria-label"],Np={class:"spm-webview-toolbar__address"},Fp=["aria-label"],jp={class:"spm-webview-toolbar__actions"},Hp=["aria-label"],Up={class:"spm-zoom-controller"},Wp=["disabled"],Vp=["disabled"],Kp={key:1,class:"spm-webview-fallback"},qp=["src"],br="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",ql="siyuan-slidev-peek-view-mode";let Gl="desktop";function Gp(){if(typeof window<"u"&&window.localStorage)try{const t=window.localStorage.getItem(ql);if(t==="mobile"||t==="desktop")return t}catch{}return Gl}function Zp(t){if(Gl=t,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(ql,t)}catch{}}const Yp=ye({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(t,{emit:i}){const e=i,s=t,n=ht(Hl()),r=ht(s.url),l=ht(s.url),o=ht(!1),a=ht(!1),c=ht(!1),d=ht(1),h=ht(!1),g=ht(Gp());let u=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const y=$t(()=>g.value==="mobile"?br:u||void 0),p=ht(null),b=ht(null);let v=null,k=null,S=null;Ti(()=>s.url,X=>{X&&X!==r.value&&(r.value=X,l.value=X,g.value==="mobile"&&B(!1),p.value&&typeof p.value.loadURL=="function"&&p.value.loadURL(X))}),Ti(()=>s.visible,X=>{if(X)W(),g.value==="mobile"&&B(!1);else if(p.value)try{typeof p.value.stop=="function"&&p.value.stop()}catch{}}),$n(()=>{A(),b.value&&typeof ResizeObserver<"u"&&(v=new ResizeObserver(()=>{const X=p.value;if(X&&typeof X.invalidate=="function")try{X.invalidate()}catch{}}),v.observe(b.value)),k=X=>{var gt;const mt=X.message||((gt=X.error)==null?void 0:gt.message);if(typeof mt=="string"&&mt.includes("Invalid guestInstanceId"))return X.preventDefault(),X.stopImmediatePropagation(),!0},window.addEventListener("error",k,!0),S=X=>{const mt=X.reason,gt=typeof mt=="string"?mt:mt==null?void 0:mt.message;typeof gt=="string"&&gt.includes("Invalid guestInstanceId")&&X.preventDefault()},window.addEventListener("unhandledrejection",S)}),go(()=>{if(x(),v&&(v.disconnect(),v=null),k&&(window.removeEventListener("error",k,!0),k=null),S&&(window.removeEventListener("unhandledrejection",S),S=null),p.value)try{typeof p.value.stop=="function"&&p.value.stop()}catch{}});function A(){const X=p.value;X&&(X.addEventListener("dom-ready",_),X.addEventListener("did-start-loading",M),X.addEventListener("did-stop-loading",R),X.addEventListener("did-navigate",J),X.addEventListener("did-navigate-in-page",T),X.addEventListener("new-window",L))}function x(){const X=p.value;if(X)try{X.removeEventListener("dom-ready",_),X.removeEventListener("did-start-loading",M),X.removeEventListener("did-stop-loading",R),X.removeEventListener("did-navigate",J),X.removeEventListener("did-navigate-in-page",T),X.removeEventListener("new-window",L)}catch{}}function _(){const X=p.value;if(X&&typeof X.getUserAgent=="function"&&!u)try{const mt=X.getUserAgent();mt&&!mt.includes("iPhone")&&(u=mt)}catch{}g.value==="mobile"&&B(!1),W(),w()}function C(){const X=g.value==="mobile"?"desktop":"mobile";g.value=X,Zp(X),B(!0)}function B(X=!1){const mt=p.value;if(!mt)return;const gt=g.value==="mobile"?br:u;if(typeof mt.setUserAgent=="function"&&gt)try{mt.setUserAgent(gt)}catch(Z){console.warn("[WebviewPeekDrawer] setUserAgent error:",Z)}if(X&&typeof mt.reload=="function")try{mt.reload()}catch(Z){console.warn("[WebviewPeekDrawer] reload error:",Z)}}function M(){o.value=!0}function R(){if(o.value=!1,w(),p.value&&typeof p.value.getURL=="function"){const X=p.value.getURL();X&&X!=="about:blank"&&(r.value=X,l.value=X)}}function J(X){X!=null&&X.url&&(r.value=X.url,l.value=X.url),w()}function T(X){X!=null&&X.url&&(r.value=X.url,l.value=X.url),w()}function L(X){X&&X.url&&(X.preventDefault(),p.value&&typeof p.value.loadURL=="function"&&p.value.loadURL(X.url))}function w(){const X=p.value;X&&(typeof X.canGoBack=="function"&&(a.value=X.canGoBack()),typeof X.canGoForward=="function"&&(c.value=X.canGoForward()))}function j(){p.value&&typeof p.value.goBack=="function"&&p.value.goBack()}function Q(){p.value&&typeof p.value.goForward=="function"&&p.value.goForward()}function z(){p.value&&typeof p.value.reload=="function"&&p.value.reload()}function at(){let X=l.value.trim();X&&(/^https?:\/\//i.test(X)||(X=`https://${X}`),r.value=X,l.value=X,p.value&&typeof p.value.loadURL=="function"&&p.value.loadURL(X))}function W(){const X=p.value;if(X&&typeof X.setZoomFactor=="function")try{X.setZoomFactor(d.value)}catch(mt){console.warn("[WebviewPeekDrawer] setZoomFactor error:",mt)}}function Y(){d.value=Math.min(2.5,Math.round((d.value+.1)*10)/10),W()}function V(){d.value=Math.max(.5,Math.round((d.value-.1)*10)/10),W()}function N(){d.value=1,W()}function ct(X){X.preventDefault(),X.deltaY<0?Y():X.deltaY>0&&V()}async function rt(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(r.value),h.value=!0,setTimeout(()=>{h.value=!1},2e3)}catch(X){console.warn("Copy url failed:",X)}}function st(){var mt;const X=r.value;if(typeof window<"u"){const gt=xe("electron");(mt=gt==null?void 0:gt.shell)!=null&&mt.openExternal?gt.shell.openExternal(X).catch(()=>{window.open(X,"_blank")}):window.open(X,"_blank")}e("external-jump",X)}return(X,mt)=>{const gt=td("webview");return et(),nt("div",Dp,[m("div",Lp,[m("div",Op,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!a.value,"aria-label":"后退",onClick:j},[pt(kt,{name:"arrow-left"})],8,Pp),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"前进",onClick:Q},[pt(kt,{name:"arrow-right"})],8,Rp),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":o.value?"正在加载...":"刷新页面",onClick:z},[pt(kt,{name:"refresh"})],8,zp)]),m("div",Np,[Ie(m("input",{"onUpdate:modelValue":mt[0]||(mt[0]=Z=>l.value=Z),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:mu(at,["enter"])},null,544),[[is,l.value]]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":h.value?"已复制地址！":"复制网址",onClick:rt},[pt(kt,{name:"copy"})],8,Fp)]),m("div",jp,[m("button",{class:Et(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":g.value==="mobile"}]),"aria-label":g.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:C},[pt(kt,{name:g.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Hp),m("div",Up,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:d.value<=.5,onClick:V},[pt(kt,{name:"minus"})],8,Wp),m("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:N},St(Math.round(d.value*100))+"% ",1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:d.value>=2.5,onClick:Y},[pt(kt,{name:"plus"})],8,Vp)]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:st},[pt(kt,{name:"external-link"}),mt[1]||(mt[1]=m("span",null,"外跳",-1))])])]),m("div",{ref_key:"containerEl",ref:b,class:Et(["spm-webview-body",{"is-mobile":g.value==="mobile"}]),onWheel:Te(ct,["ctrl"])},[m("div",{class:Et(["spm-webview-viewport",{"is-mobile":g.value==="mobile"}])},[n.value?(et(),Ee(gt,{key:0,ref_key:"webviewRef",ref:p,class:"spm-webview-frame",src:r.value,useragent:y.value,allowpopups:"true",partition:"persist:slidev-peek",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(et(),nt("div",Kp,[m("iframe",{class:"spm-webview-fallback-frame",src:r.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,qp),m("div",{class:"spm-fallback-bar"},[mt[2]||(mt[2]=m("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),m("button",{class:"spm-icon-btn is-primary",onClick:st}," 在新标签页中打开 ↗ ")])]))],2)],34)])}}}),Jp=Oe(Yp,[["__scopeId","data-v-40e35375"]]);class Xp{constructor(){wt(this,"timers",new Map)}debounce(i,e,s=150){this.cancel(i);const n=setTimeout(()=>{this.timers.delete(i),e()},s);this.timers.set(i,n)}cancel(i){this.timers.has(i)&&(clearTimeout(this.timers.get(i)),this.timers.delete(i))}cancelAll(){for(const i of this.timers.values())clearTimeout(i);this.timers.clear()}hasPending(i){return this.timers.has(i)}}class Qp{constructor(i){wt(this,"blockToPageMap",new Map);wt(this,"debounceCtrl",new Xp);wt(this,"activeBlockId","");wt(this,"activePageIndex",1);wt(this,"currentDocId","");wt(this,"bridge",null);i&&(this.bridge=i)}setBridge(i){this.bridge=i}setDocId(i){this.currentDocId=i}updateSlidesIndex(i){this.blockToPageMap.clear();for(const e of i){e.startBlockId&&this.blockToPageMap.set(e.startBlockId,e.pageIndex);for(const s of e.blocks)this.blockToPageMap.set(s.id,e.pageIndex)}}getPageByBlockId(i){return this.blockToPageMap.get(i)??null}onCursorFocusBlock(i){if(!i||i===this.activeBlockId)return;this.activeBlockId=i;let e=this.getPageByBlockId(i);!e&&(i===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(e=1),e&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=e,this.bridge&&(this.bridge.navigatePage(e),this.bridge.highlightElement(i))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(i){this.activeBlockId=i;const e=this.getPageByBlockId(i);e&&(this.activePageIndex=e)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Ei(t,i){var r,l;if(!t||typeof document>"u")return!1;const e=(r=globalThis.CSS)!=null&&r.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),s=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`);if(!s){if(i)try{return vt.openTab({app:i,doc:{id:t,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(o){console.warn("[SelectionMirror] openTab fallback failed:",o)}return!1}try{s.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{s.scrollIntoView()}try{(l=s.focus)==null||l.call(s,{preventScroll:!0})}catch{}s.classList.add("protyle-wysiwyg--select");const n=s.style.outline;return s.style.outline="2px solid #3b82f6",s.style.transition="outline 0.3s ease",setTimeout(()=>{s.classList.remove("protyle-wysiwyg--select"),s.style.outline=n},1200),!0}function oe(t){return t?t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function th(t){if(!t||t.trim()===""||t.trim()==="all")return"all";const i=new Set,e=t.split("|");for(const s of e){const n=s.trim();if(n==="all")return"all";if(n.includes("-")){const[r,l]=n.split("-"),o=parseInt(r,10),a=parseInt(l,10);if(!isNaN(o)&&!isNaN(a))for(let c=Math.min(o,a);c<=Math.max(o,a);c++)i.add(c)}else{const r=parseInt(n,10);isNaN(r)||i.add(r)}}return i}const eh=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function ve(t){if(!t)return"";const i=Mr(t),e=[],s=i.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(r,l)=>{const o=l.toLowerCase();if(!eh.has(o)||/on\w+\s*=|javascript:/i.test(r))return r;if(o==="v-mark"){const a=r.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return r.startsWith("</")?e.push("</mark>"):e.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${e.length-1}%%`}return e.push(r),`%%SAFE_HTML_${e.length-1}%%`});let n=oe(s);return n=n.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(r,l,o,a,c,d,h)=>{const u=(o??a??c??d??h??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${u}</a>`}),n=n.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),n=n.replace(/!\[(.*?)\]\((.*?)\)/g,(r,l,o)=>{const c=/\.gif(?:\?|$)/i.test(o)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${o}" class="${c}" />`}),n=n.replace(/\[(.*?)\]\((.*?)\)/g,(r,l,o)=>{if(o.startsWith("siyuan://blocks/")){const a=o.replace("siyuan://blocks/","").split("?")[0];return`<a href="${o}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${o}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),n=n.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(r,l,o,a)=>`${l}<a href="${o}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${o}</a>`),n=n.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),n=n.replace(/\*(.*?)\*/g,"<em>$1</em>"),n=n.replace(/~~(.*?)~~/g,"<del>$1</del>"),n=n.replace(/`([^`]+)`/g,"<code>$1</code>"),n=n.replace(/%%SAFE_HTML_(\d+)%%/g,(r,l)=>{const o=parseInt(l,10);return e[o]||""}),n}function ih(t,i="pdf-table"){if(t.length<2)return"";const e=t.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),s=e[0];let n=[],r=1;t.length>=2&&e[1].every(a=>/^:?-+:?$/.test(a))&&(n=e[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),r=2);const l=`<thead><tr>${s.map((a,c)=>`<th${n[c]?` style="text-align: ${n[c]}"`:""}>${ve(a)}</th>`).join("")}</tr></thead>`,o=e.slice(r).map(a=>`<tr>${a.map((c,d)=>`<td${n[d]?` style="text-align: ${n[d]}"`:""}>${ve(c)}</td>`).join("")}</tr>`).join("");return`<table class="${i}">${l}<tbody>${o}</tbody></table>`}function Es(t){return String(t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function nh(t,i="ts"){if(!t)return"";if(t.trim().startsWith("//"))return`<span class="token-comment">${Es(t)}</span>`;const e=[];function s(r,l){return e.push(`<span class="${r}">${Es(l)}</span>`),`__TOK_${e.length-1}__`}let n=t.replace(/(['"`])(.*?)\1/g,(r,l,o)=>s("token-string",`${l}${o}${l}`));return n=n.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,r=>s("token-keyword",r)),n=n.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,r=>s("token-type",r)),n=n.replace(/\b(\d+)\b/g,r=>s("token-number",r)),n=Es(n),n=n.replace(/__TOK_(\d+)__/g,(r,l)=>e[parseInt(l,10)]||""),n}function sh(t,i){if(!t)return null;const e=t.frontmatter||{};if(e.hideInToc===!0||e.hideInToc==="true")return null;let s=(e.title||"").trim(),n=e.level?parseInt(e.level,10):0;if(!s){const r=t.blocks||[];for(const l of r){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){n||(n=a[1].length),s=a[2].trim();break}}}return s?((!n||isNaN(n))&&(n=1),{pageIndex:t.pageIndex||i,title:s,level:n}):null}function oh(t,i=1,e={}){const s=e.minDepth!==void 0?Number(e.minDepth):1,n=e.maxDepth!==void 0?Number(e.maxDepth):1/0,r=[];Array.isArray(t)&&t.forEach((c,d)=>{const h=sh(c,d+1);h&&r.push(h)});const l=[];let o=null;for(const c of r){const d={...c,active:c.pageIndex===i,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),o=d):o?(d.active&&(o.hasActiveChild=!0),o.children.push(d)):l.push(d)}function a(c,d=1){if(d>n)return[];const h=[];for(const g of c){const u=a(g.children,d+1);d>=s?h.push({...g,children:u}):h.push(...u)}return h}return a(l,1)}function rh(t,i=1,e={}){const s=oh(t,i,e),n=e.columns?Number(e.columns):1,r=n>1?` style="column-count: ${n};"`:"",l=e.textSm?" text-sm":"";function o(c,d=1){if(!c||c.length===0)return"";const h=`slidev-toc-list slidev-toc-list-level-${d}`,g=c.map(u=>{const y=u.active?" slidev-toc-item-active":u.hasActiveChild?" slidev-toc-item-parent-active":"",p=u.children&&u.children.length>0?o(u.children,d+1):"";let b=ve(u.title);return b.includes("LaTeX")&&(b=b.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${y}" data-page="${u.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${b}</span>
          </a>
          ${p}
        </li>
      `}).join("");return`<ol class="${h}">${g}</ol>`}const a=o(s,1);return`<div class="slidev-toc${l}"${r}>${a}</div>`}function Zl(t,i,e){var y,p,b,v;const s=t.split(`
`);if(!s.some(k=>/^(\s*)([-*+]|\d+\.)\s+/.test(k)))return null;const r=[],l=[];let o=!1;for(let k=0;k<s.length;k++){const S=s[k];if(!S.trim())continue;const A=S.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(A){const B=A[1].length,M=Math.floor(B/2);l.push({type:"task",level:M,checked:A[2].toLowerCase()==="x",text:A[3],media:[]});continue}const x=S.match(/^(\s*)[-*+]\s+(.*)$/);if(x){const B=x[1].length,M=Math.floor(B/2);l.push({type:"unordered",level:M,text:x[2],media:[]});continue}const _=S.match(/^(\s*)\d+\.\s+(.*)$/);if(_){l.length===0&&(o=!0);const B=_[1].length,M=Math.floor(B/2);l.push({type:"ordered",level:M,text:_[2],media:[]});continue}const C=S.trim();if(l.length>0){const B=C.match(/^!\[(.*?)\]\((.*?)\)$/);if(B){const J=/\.gif(?:\?|$)/i.test(B[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${oe(B[1])}" src="${B[2]}" class="${J}" /></div>`);continue}if(C.match(/^<img\b[\s\S]*?\/?>$/i)){l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${C}</div>`);continue}if(/<video\b/i.test(C)){let R=C;if(!/<\/video>/i.test(R))for(;k+1<s.length&&!/<\/video>/i.test(R);)k++,R+=" "+s[k].trim();const J=((y=e==null?void 0:e.attributes)==null?void 0:y["custom-slidev-autoplay"])==="true"||/autoplay/i.test(R),T=((p=e==null?void 0:e.attributes)==null?void 0:p["custom-slidev-loop"])==="true"||/loop/i.test(R),L=((b=e==null?void 0:e.attributes)==null?void 0:b["custom-slidev-muted"])==="true"||J||/muted/i.test(R),w=((v=e==null?void 0:e.attributes)==null?void 0:v["custom-slidev-controls"])==="false",j=R.match(/\bsrc=["']([^"']+)["']/i),Q=j?j[1]:"",z=['class="slide-video-player"'];w||z.push("controls"),J&&(z.push("autoplay"),z.push("playsinline")),T&&z.push("loop"),L&&z.push("muted"),z.push('preload="metadata"'),Q&&z.push(`src="${Q}"`);const at=R.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let W=at?at[1].trim():"";!W&&Q&&(W=`<source src="${Q}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${J?"true":"false"}" data-muted="${L?"true":"false"}"><video ${z.join(" ")}>${W}</video></div>`);continue}l[l.length-1].text+=`
`+C}else r.push(C)}if(l.length===0)return null;function a(k){if(!k)return"";const S=k.split(`
`).map(B=>B.trim()).filter(Boolean);if(S.length===0)return"";if(!S.some(B=>/^#{1,6}\s+/.test(B)))return ve(S.join(" "));const x=[];let _=[];const C=()=>{if(_.length>0){const B=_.join(" ");x.push(`<p class="slide-list-item-desc">${ve(B)}</p>`),_=[]}};for(const B of S){const M=B.match(/^(#{1,6})\s+(.*)$/);if(M){C();const R=M[1].length,J=M[2].trim();x.push(`<h${R} class="slide-list-item-title">${ve(J)}</h${R}>`)}else _.push(B)}return C(),x.join(`
`)}function c(k){if(k.length===0)return"";const S=[];let A=[];const x=C=>{if(A.length>0){const B=A.join(" "),M=C?"slide-list-item-title":"slide-list-item-desc";S.push(`<p class="${M}">${ve(B)}</p>`),A=[]}};let _=!0;for(const C of k){const B=C.match(/^(#{1,6})\s+(.*)$/);if(B){x(_);const M=B[1].length,R=B[2].trim();S.push(`<h${M} class="slide-list-item-title">${ve(R)}</h${M}>`),_=!1}else A.push(C)}return x(_),S.join(`
`)+(S.length>0?`
`:"")}const d=o?"ol":"ul",h=o?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered",g=l.map(k=>{const S=a(k.text),A=k.media&&k.media.length>0?`
${k.media.join(`
`)}`:"",x=k.level||0,_=x>0?` style="margin-left:${(x*1.25).toFixed(2)}em;${k.type==="unordered"?`list-style-type:${x%2===1?"circle":"square"} !important;`:""}"`:"",C=x>0?" slide-list-item--nested":"";if(k.type==="task"){const M=k.checked?' checked=""':"";return`<li class="pdf-task-item${C}"${_}><label><input type="checkbox" disabled=""${M}/> <span>${S}</span></label>${A}</li>`}return`<li${C?` class="${C.trim()}"`:""}${_}>${S}${A}</li>`}).join(`
`);return`${c(r)}<${d} class="${h}">
${g}
</${d}>`}function ze(t,i){var b,v,k,S,A,x,_,C,B;let e="",s="",n="";const r=[];(b=t.motion)!=null&&b.preset&&t.motion.preset!=="none"&&(e=` slidev-motion-${t.motion.preset.toLowerCase()}`,typeof t.motion.duration=="number"&&t.motion.duration>0&&r.push(`--motion-duration:${t.motion.duration}ms`),typeof t.motion.delay=="number"&&t.motion.delay>0&&r.push(`--motion-delay:${t.motion.delay}ms`));const l=((v=t.attributes)==null?void 0:v.style)||"";l&&(r.push(l),n=" slide-styled-block"),r.length>0&&(s=` style="${oe(r.join(";"))}"`);const a=`pdf-block${e}${n}`,c=(t.rawMarkdown||t.content||"").trim();if(!c)return`<div class="${a}"${s}></div>`;if(c.includes('class="slidev-block-ref"')||c.includes('class="slidev-ref-tag"'))return`<div class="${a}"${s}>${c}</div>`;if(c.startsWith("$$")&&c.endsWith("$$")){const M=c.slice(2,-2).trim();return`<div class="${a} katex-display-container"${s}><div class="katex-display font-math"><em>${oe(M)}</em></div></div>`}const d=c.match(/^(#{1,6})\s+(.*)$/);if(d){const M=d[1].length,R=ve(d[2]);return`<div class="${a}"${s}><h${M}>${R}</h${M}></div>`}if(c.startsWith(":::")){const M=c.split(`
`),J=M[0].replace(/^:::\s*/,"").trim()||"info",T=M.slice(1,M[M.length-1].startsWith(":::")?-1:void 0).join(`
`),L="pdf-callout";return`<div class="${a}"${s}><div class="${L} ${L}--${J}"><div class="${L}-title">${J.toUpperCase()}</div><div class="${L}-body">${ve(T)}</div></div></div>`}if(c.startsWith("<<<")){const J=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((j,Q)=>`<span class="code-line shiki-focus"><span class="line-no">${Q+1}</span><span class="line-content">${nh(j,"ts")}</span></span>`).join(`
`),T="pdf-code shiki-container",L=((k=t.attrs)==null?void 0:k["custom-slidev-max-height"])||t.maxHeight||"",w=L?` style="max-height:${oe(L)};overflow-y:auto;"`:"";return`<div class="${a}"${s}><pre class="${T}"${w}><span class="lang-badge">TS</span><code>${J}</code></pre></div>`}if(c.startsWith("<style")||c.startsWith("<!-- Inline style -->")||c.startsWith(`<!--
Notes`))return"";if(c.startsWith("```")){const M=c.split(`
`),R=M[0].slice(3).trim(),J=R.match(/^([^\s{\[]+)/),T=J?J[1]:"",L=R.match(/\[([^\]]+)\]/),w=L?L[1]:"",j=R.includes("twoslash"),Q=t.shikiLines||((S=R.match(/\{([^}]+)\}/))==null?void 0:S[1])||"",z=th(Q),at=M.length>2?M[M.length-1]==="```"?M.slice(1,-1):M.slice(1):[c.slice(3).replace(/```$/,"")],W="pdf-code shiki-container",Y=w?`${W} has-filename`:W,V=z!=="all",N=at.map((mt,gt)=>{const Z=gt+1,ut=z==="all"||z.has(Z)?"code-line shiki-focus":V?"code-line shiki-dimmed":"code-line";let E=oe(mt);return j&&mt.includes("doubled.value = 2")?(E=E.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${ut}"><span class="line-no">${Z}</span><span class="line-content">${E}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${ut}"><span class="line-no">${Z}</span><span class="line-content">${E}</span></span>`}).join(`
`),ct=T?`<span class="lang-badge">${oe(T)}</span>`:"",rt=w?`<span class="code-filename">${oe(w)}</span>`:"",st=((A=t.attrs)==null?void 0:A["custom-slidev-max-height"])||t.maxHeight||"",X=st?` style="max-height:${oe(st)};overflow-y:auto;"`:"";return`<div class="${a}"${s}><pre class="${Y}"${X}>${rt}${ct}<code>${N}</code></pre></div>`}if(c.includes("|")&&c.split(`
`).filter(M=>M.trim().startsWith("|")).length>=2){const M=c.split(`
`).filter(J=>J.trim().startsWith("|")),R=ih(M,i==null?void 0:i.tableClassName);return`<div class="${a}"${s}>${R}</div>`}if(c.startsWith("> "))return`<div class="${a}"${s}><blockquote class="pdf-quote"><p>${ve(c.slice(2))}</p></blockquote></div>`;const h=/<video\b/i.test(c)||t.type==="video"||t.type==="NodeVideo",g=/^(\s*)([-*+]|\d+\.)\s+/m.test(c),u=/(?:^|\n)\s*#{1,6}\s+/.test(c);if(h&&!g&&!u&&!c.includes(`
`)){const M=((x=t.attributes)==null?void 0:x["custom-slidev-autoplay"])==="true"||/autoplay/i.test(c),R=((_=t.attributes)==null?void 0:_["custom-slidev-loop"])==="true"||/loop/i.test(c),J=((C=t.attributes)==null?void 0:C["custom-slidev-muted"])==="true"||M||/muted/i.test(c),T=((B=t.attributes)==null?void 0:B["custom-slidev-controls"])==="false",L=c.match(/\bsrc=["']([^"']+)["']/i),w=L?L[1]:"",j=['class="slide-video-player"'];T||j.push("controls"),M&&(j.push("autoplay"),j.push("playsinline")),R&&j.push("loop"),J&&j.push("muted"),j.push('preload="metadata"'),w&&j.push(`src="${w}"`);const Q=c.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let z=Q?Q[1].trim():"";return!z&&w&&(z=`<source src="${w}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${a} ${a}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${M?"true":"false"}" data-muted="${J?"true":"false"}"${s}><video ${j.join(" ")}>${z}</video></div>`}const y=c.match(/^!\[(.*?)\]\((.*?)\)$/);if(y)return`<div class="${a} ${a}--image slide-media-block slide-media-container"${s}><img alt="${oe(y[1])}" src="${y[2]}" class="pdf-image slide-media-img" /></div>`;const p=Zl(c,i,t);if(p)return`<div class="${a} pdf-list-item"${s}>${p}</div>`;if(/<(?:Toc|toc)\b/i.test(c)&&!c.startsWith("```")){const M=c.match(/minDepth=["']?(\d+)["']?/i),R=c.match(/maxDepth=["']?(\d+)["']?/i),J=c.match(/columns=["']?(\d+)["']?/i);return`<div class="${a}"${s}>${rh([],1,{minDepth:M?parseInt(M[1],10):1,maxDepth:R?parseInt(R[1],10):1/0,columns:J?parseInt(J[1],10):1,textSm:c.includes("text-sm")})}</div>`}if(c.includes(`
`)||u){const M=lh(c,i,t);if(M)return`<div class="${a}"${s}>${M}</div>`}return`<div class="${a}"${s}><p>${ve(c)}</p></div>`}function lh(t,i,e){const s="pdf-block",n=t.split(/\r?\n/),r=[];let l=[];for(let a=0;a<n.length;a++){const c=n[a],d=c.trim();if(/^#{1,6}\s+/.test(d)){l.length>0&&(r.push(l.join(`
`)),l=[]),r.push(d);continue}if(!d){l.length>0&&(r.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(d)){l.length>0&&(r.push(l.join(`
`)),l=[]),r.push(d);continue}if(/<video\b/i.test(d)){l.length>0&&(r.push(l.join(`
`)),l=[]);let h=d;if(!/<\/video>/i.test(h))for(;a+1<n.length&&!/<\/video>/i.test(h);)a++,h+=`
`+n[a];r.push(h);continue}l.push(c)}return l.length>0&&r.push(l.join(`
`)),r.map(a=>{var u,y,p,b;const c=a.trim();if(!c)return"";const d=c.match(/^(#{1,6})\s+(.*)$/);if(d){const v=d[1].length;return`<h${v} class="slide-list-item-title">${ve(d[2].trim())}</h${v}>`}const h=c.match(/^!\[(.*?)\]\((.*?)\)$/);if(h){const k=/\.gif(?:\?|$)/i.test(h[2])?"list-item-gif":"pdf-image slide-media-img";return`<div class="${s} ${s}--image slide-media-block slide-media-container slide-list-media"><img alt="${oe(h[1])}" src="${h[2]}" class="${k}" /></div>`}if(/<video\b/i.test(c)){const v=((u=e==null?void 0:e.attributes)==null?void 0:u["custom-slidev-autoplay"])==="true"||/autoplay/i.test(c),k=((y=e==null?void 0:e.attributes)==null?void 0:y["custom-slidev-loop"])==="true"||/loop/i.test(c),S=((p=e==null?void 0:e.attributes)==null?void 0:p["custom-slidev-muted"])==="true"||v||/muted/i.test(c),A=((b=e==null?void 0:e.attributes)==null?void 0:b["custom-slidev-controls"])==="false",x=c.match(/\bsrc=["']([^"']+)["']/i),_=x?x[1]:"",C=['class="slide-video-player"'];A||C.push("controls"),v&&C.push("autoplay playsinline"),k&&C.push("loop"),S&&C.push("muted"),C.push('preload="metadata"'),_&&C.push(`src="${_}"`);const B=c.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let M=B?B[1].trim():"";return!M&&_&&(M=`<source src="${_}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${s} ${s}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${v?"true":"false"}" data-muted="${S?"true":"false"}"><video ${C.join(" ")}>${M}</video></div>`}const g=Zl(c,i,e);return g||`<p class="slide-list-item-desc">${ve(c)}</p>`}).filter(Boolean).join(`
`)}function ah(t,i){var r,l,o,a;const e=((r=t.frontmatter)==null?void 0:r.layout)||"default",n=(t.blocks||[]).filter(c=>c.slot!=="slot-divider-right");if(e==="two-cols"){const c=n.some(k=>k.slot==="right");let d=[],h=[];if(c)d=n.filter(k=>k.slot!=="right"),h=n.filter(k=>k.slot==="right");else{const k=Math.ceil(n.length/2);d=n.slice(0,k),h=n.slice(k)}const g=d.map(k=>ze(k,i)).join(`
`),u=h.map(k=>ze(k,i)).join(`
`),y="pdf-two-cols-wrapper layout-two-cols-grid",p=(l=t.frontmatter)!=null&&l.layoutClass?` ${t.frontmatter.layoutClass}`:"";return`
      <div class="${y}${p}">
        <div class="pdf-col pdf-col--left">${g}</div>
        <div class="pdf-col pdf-col--right">${u}</div>
      </div>
    `}if(e==="two-cols-header"){let c=[];const d=n.filter(k=>k.slot==="header");if(d.length>0)c=d;else if(n.length>0){const k=n.find(S=>S.type==="h"&&(!S.slot||S.slot==="default"));k&&(c=[k])}const h=n.filter(k=>!c.includes(k)),g=h.filter(k=>k.slot==="right"||k.slot==="col-2"),u=h.filter(k=>!g.includes(k)),y=k=>{const S=k.filter(A=>!!(A.rawMarkdown||A.content||"").trim());if(S.length>0){const A=S[0],x=(A.rawMarkdown||A.content||"").trim();(Ki(A)||/^(?:[-*+]|\d+\.)\s+/.test(x))&&(A.rawMarkdown=zs(A.rawMarkdown||A.content||""),A.content=A.rawMarkdown)}return S.map(A=>ze(A,i)).join(`
`)},p=c.map(k=>ze(k,i)).join(`
`),b=y(u),v=y(g);return`
      <div class="layout-two-cols-header-container">
        <div class="layout-header-section">${p}</div>
        <div class="pdf-two-cols-wrapper layout-two-cols-grid">
          <div class="pdf-col pdf-col--left">${b}</div>
          <div class="pdf-col pdf-col--right">${v}</div>
        </div>
      </div>
    `}if(e==="three-cols-header"){let c=[];const d=n.filter(A=>A.slot==="header");if(d.length>0)c=d;else if(n.length>0){const A=n.find(x=>x.type==="h"&&(!x.slot||x.slot==="default"));A&&(c=[A])}const h=n.filter(A=>!c.includes(A)),{col1:g,col2:u,col3:y}=Dr(h),p=A=>{const x=A.filter(_=>!!(_.rawMarkdown||_.content||"").trim());if(x.length>0){const _=x[0],C=(_.rawMarkdown||_.content||"").trim();(Ki(_)||/^(?:[-*+]|\d+\.)\s+/.test(C))&&(_.rawMarkdown=zs(_.rawMarkdown||_.content||""),_.content=_.rawMarkdown)}return x.map(_=>ze(_,i)).join(`
`)},b=c.map(A=>ze(A,i)).join(`
`),v=p(g),k=p(u),S=p(y);return`
      <div class="layout-three-cols-header-container">
        <div class="layout-header-section">${b}</div>
        <div class="pdf-three-cols-wrapper layout-three-cols-grid">
          <div class="pdf-col pdf-col--1">${v}</div>
          <div class="pdf-col pdf-col--2">${k}</div>
          <div class="pdf-col pdf-col--3">${S}</div>
        </div>
      </div>
    `}if(e==="image-right"||e==="image-left"){const c=e==="image-right",d=n.map(p=>ze(p,i)).join(`
`),h=((o=t.frontmatter)==null?void 0:o.image)||((a=t.frontmatter)==null?void 0:a.background)||"",g=`<div class="pdf-image-col" style="background-image:url('${oe(h)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${oe(h)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,u=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${d}</div>`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:1fr 1fr;grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${c?`${u}
${g}`:`${g}
${u}`}
      </div>
    `}return e==="fact"?`<div class="layout-fact-container">${n.map(d=>ze(d,i)).join(`
`)}</div>`:e==="cover"?`<div class="layout-cover-container">${n.map(d=>ze(d,i)).join(`
`)}</div>`:n.map(c=>ze(c,i)).join(`
`)}function Yl(t,i){const e="Slidev 演示文稿";let s=t.slides;const n=JSON.stringify(s),r=JSON.stringify(t.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${oe(e)}</title>
  <style>
    ${dn(i==null?void 0:i.customInlineStyles)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      gap: 32px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: 24px;
      flex-shrink: 0;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      gap: 24px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .pdf-col .slide-block {
      flex: 0 0 auto !important;
      min-height: auto !important;
      height: auto !important;
      max-height: none !important;
      width: 100% !important;
      display: block !important;
      overflow: visible !important;
      margin-bottom: 8px !important;
      box-sizing: border-box !important;
    }

    .pdf-col .slide-block:has(video),
    .pdf-col .slide-block:has(img),
    .pdf-col .slide-block:has(.slide-media-container),
    .pdf-col .slide-block:has(.slide-video-container),
    .pdf-col .slide-block:has(.slide-list-media),
    .pdf-col .slide-block.slide-block--media,
    .pdf-col .slide-block.slide-block--video,
    .pdf-col .slide-block.slide-block--image,
    .pdf-col .slide-block:only-child {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
    }

    .slide-list-media {
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: auto !important;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 auto;
      min-height: 0;
      height: 100%;
      max-height: 100%;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      flex: 1 1 auto;
      min-height: 0;
      height: 100%;
      max-height: 100%;
      overflow: hidden !important;
      overflow-y: hidden !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container,
    .two-cols-left img,
    .two-cols-right img,
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .layout-three-cols-grid video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: auto !important;
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(t.docId)},
      slides: ${n},
      config: ${r}
    };
  <\/script>
</head>
<body>
  <div id="app">
    <div class="slide-viewport slidev-theme-${t.config.theme||"default"}" id="viewport" data-slidev-theme="${t.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">⛶ 全屏</button>
    </div>
  </div>

  <script>
    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block) {
        const div = document.createElement("div");
        div.className = "slide-block";
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);

        if (md.startsWith("### ")) div.innerHTML = "<h3>" + md.slice(4) + "</h3>";
        else if (md.startsWith("## ")) div.innerHTML = "<h2>" + md.slice(3) + "</h2>";
        else if (md.startsWith("# ")) div.innerHTML = "<h1>" + md.slice(2) + "</h1>";
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                items[items.length - 1].media.push('<div class="slide-list-media">' + tr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            let pL = [];
            const flushLeadP = (isF) => {
              if (pL.length > 0) {
                let txt = pL.join(" ").replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                lParts.push('<p class="' + (isF ? "slide-list-item-title" : "slide-list-item-desc") + '">' + txt + '</p>');
                pL = [];
              }
            };
            let isF = true;
            for (const l of leadLines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushLeadP(isF);
                const lvl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                isF = false;
              } else {
                pL.push(l);
              }
            }
            flushLeadP(isF);
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = it.text.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.join(" ").replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              div.innerHTML = "<p>" + html + "</p>";
            }
          }
        }
        return div;
      }

      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default");
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          for (const b of leftList) leftCol.appendChild(renderBlock(b));
          for (const b of rightList) rightCol.appendChild(renderBlock(b));
          container.appendChild(leftCol);
          container.appendChild(rightCol);
        } else if (slide.frontmatter?.layout === "two-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-two-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-two-cols-wrapper layout-two-cols-grid";
          const leftCol = document.createElement("div");
          leftCol.className = "pdf-col pdf-col--left";
          const rightCol = document.createElement("div");
          rightCol.className = "pdf-col pdf-col--right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          let leftList = [];
          let rightList = [];
          for (const b of rem) {
            if (b.slot === "right" || b.slot === "col-2") rightList.push(b);
            else leftList.push(b);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of leftList) leftCol.appendChild(renderBlock(b));
          for (const b of rightList) rightCol.appendChild(renderBlock(b));
          gridDiv.appendChild(leftCol);
          gridDiv.appendChild(rightCol);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "three-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-three-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-three-cols-wrapper layout-three-cols-grid";
          const col1 = document.createElement("div");
          col1.className = "pdf-col pdf-col--1";
          const col2 = document.createElement("div");
          col2.className = "pdf-col pdf-col--2";
          const col3 = document.createElement("div");
          col3.className = "pdf-col pdf-col--3";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          let c1 = [], c2 = [], c3 = [];
          const hasExplicitCols = rem.some(b => b.slot === "col-1" || b.slot === "col-2" || b.slot === "col-3" || b.slot === "center" || b.slot === "left" || b.slot === "right");
          if (hasExplicitCols) {
            c2 = rem.filter(b => b.slot === "col-2" || b.slot === "center");
            c3 = rem.filter(b => b.slot === "col-3" || b.slot === "right");
            c1 = rem.filter(b => !c2.includes(b) && !c3.includes(b));
          } else if (rem.length >= 3) {
            const count1 = Math.ceil(rem.length / 3);
            const count2 = Math.ceil((rem.length - count1) / 2);
            c1 = rem.slice(0, count1);
            c2 = rem.slice(count1, count1 + count2);
            c3 = rem.slice(count1 + count2);
          } else if (rem.length === 2) {
            c1 = [rem[0]];
            c2 = [rem[1]];
            c3 = [];
          } else if (rem.length === 1) {
            const lines = (rem[0].rawMarkdown || rem[0].content || "").trim().split(/\r?
/);
            const itemStartIndices = [];
            for (let i = 0; i < lines.length; i++) {
              if (/^[ 	]*[-*+]s+|^[ 	]*d+.s+/.test(lines[i])) itemStartIndices.push(i);
            }
            if (itemStartIndices.length >= 3) {
              const count1 = Math.ceil(itemStartIndices.length / 3);
              const count2 = Math.ceil((itemStartIndices.length - count1) / 2);
              const items1 = lines.slice(itemStartIndices[0], itemStartIndices[count1]).join("
");
              const items2 = lines.slice(itemStartIndices[count1], itemStartIndices[count1 + count2]).join("
");
              const items3 = lines.slice(itemStartIndices[count1 + count2]).join("
");
              c1 = [{ ...rem[0], rawMarkdown: items1, content: items1 }];
              c2 = [{ ...rem[0], id: rem[0].id + "-col2", rawMarkdown: items2, content: items2 }];
              c3 = [{ ...rem[0], id: rem[0].id + "-col3", rawMarkdown: items3, content: items3 }];
            } else {
              c1 = rem;
            }
          } else {
            c1 = rem;
          }
          c1 = cleanColList(c1);
          c2 = cleanColList(c2);
          c3 = cleanColList(c3);
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of c1) col1.appendChild(renderBlock(b));
          for (const b of c2) col2.appendChild(renderBlock(b));
          for (const b of c3) col3.appendChild(renderBlock(b));
          gridDiv.appendChild(col1);
          gridDiv.appendChild(col2);
          gridDiv.appendChild(col3);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of (slide.blocks || [])) {
            contentCol.appendChild(renderBlock(block));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          if (isImageRight) {
            container.appendChild(contentCol);
            container.appendChild(imgCol);
          } else {
            container.appendChild(imgCol);
            container.appendChild(contentCol);
          }
        } else {
          for (const block of (slide.blocks || [])) {
            container.appendChild(renderBlock(block));
          }
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      btnPrev.addEventListener("click", () => renderSlide(currentIndex - 1));
      btnNext.addEventListener("click", () => renderSlide(currentIndex + 1));
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "ArrowRight" || e.key === " ") renderSlide(currentIndex + 1);
        if (e.key === "ArrowLeft") renderSlide(currentIndex - 1);
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      document.addEventListener("click", (e) => {
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          renderSlide(currentIndex - 1);
        } else {
          renderSlide(currentIndex + 1);
        }
      });

      renderSlide(0);
      updateScale();
    })();
  <\/script>
</body>
</html>`}function Jl(t,i){if(typeof document>"u")return!1;const e=new Blob([i],{type:"text/html;charset=utf-8"}),s=URL.createObjectURL(e),n=document.createElement("a");return n.href=s,n.download=t.endsWith(".html")?t:`${t}.html`,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(s),!0}function ch(t){switch(t){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function dh(t,i){const e="Slidev 演示讲义",s="16:9",n="light",r=ch(s),l=t.slides.map((o,a)=>{const c=o.frontmatter.layout||"default",d=ah(o),h=`${a+1} / ${t.slides.length}`;return`
      <section class="pdf-slide-page layout-${c} theme-${n}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${oe(e)}</span>
          ${`<span class="pdf-page-badge">P. ${h}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${d}
        </div>
        ${o.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${oe(o.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${oe(e)} - 高保真讲义</title>
  <style>
    ${dn(i==null?void 0:i.customInlineStyles)}

    @page {
      ${r}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: 40px 60px;
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      align-items: center;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      gap: 36px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: 24px;
      flex-shrink: 0;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      gap: 24px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
    }
  </style>
</head>
<body>
  ${l}
</body>
</html>`}function Xl(t,i){var n;if(typeof window>"u"||typeof document>"u")return!1;const e=dh(t,i);try{const r=document.createElement("iframe");r.style.position="fixed",r.style.right="0",r.style.bottom="0",r.style.width="0",r.style.height="0",r.style.border="none",r.style.visibility="hidden",document.body.appendChild(r);const l=(n=r.contentWindow)==null?void 0:n.document;if(l)return l.open(),l.write(e),l.close(),setTimeout(()=>{var o,a;try{(o=r.contentWindow)==null||o.focus(),(a=r.contentWindow)==null||a.print()}finally{setTimeout(()=>{r.remove()},2e3)}},350),!0}catch(r){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",r)}const s=window.open("","_blank");return s?(s.document.write(e),s.document.close(),s.focus(),setTimeout(()=>{s.print(),s.close()},350),!0):!1}const uh={class:"spm-slidev-preview-tab"},fh={class:"spm-slidev-tab__toolbar"},ph={class:"spm-slidev-tab__actions"},hh=["disabled"],mh={class:"spm-page-badge"},gh=["disabled"],vh=["aria-label"],bh=["aria-label"],yh=["src"],kh=ye({__name:"SlidevPreviewTab",setup(t,{expose:i}){const e=Qe("plugin"),s=Qe("sandboxBridge",new So),n=new Qp(s),r=new Tu,l=ht("web-sandbox"),o=ht(3030),a=ht(null),c=ht(!1),d=ht(null),h=ht(1),g=ht(1),u=ht([]),y=ht(!1),p=ht(!1),b=ht(!1),v=ht("siyuan"),k=ht(""),S=ht(""),A=ht(""),x=ht(!1),_=ht(!1),C=ht(""),B=ht("/plugins/siyuan-slidev/slidev-client/index.html");let M=null,R=null,J=null,T=null,L=null,w=null,j=null;$n(()=>{d.value&&(s.attach(d.value),r.nativeBridge.attach(d.value)),M=s.onSlideChanged((Z,ot)=>{h.value=Z,g.value=ot}),R=s.onBlockClicked((Z,ot)=>{h.value=ot,n.setActiveBlockId(Z),e&&typeof e.handleBlockClickedFromSlide=="function"?e.handleBlockClickedFromSlide(Z,ot):Ei(Z,e==null?void 0:e.app)}),J=s.onOpenInEditor((Z,ot)=>{h.value=ot,n.setActiveBlockId(Z),Ei(Z,e==null?void 0:e.app)}),T=r.nativeBridge.onPageChanged((Z,ot)=>{h.value=Z,g.value=ot}),L=s.onOpenPeekDrawer(async Z=>{const ot=$o();if(Z.peekType==="siyuan"&&ot.enableWebServeJump){let ut=!1;if(j&&j.docId===Z.target)ut=!0;else if(j&&j.slides&&j.slides.some(E=>{var P;return(P=E.blocks)==null?void 0:P.some(f=>f.id===Z.target)}))ut=!1;else try{const E=await gn(`SELECT id, root_id, type FROM blocks WHERE id = '${Z.target}' LIMIT 1`);E&&E.length>0&&(ut=E[0].type==="d"||E[0].id===E[0].root_id)}catch(E){console.warn("[SlidevPreviewTab] detect block type failed:",E)}v.value="web",x.value=!0,S.value=Kl(ot.webServeUrl,Z.target,{focus:!ut}),A.value=Z.title||`${ut?"思源文档":"思源块"}: ${Z.target.slice(0,8)}`,p.value=!0,s.freezeKeyboardNav(!0)}else v.value=Z.peekType,Z.peekType==="siyuan"?(k.value=Z.target,A.value=Z.title||`块速览: ${Z.target.slice(0,8)}`):(x.value=!0,S.value=Z.target,A.value=Z.title||Z.target),p.value=!0,s.freezeKeyboardNav(!0)}),w=s.onRequestToggleFullscreen(()=>{st()}),typeof document<"u"&&document.addEventListener("fullscreenchange",rt)}),vo(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",rt),L&&L(),w&&w(),M&&M(),R&&R(),J&&J(),T&&T(),s.detach(),n.destroy(),r.destroy()});async function Q(){if(l.value==="web-sandbox"){if(!j){vt.showMessage("请先在主编辑区打开演示文档");return}vt.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const Z=await r.startProMode(j,Ls);if(!Z.success){vt.showMessage(`无法启动官方 Pro 模式：${Z.error}`);return}l.value="pro-cli",o.value=Z.port||3030,B.value=Z.url,d.value&&r.nativeBridge.attach(d.value),vt.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${o.value})`)}else r.stopProMode(),l.value="web-sandbox",B.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&s.attach(d.value),vt.showMessage("已切回内置高保真沙箱")}function z(){_.value=!_.value,_.value?C.value=(j==null?void 0:j.docId)||"":(C.value="",V())}function at(){h.value>1&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(h.value-1):s.navigatePage(h.value-1))}function W(){h.value<g.value&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(h.value+1):s.navigatePage(h.value+1))}function Y(Z){h.value=Z,l.value==="pro-cli"?r.nativeBridge.navigateToPage(Z):s.navigatePage(Z)}function V(){e&&typeof e.compileCurrentDocument=="function"?e.compileCurrentDocument():e!=null&&e.eventBus&&typeof e.eventBus.emit=="function"&&e.eventBus.emit("slidev:request-compile")}function N(){p.value=!1,s.freezeKeyboardNav(!1)}function ct(){N()}function rt(){typeof document<"u"&&(c.value=!!document.fullscreenElement,s.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function st(){const Z=a.value||d.value;Z&&(document.fullscreenElement?document.exitFullscreen().then(()=>{s.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):Z.requestFullscreen().then(()=>{s.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function X(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function mt(){if(!j){vt.showMessage("请先在主编辑区打开幻灯片文档");return}const Z=Yl(j);Jl("presentation.html",Z)&&vt.showMessage("已开始下载单文件离线 HTML 演示包")}function gt(){if(!j){vt.showMessage("请先在主编辑区打开幻灯片文档");return}Xl(j)&&vt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({updateDocument(Z,ot){_.value&&C.value&&ot&&ot!==C.value||(j=Z,_.value&&!C.value&&(C.value=Z.docId),u.value=Z.slides,g.value=Z.slides.length,n.setDocId(Z.docId),n.updateSlidesIndex(Z.slides),l.value==="pro-cli"?r.scaffolder.scaffold(Z,Ls).catch(()=>{}):s.updateSlides(Z.slides,Z.config,Z.fullMarkdown,Z.customThemeCss))},navigateToBlock(Z){n.onCursorFocusBlock(Z)},isPinned:_,pinnedDocId:C,engineMode:l,toggleEngineMode:Q}),(Z,ot)=>(et(),nt("div",uh,[m("div",fh,[ot[4]||(ot[4]=m("div",{class:"spm-slidev-tab__title"},[m("svg",{class:"spm-slidev-tab__icon","aria-hidden":"true"},[m("use",{"xlink:href":"#iconSlidev"})]),m("span",null,"Slidev 演示预览")],-1)),m("div",ph,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:h.value<=1,"aria-label":"上一页",onClick:at},[pt(kt,{name:"chevron-left"})],8,hh),m("span",mh,St(h.value)+" / "+St(g.value||1),1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:h.value>=g.value,"aria-label":"下一页",onClick:W},[pt(kt,{name:"chevron-right"})],8,gh),m("button",{class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":_.value}]),"aria-label":_.value?"已锁定当前文档（点击解除）："+C.value:"点击锁定当前文档（不随主编辑区切换）",onClick:z},[pt(kt,{name:"pin"}),m("span",null,St(_.value?"已锁定":"跟随"),1)],10,vh),m("button",{class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+o.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:Q},[pt(kt,{name:"step"}),m("span",null,St(l.value==="pro-cli"?"Pro ("+o.value+")":"沙箱"),1)],10,bh),ot[3]||(ot[3]=m("span",{class:"spm-toolbar-divider"},null,-1)),m("button",{class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":y.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:ot[0]||(ot[0]=ut=>y.value=!y.value)},[pt(kt,{name:"outline"})],2),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:X},[pt(kt,{name:"presenter"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:mt},[pt(kt,{name:"export-html"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:gt},[pt(kt,{name:"export-pdf"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:V},[pt(kt,{name:"refresh"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:st},[pt(kt,{name:"fullscreen"})])])]),m("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container"},[m("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:B.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,yh),pt(wp,{visible:p.value,"onUpdate:visible":ot[1]||(ot[1]=ut=>p.value=ut),"is-maximized":b.value,"onUpdate:isMaximized":ot[2]||(ot[2]=ut=>b.value=ut),title:A.value,onClose:N},{default:cl(()=>[v.value==="siyuan"&&k.value?(et(),Ee(Bp,{key:0,"block-id":k.value,title:A.value,plugin:Ci(e),onExternalJump:ct},null,8,["block-id","title","plugin"])):Ft("",!0),x.value?Ie((et(),Ee(Jp,{key:1,visible:p.value&&v.value==="web",url:S.value,title:A.value,onExternalJump:ct},null,8,["visible","url","title"])),[[Nl,v.value==="web"]]):Ft("",!0)]),_:1},8,["visible","is-maximized","title"])],512),y.value&&u.value.length>0?(et(),Ee(fp,{key:0,slides:u.value,"current-active-page":h.value,onNavigate:Y,onRefresh:V},null,8,["slides","current-active-page"])):Ft("",!0)]))}}),wh=Oe(kh,[["__scopeId","data-v-2622f6d8"]]),xh={class:"spm-section spm-section--page"},_h={class:"spm-section-header"},Sh={class:"spm-card-control"},Ch={class:"spm-control-header"},$h={class:"spm-control-title-group"},Ih={class:"spm-control-title"},Ah={class:"spm-quick-chips"},Th=["onClick"],Eh=["value"],Mh={key:0,class:"spm-card-control"},Bh={class:"spm-control-header"},Dh={class:"spm-control-title-group"},Lh={class:"spm-control-title"},Oh={class:"spm-quick-chips"},Ph=["onClick"],Rh=["value"],zh={class:"spm-card-control"},Nh={class:"spm-control-header"},Fh={class:"spm-control-title-group"},jh={class:"spm-control-title"},Hh={key:0,class:"spm-note-status-box"},Uh=["title"],Wh={class:"spm-action-grid",style:{"margin-top":"6px"}},Vh={key:1,class:"spm-note-empty-box"},Kh={class:"spm-card-control"},qh={class:"spm-action-grid"},Gh=ye({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageImage:{},pageNotes:{},pageIndex:{}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageImage","addNoteBlock","locateNoteBlock","generateNotes","insertDividerAfter","deleteDivider"],setup(t,{emit:i}){const e=t,s=$t(()=>{if(!e.pageNotes)return"";const l=e.pageNotes.replace(/[\r\n]+/g," ").trim();return l.length>50?l.slice(0,50)+"...":l}),n=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],r=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(l,o)=>(et(),nt("div",xh,[m("div",_h,[m("span",null,"幻灯片页面设置"+St(t.pageIndex?` (第 ${t.pageIndex} 页)`:""),1)]),pt(Vl,{"model-value":t.pageLayout,onChange:o[0]||(o[0]=a=>l.$emit("update:pageLayout",a))},null,8,["model-value"]),pt(Co,{"model-value":t.pageTransition,onChange:o[1]||(o[1]=a=>l.$emit("update:pageTransition",a))},null,8,["model-value"]),m("div",Sh,[m("div",Ch,[m("div",$h,[m("div",Ih,[pt(kt,{name:"palette"}),o[12]||(o[12]=m("span",null,"页面背景 (Background)",-1))]),o[13]||(o[13]=m("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),m("div",Ah,[(et(),nt(Gt,null,ke(n,a=>m("button",{key:a.value,class:Et(["spm-chip",{active:t.pageBackground===a.value}]),onClick:c=>l.$emit("update:pageBackground",a.value)},St(a.label),11,Th)),64))]),m("input",{value:t.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:o[2]||(o[2]=a=>l.$emit("update:pageBackground",a.target.value)),onChange:o[3]||(o[3]=a=>l.$emit("update:pageBackground",a.target.value))},null,40,Eh)]),t.pageLayout==="image-right"||t.pageLayout==="image-left"||t.pageImage?(et(),nt("div",Mh,[m("div",Bh,[m("div",Dh,[m("div",Lh,[pt(kt,{name:"image"}),o[14]||(o[14]=m("span",null,"页面图片 (Image)",-1))]),o[15]||(o[15]=m("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),m("div",Oh,[(et(),nt(Gt,null,ke(r,a=>m("button",{key:a.value,class:Et(["spm-chip",{active:t.pageImage===a.value}]),onClick:c=>l.$emit("update:pageImage",a.value)},St(a.label),11,Ph)),64))]),m("input",{value:t.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:o[4]||(o[4]=a=>l.$emit("update:pageImage",a.target.value)),onChange:o[5]||(o[5]=a=>l.$emit("update:pageImage",a.target.value))},null,40,Rh)])):Ft("",!0),m("div",zh,[m("div",Nh,[m("div",Fh,[m("div",jh,[pt(kt,{name:"presenter"}),o[16]||(o[16]=m("span",null,"演讲者提词 (Notes)",-1))]),o[17]||(o[17]=m("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),m("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:o[6]||(o[6]=a=>l.$emit("generateNotes"))},[pt(kt,{name:"sparkles"}),o[18]||(o[18]=m("span",null,"AI 讲稿",-1))])]),t.pageNotes?(et(),nt("div",Hh,[o[21]||(o[21]=m("div",{class:"spm-note-status-badge"},[m("span",{class:"spm-badge-dot"}),m("span",null,"已配置正文讲稿")],-1)),m("div",{class:"spm-note-preview-text",title:t.pageNotes},St(s.value),9,Uh),m("div",Wh,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:o[7]||(o[7]=a=>l.$emit("locateNoteBlock"))},[pt(kt,{name:"search"}),o[19]||(o[19]=m("span",null,"定位讲稿块",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:o[8]||(o[8]=a=>l.$emit("addNoteBlock"))},[pt(kt,{name:"insert-below"}),o[20]||(o[20]=m("span",null,"追加讲稿块",-1))])])])):(et(),nt("div",Vh,[o[23]||(o[23]=m("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:o[9]||(o[9]=a=>l.$emit("addNoteBlock"))},[pt(kt,{name:"insert-below"}),o[22]||(o[22]=m("span",null,"添加讲稿备注块",-1))])]))]),m("div",Kh,[o[26]||(o[26]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),m("div",qh,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:o[10]||(o[10]=a=>l.$emit("insertDividerAfter"))},[pt(kt,{name:"insert-below"}),o[24]||(o[24]=m("span",null,"插入新页",-1))]),m("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:o[11]||(o[11]=a=>l.$emit("deleteDivider"))},[pt(kt,{name:"trash"}),o[25]||(o[25]=m("span",null,"删除此页",-1))])])])]))}}),Zh=Oe(Gh,[["__scopeId","data-v-4916b87e"]]),Yh={class:"spm-section spm-section--block"},Jh={class:"spm-card-control"},Xh={class:"spm-control-header"},Qh={class:"spm-control-title-group"},tm={class:"spm-control-title"},em=["aria-label"],im=["checked"],nm={key:0,class:"spm-card-control"},sm={class:"spm-control-header"},om={class:"spm-control-title-group"},rm={class:"spm-control-title"},lm={class:"spm-quick-chips"},am={key:1,class:"spm-card-control"},cm={class:"spm-control-header"},dm={class:"spm-control-title-group"},um={class:"spm-control-title"},fm={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},pm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},hm=["aria-label"],mm=["checked"],gm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},vm=["aria-label"],bm=["checked"],ym={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},km=["aria-label"],wm=["checked"],xm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},_m=["aria-label"],Sm=["checked"],Cm={class:"spm-card-control"},$m={class:"spm-control-header"},Im={class:"spm-control-title-group"},Am={class:"spm-control-title"},Tm=["aria-label"],Em=["checked"],Mm={key:0,class:"spm-quick-chips"},Bm=["onClick"],Dm={class:"spm-card-control"},Lm={class:"spm-control-header"},Om={class:"spm-control-title-group"},Pm={class:"spm-control-title"},Rm=["aria-label"],zm=["checked"],Nm={key:0,class:"spm-quick-chips"},Fm=["onClick"],jm={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},Hm={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},Um={style:{display:"flex",gap:"6px"}},Wm=["value"],Vm=["value"],Km={key:2,class:"spm-card-control"},qm={class:"spm-control-header"},Gm={class:"spm-control-title-group"},Zm={class:"spm-control-title"},Ym={class:"spm-control-desc"},Jm={class:"spm-segmented-group"},Xm=["onClick"],Qm={key:3,class:"spm-card-control"},tg={class:"spm-control-header"},eg={class:"spm-control-title-group"},ig={class:"spm-control-title"},ng={class:"spm-quick-chips"},sg=["onClick"],og=["value"],rg={key:4,class:"spm-card-control"},lg={class:"spm-control-header"},ag={class:"spm-control-title-group"},cg={class:"spm-control-title"},dg={class:"spm-quick-chips"},ug=["onClick"],fg=["value"],pg={class:"spm-card-control"},hg={class:"spm-action-grid"},mg=["aria-label"],gg=ye({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(t,{emit:i}){const e=t,s=$t(()=>{const x=e.currentSlideLayout||"";return["col-1","col-2","col-3"].includes(e.elemSlot)?"three-cols-header":x}),n=$t(()=>{const x=s.value;return["two-cols","two-cols-header","three-cols-header"].includes(x)}),r=$t(()=>{const x=s.value;return x==="three-cols-header"?"三栏插槽归属 (Slot)":x==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),l=$t(()=>{const x=s.value;return x==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":x==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":x==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),o=$t(()=>{const x=s.value;return x==="three-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}]:x==="two-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]:x==="two-cols"?[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}]:[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]});function a(x){const _=e.elemSlot||"";return x?_===x||x==="col-1"&&_==="left"||x==="col-2"&&_==="center"||x==="col-3"&&_==="right"||x==="left"&&_==="col-1"||x==="right"&&(_==="col-2"||_==="col-3"):!_||_==="default"}const c=i,d=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],h=$t(()=>{if(!e.elemMotion||e.elemMotion.trim()===""||e.elemMotion.trim()==="none")return null;try{const x=JSON.parse(e.elemMotion);if(typeof x=="object"&&x!==null)return{preset:x.preset||x.type||"slide-up",duration:typeof x.duration=="number"?x.duration:0,delay:typeof x.delay=="number"?x.delay:0}}catch{}return{preset:e.elemMotion.trim(),duration:0,delay:0}}),g=$t(()=>!!h.value),u=$t(()=>{var x;return((x=h.value)==null?void 0:x.preset)||"slide-up"}),y=$t(()=>{var x;return((x=h.value)==null?void 0:x.duration)||0}),p=$t(()=>{var x;return((x=h.value)==null?void 0:x.delay)||0});function b(){g.value?c("update:elemMotion",""):c("update:elemMotion","slide-up")}function v(x){A(x,y.value,p.value)}function k(x){A(u.value,x,p.value)}function S(x){A(u.value,y.value,x)}function A(x,_,C){if(!x||x==="none"){c("update:elemMotion","");return}if(!_&&!C){c("update:elemMotion",x);return}const B={preset:x};_>0&&(B.duration=_),C>0&&(B.delay=C),c("update:elemMotion",JSON.stringify(B))}return(x,_)=>(et(),nt("div",Yh,[_[53]||(_[53]=m("div",{class:"spm-section-header"},[m("span",null,"元素动效与排版")],-1)),m("div",Jh,[m("div",Xh,[m("div",Qh,[m("div",tm,[pt(kt,{name:"presenter"}),_[22]||(_[22]=m("span",null,"设为讲稿备注 (slidev-note)",-1))]),_[23]||(_[23]=m("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.isNote?"取消讲稿备注":"设为讲稿备注"},[m("input",{type:"checkbox",checked:!!t.isNote,onChange:_[0]||(_[0]=C=>x.$emit("toggleNote"))},null,40,im),_[24]||(_[24]=m("span",{class:"spm-switch-slider"},null,-1))],8,em)])]),t.isImage||t.imageRole?(et(),nt("div",nm,[m("div",sm,[m("div",om,[m("div",rm,[pt(kt,{name:"image"}),_[25]||(_[25]=m("span",null,"图片角色与分栏 (Image & Layout)",-1))]),_[26]||(_[26]=m("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),m("div",lm,[m("button",{class:Et(["spm-chip",{active:!t.imageRole}]),onClick:_[1]||(_[1]=C=>x.$emit("update:imageRole",""))}," 普通内容 ",2),m("button",{class:Et(["spm-chip",{active:t.imageRole==="background"}]),onClick:_[2]||(_[2]=C=>x.$emit("update:imageRole","background"))}," 🖼️ 背景图 ",2),m("button",{class:Et(["spm-chip",{active:t.imageRole==="image-left"}]),onClick:_[3]||(_[3]=C=>x.$emit("update:imageRole","image-left"))}," 🎨 图左 ",2),m("button",{class:Et(["spm-chip",{active:t.imageRole==="image-right"}]),onClick:_[4]||(_[4]=C=>x.$emit("update:imageRole","image-right"))}," 🖼️ 图右 ",2)])])):Ft("",!0),t.isVideo?(et(),nt("div",am,[m("div",cm,[m("div",dm,[m("div",um,[pt(kt,{name:"video"}),_[27]||(_[27]=m("span",null,"视频播放设置 (Video Playback)",-1))]),_[28]||(_[28]=m("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),m("div",fm,[m("div",pm,[_[30]||(_[30]=m("span",{style:{"font-size":"11px"}},"🎛️ 控制条",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoControls?"关闭控制条":"开启控制条"},[m("input",{type:"checkbox",checked:!!t.videoControls,onChange:_[5]||(_[5]=C=>x.$emit("toggleVideoControls"))},null,40,mm),_[29]||(_[29]=m("span",{class:"spm-switch-slider"},null,-1))],8,hm)]),m("div",gm,[_[32]||(_[32]=m("span",{style:{"font-size":"11px"}},"▶️ 自动播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoAutoplay?"关闭自动播放":"开启自动播放"},[m("input",{type:"checkbox",checked:!!t.videoAutoplay,onChange:_[6]||(_[6]=C=>x.$emit("toggleVideoAutoplay"))},null,40,bm),_[31]||(_[31]=m("span",{class:"spm-switch-slider"},null,-1))],8,vm)]),m("div",ym,[_[34]||(_[34]=m("span",{style:{"font-size":"11px"}},"🔁 循环播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoLoop?"关闭循环播放":"开启循环播放"},[m("input",{type:"checkbox",checked:!!t.videoLoop,onChange:_[7]||(_[7]=C=>x.$emit("toggleVideoLoop"))},null,40,wm),_[33]||(_[33]=m("span",{class:"spm-switch-slider"},null,-1))],8,km)]),m("div",xm,[_[36]||(_[36]=m("span",{style:{"font-size":"11px"}},"🔇 静音播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoMuted?"关闭静音":"开启静音"},[m("input",{type:"checkbox",checked:!!t.videoMuted,onChange:_[8]||(_[8]=C=>x.$emit("toggleVideoMuted"))},null,40,Sm),_[35]||(_[35]=m("span",{class:"spm-switch-slider"},null,-1))],8,_m)])])])):Ft("",!0),m("div",Cm,[m("div",$m,[m("div",Im,[m("div",Am,[pt(kt,{name:"step"}),_[37]||(_[37]=m("span",null,"逐步呈现 (v-click)",-1))]),_[38]||(_[38]=m("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[m("input",{type:"checkbox",checked:!!t.elemClick,onChange:_[9]||(_[9]=C=>x.$emit("toggleElemClick"))},null,40,Em),_[39]||(_[39]=m("span",{class:"spm-switch-slider"},null,-1))],8,Tm)]),t.elemClick?(et(),nt("div",Mm,[(et(),nt(Gt,null,ke(["+1","1","2","hide"],C=>m("button",{key:C,class:Et(["spm-chip",{active:t.elemClick===C}]),onClick:B=>x.$emit("update:elemClick",C)},St(C==="+1"?"顺延 (+1)":C==="hide"?"隐藏 (hide)":"第 "+C+" 步"),11,Bm)),64))])):Ft("",!0)]),m("div",Dm,[m("div",Lm,[m("div",Om,[m("div",Pm,[pt(kt,{name:"motion"}),_[40]||(_[40]=m("span",null,"入场微动效 (v-motion)",-1))]),_[41]||(_[41]=m("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":g.value?"关闭微动效":"开启微动效 (slide-up)"},[m("input",{type:"checkbox",checked:g.value,onChange:b},null,40,zm),_[42]||(_[42]=m("span",{class:"spm-switch-slider"},null,-1))],8,Rm)]),g.value?(et(),nt("div",Nm,[(et(),nt(Gt,null,ke(d,C=>m("button",{key:C.value,class:Et(["spm-chip",{active:u.value===C.value}]),onClick:B=>v(C.value)},St(C.label),11,Fm)),64))])):Ft("",!0),g.value?(et(),nt("div",jm,[m("div",Hm,[m("span",null,"时长: "+St(y.value?y.value+"ms":"默认 (450ms)"),1),m("span",null,"延迟: "+St(p.value?p.value+"ms":"0ms"),1)]),m("div",Um,[m("select",{class:"spm-select",style:{flex:"1"},value:y.value,onChange:_[10]||(_[10]=C=>k(Number(C.target.value)))},[..._[43]||(_[43]=[m("option",{value:0},"默认耗时",-1),m("option",{value:200},"极速 (200ms)",-1),m("option",{value:350},"较快 (350ms)",-1),m("option",{value:500},"平滑 (500ms)",-1),m("option",{value:800},"缓慢 (800ms)",-1)])],40,Wm),m("select",{class:"spm-select",style:{flex:"1"},value:p.value,onChange:_[11]||(_[11]=C=>S(Number(C.target.value)))},[..._[44]||(_[44]=[m("option",{value:0},"无延迟",-1),m("option",{value:150},"延迟 150ms",-1),m("option",{value:300},"延迟 300ms",-1),m("option",{value:500},"延迟 500ms",-1)])],40,Vm)])])):Ft("",!0)]),n.value||t.elemSlot?(et(),nt("div",Km,[m("div",qm,[m("div",Gm,[m("div",Zm,[pt(kt,{name:"columns"}),m("span",null,St(r.value),1)]),m("span",Ym,St(l.value),1)])]),m("div",Jm,[(et(!0),nt(Gt,null,ke(o.value,C=>(et(),nt("button",{key:C.value,class:Et(["spm-segmented-item",{active:a(C.value)}]),onClick:B=>x.$emit("update:elemSlot",C.value)},St(C.label),11,Xm))),128))])])):Ft("",!0),t.isCodeBlock?(et(),nt("div",Qm,[m("div",tg,[m("div",eg,[m("div",ig,[pt(kt,{name:"code"}),_[45]||(_[45]=m("span",null,"代码逐行聚光 (Shiki)",-1))]),_[46]||(_[46]=m("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),m("div",ng,[(et(),nt(Gt,null,ke(["1-3","all","1|2|3","2-5"],C=>m("button",{key:C,class:Et(["spm-chip",{active:t.elemShikiLines===C}]),onClick:B=>x.$emit("update:elemShikiLines",C)},St(C),11,sg)),64)),t.elemShikiLines?(et(),nt("button",{key:0,class:"spm-chip spm-chip-clear",onClick:_[12]||(_[12]=C=>x.$emit("update:elemShikiLines",""))}," 清空 ")):Ft("",!0)]),m("input",{value:t.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:_[13]||(_[13]=C=>x.$emit("update:elemShikiLines",C.target.value)),onChange:_[14]||(_[14]=C=>x.$emit("update:elemShikiLines",C.target.value))},null,40,og)])):Ft("",!0),t.isCodeBlock?(et(),nt("div",rg,[m("div",lg,[m("div",ag,[m("div",cg,[pt(kt,{name:"code"}),_[47]||(_[47]=m("span",null,"代码块限高 (Max Height)",-1))]),_[48]||(_[48]=m("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),m("div",dg,[(et(),nt(Gt,null,ke(["240px","320px","400px","50vh"],C=>m("button",{key:C,class:Et(["spm-chip",{active:t.elemMaxHeight===C}]),onClick:B=>x.$emit("update:elemMaxHeight",C)},St(C),11,ug)),64)),t.elemMaxHeight?(et(),nt("button",{key:0,class:"spm-chip spm-chip-clear",onClick:_[15]||(_[15]=C=>x.$emit("update:elemMaxHeight",""))}," 自适应 ")):Ft("",!0)]),m("input",{value:t.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:_[16]||(_[16]=C=>x.$emit("update:elemMaxHeight",C.target.value)),onChange:_[17]||(_[17]=C=>x.$emit("update:elemMaxHeight",C.target.value))},null,40,fg)])):Ft("",!0),m("div",pg,[_[52]||(_[52]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"快捷操作")])],-1)),m("div",hg,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:_[18]||(_[18]=C=>x.$emit("insertDividerBefore"))},[pt(kt,{name:"insert-above"}),_[49]||(_[49]=m("span",null,"上方分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:_[19]||(_[19]=C=>x.$emit("insertDividerAfter"))},[pt(kt,{name:"insert-below"}),_[50]||(_[50]=m("span",null,"下方分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":s.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:_[20]||(_[20]=C=>x.$emit("setTwoColsContrast"))},[pt(kt,{name:"columns"}),m("span",null,St(s.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,mg),t.hasBlockAttrs?(et(),nt("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:_[21]||(_[21]=C=>x.$emit("clearBlockAttrs"))},[pt(kt,{name:"broom"}),_[51]||(_[51]=m("span",null,"清除属性",-1))])):Ft("",!0)])])]))}}),vg={class:"spm-section spm-section--doc"},bg={class:"spm-card-control"},yg={class:"spm-control-header"},kg={class:"spm-control-title-group"},wg={class:"spm-control-title"},xg={class:"spm-segmented-group"},_g=["aria-label","onClick"],Sg={class:"spm-card-control"},Cg={class:"spm-control-header"},$g={class:"spm-control-title-group"},Ig={class:"spm-control-title"},Ag={class:"spm-segmented-group"},Tg={class:"spm-card-control"},Eg={class:"spm-control-header"},Mg={class:"spm-control-title-group"},Bg={class:"spm-control-title"},Dg={class:"spm-card-control"},Lg={class:"spm-control-header"},Og={class:"spm-control-title-group"},Pg={class:"spm-control-title"},Rg=["aria-label"],zg=["checked"],Ng={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},Fg=["value"],jg={class:"spm-card-control"},Hg={class:"spm-action-grid"},Ug=ye({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(t){const i=Qe("plugin"),e=$i,s=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function n(o){Vi({enableWebServeJump:o}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({enableWebServeJump:o})}function r(o){Vi({webServeUrl:o})}function l(o){Vi({webServeUrl:o}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({webServeUrl:o})}return(o,a)=>(et(),nt("div",vg,[a[30]||(a[30]=m("div",{class:"spm-section-header"},[m("span",null,"全局演示配置")],-1)),m("div",bg,[m("div",yg,[m("div",kg,[m("div",wg,[pt(kt,{name:"palette"}),a[14]||(a[14]=m("span",null,"幻灯片主题 (Theme)",-1))]),a[15]||(a[15]=m("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),m("div",xg,[(et(),nt(Gt,null,ke(s,c=>m("button",{key:c.value,class:Et(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:t.docTheme===c.value}]),"aria-label":c.desc,onClick:d=>o.$emit("update:docTheme",c.value)},St(c.label),11,_g)),64))])]),m("div",Sg,[m("div",Cg,[m("div",$g,[m("div",Ig,[pt(kt,{name:"ratio"}),a[16]||(a[16]=m("span",null,"画幅比例 (Aspect Ratio)",-1))]),a[17]||(a[17]=m("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),m("div",Ag,[m("button",{class:Et(["spm-segmented-item",{active:t.docAspectRatio==="16/9"}]),onClick:a[0]||(a[0]=c=>o.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),m("button",{class:Et(["spm-segmented-item",{active:t.docAspectRatio==="4/3"}]),onClick:a[1]||(a[1]=c=>o.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),m("button",{class:Et(["spm-segmented-item",{active:t.docAspectRatio==="16/10"}]),onClick:a[2]||(a[2]=c=>o.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),m("div",Tg,[m("div",Eg,[m("div",Mg,[m("div",Bg,[pt(kt,{name:"transition"}),a[18]||(a[18]=m("span",null,"全局默认转场",-1))]),a[19]||(a[19]=m("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),pt(Co,{"model-value":t.docDefaultTransition,"hide-header":!0,onChange:a[3]||(a[3]=c=>o.$emit("update:docDefaultTransition",c))},null,8,["model-value"])]),m("div",Dg,[m("div",Lg,[m("div",Og,[m("div",Pg,[pt(kt,{name:"external-link"}),a[20]||(a[20]=m("span",null,"本地网络伺服预览 (Web Serve)",-1))]),a[21]||(a[21]=m("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":Ci(e).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[m("input",{type:"checkbox",checked:Ci(e).enableWebServeJump,onChange:a[4]||(a[4]=c=>n(c.target.checked))},null,40,zg),a[22]||(a[22]=m("span",{class:"spm-switch-slider"},null,-1))],8,Rg)]),Ci(e).enableWebServeJump?(et(),nt("div",Ng,[m("input",{value:Ci(e).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:a[5]||(a[5]=Te(()=>{},["stop"])),onKeyup:a[6]||(a[6]=Te(()=>{},["stop"])),onInput:a[7]||(a[7]=c=>r(c.target.value)),onChange:a[8]||(a[8]=c=>l(c.target.value))},null,40,Fg),a[23]||(a[23]=m("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Ft("",!0)]),m("div",jg,[a[29]||(a[29]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"演示全局操作")])],-1)),m("div",Hg,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:a[9]||(a[9]=c=>o.$emit("openBottomPreview"))},[pt(kt,{name:"split-preview"}),a[24]||(a[24]=m("span",null,"分屏预览",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:a[10]||(a[10]=c=>o.$emit("openPresenter"))},[pt(kt,{name:"presenter"}),a[25]||(a[25]=m("span",null,"演讲者视图",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:a[11]||(a[11]=c=>o.$emit("aiAutoSplit"))},[pt(kt,{name:"sparkles"}),a[26]||(a[26]=m("span",null,"AI 智能分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:a[12]||(a[12]=c=>o.$emit("exportHtml"))},[pt(kt,{name:"export-html"}),a[27]||(a[27]=m("span",null,"导出 HTML",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:a[13]||(a[13]=c=>o.$emit("exportPdf"))},[pt(kt,{name:"export-pdf"}),a[28]||(a[28]=m("span",null,"导出 PDF",-1))])])])]))}});var zn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function Wg(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}function Nn(t){throw new Error('Could not dynamically require "'+t+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Ms={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var yr;function Vg(){return yr||(yr=1,(function(t,i){(function(e){t.exports=e()})(function(){return(function e(s,n,r){function l(c,d){if(!n[c]){if(!s[c]){var h=typeof Nn=="function"&&Nn;if(!d&&h)return h(c,!0);if(o)return o(c,!0);var g=new Error("Cannot find module '"+c+"'");throw g.code="MODULE_NOT_FOUND",g}var u=n[c]={exports:{}};s[c][0].call(u.exports,function(y){var p=s[c][1][y];return l(p||y)},u,u.exports,e,s,n,r)}return n[c].exports}for(var o=typeof Nn=="function"&&Nn,a=0;a<r.length;a++)l(r[a]);return l})({1:[function(e,s,n){var r=e("./utils"),l=e("./support"),o="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";n.encode=function(a){for(var c,d,h,g,u,y,p,b=[],v=0,k=a.length,S=k,A=r.getTypeOf(a)!=="string";v<a.length;)S=k-v,h=A?(c=a[v++],d=v<k?a[v++]:0,v<k?a[v++]:0):(c=a.charCodeAt(v++),d=v<k?a.charCodeAt(v++):0,v<k?a.charCodeAt(v++):0),g=c>>2,u=(3&c)<<4|d>>4,y=1<S?(15&d)<<2|h>>6:64,p=2<S?63&h:64,b.push(o.charAt(g)+o.charAt(u)+o.charAt(y)+o.charAt(p));return b.join("")},n.decode=function(a){var c,d,h,g,u,y,p=0,b=0,v="data:";if(a.substr(0,v.length)===v)throw new Error("Invalid base64 input, it looks like a data url.");var k,S=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===o.charAt(64)&&S--,a.charAt(a.length-2)===o.charAt(64)&&S--,S%1!=0)throw new Error("Invalid base64 input, bad content length.");for(k=l.uint8array?new Uint8Array(0|S):new Array(0|S);p<a.length;)c=o.indexOf(a.charAt(p++))<<2|(g=o.indexOf(a.charAt(p++)))>>4,d=(15&g)<<4|(u=o.indexOf(a.charAt(p++)))>>2,h=(3&u)<<6|(y=o.indexOf(a.charAt(p++))),k[b++]=c,u!==64&&(k[b++]=d),y!==64&&(k[b++]=h);return k}},{"./support":30,"./utils":32}],2:[function(e,s,n){var r=e("./external"),l=e("./stream/DataWorker"),o=e("./stream/Crc32Probe"),a=e("./stream/DataLengthProbe");function c(d,h,g,u,y){this.compressedSize=d,this.uncompressedSize=h,this.crc32=g,this.compression=u,this.compressedContent=y}c.prototype={getContentWorker:function(){var d=new l(r.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),h=this;return d.on("end",function(){if(this.streamInfo.data_length!==h.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(r.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,h,g){return d.pipe(new o).pipe(new a("uncompressedSize")).pipe(h.compressWorker(g)).pipe(new a("compressedSize")).withStreamInfo("compression",h)},s.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(e,s,n){var r=e("./stream/GenericWorker");n.STORE={magic:"\0\0",compressWorker:function(){return new r("STORE compression")},uncompressWorker:function(){return new r("STORE decompression")}},n.DEFLATE=e("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(e,s,n){var r=e("./utils"),l=(function(){for(var o,a=[],c=0;c<256;c++){o=c;for(var d=0;d<8;d++)o=1&o?3988292384^o>>>1:o>>>1;a[c]=o}return a})();s.exports=function(o,a){return o!==void 0&&o.length?r.getTypeOf(o)!=="string"?(function(c,d,h,g){var u=l,y=g+h;c^=-1;for(var p=g;p<y;p++)c=c>>>8^u[255&(c^d[p])];return-1^c})(0|a,o,o.length,0):(function(c,d,h,g){var u=l,y=g+h;c^=-1;for(var p=g;p<y;p++)c=c>>>8^u[255&(c^d.charCodeAt(p))];return-1^c})(0|a,o,o.length,0):0}},{"./utils":32}],5:[function(e,s,n){n.base64=!1,n.binary=!1,n.dir=!1,n.createFolders=!0,n.date=null,n.compression=null,n.compressionOptions=null,n.comment=null,n.unixPermissions=null,n.dosPermissions=null},{}],6:[function(e,s,n){var r=null;r=typeof Promise<"u"?Promise:e("lie"),s.exports={Promise:r}},{lie:37}],7:[function(e,s,n){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=e("pako"),o=e("./utils"),a=e("./stream/GenericWorker"),c=r?"uint8array":"array";function d(h,g){a.call(this,"FlateWorker/"+h),this._pako=null,this._pakoAction=h,this._pakoOptions=g,this.meta={}}n.magic="\b\0",o.inherits(d,a),d.prototype.processChunk=function(h){this.meta=h.meta,this._pako===null&&this._createPako(),this._pako.push(o.transformTo(c,h.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var h=this;this._pako.onData=function(g){h.push({data:g,meta:h.meta})}},n.compressWorker=function(h){return new d("Deflate",h)},n.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(e,s,n){function r(u,y){var p,b="";for(p=0;p<y;p++)b+=String.fromCharCode(255&u),u>>>=8;return b}function l(u,y,p,b,v,k){var S,A,x=u.file,_=u.compression,C=k!==c.utf8encode,B=o.transformTo("string",k(x.name)),M=o.transformTo("string",c.utf8encode(x.name)),R=x.comment,J=o.transformTo("string",k(R)),T=o.transformTo("string",c.utf8encode(R)),L=M.length!==x.name.length,w=T.length!==R.length,j="",Q="",z="",at=x.dir,W=x.date,Y={crc32:0,compressedSize:0,uncompressedSize:0};y&&!p||(Y.crc32=u.crc32,Y.compressedSize=u.compressedSize,Y.uncompressedSize=u.uncompressedSize);var V=0;y&&(V|=8),C||!L&&!w||(V|=2048);var N=0,ct=0;at&&(N|=16),v==="UNIX"?(ct=798,N|=(function(st,X){var mt=st;return st||(mt=X?16893:33204),(65535&mt)<<16})(x.unixPermissions,at)):(ct=20,N|=(function(st){return 63&(st||0)})(x.dosPermissions)),S=W.getUTCHours(),S<<=6,S|=W.getUTCMinutes(),S<<=5,S|=W.getUTCSeconds()/2,A=W.getUTCFullYear()-1980,A<<=4,A|=W.getUTCMonth()+1,A<<=5,A|=W.getUTCDate(),L&&(Q=r(1,1)+r(d(B),4)+M,j+="up"+r(Q.length,2)+Q),w&&(z=r(1,1)+r(d(J),4)+T,j+="uc"+r(z.length,2)+z);var rt="";return rt+=`
\0`,rt+=r(V,2),rt+=_.magic,rt+=r(S,2),rt+=r(A,2),rt+=r(Y.crc32,4),rt+=r(Y.compressedSize,4),rt+=r(Y.uncompressedSize,4),rt+=r(B.length,2),rt+=r(j.length,2),{fileRecord:h.LOCAL_FILE_HEADER+rt+B+j,dirRecord:h.CENTRAL_FILE_HEADER+r(ct,2)+rt+r(J.length,2)+"\0\0\0\0"+r(N,4)+r(b,4)+B+j+J}}var o=e("../utils"),a=e("../stream/GenericWorker"),c=e("../utf8"),d=e("../crc32"),h=e("../signature");function g(u,y,p,b){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=y,this.zipPlatform=p,this.encodeFileName=b,this.streamFiles=u,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}o.inherits(g,a),g.prototype.push=function(u){var y=u.meta.percent||0,p=this.entriesCount,b=this._sources.length;this.accumulate?this.contentBuffer.push(u):(this.bytesWritten+=u.data.length,a.prototype.push.call(this,{data:u.data,meta:{currentFile:this.currentFile,percent:p?(y+100*(p-b-1))/p:100}}))},g.prototype.openedSource=function(u){this.currentSourceOffset=this.bytesWritten,this.currentFile=u.file.name;var y=this.streamFiles&&!u.file.dir;if(y){var p=l(u,y,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:p.fileRecord,meta:{percent:0}})}else this.accumulate=!0},g.prototype.closedSource=function(u){this.accumulate=!1;var y=this.streamFiles&&!u.file.dir,p=l(u,y,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(p.dirRecord),y)this.push({data:(function(b){return h.DATA_DESCRIPTOR+r(b.crc32,4)+r(b.compressedSize,4)+r(b.uncompressedSize,4)})(u),meta:{percent:100}});else for(this.push({data:p.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},g.prototype.flush=function(){for(var u=this.bytesWritten,y=0;y<this.dirRecords.length;y++)this.push({data:this.dirRecords[y],meta:{percent:100}});var p=this.bytesWritten-u,b=(function(v,k,S,A,x){var _=o.transformTo("string",x(A));return h.CENTRAL_DIRECTORY_END+"\0\0\0\0"+r(v,2)+r(v,2)+r(k,4)+r(S,4)+r(_.length,2)+_})(this.dirRecords.length,p,u,this.zipComment,this.encodeFileName);this.push({data:b,meta:{percent:100}})},g.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},g.prototype.registerPrevious=function(u){this._sources.push(u);var y=this;return u.on("data",function(p){y.processChunk(p)}),u.on("end",function(){y.closedSource(y.previous.streamInfo),y._sources.length?y.prepareNextSource():y.end()}),u.on("error",function(p){y.error(p)}),this},g.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},g.prototype.error=function(u){var y=this._sources;if(!a.prototype.error.call(this,u))return!1;for(var p=0;p<y.length;p++)try{y[p].error(u)}catch{}return!0},g.prototype.lock=function(){a.prototype.lock.call(this);for(var u=this._sources,y=0;y<u.length;y++)u[y].lock()},s.exports=g},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(e,s,n){var r=e("../compressions"),l=e("./ZipFileWorker");n.generateWorker=function(o,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),h=0;try{o.forEach(function(g,u){h++;var y=(function(k,S){var A=k||S,x=r[A];if(!x)throw new Error(A+" is not a valid compression method !");return x})(u.options.compression,a.compression),p=u.options.compressionOptions||a.compressionOptions||{},b=u.dir,v=u.date;u._compressWorker(y,p).withStreamInfo("file",{name:g,dir:b,date:v,comment:u.comment||"",unixPermissions:u.unixPermissions,dosPermissions:u.dosPermissions}).pipe(d)}),d.entriesCount=h}catch(g){d.error(g)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(e,s,n){function r(){if(!(this instanceof r))return new r;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new r;for(var o in this)typeof this[o]!="function"&&(l[o]=this[o]);return l}}(r.prototype=e("./object")).loadAsync=e("./load"),r.support=e("./support"),r.defaults=e("./defaults"),r.version="3.10.1",r.loadAsync=function(l,o){return new r().loadAsync(l,o)},r.external=e("./external"),s.exports=r},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(e,s,n){var r=e("./utils"),l=e("./external"),o=e("./utf8"),a=e("./zipEntries"),c=e("./stream/Crc32Probe"),d=e("./nodejsUtils");function h(g){return new l.Promise(function(u,y){var p=g.decompressed.getContentWorker().pipe(new c);p.on("error",function(b){y(b)}).on("end",function(){p.streamInfo.crc32!==g.decompressed.crc32?y(new Error("Corrupted zip : CRC32 mismatch")):u()}).resume()})}s.exports=function(g,u){var y=this;return u=r.extend(u||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:o.utf8decode}),d.isNode&&d.isStream(g)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):r.prepareContent("the loaded zip file",g,!0,u.optimizedBinaryString,u.base64).then(function(p){var b=new a(u);return b.load(p),b}).then(function(p){var b=[l.Promise.resolve(p)],v=p.files;if(u.checkCRC32)for(var k=0;k<v.length;k++)b.push(h(v[k]));return l.Promise.all(b)}).then(function(p){for(var b=p.shift(),v=b.files,k=0;k<v.length;k++){var S=v[k],A=S.fileNameStr,x=r.resolve(S.fileNameStr);y.file(x,S.decompressed,{binary:!0,optimizedBinaryString:!0,date:S.date,dir:S.dir,comment:S.fileCommentStr.length?S.fileCommentStr:null,unixPermissions:S.unixPermissions,dosPermissions:S.dosPermissions,createFolders:u.createFolders}),S.dir||(y.file(x).unsafeOriginalName=A)}return b.zipComment.length&&(y.comment=b.zipComment),y})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(e,s,n){var r=e("../utils"),l=e("../stream/GenericWorker");function o(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}r.inherits(o,l),o.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},o.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},o.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},s.exports=o},{"../stream/GenericWorker":28,"../utils":32}],13:[function(e,s,n){var r=e("readable-stream").Readable;function l(o,a,c){r.call(this,a),this._helper=o;var d=this;o.on("data",function(h,g){d.push(h)||d._helper.pause(),c&&c(g)}).on("error",function(h){d.emit("error",h)}).on("end",function(){d.push(null)})}e("../utils").inherits(l,r),l.prototype._read=function(){this._helper.resume()},s.exports=l},{"../utils":32,"readable-stream":16}],14:[function(e,s,n){s.exports={isNode:typeof Buffer<"u",newBufferFrom:function(r,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(r,l);if(typeof r=="number")throw new Error('The "data" argument must not be a number');return new Buffer(r,l)},allocBuffer:function(r){if(Buffer.alloc)return Buffer.alloc(r);var l=new Buffer(r);return l.fill(0),l},isBuffer:function(r){return Buffer.isBuffer(r)},isStream:function(r){return r&&typeof r.on=="function"&&typeof r.pause=="function"&&typeof r.resume=="function"}}},{}],15:[function(e,s,n){function r(x,_,C){var B,M=o.getTypeOf(_),R=o.extend(C||{},d);R.date=R.date||new Date,R.compression!==null&&(R.compression=R.compression.toUpperCase()),typeof R.unixPermissions=="string"&&(R.unixPermissions=parseInt(R.unixPermissions,8)),R.unixPermissions&&16384&R.unixPermissions&&(R.dir=!0),R.dosPermissions&&16&R.dosPermissions&&(R.dir=!0),R.dir&&(x=v(x)),R.createFolders&&(B=b(x))&&k.call(this,B,!0);var J=M==="string"&&R.binary===!1&&R.base64===!1;C&&C.binary!==void 0||(R.binary=!J),(_ instanceof h&&_.uncompressedSize===0||R.dir||!_||_.length===0)&&(R.base64=!1,R.binary=!0,_="",R.compression="STORE",M="string");var T=null;T=_ instanceof h||_ instanceof a?_:y.isNode&&y.isStream(_)?new p(x,_):o.prepareContent(x,_,R.binary,R.optimizedBinaryString,R.base64);var L=new g(x,T,R);this.files[x]=L}var l=e("./utf8"),o=e("./utils"),a=e("./stream/GenericWorker"),c=e("./stream/StreamHelper"),d=e("./defaults"),h=e("./compressedObject"),g=e("./zipObject"),u=e("./generate"),y=e("./nodejsUtils"),p=e("./nodejs/NodejsStreamInputAdapter"),b=function(x){x.slice(-1)==="/"&&(x=x.substring(0,x.length-1));var _=x.lastIndexOf("/");return 0<_?x.substring(0,_):""},v=function(x){return x.slice(-1)!=="/"&&(x+="/"),x},k=function(x,_){return _=_!==void 0?_:d.createFolders,x=v(x),this.files[x]||r.call(this,x,null,{dir:!0,createFolders:_}),this.files[x]};function S(x){return Object.prototype.toString.call(x)==="[object RegExp]"}var A={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(x){var _,C,B;for(_ in this.files)B=this.files[_],(C=_.slice(this.root.length,_.length))&&_.slice(0,this.root.length)===this.root&&x(C,B)},filter:function(x){var _=[];return this.forEach(function(C,B){x(C,B)&&_.push(B)}),_},file:function(x,_,C){if(arguments.length!==1)return x=this.root+x,r.call(this,x,_,C),this;if(S(x)){var B=x;return this.filter(function(R,J){return!J.dir&&B.test(R)})}var M=this.files[this.root+x];return M&&!M.dir?M:null},folder:function(x){if(!x)return this;if(S(x))return this.filter(function(M,R){return R.dir&&x.test(M)});var _=this.root+x,C=k.call(this,_),B=this.clone();return B.root=C.name,B},remove:function(x){x=this.root+x;var _=this.files[x];if(_||(x.slice(-1)!=="/"&&(x+="/"),_=this.files[x]),_&&!_.dir)delete this.files[x];else for(var C=this.filter(function(M,R){return R.name.slice(0,x.length)===x}),B=0;B<C.length;B++)delete this.files[C[B].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(x){var _,C={};try{if((C=o.extend(x||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=C.type.toLowerCase(),C.compression=C.compression.toUpperCase(),C.type==="binarystring"&&(C.type="string"),!C.type)throw new Error("No output type specified.");o.checkSupport(C.type),C.platform!=="darwin"&&C.platform!=="freebsd"&&C.platform!=="linux"&&C.platform!=="sunos"||(C.platform="UNIX"),C.platform==="win32"&&(C.platform="DOS");var B=C.comment||this.comment||"";_=u.generateWorker(this,C,B)}catch(M){(_=new a("error")).error(M)}return new c(_,C.type||"string",C.mimeType)},generateAsync:function(x,_){return this.generateInternalStream(x).accumulate(_)},generateNodeStream:function(x,_){return(x=x||{}).type||(x.type="nodebuffer"),this.generateInternalStream(x).toNodejsStream(_)}};s.exports=A},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(e,s,n){s.exports=e("stream")},{stream:void 0}],17:[function(e,s,n){var r=e("./DataReader");function l(o){r.call(this,o);for(var a=0;a<this.data.length;a++)o[a]=255&o[a]}e("../utils").inherits(l,r),l.prototype.byteAt=function(o){return this.data[this.zero+o]},l.prototype.lastIndexOfSignature=function(o){for(var a=o.charCodeAt(0),c=o.charCodeAt(1),d=o.charCodeAt(2),h=o.charCodeAt(3),g=this.length-4;0<=g;--g)if(this.data[g]===a&&this.data[g+1]===c&&this.data[g+2]===d&&this.data[g+3]===h)return g-this.zero;return-1},l.prototype.readAndCheckSignature=function(o){var a=o.charCodeAt(0),c=o.charCodeAt(1),d=o.charCodeAt(2),h=o.charCodeAt(3),g=this.readData(4);return a===g[0]&&c===g[1]&&d===g[2]&&h===g[3]},l.prototype.readData=function(o){if(this.checkOffset(o),o===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},s.exports=l},{"../utils":32,"./DataReader":18}],18:[function(e,s,n){var r=e("../utils");function l(o){this.data=o,this.length=o.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(o){this.checkIndex(this.index+o)},checkIndex:function(o){if(this.length<this.zero+o||o<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+o+"). Corrupted zip ?")},setIndex:function(o){this.checkIndex(o),this.index=o},skip:function(o){this.setIndex(this.index+o)},byteAt:function(){},readInt:function(o){var a,c=0;for(this.checkOffset(o),a=this.index+o-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=o,c},readString:function(o){return r.transformTo("string",this.readData(o))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var o=this.readInt(4);return new Date(Date.UTC(1980+(o>>25&127),(o>>21&15)-1,o>>16&31,o>>11&31,o>>5&63,(31&o)<<1))}},s.exports=l},{"../utils":32}],19:[function(e,s,n){var r=e("./Uint8ArrayReader");function l(o){r.call(this,o)}e("../utils").inherits(l,r),l.prototype.readData=function(o){this.checkOffset(o);var a=this.data.slice(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},s.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(e,s,n){var r=e("./DataReader");function l(o){r.call(this,o)}e("../utils").inherits(l,r),l.prototype.byteAt=function(o){return this.data.charCodeAt(this.zero+o)},l.prototype.lastIndexOfSignature=function(o){return this.data.lastIndexOf(o)-this.zero},l.prototype.readAndCheckSignature=function(o){return o===this.readData(4)},l.prototype.readData=function(o){this.checkOffset(o);var a=this.data.slice(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},s.exports=l},{"../utils":32,"./DataReader":18}],21:[function(e,s,n){var r=e("./ArrayReader");function l(o){r.call(this,o)}e("../utils").inherits(l,r),l.prototype.readData=function(o){if(this.checkOffset(o),o===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},s.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(e,s,n){var r=e("../utils"),l=e("../support"),o=e("./ArrayReader"),a=e("./StringReader"),c=e("./NodeBufferReader"),d=e("./Uint8ArrayReader");s.exports=function(h){var g=r.getTypeOf(h);return r.checkSupport(g),g!=="string"||l.uint8array?g==="nodebuffer"?new c(h):l.uint8array?new d(r.transformTo("uint8array",h)):new o(r.transformTo("array",h)):new a(h)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(e,s,n){n.LOCAL_FILE_HEADER="PK",n.CENTRAL_FILE_HEADER="PK",n.CENTRAL_DIRECTORY_END="PK",n.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",n.ZIP64_CENTRAL_DIRECTORY_END="PK",n.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(e,s,n){var r=e("./GenericWorker"),l=e("../utils");function o(a){r.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(o,r),o.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},s.exports=o},{"../utils":32,"./GenericWorker":28}],25:[function(e,s,n){var r=e("./GenericWorker"),l=e("../crc32");function o(){r.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}e("../utils").inherits(o,r),o.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},s.exports=o},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(e,s,n){var r=e("../utils"),l=e("./GenericWorker");function o(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}r.inherits(o,l),o.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},s.exports=o},{"../utils":32,"./GenericWorker":28}],27:[function(e,s,n){var r=e("../utils"),l=e("./GenericWorker");function o(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=r.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}r.inherits(o,l),o.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},o.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,r.delay(this._tickAndRepeat,[],this)),!0)},o.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(r.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},o.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},s.exports=o},{"../utils":32,"./GenericWorker":28}],28:[function(e,s,n){function r(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}r.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,o){return this._listeners[l].push(o),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,o){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,o)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var o=this;return l.on("data",function(a){o.processChunk(a)}),l.on("end",function(){o.end()}),l.on("error",function(a){o.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,o){return this.extraStreamInfo[l]=o,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},s.exports=r},{}],29:[function(e,s,n){var r=e("../utils"),l=e("./ConvertWorker"),o=e("./GenericWorker"),a=e("../base64"),c=e("../support"),d=e("../external"),h=null;if(c.nodestream)try{h=e("../nodejs/NodejsStreamOutputAdapter")}catch{}function g(y,p){return new d.Promise(function(b,v){var k=[],S=y._internalType,A=y._outputType,x=y._mimeType;y.on("data",function(_,C){k.push(_),p&&p(C)}).on("error",function(_){k=[],v(_)}).on("end",function(){try{var _=(function(C,B,M){switch(C){case"blob":return r.newBlob(r.transformTo("arraybuffer",B),M);case"base64":return a.encode(B);default:return r.transformTo(C,B)}})(A,(function(C,B){var M,R=0,J=null,T=0;for(M=0;M<B.length;M++)T+=B[M].length;switch(C){case"string":return B.join("");case"array":return Array.prototype.concat.apply([],B);case"uint8array":for(J=new Uint8Array(T),M=0;M<B.length;M++)J.set(B[M],R),R+=B[M].length;return J;case"nodebuffer":return Buffer.concat(B);default:throw new Error("concat : unsupported type '"+C+"'")}})(S,k),x);b(_)}catch(C){v(C)}k=[]}).resume()})}function u(y,p,b){var v=p;switch(p){case"blob":case"arraybuffer":v="uint8array";break;case"base64":v="string"}try{this._internalType=v,this._outputType=p,this._mimeType=b,r.checkSupport(v),this._worker=y.pipe(new l(v)),y.lock()}catch(k){this._worker=new o("error"),this._worker.error(k)}}u.prototype={accumulate:function(y){return g(this,y)},on:function(y,p){var b=this;return y==="data"?this._worker.on(y,function(v){p.call(b,v.data,v.meta)}):this._worker.on(y,function(){r.delay(p,arguments,b)}),this},resume:function(){return r.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(y){if(r.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new h(this,{objectMode:this._outputType!=="nodebuffer"},y)}},s.exports=u},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(e,s,n){if(n.base64=!0,n.array=!0,n.string=!0,n.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",n.nodebuffer=typeof Buffer<"u",n.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")n.blob=!1;else{var r=new ArrayBuffer(0);try{n.blob=new Blob([r],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(r),n.blob=l.getBlob("application/zip").size===0}catch{n.blob=!1}}}try{n.nodestream=!!e("readable-stream").Readable}catch{n.nodestream=!1}},{"readable-stream":16}],31:[function(e,s,n){for(var r=e("./utils"),l=e("./support"),o=e("./nodejsUtils"),a=e("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function h(){a.call(this,"utf-8 decode"),this.leftOver=null}function g(){a.call(this,"utf-8 encode")}n.utf8encode=function(u){return l.nodebuffer?o.newBufferFrom(u,"utf-8"):(function(y){var p,b,v,k,S,A=y.length,x=0;for(k=0;k<A;k++)(64512&(b=y.charCodeAt(k)))==55296&&k+1<A&&(64512&(v=y.charCodeAt(k+1)))==56320&&(b=65536+(b-55296<<10)+(v-56320),k++),x+=b<128?1:b<2048?2:b<65536?3:4;for(p=l.uint8array?new Uint8Array(x):new Array(x),k=S=0;S<x;k++)(64512&(b=y.charCodeAt(k)))==55296&&k+1<A&&(64512&(v=y.charCodeAt(k+1)))==56320&&(b=65536+(b-55296<<10)+(v-56320),k++),b<128?p[S++]=b:(b<2048?p[S++]=192|b>>>6:(b<65536?p[S++]=224|b>>>12:(p[S++]=240|b>>>18,p[S++]=128|b>>>12&63),p[S++]=128|b>>>6&63),p[S++]=128|63&b);return p})(u)},n.utf8decode=function(u){return l.nodebuffer?r.transformTo("nodebuffer",u).toString("utf-8"):(function(y){var p,b,v,k,S=y.length,A=new Array(2*S);for(p=b=0;p<S;)if((v=y[p++])<128)A[b++]=v;else if(4<(k=c[v]))A[b++]=65533,p+=k-1;else{for(v&=k===2?31:k===3?15:7;1<k&&p<S;)v=v<<6|63&y[p++],k--;1<k?A[b++]=65533:v<65536?A[b++]=v:(v-=65536,A[b++]=55296|v>>10&1023,A[b++]=56320|1023&v)}return A.length!==b&&(A.subarray?A=A.subarray(0,b):A.length=b),r.applyFromCharCode(A)})(u=r.transformTo(l.uint8array?"uint8array":"array",u))},r.inherits(h,a),h.prototype.processChunk=function(u){var y=r.transformTo(l.uint8array?"uint8array":"array",u.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var p=y;(y=new Uint8Array(p.length+this.leftOver.length)).set(this.leftOver,0),y.set(p,this.leftOver.length)}else y=this.leftOver.concat(y);this.leftOver=null}var b=(function(k,S){var A;for((S=S||k.length)>k.length&&(S=k.length),A=S-1;0<=A&&(192&k[A])==128;)A--;return A<0||A===0?S:A+c[k[A]]>S?A:S})(y),v=y;b!==y.length&&(l.uint8array?(v=y.subarray(0,b),this.leftOver=y.subarray(b,y.length)):(v=y.slice(0,b),this.leftOver=y.slice(b,y.length))),this.push({data:n.utf8decode(v),meta:u.meta})},h.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:n.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},n.Utf8DecodeWorker=h,r.inherits(g,a),g.prototype.processChunk=function(u){this.push({data:n.utf8encode(u.data),meta:u.meta})},n.Utf8EncodeWorker=g},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(e,s,n){var r=e("./support"),l=e("./base64"),o=e("./nodejsUtils"),a=e("./external");function c(p){return p}function d(p,b){for(var v=0;v<p.length;++v)b[v]=255&p.charCodeAt(v);return b}e("setimmediate"),n.newBlob=function(p,b){n.checkSupport("blob");try{return new Blob([p],{type:b})}catch{try{var v=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return v.append(p),v.getBlob(b)}catch{throw new Error("Bug : can't construct the Blob.")}}};var h={stringifyByChunk:function(p,b,v){var k=[],S=0,A=p.length;if(A<=v)return String.fromCharCode.apply(null,p);for(;S<A;)b==="array"||b==="nodebuffer"?k.push(String.fromCharCode.apply(null,p.slice(S,Math.min(S+v,A)))):k.push(String.fromCharCode.apply(null,p.subarray(S,Math.min(S+v,A)))),S+=v;return k.join("")},stringifyByChar:function(p){for(var b="",v=0;v<p.length;v++)b+=String.fromCharCode(p[v]);return b},applyCanBeUsed:{uint8array:(function(){try{return r.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return r.nodebuffer&&String.fromCharCode.apply(null,o.allocBuffer(1)).length===1}catch{return!1}})()}};function g(p){var b=65536,v=n.getTypeOf(p),k=!0;if(v==="uint8array"?k=h.applyCanBeUsed.uint8array:v==="nodebuffer"&&(k=h.applyCanBeUsed.nodebuffer),k)for(;1<b;)try{return h.stringifyByChunk(p,v,b)}catch{b=Math.floor(b/2)}return h.stringifyByChar(p)}function u(p,b){for(var v=0;v<p.length;v++)b[v]=p[v];return b}n.applyFromCharCode=g;var y={};y.string={string:c,array:function(p){return d(p,new Array(p.length))},arraybuffer:function(p){return y.string.uint8array(p).buffer},uint8array:function(p){return d(p,new Uint8Array(p.length))},nodebuffer:function(p){return d(p,o.allocBuffer(p.length))}},y.array={string:g,array:c,arraybuffer:function(p){return new Uint8Array(p).buffer},uint8array:function(p){return new Uint8Array(p)},nodebuffer:function(p){return o.newBufferFrom(p)}},y.arraybuffer={string:function(p){return g(new Uint8Array(p))},array:function(p){return u(new Uint8Array(p),new Array(p.byteLength))},arraybuffer:c,uint8array:function(p){return new Uint8Array(p)},nodebuffer:function(p){return o.newBufferFrom(new Uint8Array(p))}},y.uint8array={string:g,array:function(p){return u(p,new Array(p.length))},arraybuffer:function(p){return p.buffer},uint8array:c,nodebuffer:function(p){return o.newBufferFrom(p)}},y.nodebuffer={string:g,array:function(p){return u(p,new Array(p.length))},arraybuffer:function(p){return y.nodebuffer.uint8array(p).buffer},uint8array:function(p){return u(p,new Uint8Array(p.length))},nodebuffer:c},n.transformTo=function(p,b){if(b=b||"",!p)return b;n.checkSupport(p);var v=n.getTypeOf(b);return y[v][p](b)},n.resolve=function(p){for(var b=p.split("/"),v=[],k=0;k<b.length;k++){var S=b[k];S==="."||S===""&&k!==0&&k!==b.length-1||(S===".."?v.pop():v.push(S))}return v.join("/")},n.getTypeOf=function(p){return typeof p=="string"?"string":Object.prototype.toString.call(p)==="[object Array]"?"array":r.nodebuffer&&o.isBuffer(p)?"nodebuffer":r.uint8array&&p instanceof Uint8Array?"uint8array":r.arraybuffer&&p instanceof ArrayBuffer?"arraybuffer":void 0},n.checkSupport=function(p){if(!r[p.toLowerCase()])throw new Error(p+" is not supported by this platform")},n.MAX_VALUE_16BITS=65535,n.MAX_VALUE_32BITS=-1,n.pretty=function(p){var b,v,k="";for(v=0;v<(p||"").length;v++)k+="\\x"+((b=p.charCodeAt(v))<16?"0":"")+b.toString(16).toUpperCase();return k},n.delay=function(p,b,v){setImmediate(function(){p.apply(v||null,b||[])})},n.inherits=function(p,b){function v(){}v.prototype=b.prototype,p.prototype=new v},n.extend=function(){var p,b,v={};for(p=0;p<arguments.length;p++)for(b in arguments[p])Object.prototype.hasOwnProperty.call(arguments[p],b)&&v[b]===void 0&&(v[b]=arguments[p][b]);return v},n.prepareContent=function(p,b,v,k,S){return a.Promise.resolve(b).then(function(A){return r.blob&&(A instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(A))!==-1)&&typeof FileReader<"u"?new a.Promise(function(x,_){var C=new FileReader;C.onload=function(B){x(B.target.result)},C.onerror=function(B){_(B.target.error)},C.readAsArrayBuffer(A)}):A}).then(function(A){var x=n.getTypeOf(A);return x?(x==="arraybuffer"?A=n.transformTo("uint8array",A):x==="string"&&(S?A=l.decode(A):v&&k!==!0&&(A=(function(_){return d(_,r.uint8array?new Uint8Array(_.length):new Array(_.length))})(A))),A):a.Promise.reject(new Error("Can't read the data of '"+p+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(e,s,n){var r=e("./reader/readerFor"),l=e("./utils"),o=e("./signature"),a=e("./zipEntry"),c=e("./support");function d(h){this.files=[],this.loadOptions=h}d.prototype={checkSignature:function(h){if(!this.reader.readAndCheckSignature(h)){this.reader.index-=4;var g=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(g)+", expected "+l.pretty(h)+")")}},isSignature:function(h,g){var u=this.reader.index;this.reader.setIndex(h);var y=this.reader.readString(4)===g;return this.reader.setIndex(u),y},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var h=this.reader.readData(this.zipCommentLength),g=c.uint8array?"uint8array":"array",u=l.transformTo(g,h);this.zipComment=this.loadOptions.decodeFileName(u)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var h,g,u,y=this.zip64EndOfCentralSize-44;0<y;)h=this.reader.readInt(2),g=this.reader.readInt(4),u=this.reader.readData(g),this.zip64ExtensibleData[h]={id:h,length:g,value:u}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var h,g;for(h=0;h<this.files.length;h++)g=this.files[h],this.reader.setIndex(g.localHeaderOffset),this.checkSignature(o.LOCAL_FILE_HEADER),g.readLocalPart(this.reader),g.handleUTF8(),g.processAttributes()},readCentralDir:function(){var h;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(o.CENTRAL_FILE_HEADER);)(h=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(h);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var h=this.reader.lastIndexOfSignature(o.CENTRAL_DIRECTORY_END);if(h<0)throw this.isSignature(0,o.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(h);var g=h;if(this.checkSignature(o.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(h=this.reader.lastIndexOfSignature(o.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(h),this.checkSignature(o.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,o.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(o.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(o.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var u=this.centralDirOffset+this.centralDirSize;this.zip64&&(u+=20,u+=12+this.zip64EndOfCentralSize);var y=g-u;if(0<y)this.isSignature(g,o.CENTRAL_FILE_HEADER)||(this.reader.zero=y);else if(y<0)throw new Error("Corrupted zip: missing "+Math.abs(y)+" bytes.")},prepareReader:function(h){this.reader=r(h)},load:function(h){this.prepareReader(h),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},s.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(e,s,n){var r=e("./reader/readerFor"),l=e("./utils"),o=e("./compressedObject"),a=e("./crc32"),c=e("./utf8"),d=e("./compressions"),h=e("./support");function g(u,y){this.options=u,this.loadOptions=y}g.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(u){var y,p;if(u.skip(22),this.fileNameLength=u.readInt(2),p=u.readInt(2),this.fileName=u.readData(this.fileNameLength),u.skip(p),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((y=(function(b){for(var v in d)if(Object.prototype.hasOwnProperty.call(d,v)&&d[v].magic===b)return d[v];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new o(this.compressedSize,this.uncompressedSize,this.crc32,y,u.readData(this.compressedSize))},readCentralPart:function(u){this.versionMadeBy=u.readInt(2),u.skip(2),this.bitFlag=u.readInt(2),this.compressionMethod=u.readString(2),this.date=u.readDate(),this.crc32=u.readInt(4),this.compressedSize=u.readInt(4),this.uncompressedSize=u.readInt(4);var y=u.readInt(2);if(this.extraFieldsLength=u.readInt(2),this.fileCommentLength=u.readInt(2),this.diskNumberStart=u.readInt(2),this.internalFileAttributes=u.readInt(2),this.externalFileAttributes=u.readInt(4),this.localHeaderOffset=u.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");u.skip(y),this.readExtraFields(u),this.parseZIP64ExtraField(u),this.fileComment=u.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var u=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),u==0&&(this.dosPermissions=63&this.externalFileAttributes),u==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var u=r(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=u.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=u.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=u.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=u.readInt(4))}},readExtraFields:function(u){var y,p,b,v=u.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});u.index+4<v;)y=u.readInt(2),p=u.readInt(2),b=u.readData(p),this.extraFields[y]={id:y,length:p,value:b};u.setIndex(v)},handleUTF8:function(){var u=h.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var y=this.findExtraFieldUnicodePath();if(y!==null)this.fileNameStr=y;else{var p=l.transformTo(u,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(p)}var b=this.findExtraFieldUnicodeComment();if(b!==null)this.fileCommentStr=b;else{var v=l.transformTo(u,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(v)}}},findExtraFieldUnicodePath:function(){var u=this.extraFields[28789];if(u){var y=r(u.value);return y.readInt(1)!==1||a(this.fileName)!==y.readInt(4)?null:c.utf8decode(y.readData(u.length-5))}return null},findExtraFieldUnicodeComment:function(){var u=this.extraFields[25461];if(u){var y=r(u.value);return y.readInt(1)!==1||a(this.fileComment)!==y.readInt(4)?null:c.utf8decode(y.readData(u.length-5))}return null}},s.exports=g},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(e,s,n){function r(y,p,b){this.name=y,this.dir=b.dir,this.date=b.date,this.comment=b.comment,this.unixPermissions=b.unixPermissions,this.dosPermissions=b.dosPermissions,this._data=p,this._dataBinary=b.binary,this.options={compression:b.compression,compressionOptions:b.compressionOptions}}var l=e("./stream/StreamHelper"),o=e("./stream/DataWorker"),a=e("./utf8"),c=e("./compressedObject"),d=e("./stream/GenericWorker");r.prototype={internalStream:function(y){var p=null,b="string";try{if(!y)throw new Error("No output type specified.");var v=(b=y.toLowerCase())==="string"||b==="text";b!=="binarystring"&&b!=="text"||(b="string"),p=this._decompressWorker();var k=!this._dataBinary;k&&!v&&(p=p.pipe(new a.Utf8EncodeWorker)),!k&&v&&(p=p.pipe(new a.Utf8DecodeWorker))}catch(S){(p=new d("error")).error(S)}return new l(p,b,"")},async:function(y,p){return this.internalStream(y).accumulate(p)},nodeStream:function(y,p){return this.internalStream(y||"nodebuffer").toNodejsStream(p)},_compressWorker:function(y,p){if(this._data instanceof c&&this._data.compression.magic===y.magic)return this._data.getCompressedWorker();var b=this._decompressWorker();return this._dataBinary||(b=b.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(b,y,p)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new o(this._data)}};for(var h=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],g=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},u=0;u<h.length;u++)r.prototype[h[u]]=g;s.exports=r},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(e,s,n){(function(r){var l,o,a=r.MutationObserver||r.WebKitMutationObserver;if(a){var c=0,d=new a(y),h=r.document.createTextNode("");d.observe(h,{characterData:!0}),l=function(){h.data=c=++c%2}}else if(r.setImmediate||r.MessageChannel===void 0)l="document"in r&&"onreadystatechange"in r.document.createElement("script")?function(){var p=r.document.createElement("script");p.onreadystatechange=function(){y(),p.onreadystatechange=null,p.parentNode.removeChild(p),p=null},r.document.documentElement.appendChild(p)}:function(){setTimeout(y,0)};else{var g=new r.MessageChannel;g.port1.onmessage=y,l=function(){g.port2.postMessage(0)}}var u=[];function y(){var p,b;o=!0;for(var v=u.length;v;){for(b=u,u=[],p=-1;++p<v;)b[p]();v=u.length}o=!1}s.exports=function(p){u.push(p)!==1||o||l()}}).call(this,typeof zn<"u"?zn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(e,s,n){var r=e("immediate");function l(){}var o={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function h(v){if(typeof v!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,v!==l&&p(this,v)}function g(v,k,S){this.promise=v,typeof k=="function"&&(this.onFulfilled=k,this.callFulfilled=this.otherCallFulfilled),typeof S=="function"&&(this.onRejected=S,this.callRejected=this.otherCallRejected)}function u(v,k,S){r(function(){var A;try{A=k(S)}catch(x){return o.reject(v,x)}A===v?o.reject(v,new TypeError("Cannot resolve promise with itself")):o.resolve(v,A)})}function y(v){var k=v&&v.then;if(v&&(typeof v=="object"||typeof v=="function")&&typeof k=="function")return function(){k.apply(v,arguments)}}function p(v,k){var S=!1;function A(C){S||(S=!0,o.reject(v,C))}function x(C){S||(S=!0,o.resolve(v,C))}var _=b(function(){k(x,A)});_.status==="error"&&A(_.value)}function b(v,k){var S={};try{S.value=v(k),S.status="success"}catch(A){S.status="error",S.value=A}return S}(s.exports=h).prototype.finally=function(v){if(typeof v!="function")return this;var k=this.constructor;return this.then(function(S){return k.resolve(v()).then(function(){return S})},function(S){return k.resolve(v()).then(function(){throw S})})},h.prototype.catch=function(v){return this.then(null,v)},h.prototype.then=function(v,k){if(typeof v!="function"&&this.state===c||typeof k!="function"&&this.state===a)return this;var S=new this.constructor(l);return this.state!==d?u(S,this.state===c?v:k,this.outcome):this.queue.push(new g(S,v,k)),S},g.prototype.callFulfilled=function(v){o.resolve(this.promise,v)},g.prototype.otherCallFulfilled=function(v){u(this.promise,this.onFulfilled,v)},g.prototype.callRejected=function(v){o.reject(this.promise,v)},g.prototype.otherCallRejected=function(v){u(this.promise,this.onRejected,v)},o.resolve=function(v,k){var S=b(y,k);if(S.status==="error")return o.reject(v,S.value);var A=S.value;if(A)p(v,A);else{v.state=c,v.outcome=k;for(var x=-1,_=v.queue.length;++x<_;)v.queue[x].callFulfilled(k)}return v},o.reject=function(v,k){v.state=a,v.outcome=k;for(var S=-1,A=v.queue.length;++S<A;)v.queue[S].callRejected(k);return v},h.resolve=function(v){return v instanceof this?v:o.resolve(new this(l),v)},h.reject=function(v){var k=new this(l);return o.reject(k,v)},h.all=function(v){var k=this;if(Object.prototype.toString.call(v)!=="[object Array]")return this.reject(new TypeError("must be an array"));var S=v.length,A=!1;if(!S)return this.resolve([]);for(var x=new Array(S),_=0,C=-1,B=new this(l);++C<S;)M(v[C],C);return B;function M(R,J){k.resolve(R).then(function(T){x[J]=T,++_!==S||A||(A=!0,o.resolve(B,x))},function(T){A||(A=!0,o.reject(B,T))})}},h.race=function(v){var k=this;if(Object.prototype.toString.call(v)!=="[object Array]")return this.reject(new TypeError("must be an array"));var S=v.length,A=!1;if(!S)return this.resolve([]);for(var x=-1,_=new this(l);++x<S;)C=v[x],k.resolve(C).then(function(B){A||(A=!0,o.resolve(_,B))},function(B){A||(A=!0,o.reject(_,B))});var C;return _}},{immediate:36}],38:[function(e,s,n){var r={};(0,e("./lib/utils/common").assign)(r,e("./lib/deflate"),e("./lib/inflate"),e("./lib/zlib/constants")),s.exports=r},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(e,s,n){var r=e("./zlib/deflate"),l=e("./utils/common"),o=e("./utils/strings"),a=e("./zlib/messages"),c=e("./zlib/zstream"),d=Object.prototype.toString,h=0,g=-1,u=0,y=8;function p(v){if(!(this instanceof p))return new p(v);this.options=l.assign({level:g,method:y,chunkSize:16384,windowBits:15,memLevel:8,strategy:u,to:""},v||{});var k=this.options;k.raw&&0<k.windowBits?k.windowBits=-k.windowBits:k.gzip&&0<k.windowBits&&k.windowBits<16&&(k.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var S=r.deflateInit2(this.strm,k.level,k.method,k.windowBits,k.memLevel,k.strategy);if(S!==h)throw new Error(a[S]);if(k.header&&r.deflateSetHeader(this.strm,k.header),k.dictionary){var A;if(A=typeof k.dictionary=="string"?o.string2buf(k.dictionary):d.call(k.dictionary)==="[object ArrayBuffer]"?new Uint8Array(k.dictionary):k.dictionary,(S=r.deflateSetDictionary(this.strm,A))!==h)throw new Error(a[S]);this._dict_set=!0}}function b(v,k){var S=new p(k);if(S.push(v,!0),S.err)throw S.msg||a[S.err];return S.result}p.prototype.push=function(v,k){var S,A,x=this.strm,_=this.options.chunkSize;if(this.ended)return!1;A=k===~~k?k:k===!0?4:0,typeof v=="string"?x.input=o.string2buf(v):d.call(v)==="[object ArrayBuffer]"?x.input=new Uint8Array(v):x.input=v,x.next_in=0,x.avail_in=x.input.length;do{if(x.avail_out===0&&(x.output=new l.Buf8(_),x.next_out=0,x.avail_out=_),(S=r.deflate(x,A))!==1&&S!==h)return this.onEnd(S),!(this.ended=!0);x.avail_out!==0&&(x.avail_in!==0||A!==4&&A!==2)||(this.options.to==="string"?this.onData(o.buf2binstring(l.shrinkBuf(x.output,x.next_out))):this.onData(l.shrinkBuf(x.output,x.next_out)))}while((0<x.avail_in||x.avail_out===0)&&S!==1);return A===4?(S=r.deflateEnd(this.strm),this.onEnd(S),this.ended=!0,S===h):A!==2||(this.onEnd(h),!(x.avail_out=0))},p.prototype.onData=function(v){this.chunks.push(v)},p.prototype.onEnd=function(v){v===h&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=v,this.msg=this.strm.msg},n.Deflate=p,n.deflate=b,n.deflateRaw=function(v,k){return(k=k||{}).raw=!0,b(v,k)},n.gzip=function(v,k){return(k=k||{}).gzip=!0,b(v,k)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(e,s,n){var r=e("./zlib/inflate"),l=e("./utils/common"),o=e("./utils/strings"),a=e("./zlib/constants"),c=e("./zlib/messages"),d=e("./zlib/zstream"),h=e("./zlib/gzheader"),g=Object.prototype.toString;function u(p){if(!(this instanceof u))return new u(p);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},p||{});var b=this.options;b.raw&&0<=b.windowBits&&b.windowBits<16&&(b.windowBits=-b.windowBits,b.windowBits===0&&(b.windowBits=-15)),!(0<=b.windowBits&&b.windowBits<16)||p&&p.windowBits||(b.windowBits+=32),15<b.windowBits&&b.windowBits<48&&(15&b.windowBits)==0&&(b.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var v=r.inflateInit2(this.strm,b.windowBits);if(v!==a.Z_OK)throw new Error(c[v]);this.header=new h,r.inflateGetHeader(this.strm,this.header)}function y(p,b){var v=new u(b);if(v.push(p,!0),v.err)throw v.msg||c[v.err];return v.result}u.prototype.push=function(p,b){var v,k,S,A,x,_,C=this.strm,B=this.options.chunkSize,M=this.options.dictionary,R=!1;if(this.ended)return!1;k=b===~~b?b:b===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof p=="string"?C.input=o.binstring2buf(p):g.call(p)==="[object ArrayBuffer]"?C.input=new Uint8Array(p):C.input=p,C.next_in=0,C.avail_in=C.input.length;do{if(C.avail_out===0&&(C.output=new l.Buf8(B),C.next_out=0,C.avail_out=B),(v=r.inflate(C,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&M&&(_=typeof M=="string"?o.string2buf(M):g.call(M)==="[object ArrayBuffer]"?new Uint8Array(M):M,v=r.inflateSetDictionary(this.strm,_)),v===a.Z_BUF_ERROR&&R===!0&&(v=a.Z_OK,R=!1),v!==a.Z_STREAM_END&&v!==a.Z_OK)return this.onEnd(v),!(this.ended=!0);C.next_out&&(C.avail_out!==0&&v!==a.Z_STREAM_END&&(C.avail_in!==0||k!==a.Z_FINISH&&k!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(S=o.utf8border(C.output,C.next_out),A=C.next_out-S,x=o.buf2string(C.output,S),C.next_out=A,C.avail_out=B-A,A&&l.arraySet(C.output,C.output,S,A,0),this.onData(x)):this.onData(l.shrinkBuf(C.output,C.next_out)))),C.avail_in===0&&C.avail_out===0&&(R=!0)}while((0<C.avail_in||C.avail_out===0)&&v!==a.Z_STREAM_END);return v===a.Z_STREAM_END&&(k=a.Z_FINISH),k===a.Z_FINISH?(v=r.inflateEnd(this.strm),this.onEnd(v),this.ended=!0,v===a.Z_OK):k!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(C.avail_out=0))},u.prototype.onData=function(p){this.chunks.push(p)},u.prototype.onEnd=function(p){p===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=p,this.msg=this.strm.msg},n.Inflate=u,n.inflate=y,n.inflateRaw=function(p,b){return(b=b||{}).raw=!0,y(p,b)},n.ungzip=y},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(e,s,n){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";n.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var h in d)d.hasOwnProperty(h)&&(a[h]=d[h])}}return a},n.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,h,g){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+h),g);else for(var u=0;u<h;u++)a[g+u]=c[d+u]},flattenChunks:function(a){var c,d,h,g,u,y;for(c=h=0,d=a.length;c<d;c++)h+=a[c].length;for(y=new Uint8Array(h),c=g=0,d=a.length;c<d;c++)u=a[c],y.set(u,g),g+=u.length;return y}},o={arraySet:function(a,c,d,h,g){for(var u=0;u<h;u++)a[g+u]=c[d+u]},flattenChunks:function(a){return[].concat.apply([],a)}};n.setTyped=function(a){a?(n.Buf8=Uint8Array,n.Buf16=Uint16Array,n.Buf32=Int32Array,n.assign(n,l)):(n.Buf8=Array,n.Buf16=Array,n.Buf32=Array,n.assign(n,o))},n.setTyped(r)},{}],42:[function(e,s,n){var r=e("./common"),l=!0,o=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{o=!1}for(var a=new r.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(h,g){if(g<65537&&(h.subarray&&o||!h.subarray&&l))return String.fromCharCode.apply(null,r.shrinkBuf(h,g));for(var u="",y=0;y<g;y++)u+=String.fromCharCode(h[y]);return u}a[254]=a[254]=1,n.string2buf=function(h){var g,u,y,p,b,v=h.length,k=0;for(p=0;p<v;p++)(64512&(u=h.charCodeAt(p)))==55296&&p+1<v&&(64512&(y=h.charCodeAt(p+1)))==56320&&(u=65536+(u-55296<<10)+(y-56320),p++),k+=u<128?1:u<2048?2:u<65536?3:4;for(g=new r.Buf8(k),p=b=0;b<k;p++)(64512&(u=h.charCodeAt(p)))==55296&&p+1<v&&(64512&(y=h.charCodeAt(p+1)))==56320&&(u=65536+(u-55296<<10)+(y-56320),p++),u<128?g[b++]=u:(u<2048?g[b++]=192|u>>>6:(u<65536?g[b++]=224|u>>>12:(g[b++]=240|u>>>18,g[b++]=128|u>>>12&63),g[b++]=128|u>>>6&63),g[b++]=128|63&u);return g},n.buf2binstring=function(h){return d(h,h.length)},n.binstring2buf=function(h){for(var g=new r.Buf8(h.length),u=0,y=g.length;u<y;u++)g[u]=h.charCodeAt(u);return g},n.buf2string=function(h,g){var u,y,p,b,v=g||h.length,k=new Array(2*v);for(u=y=0;u<v;)if((p=h[u++])<128)k[y++]=p;else if(4<(b=a[p]))k[y++]=65533,u+=b-1;else{for(p&=b===2?31:b===3?15:7;1<b&&u<v;)p=p<<6|63&h[u++],b--;1<b?k[y++]=65533:p<65536?k[y++]=p:(p-=65536,k[y++]=55296|p>>10&1023,k[y++]=56320|1023&p)}return d(k,y)},n.utf8border=function(h,g){var u;for((g=g||h.length)>h.length&&(g=h.length),u=g-1;0<=u&&(192&h[u])==128;)u--;return u<0||u===0?g:u+a[h[u]]>g?u:g}},{"./common":41}],43:[function(e,s,n){s.exports=function(r,l,o,a){for(var c=65535&r|0,d=r>>>16&65535|0,h=0;o!==0;){for(o-=h=2e3<o?2e3:o;d=d+(c=c+l[a++]|0)|0,--h;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(e,s,n){s.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(e,s,n){var r=(function(){for(var l,o=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;o[a]=l}return o})();s.exports=function(l,o,a,c){var d=r,h=c+a;l^=-1;for(var g=c;g<h;g++)l=l>>>8^d[255&(l^o[g])];return-1^l}},{}],46:[function(e,s,n){var r,l=e("../utils/common"),o=e("./trees"),a=e("./adler32"),c=e("./crc32"),d=e("./messages"),h=0,g=4,u=0,y=-2,p=-1,b=4,v=2,k=8,S=9,A=286,x=30,_=19,C=2*A+1,B=15,M=3,R=258,J=R+M+1,T=42,L=113,w=1,j=2,Q=3,z=4;function at(f,F){return f.msg=d[F],F}function W(f){return(f<<1)-(4<f?9:0)}function Y(f){for(var F=f.length;0<=--F;)f[F]=0}function V(f){var F=f.state,O=F.pending;O>f.avail_out&&(O=f.avail_out),O!==0&&(l.arraySet(f.output,F.pending_buf,F.pending_out,O,f.next_out),f.next_out+=O,F.pending_out+=O,f.total_out+=O,f.avail_out-=O,F.pending-=O,F.pending===0&&(F.pending_out=0))}function N(f,F){o._tr_flush_block(f,0<=f.block_start?f.block_start:-1,f.strstart-f.block_start,F),f.block_start=f.strstart,V(f.strm)}function ct(f,F){f.pending_buf[f.pending++]=F}function rt(f,F){f.pending_buf[f.pending++]=F>>>8&255,f.pending_buf[f.pending++]=255&F}function st(f,F){var O,$,I=f.max_chain_length,D=f.strstart,K=f.prev_length,H=f.nice_match,U=f.strstart>f.w_size-J?f.strstart-(f.w_size-J):0,G=f.window,it=f.w_mask,tt=f.prev,dt=f.strstart+R,xt=G[D+K-1],bt=G[D+K];f.prev_length>=f.good_match&&(I>>=2),H>f.lookahead&&(H=f.lookahead);do if(G[(O=F)+K]===bt&&G[O+K-1]===xt&&G[O]===G[D]&&G[++O]===G[D+1]){D+=2,O++;do;while(G[++D]===G[++O]&&G[++D]===G[++O]&&G[++D]===G[++O]&&G[++D]===G[++O]&&G[++D]===G[++O]&&G[++D]===G[++O]&&G[++D]===G[++O]&&G[++D]===G[++O]&&D<dt);if($=R-(dt-D),D=dt-R,K<$){if(f.match_start=F,H<=(K=$))break;xt=G[D+K-1],bt=G[D+K]}}while((F=tt[F&it])>U&&--I!=0);return K<=f.lookahead?K:f.lookahead}function X(f){var F,O,$,I,D,K,H,U,G,it,tt=f.w_size;do{if(I=f.window_size-f.lookahead-f.strstart,f.strstart>=tt+(tt-J)){for(l.arraySet(f.window,f.window,tt,tt,0),f.match_start-=tt,f.strstart-=tt,f.block_start-=tt,F=O=f.hash_size;$=f.head[--F],f.head[F]=tt<=$?$-tt:0,--O;);for(F=O=tt;$=f.prev[--F],f.prev[F]=tt<=$?$-tt:0,--O;);I+=tt}if(f.strm.avail_in===0)break;if(K=f.strm,H=f.window,U=f.strstart+f.lookahead,G=I,it=void 0,it=K.avail_in,G<it&&(it=G),O=it===0?0:(K.avail_in-=it,l.arraySet(H,K.input,K.next_in,it,U),K.state.wrap===1?K.adler=a(K.adler,H,it,U):K.state.wrap===2&&(K.adler=c(K.adler,H,it,U)),K.next_in+=it,K.total_in+=it,it),f.lookahead+=O,f.lookahead+f.insert>=M)for(D=f.strstart-f.insert,f.ins_h=f.window[D],f.ins_h=(f.ins_h<<f.hash_shift^f.window[D+1])&f.hash_mask;f.insert&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[D+M-1])&f.hash_mask,f.prev[D&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=D,D++,f.insert--,!(f.lookahead+f.insert<M)););}while(f.lookahead<J&&f.strm.avail_in!==0)}function mt(f,F){for(var O,$;;){if(f.lookahead<J){if(X(f),f.lookahead<J&&F===h)return w;if(f.lookahead===0)break}if(O=0,f.lookahead>=M&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+M-1])&f.hash_mask,O=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart),O!==0&&f.strstart-O<=f.w_size-J&&(f.match_length=st(f,O)),f.match_length>=M)if($=o._tr_tally(f,f.strstart-f.match_start,f.match_length-M),f.lookahead-=f.match_length,f.match_length<=f.max_lazy_match&&f.lookahead>=M){for(f.match_length--;f.strstart++,f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+M-1])&f.hash_mask,O=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart,--f.match_length!=0;);f.strstart++}else f.strstart+=f.match_length,f.match_length=0,f.ins_h=f.window[f.strstart],f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+1])&f.hash_mask;else $=o._tr_tally(f,0,f.window[f.strstart]),f.lookahead--,f.strstart++;if($&&(N(f,!1),f.strm.avail_out===0))return w}return f.insert=f.strstart<M-1?f.strstart:M-1,F===g?(N(f,!0),f.strm.avail_out===0?Q:z):f.last_lit&&(N(f,!1),f.strm.avail_out===0)?w:j}function gt(f,F){for(var O,$,I;;){if(f.lookahead<J){if(X(f),f.lookahead<J&&F===h)return w;if(f.lookahead===0)break}if(O=0,f.lookahead>=M&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+M-1])&f.hash_mask,O=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart),f.prev_length=f.match_length,f.prev_match=f.match_start,f.match_length=M-1,O!==0&&f.prev_length<f.max_lazy_match&&f.strstart-O<=f.w_size-J&&(f.match_length=st(f,O),f.match_length<=5&&(f.strategy===1||f.match_length===M&&4096<f.strstart-f.match_start)&&(f.match_length=M-1)),f.prev_length>=M&&f.match_length<=f.prev_length){for(I=f.strstart+f.lookahead-M,$=o._tr_tally(f,f.strstart-1-f.prev_match,f.prev_length-M),f.lookahead-=f.prev_length-1,f.prev_length-=2;++f.strstart<=I&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+M-1])&f.hash_mask,O=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart),--f.prev_length!=0;);if(f.match_available=0,f.match_length=M-1,f.strstart++,$&&(N(f,!1),f.strm.avail_out===0))return w}else if(f.match_available){if(($=o._tr_tally(f,0,f.window[f.strstart-1]))&&N(f,!1),f.strstart++,f.lookahead--,f.strm.avail_out===0)return w}else f.match_available=1,f.strstart++,f.lookahead--}return f.match_available&&($=o._tr_tally(f,0,f.window[f.strstart-1]),f.match_available=0),f.insert=f.strstart<M-1?f.strstart:M-1,F===g?(N(f,!0),f.strm.avail_out===0?Q:z):f.last_lit&&(N(f,!1),f.strm.avail_out===0)?w:j}function Z(f,F,O,$,I){this.good_length=f,this.max_lazy=F,this.nice_length=O,this.max_chain=$,this.func=I}function ot(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=k,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*C),this.dyn_dtree=new l.Buf16(2*(2*x+1)),this.bl_tree=new l.Buf16(2*(2*_+1)),Y(this.dyn_ltree),Y(this.dyn_dtree),Y(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(B+1),this.heap=new l.Buf16(2*A+1),Y(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*A+1),Y(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ut(f){var F;return f&&f.state?(f.total_in=f.total_out=0,f.data_type=v,(F=f.state).pending=0,F.pending_out=0,F.wrap<0&&(F.wrap=-F.wrap),F.status=F.wrap?T:L,f.adler=F.wrap===2?0:1,F.last_flush=h,o._tr_init(F),u):at(f,y)}function E(f){var F=ut(f);return F===u&&(function(O){O.window_size=2*O.w_size,Y(O.head),O.max_lazy_match=r[O.level].max_lazy,O.good_match=r[O.level].good_length,O.nice_match=r[O.level].nice_length,O.max_chain_length=r[O.level].max_chain,O.strstart=0,O.block_start=0,O.lookahead=0,O.insert=0,O.match_length=O.prev_length=M-1,O.match_available=0,O.ins_h=0})(f.state),F}function P(f,F,O,$,I,D){if(!f)return y;var K=1;if(F===p&&(F=6),$<0?(K=0,$=-$):15<$&&(K=2,$-=16),I<1||S<I||O!==k||$<8||15<$||F<0||9<F||D<0||b<D)return at(f,y);$===8&&($=9);var H=new ot;return(f.state=H).strm=f,H.wrap=K,H.gzhead=null,H.w_bits=$,H.w_size=1<<H.w_bits,H.w_mask=H.w_size-1,H.hash_bits=I+7,H.hash_size=1<<H.hash_bits,H.hash_mask=H.hash_size-1,H.hash_shift=~~((H.hash_bits+M-1)/M),H.window=new l.Buf8(2*H.w_size),H.head=new l.Buf16(H.hash_size),H.prev=new l.Buf16(H.w_size),H.lit_bufsize=1<<I+6,H.pending_buf_size=4*H.lit_bufsize,H.pending_buf=new l.Buf8(H.pending_buf_size),H.d_buf=1*H.lit_bufsize,H.l_buf=3*H.lit_bufsize,H.level=F,H.strategy=D,H.method=O,E(f)}r=[new Z(0,0,0,0,function(f,F){var O=65535;for(O>f.pending_buf_size-5&&(O=f.pending_buf_size-5);;){if(f.lookahead<=1){if(X(f),f.lookahead===0&&F===h)return w;if(f.lookahead===0)break}f.strstart+=f.lookahead,f.lookahead=0;var $=f.block_start+O;if((f.strstart===0||f.strstart>=$)&&(f.lookahead=f.strstart-$,f.strstart=$,N(f,!1),f.strm.avail_out===0)||f.strstart-f.block_start>=f.w_size-J&&(N(f,!1),f.strm.avail_out===0))return w}return f.insert=0,F===g?(N(f,!0),f.strm.avail_out===0?Q:z):(f.strstart>f.block_start&&(N(f,!1),f.strm.avail_out),w)}),new Z(4,4,8,4,mt),new Z(4,5,16,8,mt),new Z(4,6,32,32,mt),new Z(4,4,16,16,gt),new Z(8,16,32,32,gt),new Z(8,16,128,128,gt),new Z(8,32,128,256,gt),new Z(32,128,258,1024,gt),new Z(32,258,258,4096,gt)],n.deflateInit=function(f,F){return P(f,F,k,15,8,0)},n.deflateInit2=P,n.deflateReset=E,n.deflateResetKeep=ut,n.deflateSetHeader=function(f,F){return f&&f.state?f.state.wrap!==2?y:(f.state.gzhead=F,u):y},n.deflate=function(f,F){var O,$,I,D;if(!f||!f.state||5<F||F<0)return f?at(f,y):y;if($=f.state,!f.output||!f.input&&f.avail_in!==0||$.status===666&&F!==g)return at(f,f.avail_out===0?-5:y);if($.strm=f,O=$.last_flush,$.last_flush=F,$.status===T)if($.wrap===2)f.adler=0,ct($,31),ct($,139),ct($,8),$.gzhead?(ct($,($.gzhead.text?1:0)+($.gzhead.hcrc?2:0)+($.gzhead.extra?4:0)+($.gzhead.name?8:0)+($.gzhead.comment?16:0)),ct($,255&$.gzhead.time),ct($,$.gzhead.time>>8&255),ct($,$.gzhead.time>>16&255),ct($,$.gzhead.time>>24&255),ct($,$.level===9?2:2<=$.strategy||$.level<2?4:0),ct($,255&$.gzhead.os),$.gzhead.extra&&$.gzhead.extra.length&&(ct($,255&$.gzhead.extra.length),ct($,$.gzhead.extra.length>>8&255)),$.gzhead.hcrc&&(f.adler=c(f.adler,$.pending_buf,$.pending,0)),$.gzindex=0,$.status=69):(ct($,0),ct($,0),ct($,0),ct($,0),ct($,0),ct($,$.level===9?2:2<=$.strategy||$.level<2?4:0),ct($,3),$.status=L);else{var K=k+($.w_bits-8<<4)<<8;K|=(2<=$.strategy||$.level<2?0:$.level<6?1:$.level===6?2:3)<<6,$.strstart!==0&&(K|=32),K+=31-K%31,$.status=L,rt($,K),$.strstart!==0&&(rt($,f.adler>>>16),rt($,65535&f.adler)),f.adler=1}if($.status===69)if($.gzhead.extra){for(I=$.pending;$.gzindex<(65535&$.gzhead.extra.length)&&($.pending!==$.pending_buf_size||($.gzhead.hcrc&&$.pending>I&&(f.adler=c(f.adler,$.pending_buf,$.pending-I,I)),V(f),I=$.pending,$.pending!==$.pending_buf_size));)ct($,255&$.gzhead.extra[$.gzindex]),$.gzindex++;$.gzhead.hcrc&&$.pending>I&&(f.adler=c(f.adler,$.pending_buf,$.pending-I,I)),$.gzindex===$.gzhead.extra.length&&($.gzindex=0,$.status=73)}else $.status=73;if($.status===73)if($.gzhead.name){I=$.pending;do{if($.pending===$.pending_buf_size&&($.gzhead.hcrc&&$.pending>I&&(f.adler=c(f.adler,$.pending_buf,$.pending-I,I)),V(f),I=$.pending,$.pending===$.pending_buf_size)){D=1;break}D=$.gzindex<$.gzhead.name.length?255&$.gzhead.name.charCodeAt($.gzindex++):0,ct($,D)}while(D!==0);$.gzhead.hcrc&&$.pending>I&&(f.adler=c(f.adler,$.pending_buf,$.pending-I,I)),D===0&&($.gzindex=0,$.status=91)}else $.status=91;if($.status===91)if($.gzhead.comment){I=$.pending;do{if($.pending===$.pending_buf_size&&($.gzhead.hcrc&&$.pending>I&&(f.adler=c(f.adler,$.pending_buf,$.pending-I,I)),V(f),I=$.pending,$.pending===$.pending_buf_size)){D=1;break}D=$.gzindex<$.gzhead.comment.length?255&$.gzhead.comment.charCodeAt($.gzindex++):0,ct($,D)}while(D!==0);$.gzhead.hcrc&&$.pending>I&&(f.adler=c(f.adler,$.pending_buf,$.pending-I,I)),D===0&&($.status=103)}else $.status=103;if($.status===103&&($.gzhead.hcrc?($.pending+2>$.pending_buf_size&&V(f),$.pending+2<=$.pending_buf_size&&(ct($,255&f.adler),ct($,f.adler>>8&255),f.adler=0,$.status=L)):$.status=L),$.pending!==0){if(V(f),f.avail_out===0)return $.last_flush=-1,u}else if(f.avail_in===0&&W(F)<=W(O)&&F!==g)return at(f,-5);if($.status===666&&f.avail_in!==0)return at(f,-5);if(f.avail_in!==0||$.lookahead!==0||F!==h&&$.status!==666){var H=$.strategy===2?(function(U,G){for(var it;;){if(U.lookahead===0&&(X(U),U.lookahead===0)){if(G===h)return w;break}if(U.match_length=0,it=o._tr_tally(U,0,U.window[U.strstart]),U.lookahead--,U.strstart++,it&&(N(U,!1),U.strm.avail_out===0))return w}return U.insert=0,G===g?(N(U,!0),U.strm.avail_out===0?Q:z):U.last_lit&&(N(U,!1),U.strm.avail_out===0)?w:j})($,F):$.strategy===3?(function(U,G){for(var it,tt,dt,xt,bt=U.window;;){if(U.lookahead<=R){if(X(U),U.lookahead<=R&&G===h)return w;if(U.lookahead===0)break}if(U.match_length=0,U.lookahead>=M&&0<U.strstart&&(tt=bt[dt=U.strstart-1])===bt[++dt]&&tt===bt[++dt]&&tt===bt[++dt]){xt=U.strstart+R;do;while(tt===bt[++dt]&&tt===bt[++dt]&&tt===bt[++dt]&&tt===bt[++dt]&&tt===bt[++dt]&&tt===bt[++dt]&&tt===bt[++dt]&&tt===bt[++dt]&&dt<xt);U.match_length=R-(xt-dt),U.match_length>U.lookahead&&(U.match_length=U.lookahead)}if(U.match_length>=M?(it=o._tr_tally(U,1,U.match_length-M),U.lookahead-=U.match_length,U.strstart+=U.match_length,U.match_length=0):(it=o._tr_tally(U,0,U.window[U.strstart]),U.lookahead--,U.strstart++),it&&(N(U,!1),U.strm.avail_out===0))return w}return U.insert=0,G===g?(N(U,!0),U.strm.avail_out===0?Q:z):U.last_lit&&(N(U,!1),U.strm.avail_out===0)?w:j})($,F):r[$.level].func($,F);if(H!==Q&&H!==z||($.status=666),H===w||H===Q)return f.avail_out===0&&($.last_flush=-1),u;if(H===j&&(F===1?o._tr_align($):F!==5&&(o._tr_stored_block($,0,0,!1),F===3&&(Y($.head),$.lookahead===0&&($.strstart=0,$.block_start=0,$.insert=0))),V(f),f.avail_out===0))return $.last_flush=-1,u}return F!==g?u:$.wrap<=0?1:($.wrap===2?(ct($,255&f.adler),ct($,f.adler>>8&255),ct($,f.adler>>16&255),ct($,f.adler>>24&255),ct($,255&f.total_in),ct($,f.total_in>>8&255),ct($,f.total_in>>16&255),ct($,f.total_in>>24&255)):(rt($,f.adler>>>16),rt($,65535&f.adler)),V(f),0<$.wrap&&($.wrap=-$.wrap),$.pending!==0?u:1)},n.deflateEnd=function(f){var F;return f&&f.state?(F=f.state.status)!==T&&F!==69&&F!==73&&F!==91&&F!==103&&F!==L&&F!==666?at(f,y):(f.state=null,F===L?at(f,-3):u):y},n.deflateSetDictionary=function(f,F){var O,$,I,D,K,H,U,G,it=F.length;if(!f||!f.state||(D=(O=f.state).wrap)===2||D===1&&O.status!==T||O.lookahead)return y;for(D===1&&(f.adler=a(f.adler,F,it,0)),O.wrap=0,it>=O.w_size&&(D===0&&(Y(O.head),O.strstart=0,O.block_start=0,O.insert=0),G=new l.Buf8(O.w_size),l.arraySet(G,F,it-O.w_size,O.w_size,0),F=G,it=O.w_size),K=f.avail_in,H=f.next_in,U=f.input,f.avail_in=it,f.next_in=0,f.input=F,X(O);O.lookahead>=M;){for($=O.strstart,I=O.lookahead-(M-1);O.ins_h=(O.ins_h<<O.hash_shift^O.window[$+M-1])&O.hash_mask,O.prev[$&O.w_mask]=O.head[O.ins_h],O.head[O.ins_h]=$,$++,--I;);O.strstart=$,O.lookahead=M-1,X(O)}return O.strstart+=O.lookahead,O.block_start=O.strstart,O.insert=O.lookahead,O.lookahead=0,O.match_length=O.prev_length=M-1,O.match_available=0,f.next_in=H,f.input=U,f.avail_in=K,O.wrap=D,u},n.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(e,s,n){s.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(e,s,n){s.exports=function(r,l){var o,a,c,d,h,g,u,y,p,b,v,k,S,A,x,_,C,B,M,R,J,T,L,w,j;o=r.state,a=r.next_in,w=r.input,c=a+(r.avail_in-5),d=r.next_out,j=r.output,h=d-(l-r.avail_out),g=d+(r.avail_out-257),u=o.dmax,y=o.wsize,p=o.whave,b=o.wnext,v=o.window,k=o.hold,S=o.bits,A=o.lencode,x=o.distcode,_=(1<<o.lenbits)-1,C=(1<<o.distbits)-1;t:do{S<15&&(k+=w[a++]<<S,S+=8,k+=w[a++]<<S,S+=8),B=A[k&_];e:for(;;){if(k>>>=M=B>>>24,S-=M,(M=B>>>16&255)===0)j[d++]=65535&B;else{if(!(16&M)){if((64&M)==0){B=A[(65535&B)+(k&(1<<M)-1)];continue e}if(32&M){o.mode=12;break t}r.msg="invalid literal/length code",o.mode=30;break t}R=65535&B,(M&=15)&&(S<M&&(k+=w[a++]<<S,S+=8),R+=k&(1<<M)-1,k>>>=M,S-=M),S<15&&(k+=w[a++]<<S,S+=8,k+=w[a++]<<S,S+=8),B=x[k&C];i:for(;;){if(k>>>=M=B>>>24,S-=M,!(16&(M=B>>>16&255))){if((64&M)==0){B=x[(65535&B)+(k&(1<<M)-1)];continue i}r.msg="invalid distance code",o.mode=30;break t}if(J=65535&B,S<(M&=15)&&(k+=w[a++]<<S,(S+=8)<M&&(k+=w[a++]<<S,S+=8)),u<(J+=k&(1<<M)-1)){r.msg="invalid distance too far back",o.mode=30;break t}if(k>>>=M,S-=M,(M=d-h)<J){if(p<(M=J-M)&&o.sane){r.msg="invalid distance too far back",o.mode=30;break t}if(L=v,(T=0)===b){if(T+=y-M,M<R){for(R-=M;j[d++]=v[T++],--M;);T=d-J,L=j}}else if(b<M){if(T+=y+b-M,(M-=b)<R){for(R-=M;j[d++]=v[T++],--M;);if(T=0,b<R){for(R-=M=b;j[d++]=v[T++],--M;);T=d-J,L=j}}}else if(T+=b-M,M<R){for(R-=M;j[d++]=v[T++],--M;);T=d-J,L=j}for(;2<R;)j[d++]=L[T++],j[d++]=L[T++],j[d++]=L[T++],R-=3;R&&(j[d++]=L[T++],1<R&&(j[d++]=L[T++]))}else{for(T=d-J;j[d++]=j[T++],j[d++]=j[T++],j[d++]=j[T++],2<(R-=3););R&&(j[d++]=j[T++],1<R&&(j[d++]=j[T++]))}break}}break}}while(a<c&&d<g);a-=R=S>>3,k&=(1<<(S-=R<<3))-1,r.next_in=a,r.next_out=d,r.avail_in=a<c?c-a+5:5-(a-c),r.avail_out=d<g?g-d+257:257-(d-g),o.hold=k,o.bits=S}},{}],49:[function(e,s,n){var r=e("../utils/common"),l=e("./adler32"),o=e("./crc32"),a=e("./inffast"),c=e("./inftrees"),d=1,h=2,g=0,u=-2,y=1,p=852,b=592;function v(T){return(T>>>24&255)+(T>>>8&65280)+((65280&T)<<8)+((255&T)<<24)}function k(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new r.Buf16(320),this.work=new r.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function S(T){var L;return T&&T.state?(L=T.state,T.total_in=T.total_out=L.total=0,T.msg="",L.wrap&&(T.adler=1&L.wrap),L.mode=y,L.last=0,L.havedict=0,L.dmax=32768,L.head=null,L.hold=0,L.bits=0,L.lencode=L.lendyn=new r.Buf32(p),L.distcode=L.distdyn=new r.Buf32(b),L.sane=1,L.back=-1,g):u}function A(T){var L;return T&&T.state?((L=T.state).wsize=0,L.whave=0,L.wnext=0,S(T)):u}function x(T,L){var w,j;return T&&T.state?(j=T.state,L<0?(w=0,L=-L):(w=1+(L>>4),L<48&&(L&=15)),L&&(L<8||15<L)?u:(j.window!==null&&j.wbits!==L&&(j.window=null),j.wrap=w,j.wbits=L,A(T))):u}function _(T,L){var w,j;return T?(j=new k,(T.state=j).window=null,(w=x(T,L))!==g&&(T.state=null),w):u}var C,B,M=!0;function R(T){if(M){var L;for(C=new r.Buf32(512),B=new r.Buf32(32),L=0;L<144;)T.lens[L++]=8;for(;L<256;)T.lens[L++]=9;for(;L<280;)T.lens[L++]=7;for(;L<288;)T.lens[L++]=8;for(c(d,T.lens,0,288,C,0,T.work,{bits:9}),L=0;L<32;)T.lens[L++]=5;c(h,T.lens,0,32,B,0,T.work,{bits:5}),M=!1}T.lencode=C,T.lenbits=9,T.distcode=B,T.distbits=5}function J(T,L,w,j){var Q,z=T.state;return z.window===null&&(z.wsize=1<<z.wbits,z.wnext=0,z.whave=0,z.window=new r.Buf8(z.wsize)),j>=z.wsize?(r.arraySet(z.window,L,w-z.wsize,z.wsize,0),z.wnext=0,z.whave=z.wsize):(j<(Q=z.wsize-z.wnext)&&(Q=j),r.arraySet(z.window,L,w-j,Q,z.wnext),(j-=Q)?(r.arraySet(z.window,L,w-j,j,0),z.wnext=j,z.whave=z.wsize):(z.wnext+=Q,z.wnext===z.wsize&&(z.wnext=0),z.whave<z.wsize&&(z.whave+=Q))),0}n.inflateReset=A,n.inflateReset2=x,n.inflateResetKeep=S,n.inflateInit=function(T){return _(T,15)},n.inflateInit2=_,n.inflate=function(T,L){var w,j,Q,z,at,W,Y,V,N,ct,rt,st,X,mt,gt,Z,ot,ut,E,P,f,F,O,$,I=0,D=new r.Buf8(4),K=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!T||!T.state||!T.output||!T.input&&T.avail_in!==0)return u;(w=T.state).mode===12&&(w.mode=13),at=T.next_out,Q=T.output,Y=T.avail_out,z=T.next_in,j=T.input,W=T.avail_in,V=w.hold,N=w.bits,ct=W,rt=Y,F=g;t:for(;;)switch(w.mode){case y:if(w.wrap===0){w.mode=13;break}for(;N<16;){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}if(2&w.wrap&&V===35615){D[w.check=0]=255&V,D[1]=V>>>8&255,w.check=o(w.check,D,2,0),N=V=0,w.mode=2;break}if(w.flags=0,w.head&&(w.head.done=!1),!(1&w.wrap)||(((255&V)<<8)+(V>>8))%31){T.msg="incorrect header check",w.mode=30;break}if((15&V)!=8){T.msg="unknown compression method",w.mode=30;break}if(N-=4,f=8+(15&(V>>>=4)),w.wbits===0)w.wbits=f;else if(f>w.wbits){T.msg="invalid window size",w.mode=30;break}w.dmax=1<<f,T.adler=w.check=1,w.mode=512&V?10:12,N=V=0;break;case 2:for(;N<16;){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}if(w.flags=V,(255&w.flags)!=8){T.msg="unknown compression method",w.mode=30;break}if(57344&w.flags){T.msg="unknown header flags set",w.mode=30;break}w.head&&(w.head.text=V>>8&1),512&w.flags&&(D[0]=255&V,D[1]=V>>>8&255,w.check=o(w.check,D,2,0)),N=V=0,w.mode=3;case 3:for(;N<32;){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}w.head&&(w.head.time=V),512&w.flags&&(D[0]=255&V,D[1]=V>>>8&255,D[2]=V>>>16&255,D[3]=V>>>24&255,w.check=o(w.check,D,4,0)),N=V=0,w.mode=4;case 4:for(;N<16;){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}w.head&&(w.head.xflags=255&V,w.head.os=V>>8),512&w.flags&&(D[0]=255&V,D[1]=V>>>8&255,w.check=o(w.check,D,2,0)),N=V=0,w.mode=5;case 5:if(1024&w.flags){for(;N<16;){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}w.length=V,w.head&&(w.head.extra_len=V),512&w.flags&&(D[0]=255&V,D[1]=V>>>8&255,w.check=o(w.check,D,2,0)),N=V=0}else w.head&&(w.head.extra=null);w.mode=6;case 6:if(1024&w.flags&&(W<(st=w.length)&&(st=W),st&&(w.head&&(f=w.head.extra_len-w.length,w.head.extra||(w.head.extra=new Array(w.head.extra_len)),r.arraySet(w.head.extra,j,z,st,f)),512&w.flags&&(w.check=o(w.check,j,st,z)),W-=st,z+=st,w.length-=st),w.length))break t;w.length=0,w.mode=7;case 7:if(2048&w.flags){if(W===0)break t;for(st=0;f=j[z+st++],w.head&&f&&w.length<65536&&(w.head.name+=String.fromCharCode(f)),f&&st<W;);if(512&w.flags&&(w.check=o(w.check,j,st,z)),W-=st,z+=st,f)break t}else w.head&&(w.head.name=null);w.length=0,w.mode=8;case 8:if(4096&w.flags){if(W===0)break t;for(st=0;f=j[z+st++],w.head&&f&&w.length<65536&&(w.head.comment+=String.fromCharCode(f)),f&&st<W;);if(512&w.flags&&(w.check=o(w.check,j,st,z)),W-=st,z+=st,f)break t}else w.head&&(w.head.comment=null);w.mode=9;case 9:if(512&w.flags){for(;N<16;){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}if(V!==(65535&w.check)){T.msg="header crc mismatch",w.mode=30;break}N=V=0}w.head&&(w.head.hcrc=w.flags>>9&1,w.head.done=!0),T.adler=w.check=0,w.mode=12;break;case 10:for(;N<32;){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}T.adler=w.check=v(V),N=V=0,w.mode=11;case 11:if(w.havedict===0)return T.next_out=at,T.avail_out=Y,T.next_in=z,T.avail_in=W,w.hold=V,w.bits=N,2;T.adler=w.check=1,w.mode=12;case 12:if(L===5||L===6)break t;case 13:if(w.last){V>>>=7&N,N-=7&N,w.mode=27;break}for(;N<3;){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}switch(w.last=1&V,N-=1,3&(V>>>=1)){case 0:w.mode=14;break;case 1:if(R(w),w.mode=20,L!==6)break;V>>>=2,N-=2;break t;case 2:w.mode=17;break;case 3:T.msg="invalid block type",w.mode=30}V>>>=2,N-=2;break;case 14:for(V>>>=7&N,N-=7&N;N<32;){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}if((65535&V)!=(V>>>16^65535)){T.msg="invalid stored block lengths",w.mode=30;break}if(w.length=65535&V,N=V=0,w.mode=15,L===6)break t;case 15:w.mode=16;case 16:if(st=w.length){if(W<st&&(st=W),Y<st&&(st=Y),st===0)break t;r.arraySet(Q,j,z,st,at),W-=st,z+=st,Y-=st,at+=st,w.length-=st;break}w.mode=12;break;case 17:for(;N<14;){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}if(w.nlen=257+(31&V),V>>>=5,N-=5,w.ndist=1+(31&V),V>>>=5,N-=5,w.ncode=4+(15&V),V>>>=4,N-=4,286<w.nlen||30<w.ndist){T.msg="too many length or distance symbols",w.mode=30;break}w.have=0,w.mode=18;case 18:for(;w.have<w.ncode;){for(;N<3;){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}w.lens[K[w.have++]]=7&V,V>>>=3,N-=3}for(;w.have<19;)w.lens[K[w.have++]]=0;if(w.lencode=w.lendyn,w.lenbits=7,O={bits:w.lenbits},F=c(0,w.lens,0,19,w.lencode,0,w.work,O),w.lenbits=O.bits,F){T.msg="invalid code lengths set",w.mode=30;break}w.have=0,w.mode=19;case 19:for(;w.have<w.nlen+w.ndist;){for(;Z=(I=w.lencode[V&(1<<w.lenbits)-1])>>>16&255,ot=65535&I,!((gt=I>>>24)<=N);){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}if(ot<16)V>>>=gt,N-=gt,w.lens[w.have++]=ot;else{if(ot===16){for($=gt+2;N<$;){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}if(V>>>=gt,N-=gt,w.have===0){T.msg="invalid bit length repeat",w.mode=30;break}f=w.lens[w.have-1],st=3+(3&V),V>>>=2,N-=2}else if(ot===17){for($=gt+3;N<$;){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}N-=gt,f=0,st=3+(7&(V>>>=gt)),V>>>=3,N-=3}else{for($=gt+7;N<$;){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}N-=gt,f=0,st=11+(127&(V>>>=gt)),V>>>=7,N-=7}if(w.have+st>w.nlen+w.ndist){T.msg="invalid bit length repeat",w.mode=30;break}for(;st--;)w.lens[w.have++]=f}}if(w.mode===30)break;if(w.lens[256]===0){T.msg="invalid code -- missing end-of-block",w.mode=30;break}if(w.lenbits=9,O={bits:w.lenbits},F=c(d,w.lens,0,w.nlen,w.lencode,0,w.work,O),w.lenbits=O.bits,F){T.msg="invalid literal/lengths set",w.mode=30;break}if(w.distbits=6,w.distcode=w.distdyn,O={bits:w.distbits},F=c(h,w.lens,w.nlen,w.ndist,w.distcode,0,w.work,O),w.distbits=O.bits,F){T.msg="invalid distances set",w.mode=30;break}if(w.mode=20,L===6)break t;case 20:w.mode=21;case 21:if(6<=W&&258<=Y){T.next_out=at,T.avail_out=Y,T.next_in=z,T.avail_in=W,w.hold=V,w.bits=N,a(T,rt),at=T.next_out,Q=T.output,Y=T.avail_out,z=T.next_in,j=T.input,W=T.avail_in,V=w.hold,N=w.bits,w.mode===12&&(w.back=-1);break}for(w.back=0;Z=(I=w.lencode[V&(1<<w.lenbits)-1])>>>16&255,ot=65535&I,!((gt=I>>>24)<=N);){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}if(Z&&(240&Z)==0){for(ut=gt,E=Z,P=ot;Z=(I=w.lencode[P+((V&(1<<ut+E)-1)>>ut)])>>>16&255,ot=65535&I,!(ut+(gt=I>>>24)<=N);){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}V>>>=ut,N-=ut,w.back+=ut}if(V>>>=gt,N-=gt,w.back+=gt,w.length=ot,Z===0){w.mode=26;break}if(32&Z){w.back=-1,w.mode=12;break}if(64&Z){T.msg="invalid literal/length code",w.mode=30;break}w.extra=15&Z,w.mode=22;case 22:if(w.extra){for($=w.extra;N<$;){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}w.length+=V&(1<<w.extra)-1,V>>>=w.extra,N-=w.extra,w.back+=w.extra}w.was=w.length,w.mode=23;case 23:for(;Z=(I=w.distcode[V&(1<<w.distbits)-1])>>>16&255,ot=65535&I,!((gt=I>>>24)<=N);){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}if((240&Z)==0){for(ut=gt,E=Z,P=ot;Z=(I=w.distcode[P+((V&(1<<ut+E)-1)>>ut)])>>>16&255,ot=65535&I,!(ut+(gt=I>>>24)<=N);){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}V>>>=ut,N-=ut,w.back+=ut}if(V>>>=gt,N-=gt,w.back+=gt,64&Z){T.msg="invalid distance code",w.mode=30;break}w.offset=ot,w.extra=15&Z,w.mode=24;case 24:if(w.extra){for($=w.extra;N<$;){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}w.offset+=V&(1<<w.extra)-1,V>>>=w.extra,N-=w.extra,w.back+=w.extra}if(w.offset>w.dmax){T.msg="invalid distance too far back",w.mode=30;break}w.mode=25;case 25:if(Y===0)break t;if(st=rt-Y,w.offset>st){if((st=w.offset-st)>w.whave&&w.sane){T.msg="invalid distance too far back",w.mode=30;break}X=st>w.wnext?(st-=w.wnext,w.wsize-st):w.wnext-st,st>w.length&&(st=w.length),mt=w.window}else mt=Q,X=at-w.offset,st=w.length;for(Y<st&&(st=Y),Y-=st,w.length-=st;Q[at++]=mt[X++],--st;);w.length===0&&(w.mode=21);break;case 26:if(Y===0)break t;Q[at++]=w.length,Y--,w.mode=21;break;case 27:if(w.wrap){for(;N<32;){if(W===0)break t;W--,V|=j[z++]<<N,N+=8}if(rt-=Y,T.total_out+=rt,w.total+=rt,rt&&(T.adler=w.check=w.flags?o(w.check,Q,rt,at-rt):l(w.check,Q,rt,at-rt)),rt=Y,(w.flags?V:v(V))!==w.check){T.msg="incorrect data check",w.mode=30;break}N=V=0}w.mode=28;case 28:if(w.wrap&&w.flags){for(;N<32;){if(W===0)break t;W--,V+=j[z++]<<N,N+=8}if(V!==(4294967295&w.total)){T.msg="incorrect length check",w.mode=30;break}N=V=0}w.mode=29;case 29:F=1;break t;case 30:F=-3;break t;case 31:return-4;case 32:default:return u}return T.next_out=at,T.avail_out=Y,T.next_in=z,T.avail_in=W,w.hold=V,w.bits=N,(w.wsize||rt!==T.avail_out&&w.mode<30&&(w.mode<27||L!==4))&&J(T,T.output,T.next_out,rt-T.avail_out)?(w.mode=31,-4):(ct-=T.avail_in,rt-=T.avail_out,T.total_in+=ct,T.total_out+=rt,w.total+=rt,w.wrap&&rt&&(T.adler=w.check=w.flags?o(w.check,Q,rt,T.next_out-rt):l(w.check,Q,rt,T.next_out-rt)),T.data_type=w.bits+(w.last?64:0)+(w.mode===12?128:0)+(w.mode===20||w.mode===15?256:0),(ct==0&&rt===0||L===4)&&F===g&&(F=-5),F)},n.inflateEnd=function(T){if(!T||!T.state)return u;var L=T.state;return L.window&&(L.window=null),T.state=null,g},n.inflateGetHeader=function(T,L){var w;return T&&T.state?(2&(w=T.state).wrap)==0?u:((w.head=L).done=!1,g):u},n.inflateSetDictionary=function(T,L){var w,j=L.length;return T&&T.state?(w=T.state).wrap!==0&&w.mode!==11?u:w.mode===11&&l(1,L,j,0)!==w.check?-3:J(T,L,j,j)?(w.mode=31,-4):(w.havedict=1,g):u},n.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(e,s,n){var r=e("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],o=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];s.exports=function(d,h,g,u,y,p,b,v){var k,S,A,x,_,C,B,M,R,J=v.bits,T=0,L=0,w=0,j=0,Q=0,z=0,at=0,W=0,Y=0,V=0,N=null,ct=0,rt=new r.Buf16(16),st=new r.Buf16(16),X=null,mt=0;for(T=0;T<=15;T++)rt[T]=0;for(L=0;L<u;L++)rt[h[g+L]]++;for(Q=J,j=15;1<=j&&rt[j]===0;j--);if(j<Q&&(Q=j),j===0)return y[p++]=20971520,y[p++]=20971520,v.bits=1,0;for(w=1;w<j&&rt[w]===0;w++);for(Q<w&&(Q=w),T=W=1;T<=15;T++)if(W<<=1,(W-=rt[T])<0)return-1;if(0<W&&(d===0||j!==1))return-1;for(st[1]=0,T=1;T<15;T++)st[T+1]=st[T]+rt[T];for(L=0;L<u;L++)h[g+L]!==0&&(b[st[h[g+L]]++]=L);if(C=d===0?(N=X=b,19):d===1?(N=l,ct-=257,X=o,mt-=257,256):(N=a,X=c,-1),T=w,_=p,at=L=V=0,A=-1,x=(Y=1<<(z=Q))-1,d===1&&852<Y||d===2&&592<Y)return 1;for(;;){for(B=T-at,R=b[L]<C?(M=0,b[L]):b[L]>C?(M=X[mt+b[L]],N[ct+b[L]]):(M=96,0),k=1<<T-at,w=S=1<<z;y[_+(V>>at)+(S-=k)]=B<<24|M<<16|R|0,S!==0;);for(k=1<<T-1;V&k;)k>>=1;if(k!==0?(V&=k-1,V+=k):V=0,L++,--rt[T]==0){if(T===j)break;T=h[g+b[L]]}if(Q<T&&(V&x)!==A){for(at===0&&(at=Q),_+=w,W=1<<(z=T-at);z+at<j&&!((W-=rt[z+at])<=0);)z++,W<<=1;if(Y+=1<<z,d===1&&852<Y||d===2&&592<Y)return 1;y[A=V&x]=Q<<24|z<<16|_-p|0}}return V!==0&&(y[_+V]=T-at<<24|64<<16|0),v.bits=Q,0}},{"../utils/common":41}],51:[function(e,s,n){s.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(e,s,n){var r=e("../utils/common"),l=0,o=1;function a(I){for(var D=I.length;0<=--D;)I[D]=0}var c=0,d=29,h=256,g=h+1+d,u=30,y=19,p=2*g+1,b=15,v=16,k=7,S=256,A=16,x=17,_=18,C=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],B=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],M=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],R=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],J=new Array(2*(g+2));a(J);var T=new Array(2*u);a(T);var L=new Array(512);a(L);var w=new Array(256);a(w);var j=new Array(d);a(j);var Q,z,at,W=new Array(u);function Y(I,D,K,H,U){this.static_tree=I,this.extra_bits=D,this.extra_base=K,this.elems=H,this.max_length=U,this.has_stree=I&&I.length}function V(I,D){this.dyn_tree=I,this.max_code=0,this.stat_desc=D}function N(I){return I<256?L[I]:L[256+(I>>>7)]}function ct(I,D){I.pending_buf[I.pending++]=255&D,I.pending_buf[I.pending++]=D>>>8&255}function rt(I,D,K){I.bi_valid>v-K?(I.bi_buf|=D<<I.bi_valid&65535,ct(I,I.bi_buf),I.bi_buf=D>>v-I.bi_valid,I.bi_valid+=K-v):(I.bi_buf|=D<<I.bi_valid&65535,I.bi_valid+=K)}function st(I,D,K){rt(I,K[2*D],K[2*D+1])}function X(I,D){for(var K=0;K|=1&I,I>>>=1,K<<=1,0<--D;);return K>>>1}function mt(I,D,K){var H,U,G=new Array(b+1),it=0;for(H=1;H<=b;H++)G[H]=it=it+K[H-1]<<1;for(U=0;U<=D;U++){var tt=I[2*U+1];tt!==0&&(I[2*U]=X(G[tt]++,tt))}}function gt(I){var D;for(D=0;D<g;D++)I.dyn_ltree[2*D]=0;for(D=0;D<u;D++)I.dyn_dtree[2*D]=0;for(D=0;D<y;D++)I.bl_tree[2*D]=0;I.dyn_ltree[2*S]=1,I.opt_len=I.static_len=0,I.last_lit=I.matches=0}function Z(I){8<I.bi_valid?ct(I,I.bi_buf):0<I.bi_valid&&(I.pending_buf[I.pending++]=I.bi_buf),I.bi_buf=0,I.bi_valid=0}function ot(I,D,K,H){var U=2*D,G=2*K;return I[U]<I[G]||I[U]===I[G]&&H[D]<=H[K]}function ut(I,D,K){for(var H=I.heap[K],U=K<<1;U<=I.heap_len&&(U<I.heap_len&&ot(D,I.heap[U+1],I.heap[U],I.depth)&&U++,!ot(D,H,I.heap[U],I.depth));)I.heap[K]=I.heap[U],K=U,U<<=1;I.heap[K]=H}function E(I,D,K){var H,U,G,it,tt=0;if(I.last_lit!==0)for(;H=I.pending_buf[I.d_buf+2*tt]<<8|I.pending_buf[I.d_buf+2*tt+1],U=I.pending_buf[I.l_buf+tt],tt++,H===0?st(I,U,D):(st(I,(G=w[U])+h+1,D),(it=C[G])!==0&&rt(I,U-=j[G],it),st(I,G=N(--H),K),(it=B[G])!==0&&rt(I,H-=W[G],it)),tt<I.last_lit;);st(I,S,D)}function P(I,D){var K,H,U,G=D.dyn_tree,it=D.stat_desc.static_tree,tt=D.stat_desc.has_stree,dt=D.stat_desc.elems,xt=-1;for(I.heap_len=0,I.heap_max=p,K=0;K<dt;K++)G[2*K]!==0?(I.heap[++I.heap_len]=xt=K,I.depth[K]=0):G[2*K+1]=0;for(;I.heap_len<2;)G[2*(U=I.heap[++I.heap_len]=xt<2?++xt:0)]=1,I.depth[U]=0,I.opt_len--,tt&&(I.static_len-=it[2*U+1]);for(D.max_code=xt,K=I.heap_len>>1;1<=K;K--)ut(I,G,K);for(U=dt;K=I.heap[1],I.heap[1]=I.heap[I.heap_len--],ut(I,G,1),H=I.heap[1],I.heap[--I.heap_max]=K,I.heap[--I.heap_max]=H,G[2*U]=G[2*K]+G[2*H],I.depth[U]=(I.depth[K]>=I.depth[H]?I.depth[K]:I.depth[H])+1,G[2*K+1]=G[2*H+1]=U,I.heap[1]=U++,ut(I,G,1),2<=I.heap_len;);I.heap[--I.heap_max]=I.heap[1],(function(bt,Mt){var Vt,Yt,ee,Nt,Ke,te,Jt=Mt.dyn_tree,mi=Mt.max_code,Bi=Mt.stat_desc.static_tree,gs=Mt.stat_desc.has_stree,vs=Mt.stat_desc.extra_bits,Tn=Mt.stat_desc.extra_base,gi=Mt.stat_desc.max_length,Di=0;for(Nt=0;Nt<=b;Nt++)bt.bl_count[Nt]=0;for(Jt[2*bt.heap[bt.heap_max]+1]=0,Vt=bt.heap_max+1;Vt<p;Vt++)gi<(Nt=Jt[2*Jt[2*(Yt=bt.heap[Vt])+1]+1]+1)&&(Nt=gi,Di++),Jt[2*Yt+1]=Nt,mi<Yt||(bt.bl_count[Nt]++,Ke=0,Tn<=Yt&&(Ke=vs[Yt-Tn]),te=Jt[2*Yt],bt.opt_len+=te*(Nt+Ke),gs&&(bt.static_len+=te*(Bi[2*Yt+1]+Ke)));if(Di!==0){do{for(Nt=gi-1;bt.bl_count[Nt]===0;)Nt--;bt.bl_count[Nt]--,bt.bl_count[Nt+1]+=2,bt.bl_count[gi]--,Di-=2}while(0<Di);for(Nt=gi;Nt!==0;Nt--)for(Yt=bt.bl_count[Nt];Yt!==0;)mi<(ee=bt.heap[--Vt])||(Jt[2*ee+1]!==Nt&&(bt.opt_len+=(Nt-Jt[2*ee+1])*Jt[2*ee],Jt[2*ee+1]=Nt),Yt--)}})(I,D),mt(G,xt,I.bl_count)}function f(I,D,K){var H,U,G=-1,it=D[1],tt=0,dt=7,xt=4;for(it===0&&(dt=138,xt=3),D[2*(K+1)+1]=65535,H=0;H<=K;H++)U=it,it=D[2*(H+1)+1],++tt<dt&&U===it||(tt<xt?I.bl_tree[2*U]+=tt:U!==0?(U!==G&&I.bl_tree[2*U]++,I.bl_tree[2*A]++):tt<=10?I.bl_tree[2*x]++:I.bl_tree[2*_]++,G=U,xt=(tt=0)===it?(dt=138,3):U===it?(dt=6,3):(dt=7,4))}function F(I,D,K){var H,U,G=-1,it=D[1],tt=0,dt=7,xt=4;for(it===0&&(dt=138,xt=3),H=0;H<=K;H++)if(U=it,it=D[2*(H+1)+1],!(++tt<dt&&U===it)){if(tt<xt)for(;st(I,U,I.bl_tree),--tt!=0;);else U!==0?(U!==G&&(st(I,U,I.bl_tree),tt--),st(I,A,I.bl_tree),rt(I,tt-3,2)):tt<=10?(st(I,x,I.bl_tree),rt(I,tt-3,3)):(st(I,_,I.bl_tree),rt(I,tt-11,7));G=U,xt=(tt=0)===it?(dt=138,3):U===it?(dt=6,3):(dt=7,4)}}a(W);var O=!1;function $(I,D,K,H){rt(I,(c<<1)+(H?1:0),3),(function(U,G,it,tt){Z(U),ct(U,it),ct(U,~it),r.arraySet(U.pending_buf,U.window,G,it,U.pending),U.pending+=it})(I,D,K)}n._tr_init=function(I){O||((function(){var D,K,H,U,G,it=new Array(b+1);for(U=H=0;U<d-1;U++)for(j[U]=H,D=0;D<1<<C[U];D++)w[H++]=U;for(w[H-1]=U,U=G=0;U<16;U++)for(W[U]=G,D=0;D<1<<B[U];D++)L[G++]=U;for(G>>=7;U<u;U++)for(W[U]=G<<7,D=0;D<1<<B[U]-7;D++)L[256+G++]=U;for(K=0;K<=b;K++)it[K]=0;for(D=0;D<=143;)J[2*D+1]=8,D++,it[8]++;for(;D<=255;)J[2*D+1]=9,D++,it[9]++;for(;D<=279;)J[2*D+1]=7,D++,it[7]++;for(;D<=287;)J[2*D+1]=8,D++,it[8]++;for(mt(J,g+1,it),D=0;D<u;D++)T[2*D+1]=5,T[2*D]=X(D,5);Q=new Y(J,C,h+1,g,b),z=new Y(T,B,0,u,b),at=new Y(new Array(0),M,0,y,k)})(),O=!0),I.l_desc=new V(I.dyn_ltree,Q),I.d_desc=new V(I.dyn_dtree,z),I.bl_desc=new V(I.bl_tree,at),I.bi_buf=0,I.bi_valid=0,gt(I)},n._tr_stored_block=$,n._tr_flush_block=function(I,D,K,H){var U,G,it=0;0<I.level?(I.strm.data_type===2&&(I.strm.data_type=(function(tt){var dt,xt=4093624447;for(dt=0;dt<=31;dt++,xt>>>=1)if(1&xt&&tt.dyn_ltree[2*dt]!==0)return l;if(tt.dyn_ltree[18]!==0||tt.dyn_ltree[20]!==0||tt.dyn_ltree[26]!==0)return o;for(dt=32;dt<h;dt++)if(tt.dyn_ltree[2*dt]!==0)return o;return l})(I)),P(I,I.l_desc),P(I,I.d_desc),it=(function(tt){var dt;for(f(tt,tt.dyn_ltree,tt.l_desc.max_code),f(tt,tt.dyn_dtree,tt.d_desc.max_code),P(tt,tt.bl_desc),dt=y-1;3<=dt&&tt.bl_tree[2*R[dt]+1]===0;dt--);return tt.opt_len+=3*(dt+1)+5+5+4,dt})(I),U=I.opt_len+3+7>>>3,(G=I.static_len+3+7>>>3)<=U&&(U=G)):U=G=K+5,K+4<=U&&D!==-1?$(I,D,K,H):I.strategy===4||G===U?(rt(I,2+(H?1:0),3),E(I,J,T)):(rt(I,4+(H?1:0),3),(function(tt,dt,xt,bt){var Mt;for(rt(tt,dt-257,5),rt(tt,xt-1,5),rt(tt,bt-4,4),Mt=0;Mt<bt;Mt++)rt(tt,tt.bl_tree[2*R[Mt]+1],3);F(tt,tt.dyn_ltree,dt-1),F(tt,tt.dyn_dtree,xt-1)})(I,I.l_desc.max_code+1,I.d_desc.max_code+1,it+1),E(I,I.dyn_ltree,I.dyn_dtree)),gt(I),H&&Z(I)},n._tr_tally=function(I,D,K){return I.pending_buf[I.d_buf+2*I.last_lit]=D>>>8&255,I.pending_buf[I.d_buf+2*I.last_lit+1]=255&D,I.pending_buf[I.l_buf+I.last_lit]=255&K,I.last_lit++,D===0?I.dyn_ltree[2*K]++:(I.matches++,D--,I.dyn_ltree[2*(w[K]+h+1)]++,I.dyn_dtree[2*N(D)]++),I.last_lit===I.lit_bufsize-1},n._tr_align=function(I){rt(I,2,3),st(I,S,J),(function(D){D.bi_valid===16?(ct(D,D.bi_buf),D.bi_buf=0,D.bi_valid=0):8<=D.bi_valid&&(D.pending_buf[D.pending++]=255&D.bi_buf,D.bi_buf>>=8,D.bi_valid-=8)})(I)}},{"../utils/common":41}],53:[function(e,s,n){s.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(e,s,n){(function(r){(function(l,o){if(!l.setImmediate){var a,c,d,h,g=1,u={},y=!1,p=l.document,b=Object.getPrototypeOf&&Object.getPrototypeOf(l);b=b&&b.setTimeout?b:l,a={}.toString.call(l.process)==="[object process]"?function(A){process.nextTick(function(){k(A)})}:(function(){if(l.postMessage&&!l.importScripts){var A=!0,x=l.onmessage;return l.onmessage=function(){A=!1},l.postMessage("","*"),l.onmessage=x,A}})()?(h="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",S,!1):l.attachEvent("onmessage",S),function(A){l.postMessage(h+A,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(A){k(A.data)},function(A){d.port2.postMessage(A)}):p&&"onreadystatechange"in p.createElement("script")?(c=p.documentElement,function(A){var x=p.createElement("script");x.onreadystatechange=function(){k(A),x.onreadystatechange=null,c.removeChild(x),x=null},c.appendChild(x)}):function(A){setTimeout(k,0,A)},b.setImmediate=function(A){typeof A!="function"&&(A=new Function(""+A));for(var x=new Array(arguments.length-1),_=0;_<x.length;_++)x[_]=arguments[_+1];var C={callback:A,args:x};return u[g]=C,a(g),g++},b.clearImmediate=v}function v(A){delete u[A]}function k(A){if(y)setTimeout(k,0,A);else{var x=u[A];if(x){y=!0;try{(function(_){var C=_.callback,B=_.args;switch(B.length){case 0:C();break;case 1:C(B[0]);break;case 2:C(B[0],B[1]);break;case 3:C(B[0],B[1],B[2]);break;default:C.apply(o,B)}})(x)}finally{v(A),y=!1}}}}function S(A){A.source===l&&typeof A.data=="string"&&A.data.indexOf(h)===0&&k(+A.data.slice(h.length))}})(typeof self>"u"?r===void 0?this:r:self)}).call(this,typeof zn<"u"?zn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Ms)),Ms.exports}var Kg=Vg();const qg=Wg(Kg),Gg=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,Zg=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function Yg(t){const i=await qg.loadAsync(t),e={},s=[];let n="",r="";const l=[];i.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let o=l.find(a=>a.path.toLowerCase()==="slides.md");o||(o=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),o||(o=l.find(a=>a.path.toLowerCase().endsWith(".md"))),o&&(n=await o.file.async("string"),r=o.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||Zg.test(c)||c.includes("snippets/")){const d=await a.file.async("string");e[c]=d;const h=c.split("/");h.length>1&&(e[h.slice(1).join("/")]=d)}else if(Gg.test(c)){const d=await a.file.async("uint8array"),h=c.split("/").pop()||c,g=typeof Blob<"u"?new Blob([d]):void 0;s.push({zipPath:c,fileName:h,data:d,blob:g})}}return{entryMarkdown:n,entryMarkdownPath:r,virtualFiles:e,assets:s}}function Jg(t,i){if(Object.keys(i).length===0)return t;function e(n){const r=n.trim().replace(/^['"]|['"]$/g,""),l=r.split("/").pop()||r;if(i[r])return i[r];const o=r.replace(/^\.?\//,"");return i[o]?i[o]:i[l]?i[l]:null}function s(n){let r=n;return r=r.replace(/!\[(.*?)\]\((.*?)\)/g,(l,o,a)=>{const c=e(a);return c?`![${o}](${c})`:l}),r=r.replace(/\bsrc=["'](.*?)["']/gi,(l,o)=>{const a=e(o);return a?`src="${a}"`:l}),r}for(const n of t.slides)if(n.rawMarkdown=s(n.rawMarkdown),n.pageAttrs["custom-slidev-background"]){const r=n.pageAttrs["custom-slidev-background"],l=e(r);l&&(n.pageAttrs["custom-slidev-background"]=l)}if(t.flattenedMarkdown=s(t.flattenedMarkdown),t.docRootAttrs["custom-slidev-background"]){const n=t.docRootAttrs["custom-slidev-background"],r=e(n);r&&(t.docRootAttrs["custom-slidev-background"]=r)}return t}function Ql(t){try{if(typeof process<"u"&&typeof require<"u"){const i=require("fs");if(i.existsSync(t))return i.readFileSync(t,"utf-8")}}catch{}return null}function Xg(t,i){const e=t.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!e)return null;const s=e[1].trim(),n=s.indexOf("#"),r=n!==-1?s.slice(0,n):s,l=n!==-1?s.slice(n+1):"",o=r.replace(/^@\//,"").replace(/^\.\//,""),a=(i==null?void 0:i.virtualFiles)||{};let c=a[r]||a[o]||a[`./${o}`]||a[`@/${o}`];if(!c&&Object.keys(a).length>0){const u=o.split("/").pop();for(const[y,p]of Object.entries(a))if(y.endsWith(`/${o}`)||u&&y.endsWith(`/${u}`)){c=p;break}}if(!c){const u=[];if(i!=null&&i.baseDir)try{const y=require("path");u.push(y.resolve(i.baseDir,o)),u.push(y.resolve(i.baseDir,r))}catch{}try{const y=require("path");u.push(y.resolve(process.cwd(),o))}catch{}for(const y of u){const p=Ql(y);if(p!==null){c=p;break}}}if(!c){const u=Wl||{};if(c=u[r]||u[o]||u[`snippets/${o}`],!c){const y=o.split("/").pop();for(const[p,b]of Object.entries(u))if(p.endsWith(`/${o}`)||y&&p.endsWith(`/${y}`)){c=b;break}}}if(!c)return null;let d=c;if(l){const u=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),y=c.match(u);if(y){const p=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(p?p[1]:"")+y[1].trimEnd()}}const h=o.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${h?h[1]:""}
${d}
\`\`\``}function Qg(t){let i=!1,e=!1;for(let s=0;s<t.length;s++){const n=t[s];if(n==="'"&&!e)i=!i;else if(n==='"'&&!i)e=!e;else if(n==="#"&&!i&&!e)return t.slice(0,s).trim()}return t.trim()}function Wn(t){const i={},e=t.split(/\r?\n/);let s=0;for(;s<e.length;){const n=e[s],r=n.trim();if(!r||r.startsWith("#")){s++;continue}const l=n.indexOf(":");if(l>0){const o=n.slice(0,l).trim();let a=n.slice(l+1).trim();if(a==="|"||a===">"){s++;const c=[];let d=-1;for(;s<e.length;){const h=e[s];if(!h.trim()){c.push(""),s++;continue}const u=h.match(/^(\s+)/),y=u?u[1].length:0;if(d===-1&&(d=y),y<d)break;c.push(h.slice(d)),s++}for(;c.length>0&&c[c.length-1]==="";)c.pop();i[o]=a===">"?c.join(" "):c.join(`
`);continue}if(a=Qg(a),!a){let c=s+1;const d=[];let h=-1;for(;c<e.length;){const g=e[c],u=g.trim();if(!u||u.startsWith("#")){h!==-1&&d.push(""),c++;continue}const y=g.match(/^(\s+)/),p=y?y[1].length:0;if(h===-1)if(p>0)h=p;else break;if(p<h)break;d.push(g.slice(h)),c++}if(d.length>0){i[o]=Wn(d.join(`
`)),s=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),i[o]=a}s++}return i}const tv=/^\s*```ya?ml([\s\S]*?)```/;function kr(t){let i={},e=t.trim();const s=e.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(s&&!s[1].includes("```")){const r=Wn(s[1]);if(Object.keys(r).length>0||!s[1].trim())return i=r,e=e.slice(s[0].length).trim(),{frontmatter:i,content:e}}if(e.startsWith("---")){const r=e.match(/^---[^\n\r]*(?:\r?\n|$)/);r&&(e=e.slice(r[0].length).trim())}const n=e.match(tv);if(n)i=Wn(n[1]),e=e.slice(n[0].length).trim();else{const r=e.split(/\r?\n/),l=[];let o=0;for(let a=0;a<r.length;a++){const c=r[a].trim();if(!c){if(l.length>0){o=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{o=a;break}}l.length>0&&(i=Wn(l.join(`
`)),e=r.slice(o).join(`
`).trim())}return{frontmatter:i,content:e}}function ev(t){const i=t.split(/\r?\n/),e=[];let s=0,n=!1;function r(l){if(s>=l)return;const o=i.slice(s,l).join(`
`).trim();o&&e.push(o),s=l+1}for(let l=0;l<i.length;l++){const a=i[l].trimEnd();if(n){a.includes("-->")&&(n=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(n=!0);continue}if(a.startsWith("---")){r(l);const c=i[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(s=l,l+=1;l<i.length&&i[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let h=l+1;for(;h<i.length&&!i[h].trimStart().startsWith(d);h++);h<i.length&&(l=h)}}return s<i.length&&r(i.length),e}function Vn(t,i={}){const{stripNotesFromMarkdown:e=!0,cleanVClicks:s=!0,cleanShikiLines:n=!0,cleanSlots:r=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:o=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=i;let d=t;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const h=ev(d),g={};let u="",y="",p=0;if(h.length>0){const R=h[0],J=kr(R),T=Object.keys(J.frontmatter).length>0,L=J.content.length>0;T&&!L&&h.length>1?(p=1,b(J.frontmatter)):T&&b(J.frontmatter)}function b(R){u=R.title||"",R.theme&&(g[rn]=String(R.theme)),R.aspectRatio&&(g[ln]=String(R.aspectRatio)),R.highlighter&&(g[Cr]=String(R.highlighter)),R.transition&&(g[an]=String(R.transition)),R.colorSchema&&(g[$r]=String(R.colorSchema)),R.layout&&(g[ft]=String(R.layout)),R.background&&(g[Ut]=String(R.background)),R.image&&(g[Ae]=String(R.image)),R.class&&(g[Ni]=String(R.class));for(const[J,T]of Object.entries(R))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(J)||(g[`custom-slidev-${J}`]=typeof T=="object"?JSON.stringify(T):String(T))}const v=[];let k=0,S=0,A=0,x=0;const _=new Set,C={};let B=1;for(let R=p;R<h.length;R++){const J=h[R],{frontmatter:T,content:L}=kr(J),w=J.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),j=T.src||(w?w[1]:void 0);if(j){const Z=String(j).trim().replace(/^['"]|['"]$/g,"");let ot=c[Z]||c[Z.replace(/^\.\//,"")]||c[`pages/${Z.replace(/^.*pages\//,"")}`];if(!ot){const E=Z.replace(/^\.\//,""),P=[];if(i.baseDir)try{const f=require("path");P.push(f.resolve(i.baseDir,E)),P.push(f.resolve(i.baseDir,Z))}catch{}try{const f=require("path");P.push(f.resolve(process.cwd(),E)),P.push(f.resolve(process.cwd(),Z))}catch{}for(const f of P){const F=Ql(f);if(F!==null){ot=F;break}}}const ut={};T.layout&&(ut[ft]=String(T.layout)),T.transition&&(ut[Xt]=String(T.transition)),T.background&&(ut[Ut]=String(T.background)),T.image&&(ut[Ae]=String(T.image)),T.class&&(ut[Ni]=String(T.class));for(const[E,P]of Object.entries(T))["src","layout","transition","background","image","class"].includes(E)||(ut[`custom-slidev-${E}`]=typeof P=="object"?JSON.stringify(P):String(P));if(ot){const E=Vn(ot,{...i,virtualFiles:c});for(const P of E.slides){P.pageIndex=B++,P.pageAttrs={...ut,...P.pageAttrs},v.push(P);const f=P.pageAttrs[ft]||"default";C[f]=(C[f]||0)+1}continue}else{v.push({pageIndex:B++,pageAttrs:{...ut,"custom-slidev-src":Z},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${Z}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const E=ut[ft]||"default";C[E]=(C[E]||0)+1;continue}}const Q={};T.layout&&(Q[ft]=String(T.layout)),T.transition&&(Q[Xt]=String(T.transition)),T.background&&(Q[Ut]=String(T.background)),T.image&&(Q[Ae]=String(T.image)),T.class&&(Q[Ni]=String(T.class));for(const[Z,ot]of Object.entries(T))["layout","transition","background","image","class"].includes(Z)||(Q[`custom-slidev-${Z}`]=typeof ot=="object"?JSON.stringify(ot):String(ot));let z=L;const at=[];let W=z.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,Z=>{const ot=`__CODE_TOKEN_NOTE_${at.length}__`;return at.push(Z),ot});W=W.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,Z=>{const ot=`__CODE_TOKEN_NOTE_${at.length}__`;return at.push(Z),ot});let Y="";const V=Array.from(W.matchAll(/<!--([\s\S]*?)-->/g));if(V.length>0){const Z=V[V.length-1],ot=W.slice(Z.index+Z[0].length).trim();if(!ot||!ot.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const E=Z[1].trim();E.startsWith("TODO:")||(Y=E,k++),e&&(W=W.slice(0,Z.index).trimEnd()+W.slice(Z.index+Z[0].length))}}e&&(W=W.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let Z=0;Z<at.length;Z++)W=W.replace(`__CODE_TOKEN_NOTE_${Z}__`,at[Z]);if(z=W,Y){for(let ut=0;ut<at.length;ut++)Y=Y.replace(`__CODE_TOKEN_NOTE_${ut}__`,at[ut]);const ot=`> [!NOTE] 💡 演讲备注
${Y.split(/\r?\n/).map(ut=>`> ${ut}`).join(`
`)}
{: custom-slidev-note="true"}`;z=z?`${z}

${ot}`:ot}let N=!1;if(/<style\b/i.test(z)){N=!0;const Z=z.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(Z){for(const ot of Z){const ut=ot.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();y=y?`${y}

${ut}`:ut}l&&(z=z.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const ct=z.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);ct&&(S+=ct.length);const rt=z.match(/```\w+\s+\{[^}]+\}/g);rt&&(A+=rt.length);const st=z.match(/::\w+::|<template\s+#[^>]+>/g);if(st&&(x+=st.length),z=z.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,Z=>Xg(Z,{...i,virtualFiles:c})||Z),s&&(z=z.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),n&&(z=z.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),z=z.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),r&&(z=z.replace(/^::\w+::\s*$/gm,"")),o&&(z=Fa(z)),a){let Z=z.trim(),ot="";const ut=Z.lastIndexOf("> [!NOTE] 💡 演讲备注");if(ut!==-1&&(ot=Z.slice(ut),Z=Z.slice(0,ut).trim()),(T.layout==="image-left"||T.layout==="image-right")&&T.image){const E=String(T.image).trim(),P=T.layout==="image-left"?"image-left":"image-right",f=`![配图](${E})
{: custom-slidev-layout="${P}" }`;T.layout==="image-left"?Z=`{{{col

${f}

${Z}

}}}`:Z=`{{{col

${Z}

${f}

}}}`}if(T.background){const P=`![背景图](${String(T.background).trim()})
{: custom-slidev-role="background" }`;Z=Z?`${P}

${Z}`:P}z=ot?`${Z}

${ot}`:Z}const X=iv(z);Q[Ut]&&X.push(Q[Ut]),Q[Ae]&&X.push(Q[Ae]);for(const Z of X)_.add(Z);const mt=/<[A-Z][a-zA-Z0-9]+/.test(z),gt=Q[ft]||(B===1?g[ft]||"cover":"default");C[gt]=(C[gt]||0)+1,v.push({pageIndex:B++,pageAttrs:Q,notes:Y,rawMarkdown:z,hasVueComponent:mt,hasStyleTag:N,assetReferences:X})}if(!u&&v.length>0){const R=v[0].rawMarkdown.match(/^#\s+(.+)$/m);R&&(u=R[1].trim())}y&&(g["custom-slidev-custom-css"]=y);let M=v.map(R=>`---

${R.rawMarkdown}`).join(`

`);return M.trimStart().startsWith("---")||(M=`---

${M.trimStart()}`),{docTitle:u||"Slidev 演示文稿",docRootAttrs:g,slides:v,totalSlides:v.length,stats:{totalNotes:k,totalVClicks:S,totalShikiHighlights:A,totalSlots:x,discoveredAssets:Array.from(_),layoutDistribution:C},flattenedMarkdown:M,customCss:y}}function iv(t){const i=[],e=/!\[.*?\]\((.*?)\)/g;let s;for(;(s=e.exec(t))!==null;){const r=s[1].split(/\s+/)[0].trim();r&&i.push(r)}const n=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(s=n.exec(t))!==null;){const r=s[1].trim();r&&i.push(r)}return i}const nv={class:"spm-import-dialog"},sv={class:"spm-tabs-header"},ov={class:"spm-dialog-body"},rv={key:0,class:"spm-file-section"},lv={key:0,class:"spm-dropzone-prompt"},av={key:1,class:"spm-dropzone-active"},cv={class:"spm-file-badge"},dv={class:"spm-file-size"},uv={key:1,class:"spm-text-section"},fv={key:2,class:"spm-error-banner"},pv={key:3,class:"spm-preview-card"},hv={class:"spm-config-grid"},mv={class:"spm-form-item"},gv={class:"spm-form-item"},vv=["value"],bv={class:"spm-stats-grid"},yv={class:"spm-stat-box"},kv={class:"spm-stat-value"},wv={class:"spm-stat-box"},xv={class:"spm-stat-value"},_v={class:"spm-stat-box"},Sv={class:"spm-stat-value"},Cv={class:"spm-stat-box"},$v={class:"spm-stat-value"},Iv={key:0,class:"spm-chips-row"},Av={class:"spm-options-group"},Tv={class:"spm-checkbox-label"},Ev={class:"spm-checkbox-label"},Mv={class:"spm-checkbox-label"},Bv={class:"spm-checkbox-label"},Dv={class:"spm-dialog-footer"},Lv=["disabled"],Ov=["disabled"],Pv={key:0},Rv={key:1},zv=ye({__name:"SlidevImportDialog",emits:["close","success"],setup(t,{emit:i}){const e=i,s=Qe("plugin"),n=ht("file"),r=ht(!1),l=ht(!1),o=ht(""),a=ht(null),c=ht(null),d=ht(""),h=ht(0),g=ht(""),u=ht([]),y=ht(null),p=ht(""),b=ht([]),v=ht(""),k=ht(!0),S=ht(!0),A=ht(!0),x=ht(!0);async function _(){c.value?await j(c.value):g.value&&Q()}const C=$t(()=>{const W=h.value;if(W===0)return"0 B";const Y=1024,V=["B","KB","MB","GB"],N=Math.floor(Math.log(W)/Math.log(Y));return`${(W/Y**N).toFixed(1)} ${V[N]}`}),B=$t(()=>{var W;return((W=y.value)==null?void 0:W.docRootAttrs["custom-slidev-theme"])||"default"}),M=$t(()=>{var W;return u.value.length>0?u.value.length:((W=y.value)==null?void 0:W.stats.discoveredAssets.length)||0}),R=$t(()=>{var Y;const W=((Y=y.value)==null?void 0:Y.stats.layoutDistribution)||{};return Object.entries(W).map(([V,N])=>({name:V,count:N}))});$n(async()=>{try{const W=await ga();W!=null&&W.notebooks&&Array.isArray(W.notebooks)&&(b.value=W.notebooks.filter(Y=>!Y.closed),b.value.length>0&&(v.value=b.value[0].id))}catch(W){console.warn("获取笔记本列表失败:",W)}});function J(){var W;(W=a.value)==null||W.click()}function T(){c.value=null,d.value="",h.value=0,y.value=null,u.value=[],o.value=""}async function L(W){const Y=W.target;Y.files&&Y.files[0]&&await j(Y.files[0])}async function w(W){var Y;r.value=!1,(Y=W.dataTransfer)!=null&&Y.files&&W.dataTransfer.files[0]&&await j(W.dataTransfer.files[0])}async function j(W){o.value="",c.value=W,d.value=W.name,h.value=W.size;try{if(W.name.toLowerCase().endsWith(".zip")){const V=await W.arrayBuffer(),N=await Yg(V);if(!N.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=N.assets;const ct=Vn(N.entryMarkdown,{stripNotesFromMarkdown:S.value,cleanHtmlToMarkdown:k.value,cleanSlots:!1,virtualFiles:N.virtualFiles});y.value=ct,p.value=ct.docTitle||W.name.replace(/\.zip$/i,"")}else{const V=await W.text();u.value=[];const N=W.path||"",ct=N?N.replace(/[\\/][^\\/]+$/,""):"",rt=Vn(V,{stripNotesFromMarkdown:S.value,cleanHtmlToMarkdown:k.value,cleanSlots:!1,baseDir:ct||void 0});y.value=rt,p.value=rt.docTitle||W.name.replace(/\.md$/i,"")}}catch(Y){console.error("解析文件失败:",Y),o.value=`解析文件失败: ${Y.message||String(Y)}`}}function Q(){if(o.value="",!g.value.trim()){y.value=null;return}try{const W=Vn(g.value,{stripNotesFromMarkdown:S.value,cleanHtmlToMarkdown:k.value,cleanSlots:!1});y.value=W,p.value=W.docTitle||"Slidev 演示文稿"}catch(W){o.value=`解析 Markdown 源码失败: ${W.message||String(W)}`}}async function z(){var W;if(y.value){if(!v.value&&b.value.length>0&&(v.value=b.value[0].id),!v.value){o.value="请先选择目标笔记本";return}l.value=!0,o.value="";try{const Y=y.value,V={};if(A.value&&u.value.length>0){const ot=[];for(const ut of u.value){const E=new File([ut.data],ut.fileName,{type:"application/octet-stream"});ot.push(E)}try{const ut=await ba("/data/assets",ot);if(ut!=null&&ut.succMap)for(const[E,P]of Object.entries(ut.succMap))V[E]=String(P)}catch(ut){console.warn("上传本地静态资产失败，保留原路径:",ut)}}Object.keys(V).length>0&&Jg(Y,V);const N=(p.value.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_"),ct=`/${N}`,rt=await va(v.value,ct,Y.flattenedMarkdown);if(!rt)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const st=((W=Y.slides[0])==null?void 0:W.pageAttrs)||{};await zt(rt,{...st,...Y.docRootAttrs});const X=await Kn(rt).catch(()=>[]),mt=ot=>{if(!ot)return!1;const ut=String(ot.type||"").toLowerCase(),E=String(ot.markdown||"").trim(),P=String(ot.content||"").trim();return ut==="tb"||ut==="thematic-break"||ut==="nodethematicbreak"||E==="---"||E==="***"||P==="---"||P==="***"},gt=X.filter(mt);if(gt.length>=Y.slides.length)for(let ot=0;ot<Y.slides.length;ot++){const ut=Y.slides[ot],E=gt[ot];E&&E.id&&Object.keys(ut.pageAttrs).length>0&&await zt(E.id,ut.pageAttrs)}else for(let ot=1;ot<Y.slides.length;ot++){const ut=Y.slides[ot],E=gt[ot-1];E&&E.id&&Object.keys(ut.pageAttrs).length>0&&await zt(E.id,ut.pageAttrs)}let Z=!1;for(const ot of X){if(mt(ot)){Z=!1;continue}const ut=(ot.markdown||ot.content||"").trim();if(ut==="::right::"||ut.startsWith("::right::")){Z=!0;continue}Z&&ot.id&&await zt(ot.id,{[Tt]:"right"}).catch(()=>{})}vt.showMessage(`🎉 成功导入 Slidev 演示文档《${N}》！`),e("success",{docId:rt}),e("close"),x.value&&s&&(s.currentDocId=rt,await vt.openTab({app:s.app,doc:{id:rt}}),s.openBottomPreviewTab&&s.openBottomPreviewTab())}catch(Y){console.error("导入 Slidev 演示失败:",Y),o.value=`导入执行失败: ${Y.message||String(Y)}`}finally{l.value=!1}}}function at(){e("close")}return(W,Y)=>(et(),nt("div",{class:"spm-modal-overlay",onClick:Te(at,["self"])},[m("div",nv,[m("div",{class:"spm-dialog-header"},[Y[11]||(Y[11]=m("div",{class:"spm-dialog-title"},[m("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[m("use",{"xlink:href":"#iconSlidev"})]),m("span",null,"导入 Slidev 演示文档")],-1)),m("button",{class:"spm-close-btn",title:"关闭",onClick:at},"✕")]),m("div",sv,[m("button",{class:Et(["spm-tab-btn",{active:n.value==="file"}]),onClick:Y[0]||(Y[0]=V=>n.value="file")}," 📦 文件 / 压缩包导入 (.zip / .md) ",2),m("button",{class:Et(["spm-tab-btn",{active:n.value==="text"}]),onClick:Y[1]||(Y[1]=V=>n.value="text")}," 📝 粘贴 Markdown 源码 ",2)]),m("div",ov,[n.value==="file"?(et(),nt("div",rv,[m("div",{class:Et(["spm-dropzone",{dragover:r.value,"has-file":!!d.value}]),onDragover:Y[2]||(Y[2]=Te(V=>r.value=!0,["prevent"])),onDragleave:Y[3]||(Y[3]=Te(V=>r.value=!1,["prevent"])),onDrop:Te(w,["prevent"]),onClick:J},[m("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:L},null,544),d.value?(et(),nt("div",av,[m("span",cv,"📄 "+St(d.value),1),m("span",dv,"("+St(C.value)+")",1),m("button",{class:"spm-btn-text",onClick:Te(T,["stop"])},"更换文件")])):(et(),nt("div",lv,[...Y[12]||(Y[12]=[m("span",{class:"spm-dropzone-icon"},"📁",-1),m("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1),m("p",{class:"spm-dropzone-hint"},[Zs(" 支持 Slidev 完整工程 "),m("strong",null,".zip"),Zs("（自动解包 public/ 静态素材）或单文件 "),m("strong",null,".md")],-1)])]))],34)])):(et(),nt("div",uv,[Ie(m("textarea",{"onUpdate:modelValue":Y[4]||(Y[4]=V=>g.value=V),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:Q},null,544),[[is,g.value]])])),o.value?(et(),nt("div",fv," ⚠️ "+St(o.value),1)):Ft("",!0),y.value?(et(),nt("div",pv,[Y[24]||(Y[24]=m("div",{class:"spm-preview-card__header"},[m("span",null,"✨ 演示解析摘要"),m("span",{class:"spm-badge-success"},"预检就绪")],-1)),m("div",hv,[m("div",mv,[Y[13]||(Y[13]=m("label",{class:"spm-form-label"},"笔记文档标题",-1)),Ie(m("input",{"onUpdate:modelValue":Y[5]||(Y[5]=V=>p.value=V),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[is,p.value]])]),m("div",gv,[Y[14]||(Y[14]=m("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Ie(m("select",{"onUpdate:modelValue":Y[6]||(Y[6]=V=>v.value=V),class:"spm-select"},[(et(!0),nt(Gt,null,ke(b.value,V=>(et(),nt("option",{key:V.id,value:V.id},St(V.name),9,vv))),128))],512),[[uu,v.value]])])]),m("div",bv,[m("div",yv,[m("span",kv,St(y.value.totalSlides),1),Y[15]||(Y[15]=m("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),m("div",wv,[m("span",xv,St(B.value),1),Y[16]||(Y[16]=m("span",{class:"spm-stat-label"},"演示主题",-1))]),m("div",_v,[m("span",Sv,St(y.value.stats.totalNotes),1),Y[17]||(Y[17]=m("span",{class:"spm-stat-label"},"演讲者提词",-1))]),m("div",Cv,[m("span",$v,St(M.value),1),Y[18]||(Y[18]=m("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),R.value.length>0?(et(),nt("div",Iv,[Y[19]||(Y[19]=m("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(et(!0),nt(Gt,null,ke(R.value,V=>(et(),nt("span",{key:V.name,class:"spm-chip-badge"},St(V.name)+": "+St(V.count),1))),128))])):Ft("",!0),m("div",Av,[m("label",Tv,[Ie(m("input",{"onUpdate:modelValue":Y[7]||(Y[7]=V=>k.value=V),type:"checkbox",onChange:_},null,544),[[Rn,k.value]]),Y[20]||(Y[20]=m("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),m("label",Ev,[Ie(m("input",{"onUpdate:modelValue":Y[8]||(Y[8]=V=>S.value=V),type:"checkbox",onChange:_},null,544),[[Rn,S.value]]),Y[21]||(Y[21]=m("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),m("label",Mv,[Ie(m("input",{"onUpdate:modelValue":Y[9]||(Y[9]=V=>A.value=V),type:"checkbox"},null,512),[[Rn,A.value]]),Y[22]||(Y[22]=m("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),m("label",Bv,[Ie(m("input",{"onUpdate:modelValue":Y[10]||(Y[10]=V=>x.value=V),type:"checkbox"},null,512),[[Rn,x.value]]),Y[23]||(Y[23]=m("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Ft("",!0)]),m("div",Dv,[m("button",{class:"spm-btn-secondary",disabled:l.value,onClick:at}," 取消 ",8,Lv),m("button",{class:"spm-btn-primary",disabled:!y.value||l.value,onClick:z},[l.value?(et(),nt("span",Pv,"⏳ 正在导入生成中...")):(et(),nt("span",Rv,"🚀 确认导入思源笔记"))],8,Ov)])])]))}}),Nv=Oe(zv,[["__scopeId","data-v-8771dc8a"]]),Fv={class:"spm-slidev-inspector"},jv={class:"spm-inspector-topbar"},Hv={class:"spm-inspector-title"},Uv={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},Wv={class:"spm-inspector-topbar-actions"},Vv={class:"spm-target-banner"},Kv={class:"spm-target-info"},qv=["aria-label"],Gv={key:0,class:"spm-save-status"},Zv=["title"],Yv={class:"spm-inspector-body"},Jv=ye({__name:"SlidevInspectorDockView",setup(t,{expose:i}){const e=Qe("plugin"),s=ht(!1);function n(q){s.value=!1,c.value=q.docId,e!=null&&e.compileCurrentDocument&&e.compileCurrentDocument(q.docId)}const r=ht(""),l=ht(""),o=ht({}),a=ht(""),c=ht(""),d=ht(""),h=ht(""),g=ht(""),u=ht(null),y=ht(""),p=ht("");let b=null;function v(q="已同步"){y.value=q,b&&window.clearTimeout(b),b=window.setTimeout(()=>{y.value=""},1200)}function k(){var lt;const q=r.value||c.value;q&&(lt=navigator==null?void 0:navigator.clipboard)!=null&&lt.writeText&&navigator.clipboard.writeText(q).then(()=>{p.value="已复制！",setTimeout(()=>{p.value=""},1500)}).catch(()=>{})}const S=$t(()=>l.value==="NodeThematicBreak"),A=$t(()=>l.value==="NodeCodeBlock"),x=ht(!1),_=$t(()=>{if(x.value||D.value)return!0;const q=a.value||"";return!!fi(q)}),C=$t(()=>{const q=l.value||"";if(q==="NodeVideo"||q==="video")return!0;const lt=a.value||"";return!!(/<video\b/i.test(lt)||/\.mp4\b/i.test(lt))}),B=$t(()=>!r.value||r.value===c.value||l.value==="doc"||l.value==="NodeDocument"),M=$t(()=>{const q=r.value||c.value||"";return q.length>8?q.slice(-8):q||"无"}),R=$t(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),J=$t(()=>{if(S.value)return"分页符 (---)";if(B.value)return"全局文档";if(C.value)return"视频块";switch(l.value){case"NodeHeading":return"标题块";case"NodeParagraph":return"段落块";case"NodeCodeBlock":return"代码块";case"NodeVideo":return"视频块";case"NodeList":case"NodeListItem":return"列表项";case"NodeBlockquote":return"引述块";case"NodeTable":return"表格块";case"NodeSuperBlock":case"s":case"sb":return"超级块";default:return"内容块"}}),T=$t(()=>S.value?"tag-divider":B.value?"tag-doc":"tag-block"),L=$t(()=>o.value[ft]||"default"),w=$t(()=>o.value[Xt]||"slide-left"),j=ht(""),Q=ht(""),z=$t(()=>{var At;if(!((At=u.value)!=null&&At.slides)||u.value.slides.length===0)return null;const q=r.value,lt=d.value,yt=h.value;if(yt){let _t=u.value.slides.find(Dt=>Dt.startBlockId===yt);if(_t||(_t=u.value.slides.find(Dt=>{var Lt,Ot;return((Ot=(Lt=Dt.blocks)==null?void 0:Lt[0])==null?void 0:Ot.id)===yt}),_t))return _t}if(q){let _t=u.value.slides.find(Lt=>Lt.startBlockId===q);if(_t||(_t=u.value.slides.find(Lt=>{var Ot,Zt;return((Ot=Lt.blocks)==null?void 0:Ot.some(Bt=>Bt.id===q))||((Zt=Lt.allBlockIds)==null?void 0:Zt.includes(q))}),_t)||lt&&lt!==q&&(_t=u.value.slides.find(Lt=>{var Ot,Zt;return((Ot=Lt.blocks)==null?void 0:Ot.some(Bt=>Bt.id===lt))||((Zt=Lt.allBlockIds)==null?void 0:Zt.includes(lt))}),_t)||(_t=u.value.slides.find(Lt=>{var Ot;return(Ot=Lt.noteBlocks)==null?void 0:Ot.some(Zt=>Zt.id===q||Zt.id===lt)}),_t))return _t;const Dt=o.value[Tt];if(Dt&&["col-1","col-2","col-3"].includes(Dt)&&(_t=u.value.slides.find(Lt=>{var Ot,Zt;return((Ot=Lt.frontmatter)==null?void 0:Ot.layout)==="three-cols-header"||((Zt=Lt.blocks)==null?void 0:Zt.some(Bt=>Bt.slot==="col-1"||Bt.slot==="col-2"||Bt.slot==="col-3"))}),_t))return _t}return u.value.slides[0]||null}),at=$t(()=>{var q;return((q=z.value)==null?void 0:q.notes)||""}),W=$t(()=>{var q,lt,yt;return((yt=(lt=(q=z.value)==null?void 0:q.noteBlocks)==null?void 0:lt[0])==null?void 0:yt.id)||""}),Y=$t(()=>{var At,_t,Dt,Lt,Ot,Zt;if(S.value){const Bt=o.value[ft]||o.value["custom-slidev-layout"];if(Bt)return Bt}const q=o.value[Tt]||o.value["custom-slidev-slot"];if(q&&["col-1","col-2","col-3"].includes(q))return"three-cols-header";if(g.value)return g.value;const lt=h.value||(S.value?r.value:"");if(lt){const Bt=Ht.getBlockAttrOverride(lt);if(Bt!=null&&Bt[ft])return Bt[ft]}if(lt&&((At=u.value)!=null&&At.slides)){const Bt=u.value.slides.find(li=>li.startBlockId===lt);if((_t=Bt==null?void 0:Bt.frontmatter)!=null&&_t.layout)return Bt.frontmatter.layout}if((Lt=(Dt=z.value)==null?void 0:Dt.frontmatter)!=null&&Lt.layout)return z.value.frontmatter.layout;if((Zt=(Ot=z.value)==null?void 0:Ot.blocks)!=null&&Zt.some(Bt=>Bt.slot==="col-1"||Bt.slot==="col-2"||Bt.slot==="col-3"))return"three-cols-header";const yt=Ht.getBlockAttrOverride(c.value);return yt!=null&&yt[ft]?yt[ft]:"default"}),V=$t(()=>{var q;return((q=z.value)==null?void 0:q.pageIndex)||1}),N=$t(()=>!!(o.value[ie]||o.value["slidev-note"])),ct=$t(()=>{var lt;if(o.value[Se])return o.value[Se];const q=r.value;if(q&&((lt=z.value)!=null&&lt.blocks)){const yt=z.value.blocks.find(At=>At.id===q);if(yt!=null&&yt.clicks)return yt.clicks}return""}),rt=$t(()=>{var lt;if(o.value[He])return o.value[He];const q=r.value;if(q&&((lt=z.value)!=null&&lt.blocks)){const yt=z.value.blocks.find(At=>At.id===q);if(yt!=null&&yt.motion)return typeof yt.motion=="string"?yt.motion:JSON.stringify(yt.motion)}return""}),st=$t(()=>{var lt;if(o.value[Tt])return o.value[Tt];const q=r.value;if(q&&((lt=z.value)!=null&&lt.blocks)){const yt=z.value.blocks.find(At=>At.id===q);if(yt!=null&&yt.slot)return yt.slot}return""}),X=ht(""),mt=ht(""),gt=$t(()=>o.value[vi]==="true"),Z=$t(()=>o.value[Mn]==="true"),ot=$t(()=>o.value[Li]==="true"),ut=$t(()=>o.value[Bn]!=="false");async function E(){(gt.value?"false":"true")==="true"?(await H({[vi]:"true",[Li]:"true"}),o.value[vi]="true",o.value[Li]="true"):(await G(vi,"false"),o.value[vi]="false")}async function P(){const q=Z.value?"false":"true";await G(Mn,q)}async function f(){const q=ot.value?"false":"true";await G(Li,q)}async function F(){const q=ut.value?"false":"true";await G(Bn,q)}const O=$t(()=>{var q,lt;return((lt=(q=u.value)==null?void 0:q.config)==null?void 0:lt.theme)||o.value[rn]||"default"}),$=$t(()=>{var q,lt;return((lt=(q=u.value)==null?void 0:q.config)==null?void 0:lt.aspectRatio)||o.value[ln]||"16/9"}),I=$t(()=>{var q,lt;return((lt=(q=u.value)==null?void 0:q.config)==null?void 0:lt.defaultTransition)||o.value[an]||"slide-left"}),D=$t(()=>{var _t,Dt;if((o.value[qt]||o.value["slidev-role"])===Ir||o.value[Ut]==="true")return"background";const lt=o.value[ft]||o.value["slidev-layout"];if(lt==="image-left"||lt==="image-right")return lt;const yt=a.value||"",At=fi(yt);if(At&&((Dt=(_t=z.value)==null?void 0:_t.frontmatter)!=null&&Dt.background)){const Lt=z.value.frontmatter.background;if(Lt===At||Lt.endsWith(At)||At.endsWith(Lt))return"background"}return""});async function K(q){var Dt;const lt=r.value;if(!lt)return;const yt=a.value||"",At=fi(yt)||"",_t=h.value||c.value;if(q)if(q==="background"){const Lt={[qt]:"background",[ft]:""};_t&&At&&(j.value=At,await zt(_t,{[Ut]:At}).catch(()=>{}),Ht.setBlockAttrOverride(_t,{[Ut]:At}),se(_t,{[Ut]:At}),z.value&&(z.value.frontmatter||(z.value.frontmatter={}),z.value.frontmatter.background=At)),await H(Lt)}else(q==="image-left"||q==="image-right")&&await H({[ft]:q,[qt]:""});else{const Lt={[qt]:"",[ft]:""};if(o.value[Ut]==="true"&&(Lt[Ut]=""),_t&&At&&j.value===At&&(j.value="",await zt(_t,{[Ut]:""}).catch(()=>{}),Ht.setBlockAttrOverride(_t,{[Ut]:""}),se(_t,{[Ut]:""}),(Dt=z.value)!=null&&Dt.frontmatter&&delete z.value.frontmatter.background),await H(Lt),typeof document<"u"){const Ot=document.querySelector(`.protyle-wysiwyg [data-node-id="${lt}"]`),Zt=Ot==null?void 0:Ot.closest('[data-type="NodeListItem"]'),Bt=Zt==null?void 0:Zt.getAttribute("data-node-id");if(Bt&&Bt!==lt){const li={[ft]:"",[qt]:""};se(Bt,li),Ht.setBlockAttrOverride(Bt,li),await zt(Bt,li).catch(()=>{})}}}}async function H(q){const lt=r.value||c.value;if(lt){for(const[yt,At]of Object.entries(q))o.value[yt]=At;if(Ht.setBlockAttrOverride(lt,q),se(lt,q),ft in q){const yt=q[ft];g.value=yt,z.value&&(z.value.frontmatter||(z.value.frontmatter={}),z.value.frontmatter.layout=yt)}v("保存中...");try{await zt(lt,q),v("已同步"),e&&await e.compileCurrentDocument()}catch{v("同步失败")}}}const U=$t(()=>!!(o.value[Se]||o.value[He]||o.value[Tt]||o.value[Si]||o.value[ie]||o.value["slidev-note"]||o.value[qt]||o.value[ft]||o.value[vi]||o.value[Mn]||o.value[Li]||o.value[Bn]));async function G(q,lt){const yt=r.value||c.value;if(yt){o.value[q]=lt,Ht.setBlockAttrOverride(yt,{[q]:lt}),se(yt,{[q]:lt}),q===ft&&(g.value=lt,z.value&&(z.value.frontmatter||(z.value.frontmatter={}),z.value.frontmatter.layout=lt)),v("保存中...");try{await zt(yt,{[q]:lt}),v("已同步"),e&&await e.compileCurrentDocument()}catch{v("同步失败")}}}async function it(q,lt){var At;const yt=c.value||r.value;if(yt){o.value[q]=lt,Ht.setBlockAttrOverride(yt,{[q]:lt}),se(yt,{[q]:lt}),(At=u.value)!=null&&At.config&&(q===rn&&(u.value.config.theme=lt),q===ln&&(u.value.config.aspectRatio=lt),q===an&&(u.value.config.defaultTransition=lt)),v("更新中...");try{await zt(yt,{[q]:lt}),v("已更新"),e&&await e.compileCurrentDocument(yt)}catch{v("更新失败")}}}function tt(q){G(ft,q)}function dt(q){G(Xt,q)}function xt(q){j.value=q,G(Ut,q)}function bt(q){Q.value=q,G(Ae,q)}async function Mt(){const q=r.value;if(q)if(N.value){v("取消中...");try{await zt(q,{[ie]:"","slidev-note":""}),Ht.setBlockAttrOverride(q,{[ie]:"","slidev-note":""}),se(q,{[ie]:"","slidev-note":""}),delete o.value[ie],delete o.value["slidev-note"],v("已取消备注"),vt.showMessage("已取消讲稿备注"),e&&await e.compileCurrentDocument()}catch(lt){console.error("[SiYuanSlidev] 取消讲稿备注失败:",lt),v("取消失败"),vt.showMessage("取消讲稿备注失败")}}else{v("转换中...");try{let lt=a.value;try{const Dt=await ka(q);Dt!=null&&Dt.kramdown&&(lt=Dt.kramdown)}catch{}const _t=`> [!NOTE] 💡 演讲备注
${(Br(lt)||lt.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(Dt=>`> ${Dt}`).join(`
`)}
{: custom-slidev-note="true"}`;await Lo("markdown",_t,q),await zt(q,{[ie]:"true"}),Ht.setBlockAttrOverride(q,{[ie]:"true"}),se(q,{[ie]:"true"}),o.value[ie]="true",l.value="NodeCallout",v("已设为讲稿备注"),vt.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e&&await e.compileCurrentDocument()}catch(lt){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",lt),v("设置失败"),vt.showMessage("转为讲稿备注提示块失败")}}}async function Vt(q){var Bt,li,To,Eo,Mo,Bo,Do;const At=`> [!NOTE] 💡 演讲备注
${(q||"在此输入本页讲稿提词...").split(/\r?\n/).map(Pe=>`> ${Pe}`).join(`
`)}
{: custom-slidev-note="true"}`,_t=((Bt=u.value)==null?void 0:Bt.slides)||[],Dt=z.value,Lt=Dt?_t.findIndex(Pe=>Pe===Dt):-1;let Ot=null;if(Lt!==-1&&Lt<_t.length-1){const Pe=_t[Lt+1];Ot=await nn("markdown",At,Pe.startBlockId)}else{const Pe=((li=Dt==null?void 0:Dt.noteBlocks)==null?void 0:li.slice(-1)[0])||((To=Dt==null?void 0:Dt.blocks)==null?void 0:To.slice(-1)[0]);Pe!=null&&Pe.id?Ot=await nn("markdown",At,void 0,Pe.id):Ot=await _r("markdown",At,c.value)}const Zt=((Bo=(Mo=(Eo=Ot==null?void 0:Ot[0])==null?void 0:Eo.doOperations)==null?void 0:Mo[0])==null?void 0:Bo.id)||((Do=Ot==null?void 0:Ot[0])==null?void 0:Do.id);return Zt&&(await zt(Zt,{[ie]:"true"}),Ht.setBlockAttrOverride(Zt,{[ie]:"true"}),Ei(Zt,e==null?void 0:e.app)),e&&await e.compileCurrentDocument(),Zt}async function Yt(){try{await Vt(),vt.showMessage("已在正文末尾插入讲稿备注提示块")}catch(q){vt.showMessage("插入讲稿备注块失败"),console.error(q)}}function ee(){const q=W.value;if(!q){vt.showMessage("未找到本页关联的讲稿备注块");return}Ei(q,e==null?void 0:e.app)?vt.showMessage("已在编辑区定位讲稿备注块"):vt.showMessage("定位讲稿备注块失败")}async function Nt(){if(!c.value)return;const q=z.value||{startBlockId:r.value||c.value,blocks:a.value&&a.value!=="---"?[{id:r.value,type:l.value,content:a.value,rawMarkdown:""}]:[],rawMarkdown:a.value&&a.value!=="---"?a.value:""};vt.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const lt=await Ar(q,Sr);if(lt.notes){const yt=W.value;if(yt){const At=`> [!NOTE] 💡 演讲备注
${lt.notes.split(/\r?\n/).map(_t=>`> ${_t}`).join(`
`)}
{: custom-slidev-note="true"}`;await Lo("markdown",At,yt),await zt(yt,{[ie]:"true"}),Ht.setBlockAttrOverride(yt,{[ie]:"true"}),Ei(yt,e==null?void 0:e.app)}else await Vt(lt.notes);lt.isAiGenerated?vt.showMessage("思源 AI 演讲提词卡生成成功！"):vt.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e&&await e.compileCurrentDocument()}}function Ke(){ct.value?G(Se,""):G(Se,"+1")}function te(q){G(Se,q)}function Jt(q){G(He,q)}function mi(q){(o.value[Tt]||"")===q?G(Tt,""):G(Tt,q)}function Bi(q){X.value=q,G(Si,q)}function gs(q){mt.value=q,G(cn,q)}async function vs(){const q=Y.value==="three-cols-header";await G(Tt,q?"col-1":"left"),vt.showMessage(q?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function Tn(){const q=r.value;if(!q)return;const lt={[Se]:"",[He]:"",[Tt]:"",[Si]:"",[cn]:"",[ie]:"","slidev-note":"",[ft]:"",[qt]:"",[Xt]:"",[Ut]:"",[Ae]:"",[vi]:"",[Mn]:"",[Li]:"",[Bn]:""};if(se(q,lt),await zt(q,lt),Ht.clearBlockAttrOverride(q),typeof document<"u"){const yt=document.querySelector(`.protyle-wysiwyg [data-node-id="${q}"]`),At=yt==null?void 0:yt.closest('[data-type="NodeListItem"]'),_t=At==null?void 0:At.getAttribute("data-node-id");_t&&_t!==q&&(se(_t,lt),await zt(_t,lt).catch(()=>{}),Ht.clearBlockAttrOverride(_t))}o.value={},X.value="",mt.value="",j.value="",Q.value="",vt.showMessage("已清除本块演示属性"),e&&await e.compileCurrentDocument()}function gi(q){it(rn,q)}function Di(q){it(ln,q)}function ia(q){it(an,q)}async function na(){if(r.value)try{await nn("markdown","---",r.value,void 0),vt.showMessage("已在上方插入分页符 (---)"),e&&e.compileCurrentDocument()}catch{vt.showMessage("插入分页符失败")}}async function Io(){const q=r.value||c.value;if(q)try{await nn("markdown","---",void 0,q),vt.showMessage("已在下方插入分页符 (---)"),e&&e.compileCurrentDocument()}catch{vt.showMessage("插入分页符失败")}}async function sa(){if(r.value)try{await ya(r.value),vt.showMessage("已删除该分页符"),r.value="",l.value="",e&&e.compileCurrentDocument()}catch{vt.showMessage("删除失败")}}function Ao(){e!=null&&e.openBottomPreviewTab&&e.openBottomPreviewTab()}function oa(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function ra(){e!=null&&e.executeCommand&&e.executeCommand("slidevAiSplit")}function la(){if(!u.value){vt.showMessage("请先在主编辑区打开幻灯片文档");return}const q=Yl(u.value);Jl("presentation.html",q)&&vt.showMessage("已开始下载单文件离线 HTML 演示包")}function aa(){if(!u.value){vt.showMessage("请先在主编辑区打开幻灯片文档");return}Xl(u.value)&&vt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({setActiveBlock(q){r.value=q.id,l.value=q.type,o.value={...q.attrs},a.value=q.content||q.markdown||"",d.value=q.topBlockId||q.id,h.value=q.pageDividerId||"",g.value=q.pageDividerLayout||"",q.rootId?c.value=q.rootId:(q.type==="doc"||q.type==="NodeDocument")&&q.id&&(c.value=q.id),j.value=q.attrs[Ut]||"",Q.value=q.attrs[Ae]||"",X.value=q.attrs[Si]||"",mt.value=q.attrs[cn]||"",x.value=!!q.isImage},updateDocument(q){u.value=q,c.value=q.docId},openImportDialog(){s.value=!0},setCurrentDocId(q){c.value=q}}),(q,lt)=>(et(),nt("div",Fv,[m("div",jv,[m("div",Hv,[(et(),nt("svg",Uv,[...lt[2]||(lt[2]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),lt[3]||(lt[3]=m("span",null,"演示配置",-1))]),m("div",Wv,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:lt[0]||(lt[0]=yt=>s.value=!0)},[pt(kt,{name:"import"}),lt[4]||(lt[4]=m("span",null,"导入",-1))]),m("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:Ao},[pt(kt,{name:"split-preview"}),lt[5]||(lt[5]=m("span",null,"分屏预览",-1))])])]),m("div",Vv,[m("div",Kv,[m("span",{class:Et(["spm-target-tag",T.value])},St(J.value),3),m("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":p.value||"点击复制 ID: "+(r.value||c.value),onClick:k},[pt(kt,{name:"copy"}),m("span",null,"#"+St(M.value),1)],8,qv)]),y.value?(et(),nt("span",Gv,"● "+St(y.value),1)):Ft("",!0)]),R.value?(et(),nt("div",{key:0,class:"spm-context-quote",title:a.value},St(R.value),9,Zv)):Ft("",!0),m("div",Yv,[S.value?(et(),Ee(Zh,{key:0,"page-layout":L.value,"page-transition":w.value,"page-background":j.value,"page-image":Q.value,"page-notes":at.value,"page-index":V.value,"onUpdate:pageLayout":tt,"onUpdate:pageTransition":dt,"onUpdate:pageBackground":xt,"onUpdate:pageImage":bt,onAddNoteBlock:Yt,onLocateNoteBlock:ee,onGenerateNotes:Nt,onInsertDividerAfter:Io,onDeleteDivider:sa},null,8,["page-layout","page-transition","page-background","page-image","page-notes","page-index"])):r.value&&!B.value?(et(),Ee(gg,{key:1,"elem-click":ct.value,"elem-motion":rt.value,"elem-slot":st.value,"elem-shiki-lines":X.value,"elem-max-height":mt.value,"is-code-block":A.value,"is-image":_.value,"is-video":C.value,"video-autoplay":gt.value,"video-loop":Z.value,"video-muted":ot.value,"video-controls":ut.value,"has-block-attrs":U.value,"is-note":N.value,"image-role":D.value,"current-slide-layout":Y.value,onToggleNote:Mt,onToggleElemClick:Ke,onToggleVideoAutoplay:E,onToggleVideoLoop:P,onToggleVideoMuted:f,onToggleVideoControls:F,"onUpdate:imageRole":K,"onUpdate:elemClick":te,"onUpdate:elemMotion":Jt,"onUpdate:elemSlot":mi,"onUpdate:elemShikiLines":Bi,"onUpdate:elemMaxHeight":gs,onInsertDividerBefore:na,onInsertDividerAfter:Io,onSetTwoColsContrast:vs,onClearBlockAttrs:Tn},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout"])):(et(),Ee(Ug,{key:2,"doc-theme":O.value,"doc-aspect-ratio":$.value,"doc-default-transition":I.value,"onUpdate:docTheme":gi,"onUpdate:docAspectRatio":Di,"onUpdate:docDefaultTransition":ia,onOpenBottomPreview:Ao,onOpenPresenter:oa,onAiAutoSplit:ra,onExportHtml:la,onExportPdf:aa},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition"]))]),s.value?(et(),Ee(Nv,{key:1,onClose:lt[1]||(lt[1]=yt=>s.value=!1),onSuccess:n})):Ft("",!0)]))}}),An=new So;let di=null,We=null;function Xv(t,i){di&&ta(),di=jl(wh),di.provide("plugin",i),di.provide("sandboxBridge",An);const e=di.mount(t);return We=e,e}function ta(t){di&&(di.unmount(),di=null,We=null)}let ui=null,be=null;function Qv(t,i){ui&&ea(),ui=jl(Jv),ui.provide("plugin",i),ui.provide("sandboxBridge",An);const e=ui.mount(t);return be=e,e}function ea(t){ui&&(ui.unmount(),ui=null,be=null)}function tb(t,i){be!=null&&be.updateDocument&&be.updateDocument(t),We!=null&&We.updateDocument?We.updateDocument(t,i):An.updateSlides(t.slides,t.config,t.fullMarkdown)}function Bs(t){We!=null&&We.navigateToBlock?We.navigateToBlock(t):An.highlightElement(t)}function Fn(t){be!=null&&be.setActiveBlock&&be.setActiveBlock(t)}function eb(){return be!=null&&be.openImportDialog?(be.openImportDialog(),!0):!1}const ib=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:xi,value:"true"},{key:ft,value:"cover"},{key:Xt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:xi,value:"true"},{key:ft,value:"two-cols"},{key:Xt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:xi,value:"true"},{key:ft,value:"fact"},{key:Xt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:xi,value:"true"},{key:ft,value:"intro"},{key:Xt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:xi,value:"true"},{key:ft,value:"quote"},{key:Xt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Se,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Se,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Tt,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Si,value:"1-3"}]}];class Ds{getPresetTemplates(){return ib}buildScanSlidevBlocksSql(i="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${i}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${Xt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(i,e,s,n){const r=`SELECT block_id FROM attributes WHERE name = '${Xt}' AND value = '${i}'`,l=await s(r);let o=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{[Xt]:e}),o++)}return{updatedCount:o}}async batchUpdateLayout(i,e,s,n){const r=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${i}'`,l=await s(r);let o=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{"custom-slidev-layout":e}),o++)}return{updatedCount:o}}exportTemplatesJson(){const i=this.getPresetTemplates();return JSON.stringify({templates:i,counter:i.length},null,2)}formatTransitionSummary(i){return!i||i.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${i.map(s=>`${s.value}: ${s.count} 个`).join("，")}`}}const nb=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,sb="slidev-dock",wr="slidev-preview-tab",xr=xp;class ob extends vt.Plugin{constructor(){super(...arguments);wt(this,"isMobile",!1);wt(this,"currentDocId","");wt(this,"latestCompiledDoc",null);wt(this,"cliBridge",new to);wt(this,"debounceTimer",null);wt(this,"activeCursorBlockId","");wt(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));wt(this,"onWsMainBound",this.onWsMain.bind(this));wt(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));wt(this,"onClickEditorTitleIconBound",this.onClickEditorTitleIcon.bind(this));wt(this,"onEditorClickBound",this.onEditorClick.bind(this));wt(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));wt(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this))}async onload(){const e=vt.getFrontend();this.isMobile=e==="mobile"||e==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(nb),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"Slidev 演示 (下方分屏)",position:"right",callback:()=>{this.openBottomPreviewTab()}}),this.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{this.openBottomPreviewTab()}}),this.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{eb()||vt.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),this.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!this.currentDocId){const n=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(n==null?void 0:n.getAttribute("data-doc-id"))||""}this.currentDocId&&(await zt(this.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),vt.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(this.currentDocId))}}),this.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!this.currentDocId){const a=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(a==null?void 0:a.getAttribute("data-doc-id"))||""}if(!this.currentDocId){vt.showMessage("请先打开一篇思源笔记文档");return}const n=await Kn(this.currentDocId).catch(()=>[]);if(!n||n.length===0){vt.showMessage("当前文档无内容，无需断页");return}const r=n.map(a=>({id:a.id,type:a.type,subType:a.subType,content:a.content||"",markdown:a.markdown||""})),l=Sa(r);if(l.length===0){vt.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}vt.showMessage(`AI 分析完毕：发现 ${l.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const a of l)try{await nn("markdown","---",void 0,a.blockId),await zt(a.blockId,{"custom-slidev-layout":a.recommendedLayout}),o++}catch(c){console.warn("Failed to insert divider:",c)}vt.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),this.compileCurrentDocument(this.currentDocId)}}),this.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var h,g,u,y;if(!this.currentDocId){const p=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(p==null?void 0:p.getAttribute("data-doc-id"))||""}if(!this.currentDocId){vt.showMessage("请先打开一篇思源笔记文档");return}vt.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const n=await Kn(this.currentDocId).catch(()=>[]),r={startBlockId:this.currentDocId,blocks:n.map(p=>({id:p.id,type:p.type,content:p.content||"",rawMarkdown:p.markdown||""})),rawMarkdown:""},a=`> [!NOTE] 💡 演讲备注
${(await Ca(r,Sr)).split(/\r?\n/).map(p=>`> ${p}`).join(`
`)}
{: custom-slidev-note="true"}`,c=await _r("markdown",a,this.currentDocId).catch(()=>null),d=((u=(g=(h=c==null?void 0:c[0])==null?void 0:h.doOperations)==null?void 0:g[0])==null?void 0:u.id)||((y=c==null?void 0:c[0])==null?void 0:y.id);d&&(await zt(d,{"custom-slidev-note":"true"}),Ht.setBlockAttrOverride(d,{"custom-slidev-note":"true"}),Ei(d,this.app)),vt.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),this.compileCurrentDocument(this.currentDocId)}}),this.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const n=new Ds,r=n.buildTransitionStatsSql(),l=await gn(r).catch(()=>[]),o=n.formatTransitionSummary(l||[]);vt.showMessage(o)}}),this.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const r=new Ds().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(r),vt.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):vt.showMessage(`已生成模板数据（请在控制台查看）：
`+r)}}),this.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const r=await new Ds().batchUpdateTransitions("fade","slide-left",l=>gn(l).catch(()=>[]),(l,o)=>zt(l,o));vt.showMessage(`全库批量替换完成：已将 ${r.updatedCount} 处 fade 转场更新为 slide-left`),this.compileCurrentDocument()}}),this.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),this.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(this.latestCompiledDoc||await this.compileCurrentDocument(),!this.latestCompiledDoc){vt.showMessage("请先打开并放映一篇思源笔记文档");return}this.cliBridge.downloadSlidesMd(this.latestCompiledDoc,`slides-${this.currentDocId||"demo"}.md`)&&vt.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),this.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{vt.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await this.cliBridge.probeServer(1500)?vt.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):vt.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),this.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(this.latestCompiledDoc||await this.compileCurrentDocument(),!this.latestCompiledDoc){vt.showMessage("请先打开并放映一篇思源笔记文档");return}const n=await this.cliBridge.syncToWorkspaceFile(this.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",Ls);n.success?vt.showMessage(`已成功同步最新 slides.md 至工作空间：${n.path}`):vt.showMessage(`同步失败：${n.error}`)}});const s=this;if(this.addTab({type:wr,init(){Xv(this.element,s)},destroy(){ta(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:sb,init(){Qv(this.element,s)},destroy(){ea(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(n,r)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${n}`,{detail:r}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound)),typeof document<"u"){const n=()=>{const r=this.getActiveDocumentId();r&&(r!==this.currentDocId&&(this.currentDocId=r),this.latestCompiledDoc||this.compileCurrentDocument(r))};setTimeout(n,300),setTimeout(n,1e3)}}async onDataChanged(e){await this.loadGlobalSettings(),this.currentDocId&&await this.compileCurrentDocument(this.currentDocId)}async loadGlobalSettings(){try{const e=await this.loadData(xr),s=_p(e);return Vi(s),s}catch{return Vi(Yi),Yi}}async saveGlobalSettings(e){const s=$o(),n=Vi({...s,...e||{}});try{await this.saveData(xr,n)}catch(r){console.error("保存 Slidev 全局配置失败",r)}return n}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound)),An.detach()}async openBottomPreviewTab(){if(!this.currentDocId){const e=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(e==null?void 0:e.getAttribute("data-doc-id"))||""}await vt.openTab({app:this.app,custom:{id:this.name+wr,title:"Slidev 演示预览",icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId)}onClickEditorTitleIcon(e){var l;const s=e.detail,n=s==null?void 0:s.menu,r=((l=s==null?void 0:s.data)==null?void 0:l.id)||this.currentDocId;!n||!r||n.addItem({icon:"iconSlidev",label:"Slidev 全局演示配置",submenu:[{label:"初始化演示属性 (custom-slidev-*)",click:async()=>{await zt(r,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),vt.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"主题: 默认 (default)",click:async()=>{await zt(r,{"custom-slidev-theme":"default"}),vt.showMessage("已切换为 default 主题"),this.compileCurrentDocument(r)}},{label:"主题: 优雅衬线 (seriph)",click:async()=>{await zt(r,{"custom-slidev-theme":"seriph"}),vt.showMessage("已切换为 seriph 主题"),this.compileCurrentDocument(r)}},{label:"主题: 苹果极简 (apple-basic)",click:async()=>{await zt(r,{"custom-slidev-theme":"apple-basic"}),vt.showMessage("已切换为 apple-basic 主题"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"画幅: 16 / 9 (宽屏)",click:async()=>{await zt(r,{"custom-slidev-aspect-ratio":"16/9"}),vt.showMessage("已切换画幅为 16/9"),this.compileCurrentDocument(r)}},{label:"画幅: 4 / 3 (标屏)",click:async()=>{await zt(r,{"custom-slidev-aspect-ratio":"4/3"}),vt.showMessage("已切换画幅为 4/3"),this.compileCurrentDocument(r)}}]})}async onSwitchProtyle(e){var r,l;const s=(r=e.detail)==null?void 0:r.protyle,n=(l=s==null?void 0:s.block)==null?void 0:l.rootID;if(n&&n!==this.currentDocId){this.currentDocId=n,this.activeCursorBlockId=n;const o=await Ge(n).catch(()=>({}));Fn({id:n,rootId:n,type:"doc",attrs:o}),this.compileCurrentDocument(n)}}onClickEditorContent(e){var r,l;const s=e==null?void 0:e.detail;if(!s)return;const n=(l=(r=s.protyle)==null?void 0:r.block)==null?void 0:l.rootID;n&&(!this.currentDocId||this.currentDocId!==n)&&(this.currentDocId=n),s.event&&this.onEditorClick(s.event)}getActiveDocumentId(){if(typeof document>"u")return"";const e=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),s=e==null?void 0:e.getAttribute("data-node-id");if(s)return s;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),r=n==null?void 0:n.getAttribute("data-node-id");if(r)return r;const l=document.querySelector("[data-doc-id]"),o=l==null?void 0:l.getAttribute("data-doc-id");return o||""}resolveDocIdFromElement(e){const s=e.closest(".protyle-title"),n=s==null?void 0:s.getAttribute("data-node-id");if(n)return n;const r=e.closest(".protyle"),l=r==null?void 0:r.querySelector(".protyle-title"),o=l==null?void 0:l.getAttribute("data-node-id");if(o)return o;const a=e.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||this.currentDocId}async switchToDocGlobalInspector(e,s){var l;if(!e)return;this.activeCursorBlockId=e,this.currentDocId=e;let n=s||"";if(!n&&typeof document<"u"){const o=document.querySelector(`.protyle-title[data-node-id="${e}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${e}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((l=o==null?void 0:o.innerText)==null?void 0:l.trim())||""}const r=await Ge(e).catch(()=>({}));Fn({id:e,rootId:e,type:"doc",content:n,attrs:r,isDivider:!1,isCode:!1}),Bs(e)}onWsMain(e){const s=e.detail;if(s){if(s.cmd==="transactions"&&Array.isArray(s.data)){for(const n of s.data)if(Array.isArray(n==null?void 0:n.doOperations)){for(const r of n.doOperations)if((r==null?void 0:r.action)==="updateAttrs"&&r.id&&r.data){const l=r.data.old||{},o=r.data.new||{},a={};for(const c of Object.keys(l))c in o||(a[c]="");for(const[c,d]of Object.entries(o))a[c]=String(d??"");se(r.id,a),Ht.setBlockAttrOverride(r.id,a)}}}this.debounceTimer&&window.clearTimeout(this.debounceTimer),this.debounceTimer=window.setTimeout(()=>{this.compileCurrentDocument()},150)}}handleBlockClickedFromSlide(e,s){var o,a;if(!e)return!1;this.activeCursorBlockId=e;const n=Ei(e,this.app),r=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`),l=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,e,l);else{let c="",d="";if((o=this.latestCompiledDoc)!=null&&o.slides){const h=this.latestCompiledDoc.slides.find(g=>{var u,y,p;return g.startBlockId===e||((u=g.blocks)==null?void 0:u.some(b=>b.id===e))||((y=g.allBlockIds)==null?void 0:y.includes(e))||((p=g.noteBlocks)==null?void 0:p.some(b=>b.id===e))});h!=null&&h.startBlockId&&(c=h.startBlockId),(a=h==null?void 0:h.frontmatter)!=null&&a.layout&&(d=h.frontmatter.layout)}Ge(e).then(async h=>{if(c&&!d){const g=Ht.getBlockAttrOverride(c);if(g!=null&&g[ft]||g!=null&&g["custom-slidev-layout"])d=g[ft]||g["custom-slidev-layout"]||"";else{const u=await Ge(c).catch(()=>({}))||{};d=u[ft]||u["custom-slidev-layout"]||"",u&&Object.keys(u).length>0&&Ht.setBlockAttrOverride(c,u)}}Fn({id:e,rootId:this.currentDocId,type:l||"NodeParagraph",attrs:h||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return n}onBlockClickedFromSlide(e){const s=(e==null?void 0:e.detail)||e;s!=null&&s.blockId&&this.handleBlockClickedFromSlide(s.blockId,s.page)}onEditorClick(e){const s=e.target;if(!s)return;const n=s.closest(".protyle-title")||s.closest(".protyle-background");if(!!(n||s.closest(".protyle-content")&&!s.closest(".protyle-wysiwyg")&&!s.closest(".protyle-breadcrumb")&&!s.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(s);if(d&&this.activeCursorBlockId!==d){const h=n||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=h==null?void 0:h.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(h==null?void 0:h.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!s.closest(".protyle-wysiwyg"))return;const o=s.closest("[data-node-id]");if(!o)return;const a=o.getAttribute("data-node-id"),c=o.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(s)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Bs(a)),this.syncInspectorBlock(o,a,c))}onSelectionChange(){if(typeof window>"u")return;const e=window.getSelection();if(!e||e.rangeCount===0)return;const s=e.anchorNode;if(!s)return;const n=s.nodeType===Node.ELEMENT_NODE?s:s.parentElement;if(!n)return;const r=n.closest(".protyle-title");if(!!(r||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const h=r||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=h==null?void 0:h.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(h==null?void 0:h.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!n.closest(".protyle-wysiwyg"))return;const o=n.closest("[data-node-id]"),a=o==null?void 0:o.getAttribute("data-node-id"),c=(o==null?void 0:o.getAttribute("data-type"))||"";o&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Bs(a)),this.syncInspectorBlock(o,a,c))}async syncInspectorBlock(e,s,n){var T,L,w,j,Q,z,at,W,Y,V;let r=e,l=s,o=n;const a=e.closest('[data-type="NodeCallout"]');if(a&&a!==e){const N=a.getAttribute("data-node-id");if(N){const ct=await Ge(N).catch(()=>({}))||{},rt=Ht.getBlockAttrOverride(N)||{},st={...ct,...rt};(st[ie]||st["slidev-note"])&&(r=a,l=N,o="NodeCallout")}}const c=o==="NodeThematicBreak",d=o==="NodeCodeBlock",h=((T=r.innerText)==null?void 0:T.trim())||"",g=await Ge(l).catch(()=>({}))||{},u=Ht.getBlockAttrOverride(l)||{},y={...g,...u},p=r.closest(".protyle-wysiwyg > [data-node-id]")||r,b=(p==null?void 0:p.getAttribute("data-node-id"))||l;let v="",k="",S=p.previousElementSibling;for(;S;){const N=S.getAttribute("data-type");if(N==="NodeThematicBreak"||N==="tb"||(L=S.classList)!=null&&L.contains("hr")){v=S.getAttribute("data-node-id")||"";break}S=S.previousElementSibling}if((w=this.latestCompiledDoc)!=null&&w.slides){const N=[l,b];let ct=r.parentElement;for(;ct&&!ct.classList.contains("protyle-wysiwyg");){const st=ct.getAttribute("data-node-id");st&&!N.includes(st)&&N.push(st),ct=ct.parentElement}const rt=this.latestCompiledDoc.slides.find(st=>{var X,mt,gt;return N.includes(st.startBlockId)||((X=st.blocks)==null?void 0:X.some(Z=>N.includes(Z.id)))||((mt=st.allBlockIds)==null?void 0:mt.some(Z=>N.includes(Z)))||((gt=st.noteBlocks)==null?void 0:gt.some(Z=>N.includes(Z.id)))});rt&&(!v&&rt.startBlockId&&(v=rt.startBlockId),!k&&((j=rt.frontmatter)!=null&&j.layout)&&(k=rt.frontmatter.layout))}if(v){const N=Ht.getBlockAttrOverride(v);if(N&&(ft in N||"custom-slidev-layout"in N)&&(k=N[ft]||N["custom-slidev-layout"]||""),!k&&((Q=this.latestCompiledDoc)!=null&&Q.slides)){const ct=this.latestCompiledDoc.slides.find(rt=>rt.startBlockId===v);(z=ct==null?void 0:ct.frontmatter)!=null&&z.layout&&(k=ct.frontmatter.layout)}if(!k){const ct=await Ge(v).catch(()=>({}))||{};k=ct[ft]||ct["custom-slidev-layout"]||"",ct&&Object.keys(ct).length>0&&Ht.setBlockAttrOverride(v,ct)}se(v,{[ft]:k||""})}else if(this.currentDocId){const N=Ht.getBlockAttrOverride(this.currentDocId);N&&(ft in N||"custom-slidev-layout"in N)?k=N[ft]||N["custom-slidev-layout"]||"":!k&&((V=(Y=(W=(at=this.latestCompiledDoc)==null?void 0:at.slides)==null?void 0:W[0])==null?void 0:Y.frontmatter)!=null&&V.layout)&&(k=this.latestCompiledDoc.slides[0].frontmatter.layout)}const A=r.getAttribute(ft)||r.getAttribute("custom-slidev-layout"),x=y[ft]||y["custom-slidev-layout"]||"";A&&A!==x&&se(l,{[ft]:x});const _=r.getAttribute(qt)||r.getAttribute("custom-slidev-role"),C=y[qt]||y["custom-slidev-role"]||"";_&&_!==C&&se(l,{[qt]:C});const B=r.closest('[data-type="NodeListItem"]');if(B&&B!==r){const N=B.getAttribute("data-node-id");if(N){const ct=await Ge(N).catch(()=>({}))||{},rt=Ht.getBlockAttrOverride(N)||{},st={...ct,...rt},X=st[ft]||st["custom-slidev-layout"]||"",mt=B.getAttribute(ft)||B.getAttribute("custom-slidev-layout");mt&&mt!==X&&se(N,{[ft]:X});const gt=st[qt]||st["custom-slidev-role"]||"",Z=B.getAttribute(qt)||B.getAttribute("custom-slidev-role");Z&&Z!==gt&&se(N,{[qt]:gt})}}const M=!!r.querySelector("img, span[data-type='img']"),R=(r.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),J=M&&R.length<=50;Fn({id:l,rootId:this.currentDocId,type:o,content:h,attrs:y,isDivider:c,isCode:d,isImage:J,topBlockId:b,pageDividerId:v,pageDividerLayout:k})}async compileCurrentDocument(e){var n,r,l,o;let s=e||this.currentDocId;if(!s){const a=document.querySelector(".protyle.layout__wnd--active, .layout__wnd--active .protyle, .protyle"),c=(a==null?void 0:a.getAttribute("data-doc-id"))||((n=a==null?void 0:a.querySelector(".protyle-wysiwyg"))==null?void 0:n.getAttribute("data-doc-id"))||((r=a==null?void 0:a.querySelector(".protyle-title"))==null?void 0:r.getAttribute("data-node-id"))||((l=document.querySelector(".protyle-content[data-doc-id]"))==null?void 0:l.getAttribute("data-doc-id"))||((o=document.querySelector("[data-doc-id]"))==null?void 0:o.getAttribute("data-doc-id"));if(c)this.currentDocId=c,s=c;else return}try{const a=await Ht.compile(s);this.latestCompiledDoc=a,tb(a,s),this.purgeStaleDomSlidevAttrs(a)}catch(a){console.error("[SiYuanSlidev] Failed to compile document:",a)}}purgeStaleDomSlidevAttrs(e){var r,l,o;if(typeof document>"u"||!e)return;const s=new Map;if(Array.isArray(e.slides))for(const a of e.slides){if(a.startBlockId){const c=s.get(a.startBlockId)||{};(r=a.frontmatter)!=null&&r.layout&&(c[ft]=a.frontmatter.layout),s.set(a.startBlockId,c)}if(Array.isArray(a.blocks)){for(const c of a.blocks)if(c.id){const d=s.get(c.id)||{};(l=c.ial)!=null&&l[ft]&&(d[ft]=c.ial[ft]),(o=c.ial)!=null&&o[qt]&&(d[qt]=c.ial[qt]),Object.keys(d).length>0&&s.set(c.id,d)}}}const n=Ht.getAllAttrOverrides();for(const[a,c]of n.entries()){const d=s.get(a)||{};c[ft]!==void 0&&(d[ft]=c[ft]),c[qt]!==void 0&&(d[qt]=c[qt]),s.set(a,d)}Bf(s)}}module.exports=ob;
