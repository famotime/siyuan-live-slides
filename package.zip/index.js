"use strict";var pd=Object.defineProperty;var md=(e,t,o)=>t in e?pd(e,t,{enumerable:!0,configurable:!0,writable:!0,value:o}):e[t]=o;var $e=(e,t,o)=>md(e,typeof t!="symbol"?t+"":t,o);const le=require("siyuan");async function St(e,t){const o=await le.fetchSyncPost(e,t);return o.code===0?o.data:null}async function gd(){return St("/api/notebook/lsNotebooks","")}async function yd(e,t,o){return St("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:o})}async function Bl(e,t){const o=new FormData;o.append("assetsDirPath",e);for(const n of t)o.append("file[]",n);return St("/api/asset/upload",o)}async function qo(e,t,o,i,n){return St("/api/block/insertBlock",{dataType:e,data:t,nextID:o,previousID:i,parentID:n})}async function ws(e,t,o){return St("/api/block/appendBlock",{dataType:e,data:t,parentID:o})}async function xs(e,t,o){return St("/api/block/updateBlock",{dataType:e,data:t,id:o})}async function Vs(e){return St("/api/block/deleteBlock",{id:e})}async function _r(e){return St("/api/transactions",{reqId:Date.now(),transactions:e})}async function bd(e){return St("/api/block/getBlockKramdown",{id:e})}async function ki(e){return St("/api/block/getChildBlocks",{id:e})}async function vd(e){return St("/api/block/getDocBlocksOrders",{id:e})}async function ze(e,t){return St("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function qs(e){return St("/api/attr/getBlockAttrs",{id:e})}async function gi(e){return St("/api/query/sql",{stmt:e})}async function El(e){const t="/api/ai/chatGPT";try{const o=await St(t,{msg:e});return typeof o=="string"&&o.trim().length>0?o.trim():o&&typeof o.content=="string"&&o.content.trim().length>0?o.content.trim():null}catch{return null}}async function kd(){return St("/api/storage/getInlineStyles","")}function Cr(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function Dl(e){const t={};if(!e)return t;const o=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),i=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let n;for(;(n=i.exec(o))!==null;){const s=n[1],l=n[2]??n[3]??n[4]??"";t[s]=l}return t}const Ll=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function wd(e){const t=[];if(!e)return t;const o=new RegExp(Ll.source,"g");let i;for(;(i=o.exec(e))!==null;){const n=i[2]??i[3]??i[4];t.push({fullMatch:i[0],blockId:i[1],anchorText:n?n.trim():void 0})}return t}function xd(e,t){if(!e)return"";const o=new RegExp(Ll.source,"g");return e.replace(o,(i,n,s,l,r)=>{const a=(s??l??r??"").trim();if(t&&t[n]){const u=t[n].trim();return`<div class="slides-block-ref" data-ref-id="${n}">${u}</div>`}const c=a||`Ref(${n.slice(0,8)})`;return`<a href="siyuan://blocks/${n}" data-ref-id="${n}" class="slides-ref-tag">🔗 ${c}</a>`})}const Wi="custom-slides-theme",Ui="custom-slides-aspect-ratio",Vi="custom-slides-default-transition",Ol="custom-slides-color-schema",Ss="custom-slides-spacing",Sn="custom-slides-background",Ir="custom-slides-show-unordered-list-markers",$r="custom-slides-show-ordered-list-markers",fo="custom-slides-slide",be="custom-slides-layout",wt="custom-slides-transition",ct="custom-slides-background",Ft="custom-slides-image",Qn="custom-slides-notes",ri="custom-slides-class",Di="custom-slides-spacing",mt="custom-slides-layout-ratio",li="custom-slides-mask",Ko="custom-slides-mask-ratio",ai="custom-slides-mask-style",ci="custom-slides-mask-initial",Oe="custom-slides-click",At="custom-slides-motion",Xo="custom-slides-shiki-lines",Ae="custom-slides-slot",Ve="custom-slides-note",Ye="custom-slides-role",qi="custom-slides-max-height",Vo="custom-slides-autoplay",_n="custom-slides-loop",si="custom-slides-muted",Cn="custom-slides-controls",Nl="background",In="image-left",$n="image-right";function di(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function Sd(e,t=2){const o=t===4?[25,50,75,100]:[50,100],i=t===4?4:2;if(!e||typeof e!="string")return{steps:i,breakpoints:o};const n=e.trim();if(!n||t===4&&(n==="1:1"||n==="1"))return{steps:i,breakpoints:o};const s=n.split(":").map(y=>parseFloat(y.trim())).filter(y=>!isNaN(y)&&y>0);if(s.length===0)return{steps:i,breakpoints:o};if(s.length===1){const y=Math.min(100,Math.max(1,s[0]));return y===100?{steps:1,breakpoints:[100]}:{steps:2,breakpoints:[Math.round(y*100)/100,100]}}const l=s.every((y,d)=>d===0||y>s[d-1]),r=s[s.length-1];if(l&&(r===100||s.some(y=>y>10))){const y=s.map(d=>Math.min(100,Math.round(d*100)/100));return y[y.length-1]<100&&y.push(100),{steps:y.length,breakpoints:y}}const c=s.reduce((y,d)=>y+d,0);if(c<=0)return{steps:i,breakpoints:o};let u=0;const h=[];for(let y=0;y<s.length;y++)u+=s[y],y===s.length-1?h.push(100):h.push(Math.round(u/c*1e4)/100);return{steps:h.length,breakpoints:h}}function Pl(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function Rl(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function Bt(e,t){if(!Pl(e))return e;const o=Rl(e);return t!=null&&t.base64Map&&t.base64Map[o]?t.base64Map[o]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${o}`:`/${o}`}function _d(e,t){if(!e)return"";let o=e;return o=o.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(i,n,s)=>{const l=Bt(s,t);return`![${n}](${l})`}),o=o.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(i,n,s,l)=>{const r=Bt(s,t);return`${n}${r}${l}`}),o=o.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(i,n,s,l)=>{const r=Bt(s,t);return`${n}${r}${l}`}),o}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Gs(e){const t=Object.create(null);for(const o of e.split(","))t[o]=1;return o=>o in t}const Ze={},ui=[],oo=()=>{},zl=()=>!1,Pn=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),Rn=e=>e.startsWith("onUpdate:"),yt=Object.assign,Ks=(e,t)=>{const o=e.indexOf(t);o>-1&&e.splice(o,1)},Cd=Object.prototype.hasOwnProperty,je=(e,t)=>Cd.call(e,t),Me=Array.isArray,fi=e=>Qi(e)==="[object Map]",wi=e=>Qi(e)==="[object Set]",Ar=e=>Qi(e)==="[object Date]",De=e=>typeof e=="function",nt=e=>typeof e=="string",Ut=e=>typeof e=="symbol",qe=e=>e!==null&&typeof e=="object",Hl=e=>(qe(e)||De(e))&&De(e.then)&&De(e.catch),Fl=Object.prototype.toString,Qi=e=>Fl.call(e),Id=e=>Qi(e).slice(8,-1),jl=e=>Qi(e)==="[object Object]",Ys=e=>nt(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,Li=Gs(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),zn=e=>{const t=Object.create(null);return(o=>t[o]||(t[o]=e(o)))},$d=/-\w/g,Tt=zn(e=>e.replace($d,t=>t.slice(1).toUpperCase())),Ad=/\B([A-Z])/g,Ho=zn(e=>e.replace(Ad,"-$1").toLowerCase()),Hn=zn(e=>e.charAt(0).toUpperCase()+e.slice(1)),es=zn(e=>e?`on${Hn(e)}`:""),Xt=(e,t)=>!Object.is(e,t),hn=(e,...t)=>{for(let o=0;o<e.length;o++)e[o](...t)},Wl=(e,t,o,i=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:i,value:o})},Fn=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let Tr;const jn=()=>Tr||(Tr=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function Qt(e){if(Me(e)){const t={};for(let o=0;o<e.length;o++){const i=e[o],n=nt(i)?Ed(i):Qt(i);if(n)for(const s in n)t[s]=n[s]}return t}else if(nt(e)||qe(e))return e}const Td=/;(?![^(]*\))/g,Md=/:([^]+)/,Bd=/\/\*[^]*?\*\//g;function Ed(e){const t={};return e.replace(Bd,"").split(Td).forEach(o=>{if(o){const i=o.split(Md);i.length>1&&(t[i[0].trim()]=i[1].trim())}}),t}function xe(e){let t="";if(nt(e))t=e;else if(Me(e))for(let o=0;o<e.length;o++){const i=xe(e[o]);i&&(t+=i+" ")}else if(qe(e))for(const o in e)e[o]&&(t+=o+" ");return t.trim()}const Dd="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",Ld=Gs(Dd);function Ul(e){return!!e||e===""}function Od(e,t){if(e.length!==t.length)return!1;let o=!0;for(let i=0;o&&i<e.length;i++)o=xi(e[i],t[i]);return o}function xi(e,t){if(e===t)return!0;let o=Ar(e),i=Ar(t);if(o||i)return o&&i?e.getTime()===t.getTime():!1;if(o=Ut(e),i=Ut(t),o||i)return e===t;if(o=Me(e),i=Me(t),o||i)return o&&i?Od(e,t):!1;if(o=qe(e),i=qe(t),o||i){if(!o||!i)return!1;const n=Object.keys(e).length,s=Object.keys(t).length;if(n!==s)return!1;for(const l in e){const r=e.hasOwnProperty(l),a=t.hasOwnProperty(l);if(r&&!a||!r&&a||!xi(e[l],t[l]))return!1}}return String(e)===String(t)}function Zs(e,t){return e.findIndex(o=>xi(o,t))}const Vl=e=>!!(e&&e.__v_isRef===!0),ke=e=>nt(e)?e:e==null?"":Me(e)||qe(e)&&(e.toString===Fl||!De(e.toString))?Vl(e)?ke(e.value):JSON.stringify(e,ql,2):String(e),ql=(e,t)=>Vl(t)?ql(e,t.value):fi(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((o,[i,n],s)=>(o[ts(i,s)+" =>"]=n,o),{})}:wi(t)?{[`Set(${t.size})`]:[...t.values()].map(o=>ts(o))}:Ut(t)?ts(t):qe(t)&&!Me(t)&&!jl(t)?String(t):t,ts=(e,t="")=>{var o;return Ut(e)?`Symbol(${(o=e.description)!=null?o:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let pt;class Nd{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&pt&&(pt.active?(this.parent=pt,this.index=(pt.scopes||(pt.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,o;if(this.scopes){const i=this.scopes.slice();for(t=0,o=i.length;t<o;t++)i[t].pause()}for(t=0,o=this.effects.length;t<o;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,o;if(this.scopes){const n=this.scopes.slice();for(t=0,o=n.length;t<o;t++)n[t].resume()}const i=this.effects.slice();for(t=0,o=i.length;t<o;t++)i[t].resume()}}run(t){if(this._active){const o=pt;try{return pt=this,t()}finally{pt=o}}}on(){++this._on===1&&(this.prevScope=pt,pt=this)}off(){if(this._on>0&&--this._on===0){if(pt===this)pt=this.prevScope;else{let t=pt;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let o,i;for(o=0,i=this.effects.length;o<i;o++)this.effects[o].stop();for(this.effects.length=0,o=0,i=this.cleanups.length;o<i;o++)this.cleanups[o]();if(this.cleanups.length=0,this.scopes){const n=this.scopes.slice();for(o=0,i=n.length;o<i;o++)n[o].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const n=this.parent.scopes.pop();n&&n!==this&&(this.parent.scopes[this.index]=n,n.index=this.index)}this.parent=void 0}}}function Pd(){return pt}let Xe;const os=new WeakSet;class Gl{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,pt&&(pt.active?pt.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,os.has(this)&&(os.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Yl(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Mr(this),Zl(this);const t=Xe,o=jt;Xe=this,jt=!0;try{return this.fn()}finally{Jl(this),Xe=t,jt=o,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)Qs(t);this.deps=this.depsTail=void 0,Mr(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?os.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){_s(this)&&this.run()}get dirty(){return _s(this)}}let Kl=0,Oi,Ni;function Yl(e,t=!1){if(e.flags|=8,t){e.next=Ni,Ni=e;return}e.next=Oi,Oi=e}function Js(){Kl++}function Xs(){if(--Kl>0)return;if(Ni){let t=Ni;for(Ni=void 0;t;){const o=t.next;t.next=void 0,t.flags&=-9,t=o}}let e;for(;Oi;){let t=Oi;for(Oi=void 0;t;){const o=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(i){e||(e=i)}t=o}}if(e)throw e}function Zl(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function Jl(e){let t,o=e.depsTail,i=o;for(;i;){const n=i.prevDep;i.version===-1?(i===o&&(o=n),Qs(i),Rd(i)):t=i,i.dep.activeLink=i.prevActiveLink,i.prevActiveLink=void 0,i=n}e.deps=t,e.depsTail=o}function _s(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(Xl(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function Xl(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===Gi)||(e.globalVersion=Gi,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!_s(e))))return;e.flags|=2;const t=e.dep,o=Xe,i=jt;Xe=e,jt=!0;try{Zl(e);const n=e.fn(e._value);(t.version===0||Xt(n,e._value))&&(e.flags|=128,e._value=n,t.version++)}catch(n){throw t.version++,n}finally{Xe=o,jt=i,Jl(e),e.flags&=-3}}function Qs(e,t=!1){const{dep:o,prevSub:i,nextSub:n}=e;if(i&&(i.nextSub=n,e.prevSub=void 0),n&&(n.prevSub=i,e.nextSub=void 0),o.subs===e&&(o.subs=i,!i&&o.computed)){o.computed.flags&=-5;for(let s=o.computed.deps;s;s=s.nextDep)Qs(s,!0)}!t&&!--o.sc&&o.map&&o.map.delete(o.key)}function Rd(e){const{prevDep:t,nextDep:o}=e;t&&(t.nextDep=o,e.prevDep=void 0),o&&(o.prevDep=t,e.nextDep=void 0)}let jt=!0;const Ql=[];function vo(){Ql.push(jt),jt=!1}function ko(){const e=Ql.pop();jt=e===void 0?!0:e}function Mr(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const o=Xe;Xe=void 0;try{t()}finally{Xe=o}}}let Gi=0;class zd{constructor(t,o){this.sub=t,this.dep=o,this.version=o.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class er{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!Xe||!jt||Xe===this.computed)return;let o=this.activeLink;if(o===void 0||o.sub!==Xe)o=this.activeLink=new zd(Xe,this),Xe.deps?(o.prevDep=Xe.depsTail,Xe.depsTail.nextDep=o,Xe.depsTail=o):Xe.deps=Xe.depsTail=o,ea(o);else if(o.version===-1&&(o.version=this.version,o.nextDep)){const i=o.nextDep;i.prevDep=o.prevDep,o.prevDep&&(o.prevDep.nextDep=i),o.prevDep=Xe.depsTail,o.nextDep=void 0,Xe.depsTail.nextDep=o,Xe.depsTail=o,Xe.deps===o&&(Xe.deps=i)}return o}trigger(t){this.version++,Gi++,this.notify(t)}notify(t){Js();try{for(let o=this.subs;o;o=o.prevSub)o.sub.notify()&&o.sub.dep.notify()}finally{Xs()}}}function ea(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let i=t.deps;i;i=i.nextDep)ea(i)}const o=e.dep.subs;o!==e&&(e.prevSub=o,o&&(o.nextSub=e)),e.dep.subs=e}}const Cs=new WeakMap,Yo=Symbol(""),Is=Symbol(""),Ki=Symbol("");function kt(e,t,o){if(jt&&Xe){let i=Cs.get(e);i||Cs.set(e,i=new Map);let n=i.get(o);n||(i.set(o,n=new er),n.map=i,n.key=o),n.track()}}function ho(e,t,o,i,n,s){const l=Cs.get(e);if(!l){Gi++;return}const r=a=>{a&&a.trigger()};if(Js(),t==="clear")l.forEach(r);else{const a=Me(e),c=a&&Ys(o);if(a&&o==="length"){const u=Number(i);l.forEach((h,y)=>{(y==="length"||y===Ki||!Ut(y)&&y>=u)&&r(h)})}else switch((o!==void 0||l.has(void 0))&&r(l.get(o)),c&&r(l.get(Ki)),t){case"add":a?c&&r(l.get("length")):(r(l.get(Yo)),fi(e)&&r(l.get(Is)));break;case"delete":a||(r(l.get(Yo)),fi(e)&&r(l.get(Is)));break;case"set":fi(e)&&r(l.get(Yo));break}}Xs()}function ti(e){const t=Fe(e);return t===e?t:(kt(t,"iterate",Ki),zt(e)?t:t.map(Vt))}function Wn(e){return kt(e=Fe(e),"iterate",Ki),e}function Zt(e,t){return wo(e)?yi(Zo(e)?Vt(t):t):Vt(t)}const Hd={__proto__:null,[Symbol.iterator](){return is(this,Symbol.iterator,e=>Zt(this,e))},concat(...e){return ti(this).concat(...e.map(t=>Me(t)?ti(t):t))},entries(){return is(this,"entries",e=>(e[1]=Zt(this,e[1]),e))},every(e,t){return lo(this,"every",e,t,void 0,arguments)},filter(e,t){return lo(this,"filter",e,t,o=>o.map(i=>Zt(this,i)),arguments)},find(e,t){return lo(this,"find",e,t,o=>Zt(this,o),arguments)},findIndex(e,t){return lo(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return lo(this,"findLast",e,t,o=>Zt(this,o),arguments)},findLastIndex(e,t){return lo(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return lo(this,"forEach",e,t,void 0,arguments)},includes(...e){return ns(this,"includes",e)},indexOf(...e){return ns(this,"indexOf",e)},join(e){return ti(this).join(e)},lastIndexOf(...e){return ns(this,"lastIndexOf",e)},map(e,t){return lo(this,"map",e,t,void 0,arguments)},pop(){return $i(this,"pop")},push(...e){return $i(this,"push",e)},reduce(e,...t){return Br(this,"reduce",e,t)},reduceRight(e,...t){return Br(this,"reduceRight",e,t)},shift(){return $i(this,"shift")},some(e,t){return lo(this,"some",e,t,void 0,arguments)},splice(...e){return $i(this,"splice",e)},toReversed(){return ti(this).toReversed()},toSorted(e){return ti(this).toSorted(e)},toSpliced(...e){return ti(this).toSpliced(...e)},unshift(...e){return $i(this,"unshift",e)},values(){return is(this,"values",e=>Zt(this,e))}};function is(e,t,o){const i=Wn(e),n=i[t]();return i!==e&&!zt(e)&&(n._next=n.next,n.next=()=>{const s=n._next();return s.done||(s.value=o(s.value)),s}),n}const Fd=Array.prototype;function lo(e,t,o,i,n,s){const l=Wn(e),r=l!==e&&!zt(e),a=l[t];if(a!==Fd[t]){const h=a.apply(e,s);return r?Vt(h):h}let c=o;l!==e&&(r?c=function(h,y){return o.call(this,Zt(e,h),y,e)}:o.length>2&&(c=function(h,y){return o.call(this,h,y,e)}));const u=a.call(l,c,i);return r&&n?n(u):u}function Br(e,t,o,i){const n=Wn(e),s=n!==e&&!zt(e);let l=o,r=!1;n!==e&&(s?(r=i.length===0,l=function(c,u,h){return r&&(r=!1,c=Zt(e,c)),o.call(this,c,Zt(e,u),h,e)}):o.length>3&&(l=function(c,u,h){return o.call(this,c,u,h,e)}));const a=n[t](l,...i);return r?Zt(e,a):a}function ns(e,t,o){const i=Fe(e);kt(i,"iterate",Ki);const n=i[t](...o);return(n===-1||n===!1)&&ir(o[0])?(o[0]=Fe(o[0]),i[t](...o)):n}function $i(e,t,o=[]){vo(),Js();const i=Fe(e)[t].apply(e,o);return Xs(),ko(),i}const jd=Gs("__proto__,__v_isRef,__isVue"),ta=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Ut));function Wd(e){Ut(e)||(e=String(e));const t=Fe(this);return kt(t,"has",e),t.hasOwnProperty(e)}class oa{constructor(t=!1,o=!1){this._isReadonly=t,this._isShallow=o}get(t,o,i){if(o==="__v_skip")return t.__v_skip;const n=this._isReadonly,s=this._isShallow;if(o==="__v_isReactive")return!n;if(o==="__v_isReadonly")return n;if(o==="__v_isShallow")return s;if(o==="__v_raw")return i===(n?s?Qd:ra:s?sa:na).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(i)?t:void 0;const l=Me(t);if(!n){let a;if(l&&(a=Hd[o]))return a;if(o==="hasOwnProperty")return Wd}const r=Reflect.get(t,o,ot(t)?t:i);if((Ut(o)?ta.has(o):jd(o))||(n||kt(t,"get",o),s))return r;if(ot(r)){const a=l&&Ys(o)?r:r.value;return n&&qe(a)?As(a):a}return qe(r)?n?As(r):Un(r):r}}class ia extends oa{constructor(t=!1){super(!1,t)}set(t,o,i,n){let s=t[o];const l=Me(t)&&Ys(o);if(!this._isShallow){const c=wo(s);if(!zt(i)&&!wo(i)&&(s=Fe(s),i=Fe(i)),!l&&ot(s)&&!ot(i))return c||(s.value=i),!0}const r=l?Number(o)<t.length:je(t,o),a=Reflect.set(t,o,i,ot(t)?t:n);return t===Fe(n)&&a&&(r?Xt(i,s)&&ho(t,"set",o,i):ho(t,"add",o,i)),a}deleteProperty(t,o){const i=je(t,o);t[o];const n=Reflect.deleteProperty(t,o);return n&&i&&ho(t,"delete",o,void 0),n}has(t,o){const i=Reflect.has(t,o);return(!Ut(o)||!ta.has(o))&&kt(t,"has",o),i}ownKeys(t){return kt(t,"iterate",Me(t)?"length":Yo),Reflect.ownKeys(t)}}class Ud extends oa{constructor(t=!1){super(!0,t)}set(t,o){return!0}deleteProperty(t,o){return!0}}const Vd=new ia,qd=new Ud,Gd=new ia(!0);const $s=e=>e,rn=e=>Reflect.getPrototypeOf(e);function Kd(e,t,o){return function(...i){const n=this.__v_raw,s=Fe(n),l=fi(s),r=e==="entries"||e===Symbol.iterator&&l,a=e==="keys"&&l,c=n[e](...i),u=o?$s:t?yi:Vt;return!t&&kt(s,"iterate",a?Is:Yo),yt(Object.create(c),{next(){const{value:h,done:y}=c.next();return y?{value:h,done:y}:{value:r?[u(h[0]),u(h[1])]:u(h),done:y}}})}}function ln(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function Yd(e,t){const o={get(n){const s=this.__v_raw,l=Fe(s),r=Fe(n);e||(Xt(n,r)&&kt(l,"get",n),kt(l,"get",r));const{has:a}=rn(l),c=t?$s:e?yi:Vt;if(a.call(l,n))return c(s.get(n));if(a.call(l,r))return c(s.get(r));s!==l&&s.get(n)},get size(){const n=this.__v_raw;return!e&&kt(Fe(n),"iterate",Yo),n.size},has(n){const s=this.__v_raw,l=Fe(s),r=Fe(n);return e||(Xt(n,r)&&kt(l,"has",n),kt(l,"has",r)),n===r?s.has(n):s.has(n)||s.has(r)},forEach(n,s){const l=this,r=l.__v_raw,a=Fe(r),c=t?$s:e?yi:Vt;return!e&&kt(a,"iterate",Yo),r.forEach((u,h)=>n.call(s,c(u),c(h),l))}};return yt(o,e?{add:ln("add"),set:ln("set"),delete:ln("delete"),clear:ln("clear")}:{add(n){const s=Fe(this),l=rn(s),r=Fe(n),a=!t&&!zt(n)&&!wo(n)?r:n;return l.has.call(s,a)||Xt(n,a)&&l.has.call(s,n)||Xt(r,a)&&l.has.call(s,r)||(s.add(a),ho(s,"add",a,a)),this},set(n,s){!t&&!zt(s)&&!wo(s)&&(s=Fe(s));const l=Fe(this),{has:r,get:a}=rn(l);let c=r.call(l,n);c||(n=Fe(n),c=r.call(l,n));const u=a.call(l,n);return l.set(n,s),c?Xt(s,u)&&ho(l,"set",n,s):ho(l,"add",n,s),this},delete(n){const s=Fe(this),{has:l,get:r}=rn(s);let a=l.call(s,n);a||(n=Fe(n),a=l.call(s,n)),r&&r.call(s,n);const c=s.delete(n);return a&&ho(s,"delete",n,void 0),c},clear(){const n=Fe(this),s=n.size!==0,l=n.clear();return s&&ho(n,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(n=>{o[n]=Kd(n,e,t)}),o}function tr(e,t){const o=Yd(e,t);return(i,n,s)=>n==="__v_isReactive"?!e:n==="__v_isReadonly"?e:n==="__v_raw"?i:Reflect.get(je(o,n)&&n in i?o:i,n,s)}const Zd={get:tr(!1,!1)},Jd={get:tr(!1,!0)},Xd={get:tr(!0,!1)};const na=new WeakMap,sa=new WeakMap,ra=new WeakMap,Qd=new WeakMap;function eu(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Un(e){return wo(e)?e:or(e,!1,Vd,Zd,na)}function tu(e){return or(e,!1,Gd,Jd,sa)}function As(e){return or(e,!0,qd,Xd,ra)}function or(e,t,o,i,n){if(!qe(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const s=n.get(e);if(s)return s;const l=eu(Id(e));if(l===0)return e;const r=new Proxy(e,l===2?i:o);return n.set(e,r),r}function Zo(e){return wo(e)?Zo(e.__v_raw):!!(e&&e.__v_isReactive)}function wo(e){return!!(e&&e.__v_isReadonly)}function zt(e){return!!(e&&e.__v_isShallow)}function ir(e){return e?!!e.__v_raw:!1}function Fe(e){const t=e&&e.__v_raw;return t?Fe(t):e}function ou(e){return!je(e,"__v_skip")&&Object.isExtensible(e)&&Wl(e,"__v_skip",!0),e}const Vt=e=>qe(e)?Un(e):e,yi=e=>qe(e)?As(e):e;function ot(e){return e?e.__v_isRef===!0:!1}function pe(e){return iu(e,!1)}function iu(e,t){return ot(e)?e:new nu(e,t)}class nu{constructor(t,o){this.dep=new er,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=o?t:Fe(t),this._value=o?t:Vt(t),this.__v_isShallow=o}get value(){return this.dep.track(),this._value}set value(t){const o=this._rawValue,i=this.__v_isShallow||zt(t)||wo(t);t=i?t:Fe(t),Xt(t,o)&&(this._rawValue=t,this._value=i?t:Vt(t),this.dep.trigger())}}function he(e){return ot(e)?e.value:e}const su={get:(e,t,o)=>t==="__v_raw"?e:he(Reflect.get(e,t,o)),set:(e,t,o,i)=>{const n=e[t];return ot(n)&&!ot(o)?(n.value=o,!0):Reflect.set(e,t,o,i)}};function la(e){return Zo(e)?e:new Proxy(e,su)}class ru{constructor(t,o,i){this.fn=t,this.setter=o,this._value=void 0,this.dep=new er(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=Gi-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!o,this.isSSR=i}notify(){if(this.flags|=16,!(this.flags&8)&&Xe!==this)return Yl(this,!0),!0}get value(){const t=this.dep.track();return Xl(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function lu(e,t,o=!1){let i,n;return De(e)?i=e:(i=e.get,n=e.set),new ru(i,n,o)}const an={},An=new WeakMap;let Uo;function au(e,t=!1,o=Uo){if(o){let i=An.get(o);i||An.set(o,i=[]),i.push(e)}}function cu(e,t,o=Ze){const{immediate:i,deep:n,once:s,scheduler:l,augmentJob:r,call:a}=o,c=_=>n?_:zt(_)||n===!1||n===0?po(_,1):po(_);let u,h,y,d,f=!1,p=!1;if(ot(e)?(h=()=>e.value,f=zt(e)):Zo(e)?(h=()=>c(e),f=!0):Me(e)?(p=!0,f=e.some(_=>Zo(_)||zt(_)),h=()=>e.map(_=>{if(ot(_))return _.value;if(Zo(_))return c(_);if(De(_))return a?a(_,2):_()})):De(e)?t?h=a?()=>a(e,2):e:h=()=>{if(y){vo();try{y()}finally{ko()}}const _=Uo;Uo=u;try{return a?a(e,3,[d]):e(d)}finally{Uo=_}}:h=oo,t&&n){const _=h,M=n===!0?1/0:n;h=()=>po(_(),M)}const g=Pd(),b=()=>{u.stop(),g&&g.active&&Ks(g.effects,u)};if(s&&t){const _=t;t=(...M)=>{const A=_(...M);return b(),A}}let k=p?new Array(e.length).fill(an):an;const w=_=>{if(!(!(u.flags&1)||!u.dirty&&!_))if(t){const M=u.run();if(_||n||f||(p?M.some((A,I)=>Xt(A,k[I])):Xt(M,k))){y&&y();const A=Uo;Uo=u;try{const I=[M,k===an?void 0:p&&k[0]===an?[]:k,d];k=M,a?a(t,3,I):t(...I)}finally{Uo=A}}}else u.run()};return r&&r(w),u=new Gl(h),u.scheduler=l?()=>l(w,!1):w,d=_=>au(_,!1,u),y=u.onStop=()=>{const _=An.get(u);if(_){if(a)a(_,4);else for(const M of _)M();An.delete(u)}},t?i?w(!0):k=u.run():l?l(w.bind(null,!0),!0):u.run(),b.pause=u.pause.bind(u),b.resume=u.resume.bind(u),b.stop=b,b}function po(e,t=1/0,o){if(t<=0||!qe(e)||e.__v_skip||(o=o||new Map,(o.get(e)||0)>=t))return e;if(o.set(e,t),t--,ot(e))po(e.value,t,o);else if(Me(e))for(let i=0;i<e.length;i++)po(e[i],t,o);else if(wi(e)||fi(e))e.forEach(i=>{po(i,t,o)});else if(jl(e)){for(const i in e)po(e[i],t,o);for(const i of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,i)&&po(e[i],t,o)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function en(e,t,o,i){try{return i?e(...i):e()}catch(n){Vn(n,t,o)}}function qt(e,t,o,i){if(De(e)){const n=en(e,t,o,i);return n&&Hl(n)&&n.catch(s=>{Vn(s,t,o)}),n}if(Me(e)){const n=[];for(let s=0;s<e.length;s++)n.push(qt(e[s],t,o,i));return n}}function Vn(e,t,o,i=!0){const n=t?t.vnode:null,{errorHandler:s,throwUnhandledErrorInProduction:l}=t&&t.appContext.config||Ze;if(t){let r=t.parent;const a=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${o}`;for(;r;){const u=r.ec;if(u){for(let h=0;h<u.length;h++)if(u[h](e,a,c)===!1)return}r=r.parent}if(s){vo(),en(s,null,10,[e,a,c]),ko();return}}du(e,o,n,i,l)}function du(e,t,o,i=!0,n=!1){if(n)throw e;console.error(e)}const It=[];let Kt=-1;const hi=[];let To=null,ii=0;const aa=Promise.resolve();let Tn=null;function Mn(e){const t=Tn||aa;return e?t.then(this?e.bind(this):e):t}function uu(e){let t=Kt+1,o=It.length;for(;t<o;){const i=t+o>>>1,n=It[i],s=Yi(n);s<e||s===e&&n.flags&2?t=i+1:o=i}return t}function nr(e){if(!(e.flags&1)){const t=Yi(e),o=It[It.length-1];!o||!(e.flags&2)&&t>=Yi(o)?It.push(e):It.splice(uu(t),0,e),e.flags|=1,ca()}}function ca(){Tn||(Tn=aa.then(ua))}function fu(e){Me(e)?hi.push(...e):To&&e.id===-1?To.splice(ii+1,0,e):e.flags&1||(hi.push(e),e.flags|=1),ca()}function Er(e,t,o=Kt+1){for(;o<It.length;o++){const i=It[o];if(i&&i.flags&2){if(e&&i.id!==e.uid)continue;It.splice(o,1),o--,i.flags&4&&(i.flags&=-2),i(),i.flags&4||(i.flags&=-2)}}}function da(e){if(hi.length){const t=[...new Set(hi)].sort((o,i)=>Yi(o)-Yi(i));if(hi.length=0,To){To.push(...t);return}for(To=t,ii=0;ii<To.length;ii++){const o=To[ii];o.flags&4&&(o.flags&=-2),o.flags&8||o(),o.flags&=-2}To=null,ii=0}}const Yi=e=>e.id==null?e.flags&2?-1:1/0:e.id;function ua(e){try{for(Kt=0;Kt<It.length;Kt++){const t=It[Kt];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),en(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;Kt<It.length;Kt++){const t=It[Kt];t&&(t.flags&=-2)}Kt=-1,It.length=0,da(),Tn=null,(It.length||hi.length)&&ua()}}let gt=null,fa=null;function Bn(e){const t=gt;return gt=e,fa=e&&e.type.__scopeId||null,t}function ha(e,t=gt,o){if(!t||e._n)return e;const i=(...n)=>{i._d&&Ur(-1);const s=Bn(t),l=go.length;let r;try{r=e(...n)}finally{for(let a=go.length;a>l;a--)cr();Bn(s),i._d&&Ur(1)}return r};return i._n=!0,i._c=!0,i._d=!0,i}function Ht(e,t){if(gt===null)return e;const o=Yn(gt),i=e.dirs||(e.dirs=[]);for(let n=0;n<t.length;n++){let[s,l,r,a=Ze]=t[n];s&&(De(s)&&(s={mounted:s,updated:s}),s.deep&&po(l),i.push({dir:s,instance:o,value:l,oldValue:void 0,arg:r,modifiers:a}))}return e}function Fo(e,t,o,i){const n=e.dirs,s=t&&t.dirs;for(let l=0;l<n.length;l++){const r=n[l];s&&(r.oldValue=s[l].value);let a=r.dir[i];a&&(vo(),qt(a,o,8,[e.el,r,e,t]),ko())}}function hu(e,t){if(xt){let o=xt.provides;const i=xt.parent&&xt.parent.provides;i===o&&(o=xt.provides=Object.create(i)),o[e]=t}}function Wt(e,t,o=!1){const i=ff();if(i||mi){let n=mi?mi._context.provides:i?i.parent==null||i.ce?i.vnode.appContext&&i.vnode.appContext.provides:i.parent.provides:void 0;if(n&&e in n)return n[e];if(arguments.length>1)return o&&De(t)?t.call(i&&i.proxy):t}}const pu=Symbol.for("v-scx"),mu=()=>Wt(pu);function Po(e,t,o){return pa(e,t,o)}function pa(e,t,o=Ze){const{immediate:i,deep:n,flush:s,once:l}=o,r=yt({},o),a=t&&i||!t&&s!=="post";let c;if(Ji){if(s==="sync"){const d=mu();c=d.__watcherHandles||(d.__watcherHandles=[])}else if(!a){const d=()=>{};return d.stop=oo,d.resume=oo,d.pause=oo,d}}const u=xt;r.call=(d,f,p)=>qt(d,u,f,p);let h=!1;s==="post"?r.scheduler=d=>{Mt(d,u&&u.suspense)}:s!=="sync"&&(h=!0,r.scheduler=(d,f)=>{f?d():nr(d)}),r.augmentJob=d=>{t&&(d.flags|=4),h&&(d.flags|=2,u&&(d.id=u.uid,d.i=u))};const y=cu(e,t,r);return Ji&&(c?c.push(y):a&&y()),y}function gu(e,t,o){const i=this.proxy,n=nt(e)?e.includes(".")?ma(i,e):()=>i[e]:e.bind(i,i);let s;De(t)?s=t:(s=t.handler,o=t);const l=on(this),r=pa(n,s.bind(i),o);return l(),r}function ma(e,t){const o=t.split(".");return()=>{let i=e;for(let n=0;n<o.length&&i;n++)i=i[o[n]];return i}}const yu=Symbol("_vte"),bu=e=>e.__isTeleport,ss=Symbol("_leaveCb");function sr(e,t){e.shapeFlag&6&&e.component?(e.transition=t,sr(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function Pt(e,t){return De(e)?yt({name:e.name},t,{setup:e}):e}function ga(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function Dr(e,t){let o;return!!((o=Object.getOwnPropertyDescriptor(e,t))&&!o.configurable)}const En=new WeakMap;function Pi(e,t,o,i,n=!1){if(Me(e)){e.forEach((p,g)=>Pi(p,t&&(Me(t)?t[g]:t),o,i,n));return}if(pi(i)&&!n){i.shapeFlag&512&&i.type.__asyncResolved&&i.component.subTree.component&&Pi(e,t,o,i.component.subTree);return}const s=i.shapeFlag&4?Yn(i.component):i.el,l=n?null:s,{i:r,r:a}=e,c=t&&t.r,u=r.refs===Ze?r.refs={}:r.refs,h=r.setupState,y=Fe(h),d=h===Ze?zl:p=>Dr(u,p)?!1:je(y,p),f=(p,g)=>!(g&&Dr(u,g));if(c!=null&&c!==a){if(Lr(t),nt(c))u[c]=null,d(c)&&(h[c]=null);else if(ot(c)){const p=t;f(c,p.k)&&(c.value=null),p.k&&(u[p.k]=null)}}if(De(a))en(a,r,12,[l,u]);else{const p=nt(a),g=ot(a);if(p||g){const b=()=>{if(e.f){const k=p?d(a)?h[a]:u[a]:f()||!e.k?a.value:u[e.k];if(n)Me(k)&&Ks(k,s);else if(Me(k))k.includes(s)||k.push(s);else if(p)u[a]=[s],d(a)&&(h[a]=u[a]);else{const w=[s];f(a,e.k)&&(a.value=w),e.k&&(u[e.k]=w)}}else p?(u[a]=l,d(a)&&(h[a]=l)):g&&(f(a,e.k)&&(a.value=l),e.k&&(u[e.k]=l))};if(l){const k=()=>{b(),En.delete(e)};k.id=-1,En.set(e,k),Mt(k,o)}else Lr(e),b()}}}function Lr(e){const t=En.get(e);t&&(t.flags|=8,En.delete(e))}jn().requestIdleCallback;jn().cancelIdleCallback;const pi=e=>!!e.type.__asyncLoader,ya=e=>e.type.__isKeepAlive;function vu(e,t){ba(e,"a",t)}function ku(e,t){ba(e,"da",t)}function ba(e,t,o=xt){const i=e.__wdc||(e.__wdc=()=>{let n=o;for(;n;){if(n.isDeactivated)return;n=n.parent}return e()});if(qn(t,i,o),o){let n=o.parent;for(;n&&n.parent;)ya(n.parent.vnode)&&wu(i,t,o,n),n=n.parent}}function wu(e,t,o,i){const n=qn(t,e,i,!0);tn(()=>{Ks(i[t],n)},o)}function qn(e,t,o=xt,i=!1){if(o){const n=o[e]||(o[e]=[]),s=t.__weh||(t.__weh=(...l)=>{vo();const r=on(o),a=qt(t,o,e,l);return r(),ko(),a});return i?n.unshift(s):n.push(s),s}}const So=e=>(t,o=xt)=>{(!Ji||e==="sp")&&qn(e,(...i)=>t(...i),o)},xu=So("bm"),Qo=So("m"),Su=So("bu"),_u=So("u"),rr=So("bum"),tn=So("um"),Cu=So("sp"),Iu=So("rtg"),$u=So("rtc");function Au(e,t=xt){qn("ec",e,t)}const Tu="components";function Mu(e,t){return Eu(Tu,e,!0,t)||e}const Bu=Symbol.for("v-ndc");function Eu(e,t,o=!0,i=!1){const n=gt||xt;if(n){const s=n.type;{const r=yf(s,!1);if(r&&(r===t||r===Tt(t)||r===Hn(Tt(t))))return s}const l=Or(n[e]||s[e],t)||Or(n.appContext[e],t);return!l&&i?s:l}}function Or(e,t){return e&&(e[t]||e[Tt(t)]||e[Hn(Tt(t))])}function $t(e,t,o,i){let n;const s=o,l=Me(e);if(l||nt(e)){const r=l&&Zo(e);let a=!1,c=!1;r&&(a=!zt(e),c=wo(e),e=Wn(e)),n=new Array(e.length);for(let u=0,h=e.length;u<h;u++)n[u]=t(a?c?yi(Vt(e[u])):Vt(e[u]):e[u],u,void 0,s)}else if(typeof e=="number"){n=new Array(e);for(let r=0;r<e;r++)n[r]=t(r+1,r,void 0,s)}else if(qe(e))if(e[Symbol.iterator])n=Array.from(e,(r,a)=>t(r,a,void 0,s));else{const r=Object.keys(e);n=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const u=r[a];n[a]=t(e[u],u,a,s)}}else n=[];return n}function cn(e,t,o={},i,n,s){if(gt.ce||gt.parent&&pi(gt.parent)&&gt.parent.ce){const c=o,u=Object.keys(c).length>0;return t!=="default"&&(c.name=t),J(),to(Je,null,[se("slot",c,i&&i())],u?-2:64)}let l=e[t];l&&l._c&&(l._d=!1);const r=go.length;J();let a;try{const c=l&&va(l(o)),u=o.key||s||c&&c.key;a=to(Je,{key:(u&&!Ut(u)?u:`_${t}`)+(!c&&i?"_fb":"")},c||(i?i():[]),c&&e._===1?64:-2)}catch(c){for(let u=go.length;u>r;u--)cr();throw c}finally{l&&l._c&&(l._d=!0)}return a}function va(e){return e.some(t=>dr(t)?!(t.type===xo||t.type===Je&&!va(t.children)):!0)?e:null}const Ts=e=>e?za(e)?Yn(e):Ts(e.parent):null,Ri=yt(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>Ts(e.parent),$root:e=>Ts(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>wa(e),$forceUpdate:e=>e.f||(e.f=()=>{nr(e.update)}),$nextTick:e=>e.n||(e.n=Mn.bind(e.proxy)),$watch:e=>gu.bind(e)}),rs=(e,t)=>e!==Ze&&!e.__isScriptSetup&&je(e,t),Du={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:o,setupState:i,data:n,props:s,accessCache:l,type:r,appContext:a}=e;if(t[0]!=="$"){const y=l[t];if(y!==void 0)switch(y){case 1:return i[t];case 2:return n[t];case 4:return o[t];case 3:return s[t]}else{if(rs(i,t))return l[t]=1,i[t];if(n!==Ze&&je(n,t))return l[t]=2,n[t];if(je(s,t))return l[t]=3,s[t];if(o!==Ze&&je(o,t))return l[t]=4,o[t];Ms&&(l[t]=0)}}const c=Ri[t];let u,h;if(c)return t==="$attrs"&&kt(e.attrs,"get",""),c(e);if((u=r.__cssModules)&&(u=u[t]))return u;if(o!==Ze&&je(o,t))return l[t]=4,o[t];if(h=a.config.globalProperties,je(h,t))return h[t]},set({_:e},t,o){const{data:i,setupState:n,ctx:s}=e;return rs(n,t)?(n[t]=o,!0):i!==Ze&&je(i,t)?(i[t]=o,!0):je(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(s[t]=o,!0)},has({_:{data:e,setupState:t,accessCache:o,ctx:i,appContext:n,props:s,type:l}},r){let a;return!!(o[r]||e!==Ze&&r[0]!=="$"&&je(e,r)||rs(t,r)||je(s,r)||je(i,r)||je(Ri,r)||je(n.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(e,t,o){return o.get!=null?e._.accessCache[t]=0:je(o,"value")&&this.set(e,t,o.value,null),Reflect.defineProperty(e,t,o)}};function Nr(e){return Me(e)?e.reduce((t,o)=>(t[o]=null,t),{}):e}let Ms=!0;function Lu(e){const t=wa(e),o=e.proxy,i=e.ctx;Ms=!1,t.beforeCreate&&Pr(t.beforeCreate,e,"bc");const{data:n,computed:s,methods:l,watch:r,provide:a,inject:c,created:u,beforeMount:h,mounted:y,beforeUpdate:d,updated:f,activated:p,deactivated:g,beforeDestroy:b,beforeUnmount:k,destroyed:w,unmounted:_,render:M,renderTracked:A,renderTriggered:I,errorCaptured:N,serverPrefetch:H,expose:z,inheritAttrs:j,components:B,directives:D,filters:x}=t;if(c&&Ou(c,i,null),l)for(const $ in l){const T=l[$];De(T)&&(i[$]=T.bind(o))}if(n){const $=n.call(o,o);qe($)&&(e.data=Un($))}if(Ms=!0,s)for(const $ in s){const T=s[$],O=De(T)?T.bind(o,o):De(T.get)?T.get.bind(o,o):oo,te=!De(T)&&De(T.set)?T.set.bind(o):oo,K=ye({get:O,set:te});Object.defineProperty(i,$,{enumerable:!0,configurable:!0,get:()=>K.value,set:Z=>K.value=Z})}if(r)for(const $ in r)ka(r[$],i,o,$);if(a){const $=De(a)?a.call(o):a;Reflect.ownKeys($).forEach(T=>{hu(T,$[T])})}u&&Pr(u,e,"c");function W($,T){Me(T)?T.forEach(O=>$(O.bind(o))):T&&$(T.bind(o))}if(W(xu,h),W(Qo,y),W(Su,d),W(_u,f),W(vu,p),W(ku,g),W(Au,N),W($u,A),W(Iu,I),W(rr,k),W(tn,_),W(Cu,H),Me(z))if(z.length){const $=e.exposed||(e.exposed={});z.forEach(T=>{Object.defineProperty($,T,{get:()=>o[T],set:O=>o[T]=O,enumerable:!0})})}else e.exposed||(e.exposed={});M&&e.render===oo&&(e.render=M),j!=null&&(e.inheritAttrs=j),B&&(e.components=B),D&&(e.directives=D),H&&ga(e)}function Ou(e,t,o=oo){Me(e)&&(e=Bs(e));for(const i in e){const n=e[i];let s;qe(n)?"default"in n?s=Wt(n.from||i,n.default,!0):s=Wt(n.from||i):s=Wt(n),ot(s)?Object.defineProperty(t,i,{enumerable:!0,configurable:!0,get:()=>s.value,set:l=>s.value=l}):t[i]=s}}function Pr(e,t,o){qt(Me(e)?e.map(i=>i.bind(t.proxy)):e.bind(t.proxy),t,o)}function ka(e,t,o,i){let n=i.includes(".")?ma(o,i):()=>o[i];if(nt(e)){const s=t[e];De(s)&&Po(n,s)}else if(De(e))Po(n,e.bind(o));else if(qe(e))if(Me(e))e.forEach(s=>ka(s,t,o,i));else{const s=De(e.handler)?e.handler.bind(o):t[e.handler];De(s)&&Po(n,s,e)}}function wa(e){const t=e.type,{mixins:o,extends:i}=t,{mixins:n,optionsCache:s,config:{optionMergeStrategies:l}}=e.appContext,r=s.get(t);let a;return r?a=r:!n.length&&!o&&!i?a=t:(a={},n.length&&n.forEach(c=>Dn(a,c,l,!0)),Dn(a,t,l)),qe(t)&&s.set(t,a),a}function Dn(e,t,o,i=!1){const{mixins:n,extends:s}=t;s&&Dn(e,s,o,!0),n&&n.forEach(l=>Dn(e,l,o,!0));for(const l in t)if(!(i&&l==="expose")){const r=Nu[l]||o&&o[l];e[l]=r?r(e[l],t[l]):t[l]}return e}const Nu={data:Rr,props:zr,emits:zr,methods:Mi,computed:Mi,beforeCreate:Ct,created:Ct,beforeMount:Ct,mounted:Ct,beforeUpdate:Ct,updated:Ct,beforeDestroy:Ct,beforeUnmount:Ct,destroyed:Ct,unmounted:Ct,activated:Ct,deactivated:Ct,errorCaptured:Ct,serverPrefetch:Ct,components:Mi,directives:Mi,watch:Ru,provide:Rr,inject:Pu};function Rr(e,t){return t?e?function(){return yt(De(e)?e.call(this,this):e,De(t)?t.call(this,this):t)}:t:e}function Pu(e,t){return Mi(Bs(e),Bs(t))}function Bs(e){if(Me(e)){const t={};for(let o=0;o<e.length;o++)t[e[o]]=e[o];return t}return e}function Ct(e,t){return e?[...new Set([].concat(e,t))]:t}function Mi(e,t){return e?yt(Object.create(null),e,t):t}function zr(e,t){return e?Me(e)&&Me(t)?[...new Set([...e,...t])]:yt(Object.create(null),Nr(e),Nr(t??{})):t}function Ru(e,t){if(!e)return t;if(!t)return e;const o=yt(Object.create(null),e);for(const i in t)o[i]=Ct(e[i],t[i]);return o}function xa(){return{app:null,config:{isNativeTag:zl,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let zu=0;function Hu(e,t){return function(i,n=null){De(i)||(i=yt({},i)),n!=null&&!qe(n)&&(n=null);const s=xa(),l=new WeakSet,r=[];let a=!1;const c=s.app={_uid:zu++,_component:i,_props:n,_container:null,_context:s,_instance:null,version:vf,get config(){return s.config},set config(u){},use(u,...h){return l.has(u)||(u&&De(u.install)?(l.add(u),u.install(c,...h)):De(u)&&(l.add(u),u(c,...h))),c},mixin(u){return s.mixins.includes(u)||s.mixins.push(u),c},component(u,h){return h?(s.components[u]=h,c):s.components[u]},directive(u,h){return h?(s.directives[u]=h,c):s.directives[u]},mount(u,h,y){if(!a){const d=c._ceVNode||se(i,n);return d.appContext=s,y===!0?y="svg":y===!1&&(y=void 0),e(d,u,y),a=!0,c._container=u,u.__vue_app__=c,Yn(d.component)}},onUnmount(u){r.push(u)},unmount(){a&&(qt(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(u,h){return s.provides[u]=h,c},runWithContext(u){const h=mi;mi=c;try{return u()}finally{mi=h}}};return c}}let mi=null;const Fu=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${Tt(t)}Modifiers`]||e[`${Ho(t)}Modifiers`];function ju(e,t,...o){if(e.isUnmounted)return;const i=e.vnode.props||Ze;let n=o;const s=t.startsWith("update:"),l=s&&Fu(i,t.slice(7));l&&(l.trim&&(n=o.map(u=>nt(u)?u.trim():u)),l.number&&(n=o.map(Fn)));let r,a=i[r=es(t)]||i[r=es(Tt(t))];!a&&s&&(a=i[r=es(Ho(t))]),a&&qt(a,e,6,n);const c=i[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,qt(c,e,6,n)}}const Wu=new WeakMap;function Sa(e,t,o=!1){const i=o?Wu:t.emitsCache,n=i.get(e);if(n!==void 0)return n;const s=e.emits;let l={},r=!1;if(!De(e)){const a=c=>{const u=Sa(c,t,!0);u&&(r=!0,yt(l,u))};!o&&t.mixins.length&&t.mixins.forEach(a),e.extends&&a(e.extends),e.mixins&&e.mixins.forEach(a)}return!s&&!r?(qe(e)&&i.set(e,null),null):(Me(s)?s.forEach(a=>l[a]=null):yt(l,s),qe(e)&&i.set(e,l),l)}function Gn(e,t){return!e||!Pn(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),je(e,t[0].toLowerCase()+t.slice(1))||je(e,Ho(t))||je(e,t))}function Hr(e){const{type:t,vnode:o,proxy:i,withProxy:n,propsOptions:[s],slots:l,attrs:r,emit:a,render:c,renderCache:u,props:h,data:y,setupState:d,ctx:f,inheritAttrs:p}=e,g=Bn(e);let b,k;try{if(o.shapeFlag&4){const _=n||i,M=_;b=Jt(c.call(M,_,u,h,d,y,f)),k=r}else{const _=t;b=Jt(_.length>1?_(h,{attrs:r,slots:l,emit:a}):_(h,null)),k=t.props?r:Uu(r)}}catch(_){go.length=0,Vn(_,e,1),b=se(xo)}let w=b;if(k&&p!==!1){const _=Object.keys(k),{shapeFlag:M}=w;_.length&&M&7&&(s&&_.some(Rn)&&(k=Vu(k,s)),w=bi(w,k,!1,!0))}return o.dirs&&(w=bi(w,null,!1,!0),w.dirs=w.dirs?w.dirs.concat(o.dirs):o.dirs),o.transition&&sr(w,o.transition),b=w,Bn(g),b}const Uu=e=>{let t;for(const o in e)(o==="class"||o==="style"||Pn(o))&&((t||(t={}))[o]=e[o]);return t},Vu=(e,t)=>{const o={};for(const i in e)(!Rn(i)||!(i.slice(9)in t))&&(o[i]=e[i]);return o};function qu(e,t,o){const{props:i,children:n,component:s}=e,{props:l,children:r,patchFlag:a}=t,c=s.emitsOptions;if(t.dirs||t.transition)return!0;if(o&&a>=0){if(a&1024)return!0;if(a&16)return i?Fr(i,l,c):!!l;if(a&8){const u=t.dynamicProps;for(let h=0;h<u.length;h++){const y=u[h];if(_a(l,i,y)&&!Gn(c,y))return!0}}}else return(n||r)&&(!r||!r.$stable)?!0:i===l?!1:i?l?Fr(i,l,c):!0:!!l;return!1}function Fr(e,t,o){const i=Object.keys(t);if(i.length!==Object.keys(e).length)return!0;for(let n=0;n<i.length;n++){const s=i[n];if(_a(t,e,s)&&!Gn(o,s))return!0}return!1}function _a(e,t,o){const i=e[o],n=t[o];return o==="style"&&qe(i)&&qe(n)?!xi(i,n):i!==n}function Gu({vnode:e,parent:t,suspense:o},i){for(;t;){const n=t.subTree;if(n.suspense&&n.suspense.activeBranch===e&&(n.suspense.vnode.el=n.el=i,e=n),n===e)(e=t.vnode).el=i,t=t.parent;else break}o&&o.activeBranch===e&&(o.vnode.el=i)}const Ca={},Ia=()=>Object.create(Ca),$a=e=>Object.getPrototypeOf(e)===Ca;function Ku(e,t,o,i=!1){const n={},s=Ia();e.propsDefaults=Object.create(null),Aa(e,t,n,s);for(const l in e.propsOptions[0])l in n||(n[l]=void 0);o?e.props=i?n:tu(n):e.type.props?e.props=n:e.props=s,e.attrs=s}function Yu(e,t,o,i){const{props:n,attrs:s,vnode:{patchFlag:l}}=e,r=Fe(n),[a]=e.propsOptions;let c=!1;if((i||l>0)&&!(l&16)){if(l&8){const u=e.vnode.dynamicProps;for(let h=0;h<u.length;h++){let y=u[h];if(Gn(e.emitsOptions,y))continue;const d=t[y];if(a)if(je(s,y))d!==s[y]&&(s[y]=d,c=!0);else{const f=Tt(y);n[f]=Es(a,r,f,d,e,!1)}else d!==s[y]&&(s[y]=d,c=!0)}}}else{Aa(e,t,n,s)&&(c=!0);let u;for(const h in r)(!t||!je(t,h)&&((u=Ho(h))===h||!je(t,u)))&&(a?o&&(o[h]!==void 0||o[u]!==void 0)&&(n[h]=Es(a,r,h,void 0,e,!0)):delete n[h]);if(s!==r)for(const h in s)(!t||!je(t,h))&&(delete s[h],c=!0)}c&&ho(e.attrs,"set","")}function Aa(e,t,o,i){const[n,s]=e.propsOptions;let l=!1,r;if(t)for(let a in t){if(Li(a))continue;const c=t[a];let u;n&&je(n,u=Tt(a))?!s||!s.includes(u)?o[u]=c:(r||(r={}))[u]=c:Gn(e.emitsOptions,a)||(!(a in i)||c!==i[a])&&(i[a]=c,l=!0)}if(s){const a=Fe(o),c=r||Ze;for(let u=0;u<s.length;u++){const h=s[u];o[h]=Es(n,a,h,c[h],e,!je(c,h))}}return l}function Es(e,t,o,i,n,s){const l=e[o];if(l!=null){const r=je(l,"default");if(r&&i===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&De(a)){const{propsDefaults:c}=n;if(o in c)i=c[o];else{const u=on(n);i=c[o]=a.call(null,t),u()}}else i=a;n.ce&&n.ce._setProp(o,i)}l[0]&&(s&&!r?i=!1:l[1]&&(i===""||i===Ho(o))&&(i=!0))}return i}const Zu=new WeakMap;function Ta(e,t,o=!1){const i=o?Zu:t.propsCache,n=i.get(e);if(n)return n;const s=e.props,l={},r=[];let a=!1;if(!De(e)){const u=h=>{a=!0;const[y,d]=Ta(h,t,!0);yt(l,y),d&&r.push(...d)};!o&&t.mixins.length&&t.mixins.forEach(u),e.extends&&u(e.extends),e.mixins&&e.mixins.forEach(u)}if(!s&&!a)return qe(e)&&i.set(e,ui),ui;if(Me(s))for(let u=0;u<s.length;u++){const h=Tt(s[u]);jr(h)&&(l[h]=Ze)}else if(s)for(const u in s){const h=Tt(u);if(jr(h)){const y=s[u],d=l[h]=Me(y)||De(y)?{type:y}:yt({},y),f=d.type;let p=!1,g=!0;if(Me(f))for(let b=0;b<f.length;++b){const k=f[b],w=De(k)&&k.name;if(w==="Boolean"){p=!0;break}else w==="String"&&(g=!1)}else p=De(f)&&f.name==="Boolean";d[0]=p,d[1]=g,(p||je(d,"default"))&&r.push(h)}}const c=[l,r];return qe(e)&&i.set(e,c),c}function jr(e){return e[0]!=="$"&&!Li(e)}const lr=e=>e==="_"||e==="_ctx"||e==="$stable",ar=e=>Me(e)?e.map(Jt):[Jt(e)],Ju=(e,t,o)=>{if(t._n)return t;const i=ha((...n)=>ar(t(...n)),o);return i._c=!1,i},Ma=(e,t,o)=>{const i=e._ctx;for(const n in e){if(lr(n))continue;const s=e[n];if(De(s))t[n]=Ju(n,s,i);else if(s!=null){const l=ar(s);t[n]=()=>l}}},Ba=(e,t)=>{const o=ar(t);e.slots.default=()=>o},Ea=(e,t,o)=>{for(const i in t)(o||!lr(i))&&(e[i]=t[i])},Xu=(e,t,o)=>{const i=e.slots=Ia();if(e.vnode.shapeFlag&32){const n=t._;n?(Ea(i,t,o),o&&Wl(i,"_",n,!0)):Ma(t,i)}else t&&Ba(e,t)},Qu=(e,t,o)=>{const{vnode:i,slots:n}=e;let s=!0,l=Ze;if(i.shapeFlag&32){const r=t._;r?o&&r===1?s=!1:Ea(n,t,o):(s=!t.$stable,Ma(t,n)),l=t}else t&&(Ba(e,t),l={default:1});if(s)for(const r in n)!lr(r)&&l[r]==null&&delete n[r]},Mt=sf;function ef(e){return tf(e)}function tf(e,t){const o=jn();o.__VUE__=!0;const{insert:i,remove:n,patchProp:s,createElement:l,createText:r,createComment:a,setText:c,setElementText:u,parentNode:h,nextSibling:y,setScopeId:d=oo,insertStaticContent:f}=e,p=(E,F,v,U=null,R=null,S=null,C=void 0,L=null,G=!!F.dynamicChildren)=>{if(E===F)return;E&&!Ai(E,F)&&(U=Ie(E),Z(E,R,S,!0),E=null),F.patchFlag===-2&&(G=!1,F.dynamicChildren=null);const{type:q,ref:Y,shapeFlag:X}=F;switch(q){case Kn:g(E,F,v,U);break;case xo:b(E,F,v,U);break;case pn:E==null&&k(F,v,U,C);break;case Je:B(E,F,v,U,R,S,C,L,G);break;default:X&1?M(E,F,v,U,R,S,C,L,G):X&6?D(E,F,v,U,R,S,C,L,G):(X&64||X&128)&&q.process(E,F,v,U,R,S,C,L,G,P)}Y!=null&&R?Pi(Y,E&&E.ref,S,F||E,!F):Y==null&&E&&E.ref!=null&&Pi(E.ref,null,S,E,!0)},g=(E,F,v,U)=>{if(E==null)i(F.el=r(F.children),v,U);else{const R=F.el=E.el;F.children!==E.children&&c(R,F.children)}},b=(E,F,v,U)=>{E==null?i(F.el=a(F.children||""),v,U):F.el=E.el},k=(E,F,v,U)=>{[E.el,E.anchor]=f(E.children,F,v,U,E.el,E.anchor)},w=({el:E,anchor:F},v,U)=>{let R;for(;E&&E!==F;)R=y(E),i(E,v,U),E=R;i(F,v,U)},_=({el:E,anchor:F})=>{let v;for(;E&&E!==F;)v=y(E),n(E),E=v;n(F)},M=(E,F,v,U,R,S,C,L,G)=>{if(F.type==="svg"?C="svg":F.type==="math"&&(C="mathml"),E==null)A(F,v,U,R,S,C,L,G);else{const q=E.el&&E.el._isVueCE?E.el:null;try{q&&q._beginPatch(),H(E,F,R,S,C,L,G)}finally{q&&q._endPatch()}}},A=(E,F,v,U,R,S,C,L)=>{let G,q;const{props:Y,shapeFlag:X,transition:ae,dirs:ne}=E;if(G=E.el=l(E.type,S,Y&&Y.is,Y),X&8?u(G,E.children):X&16&&N(E.children,G,null,U,R,ls(E,S),C,L),ne&&Fo(E,null,U,"created"),I(G,E,E.scopeId,C,U),Y){for(const Ce in Y)Ce!=="value"&&!Li(Ce)&&s(G,Ce,null,Y[Ce],S,U);"value"in Y&&s(G,"value",null,Y.value,S),(q=Y.onVnodeBeforeMount)&&Gt(q,U,E)}ne&&Fo(E,null,U,"beforeMount");const me=of(R,ae);me&&ae.beforeEnter(G),i(G,F,v),((q=Y&&Y.onVnodeMounted)||me||ne)&&Mt(()=>{try{q&&Gt(q,U,E),me&&ae.enter(G),ne&&Fo(E,null,U,"mounted")}finally{}},R)},I=(E,F,v,U,R)=>{if(v&&d(E,v),U)for(let S=0;S<U.length;S++)d(E,U[S]);if(R){let S=R.subTree;if(F===S||Na(S.type)&&(S.ssContent===F||S.ssFallback===F)){const C=R.vnode;I(E,C,C.scopeId,C.slotScopeIds,R.parent)}}},N=(E,F,v,U,R,S,C,L,G=0)=>{for(let q=G;q<E.length;q++){const Y=E[q]=L?co(E[q]):Jt(E[q]);p(null,Y,F,v,U,R,S,C,L)}},H=(E,F,v,U,R,S,C)=>{const L=F.el=E.el;let{patchFlag:G,dynamicChildren:q,dirs:Y}=F;G|=E.patchFlag&16;const X=E.props||Ze,ae=F.props||Ze;let ne;if(v&&jo(v,!1),(ne=ae.onVnodeBeforeUpdate)&&Gt(ne,v,F,E),Y&&Fo(F,E,v,"beforeUpdate"),v&&jo(v,!0),q&&(!E.dynamicChildren||E.dynamicChildren.length!==q.length)&&(G=0,C=!1,q=null),(X.innerHTML&&ae.innerHTML==null||X.textContent&&ae.textContent==null)&&u(L,""),q?z(E.dynamicChildren,q,L,v,U,ls(F,R),S):C||T(E,F,L,null,v,U,ls(F,R),S,!1),G>0){if(G&16)j(L,X,ae,v,R);else if(G&2&&X.class!==ae.class&&s(L,"class",null,ae.class,R),G&4&&s(L,"style",X.style,ae.style,R),G&8){const me=F.dynamicProps;for(let Ce=0;Ce<me.length;Ce++){const we=me[Ce],Le=X[we],He=ae[we];(He!==Le||we==="value")&&s(L,we,Le,He,R,v)}}G&1&&E.children!==F.children&&u(L,F.children)}else!C&&q==null&&j(L,X,ae,v,R);((ne=ae.onVnodeUpdated)||Y)&&Mt(()=>{ne&&Gt(ne,v,F,E),Y&&Fo(F,E,v,"updated")},U)},z=(E,F,v,U,R,S,C)=>{for(let L=0;L<F.length;L++){const G=E[L],q=F[L],Y=G.el&&(G.type===Je||!Ai(G,q)||G.shapeFlag&198)?h(G.el):v;p(G,q,Y,null,U,R,S,C,!0)}},j=(E,F,v,U,R)=>{if(F!==v){if(F!==Ze)for(const S in F)!Li(S)&&!(S in v)&&s(E,S,F[S],null,R,U);for(const S in v){if(Li(S))continue;const C=v[S],L=F[S];C!==L&&S!=="value"&&s(E,S,L,C,R,U)}"value"in v&&s(E,"value",F.value,v.value,R)}},B=(E,F,v,U,R,S,C,L,G)=>{const q=F.el=E?E.el:r(""),Y=F.anchor=E?E.anchor:r("");let{patchFlag:X,dynamicChildren:ae,slotScopeIds:ne}=F;ne&&(L=L?L.concat(ne):ne),E==null?(i(q,v,U),i(Y,v,U),N(F.children||[],v,Y,R,S,C,L,G)):X>0&&X&64&&ae&&E.dynamicChildren&&E.dynamicChildren.length===ae.length?(z(E.dynamicChildren,ae,v,R,S,C,L),(F.key!=null||R&&F===R.subTree)&&Da(E,F,!0)):T(E,F,v,Y,R,S,C,L,G)},D=(E,F,v,U,R,S,C,L,G)=>{F.slotScopeIds=L,E==null?F.shapeFlag&512?R.ctx.activate(F,v,U,C,G):x(F,v,U,R,S,C,G):V(E,F,G)},x=(E,F,v,U,R,S,C)=>{const L=E.component=uf(E,U,R);if(ya(E)&&(L.ctx.renderer=P),hf(L,!1,C),L.asyncDep){if(R&&R.registerDep(L,W,C),!E.el){const G=L.subTree=se(xo);b(null,G,F,v),E.placeholder=G.el}}else W(L,E,F,v,R,S,C)},V=(E,F,v)=>{const U=F.component=E.component;if(qu(E,F,v))if(U.asyncDep&&!U.asyncResolved){$(U,F,v);return}else U.next=F,U.update();else F.el=E.el,U.vnode=F},W=(E,F,v,U,R,S,C)=>{const L=()=>{if(E.isMounted){let{next:X,bu:ae,u:ne,parent:me,vnode:Ce}=E;{const rt=La(E);if(rt){X&&(X.el=Ce.el,$(E,X,C)),rt.asyncDep.then(()=>{Mt(()=>{E.isUnmounted||q()},R)});return}}let we=X,Le;jo(E,!1),X?(X.el=Ce.el,$(E,X,C)):X=Ce,ae&&hn(ae),(Le=X.props&&X.props.onVnodeBeforeUpdate)&&Gt(Le,me,X,Ce),jo(E,!0);const He=Hr(E),Ge=E.subTree;E.subTree=He,p(Ge,He,h(Ge.el),Ie(Ge),E,R,S),X.el=He.el,we===null&&Gu(E,He.el),ne&&Mt(ne,R),(Le=X.props&&X.props.onVnodeUpdated)&&Mt(()=>Gt(Le,me,X,Ce),R)}else{let X;const{el:ae,props:ne}=F,{bm:me,m:Ce,parent:we,root:Le,type:He}=E,Ge=pi(F);jo(E,!1),me&&hn(me),!Ge&&(X=ne&&ne.onVnodeBeforeMount)&&Gt(X,we,F),jo(E,!0);{Le.ce&&Le.ce._hasShadowRoot()&&Le.ce._injectChildStyle(He,E.parent?E.parent.type:void 0);const rt=E.subTree=Hr(E);p(null,rt,v,U,E,R,S),F.el=rt.el}if(Ce&&Mt(Ce,R),!Ge&&(X=ne&&ne.onVnodeMounted)){const rt=F;Mt(()=>Gt(X,we,rt),R)}(F.shapeFlag&256||we&&pi(we.vnode)&&we.vnode.shapeFlag&256)&&E.a&&Mt(E.a,R),E.isMounted=!0,F=v=U=null}};E.scope.on();const G=E.effect=new Gl(L);E.scope.off();const q=E.update=G.run.bind(G),Y=E.job=G.runIfDirty.bind(G);Y.i=E,Y.id=E.uid,G.scheduler=()=>nr(Y),jo(E,!0),q()},$=(E,F,v)=>{F.component=E;const U=E.vnode.props;E.vnode=F,E.next=null,Yu(E,F.props,U,v),Qu(E,F.children,v),vo(),Er(E),ko()},T=(E,F,v,U,R,S,C,L,G=!1)=>{const q=E&&E.children,Y=E?E.shapeFlag:0,X=F.children,{patchFlag:ae,shapeFlag:ne}=F;if(ae>0){if(ae&128){te(q,X,v,U,R,S,C,L,G);return}else if(ae&256){O(q,X,v,U,R,S,C,L,G);return}}ne&8?(Y&16&&Se(q,R,S),X!==q&&u(v,X)):Y&16?ne&16?te(q,X,v,U,R,S,C,L,G):Se(q,R,S,!0):(Y&8&&u(v,""),ne&16&&N(X,v,U,R,S,C,L,G))},O=(E,F,v,U,R,S,C,L,G)=>{E=E||ui,F=F||ui;const q=E.length,Y=F.length,X=Math.min(q,Y);let ae;for(ae=0;ae<X;ae++){const ne=F[ae]=G?co(F[ae]):Jt(F[ae]);p(E[ae],ne,v,null,R,S,C,L,G)}q>Y?Se(E,R,S,!0,!1,X):N(F,v,U,R,S,C,L,G,X)},te=(E,F,v,U,R,S,C,L,G)=>{let q=0;const Y=F.length;let X=E.length-1,ae=Y-1;for(;q<=X&&q<=ae;){const ne=E[q],me=F[q]=G?co(F[q]):Jt(F[q]);if(Ai(ne,me))p(ne,me,v,null,R,S,C,L,G);else break;q++}for(;q<=X&&q<=ae;){const ne=E[X],me=F[ae]=G?co(F[ae]):Jt(F[ae]);if(Ai(ne,me))p(ne,me,v,null,R,S,C,L,G);else break;X--,ae--}if(q>X){if(q<=ae){const ne=ae+1,me=ne<Y?F[ne].el:U;for(;q<=ae;)p(null,F[q]=G?co(F[q]):Jt(F[q]),v,me,R,S,C,L,G),q++}}else if(q>ae)for(;q<=X;)Z(E[q],R,S,!0),q++;else{const ne=q,me=q,Ce=new Map;for(q=me;q<=ae;q++){const tt=F[q]=G?co(F[q]):Jt(F[q]);tt.key!=null&&Ce.set(tt.key,q)}let we,Le=0;const He=ae-me+1;let Ge=!1,rt=0;const Pe=new Array(He);for(q=0;q<He;q++)Pe[q]=0;for(q=ne;q<=X;q++){const tt=E[q];if(Le>=He){Z(tt,R,S,!0);continue}let Ke;if(tt.key!=null)Ke=Ce.get(tt.key);else for(we=me;we<=ae;we++)if(Pe[we-me]===0&&Ai(tt,F[we])){Ke=we;break}Ke===void 0?Z(tt,R,S,!0):(Pe[Ke-me]=q+1,Ke>=rt?rt=Ke:Ge=!0,p(tt,F[Ke],v,null,R,S,C,L,G),Le++)}const ft=Ge?nf(Pe):ui;for(we=ft.length-1,q=He-1;q>=0;q--){const tt=me+q,Ke=F[tt],ue=F[tt+1],fe=tt+1<Y?ue.el||Oa(ue):U;Pe[q]===0?p(null,Ke,v,fe,R,S,C,L,G):Ge&&(we<0||q!==ft[we]?K(Ke,v,fe,2):we--)}}},K=(E,F,v,U,R=null)=>{const{el:S,type:C,transition:L,children:G,shapeFlag:q}=E;if(q&6){K(E.component.subTree,F,v,U);return}if(q&128){E.suspense.move(F,v,U);return}if(q&64){C.move(E,F,v,P);return}if(C===Je){i(S,F,v);for(let X=0;X<G.length;X++)K(G[X],F,v,U);i(E.anchor,F,v);return}if(C===pn){w(E,F,v);return}if(U!==2&&q&1&&L)if(U===0)L.persisted&&!S[ss]?i(S,F,v):(L.beforeEnter(S),i(S,F,v),Mt(()=>L.enter(S),R));else{const{leave:X,delayLeave:ae,afterLeave:ne}=L,me=()=>{E.ctx.isUnmounted?n(S):i(S,F,v)},Ce=()=>{const we=S._isLeaving||!!S[ss];S._isLeaving&&S[ss](!0),L.persisted&&!we?me():X(S,()=>{me(),ne&&ne()})};ae?ae(S,me,Ce):Ce()}else i(S,F,v)},Z=(E,F,v,U=!1,R=!1)=>{const{type:S,props:C,ref:L,children:G,dynamicChildren:q,shapeFlag:Y,patchFlag:X,dirs:ae,cacheIndex:ne,memo:me}=E;if(X===-2&&(R=!1),L!=null&&(vo(),Pi(L,null,v,E,!0),ko()),ne!=null&&(F.renderCache[ne]=void 0),Y&256){F.ctx.deactivate(E);return}const Ce=Y&1&&ae,we=!pi(E);let Le;if(we&&(Le=C&&C.onVnodeBeforeUnmount)&&Gt(Le,F,E),Y&6)re(E.component,v,U);else{if(Y&128){E.suspense.unmount(v,U);return}Ce&&Fo(E,null,F,"beforeUnmount"),Y&64?E.type.remove(E,F,v,P,U):q&&!q.hasOnce&&(S!==Je||X>0&&X&64)?Se(q,F,v,!1,!0):(S===Je&&X&384||!R&&Y&16)&&Se(G,F,v),U&&ce(E)}const He=me!=null&&ne==null;(we&&(Le=C&&C.onVnodeUnmounted)||Ce||He)&&Mt(()=>{Le&&Gt(Le,F,E),Ce&&Fo(E,null,F,"unmounted"),He&&(E.el=null)},v)},ce=E=>{const{type:F,el:v,anchor:U,transition:R}=E;if(F===Je){oe(v,U);return}if(F===pn){_(E);return}const S=()=>{n(v),R&&!R.persisted&&R.afterLeave&&R.afterLeave()};if(E.shapeFlag&1&&R&&!R.persisted){const{leave:C,delayLeave:L}=R,G=()=>C(v,S);L?L(E.el,S,G):G()}else S()},oe=(E,F)=>{let v;for(;E!==F;)v=y(E),n(E),E=v;n(F)},re=(E,F,v)=>{const{bum:U,scope:R,job:S,subTree:C,um:L,m:G,a:q}=E;Wr(G),Wr(q),U&&hn(U),R.stop(),S&&(S.flags|=8,Z(C,E,F,v)),L&&Mt(L,F),Mt(()=>{E.isUnmounted=!0},F)},Se=(E,F,v,U=!1,R=!1,S=0)=>{for(let C=S;C<E.length;C++)Z(E[C],F,v,U,R)},Ie=E=>{if(E.shapeFlag&6)return Ie(E.component.subTree);if(E.shapeFlag&128)return E.suspense.next();const F=y(E.anchor||E.el),v=F&&F[yu];return v?y(v):F};let ve=!1;const _e=(E,F,v)=>{let U;E==null?F._vnode&&(Z(F._vnode,null,null,!0),U=F._vnode.component):p(F._vnode||null,E,F,null,null,null,v),F._vnode=E,ve||(ve=!0,Er(U),da(),ve=!1)},P={p,um:Z,m:K,r:ce,mt:x,mc:N,pc:T,pbc:z,n:Ie,o:e};return{render:_e,hydrate:void 0,createApp:Hu(_e)}}function ls({type:e,props:t},o){return o==="svg"&&e==="foreignObject"||o==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:o}function jo({effect:e,job:t},o){o?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function of(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function Da(e,t,o=!1){const i=e.children,n=t.children;if(Me(i)&&Me(n))for(let s=0;s<i.length;s++){const l=i[s];let r=n[s];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=n[s]=co(n[s]),r.el=l.el),!o&&r.patchFlag!==-2&&Da(l,r)),r.type===Kn&&(r.patchFlag===-1&&(r=n[s]=co(r)),r.el=l.el),r.type===xo&&!r.el&&(r.el=l.el)}}function nf(e){const t=e.slice(),o=[0];let i,n,s,l,r;const a=e.length;for(i=0;i<a;i++){const c=e[i];if(c!==0){if(n=o[o.length-1],e[n]<c){t[i]=n,o.push(i);continue}for(s=0,l=o.length-1;s<l;)r=s+l>>1,e[o[r]]<c?s=r+1:l=r;c<e[o[s]]&&(s>0&&(t[i]=o[s-1]),o[s]=i)}}for(s=o.length,l=o[s-1];s-- >0;)o[s]=l,l=t[l];return o}function La(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:La(t)}function Wr(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function Oa(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?Oa(t.subTree):null}const Na=e=>e.__isSuspense;function sf(e,t){t&&t.pendingBranch?Me(e)?t.effects.push(...e):t.effects.push(e):fu(e)}const Je=Symbol.for("v-fgt"),Kn=Symbol.for("v-txt"),xo=Symbol.for("v-cmt"),pn=Symbol.for("v-stc"),go=[];let Nt=null;function J(e=!1){go.push(Nt=e?null:[])}function cr(){go.pop(),Nt=go[go.length-1]||null}let Zi=1;function Ur(e,t=!1){Zi+=e,e<0&&Nt&&t&&(Nt.hasOnce=!0)}function Pa(e){return e.dynamicChildren=Zi>0?Nt||ui:null,cr(),Zi>0&&Nt&&Nt.push(e),e}function ee(e,t,o,i,n,s){return Pa(m(e,t,o,i,n,s,!0))}function to(e,t,o,i,n){return Pa(se(e,t,o,i,n,!0))}function dr(e){return e?e.__v_isVNode===!0:!1}function Ai(e,t){return e.type===t.type&&e.key===t.key}const Ra=({key:e})=>e??null,mn=({ref:e,ref_key:t,ref_for:o})=>(typeof e=="number"&&(e=""+e),e!=null?nt(e)||ot(e)||De(e)?{i:gt,r:e,k:t,f:!!o}:e:null);function m(e,t=null,o=null,i=0,n=null,s=e===Je?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&Ra(t),ref:t&&mn(t),scopeId:fa,slotScopeIds:null,children:o,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:i,dynamicProps:n,dynamicChildren:null,appContext:null,ctx:gt};return r?(Ln(a,o),s&128&&e.normalize(a)):o&&(a.shapeFlag|=nt(o)?8:16),Zi>0&&!l&&Nt&&(a.patchFlag>0||s&6)&&a.patchFlag!==32&&Nt.push(a),a}const se=rf;function rf(e,t=null,o=null,i=0,n=null,s=!1){if((!e||e===Bu)&&(e=xo),dr(e)){const r=bi(e,t,!0);return o&&Ln(r,o),Zi>0&&!s&&Nt&&(r.shapeFlag&6?Nt[Nt.indexOf(e)]=r:Nt.push(r)),r.patchFlag=-2,r}if(bf(e)&&(e=e.__vccOpts),t){t=lf(t);let{class:r,style:a}=t;r&&!nt(r)&&(t.class=xe(r)),qe(a)&&(ir(a)&&!Me(a)&&(a=yt({},a)),t.style=Qt(a))}const l=nt(e)?1:Na(e)?128:bu(e)?64:qe(e)?4:De(e)?2:0;return m(e,t,o,i,n,l,s,!0)}function lf(e){return e?ir(e)||$a(e)?yt({},e):e:null}function bi(e,t,o=!1,i=!1){const{props:n,ref:s,patchFlag:l,children:r,transition:a}=e,c=t?af(n||{},t):n,u={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&Ra(c),ref:t&&t.ref?o&&s?Me(s)?s.concat(mn(t)):[s,mn(t)]:mn(t):s,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Je?l===-1?16:l|16:l,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:a,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&bi(e.ssContent),ssFallback:e.ssFallback&&bi(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return a&&i&&sr(u,a.clone(u)),u}function Et(e=" ",t=0){return se(Kn,null,e,t)}function ht(e,t){const o=se(pn,null,e);return o.staticCount=t,o}function Te(e="",t=!1){return t?(J(),to(xo,null,e)):se(xo,null,e)}function Jt(e){return e==null||typeof e=="boolean"?se(xo):Me(e)?se(Je,null,e.slice()):dr(e)?co(e):se(Kn,null,String(e))}function co(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:bi(e)}function Ln(e,t){let o=0;const{shapeFlag:i}=e;if(t==null)t=null;else if(Me(t))o=16;else if(typeof t=="object")if(i&65){const n=t.default;n&&(n._c&&(n._d=!1),Ln(e,n()),n._c&&(n._d=!0));return}else{o=32;const n=t._;!n&&!$a(t)?t._ctx=gt:n===3&&gt&&(gt.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(De(t)){if(i&65){Ln(e,{default:t});return}t={default:t,_ctx:gt},o=32}else t=String(t),i&64?(o=16,t=[Et(t)]):o=8;e.children=t,e.shapeFlag|=o}function af(...e){const t={};for(let o=0;o<e.length;o++){const i=e[o];for(const n in i)if(n==="class")t.class!==i.class&&(t.class=xe([t.class,i.class]));else if(n==="style")t.style=Qt([t.style,i.style]);else if(Pn(n)){const s=t[n],l=i[n];l&&s!==l&&!(Me(s)&&s.includes(l))?t[n]=s?[].concat(s,l):l:l==null&&s==null&&!Rn(n)&&(t[n]=l)}else n!==""&&(t[n]=i[n])}return t}function Gt(e,t,o,i=null){qt(e,t,7,[o,i])}const cf=xa();let df=0;function uf(e,t,o){const i=e.type,n=(t?t.appContext:e.appContext)||cf,s={uid:df++,vnode:e,type:i,parent:t,appContext:n,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Nd(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(n.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Ta(i,n),emitsOptions:Sa(i,n),emit:null,emitted:null,propsDefaults:Ze,inheritAttrs:i.inheritAttrs,ctx:Ze,data:Ze,props:Ze,attrs:Ze,slots:Ze,refs:Ze,setupState:Ze,setupContext:null,suspense:o,suspenseId:o?o.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return s.ctx={_:s},s.root=t?t.root:s,s.emit=ju.bind(null,s),e.ce&&e.ce(s),s}let xt=null;const ff=()=>xt||gt;let On,Ds;{const e=jn(),t=(o,i)=>{let n;return(n=e[o])||(n=e[o]=[]),n.push(i),s=>{n.length>1?n.forEach(l=>l(s)):n[0](s)}};On=t("__VUE_INSTANCE_SETTERS__",o=>xt=o),Ds=t("__VUE_SSR_SETTERS__",o=>Ji=o)}const on=e=>{const t=xt;return On(e),e.scope.on(),()=>{e.scope.off(),On(t)}},Vr=()=>{xt&&xt.scope.off(),On(null)};function za(e){return e.vnode.shapeFlag&4}let Ji=!1;function hf(e,t=!1,o=!1){t&&Ds(t);const{props:i,children:n}=e.vnode,s=za(e);Ku(e,i,s,t),Xu(e,n,o||t);const l=s?pf(e,t):void 0;return t&&Ds(!1),l}function pf(e,t){const o=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,Du);const{setup:i}=o;if(i){vo();const n=e.setupContext=i.length>1?gf(e):null,s=on(e),l=en(i,e,0,[e.props,n]),r=Hl(l);if(ko(),s(),(r||e.sp)&&!pi(e)&&ga(e),r){if(l.then(Vr,Vr),t)return l.then(a=>{qr(e,a)}).catch(a=>{Vn(a,e,0)});e.asyncDep=l}else qr(e,l)}else Ha(e)}function qr(e,t,o){De(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:qe(t)&&(e.setupState=la(t)),Ha(e)}function Ha(e,t,o){const i=e.type;e.render||(e.render=i.render||oo);{const n=on(e);vo();try{Lu(e)}finally{ko(),n()}}}const mf={get(e,t){return kt(e,"get",""),e[t]}};function gf(e){const t=o=>{e.exposed=o||{}};return{attrs:new Proxy(e.attrs,mf),slots:e.slots,emit:e.emit,expose:t}}function Yn(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(la(ou(e.exposed)),{get(t,o){if(o in t)return t[o];if(o in Ri)return Ri[o](e)},has(t,o){return o in t||o in Ri}})):e.proxy}function yf(e,t=!0){return De(e)?e.displayName||e.name:e.name||t&&e.__name}function bf(e){return De(e)&&"__vccOpts"in e}const ye=(e,t)=>lu(e,t,Ji),vf="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Ls;const Gr=typeof window<"u"&&window.trustedTypes;if(Gr)try{Ls=Gr.createPolicy("vue",{createHTML:e=>e})}catch{}const Fa=Ls?e=>Ls.createHTML(e):e=>e,kf="http://www.w3.org/2000/svg",wf="http://www.w3.org/1998/Math/MathML",ao=typeof document<"u"?document:null,Kr=ao&&ao.createElement("template"),xf={insert:(e,t,o)=>{t.insertBefore(e,o||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,o,i)=>{const n=t==="svg"?ao.createElementNS(kf,e):t==="mathml"?ao.createElementNS(wf,e):o?ao.createElement(e,{is:o}):ao.createElement(e);return e==="select"&&i&&i.multiple!=null&&n.setAttribute("multiple",i.multiple),n},createText:e=>ao.createTextNode(e),createComment:e=>ao.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>ao.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,o,i,n,s){const l=o?o.previousSibling:t.lastChild;if(n&&(n===s||n.nextSibling))for(;t.insertBefore(n.cloneNode(!0),o),!(n===s||!(n=n.nextSibling)););else{Kr.innerHTML=Fa(i==="svg"?`<svg>${e}</svg>`:i==="mathml"?`<math>${e}</math>`:e);const r=Kr.content;if(i==="svg"||i==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}t.insertBefore(r,o)}return[l?l.nextSibling:t.firstChild,o?o.previousSibling:t.lastChild]}},Sf=Symbol("_vtc");function _f(e,t,o){const i=e[Sf];i&&(t=(t?[t,...i]:[...i]).join(" ")),t==null?e.removeAttribute("class"):o?e.setAttribute("class",t):e.className=t}const Nn=Symbol("_vod"),ja=Symbol("_vsh"),Os={name:"show",beforeMount(e,{value:t},{transition:o}){e[Nn]=e.style.display==="none"?"":e.style.display,o&&t?o.beforeEnter(e):Ti(e,t)},mounted(e,{value:t},{transition:o}){o&&t&&o.enter(e)},updated(e,{value:t,oldValue:o},{transition:i}){!t!=!o&&(i?t?(i.beforeEnter(e),Ti(e,!0),i.enter(e)):i.leave(e,()=>{Ti(e,!1)}):Ti(e,t))},beforeUnmount(e,{value:t}){Ti(e,t)}};function Ti(e,t){e.style.display=t?e[Nn]:"none",e[ja]=!t}const Cf=Symbol(""),If=/(?:^|;)\s*display\s*:/;function $f(e,t,o){const i=e.style,n=nt(o);let s=!1;if(o&&!n){if(t)if(nt(t))for(const l of t.split(";")){const r=l.slice(0,l.indexOf(":")).trim();o[r]==null&&Bi(i,r,"")}else for(const l in t)o[l]==null&&Bi(i,l,"");for(const l in o){l==="display"&&(s=!0);const r=o[l];r!=null?Tf(e,l,!nt(t)&&t?t[l]:void 0,r)||Bi(i,l,r):Bi(i,l,"")}}else if(n){if(t!==o){const l=i[Cf];l&&(o+=";"+l),i.cssText=o,s=If.test(o)}}else t&&e.removeAttribute("style");Nn in e&&(e[Nn]=s?i.display:"",e[ja]&&(i.display="none"))}const Yr=/\s*!important$/;function Bi(e,t,o){if(Me(o))o.forEach(i=>Bi(e,t,i));else if(o==null&&(o=""),t.startsWith("--"))e.setProperty(t,o);else{const i=Af(e,t);Yr.test(o)?e.setProperty(Ho(i),o.replace(Yr,""),"important"):e[i]=o}}const Zr=["Webkit","Moz","ms"],as={};function Af(e,t){const o=as[t];if(o)return o;let i=Tt(t);if(i!=="filter"&&i in e)return as[t]=i;i=Hn(i);for(let n=0;n<Zr.length;n++){const s=Zr[n]+i;if(s in e)return as[t]=s}return t}function Tf(e,t,o,i){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&nt(i)&&o===i}const Jr="http://www.w3.org/1999/xlink";function Xr(e,t,o,i,n,s=Ld(t)){i&&t.startsWith("xlink:")?o==null?e.removeAttributeNS(Jr,t.slice(6,t.length)):e.setAttributeNS(Jr,t,o):o==null||s&&!Ul(o)?e.removeAttribute(t):e.setAttribute(t,s?"":Ut(o)?String(o):o)}function Qr(e,t,o,i,n){if(t==="innerHTML"||t==="textContent"){o!=null&&(e[t]=t==="innerHTML"?Fa(o):o);return}const s=e.tagName;if(t==="value"&&s!=="PROGRESS"&&!s.includes("-")){const r=s==="OPTION"?e.getAttribute("value")||"":e.value,a=o==null?e.type==="checkbox"?"on":"":String(o);(r!==a||!("_value"in e))&&(e.value=a),o==null&&e.removeAttribute(t),e._value=o;return}let l=!1;if(o===""||o==null){const r=typeof e[t];r==="boolean"?o=Ul(o):o==null&&r==="string"?(o="",l=!0):r==="number"&&(o=0,l=!0)}try{e[t]=o}catch{}l&&e.removeAttribute(n||t)}function Mo(e,t,o,i){e.addEventListener(t,o,i)}function Mf(e,t,o,i){e.removeEventListener(t,o,i)}const el=Symbol("_vei");function Bf(e,t,o,i,n=null){const s=e[el]||(e[el]={}),l=s[t];if(i&&l)l.value=i;else{const[r,a]=Lf(t);if(i){const c=s[t]=Pf(i,n);Mo(e,r,c,a)}else l&&(Mf(e,r,l,a),s[t]=void 0)}}const Ef=/(Once|Passive|Capture)$/,Df=/^on:?(?:Once|Passive|Capture)$/;function Lf(e){let t,o;for(;(o=e.match(Ef))&&!Df.test(e);)t||(t={}),e=e.slice(0,e.length-o[1].length),t[o[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):Ho(e.slice(2)),t]}let cs=0;const Of=Promise.resolve(),Nf=()=>cs||(Of.then(()=>cs=0),cs=Date.now());function Pf(e,t){const o=i=>{if(!i._vts)i._vts=Date.now();else if(i._vts<=o.attached)return;const n=o.value;if(Me(n)){const s=i.stopImmediatePropagation;i.stopImmediatePropagation=()=>{s.call(i),i._stopped=!0};const l=n.slice(),r=[i];for(let a=0;a<l.length&&!i._stopped;a++){const c=l[a];c&&qt(c,t,5,r)}}else qt(n,t,5,[i])};return o.value=e,o.attached=Nf(),o}const tl=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,Rf=(e,t,o,i,n,s)=>{const l=n==="svg";t==="class"?_f(e,i,l):t==="style"?$f(e,o,i):Pn(t)?Rn(t)||Bf(e,t,o,i,s):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):zf(e,t,i,l))?(Qr(e,t,i),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&Xr(e,t,i,l,s,t!=="value")):e._isVueCE&&(Hf(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!nt(i)))?Qr(e,Tt(t),i,s,t):(t==="true-value"?e._trueValue=i:t==="false-value"&&(e._falseValue=i),Xr(e,t,i,l))};function zf(e,t,o,i){if(i)return!!(t==="innerHTML"||t==="textContent"||t in e&&tl(t)&&De(o));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const n=e.tagName;if(n==="IMG"||n==="VIDEO"||n==="CANVAS"||n==="SOURCE")return!1}return tl(t)&&nt(o)?!1:t in e}function Hf(e,t){const o=e._def.props;if(!o)return!1;const i=Tt(t);return Array.isArray(o)?o.some(n=>Tt(n)===i):Object.keys(o).some(n=>Tt(n)===i)}const vi=e=>{const t=e.props["onUpdate:modelValue"]||!1;return Me(t)?o=>hn(t,o):t};function Ff(e){e.target.composing=!0}function ol(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const yo=Symbol("_assign");function il(e,t,o){return t&&(e=e.trim()),o&&(e=Fn(e)),e}const Ns={created(e,{modifiers:{lazy:t,trim:o,number:i}},n){e[yo]=vi(n);const s=i||n.props&&n.props.type==="number";Mo(e,t?"change":"input",l=>{l.target.composing||e[yo](il(e.value,o,s))}),(o||s)&&Mo(e,"change",()=>{e.value=il(e.value,o,s)}),t||(Mo(e,"compositionstart",Ff),Mo(e,"compositionend",ol),Mo(e,"change",ol))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:o,modifiers:{lazy:i,trim:n,number:s}},l){if(e[yo]=vi(l),e.composing)return;const r=(s||e.type==="number")&&!/^0\d/.test(e.value)?Fn(e.value):e.value,a=t??"";if(r===a)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(i&&t===o||n&&e.value.trim()===a)||(e.value=a)}},dn={deep:!0,created(e,t,o){e[yo]=vi(o),Mo(e,"change",()=>{const i=e._modelValue,n=Xi(e),s=e.checked,l=e[yo];if(Me(i)){const r=Zs(i,n),a=r!==-1;if(s&&!a)l(i.concat(n));else if(!s&&a){const c=[...i];c.splice(r,1),l(c)}}else if(wi(i)){const r=new Set(i);s?r.add(n):r.delete(n),l(r)}else l(Wa(e,s))})},mounted:nl,beforeUpdate(e,t,o){e[yo]=vi(o),nl(e,t,o)}};function nl(e,{value:t,oldValue:o},i){e._modelValue=t;let n;if(Me(t))n=Zs(t,i.props.value)>-1;else if(wi(t))n=t.has(i.props.value);else{if(t===o)return;n=xi(t,Wa(e,!0))}e.checked!==n&&(e.checked=n)}const jf={deep:!0,created(e,{value:t,modifiers:{number:o}},i){e._modelValue=t,Mo(e,"change",()=>{const n=Array.prototype.filter.call(e.options,s=>s.selected).map(s=>o?Fn(Xi(s)):Xi(s));e[yo](e.multiple?wi(e._modelValue)?new Set(n):n:n[0]),e._assigning=!0,Mn(()=>{e._assigning=!1})}),e[yo]=vi(i)},mounted(e,{value:t}){sl(e,t)},beforeUpdate(e,{value:t},o){e._modelValue=t,e[yo]=vi(o)},updated(e,{value:t}){e._assigning||sl(e,t)}};function sl(e,t){const o=e.multiple,i=Me(t);if(!(o&&!i&&!wi(t))){for(let n=0,s=e.options.length;n<s;n++){const l=e.options[n],r=Xi(l);if(o)if(i){const a=typeof r;a==="string"||a==="number"?l.selected=t.some(c=>String(c)===String(r)):l.selected=Zs(t,r)>-1}else l.selected=t.has(r);else if(xi(Xi(l),t)){e.selectedIndex!==n&&(e.selectedIndex=n);return}}!o&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function Xi(e){return"_value"in e?e._value:e.value}function Wa(e,t){const o=t?"_trueValue":"_falseValue";return o in e?e[o]:t}const Wf=["ctrl","shift","alt","meta"],Uf={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>Wf.some(o=>e[`${o}Key`]&&!t.includes(o))},eo=(e,t)=>{if(!e)return e;const o=e._withMods||(e._withMods={}),i=t.join(".");return o[i]||(o[i]=((n,...s)=>{for(let l=0;l<t.length;l++){const r=Uf[t[l]];if(r&&r(n,t))return}return e(n,...s)}))},Vf={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},qf=(e,t)=>{const o=e._withKeys||(e._withKeys={}),i=t.join(".");return o[i]||(o[i]=(n=>{if(!("key"in n))return;const s=Ho(n.key);if(t.some(l=>l===s||Vf[l]===s))return e(n)}))},Gf=yt({patchProp:Rf},xf);let rl;function Kf(){return rl||(rl=ef(Gf))}const ur=((...e)=>{const t=Kf().createApp(...e),{mount:o}=t;return t.mount=i=>{const n=Zf(i);if(!n)return;const s=t._component;!De(s)&&!s.render&&!s.template&&(s.template=n.innerHTML),n.nodeType===1&&(n.textContent="");const l=o(n,!1,Yf(n));return n instanceof Element&&(n.removeAttribute("v-cloak"),n.setAttribute("data-v-app","")),l},t});function Yf(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function Zf(e){return nt(e)?document.querySelector(e):e}const Jf="slides-config.json",Oo={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0},Yt=Un({...Oo});function Xf(e){if(!e||typeof e!="object")return{...Oo};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():Oo.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers!==void 0?!!t.showUnorderedListMarkers:Oo.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers!==void 0?!!t.showOrderedListMarkers:Oo.showOrderedListMarkers}}function uo(e){if(!e||typeof e!="object")return{...Yt};const t=e;return t.enableWebServeJump!==void 0&&(Yt.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(Yt.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(Yt.normalizeHeadingSizes=!!t.normalizeHeadingSizes),t.showUnorderedListMarkers!==void 0&&(Yt.showUnorderedListMarkers=!!t.showUnorderedListMarkers),t.showOrderedListMarkers!==void 0&&(Yt.showOrderedListMarkers=!!t.showOrderedListMarkers),{...Yt}}function Zn(){return{...Yt}}function Ua(e,t,o){const i=(e||Oo.webServeUrl).trim(),n=i.startsWith("http://")||i.startsWith("https://")?i:`http://${i}`,s=(o==null?void 0:o.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(n);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",t),o!=null&&o.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",s),l.toString()}catch{const l=o!=null&&o.focus?"&focus=1":"";return`${n.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${l}&r=${s}`}}const oi={theme:"apple-basic",aspectRatio:"16/9",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",background:"",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0};function Qf(e){var n,s,l,r,a,c;const t=Zn();if(!e)return{...oi,normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers};const o=e[Ir]!==void 0?e[Ir]!=="false":t.showUnorderedListMarkers,i=e[$r]!==void 0?e[$r]!=="false":t.showOrderedListMarkers;return{theme:((n=e[Wi])==null?void 0:n.trim())||oi.theme,aspectRatio:((s=e[Ui])==null?void 0:s.trim())||oi.aspectRatio,defaultTransition:((l=e[Vi])==null?void 0:l.trim())||oi.defaultTransition,colorSchema:((r=e[Ol])==null?void 0:r.trim())||oi.colorSchema,spacing:((a=e[Ss])==null?void 0:a.trim())||oi.spacing,background:((c=e[Sn])==null?void 0:c.trim())||"",normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:o,showOrderedListMarkers:i}}function mo(e){var o,i,n,s,l;const t=(o=e.ial)==null?void 0:o[fo];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((i=e.markdown)==null?void 0:i.trim())==="---"||((n=e.markdown)==null?void 0:n.trim())==="***"||e.type==="b"&&(((s=e.markdown)==null?void 0:s.trim())==="---"||((l=e.content)==null?void 0:l.trim())==="---"))}function ll(e){const t={};let o="";if(!e)return{frontmatter:t,notes:o};e[be]&&(t.layout=e[be].trim()),e[wt]&&(t.transition=e[wt].trim()),e[ct]&&(t.background=e[ct].trim()),e[Ft]&&(t.image=e[Ft].trim()),e[ri]&&(t.class=e[ri].trim()),e[Di]&&(t.spacing=e[Di].trim()),e[mt]&&(t.layoutRatio=e[mt].trim()),e[li]&&(t.mask=e[li].trim()),e[Ko]&&(t.maskRatio=e[Ko].trim()),e[ai]&&(t.maskStyle=e[ai].trim()),e[ci]&&(t.maskInitial=e[ci].trim()),e[Qn]&&(o=e[Qn].trim());for(const[i,n]of Object.entries(e))if(i.startsWith("custom-slides-")&&![be,mt,li,Ko,ai,ci,wt,ct,Ft,ri,Di,Qn,fo].includes(i)){const s=i.replace(/^custom-slides-/,"");try{t[s]=JSON.parse(n)}catch{t[s]=n}}return{frontmatter:t,notes:o}}function al(e){const t={};if(!e)return t;const o=e[Ve];o!=null&&o!==""&&o!=="false"&&o!=="0"&&(t.isNote=!0);const i=e[Ye],n=e[ct];(i===Nl||n==="true"||n==="1")&&(t.isBackground=!0);const s=e[be];s===In||s===$n?t.imageLayout=s:(i===In||i===$n)&&(t.imageLayout=i);const l=e[Oe];if(l!=null&&(t.clicks=l.trim()),e[At])try{const r=JSON.parse(e[At]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[At].trim()}}return e[Xo]&&(t.shikiLines=e[Xo].trim()),e[qi]&&(t.maxHeight=e[qi].trim()),e[Ae]&&(t.slot=e[Ae].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function bo(e,t){const o=(e||t||"").trim();if(!o)return null;const i=o.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(i)return i[1].trim();const n=o.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(n)return n[1].trim();const s=o.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(s)?s:null}function zi(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const o=t[0],i=o.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!i)return e;const n=i[1].length,s=i[2].trim(),l=o.length-i[2].length;if(t.length===1)return s;const r=[s];for(let a=1;a<t.length;a++){const c=t[a];if(!c.trim()){r.push("");continue}const u=c.match(/^(\s*)/),h=u?u[1].length:0;h>=l?r.push(c.slice(l)):h>n?r.push(c.slice(h)):r.push(c)}return r.join(`
`)}function Ro(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const o=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(o)}function ds(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const o=e.trim();if(!o)return`repeat(${t}, 1fr)`;if(o.includes(":")){const n=o.split(":").map(s=>parseFloat(s.trim())).filter(s=>!isNaN(s)&&s>0);if(n.length>=2)return n.map(s=>`${s}fr`).join(" ")}const i=o.split(/\s+/).filter(Boolean);return i.length>=2?i.join(" "):`repeat(${t}, 1fr)`}function Hi(e){if(!e)return[];if(ut(e)&&io(e)&&!no(e)){const i=Si(e),n=[];for(const s of i)n.push(...Hi(s));return n}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const l=e.children.filter(Ro);if(l.length>0)return l}const n=(e.markdown||e.content||"").trim().split(/\r?\n/),s=[];for(let l=0;l<n.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(n[l])&&s.push(l);if(s.length>=2){const l=[];for(let r=0;r<s.length;r++){const a=s[r],c=r+1<s.length?s[r+1]:n.length,u=n.slice(a,c).join(`
`);l.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:u,content:u,ial:{...e.ial||{}}})}return l}}return Ro(e)?[e]:[]}function fr(e){var n;if(!e||!ut(e)||!io(e)||no(e))return null;const t=Si(e);if(t.length===0)return null;if(t.length===1&&ut(t[0])&&io(t[0])){const s=fr(t[0]);return s?{items:s.items,nestedSuperBlocks:[t[0],...s.nestedSuperBlocks]}:null}const o=[];for(const s of t)if(ut(s)){o.push(s);const l=((n=s.children)==null?void 0:n.filter(ut))||[];o.push(...l)}const i=t.map(Hi);if(i.length>=2&&i.every(s=>s.length>0)){const s=i.flat();if(s.length>=2&&s.length<=6)return{items:s,nestedSuperBlocks:o}}if(t.length===2){const s=Hi(t[0]),l=Hi(t[1]);if(s.length+l.length>=2&&s.length+l.length<=6&&(s.length>0||l.length>0))return{items:[...s,...l],nestedSuperBlocks:o}}return null}function eh(e){if(!e||!ut(e)||!io(e)||no(e))return null;const t=fr(e);if(!t)return null;const{items:o,nestedSuperBlocks:i}=t;if(o.length<2||o.length>6)return null;const n=hr(e)||void 0,s=o.length;return{superBlockNode:e,nestedSuperBlocks:i,count:s,layout:"cols-header",items:o,slots:o.map((l,r)=>`col-${r+1}`),ratio:n}}function Va(e){if(!e||!ut(e)||!io(e)||no(e))return null;const t=Si(e);if(t.length===0)return null;const o=[];for(const i of t){const n=Hi(i);if(n.length===0)return null;o.push(...n)}return o}function th(e){if(!e||!ut(e)||!io(e)||no(e))return null;const t=Va(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function oh(e){if(!e||!ut(e)||!io(e)||no(e))return null;const t=fr(e);if(t&&t.items.length===4)return t.items;const o=Va(e);if(o&&o.length===4)return o;const i=Si(e);return i.length===4?i:null}function ih(e,t){if(!e||e.length===0)return null;const o=[];function i(r,a){if(ut(r)){const c=oh(r);c&&c.length===4&&o.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)i(c,a)}for(let r=0;r<e.length;r++)i(e[r],r);if(o.length===0)return null;let n=null;t&&(n=o.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const a=c=>c.id===t?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),n||(n=o[0]);const l=e.slice(0,n.topLevelIndex).slice().reverse().find(r=>qa(r));return{superBlockNode:n.sbNode,items:n.items,headerNode:l}}function nh(e,t,o){var u,h,y,d,f;const i=[],n=[],s=(o==null?void 0:o.tracked)||[],l=[];let r={pageTargetId:e,blocks:[]};l.push(r);for(let p=0;p<t.length;p++){const g=t[p];if(mo(g)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=g.id,r.blocks.push(g);continue}r={pageTargetId:g.id,blocks:[g]},l.push(r)}else r.blocks.push(g)}function a(p){const g=[];for(const b of p)ut(b)&&g.push(b),b.children&&b.children.length>0&&g.push(...a(b.children));return g}function c(p,g,b){const k={blockId:p,attrs:g,previousAttrs:b};i.push(k),o!=null&&o.onTagChange&&o.onTagChange(k)}for(const p of l){const g=p.pageTargetId,b=t.find(A=>A.id===g),k=s.find(A=>A.pageTargetId===g);if(p.blocks.some(A=>{var I,N;return!!(no(A)||Ps(A)&&(((I=A.ial)==null?void 0:I[be])==="image-left"||((N=A.ial)==null?void 0:N[be])==="image-right"))})){if(k){const A=k.headerId;if(A){c(A,{[Ae]:""});const I=t.find(N=>N.id===A);I!=null&&I.ial&&(I.ial[Ae]="")}for(const I of k.itemIds){c(I,{[Ae]:""});const N=t.find(H=>H.id===I);N!=null&&N.ial&&(N.ial[Ae]="")}}continue}let _=null,M=-1;for(let A=0;A<p.blocks.length;A++){const I=p.blocks[A],N=ut(I)?[I,...a(I.children||[])]:I.children?a(I.children):[];for(const H of N){const z=eh(H);if(z){_=z,M=A;break}}if(_)break}if(_){const{superBlockNode:A,layout:I,items:N,slots:H}=_,j=p.blocks.slice(0,M).find($=>qa($)),B=j==null?void 0:j.id,D=((u=b==null?void 0:b.ial)==null?void 0:u[be])||"",x=D==="clover",V=x?"clover":I;if(D!==V&&(c(g,{[be]:V},{[be]:D}),b&&(b.ial||(b.ial={}),b.ial[be]=V)),j){const $=((h=j.ial)==null?void 0:h[Ae])||"";$!=="header"&&(c(j.id,{[Ae]:"header"},{[Ae]:$}),j.ial||(j.ial={}),j.ial[Ae]="header")}if(k!=null&&k.headerId&&k.headerId!==B){c(k.headerId,{[Ae]:""});const $=t.find(T=>T.id===k.headerId);$&&($.ial||($.ial={}),$.ial[Ae]="")}const W=[];for(let $=0;$<N.length;$++){const T=N[$],O=H[$];W.push(T.id);const te=((y=T.ial)==null?void 0:y[Ae])||"";if(te!==O&&(c(T.id,{[Ae]:O},{[Ae]:te}),T.ial||(T.ial={}),T.ial[Ae]=O),T.children&&T.children.length>0)for(const K of T.children)K.ial||(K.ial={}),K.ial[Ae]!==O&&(K.ial[Ae]=O)}if(k!=null&&k.itemIds){for(const $ of k.itemIds)if(!W.includes($)){c($,{[Ae]:""});const T=t.find(O=>O.id===$);T&&(T.ial||(T.ial={}),T.ial[Ae]="")}}n.push({superBlockId:A.id,nestedSuperBlockIds:(d=_.nestedSuperBlocks)==null?void 0:d.map($=>$.id),pageTargetId:g,headerId:B,itemIds:W,layout:x?"clover":I})}else{let A=!1;const I=[];for(const z of p.blocks){const j=ut(z)?[z,...a(z.children||[])]:z.children?a(z.children):[];for(const B of j){const D=th(B);if(D){A=!0;for(const x of D.items)I.push(x.id)}}}const N=((f=b==null?void 0:b.ial)==null?void 0:f[be])||"",H=di(N);if(k||A&&H){c(g,{[be]:""},{[be]:N}),b&&(b.ial||(b.ial={}),b.ial[be]="");const z=k==null?void 0:k.headerId;if(z){c(z,{[Ae]:""});const B=t.find(D=>D.id===z);B&&(B.ial||(B.ial={}),B.ial[Ae]="")}const j=new Set([...(k==null?void 0:k.itemIds)||[],...I]);for(const B of j){c(B,{[Ae]:""});const D=t.find(x=>x.id===B);D&&(D.ial||(D.ial={}),D.ial[Ae]="")}}}}return{changes:i,newTracked:n}}function ut(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function io(e){if(!ut(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const i=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(i==="col"||i==="h")return!0;if(i==="row"||i==="v")return!1}if(e.children&&e.children.length>0){for(const i of e.children)if(i.type==="NodeSuperBlockLayoutMarker"||i.type==="layout-marker"){const n=(i.content||i.markdown||"").trim().toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}}const o=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(o)?!0:!/^\{\{\{row\b/i.test(o)}function Ps(e){return!e||Ro(e)||ut(e)||!bo(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function hr(e){var y;if(!e||!ut(e)||!io(e))return null;const t=Si(e);if(!t||t.length<2)return null;const o=[];let i=!1;for(const d of t){const f=(((y=d.ial)==null?void 0:y.style)||d.style||"").trim();let p=null;if(f){const g=f.match(/calc\(\s*([\d.]+)%/i);if(g)p=parseFloat(g[1]);else{const b=f.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);b&&(p=parseFloat(b[1]))}}p!==null&&!isNaN(p)&&p>0?(o.push(p),i=!0):o.push(null)}if(!i)return null;const n=t.length,s=o.reduce((d,f)=>d+(f||0),0),l=o.filter(d=>d===null).length,r=Math.max(0,100-s),a=l>0?r/l:100/n,c=o.map(d=>d!==null?d:a),u=c.reduce((d,f)=>d+f,0);if(u<=0)return null;const h=c.map(d=>d/u*100);if(h.length===2){const[d]=h;if(d>=48&&d<=52)return"1:1";if(d>=31&&d<=35)return"1:2";if(d>=65&&d<=69)return"2:1";if(d>=28&&d<=32)return"3:7";if(d>=68&&d<=72)return"7:3";if(d>=38&&d<=42)return"4:6";if(d>=58&&d<=62)return"6:4";if(d>=23&&d<=27)return"1:3";if(d>=73&&d<=77)return"3:1";const f=Math.round(d),p=100-f;return`${f}:${p}`}if(h.length===3){const[d,f,p]=h;if(d>=31&&d<=35&&f>=31&&f<=35&&p>=31&&p<=35)return"1:1:1";if(d>=23&&d<=27&&f>=48&&f<=52&&p>=23&&p<=27)return"1:2:1";if(d>=48&&d<=52&&f>=23&&f<=27&&p>=23&&p<=27)return"2:1:1";if(d>=23&&d<=27&&f>=23&&f<=27&&p>=48&&p<=52)return"1:1:2";if(d>=18&&d<=22&&f>=58&&f<=62&&p>=18&&p<=22)return"1:3:1";const g=Math.round(d),b=Math.round(f),k=100-g-b;return`${g}:${b}:${k}`}return h.map(d=>Math.round(d)).join(":")}function no(e){if(!e||!ut(e)||!io(e))return null;const t=(e.children||[]).filter(s=>{const l=s.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const o=Ps(t[0]),i=Ps(t[t.length-1]),n=hr(e)||void 0;if(o&&!i){const s=bo(t[0].markdown,t[0].content);if(s)return{imageNode:t[0],imageUrl:s,layout:In,contentNodes:t.slice(1),ratio:n}}if(!o&&i){const s=bo(t[t.length-1].markdown,t[t.length-1].content);if(s)return{imageNode:t[t.length-1],imageUrl:s,layout:$n,contentNodes:t.slice(0,t.length-1),ratio:n}}return null}function sh(e,t){const o=[];function i(n){for(const s of n){const l=no(s);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const u=r.ial[be];if(u!==a){const y={blockId:r.id,layout:a,previousLayout:u,ratio:c};r.ial[be]=a,o.push(y),t&&t(y)}}s.children&&s.children.length>0&&i(s.children)}}return i(e),o}function Si(e){return(e.children||[]).filter(t=>{const o=t.type||"";if(o==="NodeSuperBlockOpenMarker"||o==="NodeSuperBlockLayoutMarker"||o==="NodeSuperBlockCloseMarker"||o==="open-marker"||o==="layout-marker"||o==="close-marker")return!1;const i=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(i)||i==="}}}")})}function qa(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const o=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(o)}function Wo(e,t,o){let i="",n=0;const s=/<div\b([^>]*)>/gi;for(;n<e.length;){s.lastIndex=n;let l,r=!1,a=-1,c=0;for(;(l=s.exec(e))!==null;){const b=l[1].match(/\bclass=["']([^"']*)["']/i);if(b){const k=b[1];if(typeof t=="string"?k.split(/\s+/).includes(t):t.test(k)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){i+=e.slice(n);break}i+=e.slice(n,a);const u=a+c;let h=1,y=-1,d=-1;const f=/<\/?div\b[^>]*>/gi;f.lastIndex=u;let p;for(;(p=f.exec(e))!==null;)if(p[0].startsWith("</")){if(h--,h===0){y=p.index,d=p.index+p[0].length;break}}else h++;if(y!==-1&&d!==-1){const g=e.slice(u,y);i+=o(g),n=d}else i+=e.slice(a,u),n=u}return i}function rh(e){const t=[];let o="",i=0;const n=/<div\b([^>]*)>/gi;for(;i<e.length;){n.lastIndex=i;let s,l=!1,r=-1,a=0;for(;(s=n.exec(e))!==null;){const p=s[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(p)){l=!0,r=s.index,a=s[0].length;break}}if(!l){o+=e.slice(i);break}o+=e.slice(i,r);const c=r+a;let u=1,h=-1,y=-1;const d=/<\/?div\b[^>]*>/gi;d.lastIndex=c;let f;for(;(f=d.exec(e))!==null;)if(f[0].startsWith("</")){if(u--,u===0){h=f.index,y=f.index+f[0].length;break}}else u++;if(h!==-1&&y!==-1){const p=e.slice(r,y),g=`__VUE_DIV_TOKEN_${t.length}__`;t.push(p),o+=g,i=y}else o+=e.slice(r,c),i=c}return{text:o,tokens:t}}function lh(e){const t=[];let o=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});o=o.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});const i=[];o=o.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${i.length}__`;return i.push(r),a});const{text:n,tokens:s}=rh(o);o=n;const l=[];o=o.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),o=o.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),o=o.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),o=o.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),o=o.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),o=o.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),o=o.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),o=o.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),o=o.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),o=o.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(u=>`\`${u[1].trim()}\``).join(" | ")}
`),o=o.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),o=Wo(o,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const u=c[2].trim().toUpperCase(),h=c[3].trim();return`**${u}:**
\`\`\`yaml
${h}
\`\`\``}).join(`

`)+`
`:r}),o=Wo(o,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let u=`
`;return a&&(u+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(u+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),u.trim()?u:r}),o=o.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(u=>`- ${u[1]} ${u[2].trim()}`).join(`
`)+`
`:a}),o=Wo(o,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const u=c[1]||"";let h="-";return u.includes("warn")?h="- ⚠️":u.includes("bad")?h="- ❌":u.includes("ok")&&(h="- ✅"),`${h} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),o=Wo(o,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,u)=>{const y=(c[1]||"").includes("hot")?"⚠️ ":"";return`${u+1}. ${y}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),o=Wo(o,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),o=Wo(o,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),o=Wo(o,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),o=o.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),o=o.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),o=o.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),o=o.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),o=o.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),o=o.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),o=o.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),o=o.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),o=o.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),o=o.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),o=o.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),o=o.replace(/<br\s*\/?>/gi,`
`),o=o.replace(/<hr\s*\/?>/gi,`
---
`),o=o.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),o=o.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),o=o.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),o=o.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((h,y)=>Math.max(h,y.length),0),u="`".repeat(c+1);return`${u} ${a} ${u}`}return`\`${a}\``}),o=o.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),o=o.replace(/\*{4}/g,"** **"),o=o.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),o=o.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),o=o.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),o=o.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,u,h)=>{const y=h.trim();return y.includes("<")||y.includes(`
`)?r:`[${y}](${c})`}),o=o.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),o=o.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const u=c.replace(/<[^>]+>/g,"").trim();return u?`((${a} '${u}'))`:`((${a}))`}),o=o.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),o=o.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),o=o.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),o=o.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)o=o.replace(`__VUE_COMP_TOKEN_${r}__`,()=>l[r]);for(let r=0;r<s.length;r++)o=o.replace(`__VUE_DIV_TOKEN_${r}__`,()=>s[r]);for(let r=0;r<i.length;r++)o=o.replace(`__SCRIPT_TOKEN_${r}__`,()=>i[r]);for(let r=0;r<t.length;r++)o=o.replace(`__CODE_TOKEN_${r}__`,()=>t[r]);return o=o.replace(/\n{3,}/g,`

`).trim(),o}function Ga(e){if(!e||typeof e!="string")return"";const t=[];let o=e.replace(/`([^`]+)`/g,i=>(t.push(i),`%%INLINE_CODE_${t.length-1}%%`));return o=o.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),o=o.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),o=o.replace(/\{:[^}]*\}/g,""),o=o.replace(/%%INLINE_CODE_(\d+)%%/g,(i,n)=>t[parseInt(n,10)]||""),o}function Rs(e){if(!e)return"";const t=e.trim();return t?/^\d+$/.test(t)?`${t}px`:/^(\d+(?:\.\d+)?)%$/.test(t)?`${t.slice(0,-1)}cqh`:/^(\d+(?:\.\d+)?)vh$/.test(t)?`${t.slice(0,-2)}cqh`:t:""}function pr(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let n=t.split(/\r?\n/).map(s=>s.trim().replace(/^>\s*/,"")).join(`
`).trim();return n=n.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),n=n.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),n=n.replace(/^[-*+]\s+/,""),n=n.replace(/^\d+\.\s+/,""),n.trim()}function ah(e){var i;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const o=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return o?o[1].length:e.type==="h"?(i=e.ial)!=null&&i.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function zs(e,t=2){const o=Math.max(2,t);if(!e||e.length===0)return Array.from({length:o},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,u=Array.from({length:o},()=>[]),h=Math.min(o,c.length),y=Math.floor(c.length/h),d=c.length%h;let f=0;for(let p=0;p<h;p++){const g=y+(p<d?1:0);u[p]=c.slice(f,f+g),f+=g}return u}if(e.length===1){const c=e[0],h=(c.slot||"").trim().match(/^col-(\d+)$/i),y=h?parseInt(h[1],10):null,d=(c.rawMarkdown||c.content||"").trim(),f=d.split(/\r?\n/),p=[];for(let k=0;k<f.length;k++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(f[k])&&p.push(k);if(p.length>=o){const k=Array.from({length:o},()=>[]);let w=0;for(let _=0;_<o;_++){const M=o-_,A=p.length-w,I=Math.ceil(A/M),N=p[w],H=w+I<p.length?p[w+I]:f.length,z=f.slice(N,H).join(`
`);k[_]=[{...c,id:_===0?c.id:`${c.id}-col${_+1}`,rawMarkdown:z,content:z}],w+=I}return k}const g=d.match(/<li[\s\S]*?<\/li>/gi);if(g&&g.length>=o){const k=Array.from({length:o},()=>[]);let w=0;for(let _=0;_<o;_++){const M=o-_,A=g.length-w,I=Math.ceil(A/M),N=`<ul>
${g.slice(w,w+I).join(`
`)}
</ul>`;k[_]=[{...c,id:_===0?c.id:`${c.id}-col${_+1}`,rawMarkdown:N,content:N}],w+=I}return k}const b=d.split(/\r?\n\s*\r?\n/).filter(k=>k.trim()!=="");if(b.length>=o){const k=Array.from({length:o},()=>[]);let w=0;for(let _=0;_<o;_++){const M=o-_,A=b.length-w,I=Math.ceil(A/M),N=b.slice(w,w+I).join(`

`);k[_]=[{...c,id:_===0?c.id:`${c.id}-col${_+1}`,rawMarkdown:N,content:N}],w+=I}return k}if(y&&y>=1&&y<=o){const k=Array.from({length:o},()=>[]);return k[y-1]=[c],k}return[[c],...Array.from({length:o-1},()=>[])]}const i=c=>{const u=(c.slot||"").trim();if(!u)return null;if(u==="left")return 1;if(u==="center")return 2;if(u==="right")return o===2?2:o;const h=u.match(/^col-(\d+)$/i);if(h){const y=parseInt(h[1],10);if(y>=1&&y<=o)return y}return null},n=e.map(i);if(n.some(c=>c!==null)){if(n.some(d=>d!==null&&d>=2)){const d=Array.from({length:o},()=>[]);let f=1;for(const g of e){const b=i(g);b!==null&&(f=b),d[f-1].push(g)}if(!e.some(g=>/^col-\d+$/i.test((g.slot||"").trim()))&&d[0].length===0){const g=d.filter(b=>b.length>0);if(g.length===1)return[g[0],...Array.from({length:o-1},()=>[])]}return d}const u=e.filter(d=>i(d)===1),h=e.filter(d=>i(d)===null),y=o-1;if(h.length>=y){const d=Math.floor(h.length/y),f=h.length%y,p=[u];let g=0;for(let b=0;b<y;b++){const k=d+(b<f?1:0);p.push(h.slice(g,g+k)),g+=k}return p}else if(h.length>0){const d=[u];for(let f=0;f<y;f++)d.push(f<h.length?[h[f]]:[]);return d}else return[u,...Array.from({length:y},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const u=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(u)},r=e.map((c,u)=>l(c)?u:-1).filter(c=>c!==-1);if(r.length>=o){const c=Array.from({length:o},()=>[]);for(let u=0;u<o;u++){const h=r[u],y=u+1<o?r[u+1]:e.length;c[u]=e.slice(h,y)}return c}if(e.length>=o){const c=Array.from({length:o},()=>[]);let u=0;for(let h=0;h<o;h++){const y=o-h,d=e.length-u,f=Math.ceil(d/y);c[h]=e.slice(u,u+f),u+=f}return c}if(e.length>1&&e.length<o){const c=Array.from({length:o},()=>[]);for(let u=0;u<e.length;u++)c[u]=[e[u]];return c}const a=Array.from({length:o},()=>[]);return a[0]=e,a}function cl(e,t,o,i){const n=Qf(t),s=[],l=ll(t),r=n.background?Bt(n.background,i):void 0;let a={pageIndex:1,startBlockId:e,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};a.frontmatter.background&&(a.frontmatter.background=Bt(a.frontmatter.background,i)),a.frontmatter.image&&(a.frontmatter.image=Bt(a.frontmatter.image,i));const c=d=>{const f=[];for(let p=d;p<o.length&&!(p>d&&mo(o[p]));p++)f.push(o[p]);return f},u=d=>{let f,p,g;const b=k=>{var I;if(f)return;const w=no(k);if(w){f=w.layout,p=w.imageUrl,g=w.ratio;return}const _=Cr(k),M=k.ial?{...k.ial}:{},A=al(M);if(A.imageLayout==="image-left"||A.imageLayout==="image-right"){const N=bo(_,k.content);if(N){f=A.imageLayout,p=N,g=(I=k.ial)==null?void 0:I[mt];return}}if(k.children&&k.children.length>0){for(const N of k.children)if(b(N),f)return}};for(const k of d)if(b(k),f)break;return{foundLayout:f,foundImage:p,foundRatio:g}},h=(d,f)=>{const{foundLayout:p,foundImage:g,foundRatio:b}=u(f);p&&(d.frontmatter.layout=p,g&&(d.frontmatter.image=Bt(g,i)),b&&!d.frontmatter.layoutRatio&&(d.frontmatter.layoutRatio=b))};h(a,c(0)),s.push(a);let y=[];for(let d=0;d<o.length;d++){const f=o[d];if(mo(f)){y=[];const g=ll(f.ial);if(s.length===1&&a.blocks.length===0){a.startBlockId=f.id,a.allBlockIds||(a.allBlockIds=[]),a.allBlockIds.includes(f.id)||a.allBlockIds.push(f.id),g.frontmatter.layout&&(a.frontmatter.layout=g.frontmatter.layout),Object.assign(a.frontmatter,g.frontmatter),delete a.frontmatter.background,!g.frontmatter.image&&l.frontmatter.image&&(a.frontmatter.image=l.frontmatter.image),r&&(a.frontmatter.background=r),a.frontmatter.background&&(a.frontmatter.background=Bt(a.frontmatter.background,i)),a.frontmatter.image&&(a.frontmatter.image=Bt(a.frontmatter.image,i)),h(a,c(d+1));continue}a={pageIndex:s.length+1,startBlockId:f.id,frontmatter:{layout:g.frontmatter.layout||"default",...g.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[f.id]},r||delete a.frontmatter.background,a.frontmatter.background&&(a.frontmatter.background=Bt(a.frontmatter.background,i)),a.frontmatter.image&&(a.frontmatter.image=Bt(a.frontmatter.image,i)),h(a,c(d+1)),s.push(a);continue}const p=(g,b)=>{var ce,oe,re,Se,Ie,ve,_e;if(a.allBlockIds||(a.allBlockIds=[]),g.id&&!a.allBlockIds.includes(g.id)&&a.allBlockIds.push(g.id),g.children&&g.children.length>0){const P=ie=>{for(const E of ie)E.id&&!a.allBlockIds.includes(E.id)&&a.allBlockIds.push(E.id),E.children&&E.children.length>0&&P(E.children)};P(g.children)}let k=Cr(g),w=g.ial?{...g.ial}:{};const _=k.match(/\{:\s*([^}]+)\s*\}\s*$/);_&&(w={...Dl(_[0]),...w},k=k.slice(0,_.index).trim()),g.type!=="c"&&!k.startsWith("```")&&(k=Ga(k));let M=k.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(M)||M==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(M)&&/\r?\n\}\}\}$/.test(M)&&(k=M.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),M=k.trim());const A=al(w);if(k=_d(k,i),k=xd(k,i==null?void 0:i.refContentMap),g.children&&g.children.length>0){const P=["custom-slides-autoplay","custom-slides-loop","custom-slides-muted","custom-slides-controls"],ie=E=>{for(const F of E){if(F.ial)for(const[v,U]of Object.entries(F.ial))P.includes(v)&&!w[v]&&(w[v]=U);F.children&&F.children.length>0&&ie(F.children)}};ie(g.children)}const I=g.type==="video"||g.type==="NodeVideo"||/<video\b/i.test(k);if(I){const P=w["custom-slides-autoplay"]==="true",ie=w["custom-slides-loop"]==="true",E=w["custom-slides-muted"]==="true"||P,F=w["custom-slides-controls"]==="false";k=k.replace(/<video\b([^>]*)>/gi,(v,U)=>{let R=U;return F?R=R.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(R)||(R+=" controls"),P&&!/autoplay/i.test(R)?R+=" autoplay playsinline":!P&&w["custom-slides-autoplay"]==="false"&&(R=R.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),ie&&!/loop/i.test(R)?R+=" loop":!ie&&w["custom-slides-loop"]==="false"&&(R=R.replace(/\bloop\b/gi,"").trim()),E&&!/muted/i.test(R)?R+=" muted":!E&&w["custom-slides-muted"]==="false"&&(R=R.replace(/\bmuted\b/gi,"").trim()),`<video ${R.trim()}>`})}if(A.isBackground){const P=bo(k,g.content);if(P){a.frontmatter.background=Bt(P,i);return}}const N=no(g);if(N){a.frontmatter.layout=N.layout,a.frontmatter.image=Bt(N.imageUrl,i),!a.frontmatter.layoutRatio&&N.ratio&&(a.frontmatter.layoutRatio=N.ratio);for(const P of N.contentNodes)p(P);return}if(A.imageLayout==="image-left"||A.imageLayout==="image-right"){const P=bo(k,g.content);if(P){a.frontmatter.layout=A.imageLayout,a.frontmatter.image=Bt(P,i),!a.frontmatter.layoutRatio&&((ce=g.ial)!=null&&ce[mt])&&(a.frontmatter.layoutRatio=g.ial[mt]);return}}if(ut(g)&&g.children&&g.children.length>0){for(const P of g.children)p(P);return}const H=!!(A.slot||b!=null&&b.defaultSlot||a.frontmatter.layout==="clover"||di(a.frontmatter.layout)||a.frontmatter.layout==="two-cols"),z=!!(g.children&&g.children.some(P=>{var ie,E;return((ie=P.ial)==null?void 0:ie[Ae])||((E=P.ial)==null?void 0:E[Oe])||P.children&&P.children.length>=2||P.children&&P.children.some(F=>{var v,U,R,S,C,L;return((v=F.ial)==null?void 0:v[Oe])||((U=F.ial)==null?void 0:U[Ae])||((R=F.ial)==null?void 0:R[Ye])||((S=F.ial)==null?void 0:S[be])||((C=F.ial)==null?void 0:C["custom-slides-role"])||((L=F.ial)==null?void 0:L["custom-slides-layout"])})}));if((g.type==="l"||g.type==="NodeList"||g.type==="list")&&g.children&&g.children.length>0&&(z||A.slot||A.clicks||H)){const P=/^\s*\d+\.\s+/m.test(g.markdown||"")||g.subType==="o"||g.subtype==="o";for(let ie=0;ie<g.children.length;ie++){const E=g.children[ie];A.slot&&(!E.ial||!E.ial[Ae])&&(E.ial||(E.ial={}),E.ial[Ae]=A.slot),p(E,{...b,parentClicks:A.clicks||(b==null?void 0:b.parentClicks),defaultSlot:A.slot||(b==null?void 0:b.defaultSlot),isParentListUnpacked:!0,isListItem:!0,listContext:{isOrdered:P,itemIndex:ie+1}})}return}const j=!!(b!=null&&b.isParentListUnpacked),B=!!(g.children&&g.children.length>=2)||!!A.clicks||!!((oe=g.children)!=null&&oe.some(P=>{var ie;return(ie=P.ial)==null?void 0:ie[Oe]}))||j||!g.markdown&&!!(g.children&&g.children.length>0);if(Ro(g)&&g.children&&g.children.length>0&&(H||j||A.clicks||g.children.some(P=>{var ie;return(ie=P.ial)==null?void 0:ie[Oe]}))&&B){const P=!!(g.children&&g.children.length>=2),ie=g.children.find(C=>!!(C.markdown||C.content||"").trim())||g.children[0],E=((re=ie==null?void 0:ie.ial)==null?void 0:re[Oe])||((Se=ie==null?void 0:ie.ial)==null?void 0:Se["custom-slides-click"]),F=!!(!A.clicks&&P&&E),v=A.clicks||(F?E:void 0)||(b==null?void 0:b.parentClicks),U=g.id||(b==null?void 0:b.parentContainerId),R=A.slot||(b==null?void 0:b.defaultSlot);let S=!0;for(const C of g.children){R&&(!C.ial||!C.ial[Ae])&&(C.ial||(C.ial={}),C.ial[Ae]=R);const L=!!(C.markdown||C.content||"").trim(),G=S&&L;if(G){if(!(a.frontmatter.layout==="image-right"||a.frontmatter.layout==="image-left")&&!!(a.frontmatter.layout==="clover"||di(a.frontmatter.layout)||a.frontmatter.layout==="two-cols")&&!!(b!=null&&b.defaultSlot||A.slot||(Ie=g.ial)!=null&&Ie[Ae]))C.markdown&&(C.markdown=zi(C.markdown)),C.content&&(C.content=zi(C.content));else{const ne=!!((ve=b==null?void 0:b.listContext)!=null&&ve.isOrdered),me=((_e=b==null?void 0:b.listContext)==null?void 0:_e.itemIndex)||1,Ce=ne?`${me}. `:"- ",we=Le=>{if(!Le)return Ce.trim();const He=Le.trim();return/^[-*+]\s+/.test(He)||/^\d+\.\s+/.test(He)?Le:`${Ce}${Le}`};C.markdown&&(C.markdown=we(C.markdown)),C.content&&(C.content=we(C.content))}S=!1}let q=C;G&&v&&P?(q={...C,ial:{...C.ial||{}}},delete q.ial[Oe],delete q.ial["custom-slides-click"]):!P&&v&&(q={...C,ial:{...C.ial||{},[Oe]:v}}),p(q,{...b,parentClicks:v,parentContainerId:U,defaultSlot:R,isListItem:!0})}return}if(A.isNote){const P=pr(k);P&&(a.notes?a.notes+=`

`+P:a.notes=P),a.noteBlocks||(a.noteBlocks=[]),a.noteBlocks.push({id:g.id,type:g.type,content:P||g.content||"",rawMarkdown:k,isNote:!0,attributes:g.ial});return}M=k.trim();const D=(g.content||"").trim();if(M==="::right::"||D==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(M)||M.startsWith("::right::")){a.blocks.push({id:g.id,type:g.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:g.ial});return}const V=ah(g);let W=A.slot,$=A.clicks,T=A.motion,O={...g.ial||{}};if(V!==null){for(;y.length>0&&y[y.length-1].level>=V;)y.pop();const P=y.length>0?y[y.length-1]:void 0;!W&&(P!=null&&P.slot)&&(W=P.slot),!$&&(P!=null&&P.clicks)&&!(b!=null&&b.parentContainerId)&&($=P.clicks),!T&&(P!=null&&P.motion)&&(T=P.motion);const ie={...(P==null?void 0:P.customAttrs)||{}};if(g.ial)for(const[E,F]of Object.entries(g.ial))E.startsWith("custom-slides-")&&!E.startsWith("custom-slides-slide")&&(ie[E]=F);b!=null&&b.parentContainerId||y.push({level:V,slot:W,clicks:$,motion:T,customAttrs:ie})}else{const P=y.length>0?y[y.length-1]:void 0;P&&(!W&&P.slot&&P.slot!=="header"&&(W=P.slot),!$&&P.clicks&&!(b!=null&&b.parentContainerId)&&($=P.clicks),!T&&P.motion&&(T=P.motion),P.customAttrs&&(O={...P.customAttrs,...O}))}!W&&a.blocks.some(P=>P.slot==="slot-divider-right")&&(W="right"),!W&&(b!=null&&b.defaultSlot)&&(W=b.defaultSlot),W&&(O[Ae]=W),$&&!O[Oe]&&(O[Oe]=$),T&&!O[At]&&(O[At]=JSON.stringify(T)),(I||w["custom-slides-autoplay"]||w["custom-slides-muted"])&&(w["custom-slides-autoplay"]&&(O["custom-slides-autoplay"]=w["custom-slides-autoplay"],w["custom-slides-autoplay"]==="true"&&!w["custom-slides-muted"]&&(O["custom-slides-muted"]="true")),w["custom-slides-loop"]&&(O["custom-slides-loop"]=w["custom-slides-loop"]),w["custom-slides-muted"]&&(O["custom-slides-muted"]=w["custom-slides-muted"]),w["custom-slides-controls"]&&(O["custom-slides-controls"]=w["custom-slides-controls"]));const te=A.maxHeight?Rs(A.maxHeight):void 0,K=!!(b!=null&&b.isListItem||Ro(g)),Z={id:g.id,type:g.type,content:g.content||"",rawMarkdown:k,clicks:$,parentClicks:b==null?void 0:b.parentClicks,parentContainerId:b==null?void 0:b.parentContainerId,motion:T,shikiLines:A.shikiLines,maxHeight:te,slot:W,attributes:O,attrs:O,rawNode:g,isListItem:K};a.blocks.push(Z)};p(f)}for(let d=0;d<s.length;d++){const f=s[d],p=f.blocks.filter(k=>k.slot!=="slot-divider-right"),g=k=>{const w=k.filter(I=>!!(I.rawMarkdown||I.content||"").trim());if(w.length===0)return;const _=w[0],M=(_.rawMarkdown||_.content||"").trim();(Ro(_)||/^(?:[-*+]|\d+\.)\s+/.test(M))&&(_.rawMarkdown=zi(_.rawMarkdown||_.content||""),_.content=_.rawMarkdown)},b=f.frontmatter.layout||"default";if(b==="clover"||di(b)){let k=[];const w=p.filter(N=>N.slot==="header");if(w.length>0)k=w;else if(p.length>0){const N=p.find(H=>H.type==="h"&&(!H.slot||H.slot==="default"));N&&(k=[N])}const _=p.filter(N=>!k.includes(N));let M=2;if(b==="clover")M=4;else if(b==="three-cols-header")M=3;else if(b==="two-cols-header")M=2;else{let N=0;for(const H of _){const z=(H.slot||"").match(/^col-(\d+)$/i);z&&(N=Math.max(N,parseInt(z[1],10)))}if(N>=2)M=N;else if(f.frontmatter.layoutRatio){const H=f.frontmatter.layoutRatio.trim();if(H.includes(":")){const z=H.split(":").map(j=>parseFloat(j.trim())).filter(j=>!isNaN(j)&&j>0);z.length>=2&&(M=z.length)}else{const z=H.split(/\s+/).filter(Boolean);z.length>=2&&(M=z.length)}}else _.length===1&&_[0].children&&_[0].children.length>=2&&(M=Math.min(6,_[0].children.length))}const A=zs(_,M);A.forEach((N,H)=>{const z=`col-${H+1}`;for(const j of N)(!j.slot||j.slot==="default")&&(j.slot=z);g(N)});const I=A.flat();if(_.length===1&&I.length>1){const N=f.blocks.findIndex(H=>H.id===_[0].id);N!==-1&&f.blocks.splice(N,1,...I)}}else if(b==="two-cols"){const k=p.filter(_=>_.slot==="right"),w=p.filter(_=>!_.slot||_.slot==="default");if(k.length===0&&w.length>=2){const[,_]=zs(w,2);for(const M of _)M.slot="right"}g(p.filter(_=>_.slot!=="right")),g(p.filter(_=>_.slot==="right"))}f.rawMarkdown=f.blocks.filter(k=>k.slot!=="slot-divider-right").map(k=>k.rawMarkdown||k.content||"").filter(Boolean).join(`

`).trim()}return{docId:e,config:n,slides:s}}const dl=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function ch(e){var n,s,l,r,a,c,u,h,y,d,f,p;if(!e||typeof e!="object")return"";const t=[],o=[];if(Array.isArray(e.styles))for(const g of e.styles){if(!g||!g.id)continue;const b=`--b3-inline-style-${g.id}`;(n=g.light)!=null&&n.color&&t.push(`  ${b}-color: ${g.light.color};`),(s=g.light)!=null&&s.backgroundColor&&t.push(`  ${b}-background-color: ${g.light.backgroundColor};`),(l=g.dark)!=null&&l.color&&o.push(`  ${b}-color: ${g.dark.color};`),(r=g.dark)!=null&&r.backgroundColor&&o.push(`  ${b}-background-color: ${g.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const g of e.builtin.colors){if(!g||typeof g.index!="number")continue;const b=g.index;(a=g.light)!=null&&a.color&&t.push(`  --b3-font-color${b}: ${g.light.color};`),(c=g.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${b}: ${g.light.backgroundColor};`),(u=g.dark)!=null&&u.color&&o.push(`  --b3-font-color${b}: ${g.dark.color};`),(h=g.dark)!=null&&h.backgroundColor&&o.push(`  --b3-font-background${b}: ${g.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const g of e.builtin.styles){if(!g||!g.id)continue;const b=g.id;(y=g.light)!=null&&y.color&&t.push(`  --b3-card-${b}-color: ${g.light.color};`),(d=g.light)!=null&&d.backgroundColor&&t.push(`  --b3-card-${b}-background: ${g.light.backgroundColor};`),(f=g.dark)!=null&&f.color&&o.push(`  --b3-card-${b}-color: ${g.dark.color};`),(p=g.dark)!=null&&p.backgroundColor&&o.push(`  --b3-card-${b}-background: ${g.dark.backgroundColor};`)}if(t.length===0&&o.length===0)return"";const i=[];return t.length>0&&i.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),o.length>0&&i.push(`html.dark, [data-theme="dark"], .dark {
${o.join(`
`)}
}`),i.join(`

`)}function Fi(e){const t=ch(e);return t?`${dl}

/* Custom Workspace Inline Styles */
${t}`:dl}const us=Dl;function dh(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function uh(e,t){const o=new Map,i=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:o,rebuildRoots:i};const n=new Map;for(const s of t)s!=null&&s.id&&n.set(s.id,s);for(const s of e||[]){if(!(s!=null&&s.id))continue;const l=n.get(s.id);if(!l)continue;const r=s.content??"",a=s.markdown??"";(l.content??"")===r&&(l.markdown??"")===a||(dh(l)?i.push(s.id):o.set(s.id,{content:r,markdown:a}))}return{usable:!0,reason:"",leafPatch:o,rebuildRoots:i}}function fh(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function Hs(e){return ut(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function hh(e,t,o,i=8,n){const s=new Map;for(const y of t)y!=null&&y.id&&s.set(y.id,y);const l=y=>({id:y.id,parent_id:y.parent_id,root_id:y.root_id||e,type:y.type,subType:y.subtype??y.subType??"",content:y.content||"",markdown:y.markdown||"",ial:o(y.id,y.ial),children:[]}),r=y=>{let d=y.parent_id,f=0;for(;d&&d!==e&&f++<16;){const p=s.get(d);if(!p||!fh(p))return d;d=p.parent_id}return d||e},a=new Map;for(const y of t){if(!(y!=null&&y.id)||y.id===e||n&&n.size>0&&!n.has(y.id))continue;const d=r(y),f=a.get(d);f?f.push(y):a.set(d,[y])}if(n&&n.size>0)for(const y of a.values())y.sort((d,f)=>(n.get(d.id)??Number.MAX_SAFE_INTEGER)-(n.get(f.id)??Number.MAX_SAFE_INTEGER));const c=new Map,u=(y,d)=>{const f=l(y);if(c.set(f.id,f),d>=i||!Hs(f))return f;const p=a.get(f.id);return p&&p.length>0&&(f.children=p.map(g=>u(g,d+1))),f};return{topLevel:(a.get(e)||[]).map(y=>u(y,0)),byId:c}}const ph={getBlockAttrs:qs,getChildBlocks:ki,getDocBlocksOrders:vd,setBlockAttrs:ze,sql:gi,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:kd};class mh{constructor(t){$e(this,"deps");$e(this,"attrOverrides",new Map);$e(this,"trackedListSuperBlocks",new Map);$e(this,"fallbackWarnedDocId","");this.deps={...ph,...t||{}}}setBlockAttrOverride(t,o){if(!t||!o)return;const n={...this.attrOverrides.get(t)||{}};for(const[s,l]of Object.entries(o))l===""||l===null||l===void 0?delete n[s]:n[s]=String(l);Object.keys(n).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,n)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,o){if(!t)return;if(!o){this.attrOverrides.delete(t);return}const i=this.attrOverrides.get(t);i&&(delete i[o],Object.keys(i).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const o=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},i=this.attrOverrides.get(t);i&&Object.assign(o,i);const n=await this.deps.getChildBlocks(t).catch(()=>[])||[],s=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],l=new Map;for(let W=0;W<s.length;W++)s[W]&&l.set(s[W],W);const r=l.size>0,a=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[],u=uh(n,c),h=new Map;if(Array.isArray(c))for(const W of c)W.id&&W.ial&&h.set(W.id,us(W.ial));const y=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,d=await this.deps.sql(y).catch(()=>[])||[];if(Array.isArray(d)){for(const W of d)if(W.block_id&&W.name){let $=h.get(W.block_id);$||($={},h.set(W.block_id,$)),$[W.name]=W.value||""}}const f=(W,$)=>{const T={...h.get(W)||($?us($):{})},O=this.attrOverrides.get(W);return O&&Object.assign(T,O),T},p=Array.isArray(c)&&c.length>0?hh(t,c,f,8,l):null,g=n.map(W=>W.id).filter(Boolean),b=W=>({id:W.id,parent_id:W.parent_id,root_id:W.root_id||t,type:W.type,subType:W.subType,content:W.content||"",markdown:W.markdown||"",ial:f(W.id,W.ial),children:W.children}),k=async(W,$=0)=>{if(!W||$>8||!Hs(W))return;const T=await this.deps.getChildBlocks(W.id).catch(()=>[])||[];if(!(!Array.isArray(T)||T.length===0)){W.children=T.filter(O=>O==null?void 0:O.id).map(O=>({id:O.id,parent_id:W.id,root_id:t,type:O.type,subType:O.subType,content:O.content||"",markdown:O.markdown||"",ial:f(O.id,O.ial),children:[]}));for(const O of W.children)await k(O,$+1)}},w=new Map;for(const W of c)W!=null&&W.id&&w.set(W.id,W);const _=g.every(W=>{const $=w.get(W);return!$||!!$.type});let M=[],A=!1;if(p&&u.usable&&r&&_){this.fallbackWarnedDocId="";for(const[$,T]of u.leafPatch){const O=p.byId.get($);O&&(O.content=T.content,O.markdown=T.markdown)}const W=new Map;for(const $ of n)$!=null&&$.id&&W.set($.id,$);for(const $ of u.rebuildRoots){const T=p.byId.get($),O=W.get($);T&&O&&(T.content=O.content||"",T.markdown=O.markdown||""),await k(T)}for(const $ of n){if(!($!=null&&$.id)||p.byId.has($.id))continue;const T=b($);await k(T),p.byId.set(T.id,T),p.topLevel.push(T)}M=p.topLevel.filter($=>l.has($.id)).sort(($,T)=>(l.get($.id)??0)-(l.get(T.id)??0))}else g.length>0?(A=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${g.length} 索引行=${c.length} 文档序=${s.length} 原因=${u.reason||"缺少实时文档序"}`)),M=n.map(W=>b(W))):p&&(M=p.topLevel);const I=async(W,$=0)=>{if(!(!W||W.length===0||$>8))for(const T of W){if(Hs(T)&&(!T.children||T.children.length===0)){let te=await this.deps.getChildBlocks(T.id).catch(()=>[]);if(!te||te.length===0){const K=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${T.id}' ORDER BY sort ASC, created ASC`;te=await this.deps.sql(K).catch(()=>[])||[]}if(Array.isArray(te)&&te.length>0){const K=new Set(M.map(ce=>ce.id)),Z=te.filter(ce=>ce.id!==T.id&&!K.has(ce.id));Z.length>0&&(T.children=Z.map(ce=>{const oe=h.get(ce.id)||(ce.ial?us(ce.ial):{}),re=this.attrOverrides.get(ce.id);return re&&Object.assign(oe,re),{id:ce.id,parent_id:ce.parent_id||T.id,root_id:ce.root_id||t,type:ce.type,subType:ce.subType,content:ce.content||"",markdown:ce.markdown||"",ial:oe}}))}}T.children&&T.children.length>0&&await I(T.children,$+1)}};A&&await I(M);const N=W=>{var $,T;for(const O of W)if(O.children&&O.children.length>0){N(O.children);for(const te of O.children)if(te.ial)for(const[K,Z]of Object.entries(te.ial))K.startsWith("custom-slides-")&&!(($=O.ial)!=null&&$[K])&&(O.ial||(O.ial={}),O.ial[K]=Z);if(O.ial){for(const[te,K]of Object.entries(O.ial))if(te.startsWith("custom-slides-"))for(const Z of O.children)(Z.type==="video"||Z.type==="NodeVideo"||/<video\b/i.test(Z.markdown||Z.content||""))&&!((T=Z.ial)!=null&&T[te])&&(Z.ial||(Z.ial={}),Z.ial[te]=K)}}};N(M),sh(M,W=>{const $={[be]:W.layout};this.setBlockAttrOverride(W.blockId,$),(this.deps.setBlockAttrs||ze)(W.blockId,$).catch(O=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",O)})});const H=this.trackedListSuperBlocks.get(t)||[],z=nh(t,M,{tracked:H,onTagChange:W=>{this.setBlockAttrOverride(W.blockId,W.attrs),W.blockId===t&&Object.assign(o,W.attrs);const $=O=>{for(const te of O)te.id===W.blockId&&(te.ial||(te.ial={}),Object.assign(te.ial,W.attrs)),te.children&&te.children.length>0&&$(te.children)};$(M),(this.deps.setBlockAttrs||ze)(W.blockId,W.attrs).catch(O=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",O)})}});this.trackedListSuperBlocks.set(t,z.newTracked);const j=new Set,B=W=>{for(const $ of W){const T=$.markdown||$.content||"";if(T.includes("((")){const O=wd(T);for(const te of O)j.add(te.blockId)}$.children&&$.children.length>0&&B($.children)}};B(M);const D={};if(j.size>0){const W=Array.from(j).map(T=>`'${T}'`).join(","),$=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${W})`).catch(()=>[])||[];if(Array.isArray($))for(const T of $)T.id&&(D[T.id]=T.markdown||T.content||"")}const x=this.deps.getBaseUrl?this.deps.getBaseUrl():"",V=cl(t,o,M,{baseUrl:x,refContentMap:D});try{const W=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;V.customThemeCss=Fi(W)}catch{V.customThemeCss=Fi(null)}return V}catch(o){console.error("[DocumentCompilerService] Failed to compile document:",o);const i=cl(t,{},[],{});return i.customThemeCss=Fi(null),i}}}const Ee=new mh,gh={presenterMode:!0,exportHtml:!1,exportPdf:!1,exportImage:!1,import:!1,aiScript:!0};function Bo(e){return gh[e]===!1}function Dt(e){return!Bo(e)}const ul=["white","snow","ivory","ghostwhite","floralwhite","aliceblue","whitesmoke","seashell","beige","oldlace","linen","antiquewhite","lightyellow","lightcyan","papayawhip","blanchedalmond","cornsilk","lavender","lavenderblush","lemonchiffon","honeydew","mintcream","azure","mistyrose","wheat","lightgoldenrodyellow","palegoldenrod","gainsboro","lightgrey","lightgray","silver","pink","lightpink","peachpuff","navajowhite","moccasin","bisque","khaki","palegreen","lightgreen","lightblue","powderblue","paleturquoise","lightsteelblue","thistle","yellow","cyan","aqua"],fl=["black","transparent","navy","darkblue","midnightblue","darkslategray","darkslategrey","maroon","darkred","darkgreen","indigo","darkslateblue","dimgray","dimgrey","purple","brown","olive","teal","blue","darkviolet","darkmagenta","darkcyan","darkolivegreen","saddlebrown","sienna","firebrick","crimson","mediumblue","rebeccapurple"];function mr(e,t,o){return .299*e+.587*t+.114*o}function hl(e){let t=e.startsWith("#")?e.slice(1):e;if((t.length===3||t.length===4)&&(t=t.slice(0,3).split("").map(o=>o+o).join("")),t.length>=6){const o=parseInt(t.substring(0,2),16),i=parseInt(t.substring(2,4),16),n=parseInt(t.substring(4,6),16);if(!isNaN(o)&&!isNaN(i)&&!isNaN(n))return mr(o,i,n)}return null}function pl(e){const t=e.match(/rgba?\s*\(\s*(\d+(?:\.\d+)?)\s*[,\s]\s*(\d+(?:\.\d+)?)\s*[,\s]\s*(\d+(?:\.\d+)?)(?:\s*[,/]\s*([0-9.]+%?))?/i);if(!t)return null;const o=Number(t[1]),i=Number(t[2]),n=Number(t[3]);if(isNaN(o)||isNaN(i)||isNaN(n))return null;if(t[4]!==void 0){const s=t[4].endsWith("%")?parseFloat(t[4])/100:parseFloat(t[4]);if(!isNaN(s)&&s<=.05)return null}return mr(o,i,n)}function ml(e){const t=e.match(/hsla?\s*\(\s*([0-9.]+)(?:deg)?\s*[,\s]\s*([0-9.]+)%\s*[,\s]\s*([0-9.]+)%(?:\s*[,/]\s*([0-9.]+%?))?/i);if(!t)return null;if(t[4]!==void 0){const a=t[4].endsWith("%")?parseFloat(t[4])/100:parseFloat(t[4]);if(!isNaN(a)&&a<=.05)return null}const o=(Number(t[1])%360+360)%360/360,i=Math.max(0,Math.min(1,Number(t[2])/100)),n=Math.max(0,Math.min(1,Number(t[3])/100));let s,l,r;if(i===0)s=l=r=n*255;else{const a=n<.5?n*(1+i):n+i-n*i,c=2*n-a,u=h=>{let y=h;return y<0&&(y+=1),y>1&&(y-=1),y<1/6?c+(a-c)*6*y:y<1/2?a:y<2/3?c+(a-c)*(2/3-y)*6:c};s=u(o+1/3)*255,l=u(o)*255,r=u(o-1/3)*255}return mr(s,l,r)}function Ka(e){if(!e||typeof e!="string")return null;const t=e.trim().toLowerCase();if(!t||/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/|url\s*\()/i.test(t))return null;if(ul.includes(t))return!0;if(fl.includes(t))return!1;if(t.startsWith("#")){const o=hl(t);return o===null?null:o>140}if(/^rgba?\s*\(/i.test(t)){const o=pl(t);return o===null?null:o>140}if(/^hsla?\s*\(/i.test(t)){const o=ml(t);return o===null?null:o>140}if(/(?:linear|radial|conic)-gradient\s*\(/i.test(t)){const o=[],i=t.match(/#(?:[0-9a-f]{8}|[0-9a-f]{6}|[0-9a-f]{4}|[0-9a-f]{3})\b/gi);if(i)for(const a of i){const c=hl(a);c!==null&&o.push(c)}const n=t.match(/rgba?\s*\([^)]+\)/gi);if(n)for(const a of n){const c=pl(a);c!==null&&o.push(c)}const s=t.match(/hsla?\s*\([^)]+\)/gi);if(s)for(const a of s){const c=ml(a);c!==null&&o.push(c)}const r=t.replace(/#[0-9a-f]+|rgba?\([^)]+\)|hsla?\([^)]+\)/gi," ").match(/\b[a-z]+\b/gi);if(r)for(const a of r)a!=="transparent"&&(ul.includes(a)?o.push(240):fl.includes(a)&&o.push(20));if(o.length>0)return o.reduce((c,u)=>c+u,0)/o.length>140;if(/\btransparent\b/.test(t))return!1}return null}function zo(){var e,t,o,i,n,s,l,r,a,c,u,h,y;if(typeof window<"u"){const d=(o=(t=(e=window.siyuan)==null?void 0:e.config)==null?void 0:t.appearance)==null?void 0:o.mode;if(d===0)return"light";if(d===1)return"dark"}if(typeof document<"u"){const d=(i=document.documentElement)==null?void 0:i.getAttribute("data-theme-mode");if(d==="light"||d==="dark")return d;const f=(n=document.body)==null?void 0:n.getAttribute("data-theme-mode");if(f==="light"||f==="dark")return f;if((l=(s=document.documentElement)==null?void 0:s.classList)!=null&&l.contains("theme--dark")||(a=(r=document.body)==null?void 0:r.classList)!=null&&a.contains("theme--dark"))return"dark";if((u=(c=document.documentElement)==null?void 0:c.classList)!=null&&u.contains("theme--light")||(y=(h=document.body)==null?void 0:h.classList)!=null&&y.contains("theme--light"))return"light"}if(typeof window<"u"&&typeof window.matchMedia=="function"){if(window.matchMedia("(prefers-color-scheme: light)").matches)return"light";if(window.matchMedia("(prefers-color-scheme: dark)").matches)return"dark"}return"light"}function gr(e,t){return e==="light"?"light":e==="dark"?"dark":t==="light"||t==="dark"?t:zo()}function Ya(e){if(typeof MutationObserver>"u"||typeof document>"u")return()=>{};let t=zo();const o=()=>{const n=zo();n!==t&&(t=n,e(n))},i=new MutationObserver(o);return document.documentElement&&i.observe(document.documentElement,{attributes:!0,attributeFilter:["data-theme-mode","class"]}),document.body&&i.observe(document.body,{attributes:!0,attributeFilter:["data-theme-mode","class"]}),()=>i.disconnect()}class Jn{constructor(){$e(this,"iframe",null);$e(this,"isReady",!1);$e(this,"pendingMessages",[]);$e(this,"slideChangedHandlers",[]);$e(this,"blockClickedHandlers",[]);$e(this,"openInEditorHandlers",[]);$e(this,"clientReadyHandlers",[]);$e(this,"openPeekDrawerHandlers",[]);$e(this,"toggleFullscreenHandlers",[]);$e(this,"openPresenterHandlers",[]);$e(this,"captureProgressHandlers",[]);$e(this,"capturePageDoneHandlers",[]);$e(this,"captureCompleteHandlers",[]);$e(this,"captureErrorHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}resetReady(){this.isReady=!1}postMessage(t,o){var n;const i={source:"siyuan-slides-host",action:t,payload:o};if(!((n=this.iframe)!=null&&n.contentWindow)||!this.isReady){if(t==="UPDATE_SLIDES"||t==="NAVIGATE_PAGE"){const s=this.pendingMessages.findIndex(l=>l.action===t);s!==-1?this.pendingMessages[s]=i:this.pendingMessages.push(i)}else this.pendingMessages.length>=50&&this.pendingMessages.shift(),this.pendingMessages.push(i);return}try{this.iframe.contentWindow.postMessage(i,"*")}catch(s){console.warn("[WebSandboxBridge] postMessage error:",s)}}updateSlides(t,o,i){const n=o?{...o,hostThemeMode:o.hostThemeMode||zo()}:void 0;this.postMessage("UPDATE_SLIDES",{slides:t,config:n,customThemeCss:i})}navigatePage(t,o){const i={pageIndex:t};typeof o=="number"&&(i.step=o),this.postMessage("NAVIGATE_PAGE",i)}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}startImageExport(t){this.postMessage("START_IMAGE_EXPORT",{captureOptions:t})}cancelImageExport(){this.postMessage("CANCEL_IMAGE_EXPORT",{})}onCaptureProgress(t){return this.captureProgressHandlers.push(t),()=>{this.captureProgressHandlers=this.captureProgressHandlers.filter(o=>o!==t)}}onCapturePageDone(t){return this.capturePageDoneHandlers.push(t),()=>{this.capturePageDoneHandlers=this.capturePageDoneHandlers.filter(o=>o!==t)}}onCaptureComplete(t){return this.captureCompleteHandlers.push(t),()=>{this.captureCompleteHandlers=this.captureCompleteHandlers.filter(o=>o!==t)}}onCaptureError(t){return this.captureErrorHandlers.push(t),()=>{this.captureErrorHandlers=this.captureErrorHandlers.filter(o=>o!==t)}}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(o=>o!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(o=>o!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(o=>o!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(o=>o!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(o=>o!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(o=>o!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(o=>o!==t)}}handleWindowMessage(t){var i,n;const o=t.data;if(!(!o||o.source!=="siyuan-slides-client")&&!((i=this.iframe)!=null&&i.contentWindow&&t.source&&t.source!==this.iframe.contentWindow))switch(o.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const s=this.pendingMessages.shift();s&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(s,"*")}for(const s of this.clientReadyHandlers)s();break;case"SLIDE_CHANGED":if(o.payload.currentPage!==void 0)for(const s of this.slideChangedHandlers)o.payload.currentStep!==void 0||o.payload.maxStep!==void 0?s(o.payload.currentPage,o.payload.totalPages||1,o.payload.currentBlockId||"",o.payload.currentStep,o.payload.maxStep):s(o.payload.currentPage,o.payload.totalPages||1,o.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(o.payload.clickedBlockId)for(const s of this.blockClickedHandlers)s(o.payload.clickedBlockId,o.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(o.payload.blockId||o.payload.clickedBlockId){const s=o.payload.blockId||o.payload.clickedBlockId||"";for(const l of this.openInEditorHandlers)l(s,o.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(o.payload.peekType){const s=o.payload.blockId||o.payload.url||"",l={peekType:o.payload.peekType,target:s,title:o.payload.title};for(const r of this.openPeekDrawerHandlers)r(l)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const s of this.toggleFullscreenHandlers)s();break;case"OPEN_PRESENTER":for(const s of this.openPresenterHandlers)s();break;case"CAPTURE_PROGRESS":if(o.payload.captureProgress)for(const s of this.captureProgressHandlers)s(o.payload.captureProgress);break;case"CAPTURE_PAGE_DONE":if(o.payload.captureResult)for(const s of this.capturePageDoneHandlers)s(o.payload.captureResult);break;case"CAPTURE_COMPLETE":for(const s of this.captureCompleteHandlers)s({total:o.payload.totalPages||0});break;case"CAPTURE_ERROR":for(const s of this.captureErrorHandlers)s(o.payload.captureError||"未知沙箱截图异常");break}}}const yh={class:"slides-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},bh={key:0},vh={key:1},kh={key:2},wh={key:3},xh={key:4},Sh={key:5},_h={key:6},Ch={key:7},Ih={key:8},$h={key:9},Ah={key:10},Th={key:11},Mh={key:12},Bh={key:13},Eh={key:14},Dh={key:15},Lh={key:16},Oh={key:17},Nh={key:18},Ph={key:19},Rh={key:20},zh={key:21},Hh={key:22},Fh={key:23},jh={key:24},Wh={key:25},Uh={key:26},Vh={key:27},qh={key:28},Gh={key:29},Kh={key:30},Yh={key:31},Zh={key:32},Jh={key:33},Xh={key:34},Qh={key:35},ep={key:36},tp={key:37},op={key:38},ip={key:39},np={key:40},sp={key:41},rp={key:42},lp={key:43},ap={key:44},cp={key:45},dp={key:46},up={key:47},fp={key:48},hp={key:49},pp={key:50},mp={key:51},gp={key:52},yp={key:53},bp={key:54},vp={key:55},kp={key:56},wp={key:57},xp={key:58},Sp={key:59},_p={key:60},Cp={key:61},Ip={key:62},$p={key:63},Ap={key:64},Tp={key:65},Mp={key:66},Bp={key:67},Ep={key:68},Dp={key:69},Lp={key:70},Op={key:71},Np={key:72},Pp={key:73},Rp=Pt({__name:"SlidesIcon",props:{name:{}},setup(e){return(t,o)=>(J(),ee("svg",yh,[e.name==="fullscreen"||e.name==="maximize"?(J(),ee("g",bh,[...o[0]||(o[0]=[m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("polyline",{points:"9 21 3 21 3 15"},null,-1),m("polyline",{points:"21 15 21 21 15 21"},null,-1),m("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(J(),ee("g",vh,[...o[1]||(o[1]=[m("polyline",{points:"4 14 10 14 10 20"},null,-1),m("polyline",{points:"20 10 14 10 14 4"},null,-1),m("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),m("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(J(),ee("g",kh,[...o[2]||(o[2]=[m("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),m("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(J(),ee("g",wh,[...o[3]||(o[3]=[m("path",{d:"M12 20h9"},null,-1),m("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(J(),ee("g",xh,[...o[4]||(o[4]=[m("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),m("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(J(),ee("g",Sh,[...o[5]||(o[5]=[m("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(J(),ee("g",_h,[...o[6]||(o[6]=[m("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),m("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(J(),ee("g",Ch,[...o[7]||(o[7]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(J(),ee("g",Ih,[...o[8]||(o[8]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(J(),ee("g",$h,[...o[9]||(o[9]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(J(),ee("g",Ah,[...o[10]||(o[10]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),m("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(J(),ee("g",Th,[...o[11]||(o[11]=[m("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),m("polyline",{points:"7 9 12 14 17 9"},null,-1),m("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(J(),ee("g",Mh,[...o[12]||(o[12]=[m("path",{d:"M2 3h20"},null,-1),m("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),m("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(J(),ee("g",Bh,[...o[13]||(o[13]=[m("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),m("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(J(),ee("g",Eh,[...o[14]||(o[14]=[m("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(J(),ee("g",Dh,[...o[15]||(o[15]=[m("path",{d:"M5 12h14"},null,-1),m("path",{d:"m12 5 7 7-7 7"},null,-1),m("path",{d:"M5 6h4"},null,-1),m("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(J(),ee("g",Lh,[...o[16]||(o[16]=[m("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),m("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="layout-grid"||e.name==="grid-2x2"||e.name==="grid"||e.name==="overview"?(J(),ee("g",Oh,[...o[17]||(o[17]=[m("rect",{x:"3",y:"3",width:"7",height:"7",rx:"1"},null,-1),m("rect",{x:"14",y:"3",width:"7",height:"7",rx:"1"},null,-1),m("rect",{x:"14",y:"14",width:"7",height:"7",rx:"1"},null,-1),m("rect",{x:"3",y:"14",width:"7",height:"7",rx:"1"},null,-1)])])):e.name==="code"?(J(),ee("g",Nh,[...o[18]||(o[18]=[m("polyline",{points:"16 18 22 12 16 6"},null,-1),m("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="list"?(J(),ee("g",Ph,[...o[19]||(o[19]=[ht('<line x1="8" y1="6" x2="21" y2="6" data-v-144f3270></line><line x1="8" y1="12" x2="21" y2="12" data-v-144f3270></line><line x1="8" y1="18" x2="21" y2="18" data-v-144f3270></line><line x1="3" y1="6" x2="3.01" y2="6" data-v-144f3270></line><line x1="3" y1="12" x2="3.01" y2="12" data-v-144f3270></line><line x1="3" y1="18" x2="3.01" y2="18" data-v-144f3270></line>',6)])])):e.name==="insert-above"?(J(),ee("g",Rh,[...o[20]||(o[20]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),m("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),m("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(J(),ee("g",zh,[...o[21]||(o[21]=[m("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),m("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(J(),ee("g",Hh,[...o[22]||(o[22]=[m("path",{d:"m18 15-6-6"},null,-1),m("path",{d:"M4 20h16"},null,-1),m("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(J(),ee("g",Fh,[...o[23]||(o[23]=[m("path",{d:"M3 6h18"},null,-1),m("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),m("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(J(),ee("g",jh,[...o[24]||(o[24]=[m("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(J(),ee("g",Wh,[...o[25]||(o[25]=[ht('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-144f3270></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-144f3270></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-144f3270></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-144f3270></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-144f3270></path>',5)])])):e.name==="ratio"?(J(),ee("g",Uh,[...o[26]||(o[26]=[m("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(J(),ee("g",Vh,[...o[27]||(o[27]=[m("path",{d:"M8 3 4 7l4 4"},null,-1),m("path",{d:"M4 7h16"},null,-1),m("path",{d:"m16 21 4-4-4-4"},null,-1),m("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(J(),ee("g",qh,[...o[28]||(o[28]=[m("polyline",{points:"16 16 12 12 8 16"},null,-1),m("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),m("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(J(),ee("g",Gh,[...o[29]||(o[29]=[m("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),m("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),m("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(J(),ee("g",Kh,[...o[30]||(o[30]=[m("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),m("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(J(),ee("g",Yh,[...o[31]||(o[31]=[m("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),m("path",{d:"M21 3v5h-5"},null,-1),m("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),m("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(J(),ee("g",Zh,[...o[32]||(o[32]=[m("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),m("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),m("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="chevron-left"?(J(),ee("g",Jh,[...o[33]||(o[33]=[m("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(J(),ee("g",Xh,[...o[34]||(o[34]=[m("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="chevron-down"?(J(),ee("g",Qh,[...o[35]||(o[35]=[m("polyline",{points:"6 9 12 15 18 9"},null,-1)])])):e.name==="chevrons-left"?(J(),ee("g",ep,[...o[36]||(o[36]=[m("polyline",{points:"11 17 6 12 11 7"},null,-1),m("polyline",{points:"18 17 13 12 18 7"},null,-1)])])):e.name==="chevrons-right"?(J(),ee("g",tp,[...o[37]||(o[37]=[m("polyline",{points:"13 17 18 12 13 7"},null,-1),m("polyline",{points:"6 17 11 12 6 7"},null,-1)])])):e.name==="play"?(J(),ee("g",op,[...o[38]||(o[38]=[m("polygon",{points:"6 3 20 12 6 21 6 3"},null,-1)])])):e.name==="pause"?(J(),ee("g",ip,[...o[39]||(o[39]=[m("line",{x1:"10",y1:"4",x2:"10",y2:"20"},null,-1),m("line",{x1:"14",y1:"4",x2:"14",y2:"20"},null,-1)])])):e.name==="clock"?(J(),ee("g",np,[...o[40]||(o[40]=[m("circle",{cx:"12",cy:"12",r:"10"},null,-1),m("polyline",{points:"12 6 12 12 16 14"},null,-1)])])):e.name==="copy"?(J(),ee("g",sp,[...o[41]||(o[41]=[m("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),m("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"||e.name==="export-image"?(J(),ee("g",rp,[...o[42]||(o[42]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),m("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),m("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(J(),ee("g",lp,[...o[43]||(o[43]=[m("circle",{cx:"11",cy:"11",r:"7"},null,-1),m("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(J(),ee("g",ap,[...o[44]||(o[44]=[m("circle",{cx:"12",cy:"12",r:"3"},null,-1),m("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(J(),ee("g",cp,[...o[45]||(o[45]=[ht('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-144f3270></path><polyline points="14 2 14 8 20 8" data-v-144f3270></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-144f3270></line><line x1="16" y1="17" x2="8" y2="17" data-v-144f3270></line><line x1="10" y1="9" x2="8" y2="9" data-v-144f3270></line>',5)])])):e.name==="focus"||e.name==="target"?(J(),ee("g",dp,[...o[46]||(o[46]=[m("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),m("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),m("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(J(),ee("g",up,[...o[47]||(o[47]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),m("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),m("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(J(),ee("g",fp,[...o[48]||(o[48]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-144f3270></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-144f3270></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-144f3270></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-144f3270></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(J(),ee("g",hp,[...o[49]||(o[49]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-144f3270></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-144f3270></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-144f3270></line><line x1="5" y1="15" x2="8" y2="15" data-v-144f3270></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-144f3270></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-144f3270></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-144f3270></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(J(),ee("g",pp,[...o[50]||(o[50]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-144f3270></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-144f3270></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-144f3270></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-144f3270></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-144f3270></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-144f3270></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(J(),ee("g",mp,[...o[51]||(o[51]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-144f3270></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-144f3270></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-144f3270></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-144f3270></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-144f3270></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-144f3270></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-144f3270></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-144f3270></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-144f3270></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(J(),ee("g",gp,[...o[52]||(o[52]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><line x1="5" y1="7" x2="13" y2="7" data-v-144f3270></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-144f3270></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-144f3270></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-144f3270></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-144f3270></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-144f3270></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-144f3270></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(J(),ee("g",yp,[...o[53]||(o[53]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><line x1="12" y1="4" x2="12" y2="20" data-v-144f3270></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-144f3270></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-144f3270></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-144f3270></line><circle cx="15.5" cy="8.5" r="1.2" data-v-144f3270></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-144f3270></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(J(),ee("g",bp,[...o[54]||(o[54]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><line x1="12" y1="4" x2="12" y2="20" data-v-144f3270></line><circle cx="6" cy="8.5" r="1.2" data-v-144f3270></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-144f3270></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-144f3270></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-144f3270></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-144f3270></line>',7)])])):e.name==="layout-center"||e.name==="center"?(J(),ee("g",vp,[...o[55]||(o[55]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(J(),ee("g",kp,[...o[56]||(o[56]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><circle cx="8" cy="9" r="1.5" data-v-144f3270></circle><line x1="14" y1="8" x2="9" y2="14" data-v-144f3270></line><circle cx="15" cy="13" r="1.5" data-v-144f3270></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-144f3270></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(J(),ee("g",wp,[...o[57]||(o[57]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><circle cx="7.5" cy="9.5" r="2" data-v-144f3270></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-144f3270></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-144f3270></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-144f3270></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-144f3270></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(J(),ee("g",xp,[...o[58]||(o[58]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-144f3270></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-144f3270></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-144f3270></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-144f3270></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(J(),ee("g",Sp,[...o[59]||(o[59]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(J(),ee("g",_p,[...o[60]||(o[60]=[m("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),m("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(J(),ee("g",Cp,[...o[61]||(o[61]=[m("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),m("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),m("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(J(),ee("g",Ip,[...o[62]||(o[62]=[m("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),m("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(J(),ee("g",$p,[...o[63]||(o[63]=[m("path",{d:"m17 1 4 4-4 4"},null,-1),m("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),m("path",{d:"m7 23-4-4 4-4"},null,-1),m("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(J(),ee("g",Ap,[...o[64]||(o[64]=[m("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),m("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),m("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(J(),ee("g",Tp,[...o[65]||(o[65]=[ht('<line x1="4" y1="21" x2="4" y2="14" data-v-144f3270></line><line x1="4" y1="10" x2="4" y2="3" data-v-144f3270></line><line x1="12" y1="21" x2="12" y2="12" data-v-144f3270></line><line x1="12" y1="8" x2="12" y2="3" data-v-144f3270></line><line x1="20" y1="21" x2="20" y2="16" data-v-144f3270></line><line x1="20" y1="12" x2="20" y2="3" data-v-144f3270></line><line x1="1" y1="14" x2="7" y2="14" data-v-144f3270></line><line x1="9" y1="8" x2="15" y2="8" data-v-144f3270></line><line x1="17" y1="16" x2="23" y2="16" data-v-144f3270></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(J(),ee("g",Mp,[...o[66]||(o[66]=[m("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),m("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),m("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),m("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(J(),ee("g",Bp,[...o[67]||(o[67]=[m("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(J(),ee("g",Ep,[...o[68]||(o[68]=[m("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),m("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),m("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),m("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(J(),ee("g",Dp,[...o[69]||(o[69]=[m("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),m("path",{d:"m13 8 2 2"},null,-1),m("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(J(),ee("g",Lp,[...o[70]||(o[70]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-144f3270></rect><line x1="13" y1="8" x2="19" y2="8" data-v-144f3270></line><line x1="13" y1="12" x2="19" y2="12" data-v-144f3270></line><line x1="13" y1="16" x2="17" y2="16" data-v-144f3270></line>',5)])])):e.name==="image-right"?(J(),ee("g",Op,[...o[71]||(o[71]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-144f3270></rect><line x1="5" y1="8" x2="11" y2="8" data-v-144f3270></line><line x1="5" y1="12" x2="11" y2="12" data-v-144f3270></line><line x1="5" y1="16" x2="9" y2="16" data-v-144f3270></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(J(),ee("g",Np,[...o[72]||(o[72]=[m("circle",{cx:"12",cy:"12",r:"10"},null,-1),m("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),m("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(J(),ee("g",Pp,[...o[73]||(o[73]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),so=(e,t)=>{const o=e.__vccOpts||e;for(const[i,n]of t)o[i]=n;return o},de=so(Rp,[["__scopeId","data-v-144f3270"]]),zp={class:"spm-immersion-header"},Hp={class:"spm-immersion-header__left"},Fp={class:"spm-immersion-title"},jp={class:"spm-immersion-header__center"},Wp={class:"spm-immersion-header__actions"},Up=["aria-label"],Vp={class:"spm-immersion-body"},qp=Pt({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const o=e,i=t;function n(){i("update:visible",!1),i("close")}function s(){o.closeOnClickMask&&n()}function l(){i("update:isMaximized",!o.isMaximized),i("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),n())}return(a,c)=>Ht((J(),ee("div",{class:xe(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:eo(r,["stop"])},[m("div",{class:"spm-immersion-mask",onClick:s}),m("div",{class:xe(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[m("div",zp,[m("div",Hp,[cn(a.$slots,"header-left",{},()=>[m("span",Fp,ke(e.title),1)])]),m("div",jp,[cn(a.$slots,"header-center",{},void 0)]),m("div",Wp,[cn(a.$slots,"header-actions",{},void 0),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[se(de,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,Up),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:n},[se(de,{name:"close"})])])]),m("div",Vp,[cn(a.$slots,"default",{},void 0)])],2)],34)),[[Os,e.visible]])}}),Gp=so(qp,[["__scopeId","data-v-1359fecb"]]);function Kp(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function nn(e){const t=Kp();if(t)try{return t(e)}catch{try{const o=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(o)}catch{}}}function Yp(){var t;if(typeof window<"u"&&window.process)return window.process;const e=nn("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function Zp(){var t,o;const e=Yp();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const i=nn("child_process");if(i&&typeof i.spawn=="function")return!0}return!!(typeof process<"u"&&((o=process.versions)!=null&&o.node))}function Jp(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}const Xp={class:"spm-protyle-drawer"},Qp={class:"spm-protyle-drawer__subbar"},em={class:"spm-protyle-drawer__nav"},tm=["title"],om={class:"spm-protyle-drawer__actions"},im=["aria-label"],nm=["aria-label"],sm=Pt({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const o=t,i=e,n=pe(i.blockId),s=pe(i.title||""),l=pe(!1),r=pe(!0),a=pe(!1),c=pe(""),u=Yt,h=pe([]),y=pe(null);let d=null;Po(()=>i.blockId,I=>{I&&I!==n.value&&(n.value=I,s.value=i.title||"",h.value=[],p(I))}),Qo(()=>{n.value&&p(n.value)}),rr(()=>{g()});async function f(I){try{const N=await gi(`SELECT id, root_id, type, content FROM blocks WHERE id = '${I}' LIMIT 1`);if(Array.isArray(N)&&N.length>0){const H=N[0];c.value=H.root_id||"";const z=H.id===H.root_id||H.type==="d";a.value=z,r.value=!z,!s.value&&H.content&&(s.value=H.content.trim().slice(0,30));return}}catch(N){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",N)}a.value=!1,r.value=!0}async function p(I,N){if(!y.value||!I)return;g(),await f(I),typeof N=="boolean"&&(r.value=!a.value&&N);let H,z;r.value&&!a.value?(H=["cb-get-all","cb-get-hl","cb-get-focus"],z={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(H=["cb-get-context","cb-get-hl"],z={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{d=new le.Protyle(i.plugin.app,y.value,{blockId:I,action:H,render:z}),!l.value&&d&&typeof d.disable=="function"&&d.disable()}catch(j){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",j)}}function g(){if(d){try{typeof d.destroy=="function"&&d.destroy()}catch(I){console.warn("[ProtylePeekDrawer] Error destroying protyle:",I)}d=null}y.value&&(y.value.innerHTML="")}function b(){a.value||(r.value=!r.value,p(n.value,r.value))}function k(){l.value=!l.value,d&&(l.value?(typeof d.enable=="function"&&d.enable(),typeof d.focus=="function"&&d.focus()):typeof d.disable=="function"&&d.disable())}function w(){if(n.value)try{le.openWindow({doc:{id:n.value},alwaysOnTop:!0})}catch(I){console.warn("[ProtylePeekDrawer] openWindow failed:",I)}}function _(){var H;if(!n.value)return;const I=Zn(),N=Ua(I.webServeUrl,n.value,{focus:!a.value});if(typeof window<"u"){const z=nn("electron");(H=z==null?void 0:z.shell)!=null&&H.openExternal?z.shell.openExternal(N).catch(()=>{window.open(N,"_blank")}):window.open(N,"_blank")}o("external-jump",N)}function M(){if(h.value.length>0){const I=h.value.pop();I&&(n.value=I.blockId,s.value=I.title,r.value=I.isFocusMode,a.value=I.isDoc,p(I.blockId,I.isFocusMode))}}function A(I){const N=I.target;if(!N)return;const H=N.closest('[data-type="block-ref"]');if(H){const j=H.getAttribute("data-id");if(j&&j!==n.value){I.preventDefault(),I.stopPropagation(),h.value.push({blockId:n.value,title:s.value||n.value,isFocusMode:r.value,isDoc:a.value}),n.value=j,s.value=H.innerText.trim()||j,p(j);return}}const z=N.closest("a");if(z&&z.href&&z.href.startsWith("siyuan://blocks/")){I.preventDefault(),I.stopPropagation();const j=z.href.replace("siyuan://blocks/","").split("?")[0];j&&j!==n.value&&(h.value.push({blockId:n.value,title:s.value||n.value,isFocusMode:r.value,isDoc:a.value}),n.value=j,s.value=z.innerText.trim()||j,p(j))}}return(I,N)=>(J(),ee("div",Xp,[m("div",Qp,[m("div",em,[h.value.length>0?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:M},[se(de,{name:"arrow-left"}),N[0]||(N[0]=m("span",null,"返回",-1))])):Te("",!0),m("span",{class:xe(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},ke(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),m("span",{class:"spm-protyle-id",title:s.value||n.value},ke(s.value||n.value),9,tm)]),m("div",om,[a.value?Te("",!0):(J(),ee("button",{key:0,class:xe(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:b},[se(de,{name:r.value?"focus":"file-text"},null,8,["name"]),m("span",null,ke(r.value?"块聚焦":"展开全文"),1)],10,im)),m("button",{class:xe(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:k},[se(de,{name:l.value?"edit":"eye"},null,8,["name"]),m("span",null,ke(l.value?"编辑中":"只读"),1)],10,nm),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:w},[se(de,{name:"window"}),N[1]||(N[1]=m("span",null,"独立窗口",-1))]),he(u).enableWebServeJump?(J(),ee("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:_},[se(de,{name:"external-link"}),N[2]||(N[2]=m("span",null,"外跳",-1))])):Te("",!0)])]),m("div",{ref_key:"mountEl",ref:y,class:xe(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:A},null,2)]))}}),rm=so(sm,[["__scopeId","data-v-0d6e2df3"]]),lm=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,am=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function gl(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const o=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(o)return`/assets/${o[1]}`;const i=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return i?`/plugins/${i[1]}`:null}function Za(e){const t=(e||"").replace(/^file:\/\//i,"");let o=t;try{o=decodeURIComponent(t)}catch{}if(o.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(o)?o.slice(1):o;const i=o.indexOf("/");return i>=0?o.slice(i):o}function cm(e){const t=e.split(/[/?#]/)[0];return!t||am.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function dm(e){const t=e.indexOf("#"),o=t>=0?e.slice(t):"",i=t>=0?e.slice(0,t):e,n=i.indexOf("?"),s=n>=0?i.slice(0,n):i,l=n>=0?i.slice(n+1):"";if(!/^\/?assets\/.+\.html?$/i.test(s))return e;const r=new URLSearchParams(l);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${s}?${r.toString()}${o}`)}function Ja(e){const t=um(e);return t.external||!t.url?t:{url:dm(t.url),external:!1}}function um(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(Pl(t))return{url:`/${Rl(t)}`,external:!1};if(/^file:/i.test(t)){const i=gl(Za(t));return i?{url:i,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const i=gl(t);return i?{url:i,external:!1}:{url:t,external:!0}}return lm.test(t)?{url:t,external:!0}:cm(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const fm={class:"spm-webview-drawer"},hm={class:"spm-webview-toolbar"},pm={class:"spm-webview-toolbar__nav"},mm=["disabled"],gm=["disabled"],ym=["aria-label"],bm={class:"spm-webview-toolbar__address"},vm=["aria-label"],km={class:"spm-webview-toolbar__actions"},wm=["aria-label"],xm={class:"spm-zoom-controller"},Sm=["disabled"],_m=["disabled"],Cm={key:1,class:"spm-webview-fallback"},Im=["src"],$m={key:2,class:"spm-load-error"},Am={class:"spm-load-error__code"},Tm={class:"spm-load-error__code-num"},Mm={class:"spm-load-error__url"},Bm={class:"spm-load-error__hint"},Em={class:"spm-load-error__actions"},yl="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",Xa="siyuan-slides-peek-view-mode";let Qa="desktop";function Dm(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(Xa);if(e==="mobile"||e==="desktop")return e}catch{}return Qa}function Lm(e){if(Qa=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(Xa,e)}catch{}}function Om(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const Nm=Pt({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const o=t,i=e,n=pe(Zp()&&!Jp()),s=pe(i.url),l=pe(i.url),r=i.url,a=pe(!1),c=pe(null),u=pe(!1),h=pe(!1),y=pe(1),d=pe(!1),f=pe(Dm());let p=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const g=ye(()=>f.value==="mobile"?yl:p||void 0),b=pe(null),k=pe(null);let w=null,_=null,M=null;Po(()=>i.url,P=>{P&&P!==s.value&&(s.value=P,l.value=P,f.value==="mobile"&&z(!1),b.value&&typeof b.value.loadURL=="function"&&b.value.loadURL(P))}),Po(()=>i.visible,P=>{if(P)ce(),f.value==="mobile"&&z(!1);else if(b.value)try{typeof b.value.stop=="function"&&b.value.stop()}catch{}}),Qo(()=>{A(),k.value&&typeof ResizeObserver<"u"&&(w=new ResizeObserver(()=>{const P=b.value;if(P&&typeof P.invalidate=="function")try{P.invalidate()}catch{}}),w.observe(k.value)),_=P=>{var E;const ie=P.message||((E=P.error)==null?void 0:E.message);if(typeof ie=="string"&&ie.includes("Invalid guestInstanceId"))return P.preventDefault(),P.stopImmediatePropagation(),!0},window.addEventListener("error",_,!0),M=P=>{const ie=P.reason,E=typeof ie=="string"?ie:ie==null?void 0:ie.message;typeof E=="string"&&E.includes("Invalid guestInstanceId")&&P.preventDefault()},window.addEventListener("unhandledrejection",M)}),rr(()=>{if(I(),w&&(w.disconnect(),w=null),_&&(window.removeEventListener("error",_,!0),_=null),M&&(window.removeEventListener("unhandledrejection",M),M=null),b.value)try{typeof b.value.stop=="function"&&b.value.stop()}catch{}});function A(){const P=b.value;P&&(P.addEventListener("dom-ready",N),P.addEventListener("did-start-loading",j),P.addEventListener("did-stop-loading",x),P.addEventListener("did-navigate",V),P.addEventListener("did-navigate-in-page",W),P.addEventListener("new-window",$),P.addEventListener("did-fail-load",B),P.addEventListener("did-fail-provisional-load",B))}function I(){const P=b.value;if(P)try{P.removeEventListener("dom-ready",N),P.removeEventListener("did-start-loading",j),P.removeEventListener("did-stop-loading",x),P.removeEventListener("did-navigate",V),P.removeEventListener("did-navigate-in-page",W),P.removeEventListener("new-window",$),P.removeEventListener("did-fail-load",B),P.removeEventListener("did-fail-provisional-load",B)}catch{}}function N(){const P=b.value;if(P&&typeof P.getUserAgent=="function"&&!p)try{const ie=P.getUserAgent();ie&&!ie.includes("iPhone")&&(p=ie)}catch{}f.value==="mobile"&&z(!1),ce(),T()}function H(){const P=f.value==="mobile"?"desktop":"mobile";f.value=P,Lm(P),z(!0)}function z(P=!1){const ie=b.value;if(!ie)return;const E=f.value==="mobile"?yl:p;if(typeof ie.setUserAgent=="function"&&E)try{ie.setUserAgent(E)}catch(F){console.warn("[WebviewPeekDrawer] setUserAgent error:",F)}if(P&&typeof ie.reload=="function")try{ie.reload()}catch(F){console.warn("[WebviewPeekDrawer] reload error:",F)}}function j(){a.value=!0,c.value=null}function B(P){if(P&&P.isMainFrame===!1||P&&Number(P.errorCode)===-3)return;const ie=String((P==null?void 0:P.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((P==null?void 0:P.errorCode)??0),description:ie,validatedURL:String((P==null?void 0:P.validatedURL)||s.value),hint:Om(ie)},a.value=!1}function D(){c.value=null,K()}function x(){if(a.value=!1,T(),b.value&&typeof b.value.getURL=="function"){const P=b.value.getURL();P&&P!=="about:blank"&&(s.value=P,l.value=P)}}function V(P){P!=null&&P.url&&(s.value=P.url,l.value=P.url),T()}function W(P){P!=null&&P.url&&(s.value=P.url,l.value=P.url),T()}function $(P){P&&P.url&&(P.preventDefault(),b.value&&typeof b.value.loadURL=="function"&&b.value.loadURL(P.url))}function T(){const P=b.value;P&&(typeof P.canGoBack=="function"&&(u.value=P.canGoBack()),typeof P.canGoForward=="function"&&(h.value=P.canGoForward()))}function O(){b.value&&typeof b.value.goBack=="function"&&b.value.goBack()}function te(){b.value&&typeof b.value.goForward=="function"&&b.value.goForward()}function K(){b.value&&typeof b.value.reload=="function"&&b.value.reload()}function Z(){const P=Ja(l.value);if(P.url){if(P.external){s.value=P.url,_e();return}s.value=P.url,l.value=P.url,b.value&&typeof b.value.loadURL=="function"&&b.value.loadURL(P.url)}}function ce(){const P=b.value;if(P&&typeof P.setZoomFactor=="function")try{P.setZoomFactor(y.value)}catch(ie){console.warn("[WebviewPeekDrawer] setZoomFactor error:",ie)}}function oe(){y.value=Math.min(2.5,Math.round((y.value+.1)*10)/10),ce()}function re(){y.value=Math.max(.5,Math.round((y.value-.1)*10)/10),ce()}function Se(){y.value=1,ce()}function Ie(P){P.preventDefault(),P.deltaY<0?oe():P.deltaY>0&&re()}async function ve(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(s.value),d.value=!0,setTimeout(()=>{d.value=!1},2e3)}catch(P){console.warn("Copy url failed:",P)}}function _e(){var ie;const P=s.value;if(typeof window<"u"){const E=nn("electron");(ie=E==null?void 0:E.shell)!=null&&ie.openExternal?E.shell.openExternal(P).catch(()=>{window.open(P,"_blank")}):window.open(P,"_blank")}o("external-jump",P)}return(P,ie)=>{const E=Mu("webview");return J(),ee("div",fm,[m("div",hm,[m("div",pm,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!u.value,"aria-label":"后退",onClick:O},[se(de,{name:"arrow-left"})],8,mm),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!h.value,"aria-label":"前进",onClick:te},[se(de,{name:"arrow-right"})],8,gm),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":a.value?"正在加载...":"刷新页面",onClick:K},[se(de,{name:"refresh"})],8,ym)]),m("div",bm,[Ht(m("input",{"onUpdate:modelValue":ie[0]||(ie[0]=F=>l.value=F),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:qf(Z,["enter"])},null,544),[[Ns,l.value]]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":d.value?"已复制地址！":"复制网址",onClick:ve},[se(de,{name:"copy"})],8,vm)]),m("div",km,[m("button",{class:xe(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":f.value==="mobile"}]),"aria-label":f.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:H},[se(de,{name:f.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,wm),m("div",xm,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:y.value<=.5,onClick:re},[se(de,{name:"minus"})],8,Sm),m("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:Se},ke(Math.round(y.value*100))+"% ",1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:y.value>=2.5,onClick:oe},[se(de,{name:"plus"})],8,_m)]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:_e},[se(de,{name:"external-link"}),ie[1]||(ie[1]=m("span",null,"外跳",-1))])])]),m("div",{ref_key:"containerEl",ref:k,class:xe(["spm-webview-body",{"is-mobile":f.value==="mobile"}]),onWheel:eo(Ie,["ctrl"])},[m("div",{class:xe(["spm-webview-viewport",{"is-mobile":f.value==="mobile"}])},[n.value?(J(),to(E,{key:0,ref_key:"webviewRef",ref:b,class:"spm-webview-frame",src:he(r),useragent:g.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(J(),ee("div",Cm,[m("iframe",{class:"spm-webview-fallback-frame",src:s.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Im),m("div",{class:"spm-fallback-bar"},[ie[2]||(ie[2]=m("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),m("button",{class:"spm-icon-btn is-primary",onClick:_e}," 在新标签页中打开 ↗ ")])])),c.value?(J(),ee("div",$m,[se(de,{name:"alert",class:"spm-load-error__icon"}),ie[5]||(ie[5]=m("div",{class:"spm-load-error__title"},"页面加载失败",-1)),m("div",Am,[Et(ke(c.value.description)+" ",1),m("span",Tm,"("+ke(c.value.errorCode)+")",1)]),m("div",Mm,ke(c.value.validatedURL),1),m("p",Bm,ke(c.value.hint),1),m("div",Em,[m("button",{class:"spm-icon-btn","aria-label":"重试",onClick:D},[se(de,{name:"refresh"}),ie[3]||(ie[3]=m("span",null,"重试",-1))]),m("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:_e},[se(de,{name:"external-link"}),ie[4]||(ie[4]=m("span",null,"用系统浏览器打开 ↗",-1))])])])):Te("",!0)],2)],34)])}}}),Pm=so(Nm,[["__scopeId","data-v-6e363f73"]]);class Rm{constructor(){$e(this,"timers",new Map)}debounce(t,o,i=150){this.cancel(t);const n=setTimeout(()=>{this.timers.delete(t),o()},i);this.timers.set(t,n)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class zm{constructor(t){$e(this,"blockToPageMap",new Map);$e(this,"debounceCtrl",new Rm);$e(this,"activeBlockId","");$e(this,"activePageIndex",1);$e(this,"currentDocId","");$e(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t,t&&this.blockToPageMap.delete(t)}updateSlidesIndex(t){this.blockToPageMap.clear();for(const o of t){o.startBlockId&&o.startBlockId!==this.currentDocId&&this.blockToPageMap.set(o.startBlockId,o.pageIndex);for(const i of o.blocks)this.blockToPageMap.set(i.id,o.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;if(this.activeBlockId=t,t===this.currentDocId){this.debounceCtrl.cancel("cursor-navigate");return}const o=this.getPageByBlockId(t);if(!o){this.debounceCtrl.cancel("cursor-navigate");return}this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=o,this.bridge&&(this.bridge.navigatePage(o),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t,t||this.debounceCtrl.cancel("cursor-navigate");const o=this.getPageByBlockId(t);o&&(this.activePageIndex=o)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}let Ot=null,gn=null,yn="";function ji(){var e,t;if(gn&&(clearTimeout(gn),gn=null),Ot){try{Ot.classList.remove("protyle-wysiwyg--select"),yn?Ot.style.outline=yn:typeof((e=Ot.style)==null?void 0:e.removeProperty)=="function"?Ot.style.removeProperty("outline"):Ot.style&&(Ot.style.outline=""),typeof((t=Ot.style)==null?void 0:t.removeProperty)=="function"?Ot.style.removeProperty("transition"):Ot.style&&(Ot.style.transition="")}catch(o){console.warn("[SelectionMirror] clear activeHighlightEl failed:",o)}Ot=null,yn=""}if(typeof document<"u"&&typeof document.querySelectorAll=="function")try{document.querySelectorAll(".protyle-wysiwyg [data-node-id].protyle-wysiwyg--select, .protyle-wysiwyg [data-node-id][style*='outline']").forEach(i=>{var s,l;i.classList.remove("protyle-wysiwyg--select");const n=((s=i.style)==null?void 0:s.outline)||"";(n.includes("#3b82f6")||n.includes("rgb(59, 130, 246)")||n.includes("59, 130, 246"))&&(typeof((l=i.style)==null?void 0:l.removeProperty)=="function"?(i.style.removeProperty("outline"),i.style.removeProperty("transition")):i.style&&(i.style.outline="",i.style.transition=""))})}catch{}}function Jo(e,t){var l,r,a,c;if(!e||typeof document>"u")return ji(),!1;ji();const o=(l=globalThis.CSS)!=null&&l.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),i=document.querySelector(`.protyle-wysiwyg [data-node-id="${o}"]`)||document.querySelector(`[data-node-id="${o}"]`);if(!i){if(t)try{return le.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(u){console.warn("[SelectionMirror] openTab fallback failed:",u)}return!1}try{i.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{(r=i.scrollIntoView)==null||r.call(i)}try{(a=i.focus)==null||a.call(i,{preventScroll:!0})}catch{}const n=((c=i.style)==null?void 0:c.outline)||"";return yn=n.includes("#3b82f6")||n.includes("rgb(59, 130, 246)")||n.includes("59, 130, 246")?"":n,i.classList.add("protyle-wysiwyg--select"),i.style&&(i.style.outline="2px solid #3b82f6",i.style.transition="outline 0.2s ease"),Ot=i,gn=setTimeout(()=>{ji()},500),!0}function bl(e){var i,n,s;const t=typeof document<"u"?document:null,o=e||t;if(!o&&!t)return!1;try{const l=(typeof(o==null?void 0:o.querySelectorAll)=="function"?o.querySelectorAll(".protyle-wysiwyg--select"):null)||(typeof(t==null?void 0:t.querySelectorAll)=="function"?t.querySelectorAll(".protyle-wysiwyg--select"):[]);if(l&&l.length>1){const r=new Set;for(let a=0;a<l.length;a++){const c=l[a],u=typeof c.closest=="function"?c.closest("[data-node-id]"):c,h=(i=u==null?void 0:u.getAttribute)==null?void 0:i.call(u,"data-node-id");h?r.add(h):r.add(`elem-${a}`)}if(r.size>1)return!0}}catch{}try{const l=typeof window<"u"?window:globalThis.window,r=typeof(l==null?void 0:l.getSelection)=="function"?l.getSelection():null;if(r&&r.rangeCount>0&&!r.isCollapsed&&typeof r.getRangeAt=="function"){const a=r.getRangeAt(0);if(a){const c=a.startContainer,u=a.endContainer;if(c&&u&&c!==u){const h=c.nodeType===1?c:c.parentElement,y=u.nodeType===1?u:u.parentElement,d=typeof(h==null?void 0:h.closest)=="function"?h.closest("[data-node-id]"):null,f=typeof(y==null?void 0:y.closest)=="function"?y.closest("[data-node-id]"):null,p=(n=d==null?void 0:d.getAttribute)==null?void 0:n.call(d,"data-node-id"),g=(s=f==null?void 0:f.getAttribute)==null?void 0:s.call(f,"data-node-id");if(p&&g&&p!==g)return!0}}}}catch{}return!1}function Hm(e){if(!e)return"";const t=e.split(`
`).map(l=>l.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(l=>/^#{1,6}\s+/.test(l)))return t.map(l=>dt(l)).join("<br/>");const i=[];let n=[];const s=()=>{if(n.length>0){const l=n.map(r=>dt(r)).join("<br/>");i.push(`<p class="slide-list-item-desc">${l}</p>`),n=[]}};for(const l of t){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){s();const a=r[1].length,c=r[2].trim();i.push(`<h${a} class="slide-list-item-title">${dt(c)}</h${a}>`)}else n.push(l)}return s(),i.join(`
`)}function Fm(e){if(e.length===0)return"";const t=[],o=e[0],i=o.match(/^(#{1,6})\s+(.*)$/);if(i){const n=i[1].length,s=i[2].trim();t.push(`<h${n} class="slide-list-item-title">${dt(s)}</h${n}>`)}else t.push(`<p class="slide-list-item-title">${dt(o)}</p>`);if(e.length>1){const n=e.slice(1);let s=[];const l=()=>{if(s.length>0){const r=s.map(a=>dt(a)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),s=[]}};for(const r of n){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,u=a[2].trim();t.push(`<h${c} class="slide-list-item-title">${dt(u)}</h${c}>`)}else s.push(r)}l()}return t.join(`
`)+(t.length>0?`
`:"")}function ec(e,t,o){var y,d,f,p;const i=e.split(`
`);if(!i.some(g=>/^(\s*)([-*+]|\d+\.)\s+/.test(g)))return(o!=null&&o.isListItem||(o==null?void 0:o.type)==="i")&&!(o!=null&&o.isColFirst)?`<ul class="slide-list slide-list--unordered">
<li class="slide-list-item">${dt(e)}</li>
</ul>`:null;const s=[],l=[];let r=!1;for(let g=0;g<i.length;g++){const b=i[g];if(!b.trim())continue;const k=b.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(k){const A=k[1].length,I=Math.floor(A/2);l.push({type:"task",level:I,checked:k[2].toLowerCase()==="x",text:k[3],media:[]});continue}const w=b.match(/^(\s*)[-*+]\s+(.*)$/);if(w){const A=w[1].length,I=Math.floor(A/2);l.push({type:"unordered",level:I,text:w[2],media:[]});continue}const _=b.match(/^(\s*)\d+\.\s+(.*)$/);if(_){l.length===0&&(r=!0);const A=_[1].length,I=Math.floor(A/2);l.push({type:"ordered",level:I,text:_[2],media:[]});continue}const M=b.trim();if(!(!M||/^\{:.*?\}$/.test(M)))if(l.length>0){const A=M.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(A){const H=/\.gif(?:\?|$)/i.test(A[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${st(A[1])}" src="${A[2]}" class="${H}" /></div>`);continue}if(M.match(/^<img\b[\s\S]*?\/?>$/i)){const N=M.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${N}</div>`);continue}if(/<video\b/i.test(M)){let N=M;if(!/<\/video>/i.test(N))for(;g+1<i.length&&!/<\/video>/i.test(N);)g++,N+=" "+i[g].trim();const H=((y=o==null?void 0:o.attributes)==null?void 0:y["custom-slides-autoplay"])==="true"||/autoplay/i.test(N),z=((d=o==null?void 0:o.attributes)==null?void 0:d["custom-slides-loop"])==="true"||/loop/i.test(N),j=((f=o==null?void 0:o.attributes)==null?void 0:f["custom-slides-muted"])==="true"||H||/muted/i.test(N),B=((p=o==null?void 0:o.attributes)==null?void 0:p["custom-slides-controls"])==="false",D=N.match(/\bsrc=["']([^"']+)["']/i),x=D?D[1]:"",V=['class="slide-video-player"'];B||V.push("controls"),H&&(V.push("autoplay"),V.push("playsinline")),z&&V.push("loop"),j&&V.push("muted"),V.push('preload="metadata"'),x&&V.push(`src="${x}"`);const W=N.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let $=W?W[1].trim():"";!$&&x&&($=`<source src="${x}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${H?"true":"false"}" data-muted="${j?"true":"false"}"><video ${V.join(" ")}>${$}</video></div>`);continue}l[l.length-1].text+=`
`+M}else s.push(M)}if(l.length===0)return null;const a=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),u=l.map(g=>{const b=Hm(g.text),k=g.media&&g.media.length>0?`
${g.media.join(`
`)}`:"",w=g.level||0,_=w>0?` style="margin-left:${(w*1.25).toFixed(2)}em;${g.type==="unordered"?`list-style-type:${w%2===1?"circle":"square"} !important;`:""}"`:"",M=w>0?" slide-list-item--nested":"";if(g.type==="task"){const I=g.checked?' checked=""':"";return`<li class="pdf-task-item${M}"${_}><label><input type="checkbox" disabled=""${I}/> <span>${b}</span></label>${k}</li>`}return`<li${M?` class="${M.trim()}"`:""}${_}>${b}${k}</li>`}).join(`
`);return`${Fm(s)}<${a} class="${c}">
${u}
</${a}>`}function jm(e,t,o){const i=(t==null?void 0:t.containerClassName)||"pdf-block",n=e.split(/\r?\n/),s=[];let l=[];for(let c=0;c<n.length;c++){const u=n[c],h=u.trim();if(/^#{1,6}\s+/.test(h)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(h);continue}if(!h){l.length>0&&(s.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(h)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(h);continue}if(/<video\b/i.test(h)){l.length>0&&(s.push(l.join(`
`)),l=[]);let y=h;if(!/<\/video>/i.test(y))for(;c+1<n.length&&!/<\/video>/i.test(y);)c++,y+=`
`+n[c];s.push(y);continue}l.push(u)}l.length>0&&s.push(l.join(`
`));let r=!0;return s.map(c=>{var f,p,g,b;const u=c.trim();if(!u)return"";const h=u.match(/^(#{1,6})\s+(.*)$/);if(h){r=!1;const k=h[1].length;return`<h${k} class="slide-list-item-title">${dt(h[2].trim())}</h${k}>`}const y=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(y){const k=/\.gif(?:\?|$)/i.test(y[2]),w=(t==null?void 0:t.imageClassName)||(k?"list-item-gif":"pdf-image slide-media-img");return`<div class="${i} ${i}--image slide-media-block slide-media-container slide-list-media"><img alt="${st(y[1])}" src="${y[2]}" class="${w}" /></div>`}if(/<video\b/i.test(u)){const k=((f=o==null?void 0:o.attributes)==null?void 0:f["custom-slides-autoplay"])==="true"||/autoplay/i.test(u),w=((p=o==null?void 0:o.attributes)==null?void 0:p["custom-slides-loop"])==="true"||/loop/i.test(u),_=((g=o==null?void 0:o.attributes)==null?void 0:g["custom-slides-muted"])==="true"||k||/muted/i.test(u),M=((b=o==null?void 0:o.attributes)==null?void 0:b["custom-slides-controls"])==="false",A=u.match(/\bsrc=["']([^"']+)["']/i),I=A?A[1]:"",N=['class="slide-video-player"'];M||N.push("controls"),k&&N.push("autoplay playsinline"),w&&N.push("loop"),_&&N.push("muted"),N.push('preload="metadata"'),I&&N.push(`src="${I}"`);const H=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let z=H?H[1].trim():"";return!z&&I&&(z=`<source src="${I}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${i} ${i}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${k?"true":"false"}" data-muted="${_?"true":"false"}"><video ${N.join(" ")}>${z}</video></div>`}const d=ec(u,t,o);if(d)return r=!1,d;if(r){r=!1;const k=u.split(/\r?\n/).map(A=>A.trim()).filter(Boolean);if(k.length===1)return`<p class="slide-list-item-title">${dt(k[0])}</p>`;const w=k[0],M=k.slice(1).map(A=>dt(A)).join("<br/>");return`<p class="slide-list-item-title">${dt(w)}</p>
<p class="slide-list-item-desc">${M}</p>`}return`<p class="slide-list-item-desc">${dt(u)}</p>`}).filter(Boolean).join(`
`)}function fs(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function tc(e,t){var r,a,c,u,h,y,d,f;const o=((r=e.frontmatter)==null?void 0:r.layout)||"default",n=(e.blocks||[]).filter(p=>p.slot!=="slot-divider-right"),l=o==="cover"?null:n.find(fs);if(o==="two-cols"){const p=n.some(j=>j.slot==="right");let g=[],b=[];if(p)g=n.filter(j=>j.slot!=="right"),b=n.filter(j=>j.slot==="right");else{const j=Math.ceil(n.length/2);g=n.slice(0,j),b=n.slice(j)}const k=j=>{const B=j.filter(D=>!!(D.rawMarkdown||D.content||"").trim());if(B.length>0){const D=B[0],x=(D.rawMarkdown||D.content||"").trim();(Ro(D)||/^(?:[-*+]|\d+\.)\s+/.test(x))&&(D.rawMarkdown=zi(D.rawMarkdown||D.content||""),D.content=D.rawMarkdown)}};k(g),k(b);const w=g.map(j=>$o(j,t)).join(`
`),_=b.map(j=>$o(j,t)).join(`
`),M=(t==null?void 0:t.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",A=(a=e.frontmatter)!=null&&a.layoutClass?` ${e.frontmatter.layoutClass}`:"",I=(t==null?void 0:t.leftColClass)||"pdf-col pdf-col--left",N=(t==null?void 0:t.rightColClass)||"pdf-col pdf-col--right",z=`style="grid-template-columns: ${ds((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${M}${A}" ${z}>
        <div class="${I}">${w}</div>
        <div class="${N}">${_}</div>
      </div>
    `}if(o==="clover"||di(o)){const p=o==="clover";let g=[];const b=n.filter(V=>V.slot==="header");if(b.length>0)g=b;else if(n.length>0){const V=n.find(W=>W.type==="h"&&(!W.slot||W.slot==="default"));V&&(g=[V])}const k=n.filter(V=>!g.includes(V));let w=2;if(p)w=4;else if(o==="three-cols-header")w=3;else if(o==="two-cols-header")w=2;else{let V=0;for(const W of k){const $=(W.slot||"").match(/^col-(\d+)$/i);$&&(V=Math.max(V,parseInt($[1],10)))}if(V>=2)w=V;else if((u=e.frontmatter)!=null&&u.layoutRatio){const W=e.frontmatter.layoutRatio.trim();if(W.includes(":")){const $=W.split(":").map(T=>parseFloat(T.trim())).filter(T=>!isNaN(T)&&T>0);$.length>=2&&(w=$.length)}else{const $=W.split(/\s+/).filter(Boolean);$.length>=2&&(w=$.length)}}else k.length===1&&k[0].children&&k[0].children.length>=2&&(w=Math.min(6,k[0].children.length))}const _=zs(k,w),M=k.some(V=>V.slot&&/^(?:col-\d+|left|right)$/i.test(V.slot)),A=o==="clover"||o==="two-cols-header"||o==="three-cols-header"||di(o)&&M,I=V=>{const W=V.filter(T=>!!(T.rawMarkdown||T.content||"").trim());if(A&&W.length>0){const T=W[0],O=(T.rawMarkdown||T.content||"").trim();(Ro(T)||/^(?:[-*+]|\d+\.)\s+/.test(O))&&(T.rawMarkdown=zi(T.rawMarkdown||T.content||""),T.content=T.rawMarkdown),T.isColFirst=!0}const $=A?W.find(fs):null;return W.map(T=>$o(T,{...t,extraClassName:T===$?"slides-col-first-heading-block":""})).join(`
`)},N=g.find(fs),H=g.map(V=>$o(V,{...t,extraClassName:V===N?"slides-page-first-heading-block":""})).join(`
`),z=p?"repeat(2, minmax(0, 1fr))":ds((h=e.frontmatter)==null?void 0:h.layoutRatio,w),j=p?`style="grid-template-columns: ${z}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${z};"`,B=[p?"layout-clover-container":"layout-cols-header-container",w===2?"layout-two-cols-header-container":"",w===3?"layout-three-cols-header-container":"",`layout-${o}-container`,A?"has-superblock-cols":""].filter(Boolean).join(" "),D=[p?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",w===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",w===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",A?"has-superblock-cols":""].filter(Boolean).join(" "),x=_.map((V,W)=>{const $=W+1;return`<div class="${["pdf-col",w===2&&$===1?"pdf-col--left":"",w===2&&$===2?"pdf-col--right":"",`pdf-col--${$}`,`col-${$}`].filter(Boolean).join(" ")}">${I(V)}</div>`}).join(`
`);return`
      <div class="${B}">
        <div class="layout-header-section">${H}</div>
        <div class="${D}" ${j}>
          ${x}
        </div>
      </div>
    `}if(o==="image-right"||o==="image-left"){const p=o==="image-right",g=n.map(A=>$o(A,t)).join(`
`),b=((y=e.frontmatter)==null?void 0:y.image)||((d=e.frontmatter)==null?void 0:d.background)||"",k=`<div class="pdf-image-col" style="background-image:url('${st(b)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${st(b)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,w=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${g}</div>`,_=p?`${w}
${k}`:`${k}
${w}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${ds((f=e.frontmatter)==null?void 0:f.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${_}
      </div>
    `}return o==="fact"?`<div class="layout-fact-container">${n.map(g=>$o(g,t)).join(`
`)}</div>`:o==="cover"?`<div class="layout-cover-container">${n.map(g=>$o(g,t)).join(`
`)}</div>`:n.map(p=>$o(p,{...t,extraClassName:p===l?"slides-page-first-heading-block":""})).join(`
`)}function st(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Wm(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,o=e.split("|");for(const i of o){const n=i.trim();if(n==="all")return"all";if(n.includes("-")){const[s,l]=n.split("-"),r=parseInt(s,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)t.add(c)}else{const s=parseInt(n,10);isNaN(s)||t.add(s)}}return t}const Um=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function dt(e){if(!e)return"";const t=Ga(e),o=[],i=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,l)=>{const r=l.toLowerCase();if(!Um.has(r)||/on\w+\s*=|javascript:/i.test(s))return s;if(r==="v-mark"){const a=s.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return s.startsWith("</")?o.push("</mark>"):o.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${o.length-1}%%`}return o.push(s),`%%SAFE_HTML_${o.length-1}%%`});let n=st(i);return n=n.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,l,r,a,c,u,h)=>{const d=(r??a??c??u??h??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${d}</a>`}),n=n.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),n=n.replace(/!\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),n=n.replace(/\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slides-link">${l}</a>`}),n=n.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${r}</a>`),n=n.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),n=n.replace(/\*(.*?)\*/g,"<em>$1</em>"),n=n.replace(/~~(.*?)~~/g,"<del>$1</del>"),n=n.replace(/`([^`]+)`/g,"<code>$1</code>"),n=n.replace(/%%SAFE_HTML_(\d+)%%/g,(s,l)=>{const r=parseInt(l,10);return o[r]||""}),n}function Vm(e,t="pdf-table"){if(e.length<2)return"";const o=e.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),i=o[0];let n=[],s=1;e.length>=2&&o[1].every(a=>/^:?-+:?$/.test(a))&&(n=o[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),s=2);const l=`<thead><tr>${i.map((a,c)=>`<th${n[c]?` style="text-align: ${n[c]}"`:""}>${dt(a)}</th>`).join("")}</tr></thead>`,r=o.slice(s).map(a=>`<tr>${a.map((c,u)=>`<td${n[u]?` style="text-align: ${n[u]}"`:""}>${dt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${l}<tbody>${r}</tbody></table>`}function hs(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function vl(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${hs(e)}</span>`;const o=[];function i(s,l){return o.push(`<span class="${s}">${hs(l)}</span>`),`__TOK_${o.length-1}__`}let n=e.replace(/(['"`])(.*?)\1/g,(s,l,r)=>i("token-string",`${l}${r}${l}`));return n=n.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,s=>i("token-keyword",s)),n=n.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,s=>i("token-type",s)),n=n.replace(/\b(\d+)\b/g,s=>i("token-number",s)),n=hs(n),n=n.replace(/__TOK_(\d+)__/g,(s,l)=>o[parseInt(l,10)]||""),n}function qm(e,t){if(!e)return null;const o=e.frontmatter||{};if(o.hideInToc===!0||o.hideInToc==="true")return null;let i=(o.title||"").trim(),n=o.level?parseInt(o.level,10):0;if(!i){const s=e.blocks||[];for(const l of s){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){n||(n=a[1].length),i=a[2].trim();break}}}return i?((!n||isNaN(n))&&(n=1),{pageIndex:e.pageIndex||t,title:i,level:n}):null}function Gm(e,t=1,o={}){const i=o.minDepth!==void 0?Number(o.minDepth):1,n=o.maxDepth!==void 0?Number(o.maxDepth):1/0,s=[];Array.isArray(e)&&e.forEach((c,u)=>{const h=qm(c,u+1);h&&s.push(h)});const l=[];let r=null;for(const c of s){const u={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(u),r=u):r?(u.active&&(r.hasActiveChild=!0),r.children.push(u)):l.push(u)}function a(c,u=1){if(u>n)return[];const h=[];for(const y of c){const d=a(y.children,u+1);u>=i?h.push({...y,children:d}):h.push(...d)}return h}return a(l,1)}function Km(e,t=1,o={}){const i=Gm(e,t,o),n=o.columns?Number(o.columns):1,s=n>1?` style="column-count: ${n};"`:"",l=o.textSm?" text-sm":"";function r(c,u=1){if(!c||c.length===0)return"";const h=`slides-toc-list slides-toc-list-level-${u}`,y=c.map(d=>{const f=d.active?" slides-toc-item-active":d.hasActiveChild?" slides-toc-item-parent-active":"",p=d.children&&d.children.length>0?r(d.children,u+1):"";let g=dt(d.title);return g.includes("LaTeX")&&(g=g.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slides-toc-item${f}" data-page="${d.pageIndex}">
          <a class="slides-toc-link" href="javascript:void(0)">
            <span class="slides-toc-title">${g}</span>
          </a>
          ${p}
        </li>
      `}).join("");return`<ol class="${h}">${y}</ol>`}const a=r(i,1);return`<div class="slides-toc${l}"${s}>${a}</div>`}function $o(e,t){var M,A,I,N,H,z,j,B,D,x,V,W;let o="",i="",n="";const s=[];(M=e.motion)!=null&&M.preset&&e.motion.preset!=="none"&&(o=` slides-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&s.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&s.push(`--motion-delay:${e.motion.delay}ms`));const l=((A=e.attributes)==null?void 0:A.style)||"";l&&(s.push(l),n=" slide-styled-block"),s.length>0&&(i=` style="${st(s.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",a=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=t!=null&&t.blockClassResolver?t.blockClassResolver(e):"",u=c?` ${c}`:"",h=`${r}${o}${n}${a}${u}`,y=(e.rawMarkdown||e.content||"").trim();if(!y)return`<div class="${h}"${i}></div>`;if(y.includes('class="slides-block-ref"')||y.includes('class="slides-ref-tag"'))return`<div class="${h}"${i}>${y}</div>`;if(y.startsWith("$$")&&y.endsWith("$$")){const $=y.slice(2,-2).trim();return`<div class="${h} katex-display-container"${i}><div class="katex-display font-math"><em>${st($)}</em></div></div>`}const d=y.match(/^(#{1,6})\s+(.*)$/);if(d){const $=d[1].length,T=dt(d[2]),te=!!(e.isColFirst||e.type==="i"&&((I=t==null?void 0:t.extraClassName)!=null&&I.includes("slides-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${h}"${i}><h${$}${te}>${T}</h${$}></div>`}if(y.startsWith(":::")){const $=y.split(`
`),O=$[0].replace(/^:::\s*/,"").trim()||"info",te=$.slice(1,$[$.length-1].startsWith(":::")?-1:void 0).join(`
`),K=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${h}"${i}><div class="${K} ${K}--${O}"><div class="${K}-title">${O.toUpperCase()}</div><div class="${K}-body">${dt(te)}</div></div></div>`}if(y.startsWith("<<<")){const O=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((oe,re)=>`<span class="code-line shiki-focus"><span class="line-no">${re+1}</span><span class="line-content">${vl(oe,"ts")}</span></span>`).join(`
`),te=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",K=((N=e.attrs)==null?void 0:N["custom-slides-max-height"])||((H=e.attributes)==null?void 0:H["custom-slides-max-height"])||e.maxHeight||"",Z=Rs(String(K||"")),ce=Z?` style="max-height:${st(Z)};overflow-y:auto;"`:"";return`<div class="${h}"${i}><pre class="${te}"${ce}><span class="lang-badge">TS</span><code>${O}</code></pre></div>`}if(y.startsWith("<style")||y.startsWith("<!-- Inline style -->")||y.startsWith(`<!--
Notes`))return"";if(y.startsWith("```")){const $=y.split(`
`),T=$[0].slice(3).trim(),O=T.match(/^([^\s{\[]+)/),te=O?O[1]:"",K=T.match(/\[([^\]]+)\]/),Z=K?K[1]:"",ce=T.includes("twoslash"),oe=e.shikiLines||((z=T.match(/\{([^}]+)\}/))==null?void 0:z[1])||"",re=Wm(oe),Se=$.length>2?$[$.length-1]==="```"?$.slice(1,-1):$.slice(1):[y.slice(3).replace(/```$/,"")],Ie=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",ve=Z?`${Ie} has-filename`:Ie,_e=re!=="all",P=Se.map((R,S)=>{const C=S+1,G=re==="all"||re.has(C)?"code-line shiki-focus":_e?"code-line shiki-dimmed":"code-line";let Y=(t==null?void 0:t.highlight)===!0?vl(R,te):st(R);return ce&&R.includes("doubled.value = 2")?(Y=Y.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${G}"><span class="line-no">${C}</span><span class="line-content">${Y}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${G}"><span class="line-no">${C}</span><span class="line-content">${Y}</span></span>`}).join(`
`),ie=te?`<span class="lang-badge">${st(te)}</span>`:"",E=Z?`<span class="code-filename">${st(Z)}</span>`:"",F=((j=e.attrs)==null?void 0:j["custom-slides-max-height"])||((B=e.attributes)==null?void 0:B["custom-slides-max-height"])||e.maxHeight||"",v=Rs(String(F||"")),U=v?` style="max-height:${st(v)};overflow-y:auto;"`:"";return`<div class="${h}"${i}><pre class="${ve}"${U}>${E}${ie}<code>${P}</code></pre></div>`}if(y.includes("|")&&y.split(`
`).filter($=>$.trim().startsWith("|")).length>=2){const $=y.split(`
`).filter(O=>O.trim().startsWith("|")),T=Vm($,t==null?void 0:t.tableClassName);return`<div class="${h}"${i}>${T}</div>`}if(y.startsWith("> ")){const $=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${h}"${i}><blockquote class="${$}"><p>${dt(y.slice(2))}</p></blockquote></div>`}const f=/<video\b/i.test(y)||e.type==="video"||e.type==="NodeVideo",p=/^(\s*)([-*+]|\d+\.)\s+/m.test(y),g=/(?:^|\n)\s*#{1,6}\s+/.test(y);if(f&&!p&&!g&&!y.includes(`
`)){const $=((D=e.attributes)==null?void 0:D["custom-slides-autoplay"])==="true"||/autoplay/i.test(y),T=((x=e.attributes)==null?void 0:x["custom-slides-loop"])==="true"||/loop/i.test(y),O=((V=e.attributes)==null?void 0:V["custom-slides-muted"])==="true"||$||/muted/i.test(y),te=((W=e.attributes)==null?void 0:W["custom-slides-controls"])==="false",K=y.match(/\bsrc=["']([^"']+)["']/i),Z=K?K[1]:"",ce=['class="slide-video-player"'];te||ce.push("controls"),$&&(ce.push("autoplay"),ce.push("playsinline")),T&&ce.push("loop"),O&&ce.push("muted"),ce.push('preload="auto"'),Z&&ce.push(`src="${Z}"`);const oe=y.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let re=oe?oe[1].trim():"";return!re&&Z&&(re=`<source src="${Z}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${h} ${h}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${$?"true":"false"}" data-muted="${O?"true":"false"}"${i}><video ${ce.join(" ")}>${re}</video></div>`}const b=y.match(/^!\[(.*?)\]\((.*?)\)$/);if(b){const $=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${h} ${h}--image slide-media-block slide-media-container"${i}><img alt="${st(b[1])}" src="${b[2]}" class="${$}" /></div>`}const k=ec(y,t,e);if(k)return`<div class="${h} pdf-list-item"${i}>${k}</div>`;if(/<(?:Toc|toc)\b/i.test(y)&&!y.startsWith("```")){const $=y.match(/minDepth=["']?(\d+)["']?/i),T=y.match(/maxDepth=["']?(\d+)["']?/i),O=y.match(/columns=["']?(\d+)["']?/i),te=(t==null?void 0:t.allSlides)||[];return`<div class="${h}"${i}>${Km(te,(t==null?void 0:t.currentPageIndex)||1,{minDepth:$?parseInt($[1],10):1,maxDepth:T?parseInt(T[1],10):1/0,columns:O?parseInt(O[1],10):1,textSm:y.includes("text-sm")})}</div>`}if(y.includes(`
`)||g){const $=jm(y,t,e);if($)return`<div class="${h}"${i}>${$}</div>`}const _=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${h}"${i}><p${_}>${dt(y)}</p></div>`}function Ym(e){return`
    ${Fi(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default (Modern Tech / Digital Geek) */
    [data-slides-theme="tech"],
    .slides-theme-tech {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
      --slide-accent-secondary: #06b6d4;
    }
    [data-theme="light"][data-slides-theme="tech"],
    [data-theme="light"] .slides-theme-tech,
    .slide-viewport[data-theme="light"].slides-theme-tech,
    .slide-viewport[data-theme="light"] {
      --slide-bg: #f8fafc;
      --slide-text: #0f172a;
      --slide-text-secondary: #475569;
      --slide-code-bg: #f1f5f9;
      --slide-code-border: rgba(15, 23, 42, 0.12);
      --slide-accent: #059669;
      --slide-accent-secondary: #0284c7;
      --slide-card-bg: rgba(255, 255, 255, 0.85);
      --slide-card-border: rgba(148, 163, 184, 0.35);
      --slide-card-shadow: 0 4px 14px rgba(15, 23, 42, 0.06);
    }
    [data-theme="dark"][data-slides-theme="tech"],
    [data-theme="dark"] .slides-theme-tech,
    .slide-viewport[data-theme="dark"].slides-theme-tech,
    .slide-viewport:not([data-theme="light"]) {
      --slide-bg: #090d16;
      --slide-text: #f1f5f9;
      --slide-text-secondary: #94a3b8;
      --slide-code-bg: #0f172a;
      --slide-code-border: rgba(56, 189, 248, 0.22);
      --slide-accent: #10b981;
      --slide-accent-secondary: #38bdf8;
      --slide-card-bg: rgba(15, 23, 42, 0.7);
      --slide-card-border: rgba(56, 189, 248, 0.2);
      --slide-card-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
    }
    /* 单页为 light 时高特异性覆盖，即使外层是 dark 也强制生效 */
    [data-theme="dark"] .slide-viewport[data-theme="light"],
    .slide-viewport[data-theme="light"] {
      color: var(--slide-text) !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-tech,
    .slide-viewport[data-theme="light"].slides-theme-tech {
      --slide-text: #0f172a !important;
      --slide-text-secondary: #475569 !important;
      --slide-accent: #059669 !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-seriph,
    .slide-viewport[data-theme="light"].slides-theme-seriph {
      --slide-text: #231f1d !important;
      --slide-text-secondary: #57534e !important;
      --slide-accent: #b45309 !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-apple-basic,
    .slide-viewport[data-theme="light"].slides-theme-apple-basic {
      --slide-text: #000000 !important;
      --slide-text-secondary: #6e6e73 !important;
      --slide-accent: #0071e3 !important;
    }
    /* 单页为 dark 时高特异性覆盖，即使外层是 light 也强制生效 */
    [data-theme="light"] .slide-viewport[data-theme="dark"],
    .slide-viewport[data-theme="dark"] {
      color: var(--slide-text) !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-tech,
    .slide-viewport[data-theme="dark"].slides-theme-tech {
      --slide-text: #f1f5f9 !important;
      --slide-text-secondary: #94a3b8 !important;
      --slide-accent: #10b981 !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-seriph,
    .slide-viewport[data-theme="dark"].slides-theme-seriph {
      --slide-text: #f5f2eb !important;
      --slide-text-secondary: #a8a29e !important;
      --slide-accent: #f59e0b !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-apple-basic,
    .slide-viewport[data-theme="dark"].slides-theme-apple-basic {
      --slide-text: #ffffff !important;
      --slide-text-secondary: #86868b !important;
      --slide-accent: #2997ff !important;
    }
    .slides-theme-tech .layout-cover h1,
    .slides-theme-tech .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, var(--slide-accent), var(--slide-accent-secondary)) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slides-theme-tech .layout-cover h2,
    .slides-theme-tech .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      color: var(--slide-text-secondary) !important;
      margin-bottom: 12px !important;
    }
    .slides-theme-tech .layout-cover p,
    .slides-theme-tech .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      color: var(--slide-text-secondary) !important;
    }
    /* 默认科技风：内容页顶部标题带 Accent 垂直指示条与柔和横向高亮底衬 */
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      color: var(--slide-accent);
      border-left: 4px solid var(--slide-accent);
      padding: 4px 14px;
      padding-left: 14px;
      background: linear-gradient(90deg, color-mix(in srgb, var(--slide-accent) 13%, transparent), transparent 76%);
      border-radius: 0 6px 6px 0;
      letter-spacing: -0.015em;
    }
    .slides-theme-tech blockquote {
      border-left: 3px solid var(--slide-accent) !important;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent) !important;
      border-radius: 4px;
      padding: 12px 18px !important;
    }
    .slides-theme-tech pre {
      border: 1px solid var(--slide-code-border) !important;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.18) !important;
      border-radius: 8px !important;
    }

    /* 2. 优雅衬线主题 Seriph (典雅学术书卷风) */
    [data-slides-theme="seriph"],
    .slides-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      --slide-accent-secondary: #9a3412;
      letter-spacing: 0.02em;
    }
    [data-theme="light"][data-slides-theme="seriph"],
    [data-theme="light"] .slides-theme-seriph {
      --slide-bg: #fcfbf7;
      --slide-text: #231f1d;
      --slide-text-secondary: #57534e;
      --slide-code-bg: #f5f0e6;
      --slide-code-border: rgba(180, 83, 9, 0.2);
      --slide-accent: #b45309;
      --slide-accent-secondary: #9a3412;
      --slide-card-bg: rgba(255, 255, 255, 0.75);
      --slide-card-border: rgba(180, 83, 9, 0.25);
      --slide-card-shadow: 0 2px 10px rgba(41, 37, 36, 0.04);
    }
    [data-theme="dark"][data-slides-theme="seriph"],
    [data-theme="dark"] .slides-theme-seriph {
      --slide-bg: #171513;
      --slide-text: #f5f2eb;
      --slide-text-secondary: #a8a29e;
      --slide-code-bg: #24201c;
      --slide-code-border: rgba(245, 158, 11, 0.22);
      --slide-accent: #f59e0b;
      --slide-accent-secondary: #fb923c;
      --slide-card-bg: rgba(32, 28, 24, 0.8);
      --slide-card-border: rgba(245, 158, 11, 0.22);
      --slide-card-shadow: 0 4px 16px rgba(0, 0, 0, 0.4);
    }
    .slides-theme-seriph,
    .slides-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.75;
    }
    .slides-theme-seriph h1,
    .slides-theme-seriph h2,
    .slides-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slides-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      font-weight: 700 !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
      margin-bottom: 24px;
    }
    .slides-theme-seriph .layout-cover p {
      font-style: italic;
      color: var(--slide-text-secondary);
    }
    /* 优雅衬线风：内容页顶部标题学术双线眉批 */
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      display: block;
      position: relative;
      color: var(--slide-accent);
      border-bottom: 1.5px solid color-mix(in srgb, var(--slide-accent) 45%, transparent);
      padding-bottom: 10px;
      margin-bottom: 14px;
    }
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3::after {
      content: "";
      position: absolute;
      left: 0;
      right: 0;
      bottom: 3px;
      height: 1.5px;
      pointer-events: none;
      background: linear-gradient(90deg, var(--slide-accent) 0%, color-mix(in srgb, var(--slide-accent) 35%, transparent) 50%, transparent 92%);
    }
    .slides-theme-seriph blockquote {
      position: relative;
      font-style: italic;
      border-left: 2px solid var(--slide-accent) !important;
      background: color-mix(in srgb, var(--slide-accent) 6%, transparent) !important;
      padding: 14px 20px 14px 28px !important;
      border-radius: 4px;
      margin: 12px 0 !important;
    }
    .slides-theme-seriph blockquote::before {
      content: "“";
      position: absolute;
      left: 8px;
      top: 6px;
      font-size: 2rem;
      line-height: 1;
      color: var(--slide-accent);
      opacity: 0.6;
      font-family: Georgia, serif;
    }
    .slides-theme-seriph pre {
      border: 1px solid var(--slide-code-border) !important;
      border-radius: 4px !important;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08) !important;
    }

    /* 3. 极简发布会主题 Apple Basic (苹果 Keynote / 瑞士纯粹主义) */
    [data-slides-theme="apple-basic"],
    .slides-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
      --slide-accent-secondary: #0077ed;
      letter-spacing: -0.025em;
    }
    [data-theme="light"][data-slides-theme="apple-basic"],
    [data-theme="light"] .slides-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #000000;
      --slide-text-secondary: #6e6e73;
      --slide-code-bg: #f5f5f7;
      --slide-code-border: transparent;
      --slide-accent: #0071e3;
      --slide-accent-secondary: #0077ed;
      --slide-card-bg: #f5f5f7;
      --slide-card-border: transparent;
      --slide-card-shadow: none;
    }
    [data-theme="dark"][data-slides-theme="apple-basic"],
    [data-theme="dark"] .slides-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #ffffff;
      --slide-text-secondary: #86868b;
      --slide-code-bg: #161617;
      --slide-code-border: transparent;
      --slide-accent: #2997ff;
      --slide-accent-secondary: #64d2ff;
      --slide-card-bg: #161617;
      --slide-card-border: transparent;
      --slide-card-shadow: none;
    }
    .slides-theme-apple-basic,
    .slides-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slides-theme-apple-basic h1,
    .slides-theme-apple-basic h2,
    .slides-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slides-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 4rem !important;
      font-weight: 800 !important;
      letter-spacing: -0.045em !important;
      margin-bottom: 12px;
    }
    .slides-theme-apple-basic .layout-cover p {
      color: var(--slide-text-secondary) !important;
      font-size: 1.35rem !important;
      font-weight: 500 !important;
      opacity: 1 !important;
    }
    /* 极简发布会风：彻底去装饰化，高字重、紧凑字距与充沛留白 */
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      border: none !important;
      background: none !important;
      padding: 0 !important;
      margin-bottom: 16px !important;
      letter-spacing: -0.04em !important;
      font-weight: 800 !important;
    }
    .slides-theme-apple-basic pre {
      border-radius: 16px !important;
      border: none !important;
      background: var(--slide-code-bg) !important;
      box-shadow: none !important;
    }
    .slides-theme-apple-basic blockquote {
      border-left: none !important;
      background: var(--slide-card-bg) !important;
      border-radius: 14px !important;
      padding: 18px 24px !important;
      font-size: 1.15rem !important;
      color: var(--slide-text) !important;
    }

    /* 复杂背景防穿透文字保护 (Text Scrim & Backdrop Protection) */
    .slide-viewport[style*="background-image"] .slide-content h1,
    .slide-viewport[style*="background-image"] .slide-content h2,
    .slide-viewport[style*="background-image"] .slide-content h3,
    .slide-viewport[style*="background-image"] .slide-content p,
    .slide-viewport[style*="background-image"] .slide-content li {
      text-shadow: 0 1px 3px rgba(0, 0, 0, 0.75), 0 2px 8px rgba(0, 0, 0, 0.45);
    }
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h1,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h2,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h3,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content p,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content li {
      text-shadow: 0 1px 3px rgba(255, 255, 255, 0.85);
    }
    .slide-viewport[style*="background-image"] .layout-cols-grid > div,
    .slide-viewport[style*="background-image"] .layout-two-cols-grid > div,
    .slide-viewport[style*="background-image"] .layout-three-cols-grid > div,
    .slide-viewport[style*="background-image"] .two-cols-left,
    .slide-viewport[style*="background-image"] .two-cols-right,
    .slide-viewport[style*="background-image"] .pdf-col {
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
    }

    /* 封面页在背景图或显式设置文字颜色时，禁用透明渐变镂空，避免与 text-shadow 叠加成浮雕黑芯并遵循主题及实际文字色 */
    .slide-viewport[style*="background-image"] .layout-cover h1,
    .slide-viewport[style*="background-image"] .layout-cover .slide-block h1,
    .slides-overview-canvas[style*="background-image"].layout-cover h1,
    .slides-overview-canvas[style*="background-image"].layout-cover .slide-block h1,
    .slides-overview-canvas[style*="background-image"] .layout-cover h1,
    .slides-overview-canvas[style*="background-image"] .layout-cover .slide-block h1,
    .slides-theme-tech .layout-cover .slide-block[style^="color:"] h1,
    .slides-theme-tech .layout-cover .slide-block[style*=" color:"] h1,
    .slides-theme-tech .layout-cover .slide-block[style*=";color:"] h1,
    .slides-theme-tech .layout-cover h1[style^="color:"],
    .slides-theme-tech .layout-cover h1[style*=" color:"],
    .slides-theme-tech .layout-cover h1[style*=";color:"] {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
    }
    .layout-cover h1 span[style^="color:"],
    .layout-cover h1 span[style*=" color:"],
    .layout-cover h1 span[style*=";color:"],
    .layout-cover h1 font[color] {
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: currentColor !important;
    }
    /* 当内容页存在背景图时，顶部标题回退至高对比正文字色并配合局部半透明底衬，同时保留主题装饰 */
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      color: var(--slide-text);
    }
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      background: linear-gradient(90deg, color-mix(in srgb, var(--slide-bg) 42%, transparent), transparent 82%);
    }
    /* 用户显式块级前景色优先于主题及背景图默认回退色 */
    .slide-viewport .slide-block[style^="color:"] h1,
    .slide-viewport .slide-block[style*=" color:"] h1,
    .slide-viewport .slide-block[style*=";color:"] h1,
    .slide-viewport .slide-block[style^="color:"] h2,
    .slide-viewport .slide-block[style*=" color:"] h2,
    .slide-viewport .slide-block[style*=";color:"] h2,
    .slide-viewport .slide-block[style^="color:"] h3,
    .slide-viewport .slide-block[style*=" color:"] h3,
    .slide-viewport .slide-block[style*=";color:"] h3 {
      color: inherit !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slides-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
      container-type: size;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slides-spacing="compact"] {
      --slides-padding-y: 16px;
      --slides-padding-x: 28px;
      --slides-block-gap: 8px;
      --slides-list-gap: 4px;
      --slides-cols-gap: 20px;
      --slides-title-margin-bottom: 8px;
      --slides-header-gap: 10px;
      --slides-line-height: 1.45;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slides-spacing="normal"] {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-block-gap: 14px;
      --slides-list-gap: 6px;
      --slides-cols-gap: 32px;
      --slides-title-margin-bottom: 12px;
      --slides-header-gap: 16px;
      --slides-line-height: 1.6;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slides-spacing="loose"] {
      --slides-padding-y: 52px;
      --slides-padding-x: 72px;
      --slides-block-gap: 22px;
      --slides-list-gap: 10px;
      --slides-cols-gap: 44px;
      --slides-title-margin-bottom: 18px;
      --slides-header-gap: 24px;
      --slides-line-height: 1.75;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: var(--slides-cols-gap, 32px);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.75);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.625);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: var(--slides-block-gap, 14px);
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: var(--slides-block-gap, 14px); line-height: var(--slides-line-height, 1.6); }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: var(--slides-title-margin-bottom, 12px); }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: calc(var(--slides-title-margin-bottom, 10px) * 0.85); }
    .slide-block p { font-size: 1.15rem; line-height: var(--slides-line-height, 1.6); }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: calc(var(--slides-block-gap, 14px) * 0.6) 0;
      display: flex;
      flex-direction: column;
      gap: var(--slides-list-gap, 6px);
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: var(--slides-line-height, 1.6);
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: var(--slides-list-gap, 6px) !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: var(--slides-line-height, 1.6) !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slides-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slides-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slides-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slides-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
      user-select: none;
      -webkit-user-drag: none;
      touch-action: none;
    }
    .slides-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slides-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slides-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidesMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidesMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidesMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slides-motion-fade-in { animation: slidesMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-up { animation: slidesMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-down { animation: slidesMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-left { animation: slidesMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-right { animation: slidesMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-zoom-in, .slides-motion-pop { animation: slidesMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slides-motion-bounce { animation: slidesMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slides-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    a.slides-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    a.slides-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slides-ref-tag:hover, a.slides-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slides-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slides-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slides-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slides-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-left: var(--slides-padding-x, 48px) !important;
      padding-right: var(--slides-padding-x, 48px) !important;
      padding-bottom: var(--slides-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slides-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slides-mask-body-container--has-mask:first-child,
    .slide-content > .slides-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-top: var(--slides-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slides-padding-x: 0px !important;
      --slides-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slides-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slides-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slides-mask-layer--solid .slides-mask-overlay,
    .slides-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slides-mask-layer--solid .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slides-mask-layer--blur .slides-mask-overlay,
    .slides-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slides-mask-layer--blur .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slides-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slides-mask-layer--down .slides-mask-divider-line,
    .slides-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--right .slides-mask-divider-line,
    .slides-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--clockwise,
    .slides-mask-layer--counter-clockwise,
    .slides-mask-layer--cw,
    .slides-mask-layer--ccw,
    .slides-mask-layer--clock {
      transform: none !important;
    }
    .slides-mask-layer--clockwise .slides-mask-divider-line,
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-layer--cw .slides-mask-divider-line,
    .slides-mask-layer--ccw .slides-mask-divider-line,
    .slides-mask-layer--clock .slides-mask-divider-line,
    .slides-mask-divider-line--clock,
    .slides-mask-divider-line--clockwise,
    .slides-mask-divider-line--counter-clockwise {
      top: 50%;
      left: 50%;
      right: auto;
      bottom: auto;
      width: 55%;
      height: 2.5px;
      transform-origin: 0% 50%;
      transform: translateY(-50%) rotate(-180deg);
      background: linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1), opacity 0.3s ease;
      will-change: transform, opacity;
    }
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-divider-line--counter-clockwise {
      transform: translateY(-50%) rotate(-90deg);
    }`}function Zm(){return`    (function() {
      const data = window.__SLIDES_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function Jm(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slides-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slides-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slides-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slides-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slides-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slides-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slides-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slides-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slides-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slides-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slides-overview-canvas *{scrollbar-width:none;}.slides-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slides-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slides-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slides-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slides-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function Xm(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slides-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr, defaultSteps) {
        var defSteps = (defaultSteps === 4) ? 4 : 2;
        var defBps = (defaultSteps === 4) ? [25, 50, 75, 100] : [50, 100];
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: defSteps, breakpoints: defBps };
        }
        var clean = ratioStr.trim();
        if (!clean || (defaultSteps === 4 && (clean === "1:1" || clean === "1"))) return { steps: defSteps, breakpoints: defBps };
        var parts = clean.split(":").map(function(p) { return parseFloat(p.trim()); }).filter(function(n) { return !isNaN(n) && n > 0; });
        if (parts.length === 0) return { steps: defSteps, breakpoints: defBps };
        if (parts.length === 1) {
          var val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        var isMonotonic = parts.every(function(val, idx) { return idx === 0 || val > parts[idx - 1]; });
        var maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(function(p) { return p > 10; }))) {
          var bps = parts.map(function(p) { return Math.min(100, Math.round(p * 100) / 100); });
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        var totalWeight = parts.reduce(function(acc, cur) { return acc + cur; }, 0);
        if (totalWeight <= 0) return { steps: defSteps, breakpoints: defBps };
        var accumulated = 0;
        var bps = [];
        for (var i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        if (currentMaskConfig.isClock) {
          const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
          const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360));
          const needleAngle = isCw ? (-180 + sweepDeg) : (-90 - sweepDeg);

          if (maskOverlayEl) {
            let maskGrad = "";
            if (sweepDeg <= 0) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)";
            } else if (sweepDeg >= 360) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)";
            } else if (isCw) {
              maskGrad = "conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent " + sweepDeg + "deg, #000 " + sweepDeg + "deg, #000 360deg)";
            } else {
              const remDeg = 360 - sweepDeg;
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 " + remDeg + "deg, transparent " + remDeg + "deg, transparent 360deg)";
            }
            maskOverlayEl.style.webkitMaskImage = maskGrad;
            maskOverlayEl.style.maskImage = maskGrad;
          }

          if (maskDividerEl) {
            maskDividerEl.style.transform = "translateY(-50%) rotate(" + needleAngle + "deg)";
            maskDividerEl.style.opacity = (p <= 0 || p >= 100) ? "0" : "1";
          }

          if (p >= 100) {
            maskLayerEl.style.opacity = "0";
            maskLayerEl.style.pointerEvents = "none";
          } else {
            maskLayerEl.style.opacity = "1";
            maskLayerEl.style.pointerEvents = "none";
          }
          return;
        }

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        // FSM-9 优化：回退至上一页时传递 backward 方向，使上一页遮罩处于完全展开状态
        renderSlide(currentIndex - 1, "backward");
      }

`}function Qm(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ \\t]*[-*+]\\s+|^[ \\t]*\\d+\\.\\s+/, "");
        cleaned = cleaned.replace(/\\n[ \\t]{2,4}/g, "\\n");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}\\s+/.test(md)) return true;
        if (/^(?:[-*+]|\\d+\\.)\\s+#{1,6}\\s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|\\d+\\.)\\s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slides-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slides-block-ref"') || md.includes('class="slides-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const allInteractive = div.querySelectorAll("*");
          allInteractive.forEach(btn => {
            let hasNext = false;
            let hasPrev = false;
            for (let i = 0; i < btn.attributes.length; i++) {
              const a = btn.attributes[i];
              const attrName = a.name.toLowerCase();
              if (attrName.indexOf("@click") !== -1 || attrName.indexOf("v-on:click") !== -1) {
                if (a.value.indexOf("next") !== -1) hasNext = true;
                if (a.value.indexOf("prev") !== -1) hasPrev = true;
              }
            }
            if (hasNext) {
              btn.style.cursor = "pointer";
              btn.addEventListener("click", (e) => {
                e.stopPropagation();
                renderSlide(currentIndex + 1);
              });
            } else if (hasPrev) {
              btn.style.cursor = "pointer";
              btn.addEventListener("click", (e) => {
                e.stopPropagation();
                renderSlide(currentIndex - 1);
              });
            }
          });

          return div;
        }

        const hasHeadingTag = /(?:^|\\n)\\s*#{1,6}\\s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\\x60\\x60\\x60")) {
          var rawMaxH = block?.attributes?.["custom-slides-max-height"] || block?.attrs?.["custom-slides-max-height"] || block?.maxHeight || "";
          var customMaxHeight = "";
          if (rawMaxH) {
            var sMaxH = String(rawMaxH).trim();
            if (/^\\d+$/.test(sMaxH)) customMaxHeight = sMaxH + "px";
            else if (/^(\\d+(?:\\.\\d+)?)%$/.test(sMaxH)) customMaxHeight = sMaxH.replace("%", "cqh");
            else if (/^(\\d+(?:\\.\\d+)?)vh$/.test(sMaxH)) customMaxHeight = sMaxH.replace("vh", "cqh");
            else customMaxHeight = sMaxH;
          }
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(\\s*)([-*+]|\\d+\\.)\\s+/m.test(md) && !hasHeadingTag && !md.includes("\\n")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (
          /^(\\s*)([-*+]|\\d+\\.)\\s+/m.test(md) ||
          (md.includes("\\n") && /^(\\s*)([-*+]|\\d+\\.)\\s+/m.test(md.split("\\n").slice(1).join("\\n"))) ||
          ((block && (block.isListItem || block.type === "i")) && !block.isColFirst)
        ) {
          div.classList.add("pdf-list-item");
          const lines = md.split("\\n");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^\\{:.*?\\}$/.test(tr)) continue;
            const um = line.match(/^(\\s*)[-*+]\\s+(.*)$/);
            const om = line.match(/^(\\s*)\\d+\\.\\s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^!\\[(.*?)\\]\\((.*?)\\)(?:\\{:?[^}]*\\})?$/);
              if (im) {
                const isGif = /\\.gif(?:\\?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\\b[\\s\\S]*?\\/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/\\s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\\b/i.test(tr)) {
                let vHtml = tr;
                if (!/<\\/video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/<\\/video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "\\n" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          if (items.length === 0 && (block && (block.isListItem || block.type === "i")) && !block.isColFirst) {
            items.push({ type: "unordered", level: 0, text: md, media: [] });
            leadLines.length = 0;
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})\\s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})\\s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("\\n") + "\\n";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "\\n" + it.media.join("\\n") : "";
            const lines = (it.text || "").split("\\n").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}\\s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})\\s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("\\n") + med + '</li>';
          }).join("\\n");
          div.innerHTML = leadHtml + '<' + tag + ' class="' + listCls + '">\\n' + liHtml + '\\n</' + tag + '>';
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\\r?\\n/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}\\s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              continue;
            }
            if (/^!\\[.*?\\]\\(.*?\\)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              let vRaw = trimmed;
              if (!/<\\/video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/<\\/video>/i.test(vRaw)) {
                  i++;
                  vRaw += "\\n" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("\\n"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}\\s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})\\s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^!\\[(.*?)\\]\\((.*?)\\)$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\\r?\\n/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>\\n<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("\\n");
          } else {
            const imgMatch = md.match(/^!\\[(.*?)\\]\\((.*?)\\)$/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }
`}function eg(){return`      function renderSlide(idx, direction) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        function isLightColor(colorStr) {
          if (!colorStr || typeof colorStr !== 'string') return null;
          const s = colorStr.trim().toLowerCase();
          if (!s) return null;
          if (/^(?:https?:\\/\\/|\\/|data:|assets\\/|\\.\\/assets\\/|url\\s*\\()/i.test(s)) return null;
          const lightNamed = ['white', 'snow', 'ivory', 'ghostwhite', 'floralwhite', 'aliceblue', 'whitesmoke', 'seashell', 'beige', 'oldlace', 'linen', 'antiquewhite', 'lightyellow', 'lightcyan', 'papayawhip', 'blanchedalmond', 'cornsilk', 'lavender', 'lavenderblush', 'lemonchiffon', 'honeydew', 'mintcream', 'azure', 'mistyrose', 'wheat', 'lightgoldenrodyellow', 'palegoldenrod', 'gainsboro', 'lightgrey', 'lightgray', 'silver', 'pink', 'lightpink', 'peachpuff', 'navajowhite', 'moccasin', 'bisque', 'khaki', 'palegreen', 'lightgreen', 'lightblue', 'powderblue', 'paleturquoise', 'lightsteelblue', 'thistle', 'yellow', 'cyan', 'aqua'];
          const darkNamed = ['black', 'transparent', 'navy', 'darkblue', 'midnightblue', 'darkslategray', 'darkslategrey', 'maroon', 'darkred', 'darkgreen', 'indigo', 'darkslateblue', 'dimgray', 'dimgrey', 'purple', 'brown', 'olive', 'teal', 'blue', 'darkviolet', 'darkmagenta', 'darkcyan', 'darkolivegreen', 'saddlebrown', 'sienna', 'firebrick', 'crimson', 'mediumblue', 'rebeccapurple'];
          if (lightNamed.includes(s)) return true;
          if (darkNamed.includes(s)) return false;

          function calcLum(r, g, b) {
            return 0.299 * r + 0.587 * g + 0.114 * b;
          }
          function parseHexLum(hexRaw) {
            let hex = hexRaw.startsWith('#') ? hexRaw.slice(1) : hexRaw;
            if (hex.length === 3 || hex.length === 4) hex = hex.slice(0, 3).split('').map(c => c + c).join('');
            if (hex.length >= 6) {
              const r = parseInt(hex.substring(0, 2), 16);
              const g = parseInt(hex.substring(2, 4), 16);
              const b = parseInt(hex.substring(4, 6), 16);
              if (!isNaN(r) && !isNaN(g) && !isNaN(b)) return calcLum(r, g, b);
            }
            return null;
          }
          function parseRgbLum(rgbStr) {
            const m = rgbStr.match(/rgba?\\s*\\(\\s*(\\d+(?:\\.\\d+)?)\\s*[,\\s]\\s*(\\d+(?:\\.\\d+)?)\\s*[,\\s]\\s*(\\d+(?:\\.\\d+)?)(?:\\s*[,\\/]\\s*([0-9.]+%?))?/i);
            if (!m) return null;
            const r = Number(m[1]), g = Number(m[2]), b = Number(m[3]);
            if (isNaN(r) || isNaN(g) || isNaN(b)) return null;
            if (m[4] !== undefined) {
              const a = m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
              if (!isNaN(a) && a <= 0.05) return null;
            }
            return calcLum(r, g, b);
          }
          function parseHslLum(hslStr) {
            const m = hslStr.match(/hsla?\\s*\\(\\s*([0-9.]+)(?:deg)?\\s*[,\\s]\\s*([0-9.]+)%\\s*[,\\s]\\s*([0-9.]+)%(?:\\s*[,\\/]\\s*([0-9.]+%?))?/i);
            if (!m) return null;
            if (m[4] !== undefined) {
              const a = m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
              if (!isNaN(a) && a <= 0.05) return null;
            }
            const h = (((Number(m[1]) % 360) + 360) % 360) / 360;
            const sat = Math.max(0, Math.min(1, Number(m[2]) / 100));
            const lig = Math.max(0, Math.min(1, Number(m[3]) / 100));
            let r, g, b;
            if (sat === 0) {
              r = g = b = lig * 255;
            } else {
              const q = lig < 0.5 ? lig * (1 + sat) : lig + sat - lig * sat;
              const p = 2 * lig - q;
              const hue2rgb = (t) => {
                let tt = t;
                if (tt < 0) tt += 1;
                if (tt > 1) tt -= 1;
                if (tt < 1 / 6) return p + (q - p) * 6 * tt;
                if (tt < 1 / 2) return q;
                if (tt < 2 / 3) return p + (q - p) * (2 / 3 - tt) * 6;
                return p;
              };
              r = hue2rgb(h + 1 / 3) * 255;
              g = hue2rgb(h) * 255;
              b = hue2rgb(h - 1 / 3) * 255;
            }
            return calcLum(r, g, b);
          }

          if (s.startsWith('#')) {
            const lum = parseHexLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/^rgba?\\s*\\(/i.test(s)) {
            const lum = parseRgbLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/^hsla?\\s*\\(/i.test(s)) {
            const lum = parseHslLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/(?:linear|radial|conic)-gradient\\s*\\(/i.test(s)) {
            const luminances = [];
            const hexMatches = s.match(/#(?:[0-9a-f]{8}|[0-9a-f]{6}|[0-9a-f]{4}|[0-9a-f]{3})\\b/gi);
            if (hexMatches) {
              for (const h of hexMatches) {
                const lum = parseHexLum(h);
                if (lum !== null) luminances.push(lum);
              }
            }
            const rgbMatches = s.match(/rgba?\\s*\\([^)]+\\)/gi);
            if (rgbMatches) {
              for (const r of rgbMatches) {
                const lum = parseRgbLum(r);
                if (lum !== null) luminances.push(lum);
              }
            }
            const hslMatches = s.match(/hsla?\\s*\\([^)]+\\)/gi);
            if (hslMatches) {
              for (const h of hslMatches) {
                const lum = parseHslLum(h);
                if (lum !== null) luminances.push(lum);
              }
            }
            const stripped = s.replace(/#[0-9a-f]+|rgba?\\([^)]+\\)|hsla?\\([^)]+\\)/gi, ' ');
            const wordMatches = stripped.match(/\\b[a-z]+\\b/gi);
            if (wordMatches) {
              for (const w of wordMatches) {
                if (w === 'transparent') continue;
                if (lightNamed.includes(w)) luminances.push(240);
                else if (darkNamed.includes(w)) luminances.push(20);
              }
            }
            if (luminances.length > 0) {
              const avg = luminances.reduce((acc, v) => acc + v, 0) / luminances.length;
              return avg > 140;
            }
            if (/\\btransparent\\b/.test(s)) return false;
          }
          return null;
        }

        const slideBg = slide.frontmatter?.background || (data.config && data.config.background);
        const isLightBg = isLightColor(slideBg);
        const curTheme = data.config?.theme || "default";
        if (slideBg) {
          if (/^(http|\\/|data:|assets\\/)/.test(slideBg)) {
            container.style.backgroundImage = 'url("' + slideBg + '")';
            container.style.backgroundSize = "cover";
            container.style.backgroundPosition = "center";
          } else {
            container.style.backgroundImage = "none";
            container.style.background = slideBg;
          }
        } else {
          container.style.backgroundImage = "none";
          container.style.background = "";
        }
        if (isLightBg === true) {
          if (viewport) viewport.setAttribute("data-theme", "light");
          const textColor = curTheme === "apple-basic" ? "#000000" : (curTheme === "seriph" ? "#231f1d" : "#0f172a");
          container.style.color = textColor;
          container.style.setProperty("--slide-text", textColor);
        } else if (isLightBg === false) {
          if (viewport) viewport.setAttribute("data-theme", "dark");
          const textColor = curTheme === "apple-basic" ? "#ffffff" : (curTheme === "seriph" ? "#f5f2eb" : "#f1f5f9");
          container.style.color = textColor;
          container.style.setProperty("--slide-text", textColor);
        } else {
          const fallbackSchema = (data.config?.colorSchema === "light" || data.config?.colorSchema === "dark")
            ? data.config.colorSchema
            : (data.config?.hostThemeMode || null);
          if (viewport) {
            if (fallbackSchema === "light" || fallbackSchema === "dark") {
              viewport.setAttribute("data-theme", fallbackSchema);
            } else {
              viewport.removeAttribute("data-theme");
            }
          }
          container.style.color = "";
          container.style.removeProperty("--slide-text");
        }

        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        const isClock = maskDir === "clockwise" || maskDir === "counter-clockwise" || maskDir === "cw" || maskDir === "ccw";
        if (maskDir === "down" || maskDir === "right" || isClock) {
          const isClover = slide.frontmatter?.layout === "clover";
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio, (isClock || isClover) ? 4 : 2);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: isClock ? ((maskDir === "cw" || maskDir === "clockwise") ? "clockwise" : "counter-clockwise") : maskDir,
            isClock: isClock,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          // FSM-9 优化：后退进入历史页时，遮罩与逐步呈现处于全部揭开完成状态，避免上一页重新变为全黑遮盖
          currentMaskStep = (direction === "backward") ? currentMaskConfig.totalSteps : 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slides-mask-layer slides-mask-layer--" + currentMaskConfig.style + " slides-mask-layer--" + currentMaskConfig.direction + (currentMaskConfig.isClock ? " slides-mask-layer--clock" : "");
          const overlay = document.createElement("div");
          overlay.className = "slides-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slides-mask-divider-line" + (currentMaskConfig.isClock ? " slides-mask-divider-line--clock" : "");
          divider.style.opacity = "0";
          if (currentMaskConfig.isClock) {
            const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
            divider.style.transform = isCw ? "translateY(-50%) rotate(-180deg)" : "translateY(-50%) rotate(-90deg)";
          }
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slides-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slides-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slides-mask-body-container slides-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slides-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slides-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slides-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function tg(){return`      let lightboxScale = 1.0;
      let lightboxTranslateX = 0;
      let lightboxTranslateY = 0;
      let isLightboxDragging = false;
      let lightboxDragStartX = 0;
      let lightboxDragStartY = 0;
      let lightboxInitialTx = 0;
      let lightboxInitialTy = 0;
      let lightboxHasMoved = false;
      let lightboxMediaType = "";

      function updateLightboxImgTransform(animate) {
        if (!lightboxContent) return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        img.style.transformOrigin = "center center";
        img.style.transform = "translate(" + lightboxTranslateX + "px, " + lightboxTranslateY + "px) scale(" + lightboxScale + ")";
        img.style.transition = animate ? "transform 0.12s cubic-bezier(0.16, 1, 0.3, 1)" : "none";
        img.style.cursor = lightboxScale > 1.0 ? (isLightboxDragging ? "grabbing" : "grab") : "zoom-in";
      }

      function resetLightboxZoom() {
        lightboxScale = 1.0;
        lightboxTranslateX = 0;
        lightboxTranslateY = 0;
        isLightboxDragging = false;
        lightboxHasMoved = false;
        updateLightboxImgTransform(false);
      }

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        lightboxMediaType = type;
        resetLightboxZoom();
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slides-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slides-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
          updateLightboxImgTransform(false);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
        lightboxMediaType = "";
        resetLightboxZoom();
      }

      function handleLightboxWheel(e) {
        if (!lightboxContent || lightboxMediaType !== "image") return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        e.preventDefault();
        e.stopPropagation();
        if (Math.abs(e.deltaY) < 1) return;

        const factor = e.deltaY < 0 ? 1.2 : 1 / 1.2;
        const currentScale = lightboxScale;
        let nextScale = currentScale * factor;

        if (nextScale <= 1.02) {
          resetLightboxZoom();
          return;
        }
        if (nextScale > 5.0) {
          nextScale = 5.0;
        }

        const rect = img.getBoundingClientRect();
        const currentCenterX = rect.left + rect.width / 2;
        const currentCenterY = rect.top + rect.height / 2;
        const origCenterX = currentCenterX - lightboxTranslateX;
        const origCenterY = currentCenterY - lightboxTranslateY;

        const nextTx = (e.clientX - origCenterX) * (1 - nextScale / currentScale) + lightboxTranslateX * (nextScale / currentScale);
        const nextTy = (e.clientY - origCenterY) * (1 - nextScale / currentScale) + lightboxTranslateY * (nextScale / currentScale);

        lightboxTranslateX = Math.round(nextTx * 10) / 10;
        lightboxTranslateY = Math.round(nextTy * 10) / 10;
        lightboxScale = Math.round(nextScale * 1000) / 1000;
        updateLightboxImgTransform(true);
      }

      if (lightboxContent) {
        lightboxContent.addEventListener("pointerdown", (e) => {
          if (e.button !== 0 || lightboxMediaType !== "image" || lightboxScale <= 1.0) return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          isLightboxDragging = true;
          lightboxDragStartX = e.clientX;
          lightboxDragStartY = e.clientY;
          lightboxInitialTx = lightboxTranslateX;
          lightboxInitialTy = lightboxTranslateY;
          lightboxHasMoved = false;
          if (img.setPointerCapture) {
            try { img.setPointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        });

        window.addEventListener("pointermove", (e) => {
          if (!isLightboxDragging || lightboxMediaType !== "image") return;
          e.preventDefault();
          e.stopPropagation();
          const dx = e.clientX - lightboxDragStartX;
          const dy = e.clientY - lightboxDragStartY;
          if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
            lightboxHasMoved = true;
          }
          lightboxTranslateX = Math.round((lightboxInitialTx + dx) * 10) / 10;
          lightboxTranslateY = Math.round((lightboxInitialTy + dy) * 10) / 10;
          updateLightboxImgTransform(false);
        });

        const onLightboxPointerEnd = (e) => {
          if (!isLightboxDragging) return;
          isLightboxDragging = false;
          const img = lightboxContent ? lightboxContent.querySelector(".slides-lightbox-img") : null;
          if (img && img.releasePointerCapture) {
            try { img.releasePointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        };
        window.addEventListener("pointerup", onLightboxPointerEnd);
        window.addEventListener("pointercancel", onLightboxPointerEnd);

        lightboxContent.addEventListener("dblclick", (e) => {
          if (lightboxMediaType !== "image") return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          if (lightboxScale > 1.05 || lightboxTranslateX !== 0 || lightboxTranslateY !== 0) {
            resetLightboxZoom();
          } else {
            const targetScale = 2.0;
            const rect = img.getBoundingClientRect();
            const currentCenterX = rect.left + rect.width / 2;
            const currentCenterY = rect.top + rect.height / 2;
            const origCenterX = currentCenterX - lightboxTranslateX;
            const origCenterY = currentCenterY - lightboxTranslateY;
            lightboxTranslateX = Math.round(((e.clientX - origCenterX) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxTranslateY = Math.round(((e.clientY - origCenterY) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxScale = targetScale;
            updateLightboxImgTransform(true);
          }
        });
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            if (lightboxHasMoved) {
              lightboxHasMoved = false;
              return;
            }
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function og(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function ig(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slides-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slides-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slides-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background || (data.config && data.config.background);
          if (bg) {
            if (/^(http|\\/|data:|assets\\/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slides-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slides-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slides-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slides-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slides-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function ng(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slides-viewport") || cur.classList.contains("slides-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) {
          if (typeof handleLightboxWheel === "function") {
            handleLightboxWheel(e);
          }
          return;
        }
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          if (typeof lightboxHasMoved !== "undefined" && lightboxHasMoved) {
            lightboxHasMoved = false;
            e.stopPropagation();
            return;
          }
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slides-lightbox-img, .slides-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const hasPendingMask = currentMaskConfig && (currentMaskStep < currentMaskConfig.totalSteps);
        if (hasPendingMask) {
          const isBottomControls = targetEl.closest(".controls-bar, .controls, .slides-toc");
          if (isBottomControls) return;
          e.preventDefault();
          e.stopPropagation();
          goNext();
          return;
        }

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slides-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function sg(){return[Zm(),Jm(),Xm(),Qm(),eg(),tg(),og(),ig(),ng()].join("")}function rg(e,t=!1){var l;const o=new Set,i=r=>{if(!r||typeof r!="string")return;const a=r.trim();!a||a.startsWith("data:")||(a.includes("/assets/")||a.startsWith("assets/")||a.startsWith("./assets/")||a.startsWith("/assets/")||t&&/^https?:\/\//i.test(a))&&o.add(a)},n=r=>{if(!r||typeof r!="string")return;const a=/!\[.*?\]\((.+?)\)/g;let c;for(;(c=a.exec(r))!==null;)c[1]&&i(c[1]);const u=/<(?:img|video|audio|source)\b[^>]*?\bsrc=["'](.*?)["']/gi;for(;(c=u.exec(r))!==null;)c[1]&&i(c[1]);const h=/url\(\s*["']?(.*?)["']?\s*\)/gi;for(;(c=h.exec(r))!==null;)c[1]&&i(c[1])},s=r=>{if(r&&(r.rawMarkdown&&n(r.rawMarkdown),r.content&&n(r.content),Array.isArray(r.children)))for(const a of r.children)s(a)};(l=e.config)!=null&&l.background&&i(e.config.background);for(const r of e.slides||[]){if(r.frontmatter)for(const a of Object.values(r.frontmatter))typeof a=="string"&&i(a);if(r.rawMarkdown&&n(r.rawMarkdown),Array.isArray(r.blocks))for(const a of r.blocks)s(a);if(Array.isArray(r.noteBlocks))for(const a of r.noteBlocks)s(a);r.notes&&n(r.notes)}try{const r=JSON.stringify(e),a=/(?:https?:\/\/[^\s"'<>\)\\]+)?(?:\.\/|\/)?assets\/[^\s"'<>\)\\]+/g,c=r.match(a);if(c)for(const u of c)i(u);if(t){const u=/https?:\/\/[^\s"'<>\)\\]+\.(?:png|jpe?g|gif|webp|svg|avif|ico|bmp)(?:\?[^\s"'<>\)\\]*)?/gi,h=r.match(u);if(h)for(const y of h)i(y)}}catch{}return Array.from(o)}async function Fs(e){if(typeof FileReader<"u")return new Promise((n,s)=>{const l=new FileReader;l.onloadend=()=>{typeof l.result=="string"?n(l.result):s(new Error("Failed to convert blob to data URL"))},l.onerror=()=>s(l.error||new Error("FileReader error")),l.readAsDataURL(e)});const t=await e.arrayBuffer(),o=Buffer.from(t);return`data:${e.type||"image/png"};base64,${o.toString("base64")}`}async function kl(e){if(typeof e=="string")return e.startsWith("data:")?e:`data:image/png;base64,${e}`;if(e instanceof ArrayBuffer){const t=new Blob([e]);return Fs(t)}return e instanceof Blob?Fs(e):""}async function lg(e,t){var l,r;const o=rg(e,t==null?void 0:t.includeRemote);if(o.length===0)return{};const i={},n=typeof window<"u"&&((r=(l=window.siyuan)==null?void 0:l.config)==null?void 0:r.apiToken)||"",s=n?{Authorization:`Token ${n}`}:{};for(const a of o){let c="",u=!1;const h=a.indexOf("/assets/");h!==-1?(c=a.slice(h+1),u=!0):a.startsWith("assets/")?(c=a,u=!0):a.startsWith("./assets/")?(c=a.slice(2),u=!0):a.startsWith("/assets/")&&(c=a.slice(1),u=!0);try{let y=null;if(t!=null&&t.fetcher){const d=await t.fetcher(a).catch(()=>null);if(d)y=await kl(d);else if(c&&c!==a){const f=await t.fetcher(`/${c}`).catch(()=>null);f&&(y=await kl(f))}}else if(typeof fetch<"u"){const d=[];(a.startsWith("http://")||a.startsWith("https://"))&&d.push({url:a,headers:u?s:void 0}),u&&c&&(d.push({url:`/${c}`,headers:s}),d.push({url:`./${c}`,headers:s}),d.push({url:c,headers:s})),u||d.push({url:a});for(const f of d)try{const p=await fetch(f.url,{credentials:"include",headers:f.headers});if(p.ok){const g=await p.blob();if(y=await Fs(g),y)break}}catch{}}if(y){const d=[a];c&&d.push(`/${c}`,`./${c}`,c);for(const f of d){i[f]=y;try{i[decodeURI(f)]=y,i[encodeURI(f)]=y}catch{}}}}catch(y){console.warn(`[single-html-exporter] Failed to inline asset "${a}":`,y)}}return i}function ag(e,t){const o=(t==null?void 0:t.title)||"即现演示文稿";let i=e.slides,n={...e.config},s=e.customThemeCss;if(t!=null&&t.inlineAssetBase64Map&&Object.keys(t.inlineAssetBase64Map).length>0){const c=t.inlineAssetBase64Map,u=Object.entries(c).sort((d,f)=>f[0].length-d[0].length),h=d=>{if(!d||typeof d!="string")return d;let f=d;for(const[p,g]of u)f.includes(p)&&(f=f.split(p).join(g));return f},y=d=>{const f=h(d.rawMarkdown||""),p=h(d.content||""),g=Array.isArray(d.children)?d.children.map(b=>y(b)):d.children;return{...d,rawMarkdown:f,content:p,children:g}};n.background&&typeof n.background=="string"&&(n.background=h(n.background)),s&&(s=h(s)),i=(e.slides||[]).map(d=>{const f=h(d.rawMarkdown||""),p=(d.blocks||[]).map(y),g=Array.isArray(d.noteBlocks)?d.noteBlocks.map(y):d.noteBlocks,b=h(d.notes||"");let k=d.frontmatter?{...d.frontmatter}:d.frontmatter;if(k)for(const[w,_]of Object.entries(k))typeof _=="string"&&(k[w]=h(_));return{...d,rawMarkdown:f,blocks:p,noteBlocks:g,notes:b,frontmatter:k}})}const l=gr(n.colorSchema),r=JSON.stringify(i),a=JSON.stringify({...n,hostThemeMode:n.hostThemeMode||l});return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${st(o)}</title>
  <style>
${Ym(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDES_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${r},
      config: ${a}
    };
  <\/script>
</head>
<body>
  <div id="app" data-theme="${l}" data-normalize-headings="${n.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${n.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${n.showOrderedListMarkers===!1?"true":"false"}">
    <div class="slide-viewport slides-theme-${n.theme||"apple-basic"}" id="viewport" data-theme="${l}" data-slides-theme="${n.theme||"apple-basic"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slides-lightbox" class="slides-lightbox">
      <button class="slides-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slides-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${sg()}
  <\/script>
</body>
</html>`}async function oc(e,t){let o=t==null?void 0:t.inlineAssetBase64Map;return(!o||Object.keys(o).length===0)&&(o=await lg(e,t)),ag(e,{...t,inlineAssetBase64Map:o})}function ic(e,t){if(typeof document>"u")return!1;const o=new Blob([t],{type:"text/html;charset=utf-8"}),i=URL.createObjectURL(o),n=document.createElement("a");return n.href=i,n.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(i),!0}function cg(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function dg(e){const t=cg(e==null?void 0:e.pageRatio);return`
    ${Fi(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slides-padding-y, 36px) var(--slides-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
      container-type: size;
    }
    .pdf-slide-page.spacing-compact {
      --slides-padding-y: 16px;
      --slides-padding-x: 28px;
      --slides-block-gap: 8px;
      --slides-list-gap: 4px;
      --slides-cols-gap: 20px;
      --slides-title-margin-bottom: 8px;
      --slides-header-gap: 10px;
      --slides-line-height: 1.45;
    }
    .pdf-slide-page.spacing-normal {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-block-gap: 14px;
      --slides-list-gap: 6px;
      --slides-cols-gap: 32px;
      --slides-title-margin-bottom: 12px;
      --slides-header-gap: 16px;
      --slides-line-height: 1.6;
    }
    .pdf-slide-page.spacing-loose {
      --slides-padding-y: 52px;
      --slides-padding-x: 72px;
      --slides-block-gap: 22px;
      --slides-list-gap: 10px;
      --slides-cols-gap: 44px;
      --slides-title-margin-bottom: 18px;
      --slides-header-gap: 24px;
      --slides-line-height: 1.75;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }

    /* 1. 默认科技主题 Default (Modern Tech) */
    .pdf-slide-page.slides-theme-tech {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
    }
    .pdf-slide-page.slides-theme-tech.theme-light {
      background: #f8fafc;
      color: #0f172a;
    }
    .pdf-slide-page.slides-theme-tech.theme-dark {
      background: #090d16;
      color: #f1f5f9;
    }
    .slides-theme-tech .pdf-block h1 { color: #059669; }
    .theme-dark.slides-theme-tech .pdf-block h1 { color: #10b981; }
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #059669;
      border-left: 4px solid #059669;
      padding: 4px 14px;
      padding-left: 14px;
      background: linear-gradient(90deg, rgba(5, 150, 105, 0.13), transparent 76%);
      border-radius: 0 6px 6px 0;
      letter-spacing: -0.015em;
    }
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #10b981;
      border-left-color: #10b981;
      background: linear-gradient(90deg, rgba(16, 185, 129, 0.14), transparent 76%);
    }

    /* 2. 优雅衬线主题 Seriph (Editorial Academic) */
    .pdf-slide-page.slides-theme-seriph {
      font-family: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      letter-spacing: 0.015em;
    }
    .pdf-slide-page.slides-theme-seriph.theme-light {
      background: #fcfbf7;
      color: #231f1d;
    }
    .pdf-slide-page.slides-theme-seriph.theme-dark {
      background: #171513;
      color: #f5f2eb;
    }
    .slides-theme-seriph .pdf-block h1 { color: #b45309; }
    .theme-dark.slides-theme-seriph .pdf-block h1 { color: #f59e0b; }
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      display: block;
      position: relative;
      color: #b45309;
      border-bottom: 1.5px solid rgba(180, 83, 9, 0.45);
      padding-bottom: 10px;
      margin-bottom: 14px;
    }
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3::after {
      content: "";
      position: absolute;
      left: 0;
      right: 0;
      bottom: 3px;
      height: 1.5px;
      pointer-events: none;
      background: linear-gradient(90deg, #b45309 0%, rgba(180, 83, 9, 0.35) 50%, transparent 92%);
    }
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #f59e0b;
      border-bottom-color: rgba(245, 158, 11, 0.45);
    }
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3::after {
      background: linear-gradient(90deg, #f59e0b 0%, rgba(245, 158, 11, 0.35) 50%, transparent 92%);
    }

    /* 3. 极简发布会主题 Apple Basic (Swiss Minimal) */
    .pdf-slide-page.slides-theme-apple-basic {
      font-family: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      letter-spacing: -0.025em;
    }
    .pdf-slide-page.slides-theme-apple-basic.theme-light {
      background: #ffffff;
      color: #000000;
    }
    .pdf-slide-page.slides-theme-apple-basic.theme-dark {
      background: #000000;
      color: #ffffff;
    }
    .slides-theme-apple-basic .pdf-block h1 {
      color: #000000;
      font-weight: 800;
      letter-spacing: -0.035em;
    }
    .theme-dark.slides-theme-apple-basic .pdf-block h1 {
      color: #ffffff;
      font-weight: 800;
      letter-spacing: -0.035em;
    }
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      border: none !important;
      background: none !important;
      padding: 0 !important;
      margin-bottom: 16px !important;
      letter-spacing: -0.04em !important;
      font-weight: 800 !important;
    }
    /* 页面存在背景图时，内容页顶部标题回退高对比文字与局部衬底，保留用户块级前景色 */
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #0f172a;
      text-shadow: 0 1px 3px rgba(255, 255, 255, 0.85);
    }
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3 {
      color: #f8fafc;
      text-shadow: 0 1px 3px rgba(0, 0, 0, 0.75);
    }
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3 {
      background: linear-gradient(90deg, rgba(255, 255, 255, 0.55), transparent 82%);
    }
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3 {
      background: linear-gradient(90deg, rgba(15, 23, 42, 0.42), transparent 82%);
    }
    .pdf-slide-page .pdf-block[style^="color:"] h1,
    .pdf-slide-page .pdf-block[style*=" color:"] h1,
    .pdf-slide-page .pdf-block[style*=";color:"] h1,
    .pdf-slide-page .pdf-block[style^="color:"] h2,
    .pdf-slide-page .pdf-block[style*=" color:"] h2,
    .pdf-slide-page .pdf-block[style*=";color:"] h2,
    .pdf-slide-page .pdf-block[style^="color:"] h3,
    .pdf-slide-page .pdf-block[style*=" color:"] h3,
    .pdf-slide-page .pdf-block[style*=";color:"] h3 {
      color: inherit !important;
    }
    .slides-theme-apple-basic .pdf-code,
    .slides-theme-apple-basic pre {
      border-radius: 14px !important;
      border-left: none !important;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: var(--slides-cols-gap, 32px);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.75);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.625);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: var(--slides-block-gap, 14px);
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: calc(var(--slides-block-gap, 14px) * 0.6) 0;
      display: flex;
      flex-direction: column;
      gap: var(--slides-list-gap, 6px);
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: var(--slides-line-height, 1.6);
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: var(--slides-list-gap, 6px) !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: var(--slides-line-height, 1.6) !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slides-ref-tag, .theme-dark a.slides-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slides-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slides-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slides-motion-fade-in,
      .slides-motion-slide-up,
      .slides-motion-slide-down,
      .slides-motion-slide-left,
      .slides-motion-slide-right,
      .slides-motion-zoom-in,
      .slides-motion-pop,
      .slides-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slides-mask-layer,
      .slides-mask-overlay,
      .slides-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
        mask: none !important;
        -webkit-mask: none !important;
      }
      .slides-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function ug(e,t){const o="即现演示讲义",i="16:9",n=gr(e.config.colorSchema),s=e.config.theme||"apple-basic",l=e.slides.map((r,a)=>{const c=r.frontmatter.layout||"default",u=r.frontmatter.spacing,h=u&&u!=="inherit"?u:e.config.spacing||"normal",y=tc(r),d=`${a+1} / ${e.slides.length}`,f=r.frontmatter.background||e.config.background,p=Ka(f),g=p===!0?"light":p===!1?"dark":n,b=f&&!/^(http|\/|data:|assets\/)/.test(f)?`background: ${st(f)};`:"";return`
      <section class="pdf-slide-page layout-${c} theme-${g} spacing-${h} slides-theme-${s}" data-slides-theme="${s}" style="${b}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${st(o)}</span>
          ${`<span class="pdf-page-badge">P. ${d}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${y}
        </div>
        ${r.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${st(r.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${st(o)} - 高保真讲义</title>
  <style>
    ${dg({pageRatio:i,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
  ${l}
</body>
</html>`}function nc(e,t){var n;if(typeof window>"u"||typeof document>"u")return!1;const o=ug(e,t);try{const s=document.createElement("iframe");s.style.position="fixed",s.style.right="0",s.style.bottom="0",s.style.width="0",s.style.height="0",s.style.border="none",s.style.visibility="hidden",document.body.appendChild(s);const l=(n=s.contentWindow)==null?void 0:n.document;if(l)return l.open(),l.write(o),l.close(),setTimeout(()=>{var r,a;try{(r=s.contentWindow)==null||r.focus(),(a=s.contentWindow)==null||a.print()}finally{setTimeout(()=>{s.remove()},2e3)}},350),!0}catch(s){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",s)}const i=window.open("","_blank");return i?(i.document.write(o),i.document.close(),i.focus(),setTimeout(()=>{i.print(),i.close()},350),!0):!1}var un=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function fg(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function fn(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var ps={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var wl;function hg(){return wl||(wl=1,(function(e,t){(function(o){e.exports=o()})(function(){return(function o(i,n,s){function l(c,u){if(!n[c]){if(!i[c]){var h=typeof fn=="function"&&fn;if(!u&&h)return h(c,!0);if(r)return r(c,!0);var y=new Error("Cannot find module '"+c+"'");throw y.code="MODULE_NOT_FOUND",y}var d=n[c]={exports:{}};i[c][0].call(d.exports,function(f){var p=i[c][1][f];return l(p||f)},d,d.exports,o,i,n,s)}return n[c].exports}for(var r=typeof fn=="function"&&fn,a=0;a<s.length;a++)l(s[a]);return l})({1:[function(o,i,n){var s=o("./utils"),l=o("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";n.encode=function(a){for(var c,u,h,y,d,f,p,g=[],b=0,k=a.length,w=k,_=s.getTypeOf(a)!=="string";b<a.length;)w=k-b,h=_?(c=a[b++],u=b<k?a[b++]:0,b<k?a[b++]:0):(c=a.charCodeAt(b++),u=b<k?a.charCodeAt(b++):0,b<k?a.charCodeAt(b++):0),y=c>>2,d=(3&c)<<4|u>>4,f=1<w?(15&u)<<2|h>>6:64,p=2<w?63&h:64,g.push(r.charAt(y)+r.charAt(d)+r.charAt(f)+r.charAt(p));return g.join("")},n.decode=function(a){var c,u,h,y,d,f,p=0,g=0,b="data:";if(a.substr(0,b.length)===b)throw new Error("Invalid base64 input, it looks like a data url.");var k,w=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&w--,a.charAt(a.length-2)===r.charAt(64)&&w--,w%1!=0)throw new Error("Invalid base64 input, bad content length.");for(k=l.uint8array?new Uint8Array(0|w):new Array(0|w);p<a.length;)c=r.indexOf(a.charAt(p++))<<2|(y=r.indexOf(a.charAt(p++)))>>4,u=(15&y)<<4|(d=r.indexOf(a.charAt(p++)))>>2,h=(3&d)<<6|(f=r.indexOf(a.charAt(p++))),k[g++]=c,d!==64&&(k[g++]=u),f!==64&&(k[g++]=h);return k}},{"./support":30,"./utils":32}],2:[function(o,i,n){var s=o("./external"),l=o("./stream/DataWorker"),r=o("./stream/Crc32Probe"),a=o("./stream/DataLengthProbe");function c(u,h,y,d,f){this.compressedSize=u,this.uncompressedSize=h,this.crc32=y,this.compression=d,this.compressedContent=f}c.prototype={getContentWorker:function(){var u=new l(s.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),h=this;return u.on("end",function(){if(this.streamInfo.data_length!==h.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),u},getCompressedWorker:function(){return new l(s.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(u,h,y){return u.pipe(new r).pipe(new a("uncompressedSize")).pipe(h.compressWorker(y)).pipe(new a("compressedSize")).withStreamInfo("compression",h)},i.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(o,i,n){var s=o("./stream/GenericWorker");n.STORE={magic:"\0\0",compressWorker:function(){return new s("STORE compression")},uncompressWorker:function(){return new s("STORE decompression")}},n.DEFLATE=o("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(o,i,n){var s=o("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var u=0;u<8;u++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();i.exports=function(r,a){return r!==void 0&&r.length?s.getTypeOf(r)!=="string"?(function(c,u,h,y){var d=l,f=y+h;c^=-1;for(var p=y;p<f;p++)c=c>>>8^d[255&(c^u[p])];return-1^c})(0|a,r,r.length,0):(function(c,u,h,y){var d=l,f=y+h;c^=-1;for(var p=y;p<f;p++)c=c>>>8^d[255&(c^u.charCodeAt(p))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(o,i,n){n.base64=!1,n.binary=!1,n.dir=!1,n.createFolders=!0,n.date=null,n.compression=null,n.compressionOptions=null,n.comment=null,n.unixPermissions=null,n.dosPermissions=null},{}],6:[function(o,i,n){var s=null;s=typeof Promise<"u"?Promise:o("lie"),i.exports={Promise:s}},{lie:37}],7:[function(o,i,n){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=o("pako"),r=o("./utils"),a=o("./stream/GenericWorker"),c=s?"uint8array":"array";function u(h,y){a.call(this,"FlateWorker/"+h),this._pako=null,this._pakoAction=h,this._pakoOptions=y,this.meta={}}n.magic="\b\0",r.inherits(u,a),u.prototype.processChunk=function(h){this.meta=h.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,h.data),!1)},u.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},u.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},u.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var h=this;this._pako.onData=function(y){h.push({data:y,meta:h.meta})}},n.compressWorker=function(h){return new u("Deflate",h)},n.uncompressWorker=function(){return new u("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(o,i,n){function s(d,f){var p,g="";for(p=0;p<f;p++)g+=String.fromCharCode(255&d),d>>>=8;return g}function l(d,f,p,g,b,k){var w,_,M=d.file,A=d.compression,I=k!==c.utf8encode,N=r.transformTo("string",k(M.name)),H=r.transformTo("string",c.utf8encode(M.name)),z=M.comment,j=r.transformTo("string",k(z)),B=r.transformTo("string",c.utf8encode(z)),D=H.length!==M.name.length,x=B.length!==z.length,V="",W="",$="",T=M.dir,O=M.date,te={crc32:0,compressedSize:0,uncompressedSize:0};f&&!p||(te.crc32=d.crc32,te.compressedSize=d.compressedSize,te.uncompressedSize=d.uncompressedSize);var K=0;f&&(K|=8),I||!D&&!x||(K|=2048);var Z=0,ce=0;T&&(Z|=16),b==="UNIX"?(ce=798,Z|=(function(re,Se){var Ie=re;return re||(Ie=Se?16893:33204),(65535&Ie)<<16})(M.unixPermissions,T)):(ce=20,Z|=(function(re){return 63&(re||0)})(M.dosPermissions)),w=O.getUTCHours(),w<<=6,w|=O.getUTCMinutes(),w<<=5,w|=O.getUTCSeconds()/2,_=O.getUTCFullYear()-1980,_<<=4,_|=O.getUTCMonth()+1,_<<=5,_|=O.getUTCDate(),D&&(W=s(1,1)+s(u(N),4)+H,V+="up"+s(W.length,2)+W),x&&($=s(1,1)+s(u(j),4)+B,V+="uc"+s($.length,2)+$);var oe="";return oe+=`
\0`,oe+=s(K,2),oe+=A.magic,oe+=s(w,2),oe+=s(_,2),oe+=s(te.crc32,4),oe+=s(te.compressedSize,4),oe+=s(te.uncompressedSize,4),oe+=s(N.length,2),oe+=s(V.length,2),{fileRecord:h.LOCAL_FILE_HEADER+oe+N+V,dirRecord:h.CENTRAL_FILE_HEADER+s(ce,2)+oe+s(j.length,2)+"\0\0\0\0"+s(Z,4)+s(g,4)+N+V+j}}var r=o("../utils"),a=o("../stream/GenericWorker"),c=o("../utf8"),u=o("../crc32"),h=o("../signature");function y(d,f,p,g){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=f,this.zipPlatform=p,this.encodeFileName=g,this.streamFiles=d,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(y,a),y.prototype.push=function(d){var f=d.meta.percent||0,p=this.entriesCount,g=this._sources.length;this.accumulate?this.contentBuffer.push(d):(this.bytesWritten+=d.data.length,a.prototype.push.call(this,{data:d.data,meta:{currentFile:this.currentFile,percent:p?(f+100*(p-g-1))/p:100}}))},y.prototype.openedSource=function(d){this.currentSourceOffset=this.bytesWritten,this.currentFile=d.file.name;var f=this.streamFiles&&!d.file.dir;if(f){var p=l(d,f,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:p.fileRecord,meta:{percent:0}})}else this.accumulate=!0},y.prototype.closedSource=function(d){this.accumulate=!1;var f=this.streamFiles&&!d.file.dir,p=l(d,f,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(p.dirRecord),f)this.push({data:(function(g){return h.DATA_DESCRIPTOR+s(g.crc32,4)+s(g.compressedSize,4)+s(g.uncompressedSize,4)})(d),meta:{percent:100}});else for(this.push({data:p.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},y.prototype.flush=function(){for(var d=this.bytesWritten,f=0;f<this.dirRecords.length;f++)this.push({data:this.dirRecords[f],meta:{percent:100}});var p=this.bytesWritten-d,g=(function(b,k,w,_,M){var A=r.transformTo("string",M(_));return h.CENTRAL_DIRECTORY_END+"\0\0\0\0"+s(b,2)+s(b,2)+s(k,4)+s(w,4)+s(A.length,2)+A})(this.dirRecords.length,p,d,this.zipComment,this.encodeFileName);this.push({data:g,meta:{percent:100}})},y.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},y.prototype.registerPrevious=function(d){this._sources.push(d);var f=this;return d.on("data",function(p){f.processChunk(p)}),d.on("end",function(){f.closedSource(f.previous.streamInfo),f._sources.length?f.prepareNextSource():f.end()}),d.on("error",function(p){f.error(p)}),this},y.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},y.prototype.error=function(d){var f=this._sources;if(!a.prototype.error.call(this,d))return!1;for(var p=0;p<f.length;p++)try{f[p].error(d)}catch{}return!0},y.prototype.lock=function(){a.prototype.lock.call(this);for(var d=this._sources,f=0;f<d.length;f++)d[f].lock()},i.exports=y},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(o,i,n){var s=o("../compressions"),l=o("./ZipFileWorker");n.generateWorker=function(r,a,c){var u=new l(a.streamFiles,c,a.platform,a.encodeFileName),h=0;try{r.forEach(function(y,d){h++;var f=(function(k,w){var _=k||w,M=s[_];if(!M)throw new Error(_+" is not a valid compression method !");return M})(d.options.compression,a.compression),p=d.options.compressionOptions||a.compressionOptions||{},g=d.dir,b=d.date;d._compressWorker(f,p).withStreamInfo("file",{name:y,dir:g,date:b,comment:d.comment||"",unixPermissions:d.unixPermissions,dosPermissions:d.dosPermissions}).pipe(u)}),u.entriesCount=h}catch(y){u.error(y)}return u}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(o,i,n){function s(){if(!(this instanceof s))return new s;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new s;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(s.prototype=o("./object")).loadAsync=o("./load"),s.support=o("./support"),s.defaults=o("./defaults"),s.version="3.10.1",s.loadAsync=function(l,r){return new s().loadAsync(l,r)},s.external=o("./external"),i.exports=s},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(o,i,n){var s=o("./utils"),l=o("./external"),r=o("./utf8"),a=o("./zipEntries"),c=o("./stream/Crc32Probe"),u=o("./nodejsUtils");function h(y){return new l.Promise(function(d,f){var p=y.decompressed.getContentWorker().pipe(new c);p.on("error",function(g){f(g)}).on("end",function(){p.streamInfo.crc32!==y.decompressed.crc32?f(new Error("Corrupted zip : CRC32 mismatch")):d()}).resume()})}i.exports=function(y,d){var f=this;return d=s.extend(d||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),u.isNode&&u.isStream(y)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):s.prepareContent("the loaded zip file",y,!0,d.optimizedBinaryString,d.base64).then(function(p){var g=new a(d);return g.load(p),g}).then(function(p){var g=[l.Promise.resolve(p)],b=p.files;if(d.checkCRC32)for(var k=0;k<b.length;k++)g.push(h(b[k]));return l.Promise.all(g)}).then(function(p){for(var g=p.shift(),b=g.files,k=0;k<b.length;k++){var w=b[k],_=w.fileNameStr,M=s.resolve(w.fileNameStr);f.file(M,w.decompressed,{binary:!0,optimizedBinaryString:!0,date:w.date,dir:w.dir,comment:w.fileCommentStr.length?w.fileCommentStr:null,unixPermissions:w.unixPermissions,dosPermissions:w.dosPermissions,createFolders:d.createFolders}),w.dir||(f.file(M).unsafeOriginalName=_)}return g.zipComment.length&&(f.comment=g.zipComment),f})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(o,i,n){var s=o("../utils"),l=o("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}s.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(u){c.push({data:u,meta:{percent:0}})}).on("error",function(u){c.isPaused?this.generatedError=u:c.error(u)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},i.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(o,i,n){var s=o("readable-stream").Readable;function l(r,a,c){s.call(this,a),this._helper=r;var u=this;r.on("data",function(h,y){u.push(h)||u._helper.pause(),c&&c(y)}).on("error",function(h){u.emit("error",h)}).on("end",function(){u.push(null)})}o("../utils").inherits(l,s),l.prototype._read=function(){this._helper.resume()},i.exports=l},{"../utils":32,"readable-stream":16}],14:[function(o,i,n){i.exports={isNode:typeof Buffer<"u",newBufferFrom:function(s,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(s,l);if(typeof s=="number")throw new Error('The "data" argument must not be a number');return new Buffer(s,l)},allocBuffer:function(s){if(Buffer.alloc)return Buffer.alloc(s);var l=new Buffer(s);return l.fill(0),l},isBuffer:function(s){return Buffer.isBuffer(s)},isStream:function(s){return s&&typeof s.on=="function"&&typeof s.pause=="function"&&typeof s.resume=="function"}}},{}],15:[function(o,i,n){function s(M,A,I){var N,H=r.getTypeOf(A),z=r.extend(I||{},u);z.date=z.date||new Date,z.compression!==null&&(z.compression=z.compression.toUpperCase()),typeof z.unixPermissions=="string"&&(z.unixPermissions=parseInt(z.unixPermissions,8)),z.unixPermissions&&16384&z.unixPermissions&&(z.dir=!0),z.dosPermissions&&16&z.dosPermissions&&(z.dir=!0),z.dir&&(M=b(M)),z.createFolders&&(N=g(M))&&k.call(this,N,!0);var j=H==="string"&&z.binary===!1&&z.base64===!1;I&&I.binary!==void 0||(z.binary=!j),(A instanceof h&&A.uncompressedSize===0||z.dir||!A||A.length===0)&&(z.base64=!1,z.binary=!0,A="",z.compression="STORE",H="string");var B=null;B=A instanceof h||A instanceof a?A:f.isNode&&f.isStream(A)?new p(M,A):r.prepareContent(M,A,z.binary,z.optimizedBinaryString,z.base64);var D=new y(M,B,z);this.files[M]=D}var l=o("./utf8"),r=o("./utils"),a=o("./stream/GenericWorker"),c=o("./stream/StreamHelper"),u=o("./defaults"),h=o("./compressedObject"),y=o("./zipObject"),d=o("./generate"),f=o("./nodejsUtils"),p=o("./nodejs/NodejsStreamInputAdapter"),g=function(M){M.slice(-1)==="/"&&(M=M.substring(0,M.length-1));var A=M.lastIndexOf("/");return 0<A?M.substring(0,A):""},b=function(M){return M.slice(-1)!=="/"&&(M+="/"),M},k=function(M,A){return A=A!==void 0?A:u.createFolders,M=b(M),this.files[M]||s.call(this,M,null,{dir:!0,createFolders:A}),this.files[M]};function w(M){return Object.prototype.toString.call(M)==="[object RegExp]"}var _={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(M){var A,I,N;for(A in this.files)N=this.files[A],(I=A.slice(this.root.length,A.length))&&A.slice(0,this.root.length)===this.root&&M(I,N)},filter:function(M){var A=[];return this.forEach(function(I,N){M(I,N)&&A.push(N)}),A},file:function(M,A,I){if(arguments.length!==1)return M=this.root+M,s.call(this,M,A,I),this;if(w(M)){var N=M;return this.filter(function(z,j){return!j.dir&&N.test(z)})}var H=this.files[this.root+M];return H&&!H.dir?H:null},folder:function(M){if(!M)return this;if(w(M))return this.filter(function(H,z){return z.dir&&M.test(H)});var A=this.root+M,I=k.call(this,A),N=this.clone();return N.root=I.name,N},remove:function(M){M=this.root+M;var A=this.files[M];if(A||(M.slice(-1)!=="/"&&(M+="/"),A=this.files[M]),A&&!A.dir)delete this.files[M];else for(var I=this.filter(function(H,z){return z.name.slice(0,M.length)===M}),N=0;N<I.length;N++)delete this.files[I[N].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(M){var A,I={};try{if((I=r.extend(M||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=I.type.toLowerCase(),I.compression=I.compression.toUpperCase(),I.type==="binarystring"&&(I.type="string"),!I.type)throw new Error("No output type specified.");r.checkSupport(I.type),I.platform!=="darwin"&&I.platform!=="freebsd"&&I.platform!=="linux"&&I.platform!=="sunos"||(I.platform="UNIX"),I.platform==="win32"&&(I.platform="DOS");var N=I.comment||this.comment||"";A=d.generateWorker(this,I,N)}catch(H){(A=new a("error")).error(H)}return new c(A,I.type||"string",I.mimeType)},generateAsync:function(M,A){return this.generateInternalStream(M).accumulate(A)},generateNodeStream:function(M,A){return(M=M||{}).type||(M.type="nodebuffer"),this.generateInternalStream(M).toNodejsStream(A)}};i.exports=_},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(o,i,n){i.exports=o("stream")},{stream:void 0}],17:[function(o,i,n){var s=o("./DataReader");function l(r){s.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}o("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),h=r.charCodeAt(3),y=this.length-4;0<=y;--y)if(this.data[y]===a&&this.data[y+1]===c&&this.data[y+2]===u&&this.data[y+3]===h)return y-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),h=r.charCodeAt(3),y=this.readData(4);return a===y[0]&&c===y[1]&&u===y[2]&&h===y[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./DataReader":18}],18:[function(o,i,n){var s=o("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return s.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},i.exports=l},{"../utils":32}],19:[function(o,i,n){var s=o("./Uint8ArrayReader");function l(r){s.call(this,r)}o("../utils").inherits(l,s),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(o,i,n){var s=o("./DataReader");function l(r){s.call(this,r)}o("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./DataReader":18}],21:[function(o,i,n){var s=o("./ArrayReader");function l(r){s.call(this,r)}o("../utils").inherits(l,s),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(o,i,n){var s=o("../utils"),l=o("../support"),r=o("./ArrayReader"),a=o("./StringReader"),c=o("./NodeBufferReader"),u=o("./Uint8ArrayReader");i.exports=function(h){var y=s.getTypeOf(h);return s.checkSupport(y),y!=="string"||l.uint8array?y==="nodebuffer"?new c(h):l.uint8array?new u(s.transformTo("uint8array",h)):new r(s.transformTo("array",h)):new a(h)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(o,i,n){n.LOCAL_FILE_HEADER="PK",n.CENTRAL_FILE_HEADER="PK",n.CENTRAL_DIRECTORY_END="PK",n.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",n.ZIP64_CENTRAL_DIRECTORY_END="PK",n.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(o,i,n){var s=o("./GenericWorker"),l=o("../utils");function r(a){s.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,s),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},i.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(o,i,n){var s=o("./GenericWorker"),l=o("../crc32");function r(){s.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}o("../utils").inherits(r,s),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},i.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(o,i,n){var s=o("../utils"),l=o("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}s.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},i.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(o,i,n){var s=o("../utils"),l=o("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(u){c.dataIsReady=!0,c.data=u,c.max=u&&u.length||0,c.type=s.getTypeOf(u),c.isPaused||c._tickAndRepeat()},function(u){c.error(u)})}s.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,s.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(s.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},i.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(o,i,n){function s(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}s.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},i.exports=s},{}],29:[function(o,i,n){var s=o("../utils"),l=o("./ConvertWorker"),r=o("./GenericWorker"),a=o("../base64"),c=o("../support"),u=o("../external"),h=null;if(c.nodestream)try{h=o("../nodejs/NodejsStreamOutputAdapter")}catch{}function y(f,p){return new u.Promise(function(g,b){var k=[],w=f._internalType,_=f._outputType,M=f._mimeType;f.on("data",function(A,I){k.push(A),p&&p(I)}).on("error",function(A){k=[],b(A)}).on("end",function(){try{var A=(function(I,N,H){switch(I){case"blob":return s.newBlob(s.transformTo("arraybuffer",N),H);case"base64":return a.encode(N);default:return s.transformTo(I,N)}})(_,(function(I,N){var H,z=0,j=null,B=0;for(H=0;H<N.length;H++)B+=N[H].length;switch(I){case"string":return N.join("");case"array":return Array.prototype.concat.apply([],N);case"uint8array":for(j=new Uint8Array(B),H=0;H<N.length;H++)j.set(N[H],z),z+=N[H].length;return j;case"nodebuffer":return Buffer.concat(N);default:throw new Error("concat : unsupported type '"+I+"'")}})(w,k),M);g(A)}catch(I){b(I)}k=[]}).resume()})}function d(f,p,g){var b=p;switch(p){case"blob":case"arraybuffer":b="uint8array";break;case"base64":b="string"}try{this._internalType=b,this._outputType=p,this._mimeType=g,s.checkSupport(b),this._worker=f.pipe(new l(b)),f.lock()}catch(k){this._worker=new r("error"),this._worker.error(k)}}d.prototype={accumulate:function(f){return y(this,f)},on:function(f,p){var g=this;return f==="data"?this._worker.on(f,function(b){p.call(g,b.data,b.meta)}):this._worker.on(f,function(){s.delay(p,arguments,g)}),this},resume:function(){return s.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(f){if(s.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new h(this,{objectMode:this._outputType!=="nodebuffer"},f)}},i.exports=d},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(o,i,n){if(n.base64=!0,n.array=!0,n.string=!0,n.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",n.nodebuffer=typeof Buffer<"u",n.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")n.blob=!1;else{var s=new ArrayBuffer(0);try{n.blob=new Blob([s],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(s),n.blob=l.getBlob("application/zip").size===0}catch{n.blob=!1}}}try{n.nodestream=!!o("readable-stream").Readable}catch{n.nodestream=!1}},{"readable-stream":16}],31:[function(o,i,n){for(var s=o("./utils"),l=o("./support"),r=o("./nodejsUtils"),a=o("./stream/GenericWorker"),c=new Array(256),u=0;u<256;u++)c[u]=252<=u?6:248<=u?5:240<=u?4:224<=u?3:192<=u?2:1;c[254]=c[254]=1;function h(){a.call(this,"utf-8 decode"),this.leftOver=null}function y(){a.call(this,"utf-8 encode")}n.utf8encode=function(d){return l.nodebuffer?r.newBufferFrom(d,"utf-8"):(function(f){var p,g,b,k,w,_=f.length,M=0;for(k=0;k<_;k++)(64512&(g=f.charCodeAt(k)))==55296&&k+1<_&&(64512&(b=f.charCodeAt(k+1)))==56320&&(g=65536+(g-55296<<10)+(b-56320),k++),M+=g<128?1:g<2048?2:g<65536?3:4;for(p=l.uint8array?new Uint8Array(M):new Array(M),k=w=0;w<M;k++)(64512&(g=f.charCodeAt(k)))==55296&&k+1<_&&(64512&(b=f.charCodeAt(k+1)))==56320&&(g=65536+(g-55296<<10)+(b-56320),k++),g<128?p[w++]=g:(g<2048?p[w++]=192|g>>>6:(g<65536?p[w++]=224|g>>>12:(p[w++]=240|g>>>18,p[w++]=128|g>>>12&63),p[w++]=128|g>>>6&63),p[w++]=128|63&g);return p})(d)},n.utf8decode=function(d){return l.nodebuffer?s.transformTo("nodebuffer",d).toString("utf-8"):(function(f){var p,g,b,k,w=f.length,_=new Array(2*w);for(p=g=0;p<w;)if((b=f[p++])<128)_[g++]=b;else if(4<(k=c[b]))_[g++]=65533,p+=k-1;else{for(b&=k===2?31:k===3?15:7;1<k&&p<w;)b=b<<6|63&f[p++],k--;1<k?_[g++]=65533:b<65536?_[g++]=b:(b-=65536,_[g++]=55296|b>>10&1023,_[g++]=56320|1023&b)}return _.length!==g&&(_.subarray?_=_.subarray(0,g):_.length=g),s.applyFromCharCode(_)})(d=s.transformTo(l.uint8array?"uint8array":"array",d))},s.inherits(h,a),h.prototype.processChunk=function(d){var f=s.transformTo(l.uint8array?"uint8array":"array",d.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var p=f;(f=new Uint8Array(p.length+this.leftOver.length)).set(this.leftOver,0),f.set(p,this.leftOver.length)}else f=this.leftOver.concat(f);this.leftOver=null}var g=(function(k,w){var _;for((w=w||k.length)>k.length&&(w=k.length),_=w-1;0<=_&&(192&k[_])==128;)_--;return _<0||_===0?w:_+c[k[_]]>w?_:w})(f),b=f;g!==f.length&&(l.uint8array?(b=f.subarray(0,g),this.leftOver=f.subarray(g,f.length)):(b=f.slice(0,g),this.leftOver=f.slice(g,f.length))),this.push({data:n.utf8decode(b),meta:d.meta})},h.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:n.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},n.Utf8DecodeWorker=h,s.inherits(y,a),y.prototype.processChunk=function(d){this.push({data:n.utf8encode(d.data),meta:d.meta})},n.Utf8EncodeWorker=y},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(o,i,n){var s=o("./support"),l=o("./base64"),r=o("./nodejsUtils"),a=o("./external");function c(p){return p}function u(p,g){for(var b=0;b<p.length;++b)g[b]=255&p.charCodeAt(b);return g}o("setimmediate"),n.newBlob=function(p,g){n.checkSupport("blob");try{return new Blob([p],{type:g})}catch{try{var b=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return b.append(p),b.getBlob(g)}catch{throw new Error("Bug : can't construct the Blob.")}}};var h={stringifyByChunk:function(p,g,b){var k=[],w=0,_=p.length;if(_<=b)return String.fromCharCode.apply(null,p);for(;w<_;)g==="array"||g==="nodebuffer"?k.push(String.fromCharCode.apply(null,p.slice(w,Math.min(w+b,_)))):k.push(String.fromCharCode.apply(null,p.subarray(w,Math.min(w+b,_)))),w+=b;return k.join("")},stringifyByChar:function(p){for(var g="",b=0;b<p.length;b++)g+=String.fromCharCode(p[b]);return g},applyCanBeUsed:{uint8array:(function(){try{return s.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return s.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function y(p){var g=65536,b=n.getTypeOf(p),k=!0;if(b==="uint8array"?k=h.applyCanBeUsed.uint8array:b==="nodebuffer"&&(k=h.applyCanBeUsed.nodebuffer),k)for(;1<g;)try{return h.stringifyByChunk(p,b,g)}catch{g=Math.floor(g/2)}return h.stringifyByChar(p)}function d(p,g){for(var b=0;b<p.length;b++)g[b]=p[b];return g}n.applyFromCharCode=y;var f={};f.string={string:c,array:function(p){return u(p,new Array(p.length))},arraybuffer:function(p){return f.string.uint8array(p).buffer},uint8array:function(p){return u(p,new Uint8Array(p.length))},nodebuffer:function(p){return u(p,r.allocBuffer(p.length))}},f.array={string:y,array:c,arraybuffer:function(p){return new Uint8Array(p).buffer},uint8array:function(p){return new Uint8Array(p)},nodebuffer:function(p){return r.newBufferFrom(p)}},f.arraybuffer={string:function(p){return y(new Uint8Array(p))},array:function(p){return d(new Uint8Array(p),new Array(p.byteLength))},arraybuffer:c,uint8array:function(p){return new Uint8Array(p)},nodebuffer:function(p){return r.newBufferFrom(new Uint8Array(p))}},f.uint8array={string:y,array:function(p){return d(p,new Array(p.length))},arraybuffer:function(p){return p.buffer},uint8array:c,nodebuffer:function(p){return r.newBufferFrom(p)}},f.nodebuffer={string:y,array:function(p){return d(p,new Array(p.length))},arraybuffer:function(p){return f.nodebuffer.uint8array(p).buffer},uint8array:function(p){return d(p,new Uint8Array(p.length))},nodebuffer:c},n.transformTo=function(p,g){if(g=g||"",!p)return g;n.checkSupport(p);var b=n.getTypeOf(g);return f[b][p](g)},n.resolve=function(p){for(var g=p.split("/"),b=[],k=0;k<g.length;k++){var w=g[k];w==="."||w===""&&k!==0&&k!==g.length-1||(w===".."?b.pop():b.push(w))}return b.join("/")},n.getTypeOf=function(p){return typeof p=="string"?"string":Object.prototype.toString.call(p)==="[object Array]"?"array":s.nodebuffer&&r.isBuffer(p)?"nodebuffer":s.uint8array&&p instanceof Uint8Array?"uint8array":s.arraybuffer&&p instanceof ArrayBuffer?"arraybuffer":void 0},n.checkSupport=function(p){if(!s[p.toLowerCase()])throw new Error(p+" is not supported by this platform")},n.MAX_VALUE_16BITS=65535,n.MAX_VALUE_32BITS=-1,n.pretty=function(p){var g,b,k="";for(b=0;b<(p||"").length;b++)k+="\\x"+((g=p.charCodeAt(b))<16?"0":"")+g.toString(16).toUpperCase();return k},n.delay=function(p,g,b){setImmediate(function(){p.apply(b||null,g||[])})},n.inherits=function(p,g){function b(){}b.prototype=g.prototype,p.prototype=new b},n.extend=function(){var p,g,b={};for(p=0;p<arguments.length;p++)for(g in arguments[p])Object.prototype.hasOwnProperty.call(arguments[p],g)&&b[g]===void 0&&(b[g]=arguments[p][g]);return b},n.prepareContent=function(p,g,b,k,w){return a.Promise.resolve(g).then(function(_){return s.blob&&(_ instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(_))!==-1)&&typeof FileReader<"u"?new a.Promise(function(M,A){var I=new FileReader;I.onload=function(N){M(N.target.result)},I.onerror=function(N){A(N.target.error)},I.readAsArrayBuffer(_)}):_}).then(function(_){var M=n.getTypeOf(_);return M?(M==="arraybuffer"?_=n.transformTo("uint8array",_):M==="string"&&(w?_=l.decode(_):b&&k!==!0&&(_=(function(A){return u(A,s.uint8array?new Uint8Array(A.length):new Array(A.length))})(_))),_):a.Promise.reject(new Error("Can't read the data of '"+p+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(o,i,n){var s=o("./reader/readerFor"),l=o("./utils"),r=o("./signature"),a=o("./zipEntry"),c=o("./support");function u(h){this.files=[],this.loadOptions=h}u.prototype={checkSignature:function(h){if(!this.reader.readAndCheckSignature(h)){this.reader.index-=4;var y=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(y)+", expected "+l.pretty(h)+")")}},isSignature:function(h,y){var d=this.reader.index;this.reader.setIndex(h);var f=this.reader.readString(4)===y;return this.reader.setIndex(d),f},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var h=this.reader.readData(this.zipCommentLength),y=c.uint8array?"uint8array":"array",d=l.transformTo(y,h);this.zipComment=this.loadOptions.decodeFileName(d)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var h,y,d,f=this.zip64EndOfCentralSize-44;0<f;)h=this.reader.readInt(2),y=this.reader.readInt(4),d=this.reader.readData(y),this.zip64ExtensibleData[h]={id:h,length:y,value:d}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var h,y;for(h=0;h<this.files.length;h++)y=this.files[h],this.reader.setIndex(y.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),y.readLocalPart(this.reader),y.handleUTF8(),y.processAttributes()},readCentralDir:function(){var h;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(h=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(h);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var h=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(h<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(h);var y=h;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(h=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(h),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var d=this.centralDirOffset+this.centralDirSize;this.zip64&&(d+=20,d+=12+this.zip64EndOfCentralSize);var f=y-d;if(0<f)this.isSignature(y,r.CENTRAL_FILE_HEADER)||(this.reader.zero=f);else if(f<0)throw new Error("Corrupted zip: missing "+Math.abs(f)+" bytes.")},prepareReader:function(h){this.reader=s(h)},load:function(h){this.prepareReader(h),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},i.exports=u},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(o,i,n){var s=o("./reader/readerFor"),l=o("./utils"),r=o("./compressedObject"),a=o("./crc32"),c=o("./utf8"),u=o("./compressions"),h=o("./support");function y(d,f){this.options=d,this.loadOptions=f}y.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(d){var f,p;if(d.skip(22),this.fileNameLength=d.readInt(2),p=d.readInt(2),this.fileName=d.readData(this.fileNameLength),d.skip(p),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((f=(function(g){for(var b in u)if(Object.prototype.hasOwnProperty.call(u,b)&&u[b].magic===g)return u[b];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,f,d.readData(this.compressedSize))},readCentralPart:function(d){this.versionMadeBy=d.readInt(2),d.skip(2),this.bitFlag=d.readInt(2),this.compressionMethod=d.readString(2),this.date=d.readDate(),this.crc32=d.readInt(4),this.compressedSize=d.readInt(4),this.uncompressedSize=d.readInt(4);var f=d.readInt(2);if(this.extraFieldsLength=d.readInt(2),this.fileCommentLength=d.readInt(2),this.diskNumberStart=d.readInt(2),this.internalFileAttributes=d.readInt(2),this.externalFileAttributes=d.readInt(4),this.localHeaderOffset=d.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");d.skip(f),this.readExtraFields(d),this.parseZIP64ExtraField(d),this.fileComment=d.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var d=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),d==0&&(this.dosPermissions=63&this.externalFileAttributes),d==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var d=s(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=d.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=d.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=d.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=d.readInt(4))}},readExtraFields:function(d){var f,p,g,b=d.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});d.index+4<b;)f=d.readInt(2),p=d.readInt(2),g=d.readData(p),this.extraFields[f]={id:f,length:p,value:g};d.setIndex(b)},handleUTF8:function(){var d=h.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var f=this.findExtraFieldUnicodePath();if(f!==null)this.fileNameStr=f;else{var p=l.transformTo(d,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(p)}var g=this.findExtraFieldUnicodeComment();if(g!==null)this.fileCommentStr=g;else{var b=l.transformTo(d,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(b)}}},findExtraFieldUnicodePath:function(){var d=this.extraFields[28789];if(d){var f=s(d.value);return f.readInt(1)!==1||a(this.fileName)!==f.readInt(4)?null:c.utf8decode(f.readData(d.length-5))}return null},findExtraFieldUnicodeComment:function(){var d=this.extraFields[25461];if(d){var f=s(d.value);return f.readInt(1)!==1||a(this.fileComment)!==f.readInt(4)?null:c.utf8decode(f.readData(d.length-5))}return null}},i.exports=y},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(o,i,n){function s(f,p,g){this.name=f,this.dir=g.dir,this.date=g.date,this.comment=g.comment,this.unixPermissions=g.unixPermissions,this.dosPermissions=g.dosPermissions,this._data=p,this._dataBinary=g.binary,this.options={compression:g.compression,compressionOptions:g.compressionOptions}}var l=o("./stream/StreamHelper"),r=o("./stream/DataWorker"),a=o("./utf8"),c=o("./compressedObject"),u=o("./stream/GenericWorker");s.prototype={internalStream:function(f){var p=null,g="string";try{if(!f)throw new Error("No output type specified.");var b=(g=f.toLowerCase())==="string"||g==="text";g!=="binarystring"&&g!=="text"||(g="string"),p=this._decompressWorker();var k=!this._dataBinary;k&&!b&&(p=p.pipe(new a.Utf8EncodeWorker)),!k&&b&&(p=p.pipe(new a.Utf8DecodeWorker))}catch(w){(p=new u("error")).error(w)}return new l(p,g,"")},async:function(f,p){return this.internalStream(f).accumulate(p)},nodeStream:function(f,p){return this.internalStream(f||"nodebuffer").toNodejsStream(p)},_compressWorker:function(f,p){if(this._data instanceof c&&this._data.compression.magic===f.magic)return this._data.getCompressedWorker();var g=this._decompressWorker();return this._dataBinary||(g=g.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(g,f,p)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof u?this._data:new r(this._data)}};for(var h=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],y=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},d=0;d<h.length;d++)s.prototype[h[d]]=y;i.exports=s},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(o,i,n){(function(s){var l,r,a=s.MutationObserver||s.WebKitMutationObserver;if(a){var c=0,u=new a(f),h=s.document.createTextNode("");u.observe(h,{characterData:!0}),l=function(){h.data=c=++c%2}}else if(s.setImmediate||s.MessageChannel===void 0)l="document"in s&&"onreadystatechange"in s.document.createElement("script")?function(){var p=s.document.createElement("script");p.onreadystatechange=function(){f(),p.onreadystatechange=null,p.parentNode.removeChild(p),p=null},s.document.documentElement.appendChild(p)}:function(){setTimeout(f,0)};else{var y=new s.MessageChannel;y.port1.onmessage=f,l=function(){y.port2.postMessage(0)}}var d=[];function f(){var p,g;r=!0;for(var b=d.length;b;){for(g=d,d=[],p=-1;++p<b;)g[p]();b=d.length}r=!1}i.exports=function(p){d.push(p)!==1||r||l()}}).call(this,typeof un<"u"?un:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(o,i,n){var s=o("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],u=["PENDING"];function h(b){if(typeof b!="function")throw new TypeError("resolver must be a function");this.state=u,this.queue=[],this.outcome=void 0,b!==l&&p(this,b)}function y(b,k,w){this.promise=b,typeof k=="function"&&(this.onFulfilled=k,this.callFulfilled=this.otherCallFulfilled),typeof w=="function"&&(this.onRejected=w,this.callRejected=this.otherCallRejected)}function d(b,k,w){s(function(){var _;try{_=k(w)}catch(M){return r.reject(b,M)}_===b?r.reject(b,new TypeError("Cannot resolve promise with itself")):r.resolve(b,_)})}function f(b){var k=b&&b.then;if(b&&(typeof b=="object"||typeof b=="function")&&typeof k=="function")return function(){k.apply(b,arguments)}}function p(b,k){var w=!1;function _(I){w||(w=!0,r.reject(b,I))}function M(I){w||(w=!0,r.resolve(b,I))}var A=g(function(){k(M,_)});A.status==="error"&&_(A.value)}function g(b,k){var w={};try{w.value=b(k),w.status="success"}catch(_){w.status="error",w.value=_}return w}(i.exports=h).prototype.finally=function(b){if(typeof b!="function")return this;var k=this.constructor;return this.then(function(w){return k.resolve(b()).then(function(){return w})},function(w){return k.resolve(b()).then(function(){throw w})})},h.prototype.catch=function(b){return this.then(null,b)},h.prototype.then=function(b,k){if(typeof b!="function"&&this.state===c||typeof k!="function"&&this.state===a)return this;var w=new this.constructor(l);return this.state!==u?d(w,this.state===c?b:k,this.outcome):this.queue.push(new y(w,b,k)),w},y.prototype.callFulfilled=function(b){r.resolve(this.promise,b)},y.prototype.otherCallFulfilled=function(b){d(this.promise,this.onFulfilled,b)},y.prototype.callRejected=function(b){r.reject(this.promise,b)},y.prototype.otherCallRejected=function(b){d(this.promise,this.onRejected,b)},r.resolve=function(b,k){var w=g(f,k);if(w.status==="error")return r.reject(b,w.value);var _=w.value;if(_)p(b,_);else{b.state=c,b.outcome=k;for(var M=-1,A=b.queue.length;++M<A;)b.queue[M].callFulfilled(k)}return b},r.reject=function(b,k){b.state=a,b.outcome=k;for(var w=-1,_=b.queue.length;++w<_;)b.queue[w].callRejected(k);return b},h.resolve=function(b){return b instanceof this?b:r.resolve(new this(l),b)},h.reject=function(b){var k=new this(l);return r.reject(k,b)},h.all=function(b){var k=this;if(Object.prototype.toString.call(b)!=="[object Array]")return this.reject(new TypeError("must be an array"));var w=b.length,_=!1;if(!w)return this.resolve([]);for(var M=new Array(w),A=0,I=-1,N=new this(l);++I<w;)H(b[I],I);return N;function H(z,j){k.resolve(z).then(function(B){M[j]=B,++A!==w||_||(_=!0,r.resolve(N,M))},function(B){_||(_=!0,r.reject(N,B))})}},h.race=function(b){var k=this;if(Object.prototype.toString.call(b)!=="[object Array]")return this.reject(new TypeError("must be an array"));var w=b.length,_=!1;if(!w)return this.resolve([]);for(var M=-1,A=new this(l);++M<w;)I=b[M],k.resolve(I).then(function(N){_||(_=!0,r.resolve(A,N))},function(N){_||(_=!0,r.reject(A,N))});var I;return A}},{immediate:36}],38:[function(o,i,n){var s={};(0,o("./lib/utils/common").assign)(s,o("./lib/deflate"),o("./lib/inflate"),o("./lib/zlib/constants")),i.exports=s},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(o,i,n){var s=o("./zlib/deflate"),l=o("./utils/common"),r=o("./utils/strings"),a=o("./zlib/messages"),c=o("./zlib/zstream"),u=Object.prototype.toString,h=0,y=-1,d=0,f=8;function p(b){if(!(this instanceof p))return new p(b);this.options=l.assign({level:y,method:f,chunkSize:16384,windowBits:15,memLevel:8,strategy:d,to:""},b||{});var k=this.options;k.raw&&0<k.windowBits?k.windowBits=-k.windowBits:k.gzip&&0<k.windowBits&&k.windowBits<16&&(k.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var w=s.deflateInit2(this.strm,k.level,k.method,k.windowBits,k.memLevel,k.strategy);if(w!==h)throw new Error(a[w]);if(k.header&&s.deflateSetHeader(this.strm,k.header),k.dictionary){var _;if(_=typeof k.dictionary=="string"?r.string2buf(k.dictionary):u.call(k.dictionary)==="[object ArrayBuffer]"?new Uint8Array(k.dictionary):k.dictionary,(w=s.deflateSetDictionary(this.strm,_))!==h)throw new Error(a[w]);this._dict_set=!0}}function g(b,k){var w=new p(k);if(w.push(b,!0),w.err)throw w.msg||a[w.err];return w.result}p.prototype.push=function(b,k){var w,_,M=this.strm,A=this.options.chunkSize;if(this.ended)return!1;_=k===~~k?k:k===!0?4:0,typeof b=="string"?M.input=r.string2buf(b):u.call(b)==="[object ArrayBuffer]"?M.input=new Uint8Array(b):M.input=b,M.next_in=0,M.avail_in=M.input.length;do{if(M.avail_out===0&&(M.output=new l.Buf8(A),M.next_out=0,M.avail_out=A),(w=s.deflate(M,_))!==1&&w!==h)return this.onEnd(w),!(this.ended=!0);M.avail_out!==0&&(M.avail_in!==0||_!==4&&_!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(M.output,M.next_out))):this.onData(l.shrinkBuf(M.output,M.next_out)))}while((0<M.avail_in||M.avail_out===0)&&w!==1);return _===4?(w=s.deflateEnd(this.strm),this.onEnd(w),this.ended=!0,w===h):_!==2||(this.onEnd(h),!(M.avail_out=0))},p.prototype.onData=function(b){this.chunks.push(b)},p.prototype.onEnd=function(b){b===h&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=b,this.msg=this.strm.msg},n.Deflate=p,n.deflate=g,n.deflateRaw=function(b,k){return(k=k||{}).raw=!0,g(b,k)},n.gzip=function(b,k){return(k=k||{}).gzip=!0,g(b,k)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(o,i,n){var s=o("./zlib/inflate"),l=o("./utils/common"),r=o("./utils/strings"),a=o("./zlib/constants"),c=o("./zlib/messages"),u=o("./zlib/zstream"),h=o("./zlib/gzheader"),y=Object.prototype.toString;function d(p){if(!(this instanceof d))return new d(p);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},p||{});var g=this.options;g.raw&&0<=g.windowBits&&g.windowBits<16&&(g.windowBits=-g.windowBits,g.windowBits===0&&(g.windowBits=-15)),!(0<=g.windowBits&&g.windowBits<16)||p&&p.windowBits||(g.windowBits+=32),15<g.windowBits&&g.windowBits<48&&(15&g.windowBits)==0&&(g.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var b=s.inflateInit2(this.strm,g.windowBits);if(b!==a.Z_OK)throw new Error(c[b]);this.header=new h,s.inflateGetHeader(this.strm,this.header)}function f(p,g){var b=new d(g);if(b.push(p,!0),b.err)throw b.msg||c[b.err];return b.result}d.prototype.push=function(p,g){var b,k,w,_,M,A,I=this.strm,N=this.options.chunkSize,H=this.options.dictionary,z=!1;if(this.ended)return!1;k=g===~~g?g:g===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof p=="string"?I.input=r.binstring2buf(p):y.call(p)==="[object ArrayBuffer]"?I.input=new Uint8Array(p):I.input=p,I.next_in=0,I.avail_in=I.input.length;do{if(I.avail_out===0&&(I.output=new l.Buf8(N),I.next_out=0,I.avail_out=N),(b=s.inflate(I,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&H&&(A=typeof H=="string"?r.string2buf(H):y.call(H)==="[object ArrayBuffer]"?new Uint8Array(H):H,b=s.inflateSetDictionary(this.strm,A)),b===a.Z_BUF_ERROR&&z===!0&&(b=a.Z_OK,z=!1),b!==a.Z_STREAM_END&&b!==a.Z_OK)return this.onEnd(b),!(this.ended=!0);I.next_out&&(I.avail_out!==0&&b!==a.Z_STREAM_END&&(I.avail_in!==0||k!==a.Z_FINISH&&k!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(w=r.utf8border(I.output,I.next_out),_=I.next_out-w,M=r.buf2string(I.output,w),I.next_out=_,I.avail_out=N-_,_&&l.arraySet(I.output,I.output,w,_,0),this.onData(M)):this.onData(l.shrinkBuf(I.output,I.next_out)))),I.avail_in===0&&I.avail_out===0&&(z=!0)}while((0<I.avail_in||I.avail_out===0)&&b!==a.Z_STREAM_END);return b===a.Z_STREAM_END&&(k=a.Z_FINISH),k===a.Z_FINISH?(b=s.inflateEnd(this.strm),this.onEnd(b),this.ended=!0,b===a.Z_OK):k!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(I.avail_out=0))},d.prototype.onData=function(p){this.chunks.push(p)},d.prototype.onEnd=function(p){p===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=p,this.msg=this.strm.msg},n.Inflate=d,n.inflate=f,n.inflateRaw=function(p,g){return(g=g||{}).raw=!0,f(p,g)},n.ungzip=f},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(o,i,n){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";n.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var u=c.shift();if(u){if(typeof u!="object")throw new TypeError(u+"must be non-object");for(var h in u)u.hasOwnProperty(h)&&(a[h]=u[h])}}return a},n.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,u,h,y){if(c.subarray&&a.subarray)a.set(c.subarray(u,u+h),y);else for(var d=0;d<h;d++)a[y+d]=c[u+d]},flattenChunks:function(a){var c,u,h,y,d,f;for(c=h=0,u=a.length;c<u;c++)h+=a[c].length;for(f=new Uint8Array(h),c=y=0,u=a.length;c<u;c++)d=a[c],f.set(d,y),y+=d.length;return f}},r={arraySet:function(a,c,u,h,y){for(var d=0;d<h;d++)a[y+d]=c[u+d]},flattenChunks:function(a){return[].concat.apply([],a)}};n.setTyped=function(a){a?(n.Buf8=Uint8Array,n.Buf16=Uint16Array,n.Buf32=Int32Array,n.assign(n,l)):(n.Buf8=Array,n.Buf16=Array,n.Buf32=Array,n.assign(n,r))},n.setTyped(s)},{}],42:[function(o,i,n){var s=o("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new s.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function u(h,y){if(y<65537&&(h.subarray&&r||!h.subarray&&l))return String.fromCharCode.apply(null,s.shrinkBuf(h,y));for(var d="",f=0;f<y;f++)d+=String.fromCharCode(h[f]);return d}a[254]=a[254]=1,n.string2buf=function(h){var y,d,f,p,g,b=h.length,k=0;for(p=0;p<b;p++)(64512&(d=h.charCodeAt(p)))==55296&&p+1<b&&(64512&(f=h.charCodeAt(p+1)))==56320&&(d=65536+(d-55296<<10)+(f-56320),p++),k+=d<128?1:d<2048?2:d<65536?3:4;for(y=new s.Buf8(k),p=g=0;g<k;p++)(64512&(d=h.charCodeAt(p)))==55296&&p+1<b&&(64512&(f=h.charCodeAt(p+1)))==56320&&(d=65536+(d-55296<<10)+(f-56320),p++),d<128?y[g++]=d:(d<2048?y[g++]=192|d>>>6:(d<65536?y[g++]=224|d>>>12:(y[g++]=240|d>>>18,y[g++]=128|d>>>12&63),y[g++]=128|d>>>6&63),y[g++]=128|63&d);return y},n.buf2binstring=function(h){return u(h,h.length)},n.binstring2buf=function(h){for(var y=new s.Buf8(h.length),d=0,f=y.length;d<f;d++)y[d]=h.charCodeAt(d);return y},n.buf2string=function(h,y){var d,f,p,g,b=y||h.length,k=new Array(2*b);for(d=f=0;d<b;)if((p=h[d++])<128)k[f++]=p;else if(4<(g=a[p]))k[f++]=65533,d+=g-1;else{for(p&=g===2?31:g===3?15:7;1<g&&d<b;)p=p<<6|63&h[d++],g--;1<g?k[f++]=65533:p<65536?k[f++]=p:(p-=65536,k[f++]=55296|p>>10&1023,k[f++]=56320|1023&p)}return u(k,f)},n.utf8border=function(h,y){var d;for((y=y||h.length)>h.length&&(y=h.length),d=y-1;0<=d&&(192&h[d])==128;)d--;return d<0||d===0?y:d+a[h[d]]>y?d:y}},{"./common":41}],43:[function(o,i,n){i.exports=function(s,l,r,a){for(var c=65535&s|0,u=s>>>16&65535|0,h=0;r!==0;){for(r-=h=2e3<r?2e3:r;u=u+(c=c+l[a++]|0)|0,--h;);c%=65521,u%=65521}return c|u<<16|0}},{}],44:[function(o,i,n){i.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(o,i,n){var s=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();i.exports=function(l,r,a,c){var u=s,h=c+a;l^=-1;for(var y=c;y<h;y++)l=l>>>8^u[255&(l^r[y])];return-1^l}},{}],46:[function(o,i,n){var s,l=o("../utils/common"),r=o("./trees"),a=o("./adler32"),c=o("./crc32"),u=o("./messages"),h=0,y=4,d=0,f=-2,p=-1,g=4,b=2,k=8,w=9,_=286,M=30,A=19,I=2*_+1,N=15,H=3,z=258,j=z+H+1,B=42,D=113,x=1,V=2,W=3,$=4;function T(v,U){return v.msg=u[U],U}function O(v){return(v<<1)-(4<v?9:0)}function te(v){for(var U=v.length;0<=--U;)v[U]=0}function K(v){var U=v.state,R=U.pending;R>v.avail_out&&(R=v.avail_out),R!==0&&(l.arraySet(v.output,U.pending_buf,U.pending_out,R,v.next_out),v.next_out+=R,U.pending_out+=R,v.total_out+=R,v.avail_out-=R,U.pending-=R,U.pending===0&&(U.pending_out=0))}function Z(v,U){r._tr_flush_block(v,0<=v.block_start?v.block_start:-1,v.strstart-v.block_start,U),v.block_start=v.strstart,K(v.strm)}function ce(v,U){v.pending_buf[v.pending++]=U}function oe(v,U){v.pending_buf[v.pending++]=U>>>8&255,v.pending_buf[v.pending++]=255&U}function re(v,U){var R,S,C=v.max_chain_length,L=v.strstart,G=v.prev_length,q=v.nice_match,Y=v.strstart>v.w_size-j?v.strstart-(v.w_size-j):0,X=v.window,ae=v.w_mask,ne=v.prev,me=v.strstart+z,Ce=X[L+G-1],we=X[L+G];v.prev_length>=v.good_match&&(C>>=2),q>v.lookahead&&(q=v.lookahead);do if(X[(R=U)+G]===we&&X[R+G-1]===Ce&&X[R]===X[L]&&X[++R]===X[L+1]){L+=2,R++;do;while(X[++L]===X[++R]&&X[++L]===X[++R]&&X[++L]===X[++R]&&X[++L]===X[++R]&&X[++L]===X[++R]&&X[++L]===X[++R]&&X[++L]===X[++R]&&X[++L]===X[++R]&&L<me);if(S=z-(me-L),L=me-z,G<S){if(v.match_start=U,q<=(G=S))break;Ce=X[L+G-1],we=X[L+G]}}while((U=ne[U&ae])>Y&&--C!=0);return G<=v.lookahead?G:v.lookahead}function Se(v){var U,R,S,C,L,G,q,Y,X,ae,ne=v.w_size;do{if(C=v.window_size-v.lookahead-v.strstart,v.strstart>=ne+(ne-j)){for(l.arraySet(v.window,v.window,ne,ne,0),v.match_start-=ne,v.strstart-=ne,v.block_start-=ne,U=R=v.hash_size;S=v.head[--U],v.head[U]=ne<=S?S-ne:0,--R;);for(U=R=ne;S=v.prev[--U],v.prev[U]=ne<=S?S-ne:0,--R;);C+=ne}if(v.strm.avail_in===0)break;if(G=v.strm,q=v.window,Y=v.strstart+v.lookahead,X=C,ae=void 0,ae=G.avail_in,X<ae&&(ae=X),R=ae===0?0:(G.avail_in-=ae,l.arraySet(q,G.input,G.next_in,ae,Y),G.state.wrap===1?G.adler=a(G.adler,q,ae,Y):G.state.wrap===2&&(G.adler=c(G.adler,q,ae,Y)),G.next_in+=ae,G.total_in+=ae,ae),v.lookahead+=R,v.lookahead+v.insert>=H)for(L=v.strstart-v.insert,v.ins_h=v.window[L],v.ins_h=(v.ins_h<<v.hash_shift^v.window[L+1])&v.hash_mask;v.insert&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[L+H-1])&v.hash_mask,v.prev[L&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=L,L++,v.insert--,!(v.lookahead+v.insert<H)););}while(v.lookahead<j&&v.strm.avail_in!==0)}function Ie(v,U){for(var R,S;;){if(v.lookahead<j){if(Se(v),v.lookahead<j&&U===h)return x;if(v.lookahead===0)break}if(R=0,v.lookahead>=H&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+H-1])&v.hash_mask,R=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),R!==0&&v.strstart-R<=v.w_size-j&&(v.match_length=re(v,R)),v.match_length>=H)if(S=r._tr_tally(v,v.strstart-v.match_start,v.match_length-H),v.lookahead-=v.match_length,v.match_length<=v.max_lazy_match&&v.lookahead>=H){for(v.match_length--;v.strstart++,v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+H-1])&v.hash_mask,R=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart,--v.match_length!=0;);v.strstart++}else v.strstart+=v.match_length,v.match_length=0,v.ins_h=v.window[v.strstart],v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+1])&v.hash_mask;else S=r._tr_tally(v,0,v.window[v.strstart]),v.lookahead--,v.strstart++;if(S&&(Z(v,!1),v.strm.avail_out===0))return x}return v.insert=v.strstart<H-1?v.strstart:H-1,U===y?(Z(v,!0),v.strm.avail_out===0?W:$):v.last_lit&&(Z(v,!1),v.strm.avail_out===0)?x:V}function ve(v,U){for(var R,S,C;;){if(v.lookahead<j){if(Se(v),v.lookahead<j&&U===h)return x;if(v.lookahead===0)break}if(R=0,v.lookahead>=H&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+H-1])&v.hash_mask,R=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),v.prev_length=v.match_length,v.prev_match=v.match_start,v.match_length=H-1,R!==0&&v.prev_length<v.max_lazy_match&&v.strstart-R<=v.w_size-j&&(v.match_length=re(v,R),v.match_length<=5&&(v.strategy===1||v.match_length===H&&4096<v.strstart-v.match_start)&&(v.match_length=H-1)),v.prev_length>=H&&v.match_length<=v.prev_length){for(C=v.strstart+v.lookahead-H,S=r._tr_tally(v,v.strstart-1-v.prev_match,v.prev_length-H),v.lookahead-=v.prev_length-1,v.prev_length-=2;++v.strstart<=C&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+H-1])&v.hash_mask,R=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),--v.prev_length!=0;);if(v.match_available=0,v.match_length=H-1,v.strstart++,S&&(Z(v,!1),v.strm.avail_out===0))return x}else if(v.match_available){if((S=r._tr_tally(v,0,v.window[v.strstart-1]))&&Z(v,!1),v.strstart++,v.lookahead--,v.strm.avail_out===0)return x}else v.match_available=1,v.strstart++,v.lookahead--}return v.match_available&&(S=r._tr_tally(v,0,v.window[v.strstart-1]),v.match_available=0),v.insert=v.strstart<H-1?v.strstart:H-1,U===y?(Z(v,!0),v.strm.avail_out===0?W:$):v.last_lit&&(Z(v,!1),v.strm.avail_out===0)?x:V}function _e(v,U,R,S,C){this.good_length=v,this.max_lazy=U,this.nice_length=R,this.max_chain=S,this.func=C}function P(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=k,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*I),this.dyn_dtree=new l.Buf16(2*(2*M+1)),this.bl_tree=new l.Buf16(2*(2*A+1)),te(this.dyn_ltree),te(this.dyn_dtree),te(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(N+1),this.heap=new l.Buf16(2*_+1),te(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*_+1),te(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ie(v){var U;return v&&v.state?(v.total_in=v.total_out=0,v.data_type=b,(U=v.state).pending=0,U.pending_out=0,U.wrap<0&&(U.wrap=-U.wrap),U.status=U.wrap?B:D,v.adler=U.wrap===2?0:1,U.last_flush=h,r._tr_init(U),d):T(v,f)}function E(v){var U=ie(v);return U===d&&(function(R){R.window_size=2*R.w_size,te(R.head),R.max_lazy_match=s[R.level].max_lazy,R.good_match=s[R.level].good_length,R.nice_match=s[R.level].nice_length,R.max_chain_length=s[R.level].max_chain,R.strstart=0,R.block_start=0,R.lookahead=0,R.insert=0,R.match_length=R.prev_length=H-1,R.match_available=0,R.ins_h=0})(v.state),U}function F(v,U,R,S,C,L){if(!v)return f;var G=1;if(U===p&&(U=6),S<0?(G=0,S=-S):15<S&&(G=2,S-=16),C<1||w<C||R!==k||S<8||15<S||U<0||9<U||L<0||g<L)return T(v,f);S===8&&(S=9);var q=new P;return(v.state=q).strm=v,q.wrap=G,q.gzhead=null,q.w_bits=S,q.w_size=1<<q.w_bits,q.w_mask=q.w_size-1,q.hash_bits=C+7,q.hash_size=1<<q.hash_bits,q.hash_mask=q.hash_size-1,q.hash_shift=~~((q.hash_bits+H-1)/H),q.window=new l.Buf8(2*q.w_size),q.head=new l.Buf16(q.hash_size),q.prev=new l.Buf16(q.w_size),q.lit_bufsize=1<<C+6,q.pending_buf_size=4*q.lit_bufsize,q.pending_buf=new l.Buf8(q.pending_buf_size),q.d_buf=1*q.lit_bufsize,q.l_buf=3*q.lit_bufsize,q.level=U,q.strategy=L,q.method=R,E(v)}s=[new _e(0,0,0,0,function(v,U){var R=65535;for(R>v.pending_buf_size-5&&(R=v.pending_buf_size-5);;){if(v.lookahead<=1){if(Se(v),v.lookahead===0&&U===h)return x;if(v.lookahead===0)break}v.strstart+=v.lookahead,v.lookahead=0;var S=v.block_start+R;if((v.strstart===0||v.strstart>=S)&&(v.lookahead=v.strstart-S,v.strstart=S,Z(v,!1),v.strm.avail_out===0)||v.strstart-v.block_start>=v.w_size-j&&(Z(v,!1),v.strm.avail_out===0))return x}return v.insert=0,U===y?(Z(v,!0),v.strm.avail_out===0?W:$):(v.strstart>v.block_start&&(Z(v,!1),v.strm.avail_out),x)}),new _e(4,4,8,4,Ie),new _e(4,5,16,8,Ie),new _e(4,6,32,32,Ie),new _e(4,4,16,16,ve),new _e(8,16,32,32,ve),new _e(8,16,128,128,ve),new _e(8,32,128,256,ve),new _e(32,128,258,1024,ve),new _e(32,258,258,4096,ve)],n.deflateInit=function(v,U){return F(v,U,k,15,8,0)},n.deflateInit2=F,n.deflateReset=E,n.deflateResetKeep=ie,n.deflateSetHeader=function(v,U){return v&&v.state?v.state.wrap!==2?f:(v.state.gzhead=U,d):f},n.deflate=function(v,U){var R,S,C,L;if(!v||!v.state||5<U||U<0)return v?T(v,f):f;if(S=v.state,!v.output||!v.input&&v.avail_in!==0||S.status===666&&U!==y)return T(v,v.avail_out===0?-5:f);if(S.strm=v,R=S.last_flush,S.last_flush=U,S.status===B)if(S.wrap===2)v.adler=0,ce(S,31),ce(S,139),ce(S,8),S.gzhead?(ce(S,(S.gzhead.text?1:0)+(S.gzhead.hcrc?2:0)+(S.gzhead.extra?4:0)+(S.gzhead.name?8:0)+(S.gzhead.comment?16:0)),ce(S,255&S.gzhead.time),ce(S,S.gzhead.time>>8&255),ce(S,S.gzhead.time>>16&255),ce(S,S.gzhead.time>>24&255),ce(S,S.level===9?2:2<=S.strategy||S.level<2?4:0),ce(S,255&S.gzhead.os),S.gzhead.extra&&S.gzhead.extra.length&&(ce(S,255&S.gzhead.extra.length),ce(S,S.gzhead.extra.length>>8&255)),S.gzhead.hcrc&&(v.adler=c(v.adler,S.pending_buf,S.pending,0)),S.gzindex=0,S.status=69):(ce(S,0),ce(S,0),ce(S,0),ce(S,0),ce(S,0),ce(S,S.level===9?2:2<=S.strategy||S.level<2?4:0),ce(S,3),S.status=D);else{var G=k+(S.w_bits-8<<4)<<8;G|=(2<=S.strategy||S.level<2?0:S.level<6?1:S.level===6?2:3)<<6,S.strstart!==0&&(G|=32),G+=31-G%31,S.status=D,oe(S,G),S.strstart!==0&&(oe(S,v.adler>>>16),oe(S,65535&v.adler)),v.adler=1}if(S.status===69)if(S.gzhead.extra){for(C=S.pending;S.gzindex<(65535&S.gzhead.extra.length)&&(S.pending!==S.pending_buf_size||(S.gzhead.hcrc&&S.pending>C&&(v.adler=c(v.adler,S.pending_buf,S.pending-C,C)),K(v),C=S.pending,S.pending!==S.pending_buf_size));)ce(S,255&S.gzhead.extra[S.gzindex]),S.gzindex++;S.gzhead.hcrc&&S.pending>C&&(v.adler=c(v.adler,S.pending_buf,S.pending-C,C)),S.gzindex===S.gzhead.extra.length&&(S.gzindex=0,S.status=73)}else S.status=73;if(S.status===73)if(S.gzhead.name){C=S.pending;do{if(S.pending===S.pending_buf_size&&(S.gzhead.hcrc&&S.pending>C&&(v.adler=c(v.adler,S.pending_buf,S.pending-C,C)),K(v),C=S.pending,S.pending===S.pending_buf_size)){L=1;break}L=S.gzindex<S.gzhead.name.length?255&S.gzhead.name.charCodeAt(S.gzindex++):0,ce(S,L)}while(L!==0);S.gzhead.hcrc&&S.pending>C&&(v.adler=c(v.adler,S.pending_buf,S.pending-C,C)),L===0&&(S.gzindex=0,S.status=91)}else S.status=91;if(S.status===91)if(S.gzhead.comment){C=S.pending;do{if(S.pending===S.pending_buf_size&&(S.gzhead.hcrc&&S.pending>C&&(v.adler=c(v.adler,S.pending_buf,S.pending-C,C)),K(v),C=S.pending,S.pending===S.pending_buf_size)){L=1;break}L=S.gzindex<S.gzhead.comment.length?255&S.gzhead.comment.charCodeAt(S.gzindex++):0,ce(S,L)}while(L!==0);S.gzhead.hcrc&&S.pending>C&&(v.adler=c(v.adler,S.pending_buf,S.pending-C,C)),L===0&&(S.status=103)}else S.status=103;if(S.status===103&&(S.gzhead.hcrc?(S.pending+2>S.pending_buf_size&&K(v),S.pending+2<=S.pending_buf_size&&(ce(S,255&v.adler),ce(S,v.adler>>8&255),v.adler=0,S.status=D)):S.status=D),S.pending!==0){if(K(v),v.avail_out===0)return S.last_flush=-1,d}else if(v.avail_in===0&&O(U)<=O(R)&&U!==y)return T(v,-5);if(S.status===666&&v.avail_in!==0)return T(v,-5);if(v.avail_in!==0||S.lookahead!==0||U!==h&&S.status!==666){var q=S.strategy===2?(function(Y,X){for(var ae;;){if(Y.lookahead===0&&(Se(Y),Y.lookahead===0)){if(X===h)return x;break}if(Y.match_length=0,ae=r._tr_tally(Y,0,Y.window[Y.strstart]),Y.lookahead--,Y.strstart++,ae&&(Z(Y,!1),Y.strm.avail_out===0))return x}return Y.insert=0,X===y?(Z(Y,!0),Y.strm.avail_out===0?W:$):Y.last_lit&&(Z(Y,!1),Y.strm.avail_out===0)?x:V})(S,U):S.strategy===3?(function(Y,X){for(var ae,ne,me,Ce,we=Y.window;;){if(Y.lookahead<=z){if(Se(Y),Y.lookahead<=z&&X===h)return x;if(Y.lookahead===0)break}if(Y.match_length=0,Y.lookahead>=H&&0<Y.strstart&&(ne=we[me=Y.strstart-1])===we[++me]&&ne===we[++me]&&ne===we[++me]){Ce=Y.strstart+z;do;while(ne===we[++me]&&ne===we[++me]&&ne===we[++me]&&ne===we[++me]&&ne===we[++me]&&ne===we[++me]&&ne===we[++me]&&ne===we[++me]&&me<Ce);Y.match_length=z-(Ce-me),Y.match_length>Y.lookahead&&(Y.match_length=Y.lookahead)}if(Y.match_length>=H?(ae=r._tr_tally(Y,1,Y.match_length-H),Y.lookahead-=Y.match_length,Y.strstart+=Y.match_length,Y.match_length=0):(ae=r._tr_tally(Y,0,Y.window[Y.strstart]),Y.lookahead--,Y.strstart++),ae&&(Z(Y,!1),Y.strm.avail_out===0))return x}return Y.insert=0,X===y?(Z(Y,!0),Y.strm.avail_out===0?W:$):Y.last_lit&&(Z(Y,!1),Y.strm.avail_out===0)?x:V})(S,U):s[S.level].func(S,U);if(q!==W&&q!==$||(S.status=666),q===x||q===W)return v.avail_out===0&&(S.last_flush=-1),d;if(q===V&&(U===1?r._tr_align(S):U!==5&&(r._tr_stored_block(S,0,0,!1),U===3&&(te(S.head),S.lookahead===0&&(S.strstart=0,S.block_start=0,S.insert=0))),K(v),v.avail_out===0))return S.last_flush=-1,d}return U!==y?d:S.wrap<=0?1:(S.wrap===2?(ce(S,255&v.adler),ce(S,v.adler>>8&255),ce(S,v.adler>>16&255),ce(S,v.adler>>24&255),ce(S,255&v.total_in),ce(S,v.total_in>>8&255),ce(S,v.total_in>>16&255),ce(S,v.total_in>>24&255)):(oe(S,v.adler>>>16),oe(S,65535&v.adler)),K(v),0<S.wrap&&(S.wrap=-S.wrap),S.pending!==0?d:1)},n.deflateEnd=function(v){var U;return v&&v.state?(U=v.state.status)!==B&&U!==69&&U!==73&&U!==91&&U!==103&&U!==D&&U!==666?T(v,f):(v.state=null,U===D?T(v,-3):d):f},n.deflateSetDictionary=function(v,U){var R,S,C,L,G,q,Y,X,ae=U.length;if(!v||!v.state||(L=(R=v.state).wrap)===2||L===1&&R.status!==B||R.lookahead)return f;for(L===1&&(v.adler=a(v.adler,U,ae,0)),R.wrap=0,ae>=R.w_size&&(L===0&&(te(R.head),R.strstart=0,R.block_start=0,R.insert=0),X=new l.Buf8(R.w_size),l.arraySet(X,U,ae-R.w_size,R.w_size,0),U=X,ae=R.w_size),G=v.avail_in,q=v.next_in,Y=v.input,v.avail_in=ae,v.next_in=0,v.input=U,Se(R);R.lookahead>=H;){for(S=R.strstart,C=R.lookahead-(H-1);R.ins_h=(R.ins_h<<R.hash_shift^R.window[S+H-1])&R.hash_mask,R.prev[S&R.w_mask]=R.head[R.ins_h],R.head[R.ins_h]=S,S++,--C;);R.strstart=S,R.lookahead=H-1,Se(R)}return R.strstart+=R.lookahead,R.block_start=R.strstart,R.insert=R.lookahead,R.lookahead=0,R.match_length=R.prev_length=H-1,R.match_available=0,v.next_in=q,v.input=Y,v.avail_in=G,R.wrap=L,d},n.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(o,i,n){i.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(o,i,n){i.exports=function(s,l){var r,a,c,u,h,y,d,f,p,g,b,k,w,_,M,A,I,N,H,z,j,B,D,x,V;r=s.state,a=s.next_in,x=s.input,c=a+(s.avail_in-5),u=s.next_out,V=s.output,h=u-(l-s.avail_out),y=u+(s.avail_out-257),d=r.dmax,f=r.wsize,p=r.whave,g=r.wnext,b=r.window,k=r.hold,w=r.bits,_=r.lencode,M=r.distcode,A=(1<<r.lenbits)-1,I=(1<<r.distbits)-1;e:do{w<15&&(k+=x[a++]<<w,w+=8,k+=x[a++]<<w,w+=8),N=_[k&A];t:for(;;){if(k>>>=H=N>>>24,w-=H,(H=N>>>16&255)===0)V[u++]=65535&N;else{if(!(16&H)){if((64&H)==0){N=_[(65535&N)+(k&(1<<H)-1)];continue t}if(32&H){r.mode=12;break e}s.msg="invalid literal/length code",r.mode=30;break e}z=65535&N,(H&=15)&&(w<H&&(k+=x[a++]<<w,w+=8),z+=k&(1<<H)-1,k>>>=H,w-=H),w<15&&(k+=x[a++]<<w,w+=8,k+=x[a++]<<w,w+=8),N=M[k&I];o:for(;;){if(k>>>=H=N>>>24,w-=H,!(16&(H=N>>>16&255))){if((64&H)==0){N=M[(65535&N)+(k&(1<<H)-1)];continue o}s.msg="invalid distance code",r.mode=30;break e}if(j=65535&N,w<(H&=15)&&(k+=x[a++]<<w,(w+=8)<H&&(k+=x[a++]<<w,w+=8)),d<(j+=k&(1<<H)-1)){s.msg="invalid distance too far back",r.mode=30;break e}if(k>>>=H,w-=H,(H=u-h)<j){if(p<(H=j-H)&&r.sane){s.msg="invalid distance too far back",r.mode=30;break e}if(D=b,(B=0)===g){if(B+=f-H,H<z){for(z-=H;V[u++]=b[B++],--H;);B=u-j,D=V}}else if(g<H){if(B+=f+g-H,(H-=g)<z){for(z-=H;V[u++]=b[B++],--H;);if(B=0,g<z){for(z-=H=g;V[u++]=b[B++],--H;);B=u-j,D=V}}}else if(B+=g-H,H<z){for(z-=H;V[u++]=b[B++],--H;);B=u-j,D=V}for(;2<z;)V[u++]=D[B++],V[u++]=D[B++],V[u++]=D[B++],z-=3;z&&(V[u++]=D[B++],1<z&&(V[u++]=D[B++]))}else{for(B=u-j;V[u++]=V[B++],V[u++]=V[B++],V[u++]=V[B++],2<(z-=3););z&&(V[u++]=V[B++],1<z&&(V[u++]=V[B++]))}break}}break}}while(a<c&&u<y);a-=z=w>>3,k&=(1<<(w-=z<<3))-1,s.next_in=a,s.next_out=u,s.avail_in=a<c?c-a+5:5-(a-c),s.avail_out=u<y?y-u+257:257-(u-y),r.hold=k,r.bits=w}},{}],49:[function(o,i,n){var s=o("../utils/common"),l=o("./adler32"),r=o("./crc32"),a=o("./inffast"),c=o("./inftrees"),u=1,h=2,y=0,d=-2,f=1,p=852,g=592;function b(B){return(B>>>24&255)+(B>>>8&65280)+((65280&B)<<8)+((255&B)<<24)}function k(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new s.Buf16(320),this.work=new s.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function w(B){var D;return B&&B.state?(D=B.state,B.total_in=B.total_out=D.total=0,B.msg="",D.wrap&&(B.adler=1&D.wrap),D.mode=f,D.last=0,D.havedict=0,D.dmax=32768,D.head=null,D.hold=0,D.bits=0,D.lencode=D.lendyn=new s.Buf32(p),D.distcode=D.distdyn=new s.Buf32(g),D.sane=1,D.back=-1,y):d}function _(B){var D;return B&&B.state?((D=B.state).wsize=0,D.whave=0,D.wnext=0,w(B)):d}function M(B,D){var x,V;return B&&B.state?(V=B.state,D<0?(x=0,D=-D):(x=1+(D>>4),D<48&&(D&=15)),D&&(D<8||15<D)?d:(V.window!==null&&V.wbits!==D&&(V.window=null),V.wrap=x,V.wbits=D,_(B))):d}function A(B,D){var x,V;return B?(V=new k,(B.state=V).window=null,(x=M(B,D))!==y&&(B.state=null),x):d}var I,N,H=!0;function z(B){if(H){var D;for(I=new s.Buf32(512),N=new s.Buf32(32),D=0;D<144;)B.lens[D++]=8;for(;D<256;)B.lens[D++]=9;for(;D<280;)B.lens[D++]=7;for(;D<288;)B.lens[D++]=8;for(c(u,B.lens,0,288,I,0,B.work,{bits:9}),D=0;D<32;)B.lens[D++]=5;c(h,B.lens,0,32,N,0,B.work,{bits:5}),H=!1}B.lencode=I,B.lenbits=9,B.distcode=N,B.distbits=5}function j(B,D,x,V){var W,$=B.state;return $.window===null&&($.wsize=1<<$.wbits,$.wnext=0,$.whave=0,$.window=new s.Buf8($.wsize)),V>=$.wsize?(s.arraySet($.window,D,x-$.wsize,$.wsize,0),$.wnext=0,$.whave=$.wsize):(V<(W=$.wsize-$.wnext)&&(W=V),s.arraySet($.window,D,x-V,W,$.wnext),(V-=W)?(s.arraySet($.window,D,x-V,V,0),$.wnext=V,$.whave=$.wsize):($.wnext+=W,$.wnext===$.wsize&&($.wnext=0),$.whave<$.wsize&&($.whave+=W))),0}n.inflateReset=_,n.inflateReset2=M,n.inflateResetKeep=w,n.inflateInit=function(B){return A(B,15)},n.inflateInit2=A,n.inflate=function(B,D){var x,V,W,$,T,O,te,K,Z,ce,oe,re,Se,Ie,ve,_e,P,ie,E,F,v,U,R,S,C=0,L=new s.Buf8(4),G=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!B||!B.state||!B.output||!B.input&&B.avail_in!==0)return d;(x=B.state).mode===12&&(x.mode=13),T=B.next_out,W=B.output,te=B.avail_out,$=B.next_in,V=B.input,O=B.avail_in,K=x.hold,Z=x.bits,ce=O,oe=te,U=y;e:for(;;)switch(x.mode){case f:if(x.wrap===0){x.mode=13;break}for(;Z<16;){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}if(2&x.wrap&&K===35615){L[x.check=0]=255&K,L[1]=K>>>8&255,x.check=r(x.check,L,2,0),Z=K=0,x.mode=2;break}if(x.flags=0,x.head&&(x.head.done=!1),!(1&x.wrap)||(((255&K)<<8)+(K>>8))%31){B.msg="incorrect header check",x.mode=30;break}if((15&K)!=8){B.msg="unknown compression method",x.mode=30;break}if(Z-=4,v=8+(15&(K>>>=4)),x.wbits===0)x.wbits=v;else if(v>x.wbits){B.msg="invalid window size",x.mode=30;break}x.dmax=1<<v,B.adler=x.check=1,x.mode=512&K?10:12,Z=K=0;break;case 2:for(;Z<16;){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}if(x.flags=K,(255&x.flags)!=8){B.msg="unknown compression method",x.mode=30;break}if(57344&x.flags){B.msg="unknown header flags set",x.mode=30;break}x.head&&(x.head.text=K>>8&1),512&x.flags&&(L[0]=255&K,L[1]=K>>>8&255,x.check=r(x.check,L,2,0)),Z=K=0,x.mode=3;case 3:for(;Z<32;){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}x.head&&(x.head.time=K),512&x.flags&&(L[0]=255&K,L[1]=K>>>8&255,L[2]=K>>>16&255,L[3]=K>>>24&255,x.check=r(x.check,L,4,0)),Z=K=0,x.mode=4;case 4:for(;Z<16;){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}x.head&&(x.head.xflags=255&K,x.head.os=K>>8),512&x.flags&&(L[0]=255&K,L[1]=K>>>8&255,x.check=r(x.check,L,2,0)),Z=K=0,x.mode=5;case 5:if(1024&x.flags){for(;Z<16;){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}x.length=K,x.head&&(x.head.extra_len=K),512&x.flags&&(L[0]=255&K,L[1]=K>>>8&255,x.check=r(x.check,L,2,0)),Z=K=0}else x.head&&(x.head.extra=null);x.mode=6;case 6:if(1024&x.flags&&(O<(re=x.length)&&(re=O),re&&(x.head&&(v=x.head.extra_len-x.length,x.head.extra||(x.head.extra=new Array(x.head.extra_len)),s.arraySet(x.head.extra,V,$,re,v)),512&x.flags&&(x.check=r(x.check,V,re,$)),O-=re,$+=re,x.length-=re),x.length))break e;x.length=0,x.mode=7;case 7:if(2048&x.flags){if(O===0)break e;for(re=0;v=V[$+re++],x.head&&v&&x.length<65536&&(x.head.name+=String.fromCharCode(v)),v&&re<O;);if(512&x.flags&&(x.check=r(x.check,V,re,$)),O-=re,$+=re,v)break e}else x.head&&(x.head.name=null);x.length=0,x.mode=8;case 8:if(4096&x.flags){if(O===0)break e;for(re=0;v=V[$+re++],x.head&&v&&x.length<65536&&(x.head.comment+=String.fromCharCode(v)),v&&re<O;);if(512&x.flags&&(x.check=r(x.check,V,re,$)),O-=re,$+=re,v)break e}else x.head&&(x.head.comment=null);x.mode=9;case 9:if(512&x.flags){for(;Z<16;){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}if(K!==(65535&x.check)){B.msg="header crc mismatch",x.mode=30;break}Z=K=0}x.head&&(x.head.hcrc=x.flags>>9&1,x.head.done=!0),B.adler=x.check=0,x.mode=12;break;case 10:for(;Z<32;){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}B.adler=x.check=b(K),Z=K=0,x.mode=11;case 11:if(x.havedict===0)return B.next_out=T,B.avail_out=te,B.next_in=$,B.avail_in=O,x.hold=K,x.bits=Z,2;B.adler=x.check=1,x.mode=12;case 12:if(D===5||D===6)break e;case 13:if(x.last){K>>>=7&Z,Z-=7&Z,x.mode=27;break}for(;Z<3;){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}switch(x.last=1&K,Z-=1,3&(K>>>=1)){case 0:x.mode=14;break;case 1:if(z(x),x.mode=20,D!==6)break;K>>>=2,Z-=2;break e;case 2:x.mode=17;break;case 3:B.msg="invalid block type",x.mode=30}K>>>=2,Z-=2;break;case 14:for(K>>>=7&Z,Z-=7&Z;Z<32;){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}if((65535&K)!=(K>>>16^65535)){B.msg="invalid stored block lengths",x.mode=30;break}if(x.length=65535&K,Z=K=0,x.mode=15,D===6)break e;case 15:x.mode=16;case 16:if(re=x.length){if(O<re&&(re=O),te<re&&(re=te),re===0)break e;s.arraySet(W,V,$,re,T),O-=re,$+=re,te-=re,T+=re,x.length-=re;break}x.mode=12;break;case 17:for(;Z<14;){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}if(x.nlen=257+(31&K),K>>>=5,Z-=5,x.ndist=1+(31&K),K>>>=5,Z-=5,x.ncode=4+(15&K),K>>>=4,Z-=4,286<x.nlen||30<x.ndist){B.msg="too many length or distance symbols",x.mode=30;break}x.have=0,x.mode=18;case 18:for(;x.have<x.ncode;){for(;Z<3;){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}x.lens[G[x.have++]]=7&K,K>>>=3,Z-=3}for(;x.have<19;)x.lens[G[x.have++]]=0;if(x.lencode=x.lendyn,x.lenbits=7,R={bits:x.lenbits},U=c(0,x.lens,0,19,x.lencode,0,x.work,R),x.lenbits=R.bits,U){B.msg="invalid code lengths set",x.mode=30;break}x.have=0,x.mode=19;case 19:for(;x.have<x.nlen+x.ndist;){for(;_e=(C=x.lencode[K&(1<<x.lenbits)-1])>>>16&255,P=65535&C,!((ve=C>>>24)<=Z);){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}if(P<16)K>>>=ve,Z-=ve,x.lens[x.have++]=P;else{if(P===16){for(S=ve+2;Z<S;){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}if(K>>>=ve,Z-=ve,x.have===0){B.msg="invalid bit length repeat",x.mode=30;break}v=x.lens[x.have-1],re=3+(3&K),K>>>=2,Z-=2}else if(P===17){for(S=ve+3;Z<S;){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}Z-=ve,v=0,re=3+(7&(K>>>=ve)),K>>>=3,Z-=3}else{for(S=ve+7;Z<S;){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}Z-=ve,v=0,re=11+(127&(K>>>=ve)),K>>>=7,Z-=7}if(x.have+re>x.nlen+x.ndist){B.msg="invalid bit length repeat",x.mode=30;break}for(;re--;)x.lens[x.have++]=v}}if(x.mode===30)break;if(x.lens[256]===0){B.msg="invalid code -- missing end-of-block",x.mode=30;break}if(x.lenbits=9,R={bits:x.lenbits},U=c(u,x.lens,0,x.nlen,x.lencode,0,x.work,R),x.lenbits=R.bits,U){B.msg="invalid literal/lengths set",x.mode=30;break}if(x.distbits=6,x.distcode=x.distdyn,R={bits:x.distbits},U=c(h,x.lens,x.nlen,x.ndist,x.distcode,0,x.work,R),x.distbits=R.bits,U){B.msg="invalid distances set",x.mode=30;break}if(x.mode=20,D===6)break e;case 20:x.mode=21;case 21:if(6<=O&&258<=te){B.next_out=T,B.avail_out=te,B.next_in=$,B.avail_in=O,x.hold=K,x.bits=Z,a(B,oe),T=B.next_out,W=B.output,te=B.avail_out,$=B.next_in,V=B.input,O=B.avail_in,K=x.hold,Z=x.bits,x.mode===12&&(x.back=-1);break}for(x.back=0;_e=(C=x.lencode[K&(1<<x.lenbits)-1])>>>16&255,P=65535&C,!((ve=C>>>24)<=Z);){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}if(_e&&(240&_e)==0){for(ie=ve,E=_e,F=P;_e=(C=x.lencode[F+((K&(1<<ie+E)-1)>>ie)])>>>16&255,P=65535&C,!(ie+(ve=C>>>24)<=Z);){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}K>>>=ie,Z-=ie,x.back+=ie}if(K>>>=ve,Z-=ve,x.back+=ve,x.length=P,_e===0){x.mode=26;break}if(32&_e){x.back=-1,x.mode=12;break}if(64&_e){B.msg="invalid literal/length code",x.mode=30;break}x.extra=15&_e,x.mode=22;case 22:if(x.extra){for(S=x.extra;Z<S;){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}x.length+=K&(1<<x.extra)-1,K>>>=x.extra,Z-=x.extra,x.back+=x.extra}x.was=x.length,x.mode=23;case 23:for(;_e=(C=x.distcode[K&(1<<x.distbits)-1])>>>16&255,P=65535&C,!((ve=C>>>24)<=Z);){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}if((240&_e)==0){for(ie=ve,E=_e,F=P;_e=(C=x.distcode[F+((K&(1<<ie+E)-1)>>ie)])>>>16&255,P=65535&C,!(ie+(ve=C>>>24)<=Z);){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}K>>>=ie,Z-=ie,x.back+=ie}if(K>>>=ve,Z-=ve,x.back+=ve,64&_e){B.msg="invalid distance code",x.mode=30;break}x.offset=P,x.extra=15&_e,x.mode=24;case 24:if(x.extra){for(S=x.extra;Z<S;){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}x.offset+=K&(1<<x.extra)-1,K>>>=x.extra,Z-=x.extra,x.back+=x.extra}if(x.offset>x.dmax){B.msg="invalid distance too far back",x.mode=30;break}x.mode=25;case 25:if(te===0)break e;if(re=oe-te,x.offset>re){if((re=x.offset-re)>x.whave&&x.sane){B.msg="invalid distance too far back",x.mode=30;break}Se=re>x.wnext?(re-=x.wnext,x.wsize-re):x.wnext-re,re>x.length&&(re=x.length),Ie=x.window}else Ie=W,Se=T-x.offset,re=x.length;for(te<re&&(re=te),te-=re,x.length-=re;W[T++]=Ie[Se++],--re;);x.length===0&&(x.mode=21);break;case 26:if(te===0)break e;W[T++]=x.length,te--,x.mode=21;break;case 27:if(x.wrap){for(;Z<32;){if(O===0)break e;O--,K|=V[$++]<<Z,Z+=8}if(oe-=te,B.total_out+=oe,x.total+=oe,oe&&(B.adler=x.check=x.flags?r(x.check,W,oe,T-oe):l(x.check,W,oe,T-oe)),oe=te,(x.flags?K:b(K))!==x.check){B.msg="incorrect data check",x.mode=30;break}Z=K=0}x.mode=28;case 28:if(x.wrap&&x.flags){for(;Z<32;){if(O===0)break e;O--,K+=V[$++]<<Z,Z+=8}if(K!==(4294967295&x.total)){B.msg="incorrect length check",x.mode=30;break}Z=K=0}x.mode=29;case 29:U=1;break e;case 30:U=-3;break e;case 31:return-4;case 32:default:return d}return B.next_out=T,B.avail_out=te,B.next_in=$,B.avail_in=O,x.hold=K,x.bits=Z,(x.wsize||oe!==B.avail_out&&x.mode<30&&(x.mode<27||D!==4))&&j(B,B.output,B.next_out,oe-B.avail_out)?(x.mode=31,-4):(ce-=B.avail_in,oe-=B.avail_out,B.total_in+=ce,B.total_out+=oe,x.total+=oe,x.wrap&&oe&&(B.adler=x.check=x.flags?r(x.check,W,oe,B.next_out-oe):l(x.check,W,oe,B.next_out-oe)),B.data_type=x.bits+(x.last?64:0)+(x.mode===12?128:0)+(x.mode===20||x.mode===15?256:0),(ce==0&&oe===0||D===4)&&U===y&&(U=-5),U)},n.inflateEnd=function(B){if(!B||!B.state)return d;var D=B.state;return D.window&&(D.window=null),B.state=null,y},n.inflateGetHeader=function(B,D){var x;return B&&B.state?(2&(x=B.state).wrap)==0?d:((x.head=D).done=!1,y):d},n.inflateSetDictionary=function(B,D){var x,V=D.length;return B&&B.state?(x=B.state).wrap!==0&&x.mode!==11?d:x.mode===11&&l(1,D,V,0)!==x.check?-3:j(B,D,V,V)?(x.mode=31,-4):(x.havedict=1,y):d},n.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(o,i,n){var s=o("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];i.exports=function(u,h,y,d,f,p,g,b){var k,w,_,M,A,I,N,H,z,j=b.bits,B=0,D=0,x=0,V=0,W=0,$=0,T=0,O=0,te=0,K=0,Z=null,ce=0,oe=new s.Buf16(16),re=new s.Buf16(16),Se=null,Ie=0;for(B=0;B<=15;B++)oe[B]=0;for(D=0;D<d;D++)oe[h[y+D]]++;for(W=j,V=15;1<=V&&oe[V]===0;V--);if(V<W&&(W=V),V===0)return f[p++]=20971520,f[p++]=20971520,b.bits=1,0;for(x=1;x<V&&oe[x]===0;x++);for(W<x&&(W=x),B=O=1;B<=15;B++)if(O<<=1,(O-=oe[B])<0)return-1;if(0<O&&(u===0||V!==1))return-1;for(re[1]=0,B=1;B<15;B++)re[B+1]=re[B]+oe[B];for(D=0;D<d;D++)h[y+D]!==0&&(g[re[h[y+D]]++]=D);if(I=u===0?(Z=Se=g,19):u===1?(Z=l,ce-=257,Se=r,Ie-=257,256):(Z=a,Se=c,-1),B=x,A=p,T=D=K=0,_=-1,M=(te=1<<($=W))-1,u===1&&852<te||u===2&&592<te)return 1;for(;;){for(N=B-T,z=g[D]<I?(H=0,g[D]):g[D]>I?(H=Se[Ie+g[D]],Z[ce+g[D]]):(H=96,0),k=1<<B-T,x=w=1<<$;f[A+(K>>T)+(w-=k)]=N<<24|H<<16|z|0,w!==0;);for(k=1<<B-1;K&k;)k>>=1;if(k!==0?(K&=k-1,K+=k):K=0,D++,--oe[B]==0){if(B===V)break;B=h[y+g[D]]}if(W<B&&(K&M)!==_){for(T===0&&(T=W),A+=x,O=1<<($=B-T);$+T<V&&!((O-=oe[$+T])<=0);)$++,O<<=1;if(te+=1<<$,u===1&&852<te||u===2&&592<te)return 1;f[_=K&M]=W<<24|$<<16|A-p|0}}return K!==0&&(f[A+K]=B-T<<24|64<<16|0),b.bits=W,0}},{"../utils/common":41}],51:[function(o,i,n){i.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(o,i,n){var s=o("../utils/common"),l=0,r=1;function a(C){for(var L=C.length;0<=--L;)C[L]=0}var c=0,u=29,h=256,y=h+1+u,d=30,f=19,p=2*y+1,g=15,b=16,k=7,w=256,_=16,M=17,A=18,I=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],N=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],H=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],z=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],j=new Array(2*(y+2));a(j);var B=new Array(2*d);a(B);var D=new Array(512);a(D);var x=new Array(256);a(x);var V=new Array(u);a(V);var W,$,T,O=new Array(d);function te(C,L,G,q,Y){this.static_tree=C,this.extra_bits=L,this.extra_base=G,this.elems=q,this.max_length=Y,this.has_stree=C&&C.length}function K(C,L){this.dyn_tree=C,this.max_code=0,this.stat_desc=L}function Z(C){return C<256?D[C]:D[256+(C>>>7)]}function ce(C,L){C.pending_buf[C.pending++]=255&L,C.pending_buf[C.pending++]=L>>>8&255}function oe(C,L,G){C.bi_valid>b-G?(C.bi_buf|=L<<C.bi_valid&65535,ce(C,C.bi_buf),C.bi_buf=L>>b-C.bi_valid,C.bi_valid+=G-b):(C.bi_buf|=L<<C.bi_valid&65535,C.bi_valid+=G)}function re(C,L,G){oe(C,G[2*L],G[2*L+1])}function Se(C,L){for(var G=0;G|=1&C,C>>>=1,G<<=1,0<--L;);return G>>>1}function Ie(C,L,G){var q,Y,X=new Array(g+1),ae=0;for(q=1;q<=g;q++)X[q]=ae=ae+G[q-1]<<1;for(Y=0;Y<=L;Y++){var ne=C[2*Y+1];ne!==0&&(C[2*Y]=Se(X[ne]++,ne))}}function ve(C){var L;for(L=0;L<y;L++)C.dyn_ltree[2*L]=0;for(L=0;L<d;L++)C.dyn_dtree[2*L]=0;for(L=0;L<f;L++)C.bl_tree[2*L]=0;C.dyn_ltree[2*w]=1,C.opt_len=C.static_len=0,C.last_lit=C.matches=0}function _e(C){8<C.bi_valid?ce(C,C.bi_buf):0<C.bi_valid&&(C.pending_buf[C.pending++]=C.bi_buf),C.bi_buf=0,C.bi_valid=0}function P(C,L,G,q){var Y=2*L,X=2*G;return C[Y]<C[X]||C[Y]===C[X]&&q[L]<=q[G]}function ie(C,L,G){for(var q=C.heap[G],Y=G<<1;Y<=C.heap_len&&(Y<C.heap_len&&P(L,C.heap[Y+1],C.heap[Y],C.depth)&&Y++,!P(L,q,C.heap[Y],C.depth));)C.heap[G]=C.heap[Y],G=Y,Y<<=1;C.heap[G]=q}function E(C,L,G){var q,Y,X,ae,ne=0;if(C.last_lit!==0)for(;q=C.pending_buf[C.d_buf+2*ne]<<8|C.pending_buf[C.d_buf+2*ne+1],Y=C.pending_buf[C.l_buf+ne],ne++,q===0?re(C,Y,L):(re(C,(X=x[Y])+h+1,L),(ae=I[X])!==0&&oe(C,Y-=V[X],ae),re(C,X=Z(--q),G),(ae=N[X])!==0&&oe(C,q-=O[X],ae)),ne<C.last_lit;);re(C,w,L)}function F(C,L){var G,q,Y,X=L.dyn_tree,ae=L.stat_desc.static_tree,ne=L.stat_desc.has_stree,me=L.stat_desc.elems,Ce=-1;for(C.heap_len=0,C.heap_max=p,G=0;G<me;G++)X[2*G]!==0?(C.heap[++C.heap_len]=Ce=G,C.depth[G]=0):X[2*G+1]=0;for(;C.heap_len<2;)X[2*(Y=C.heap[++C.heap_len]=Ce<2?++Ce:0)]=1,C.depth[Y]=0,C.opt_len--,ne&&(C.static_len-=ae[2*Y+1]);for(L.max_code=Ce,G=C.heap_len>>1;1<=G;G--)ie(C,X,G);for(Y=me;G=C.heap[1],C.heap[1]=C.heap[C.heap_len--],ie(C,X,1),q=C.heap[1],C.heap[--C.heap_max]=G,C.heap[--C.heap_max]=q,X[2*Y]=X[2*G]+X[2*q],C.depth[Y]=(C.depth[G]>=C.depth[q]?C.depth[G]:C.depth[q])+1,X[2*G+1]=X[2*q+1]=Y,C.heap[1]=Y++,ie(C,X,1),2<=C.heap_len;);C.heap[--C.heap_max]=C.heap[1],(function(we,Le){var He,Ge,rt,Pe,ft,tt,Ke=Le.dyn_tree,ue=Le.max_code,fe=Le.stat_desc.static_tree,Qe=Le.stat_desc.has_stree,lt=Le.stat_desc.extra_bits,_t=Le.stat_desc.extra_base,at=Le.stat_desc.max_length,ro=0;for(Pe=0;Pe<=g;Pe++)we.bl_count[Pe]=0;for(Ke[2*we.heap[we.heap_max]+1]=0,He=we.heap_max+1;He<p;He++)at<(Pe=Ke[2*Ke[2*(Ge=we.heap[He])+1]+1]+1)&&(Pe=at,ro++),Ke[2*Ge+1]=Pe,ue<Ge||(we.bl_count[Pe]++,ft=0,_t<=Ge&&(ft=lt[Ge-_t]),tt=Ke[2*Ge],we.opt_len+=tt*(Pe+ft),Qe&&(we.static_len+=tt*(fe[2*Ge+1]+ft)));if(ro!==0){do{for(Pe=at-1;we.bl_count[Pe]===0;)Pe--;we.bl_count[Pe]--,we.bl_count[Pe+1]+=2,we.bl_count[at]--,ro-=2}while(0<ro);for(Pe=at;Pe!==0;Pe--)for(Ge=we.bl_count[Pe];Ge!==0;)ue<(rt=we.heap[--He])||(Ke[2*rt+1]!==Pe&&(we.opt_len+=(Pe-Ke[2*rt+1])*Ke[2*rt],Ke[2*rt+1]=Pe),Ge--)}})(C,L),Ie(X,Ce,C.bl_count)}function v(C,L,G){var q,Y,X=-1,ae=L[1],ne=0,me=7,Ce=4;for(ae===0&&(me=138,Ce=3),L[2*(G+1)+1]=65535,q=0;q<=G;q++)Y=ae,ae=L[2*(q+1)+1],++ne<me&&Y===ae||(ne<Ce?C.bl_tree[2*Y]+=ne:Y!==0?(Y!==X&&C.bl_tree[2*Y]++,C.bl_tree[2*_]++):ne<=10?C.bl_tree[2*M]++:C.bl_tree[2*A]++,X=Y,Ce=(ne=0)===ae?(me=138,3):Y===ae?(me=6,3):(me=7,4))}function U(C,L,G){var q,Y,X=-1,ae=L[1],ne=0,me=7,Ce=4;for(ae===0&&(me=138,Ce=3),q=0;q<=G;q++)if(Y=ae,ae=L[2*(q+1)+1],!(++ne<me&&Y===ae)){if(ne<Ce)for(;re(C,Y,C.bl_tree),--ne!=0;);else Y!==0?(Y!==X&&(re(C,Y,C.bl_tree),ne--),re(C,_,C.bl_tree),oe(C,ne-3,2)):ne<=10?(re(C,M,C.bl_tree),oe(C,ne-3,3)):(re(C,A,C.bl_tree),oe(C,ne-11,7));X=Y,Ce=(ne=0)===ae?(me=138,3):Y===ae?(me=6,3):(me=7,4)}}a(O);var R=!1;function S(C,L,G,q){oe(C,(c<<1)+(q?1:0),3),(function(Y,X,ae,ne){_e(Y),ce(Y,ae),ce(Y,~ae),s.arraySet(Y.pending_buf,Y.window,X,ae,Y.pending),Y.pending+=ae})(C,L,G)}n._tr_init=function(C){R||((function(){var L,G,q,Y,X,ae=new Array(g+1);for(Y=q=0;Y<u-1;Y++)for(V[Y]=q,L=0;L<1<<I[Y];L++)x[q++]=Y;for(x[q-1]=Y,Y=X=0;Y<16;Y++)for(O[Y]=X,L=0;L<1<<N[Y];L++)D[X++]=Y;for(X>>=7;Y<d;Y++)for(O[Y]=X<<7,L=0;L<1<<N[Y]-7;L++)D[256+X++]=Y;for(G=0;G<=g;G++)ae[G]=0;for(L=0;L<=143;)j[2*L+1]=8,L++,ae[8]++;for(;L<=255;)j[2*L+1]=9,L++,ae[9]++;for(;L<=279;)j[2*L+1]=7,L++,ae[7]++;for(;L<=287;)j[2*L+1]=8,L++,ae[8]++;for(Ie(j,y+1,ae),L=0;L<d;L++)B[2*L+1]=5,B[2*L]=Se(L,5);W=new te(j,I,h+1,y,g),$=new te(B,N,0,d,g),T=new te(new Array(0),H,0,f,k)})(),R=!0),C.l_desc=new K(C.dyn_ltree,W),C.d_desc=new K(C.dyn_dtree,$),C.bl_desc=new K(C.bl_tree,T),C.bi_buf=0,C.bi_valid=0,ve(C)},n._tr_stored_block=S,n._tr_flush_block=function(C,L,G,q){var Y,X,ae=0;0<C.level?(C.strm.data_type===2&&(C.strm.data_type=(function(ne){var me,Ce=4093624447;for(me=0;me<=31;me++,Ce>>>=1)if(1&Ce&&ne.dyn_ltree[2*me]!==0)return l;if(ne.dyn_ltree[18]!==0||ne.dyn_ltree[20]!==0||ne.dyn_ltree[26]!==0)return r;for(me=32;me<h;me++)if(ne.dyn_ltree[2*me]!==0)return r;return l})(C)),F(C,C.l_desc),F(C,C.d_desc),ae=(function(ne){var me;for(v(ne,ne.dyn_ltree,ne.l_desc.max_code),v(ne,ne.dyn_dtree,ne.d_desc.max_code),F(ne,ne.bl_desc),me=f-1;3<=me&&ne.bl_tree[2*z[me]+1]===0;me--);return ne.opt_len+=3*(me+1)+5+5+4,me})(C),Y=C.opt_len+3+7>>>3,(X=C.static_len+3+7>>>3)<=Y&&(Y=X)):Y=X=G+5,G+4<=Y&&L!==-1?S(C,L,G,q):C.strategy===4||X===Y?(oe(C,2+(q?1:0),3),E(C,j,B)):(oe(C,4+(q?1:0),3),(function(ne,me,Ce,we){var Le;for(oe(ne,me-257,5),oe(ne,Ce-1,5),oe(ne,we-4,4),Le=0;Le<we;Le++)oe(ne,ne.bl_tree[2*z[Le]+1],3);U(ne,ne.dyn_ltree,me-1),U(ne,ne.dyn_dtree,Ce-1)})(C,C.l_desc.max_code+1,C.d_desc.max_code+1,ae+1),E(C,C.dyn_ltree,C.dyn_dtree)),ve(C),q&&_e(C)},n._tr_tally=function(C,L,G){return C.pending_buf[C.d_buf+2*C.last_lit]=L>>>8&255,C.pending_buf[C.d_buf+2*C.last_lit+1]=255&L,C.pending_buf[C.l_buf+C.last_lit]=255&G,C.last_lit++,L===0?C.dyn_ltree[2*G]++:(C.matches++,L--,C.dyn_ltree[2*(x[G]+h+1)]++,C.dyn_dtree[2*Z(L)]++),C.last_lit===C.lit_bufsize-1},n._tr_align=function(C){oe(C,2,3),re(C,w,j),(function(L){L.bi_valid===16?(ce(L,L.bi_buf),L.bi_buf=0,L.bi_valid=0):8<=L.bi_valid&&(L.pending_buf[L.pending++]=255&L.bi_buf,L.bi_buf>>=8,L.bi_valid-=8)})(C)}},{"../utils/common":41}],53:[function(o,i,n){i.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(o,i,n){(function(s){(function(l,r){if(!l.setImmediate){var a,c,u,h,y=1,d={},f=!1,p=l.document,g=Object.getPrototypeOf&&Object.getPrototypeOf(l);g=g&&g.setTimeout?g:l,a={}.toString.call(l.process)==="[object process]"?function(_){process.nextTick(function(){k(_)})}:(function(){if(l.postMessage&&!l.importScripts){var _=!0,M=l.onmessage;return l.onmessage=function(){_=!1},l.postMessage("","*"),l.onmessage=M,_}})()?(h="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",w,!1):l.attachEvent("onmessage",w),function(_){l.postMessage(h+_,"*")}):l.MessageChannel?((u=new MessageChannel).port1.onmessage=function(_){k(_.data)},function(_){u.port2.postMessage(_)}):p&&"onreadystatechange"in p.createElement("script")?(c=p.documentElement,function(_){var M=p.createElement("script");M.onreadystatechange=function(){k(_),M.onreadystatechange=null,c.removeChild(M),M=null},c.appendChild(M)}):function(_){setTimeout(k,0,_)},g.setImmediate=function(_){typeof _!="function"&&(_=new Function(""+_));for(var M=new Array(arguments.length-1),A=0;A<M.length;A++)M[A]=arguments[A+1];var I={callback:_,args:M};return d[y]=I,a(y),y++},g.clearImmediate=b}function b(_){delete d[_]}function k(_){if(f)setTimeout(k,0,_);else{var M=d[_];if(M){f=!0;try{(function(A){var I=A.callback,N=A.args;switch(N.length){case 0:I();break;case 1:I(N[0]);break;case 2:I(N[0],N[1]);break;case 3:I(N[0],N[1],N[2]);break;default:I.apply(r,N)}})(M)}finally{b(_),f=!1}}}}function w(_){_.source===l&&typeof _.data=="string"&&_.data.indexOf(h)===0&&k(+_.data.slice(h.length))}})(typeof self>"u"?s===void 0?this:s:self)}).call(this,typeof un<"u"?un:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(ps)),ps.exports}var pg=hg();const sc=fg(pg);function rc(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function lc(e,t){var o,i,n;if(!t)return"";if(typeof document<"u"){const s=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),l=((s==null?void 0:s.innerText)||(s==null?void 0:s.textContent)||"").trim();if(l)return l}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const s=(o=e.latestCompiledDoc.slides)==null?void 0:o[0],l=(i=s==null?void 0:s.blocks)==null?void 0:i.find(r=>r.type==="h"||r.type==="NodeHeading");if(l!=null&&l.content)return l.content.trim()}try{const s=await gi(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(s)&&s.length>0&&((n=s[0])!=null&&n.content))return String(s[0].content).trim()}catch{}return""}async function mg(e,t,o){var c,u,h;const i=Vw(),n=!!((c=i==null?void 0:i.isPinned)!=null&&c.value),s=String(((u=i==null?void 0:i.pinnedDocId)==null?void 0:u.value)||"");if(n&&s&&o&&o!==s)return;const l=o||(n&&s?s:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&l&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(l):await lc(e,l));const a=rc(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(a),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",a);return}if(typeof document<"u"){const y=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const d of y){const f=d.querySelector(".item__text"),p=((h=f==null?void 0:f.textContent)==null?void 0:h.trim())||"";if(p.includes("Slidev 演示预览")||p.startsWith("即现")){f&&(f.textContent=a),d.setAttribute("title",a);break}}}}function Ei(e){return(e||"").replace(/[/\\?%*:|"<>]/g,"_").replace(/_+/g,"_").trim().replace(/^_+|_+$/g,"")||"presentation"}async function No(e,t,o){var n,s;const i=t||(e==null?void 0:e.docId)||"";if(o&&typeof o.fetchDocumentTitle=="function"&&i)try{const l=await o.fetchDocumentTitle(i);if(l&&l.trim())return Ei(l)}catch{}if(typeof document<"u")try{const l=(i?document.querySelector(`.protyle-title[data-node-id="${i}"] .protyle-title__input`):null)||(i?document.querySelector(`.protyle[data-doc-id="${i}"] .protyle-title__input`):null)||document.querySelector(".layout__wnd--active .protyle-title__input")||document.querySelector(".protyle-title__input"),r=((l==null?void 0:l.innerText)||(l==null?void 0:l.textContent)||"").trim();if(r)return Ei(r)}catch{}if((n=e==null?void 0:e.config)!=null&&n.title&&e.config.title.trim()&&e.config.title.trim().toLowerCase()!=="presentation")return Ei(e.config.title);if(e!=null&&e.slides&&e.slides.length>0){const r=(s=e.slides[0].blocks)==null?void 0:s.find(c=>c.type==="h"||c.type==="NodeHeading"),a=((r==null?void 0:r.content)||"").replace(/^#+\s*/,"").trim();if(a)return Ei(a)}return"presentation"}function gg(e,t){if(typeof document>"u")return!1;const o=URL.createObjectURL(t),i=document.createElement("a");return i.href=o,i.download=e,document.body.appendChild(i),i.click(),document.body.removeChild(i),URL.revokeObjectURL(o),!0}function xl(e,t){if(typeof document>"u")return!1;const o=document.createElement("a");return o.href=t,o.download=e,document.body.appendChild(o),o.click(),document.body.removeChild(o),!0}async function yg(e){if(typeof navigator>"u"||!navigator.clipboard||typeof ClipboardItem>"u")return!1;try{const o=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({[o.type||"image/png"]:o})]),!0}catch(t){return console.warn("[image-exporter] 复制图像至剪贴板失败:",t),!1}}async function js(e,t){return new Promise(o=>{let i=[],n=null;const s=()=>{n&&(clearTimeout(n),n=null),i.forEach(a=>a()),i=[]};n=setTimeout(()=>{s(),o({success:!1,error:"单页截图超时（沙箱无响应）"})},2e4);const l=e.onCapturePageDone(a=>{s(),o({success:!0,dataUrl:a.dataUrl})});i.push(l);const r=e.onCaptureError(a=>{s(),o({success:!1,error:a})});i.push(r),e.startImageExport({mode:"current",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function ac(e,t){const o=[],i=Ei((t==null?void 0:t.title)||"presentation");return new Promise(n=>{let s=[],l=null;const r=()=>{l&&(clearTimeout(l),l=null),s.forEach(d=>d()),s=[]},a=()=>{l&&clearTimeout(l),l=setTimeout(()=>{r(),n({success:!1,error:"幻灯片逐页导出超时（沙箱无响应）"})},35e3)};a();const c=e.onCaptureProgress(d=>{var f;a(),(f=t==null?void 0:t.onProgress)==null||f.call(t,d.current,d.total,d.pageIndex)});s.push(c);const u=e.onCapturePageDone(d=>{a(),(d.mode==="all"||!d.mode)&&o.push({pageIndex:d.pageIndex,dataUrl:d.dataUrl})});s.push(u);const h=async()=>{r();try{if(o.length===0){n({success:!1,error:"未采集到幻灯片图像数据"});return}const d=new sc,f=(t==null?void 0:t.format)==="jpeg"?"jpg":"png";for(const b of o){const k=String(b.pageIndex).padStart(2,"0"),w=b.dataUrl.split(",")[1];d.file(`slide-${k}.${f}`,w,{base64:!0})}const p=await d.generateAsync({type:"blob",compression:"DEFLATE"}),g=gg(`${i}.zip`,p);n({success:g,total:o.length})}catch(d){n({success:!1,error:(d==null?void 0:d.message)||String(d)})}};s.push(e.onCaptureComplete(h));const y=e.onCaptureError(d=>{r(),n({success:!1,error:d})});s.push(y),e.startImageExport({mode:"all",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function cc(e,t){if(typeof document>"u")return{success:!1,error:"环境不支持 DOM 沙箱挂载"};const o=document.createElement("iframe");o.style.position="fixed",o.style.left="-9999px",o.style.top="-9999px",o.style.width="1920px",o.style.height="1080px",o.style.opacity="0",o.style.pointerEvents="none",o.src="/plugins/siyuan-live-slides/slides-client/index.html?headless=true",document.body.appendChild(o);const i=new Jn;i.attach(o);try{if(await new Promise((n,s)=>{const l=setTimeout(()=>s(new Error("静默后台沙箱加载超时")),12e3);i.onClientReady(()=>{clearTimeout(l),n()})}),i.updateSlides(e.slides,e.config),await new Promise(n=>setTimeout(n,250)),(t==null?void 0:t.mode)==="current"){const n=await js(i,t);return{success:n.success,total:1,error:n.error}}else{const n=(t==null?void 0:t.title)||await No(e,e.docId);return await ac(i,{...t,title:n})}}catch(n){return{success:!1,error:(n==null?void 0:n.message)||String(n)}}finally{i.detach(),o.remove()}}const bg=1500,vg=500,kg=4,wg=new Set(["INPUT","TEXTAREA","SELECT"]);function dc(e){const t=e;return!t||!t.tagName?!1:wg.has(t.tagName)||t.isContentEditable===!0}function xg(e){let t="",o=!1,i=null,n=null;function s(){e.onStateChange&&e.onStateChange({display:t,invalid:o})}function l(){i&&(clearTimeout(i),i=null),n&&(clearTimeout(n),n=null)}function r(){l(),t="",o=!1,s()}function a(){i&&clearTimeout(i),i=setTimeout(r,bg)}function c(){i&&(clearTimeout(i),i=null),o=!0,s(),n&&clearTimeout(n),n=setTimeout(r,vg)}function u(h){if(e.isEnabled&&!e.isEnabled()||dc(h.target)||h.isComposing||h.ctrlKey||h.metaKey||h.altKey)return!1;if(/^[0-9]$/.test(h.key))return o||t.length>=kg||(t+=h.key,s(),a()),!0;if(h.key==="Enter"){if(!t||o)return!1;const d=parseInt(t,10),f=e.getTotalPages();return!isNaN(d)&&d>=1&&f>0&&d<=f?(r(),e.onJump(d),!0):(c(),!0)}return h.key==="Escape"&&(t||o)?(r(),!0):!1}return{handleKeydown:u,getState:()=>({display:t,invalid:o}),clear:r}}const Sg={class:"spm-slides-tab__toolbar"},_g={class:"spm-slides-tab__nav"},Cg=["disabled"],Ig={class:"spm-page-badge"},$g=["disabled"],Ag=["aria-label"],Tg={class:"spm-slides-tab__tools"},Mg={key:3,class:"spm-export-image-dropdown",style:{position:"relative",display:"inline-flex","align-items":"center"}},Bg={key:0,class:"b3-menu b3-menu--context",style:{position:"absolute",top:"calc(100% + 4px)",right:"0","z-index":"100","min-width":"190px","box-shadow":"var(--b3-point-shadow)","border-radius":"4px",background:"var(--b3-theme-surface)"}},Eg=["src"],Dg=Pt({__name:"SlidesPreviewTab",setup(e,{expose:t}){const o=Wt("plugin"),i=Wt("sandboxBridge",new Jn),n=new zm(i),s=pe(null),l=pe(!1),r=pe(null),a=pe(1),c=pe(1),u=pe(!1),h=pe(!1),y=pe(!1),d=pe("siyuan"),f=pe(""),p=pe(""),g=pe(""),b=pe(!1),k=pe(!1),w=pe(""),_=pe(""),M=pe(!1),A=xg({getTotalPages:()=>c.value,isEnabled:()=>!h.value,onJump:S=>H(S),onStateChange:S=>{_.value=S.display,M.value=S.invalid}});function I(S){if(S.key==="o"||S.key==="O"){if(h.value||S.isComposing||S.ctrlKey||S.metaKey||S.altKey||dc(S.target))return;S.preventDefault(),N();return}A.handleKeydown(S)&&S.preventDefault()}function N(){var S;i.toggleOverview(),(S=r.value)==null||S.focus()}function H(S){var C;a.value=S,i.navigatePage(S),(C=r.value)==null||C.focus()}const z=pe("/plugins/siyuan-live-slides/slides-client/index.html");let j=null,B=null,D=null,x=null,V=null,W=null,$=null,T=null;Qo(()=>{r.value&&i.attach(r.value),j=i.onSlideChanged((S,C)=>{a.value=S,c.value=C}),B=i.onBlockClicked((S,C)=>{a.value=C,n.setActiveBlockId(S),S||ji(),o&&typeof o.handleBlockClickedFromSlide=="function"?o.handleBlockClickedFromSlide(S,C):S&&Jo(S,o==null?void 0:o.app)}),D=i.onOpenInEditor((S,C)=>{a.value=C,n.setActiveBlockId(S),Jo(S,o==null?void 0:o.app)}),x=i.onOpenPeekDrawer(async S=>{const C=Zn();if(S.peekType==="siyuan"&&C.enableWebServeJump){let L=!1;if(T&&T.docId===S.target)L=!0;else if(T&&T.slides&&T.slides.some(G=>{var q;return(q=G.blocks)==null?void 0:q.some(Y=>Y.id===S.target)}))L=!1;else try{const G=await gi(`SELECT id, root_id, type FROM blocks WHERE id = '${S.target}' LIMIT 1`);G&&G.length>0&&(L=G[0].type==="d"||G[0].id===G[0].root_id)}catch(G){console.warn("[SlidesPreviewTab] detect block type failed:",G)}d.value="web",b.value=!0,p.value=Ua(C.webServeUrl,S.target,{focus:!L}),g.value=S.title||`${L?"思源文档":"思源块"}: ${S.target.slice(0,8)}`,h.value=!0,i.freezeKeyboardNav(!0)}else{if(d.value=S.peekType,S.peekType==="siyuan")f.value=S.target,g.value=S.title||`块速览: ${S.target.slice(0,8)}`;else{const L=Ja(S.target);if(L.external){Ie(S.target);return}b.value=!0,p.value=L.url,g.value=S.title||L.url}h.value=!0,i.freezeKeyboardNav(!0)}}),V=i.onRequestToggleFullscreen(()=>{_e()}),W=i.onOpenPresenter(()=>{P()}),typeof document<"u"&&document.addEventListener("fullscreenchange",ve),$=Ya(S=>{T&&i.updateSlides(T.slides,{...T.config,hostThemeMode:S},T.customThemeCss)})}),tn(()=>{$&&($(),$=null),typeof document<"u"&&document.removeEventListener("fullscreenchange",ve),x&&x(),V&&V(),W&&W(),j&&j(),B&&B(),D&&D(),i.detach(),A.clear(),n.destroy()});function O(){k.value=!k.value,k.value?(w.value=(T==null?void 0:T.docId)||"",o&&typeof o.updatePreviewTabHeader=="function"&&o.updatePreviewTabHeader("",w.value)):(w.value="",oe(),o&&typeof o.updatePreviewTabHeader=="function"&&o.updatePreviewTabHeader())}let te=0;function K(S){if(h.value||Math.abs(S.deltaY)<Math.abs(S.deltaX)||Math.abs(S.deltaY)<15)return;const C=Date.now();C-te<280||(te=C,S.deltaY>0?ce():Z())}function Z(){if(a.value>1){const S=a.value-1;a.value=S,i.navigatePage(S)}}function ce(){if(a.value<c.value){const S=a.value+1;a.value=S,i.navigatePage(S)}}function oe(){o&&typeof o.compileCurrentDocument=="function"?o.compileCurrentDocument():o!=null&&o.eventBus&&typeof o.eventBus.emit=="function"&&o.eventBus.emit("slides:request-compile")}function re(){h.value=!1,i.freezeKeyboardNav(!1)}function Se(){re()}function Ie(S){var q,Y;const C=/^file:/i.test(S),L=C||/^[a-zA-Z]:[\\/]/.test(S),G=nn("electron");if(L&&typeof((q=G==null?void 0:G.shell)==null?void 0:q.openPath)=="function"){G.shell.openPath(C?Za(S):S),le.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((Y=G==null?void 0:G.shell)==null?void 0:Y.openExternal)=="function"?G.shell.openExternal(S).catch(()=>{typeof window<"u"&&window.open(S,"_blank")}):typeof window<"u"&&window.open(S,"_blank"),le.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function ve(){typeof document<"u"&&(l.value=!!document.fullscreenElement,i.postMessage("FULLSCREEN_CHANGED",{isFullscreen:l.value}))}function _e(){const S=s.value||r.value;S&&(document.fullscreenElement?document.exitFullscreen().then(()=>{i.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):S.requestFullscreen().then(()=>{i.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function P(){o&&typeof o.openPresenterTab=="function"&&o.openPresenterTab()}async function ie(){if(!T){le.showMessage("请先在主编辑区打开幻灯片文档");return}const S=await No(T,o==null?void 0:o.currentDocId,o);le.showMessage("正在导出单文件离线 HTML（内联媒体资源中...）",2e3);const C=await oc(T,{title:S});ic(`${S}.html`,C)&&le.showMessage(`已开始下载单文件离线 HTML 演示包 (${S}.html)`)}function E(){if(!T){le.showMessage("请先在主编辑区打开幻灯片文档");return}nc(T)&&le.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const F=pe(!1);async function v(){if(F.value){le.showMessage("正在逐页导出幻灯片图片中，请稍候...",2e3);return}if(!T){le.showMessage("请先在主编辑区打开幻灯片文档");return}F.value=!0;try{le.showMessage("正在逐页导出幻灯片图片...",2e3);const S=await No(T,o==null?void 0:o.currentDocId,o),C=await ac(i,{title:S,onProgress:(L,G)=>{le.showMessage(`正在导出幻灯片图片 (${L} / ${G})...`,1500)}});C.success?le.showMessage(`🎉 成功导出 ${C.total||0} 张高清图片并保存为 ${S}.zip！`,4e3):le.showMessage(`导出图片失败：${C.error||"未知异常"}`)}finally{F.value=!1}}async function U(){if(!T){le.showMessage("请先在主编辑区打开幻灯片文档");return}le.showMessage("正在导出当前幻灯片图片...",1500);const S=await js(i);if(S.success&&S.dataUrl){const C=await No(T,o==null?void 0:o.currentDocId,o),L=a.value||1,q=(c.value||1)>1?`${C}-${L}.png`:`${C}.png`;xl(q,S.dataUrl),le.showMessage(`已下载当前页高清图片 (${q})`)}else le.showMessage(`导出当前页图片失败：${S.error||"未知异常"}`)}async function R(){if(!T){le.showMessage("请先在主编辑区打开幻灯片文档");return}le.showMessage("正在复制当前幻灯片截图到剪贴板...",1500);const S=await js(i);if(S.success&&S.dataUrl)if(await yg(S.dataUrl))le.showMessage(`已成功将第 ${a.value||1} 页幻灯片复制到剪贴板！`);else{const L=await No(T,o==null?void 0:o.currentDocId,o),G=a.value||1,Y=(c.value||1)>1?`${L}-${G}.png`:`${L}.png`;xl(Y,S.dataUrl),le.showMessage(`剪贴板权限不可用，已自动下载为 ${Y}`)}else le.showMessage(`复制失败：${S.error||"未知异常"}`)}return t({updateDocument(S,C){k.value&&w.value&&C&&C!==w.value||(T=S,k.value&&!w.value&&(w.value=S.docId),c.value=S.slides.length,n.setDocId(S.docId),n.updateSlidesIndex(S.slides),i.updateSlides(S.slides,{...S.config,hostThemeMode:zo()},S.customThemeCss),o&&typeof o.updatePreviewTabHeader=="function"&&o.updatePreviewTabHeader("",S.docId))},navigateToBlock(S){n.onCursorFocusBlock(S)},isPinned:k,pinnedDocId:w}),(S,C)=>(J(),ee("div",{class:"spm-slides-preview-tab",onKeydown:I},[m("div",Sg,[m("div",_g,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:a.value<=1,"aria-label":"上一页",onClick:Z},[se(de,{name:"chevron-left"})],8,Cg),m("span",Ig,ke(a.value)+" / "+ke(c.value||1),1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:a.value>=c.value,"aria-label":"下一页",onClick:ce},[se(de,{name:"chevron-right"})],8,$g),m("button",{class:xe(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":k.value}]),"aria-label":k.value?"已锁定当前文档（点击解除）："+w.value:"点击锁定当前文档（不随主编辑区切换）",onClick:O},[se(de,{name:"pin"}),m("span",null,ke(k.value?"已锁定":"跟随"),1)],10,Ag)]),m("div",Tg,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:N},[se(de,{name:"layout-grid"})]),he(Dt)("presenterMode")?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:P},[se(de,{name:"presenter"})])):Te("",!0),he(Dt)("exportHtml")?(J(),ee("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:ie},[se(de,{name:"export-html"})])):Te("",!0),he(Dt)("exportPdf")?(J(),ee("button",{key:2,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:E},[se(de,{name:"export-pdf"})])):Te("",!0),he(Dt)("exportImage")?(J(),ee("div",Mg,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出幻灯片为图片包 (ZIP)",onClick:v},[se(de,{name:"export-image"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",style:{padding:"2px 2px","margin-left":"-4px"},"aria-label":"更多图片导出选项",onClick:C[0]||(C[0]=eo(L=>u.value=!u.value,["stop"]))},[se(de,{name:"chevron-down"})]),u.value?(J(),ee("div",Bg,[m("button",{class:"b3-menu__item",onClick:C[1]||(C[1]=L=>{v(),u.value=!1})},[...C[6]||(C[6]=[m("span",{class:"b3-menu__label"},"📦 导出全篇为图片包 (ZIP)",-1)])]),m("button",{class:"b3-menu__item",onClick:C[2]||(C[2]=L=>{U(),u.value=!1})},[...C[7]||(C[7]=[m("span",{class:"b3-menu__label"},"🖼️ 导出当前页为图片 (PNG)",-1)])]),m("button",{class:"b3-menu__item",onClick:C[3]||(C[3]=L=>{R(),u.value=!1})},[...C[8]||(C[8]=[m("span",{class:"b3-menu__label"},"📋 复制当前页至剪贴板",-1)])])])):Te("",!0)])):Te("",!0),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:oe},[se(de,{name:"refresh"})]),m("button",{class:"spm-icon-btn is-primary spm-btn-fullscreen b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:_e},[se(de,{name:"fullscreen"}),C[9]||(C[9]=m("span",{class:"spm-btn-fullscreen__label"},"全屏放映",-1))])])]),m("div",{ref_key:"fullscreenContainerRef",ref:s,class:"spm-slides-tab__viewport spm-slides-fullscreen-container",onWheel:K},[m("iframe",{ref_key:"sandboxIframeRef",ref:r,class:"spm-slides-tab__iframe",src:z.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Eg),se(Gp,{visible:h.value,"onUpdate:visible":C[4]||(C[4]=L=>h.value=L),"is-maximized":y.value,"onUpdate:isMaximized":C[5]||(C[5]=L=>y.value=L),title:g.value,onClose:re},{default:ha(()=>[d.value==="siyuan"&&f.value?(J(),to(rm,{key:0,"block-id":f.value,title:g.value,plugin:he(o),onExternalJump:Se},null,8,["block-id","title","plugin"])):Te("",!0),b.value?Ht((J(),to(Pm,{key:1,visible:h.value&&d.value==="web",url:p.value,title:g.value,onExternalJump:Se},null,8,["visible","url","title"])),[[Os,d.value==="web"]]):Te("",!0)]),_:1},8,["visible","is-maximized","title"]),Ht(m("div",{class:xe(["spm-jump-badge",{"is-invalid":M.value}])},ke(_.value),3),[[Os,_.value]])],544)],32))}}),Lg=so(Dg,[["__scopeId","data-v-7d559c8a"]]);function uc(e){if(!e||e.length===0)return{maxStep:0,blockMap:new Map,idMap:new Map};const t=new Map,o=new Map,i=new Map;let n=0;const s=(r,a)=>{t.set(r,a);const c=r.id||r.blockId;c&&o.set(c,a)},l=e.filter(r=>r.slot!=="slot-divider-right");for(const r of l){if(r.parentContainerId&&r.parentClicks&&r.parentClicks.trim()!==""&&!i.has(r.parentContainerId)){const h=String(r.parentClicks).trim();if(/^\d+$/.test(h)){const y=parseInt(h,10);n=Math.max(n,y),i.set(r.parentContainerId,y)}else n+=1,i.set(r.parentContainerId,n)}if(!!!(r.clicks&&String(r.clicks).trim()!=="")){if(r.parentContainerId&&i.has(r.parentContainerId)){const h=i.get(r.parentContainerId);s(r,{type:"step",step:h})}else s(r,{type:"always"});continue}const c=String(r.clicks).trim();if(!c){n+=1,s(r,{type:"step",step:n});continue}if(c.startsWith("[")&&c.endsWith("]"))try{const h=JSON.parse(c);if(Array.isArray(h)&&h.length>=2){const y=Math.min(Number(h[0]),Number(h[1])),d=Math.max(Number(h[0]),Number(h[1]));if(!isNaN(y)&&!isNaN(d)){n=Math.max(n,d),s(r,{type:"range",min:y,max:d});continue}}}catch{}if(c.toLowerCase()==="hide"){n+=1,s(r,{type:"hide",step:n});continue}if(/^\+\d+$/.test(c)||c==="true"){const h=c==="true"?1:parseInt(c.slice(1),10)||1;n+=h,s(r,{type:"step",step:n});continue}if(/^-\d+$/.test(c)){const h=parseInt(c.slice(1),10)||1;n=Math.max(1,n-h),s(r,{type:"step",step:n});continue}if(/^\d+$/.test(c)){const h=parseInt(c,10);if(!isNaN(h)){n=Math.max(n,h),s(r,{type:"step",step:h});continue}}const u=parseInt(c,10);!isNaN(u)&&u>0?(n=Math.max(n,u),s(r,{type:"step",step:u})):(n+=1,s(r,{type:"step",step:n}))}return{maxStep:n,blockMap:t,idMap:o}}function Og(e,t,o){if(!e)return"v-click-visible";const i=e.id||e.blockId,n=o.blockMap.get(e)||(i?o.idMap.get(i):null);return!n||n.type==="always"?"v-click-visible":n.type==="range"?t>=n.min&&t<=n.max?"v-click-visible":"v-click-hidden":n.type==="hide"?t<n.step?"v-click-visible":"v-click-hidden":n.type==="step"?t>=n.step?"v-click-visible":"v-click-hidden":"v-click-visible"}const Ws=980;function Ng(e){if(!e)return 0;const o=uc(e.blocks||[]).maxStep||0,i=e.frontmatter||{},n=i.mask;if(n!=="down"&&n!=="right")return o;const s=Sd(i.maskRatio),r=i.maskInitial==="revealed"?Math.max(0,s.steps-1):s.steps;return Math.max(o,r)}function Pg(e,t=Ws){const o=(e||"16/9").trim();let i=16/9;if(o==="4/3"||o==="4:3")i=4/3;else if(o==="16/10"||o==="16:10")i=16/10;else if(o.includes("/")||o.includes(":")){const s=o.includes("/")?"/":":",l=o.split(s).map(r=>parseFloat(r.trim()));l.length===2&&l[0]>0&&l[1]>0&&!isNaN(l[0])&&!isNaN(l[1])&&(i=l[0]/l[1])}else{const s=parseFloat(o);!isNaN(s)&&s>.2&&s<5&&(i=s)}const n=Math.ceil(t/i);return{baseWidth:t,baseHeight:n,ratio:i}}function Sl(e,t,o=Ws,i=552,n=16){const s=o>0?o:Ws,l=i>0?i:552,r=Math.max(0,e-n),a=Math.max(0,t-n);if(r<=0||a<=0)return{scale:.36,boxWidth:Math.round(s*.36),boxHeight:Math.round(l*.36)};const c=Math.min(r/s,a/l),u=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:u,boxWidth:Math.max(1,Math.round(s*u)),boxHeight:Math.max(1,Math.round(l*u))}}function Rg(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0,motion:t.motion?{...t.motion}:void 0,children:Array.isArray(t.children)?t.children.map(o=>({...o,attrs:o.attrs?{...o.attrs}:void 0,attributes:o.attributes?{...o.attributes}:void 0})):void 0})):[]}}function _l(e,t){if(!e)return"";const o=Rg(e),i=o.frontmatter||{},n=i.layout||"default",s=(t==null?void 0:t.config)||{};(n==="image-right"||n==="image-left")&&!i.image&&!i.background&&s.image&&(i.image=s.image);const l=typeof(t==null?void 0:t.currentStep)=="number",r=l?Math.max(0,t.currentStep):0,a=l?uc(o.blocks||[]):null,u=tc(o,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(t==null?void 0:t.allSlides)||[],currentPageIndex:(t==null?void 0:t.pageIndex)||o.pageIndex||1,highlight:!0,blockClassResolver:a?w=>{if(Og(w,r,a)==="v-click-hidden")return"presenter-v-click-pending";if(r>0){const M=w.id||w.blockId,A=a.blockMap.get(w)||(M?a.idMap.get(M):void 0);if((A==null?void 0:A.type)==="step"&&A.step===r||(A==null?void 0:A.type)==="range"&&A.min===r)return"presenter-v-click-active"}return""}:void 0}).replace(/<video\b([^>]*)>/gi,(w,_)=>{let M=_.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test(M)||(M+=" muted"),`<video ${M.trim()}>`}),h=i.spacing,y=h&&h!=="inherit"?h:s.spacing||"normal",d=["slide-content",`layout-${n}`,`spacing-${y}`,i.class||"",i.layoutClass||""].filter(Boolean).join(" "),f=[],p=(i.background||s.background||"").trim();if(p)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(p)){const w=p.startsWith("assets/")?`/${p}`:p.startsWith("./assets/")?p.slice(1):p;f.push(`background-image:url('${st(w)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else f.push(`background:${st(p)};`);const g=typeof i.zoom=="number"?i.zoom:typeof i.zoom=="string"?parseFloat(i.zoom):1,b=!isNaN(g)&&g>0?g:1;b!==1&&f.push(`width:${(100/b).toFixed(2)}%;height:${(100/b).toFixed(2)}%;transform-origin:top left;transform:scale(${b});`);const k=f.length>0?` style="${f.join("")}"`:"";return`<div class="${st(d)}"${k}>${u}</div>`}const zg={class:"presenter-header"},Hg={class:"presenter-title-area"},Fg={class:"presenter-brand"},jg={class:"header-pills"},Wg={class:"pill pill-page"},Ug={key:0,class:"pill pill-step"},Vg={class:"header-toolbar"},qg={class:"timer-capsule"},Gg={class:"timer-digits"},Kg={class:"timer-actions"},Yg=["aria-label"],Zg={class:"wall-clock b3-tooltips b3-tooltips__sw","aria-label":"系统当前时间"},Jg={key:0,class:"presenter-grid"},Xg={class:"slide-panels"},Qg={class:"panel-box current-slide-panel"},ey={class:"panel-header"},ty={class:"panel-header-left"},oy={class:"panel-page-num"},iy={class:"panel-header-meta"},ny={key:0,class:"panel-step-pill"},sy={class:"panel-layout-pill"},ry=["aria-label"],ly=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],ay={key:1,class:"panel-fallback"},cy=["aria-label"],dy={class:"panel-header"},uy={class:"panel-header-left"},fy={key:0,class:"panel-page-num"},hy={class:"panel-header-meta"},py={key:0,class:"panel-end-pill"},my={key:1,class:"panel-layout-pill"},gy=["aria-label"],yy=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],by={key:1,class:"panel-fallback"},vy={class:"notes-panel"},ky={class:"panel-header"},wy={class:"panel-header-left"},xy={class:"notes-size-controls"},Sy=["disabled"],_y={class:"notes-size-value"},Cy=["disabled"],Iy={key:1,class:"presenter-empty"},$y={class:"empty-icon-wrap"},Ay={class:"empty-actions"},Ty={class:"presenter-actions"},My={class:"nav-btn-group"},By=["disabled"],Ey=["disabled"],Dy={class:"actions-center"},Ly={class:"center-meta"},Oy={class:"progress-pill"},Ny={class:"nav-btn-group"},Py=["aria-label"],Ry={class:"step-dots-text"},zy=["disabled"],Hy=["disabled"],Fy=280,jy=15,Wy=Pt({__name:"SlidesPresenterTab",setup(e,{expose:t}){const o=Wt("plugin"),i=Wt("sandboxBridge",new Jn),n=pe([]),s=pe({}),l=pe(1),r=pe(0),a=pe(0),c=pe(0),u=ye(()=>n.value.length||a.value),h=pe(null),y=pe(null),d=pe({width:0,height:0}),f=pe({width:0,height:0}),p=pe(zo()),g=ye(()=>{var ue;return Pg((ue=s.value)==null?void 0:ue.aspectRatio)}),b=ye(()=>{var ue;return((ue=s.value)==null?void 0:ue.theme)||"apple-basic"}),k=ye(()=>{var ue;return gr((ue=s.value)==null?void 0:ue.colorSchema,p.value)}),w=ye(()=>{var ue;return!!((ue=s.value)!=null&&ue.normalizeHeadingSizes)}),_=ye(()=>{var ue;return((ue=s.value)==null?void 0:ue.showUnorderedListMarkers)===!1}),M=ye(()=>{var ue;return((ue=s.value)==null?void 0:ue.showOrderedListMarkers)===!1}),A=ye(()=>Sl(d.value.width,d.value.height,g.value.baseWidth,g.value.baseHeight,14)),I=ye(()=>Sl(f.value.width,f.value.height,g.value.baseWidth,g.value.baseHeight,14));function N(){h.value&&(d.value={width:h.value.clientWidth,height:h.value.clientHeight}),y.value&&(f.value={width:y.value.clientWidth,height:y.value.clientHeight})}let H=null;function z(){typeof window>"u"||typeof window.ResizeObserver!="function"||(H||(H=new window.ResizeObserver(()=>{N()})),H.disconnect(),h.value&&H.observe(h.value),y.value&&H.observe(y.value))}Po([h,y,u],()=>{Mn(()=>{z(),N()})},{flush:"post"});const j=pe(0),B=pe(!0);let D=null,x=Date.now(),V=0;const W=ye(()=>{const ue=String(Math.floor(j.value/60)).padStart(2,"0"),fe=String(j.value%60).padStart(2,"0");return`${ue}:${fe}`});function $(){if(B.value){const ue=V+(Date.now()-x);j.value=Math.floor(ue/1e3)}}function T(){B.value?(V+=Date.now()-x,B.value=!1):(x=Date.now(),B.value=!0,$())}function O(){x=Date.now(),V=0,j.value=0}const te=pe("");let K=null;function Z(){const ue=new Date,fe=String(ue.getHours()).padStart(2,"0"),Qe=String(ue.getMinutes()).padStart(2,"0");te.value=`${fe}:${Qe}`}const ce=ye(()=>n.value.length===0?null:n.value[l.value-1]||null),oe=ye(()=>l.value>=n.value.length?null:n.value[l.value]||null);function re(ue){var _t;const fe=ue==null?void 0:ue.frontmatter;if((fe==null?void 0:fe.colorSchema)==="light")return"light";if((fe==null?void 0:fe.colorSchema)==="dark")return"dark";if(typeof(fe==null?void 0:fe.class)=="string"){const at=fe.class.split(/\s+/);if(at.includes("light"))return"light";if(at.includes("dark"))return"dark"}const Qe=(fe==null?void 0:fe.background)||((_t=s.value)==null?void 0:_t.background),lt=Ka(Qe);return lt===!0?"light":lt===!1?"dark":k.value}const Se=ye(()=>re(ce.value)),Ie=ye(()=>re(oe.value)),ve=ye(()=>ce.value?Ng(ce.value):c.value),_e=ye(()=>l.value>1||r.value>0),P=ye(()=>l.value<u.value||r.value<ve.value),ie=ye(()=>_l(ce.value,{config:s.value,allSlides:n.value,pageIndex:l.value,currentStep:r.value})),E=ye(()=>_l(oe.value,{config:s.value,allSlides:n.value,pageIndex:l.value+1})),F=ye(()=>{var fe;if(!ce.value)return"无内容";const ue=(fe=ce.value.blocks)==null?void 0:fe[0];return(ue==null?void 0:ue.content)||(ue==null?void 0:ue.rawMarkdown)||`第 ${l.value} 页`});function v(ue){return(ue||[]).slice(1).map(fe=>(fe.content||fe.rawMarkdown||"").trim()).filter(fe=>fe&&!/^(image\s+)?assets\/\S*$/i.test(fe)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(fe)).join(" | ").slice(0,120)}const U=ye(()=>{var ue;return v((ue=ce.value)==null?void 0:ue.blocks)}),R=ye(()=>{var fe;if(!oe.value)return"演示结束";const ue=(fe=oe.value.blocks)==null?void 0:fe[0];return(ue==null?void 0:ue.content)||(ue==null?void 0:ue.rawMarkdown)||`第 ${l.value+1} 页`}),S=ye(()=>oe.value?v(oe.value.blocks):"这是最后一页"),C=ye(()=>{var ue;return((ue=ce.value)==null?void 0:ue.notes)||""}),L=pe(20);function G(){L.value<36&&(L.value+=2)}function q(){L.value>14&&(L.value-=2)}const Y=ye(()=>u.value<=1?100:Math.round(l.value/u.value*100));let X=null;try{X=new BroadcastChannel("siyuan-slides-sync"),X.onmessage=ue=>{const fe=ue.data;if(fe&&(fe.type==="SYNC_PAGE"&&typeof fe.page=="number"&&(l.value=fe.page,r.value=typeof fe.step=="number"?Math.max(0,fe.step):0,typeof fe.maxStep=="number"&&(c.value=Math.max(0,fe.maxStep))),fe.type==="SYNC_SLIDES"&&Array.isArray(fe.slides)&&(n.value=fe.slides,fe.config&&typeof fe.config=="object"&&(s.value=fe.config)),fe.type==="REQUEST_SYNC"&&n.value.length>0))try{X==null||X.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(n.value)),config:JSON.parse(JSON.stringify(s.value||{}))}),X==null||X.postMessage({type:"SYNC_PAGE",page:l.value,step:r.value,maxStep:ve.value})}catch{}}}catch{X=null}function ae(ue,fe=0){const Qe=Number(ue)||1,lt=Math.max(0,Number(fe)||0);i.navigatePage(Qe,lt);try{X==null||X.postMessage({type:"SYNC_PAGE",page:Qe,step:lt,maxStep:ve.value})}catch{}}function ne(){if(r.value<ve.value){r.value++,ae(l.value,r.value);return}l.value<u.value&&(l.value++,r.value=0,ae(l.value,0))}function me(){if(r.value>0){r.value--,ae(l.value,r.value);return}l.value>1&&(l.value--,r.value=0,ae(l.value,0))}function Ce(){l.value<u.value&&(l.value++,r.value=0,ae(l.value,0))}function we(){l.value>1&&(l.value--,r.value=0,ae(l.value,0))}function Le(){l.value=1,r.value=0,O(),ae(1,0)}function He(){const ue=o;typeof(ue==null?void 0:ue.openBottomPreviewTab)=="function"&&ue.openBottomPreviewTab()}function Ge(){const ue=o;typeof(ue==null?void 0:ue.openStandalonePreviewWindow)=="function"&&ue.openStandalonePreviewWindow()}function rt(ue){var fe,Qe;if(!(ue.key===" "&&((Qe=(fe=ue.target)==null?void 0:fe.closest)!=null&&Qe.call(fe,"button")))){if(ue.shiftKey&&ue.key==="ArrowRight"||ue.key==="ArrowDown"){ue.preventDefault(),Ce();return}if(ue.shiftKey&&ue.key==="ArrowLeft"||ue.key==="ArrowUp"){ue.preventDefault(),we();return}ue.key==="ArrowRight"||ue.key===" "||ue.key==="PageDown"?(ue.preventDefault(),ne()):(ue.key==="ArrowLeft"||ue.key==="PageUp")&&(ue.preventDefault(),me())}}let Pe=0;function ft(ue){var lt,_t;if(Math.abs(ue.deltaY)<jy)return;const fe=(_t=(lt=ue.target)==null?void 0:lt.closest)==null?void 0:_t.call(lt,".notes-content");if(fe){const at=fe.scrollHeight-fe.clientHeight;if(at>2&&(ue.deltaY>0&&fe.scrollTop<at-1||ue.deltaY<0&&fe.scrollTop>1))return}const Qe=Date.now();Qe-Pe<Fy||(Pe=Qe,ue.deltaY>0?ne():me())}let tt=null,Ke=null;return Qo(()=>{var fe;p.value=zo(),Ke=Ya(Qe=>{p.value=Qe}),x=Date.now(),V=0,D=window.setInterval($,500),typeof document<"u"&&document.addEventListener("visibilitychange",$),Z(),K=window.setInterval(Z,1e3),tt=i.onSlideChanged((Qe,lt,_t,at,ro)=>{l.value=Qe,lt>0&&(a.value=lt),typeof at=="number"&&(r.value=Math.max(0,at)),typeof ro=="number"&&(c.value=Math.max(0,ro))});try{X==null||X.postMessage({type:"REQUEST_SYNC"})}catch{}const ue=o==null?void 0:o.latestCompiledDoc;(fe=ue==null?void 0:ue.slides)!=null&&fe.length&&(n.value=ue.slides,ue.config&&(s.value=ue.config)),typeof window<"u"&&window.addEventListener("resize",N),Mn(()=>{z(),N()})}),tn(()=>{Ke&&(Ke(),Ke=null),D&&(window.clearInterval(D),D=null),typeof document<"u"&&document.removeEventListener("visibilitychange",$),K&&(window.clearInterval(K),K=null),tt&&tt(),typeof window<"u"&&window.removeEventListener("resize",N),H&&(H.disconnect(),H=null);try{X==null||X.close()}catch{}X=null}),t({updateDocument(ue){var fe;(fe=ue==null?void 0:ue.slides)!=null&&fe.length&&(n.value=ue.slides),ue!=null&&ue.config&&(s.value=ue.config)}}),(ue,fe)=>{var Qe,lt,_t;return J(),ee("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:rt,onWheel:ft},[m("header",zg,[m("div",Hg,[m("div",Fg,[se(de,{name:"presenter",class:"brand-icon"}),fe[1]||(fe[1]=m("span",{class:"title-name"},"演讲者控制台",-1))]),m("div",jg,[m("span",Wg,"P."+ke(l.value)+" / "+ke(u.value||1),1),ve.value>0?(J(),ee("span",Ug,[se(de,{name:"step",class:"pill-icon"}),Et(" 步进 "+ke(r.value)+" / "+ke(ve.value),1)])):Te("",!0)])]),m("div",Vg,[m("button",{class:"btn-tool b3-tooltips b3-tooltips__s","aria-label":"弹出大屏放映独立窗口 (16:9)",onClick:Ge},[se(de,{name:"window"}),fe[2]||(fe[2]=m("span",{class:"btn-tool-label"},"独立放映",-1))]),m("div",qg,[se(de,{name:"clock",class:"timer-icon"}),m("span",Gg,ke(W.value),1),m("div",Kg,[m("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":B.value?"暂停计时":"继续计时",onClick:T},[se(de,{name:B.value?"pause":"play"},null,8,["name"])],8,Yg),m("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":"重置计时",onClick:O},[se(de,{name:"reset"})])])]),m("div",Zg,[m("span",null,ke(te.value),1)])])]),u.value>0?(J(),ee("main",Jg,[m("section",Xg,[m("div",Qg,[m("div",ey,[m("div",ty,[fe[3]||(fe[3]=m("span",{class:"panel-tag is-current"},"当前放映",-1)),m("span",oy,"P."+ke(l.value),1)]),m("div",iy,[ve.value>0?(J(),ee("span",ny," 步进 "+ke(r.value)+" / "+ke(ve.value),1)):Te("",!0),m("span",sy,ke(((lt=(Qe=ce.value)==null?void 0:Qe.frontmatter)==null?void 0:lt.layout)||"default"),1)])]),m("div",{ref_key:"currentPreviewRef",ref:h,class:"panel-preview","aria-label":F.value},[ce.value?(J(),ee("div",{key:0,class:"presenter-thumb-box",style:Qt({width:A.value.boxWidth+"px",height:A.value.boxHeight+"px"})},[m("div",{class:xe(["presenter-thumb-viewport slide-viewport","slides-theme-"+b.value]),"data-theme":Se.value,"data-slides-theme":b.value,"data-normalize-headings":w.value?"true":"false","data-hide-unordered-markers":_.value?"true":"false","data-hide-ordered-markers":M.value?"true":"false",style:Qt({width:g.value.baseWidth+"px",height:g.value.baseHeight+"px",transform:"scale("+A.value.scale+")"}),innerHTML:ie.value},null,14,ly)],4)):(J(),ee("div",ay,[m("h2",null,ke(F.value),1),m("p",null,ke(U.value),1)]))],8,ry)]),m("div",{class:xe(["panel-box next-slide-panel",{"is-clickable":!!oe.value,"b3-tooltips b3-tooltips__n":!!oe.value}]),"aria-label":oe.value?"点击直接跳至下一页":"",onClick:fe[0]||(fe[0]=at=>oe.value&&Ce())},[m("div",dy,[m("div",uy,[fe[4]||(fe[4]=m("span",{class:"panel-tag"},"下一页预告",-1)),l.value<u.value?(J(),ee("span",fy,"P."+ke(l.value+1),1)):Te("",!0)]),m("div",hy,[l.value>=u.value?(J(),ee("span",py,"已到尾页")):oe.value?(J(),ee("span",my,ke(((_t=oe.value.frontmatter)==null?void 0:_t.layout)||"default"),1)):Te("",!0)])]),m("div",{ref_key:"nextPreviewRef",ref:y,class:"panel-preview panel-preview--dim","aria-label":R.value},[oe.value?(J(),ee("div",{key:0,class:"presenter-thumb-box",style:Qt({width:I.value.boxWidth+"px",height:I.value.boxHeight+"px"})},[m("div",{class:xe(["presenter-thumb-viewport slide-viewport","slides-theme-"+b.value]),"data-theme":Ie.value,"data-slides-theme":b.value,"data-normalize-headings":w.value?"true":"false","data-hide-unordered-markers":_.value?"true":"false","data-hide-ordered-markers":M.value?"true":"false",style:Qt({width:g.value.baseWidth+"px",height:g.value.baseHeight+"px",transform:"scale("+I.value.scale+")"}),innerHTML:E.value},null,14,yy)],4)):(J(),ee("div",by,[m("h2",null,ke(R.value),1),m("p",null,ke(S.value),1)]))],8,gy)],10,cy)]),m("section",vy,[m("div",ky,[m("div",wy,[se(de,{name:"notes",class:"panel-title-icon"}),fe[5]||(fe[5]=m("span",null,"讲稿备忘",-1))]),m("div",xy,[m("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"减小字体",disabled:L.value<=14,onClick:q},[se(de,{name:"minus"})],8,Sy),m("span",_y,ke(L.value)+"px",1),m("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"增大字体",disabled:L.value>=36,onClick:G},[se(de,{name:"plus"})],8,Cy)])]),m("div",{class:xe(["notes-content",{"is-empty":!C.value}]),style:Qt({fontSize:L.value+"px"})},ke(C.value||"（本页未设置演讲者备忘录）"),7)])])):(J(),ee("main",Iy,[m("div",$y,[se(de,{name:"refresh",class:"empty-icon"})]),fe[8]||(fe[8]=m("h2",null,"等待大屏放映数据",-1)),fe[9]||(fe[9]=m("p",null,"未检测到活跃的幻灯片数据，请先开启大屏放映端。",-1)),m("div",Ay,[m("button",{class:"btn-empty-action b3-tooltips b3-tooltips__n","aria-label":"在思源中打开底部演示预览页签",onClick:He},[se(de,{name:"presenter"}),fe[6]||(fe[6]=m("span",null,"打开大屏放映页签",-1))]),m("button",{class:"btn-empty-action btn-empty-action--popout b3-tooltips b3-tooltips__n","aria-label":"将放映端弹出为独立窗口 (16:9)",onClick:Ge},[se(de,{name:"window"}),fe[7]||(fe[7]=m("span",null,"弹出独立放映窗口",-1))])])])),m("footer",Ty,[m("div",My,[m("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__ne",disabled:l.value<=1,"aria-label":"快速返回上一页 (Shift + ←)",onClick:we},[se(de,{name:"chevrons-left"}),fe[10]||(fe[10]=m("span",null,"上一页",-1))],8,By),m("button",{class:"btn-nav btn-nav--step b3-tooltips b3-tooltips__n",disabled:!_e.value,"aria-label":"回退一步 (←)",onClick:me},[se(de,{name:"chevron-left"}),fe[11]||(fe[11]=m("span",null,"上一步",-1))],8,Ey)]),m("div",Dy,[m("div",Ly,[m("span",Oy,ke(Y.value)+"%",1)]),m("button",{class:"btn-restart b3-tooltips b3-tooltips__n","aria-label":"从第一页重新放映 (Home)",onClick:Le},[se(de,{name:"reset"}),fe[12]||(fe[12]=m("span",null,"重头放映",-1))])]),m("div",Ny,[ve.value>0?(J(),ee("div",{key:0,class:"step-dots-bar b3-tooltips b3-tooltips__n","aria-label":`步进进度: ${r.value} / ${ve.value}`},[(J(!0),ee(Je,null,$t(ve.value,at=>(J(),ee("span",{key:at,class:xe(["step-dot",{"is-active":at<=r.value}])},null,2))),128)),m("span",Ry,ke(r.value)+"/"+ke(ve.value),1)],8,Py)):Te("",!0),m("button",{class:"btn-nav btn-nav--step btn-nav--primary b3-tooltips b3-tooltips__n",disabled:!P.value,"aria-label":"触发下一步骤或进入下一页 (Space / →)",onClick:ne},[fe[13]||(fe[13]=m("span",null,"下一步",-1)),se(de,{name:"chevron-right"})],8,zy),m("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__nw",disabled:l.value>=u.value,"aria-label":"跳过本页剩余步骤，直接进入下一页 (Shift + →)",onClick:Ce},[fe[14]||(fe[14]=m("span",null,"下一页",-1)),se(de,{name:"chevrons-right"})],8,Hy)])])],32)}}}),Uy=so(Wy,[["__scopeId","data-v-bb574b10"]]),Vy={class:"spm-layout-picker"},qy={class:"spm-layout-picker__grid"},Gy=["title","onClick"],Ky={class:"spm-layout-icon"},Yy={class:"spm-layout-label"},Zy=Pt({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const o=e,i=t,n=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function s(r){return o.modelValue===r||r==="cols-header"&&(o.modelValue==="two-cols-header"||o.modelValue==="three-cols-header")}function l(r){i("update:modelValue",r),i("change",r)}return(r,a)=>(J(),ee("div",Vy,[a[0]||(a[0]=m("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),m("div",qy,[(J(),ee(Je,null,$t(n,c=>m("div",{key:c.name,class:xe(["spm-layout-item",{active:s(c.name)}]),title:c.desc,onClick:u=>l(c.name)},[m("div",Ky,[se(de,{name:"layout-"+c.name},null,8,["name"])]),m("span",Yy,ke(c.label),1)],10,Gy)),64))])]))}}),Jy=so(Zy,[["__scopeId","data-v-96c8a248"]]),Xy={key:0,class:"spm-transition-selector__header"},Qy={class:"spm-transition-list"},eb=["onClick"],tb={class:"spm-transition-meta"},ob={class:"spm-transition-label"},ib={class:"spm-transition-preview-box"},nb=Pt({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const o=t,i=[{name:"slide-left",label:"向左滑入",desc:"向左滑入：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function n(s){o("update:modelValue",s),o("change",s)}return(s,l)=>(J(),ee("div",{class:xe(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Te("",!0):(J(),ee("div",Xy,ke(e.title||"转场动效"),1)),m("div",Qy,[(J(),ee(Je,null,$t(i,r=>m("div",{key:r.name,class:xe(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:a=>n(r.name)},[m("div",tb,[m("span",ob,ke(r.label),1)]),m("div",ib,[m("div",{class:xe(["spm-anim-cube","anim-"+r.name])},null,2)])],10,eb)),64))])],2))}}),fc=so(nb,[["__scopeId","data-v-b5051f69"]]),sb={class:"spm-section spm-section--page"},rb={class:"spm-section-header"},lb={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},ab={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},cb={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},db={key:1,class:"spm-card-control"},ub={class:"spm-control-header"},fb={class:"spm-control-title-group"},hb={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"设置各列横向空间占比，默认平均分配"},pb={class:"spm-quick-chips"},mb=["onClick"],gb={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},yb=["value"],bb=["aria-label"],vb={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__sw",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},kb={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},wb={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},xb={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Sb={class:"spm-card-control"},_b={class:"spm-control-header"},Cb={class:"spm-control-title-group"},Ib={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"随着点击操作分段展露正文内容"},$b={class:"spm-segmented-group"},Ab={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},Tb={style:{display:"flex","align-items":"center","justify-content":"space-between"}},Mb=["aria-label"],Bb={class:"spm-quick-chips"},Eb=["onClick"],Db=["value"],Lb={style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}},Ob={style:{display:"flex",gap:"8px","margin-top":"2px"}},Nb={style:{flex:"1"}},Pb={class:"spm-segmented-group"},Rb={style:{flex:"1"}},zb={class:"spm-segmented-group"},Hb={class:"spm-card-control"},Fb={class:"spm-control-header"},jb={class:"spm-control-title-group"},Wb={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"覆盖本页内衬、内容间隙与正文行距"},Ub={class:"spm-segmented-group"},Vb={key:2,class:"spm-card-control"},qb={class:"spm-control-header"},Gb={class:"spm-control-title-group"},Kb={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"图文分栏或页面专属配图 URL / 资源路径"},Yb={class:"spm-quick-chips"},Zb=["onClick"],Jb=["value"],Xb={class:"spm-card-control"},Qb={class:"spm-control-header"},ev={class:"spm-control-title-group"},tv={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"正文备注块驱动 · 仅演讲者视图可见"},ov={key:0,class:"spm-note-status-box"},iv=["title"],nv={class:"spm-action-grid",style:{"margin-top":"6px"}},sv={key:1,class:"spm-note-empty-box"},rv={class:"spm-card-control"},lv={class:"spm-action-grid"},av=["disabled","aria-label"],cv=Pt({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},canConvertToSuperBlock:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","insertDividerAfter","deleteDivider","convertToSuperBlock"],setup(e,{emit:t}){const o=e,i=t,n=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],s=ye(()=>{const k=o.pageMask;return k==="clockwise"||k==="counter-clockwise"||k==="cw"||k==="ccw"}),l=ye(()=>s.value?"1:1:1:1":"1:1"),r=ye(()=>o.pageMaskRatio||l.value);function a(k){i("update:pageMask",k),(!o.pageMaskRatio||o.pageMaskRatio==="1:1")&&i("update:pageMaskRatio","1:1:1:1")}function c(k){i("update:pageMask",k),(!o.pageMaskRatio||o.pageMaskRatio==="1:1:1:1")&&i("update:pageMaskRatio","1:1")}const u=ye(()=>o.pageMask==="clockwise"||o.pageMask==="counter-clockwise"||o.pageMask==="cw"||o.pageMask==="ccw"?`时钟走时规则：
• 顺时针：左上 → 右上 → 右下 → 左下
• 逆时针：左上 → 左下 → 右下 → 右上
• 每次点击时针旋转 90° 并扇形扫开 1/4 象限，全部揭开后翻页`:`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`),h=ye(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(o.pageLayout)),y=ye(()=>{var _,M;if(o.pageLayout==="two-cols-header"||o.pageLayout==="two-cols"||o.pageLayout==="image-left"||o.pageLayout==="image-right")return 2;if(o.pageLayout==="three-cols-header")return 3;const k=(o.pageLayoutRatio||"").trim();if(k.includes(":")){const A=k.split(":").filter(Boolean).length;if(A>=2&&A<=6)return A}const w=(o.detectedSbRatio||"").trim();if(w.includes(":")){const A=w.split(":").filter(Boolean).length;if(A>=2&&A<=6)return A}if((_=o.detectedSbInfo)!=null&&_.colCount&&o.detectedSbInfo.colCount>=2)return Math.min(o.detectedSbInfo.colCount,6);if((M=o.detectedSbInfo)!=null&&M.slots&&Array.isArray(o.detectedSbInfo.slots)){const A=o.detectedSbInfo.slots.length;if(A>=2&&A<=6)return A}return 2}),d=ye(()=>{const k=y.value;return k===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:k===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:k===5?[{label:"默认 1:1:1:1:1",value:""}]:k===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),f=ye(()=>o.pageLayoutRatio||"");function p(){const k=y.value||2,w=Array(k).fill("1").join(":");i("update:pageLayoutRatio",w),i("resetSuperblockRatio")}const g=ye(()=>{if(!o.pageNotes)return"";const k=o.pageNotes.replace(/[\r\n]+/g," ").trim();return k.length>50?k.slice(0,50)+"...":k}),b=[{label:"默认封面",value:"https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1920&q=80"},{label:"清空配图",value:""}];return(k,w)=>(J(),ee("div",sb,[m("div",rb,[m("span",null,"幻灯片页面设置"+ke(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),se(Jy,{"model-value":e.pageLayout,onChange:w[0]||(w[0]=_=>k.$emit("update:pageLayout",_))},null,8,["model-value"]),!h.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(J(),ee("div",lb,[m("div",ab,[m("div",cb,[se(de,{name:"sparkles"}),m("span",null,[w[30]||(w[30]=Et("检测到本页横向超级块列宽比例：",-1)),m("b",null,ke(e.detectedSbRatio),1)])]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键应用超级块列宽并设为分栏",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:w[1]||(w[1]=_=>k.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[se(de,{name:"columns"}),w[31]||(w[31]=m("span",null,"设为分栏",-1))])])])):Te("",!0),h.value?(J(),ee("div",db,[m("div",ub,[m("div",fb,[m("div",hb,[se(de,{name:"ratio"}),w[32]||(w[32]=m("span",null,"分栏比例",-1))])])]),m("div",pb,[(J(!0),ee(Je,null,$t(d.value,_=>(J(),ee("button",{key:_.value,class:xe(["spm-chip",{active:f.value===_.value}]),onClick:M=>k.$emit("update:pageLayoutRatio",_.value)},ke(_.label),11,mb))),128))]),m("div",gb,[m("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:w[2]||(w[2]=_=>k.$emit("update:pageLayoutRatio",_.target.value)),onChange:w[3]||(w[3]=_=>k.$emit("update:pageLayoutRatio",_.target.value))},null,40,yb),e.detectedSbRatio?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":`读取超级块列宽比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:w[4]||(w[4]=_=>k.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[se(de,{name:"sparkles"}),w[33]||(w[33]=m("span",null,"读取",-1))],8,bb)):(J(),ee("button",vb,[se(de,{name:"sparkles"}),w[34]||(w[34]=m("span",null,"读取",-1))])),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"重置为等宽平均分布",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:p},[se(de,{name:"reset"}),w[35]||(w[35]=m("span",null,"重置",-1))])]),e.detectedSbRatio?(J(),ee("div",kb,[se(de,{name:"ratio"}),w[36]||(w[36]=m("span",null,"检测到思源超级块宽度：",-1)),m("code",wb,ke(e.detectedSbRatio),1)])):(J(),ee("div",xb,[se(de,{name:"ratio"}),w[37]||(w[37]=m("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Te("",!0),se(fc,{"model-value":e.pageTransition,onChange:w[5]||(w[5]=_=>k.$emit("update:pageTransition",_))},null,8,["model-value"]),m("div",Sb,[m("div",_b,[m("div",Cb,[m("div",Ib,[se(de,{name:"sparkles"}),w[38]||(w[38]=m("span",null,"页面动态蒙版",-1))])])]),m("div",$b,[m("button",{class:xe(["spm-segmented-item",{active:!e.pageMask}]),onClick:w[6]||(w[6]=_=>k.$emit("update:pageMask",""))}," 关闭 ",2),m("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:w[7]||(w[7]=_=>c("down"))}," 从上至下 ",2),m("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:w[8]||(w[8]=_=>c("right"))}," 从左至右 ",2),m("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="clockwise"||e.pageMask==="cw"}]),onClick:w[9]||(w[9]=_=>a("clockwise"))}," 顺时针 ↻ ",2),m("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="counter-clockwise"||e.pageMask==="ccw"}]),onClick:w[10]||(w[10]=_=>a("counter-clockwise"))}," 逆时针 ↺ ",2)]),e.pageMask?(J(),ee("div",Ab,[m("div",Tb,[w[40]||(w[40]=m("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),m("span",{class:"b3-tooltips b3-tooltips__sw","aria-label":u.value,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},[se(de,{name:"help"}),w[39]||(w[39]=m("span",null,"输入规则",-1))],8,Mb)]),m("div",Bb,[(J(),ee(Je,null,$t(n,_=>m("button",{key:_.value,class:xe(["spm-chip",{active:r.value===_.value}]),onClick:M=>k.$emit("update:pageMaskRatio",_.value)},ke(_.label),11,Eb)),64))]),m("input",{value:r.value,class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:w[11]||(w[11]=_=>k.$emit("update:pageMaskRatio",_.target.value)),onChange:w[12]||(w[12]=_=>k.$emit("update:pageMaskRatio",_.target.value))},null,40,Db),m("div",Lb,ke(e.pageMask==="clockwise"||e.pageMask==="counter-clockwise"||e.pageMask==="cw"||e.pageMask==="ccw"?"时钟走时蒙版：默认 4 步旋转展露（1:1:1:1，每步 25% 扇形面积）":"提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数"),1),m("div",Ob,[m("div",Nb,[w[41]||(w[41]=m("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),m("div",Pb,[m("button",{class:xe(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:w[13]||(w[13]=_=>k.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),m("button",{class:xe(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:w[14]||(w[14]=_=>k.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),m("div",Rb,[w[42]||(w[42]=m("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),m("div",zb,[m("button",{class:xe(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:w[15]||(w[15]=_=>k.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),m("button",{class:xe(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:w[16]||(w[16]=_=>k.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Te("",!0)]),m("div",Hb,[m("div",Fb,[m("div",jb,[m("div",Wb,[se(de,{name:"ratio"}),w[43]||(w[43]=m("span",null,"页面间距",-1))])])]),m("div",Ub,[m("button",{class:xe(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:w[17]||(w[17]=_=>k.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),m("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.pageSpacing==="compact"}]),"aria-label":"紧凑排版：外衬 16/28px，块距 8px，行高 1.45",onClick:w[18]||(w[18]=_=>k.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),m("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.pageSpacing==="normal"}]),"aria-label":"标准排版：外衬 32/48px，块距 14px，行高 1.60",onClick:w[19]||(w[19]=_=>k.$emit("update:pageSpacing","normal"))}," 标准 ",2),m("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:e.pageSpacing==="loose"}]),"aria-label":"宽松排版：外衬 52/72px，块距 22px，行高 1.75",onClick:w[20]||(w[20]=_=>k.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(J(),ee("div",Vb,[m("div",qb,[m("div",Gb,[m("div",Kb,[se(de,{name:"image"}),w[44]||(w[44]=m("span",null,"页面图片",-1))])])]),m("div",Yb,[(J(),ee(Je,null,$t(b,_=>m("button",{key:_.value,class:xe(["spm-chip",{active:e.pageImage===_.value}]),onClick:M=>k.$emit("update:pageImage",_.value)},ke(_.label),11,Zb)),64))]),m("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL 或思源本地资源路径 (如 assets/...)",onInput:w[21]||(w[21]=_=>k.$emit("update:pageImage",_.target.value)),onChange:w[22]||(w[22]=_=>k.$emit("update:pageImage",_.target.value))},null,40,Jb)])):Te("",!0),m("div",Xb,[m("div",Qb,[m("div",ev,[m("div",tv,[se(de,{name:"presenter"}),w[45]||(w[45]=m("span",null,"演讲者提词",-1))])]),he(Dt)("aiScript")?(J(),ee("button",{key:0,class:"spm-btn-text b3-tooltips b3-tooltips__sw","aria-label":"AI 自动生成本页讲稿提示块",onClick:w[23]||(w[23]=_=>k.$emit("generateNotes"))},[se(de,{name:"sparkles"}),w[46]||(w[46]=m("span",null,"AI 讲稿",-1))])):Te("",!0)]),e.pageNotes?(J(),ee("div",ov,[w[49]||(w[49]=m("div",{class:"spm-note-status-badge"},[m("span",{class:"spm-badge-dot"}),m("span",null,"已配置正文讲稿")],-1)),m("div",{class:"spm-note-preview-text",title:e.pageNotes},ke(g.value),9,iv),m("div",nv,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:w[24]||(w[24]=_=>k.$emit("locateNoteBlock"))},[se(de,{name:"search"}),w[47]||(w[47]=m("span",null,"定位讲稿块",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在本页末尾追加新的讲稿提示块",onClick:w[25]||(w[25]=_=>k.$emit("addNoteBlock"))},[se(de,{name:"insert-below"}),w[48]||(w[48]=m("span",null,"追加讲稿块",-1))])])])):(J(),ee("div",sv,[w[51]||(w[51]=m("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:w[26]||(w[26]=_=>k.$emit("addNoteBlock"))},[se(de,{name:"insert-below"}),w[50]||(w[50]=m("span",null,"添加讲稿备注块",-1))])]))]),m("div",rv,[w[55]||(w[55]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),m("div",lv,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在此分页符之后插入新的空白分页",onClick:w[27]||(w[27]=_=>k.$emit("insertDividerAfter"))},[se(de,{name:"insert-below"}),w[52]||(w[52]=m("span",null,"插入新页",-1))]),m("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:w[28]||(w[28]=_=>k.$emit("deleteDivider"))},[se(de,{name:"trash"}),w[53]||(w[53]=m("span",null,"删除此页",-1))]),m("button",{class:xe(["spm-btn-action b3-tooltips b3-tooltips__s",{"is-disabled":!e.canConvertToSuperBlock}]),style:{"grid-column":"1 / -1"},disabled:!e.canConvertToSuperBlock,"aria-label":e.canConvertToSuperBlock?"将当前选中的多个块或列表项合并为横向超级块":"请在编辑区选中多个块，或选中一个列表/列表项",onClick:w[29]||(w[29]=_=>k.$emit("convertToSuperBlock"))},[se(de,{name:"columns"}),w[54]||(w[54]=m("span",null,"转为超级块",-1))],10,av)])])]))}}),dv=so(cv,[["__scopeId","data-v-708a9ee0"]]),uv={class:"spm-section spm-section--block"},fv={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},hv={class:"spm-control-header"},pv={class:"spm-control-title-group"},mv={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"读取思源超级块列宽并一键同步到幻灯片分栏"},gv={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},yv={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},bv={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},vv={key:0},kv={key:1},wv={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},xv={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},Sv={class:"spm-action-grid"},_v={key:1,class:"spm-card-control"},Cv={class:"spm-control-header"},Iv={class:"spm-control-title-group"},$v={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"设为幻灯片背景图或图文分栏配图"},Av={class:"spm-quick-chips"},Tv={key:2,class:"spm-card-control"},Mv={class:"spm-control-header"},Bv={class:"spm-control-title-group"},Ev={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"配置播放器控制条、自动播放与循环"},Dv={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},Lv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Ov={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Nv=["aria-label"],Pv=["checked"],Rv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},zv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Hv=["aria-label"],Fv=["checked"],jv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Wv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Uv=["aria-label"],Vv=["checked"],qv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Gv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Kv=["aria-label"],Yv=["checked"],Zv={class:"spm-card-control"},Jv={class:"spm-control-header"},Xv={class:"spm-control-title-group"},Qv={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"放映时按步长逐个呈现"},e1=["aria-label"],t1=["checked"],o1={key:0,class:"spm-quick-chips"},i1=["onClick"],n1={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},s1={class:"spm-card-control"},r1={class:"spm-control-header"},l1={class:"spm-control-title-group"},a1={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"为当前块添加平滑位移与渐入动画"},c1=["aria-label"],d1=["checked"],u1={key:0,class:"spm-quick-chips"},f1=["onClick"],h1={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},p1={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},m1={style:{display:"flex",gap:"6px"}},g1=["value"],y1=["value"],b1={key:3,class:"spm-card-control"},v1={class:"spm-control-header"},k1={class:"spm-control-title-group"},w1=["aria-label"],x1={class:"spm-segmented-group"},S1=["onClick"],_1={key:4,class:"spm-card-control"},C1={class:"spm-control-header"},I1={class:"spm-control-title-group"},$1={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"翻页时动态聚光高亮特定行"},A1={class:"spm-quick-chips"},T1=["onClick"],M1=["value"],B1={key:5,class:"spm-card-control"},E1={class:"spm-control-header"},D1={class:"spm-control-title-group"},L1={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"超出限高自动竖向滚动，弱提示滚动条"},O1={class:"spm-quick-chips"},N1=["onClick"],P1=["value"],R1={class:"spm-card-control"},z1={class:"spm-action-grid"},H1=["aria-label"],F1=["disabled","aria-label"],j1=["disabled","aria-label"],W1=Pt({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{},canConvertToSuperBlock:{type:Boolean}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","convertToSuperBlock","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const o=e,i=ye(()=>{const A=o.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(o.elemSlot)?"cols-header":A}),n=ye(()=>{const A=i.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(A)}),s=ye(()=>{var I,N,H,z;if((I=o.detectedSbInfo)!=null&&I.colCount&&o.detectedSbInfo.colCount>=2)return Math.min(o.detectedSbInfo.colCount,6);const A=(N=o.elemSlot)==null?void 0:N.match(/^col-(\d+)$/);if(A){const j=parseInt(A[1],10);if(j>=2&&j<=6)return Math.max(j,3)}if(o.currentSlideLayout==="three-cols-header")return 3;if(o.currentSlideLayout==="two-cols-header"||o.currentSlideLayout==="two-cols")return 2;if((z=(H=o.detectedSbInfo)==null?void 0:H.ratio)!=null&&z.includes(":")){const j=o.detectedSbInfo.ratio.split(":").filter(Boolean);if(j.length>=2)return Math.min(j.length,6)}return 3}),l=ye(()=>{const A=i.value;return A==="cols-header"?"多栏插槽归属":A==="three-cols-header"?"三栏插槽归属":A==="two-cols-header"?"带表头双栏插槽":"多栏插槽归属"}),r=ye(()=>{const A=i.value;return A==="cols-header"?`在 cols-header 表头多栏（${s.value} 栏）中的内容块位置`:A==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":A==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":A==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=ye(()=>{const A=i.value;if(A==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(A==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(A==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const I=s.value,N=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let H=1;H<=I;H++)N.push({value:`col-${H}`,label:`第 ${H} 栏`});return N});function c(A){const I=o.elemSlot||"";return A?I===A||A==="col-1"&&I==="left"||A==="col-2"&&I==="center"||A==="col-3"&&I==="right"&&s.value===3||A==="col-2"&&I==="right"&&s.value===2||A==="left"&&I==="col-1"||A==="right"&&(I==="col-2"||I==="col-3"):!I||I==="default"}const u=t,h=[{label:"上浮",value:"slide-up"},{label:"淡入",value:"fade-in"},{label:"下沉",value:"slide-down"},{label:"左滑",value:"slide-left"},{label:"右滑",value:"slide-right"},{label:"缩放",value:"zoom-in"},{label:"弹性",value:"bounce"}],y=ye(()=>{if(!o.elemMotion||o.elemMotion.trim()===""||o.elemMotion.trim()==="none")return null;try{const A=JSON.parse(o.elemMotion);if(typeof A=="object"&&A!==null)return{preset:A.preset||A.type||"slide-up",duration:typeof A.duration=="number"?A.duration:0,delay:typeof A.delay=="number"?A.delay:0}}catch{}return{preset:o.elemMotion.trim(),duration:0,delay:0}}),d=ye(()=>!!y.value),f=ye(()=>{var A;return((A=y.value)==null?void 0:A.preset)||"slide-up"}),p=ye(()=>{var A;return((A=y.value)==null?void 0:A.duration)||0}),g=ye(()=>{var A;return((A=y.value)==null?void 0:A.delay)||0});function b(){d.value?u("update:elemMotion",""):u("update:elemMotion","slide-up")}function k(A){M(A,p.value,g.value)}function w(A){M(f.value,A,g.value)}function _(A){M(f.value,p.value,A)}function M(A,I,N){if(!A||A==="none"){u("update:elemMotion","");return}if(!I&&!N){u("update:elemMotion",A);return}const H={preset:A};I>0&&(H.duration=I),N>0&&(H.delay=N),u("update:elemMotion",JSON.stringify(H))}return(A,I)=>{var N,H,z,j,B,D;return J(),ee("div",uv,[I[53]||(I[53]=m("div",{class:"spm-section-header"},[m("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(N=e.detectedSbInfo)!=null&&N.hasSuperBlock?(J(),ee("div",fv,[m("div",hv,[m("div",pv,[m("div",mv,[se(de,{name:"ratio"}),I[24]||(I[24]=m("span",null,"超级块列宽与布局",-1))])])]),m("div",gv,[m("div",yv,[m("div",bv,[se(de,{name:"ratio"}),(H=e.detectedSbInfo)!=null&&H.isCustomWidth?(J(),ee("span",vv,"已识别自定义列宽比例")):(J(),ee("span",kv,"识别到 "+ke(((z=e.detectedSbInfo)==null?void 0:z.colCount)||2)+" 列超级块分栏",1))]),m("code",wv,ke(((j=e.detectedSbInfo)==null?void 0:j.ratio)||"1:1"),1)]),m("div",xv,ke((B=e.detectedSbInfo)!=null&&B.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),m("div",Sv,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:I[0]||(I[0]=x=>A.$emit("applySuperBlockLayout",e.detectedSbInfo))},[se(de,{name:"sparkles"}),I[25]||(I[25]=m("span",null,"应用版式与比例",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:I[1]||(I[1]=x=>{var V;return A.$emit("applySuperBlockRatio",((V=e.detectedSbInfo)==null?void 0:V.ratio)||"1:1")})},[se(de,{name:"check"}),m("span",null,"应用比例 ("+ke(((D=e.detectedSbInfo)==null?void 0:D.ratio)||"1:1")+")",1)])])])):Te("",!0),e.isImage||e.imageRole?(J(),ee("div",_v,[m("div",Cv,[m("div",Iv,[m("div",$v,[se(de,{name:"image"}),I[26]||(I[26]=m("span",null,"图片角色与分栏",-1))])])]),m("div",Av,[m("button",{class:xe(["spm-chip",{active:!e.imageRole}]),onClick:I[2]||(I[2]=x=>A.$emit("update:imageRole",""))}," 普通内容 ",2),m("button",{class:xe(["spm-chip",{active:e.imageRole==="background"}]),onClick:I[3]||(I[3]=x=>A.$emit("update:imageRole","background"))},[se(de,{name:"image"}),I[27]||(I[27]=m("span",null,"背景图",-1))],2),m("button",{class:xe(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:I[4]||(I[4]=x=>A.$emit("update:imageRole","image-left"))},[se(de,{name:"image-left"}),I[28]||(I[28]=m("span",null,"图左",-1))],2),m("button",{class:xe(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:I[5]||(I[5]=x=>A.$emit("update:imageRole","image-right"))},[se(de,{name:"image-right"}),I[29]||(I[29]=m("span",null,"图右",-1))],2)])])):Te("",!0),e.isVideo?(J(),ee("div",Tv,[m("div",Mv,[m("div",Bv,[m("div",Ev,[se(de,{name:"video"}),I[30]||(I[30]=m("span",null,"视频播放设置",-1))])])]),m("div",Dv,[m("div",Lv,[m("span",Ov,[se(de,{name:"sliders"}),I[31]||(I[31]=Et(" 控制条",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[m("input",{type:"checkbox",checked:!!e.videoControls,onChange:I[6]||(I[6]=x=>A.$emit("toggleVideoControls"))},null,40,Pv),I[32]||(I[32]=m("span",{class:"spm-switch-slider"},null,-1))],8,Nv)]),m("div",Rv,[m("span",zv,[se(de,{name:"video"}),I[33]||(I[33]=Et(" 自动播放",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[m("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:I[7]||(I[7]=x=>A.$emit("toggleVideoAutoplay"))},null,40,Fv),I[34]||(I[34]=m("span",{class:"spm-switch-slider"},null,-1))],8,Hv)]),m("div",jv,[m("span",Wv,[se(de,{name:"repeat"}),I[35]||(I[35]=Et(" 循环播放",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[m("input",{type:"checkbox",checked:!!e.videoLoop,onChange:I[8]||(I[8]=x=>A.$emit("toggleVideoLoop"))},null,40,Vv),I[36]||(I[36]=m("span",{class:"spm-switch-slider"},null,-1))],8,Uv)]),m("div",qv,[m("span",Gv,[se(de,{name:"volume-x"}),I[37]||(I[37]=Et(" 静音播放",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoMuted?"关闭静音":"开启静音"},[m("input",{type:"checkbox",checked:!!e.videoMuted,onChange:I[9]||(I[9]=x=>A.$emit("toggleVideoMuted"))},null,40,Yv),I[38]||(I[38]=m("span",{class:"spm-switch-slider"},null,-1))],8,Kv)])])])):Te("",!0),m("div",Zv,[m("div",Jv,[m("div",Xv,[m("div",Qv,[se(de,{name:"step"}),I[39]||(I[39]=m("span",null,"逐步呈现",-1))])]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[m("input",{type:"checkbox",checked:!!e.elemClick,onChange:I[10]||(I[10]=x=>A.$emit("toggleElemClick"))},null,40,t1),I[40]||(I[40]=m("span",{class:"spm-switch-slider"},null,-1))],8,e1)]),e.elemClick?(J(),ee("div",o1,[(J(),ee(Je,null,$t(["+1","1","2","hide"],x=>m("button",{key:x,class:xe(["spm-chip",{active:e.elemClick===x}]),onClick:V=>A.$emit("update:elemClick",x)},ke(x==="+1"?"顺延 (+1)":x==="hide"?"隐藏":"第 "+x+" 步"),11,i1)),64))])):e.parentElemClick?(J(),ee("div",n1,[se(de,{name:"check"}),I[41]||(I[41]=m("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Te("",!0)]),m("div",s1,[m("div",r1,[m("div",l1,[m("div",a1,[se(de,{name:"motion"}),I[42]||(I[42]=m("span",null,"入场微动效",-1))])]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":d.value?"关闭微动效":"开启微动效"},[m("input",{type:"checkbox",checked:d.value,onChange:b},null,40,d1),I[43]||(I[43]=m("span",{class:"spm-switch-slider"},null,-1))],8,c1)]),d.value?(J(),ee("div",u1,[(J(),ee(Je,null,$t(h,x=>m("button",{key:x.value,class:xe(["spm-chip",{active:f.value===x.value}]),onClick:V=>k(x.value)},ke(x.label),11,f1)),64))])):Te("",!0),d.value?(J(),ee("div",h1,[m("div",p1,[m("span",null,"时长: "+ke(p.value?p.value+"ms":"默认 (450ms)"),1),m("span",null,"延迟: "+ke(g.value?g.value+"ms":"0ms"),1)]),m("div",m1,[m("select",{class:"spm-select",style:{flex:"1"},value:p.value,onChange:I[11]||(I[11]=x=>w(Number(x.target.value)))},[...I[44]||(I[44]=[m("option",{value:0},"默认耗时",-1),m("option",{value:200},"极速 (200ms)",-1),m("option",{value:350},"较快 (350ms)",-1),m("option",{value:500},"平滑 (500ms)",-1),m("option",{value:800},"缓慢 (800ms)",-1)])],40,g1),m("select",{class:"spm-select",style:{flex:"1"},value:g.value,onChange:I[12]||(I[12]=x=>_(Number(x.target.value)))},[...I[45]||(I[45]=[m("option",{value:0},"无延迟",-1),m("option",{value:150},"延迟 150ms",-1),m("option",{value:300},"延迟 300ms",-1),m("option",{value:500},"延迟 500ms",-1)])],40,y1)])])):Te("",!0)]),n.value||e.elemSlot?(J(),ee("div",b1,[m("div",v1,[m("div",k1,[m("div",{class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":r.value},[se(de,{name:"columns"}),m("span",null,ke(l.value),1)],8,w1)])]),m("div",x1,[(J(!0),ee(Je,null,$t(a.value,x=>(J(),ee("button",{key:x.value,class:xe(["spm-segmented-item",{active:c(x.value)}]),onClick:V=>A.$emit("update:elemSlot",x.value)},ke(x.label),11,S1))),128))])])):Te("",!0),e.isCodeBlock?(J(),ee("div",_1,[m("div",C1,[m("div",I1,[m("div",$1,[se(de,{name:"code"}),I[46]||(I[46]=m("span",null,"代码逐行聚光",-1))])])]),m("div",A1,[(J(),ee(Je,null,$t(["1-3","all","1|2|3","2-5"],x=>m("button",{key:x,class:xe(["spm-chip",{active:e.elemShikiLines===x}]),onClick:V=>A.$emit("update:elemShikiLines",x)},ke(x),11,T1)),64)),e.elemShikiLines?(J(),ee("button",{key:0,class:"spm-chip spm-chip-clear",onClick:I[13]||(I[13]=x=>A.$emit("update:elemShikiLines",""))}," 清空 ")):Te("",!0)]),m("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:I[14]||(I[14]=x=>A.$emit("update:elemShikiLines",x.target.value)),onChange:I[15]||(I[15]=x=>A.$emit("update:elemShikiLines",x.target.value))},null,40,M1)])):Te("",!0),e.isCodeBlock?(J(),ee("div",B1,[m("div",E1,[m("div",D1,[m("div",L1,[se(de,{name:"code"}),I[47]||(I[47]=m("span",null,"代码块限高",-1))])])]),m("div",O1,[(J(),ee(Je,null,$t(["240px","320px","400px","50%"],x=>m("button",{key:x,class:xe(["spm-chip",{active:e.elemMaxHeight===x||x==="50%"&&(e.elemMaxHeight==="50vh"||e.elemMaxHeight==="50%")}]),onClick:V=>A.$emit("update:elemMaxHeight",x)},ke(x),11,N1)),64)),e.elemMaxHeight?(J(),ee("button",{key:0,class:"spm-chip spm-chip-clear",onClick:I[16]||(I[16]=x=>A.$emit("update:elemMaxHeight",""))}," 自适应 ")):Te("",!0)]),m("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50%",onInput:I[17]||(I[17]=x=>A.$emit("update:elemMaxHeight",x.target.value)),onChange:I[18]||(I[18]=x=>A.$emit("update:elemMaxHeight",x.target.value))},null,40,P1)])):Te("",!0),m("div",R1,[I[52]||(I[52]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"快捷操作")])],-1)),m("div",z1,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:I[19]||(I[19]=x=>A.$emit("insertDividerBefore"))},[se(de,{name:"insert-above"}),I[48]||(I[48]=m("span",null,"上方分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:I[20]||(I[20]=x=>A.$emit("insertDividerAfter"))},[se(de,{name:"insert-below"}),I[49]||(I[49]=m("span",null,"下方分页",-1))]),m("button",{class:xe(["spm-btn-action b3-tooltips b3-tooltips__se",{"spm-btn-action--active":!!e.isNote}]),"aria-label":e.isNote?"取消当前块的演示讲稿备注":"将当前块设为演示讲稿备注",onClick:I[21]||(I[21]=x=>A.$emit("toggleNote"))},[se(de,{name:"presenter"}),m("span",null,ke(e.isNote?"取消备注":"设为备注"),1)],10,H1),m("button",{class:xe(["spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw",{"is-disabled":!e.hasBlockAttrs}]),disabled:!e.hasBlockAttrs,"aria-label":e.hasBlockAttrs?"一键移除本块所有 custom-slides 演示属性":"当前块无演示属性",onClick:I[22]||(I[22]=x=>A.$emit("clearBlockAttrs"))},[se(de,{name:"broom"}),I[50]||(I[50]=m("span",null,"清除属性",-1))],10,F1),m("button",{class:xe(["spm-btn-action b3-tooltips b3-tooltips__s",{"is-disabled":!e.canConvertToSuperBlock}]),style:{"grid-column":"1 / -1"},disabled:!e.canConvertToSuperBlock,"aria-label":e.canConvertToSuperBlock?"将当前选中的多个块或列表项合并为横向超级块":"请在编辑区选中多个块，或选中一个列表/列表项",onClick:I[23]||(I[23]=x=>A.$emit("convertToSuperBlock"))},[se(de,{name:"columns"}),I[51]||(I[51]=m("span",null,"转为超级块",-1))],10,j1)])])])}}}),U1={class:"spm-section spm-section--doc"},V1={class:"spm-card-control"},q1={class:"spm-control-header"},G1={class:"spm-control-title-group"},K1={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"全局幻灯片视觉设计范式"},Y1={class:"spm-theme-card-grid"},Z1=["aria-label","onClick"],J1={key:0,class:"spm-bg-swatch-check"},X1={class:"spm-theme-card-label"},Q1={class:"spm-card-control"},e0={class:"spm-control-header"},t0={class:"spm-control-title-group"},o0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"全篇幻灯片统一底色、微渐变或壁纸"},i0={class:"spm-bg-swatch-grid"},n0=["aria-label","onClick"],s0={key:0,class:"spm-bg-swatch-check"},r0={class:"spm-bg-swatch-label"},l0={class:"spm-bg-input-row"},a0=["value"],c0={class:"spm-card-control"},d0={class:"spm-control-header"},u0={class:"spm-control-title-group"},f0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"演讲屏幕投影宽高比"},h0={class:"spm-segmented-group"},p0={class:"spm-card-control"},m0={class:"spm-control-header"},g0={class:"spm-control-title-group"},y0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"内衬、内容间隙与正文行距预设"},b0={class:"spm-segmented-group"},v0={class:"spm-card-control"},k0={class:"spm-control-header"},w0={class:"spm-control-title-group"},x0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"页面切换过渡动效（未单设转场的页面将继承此动效）"},S0={class:"spm-card-control"},_0={class:"spm-action-grid"},C0=["disabled"],I0=["disabled"],$0=["disabled"],A0=["disabled"],T0=["aria-expanded"],M0={class:"spm-advanced-toggle-label"},B0={key:0,class:"spm-advanced-content"},E0={class:"spm-card-control"},D0={class:"spm-control-header"},L0={class:"spm-control-title-group"},O0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"点击文档/块链接以 Webview 抽屉呈现，支持外跳"},N0=["aria-label"],P0=["checked"],R0={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},z0=["value"],H0={class:"spm-card-control"},F0={class:"spm-control-header"},j0={class:"spm-control-title-group"},W0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示"},U0=["aria-label"],V0=["checked"],q0={class:"spm-card-control"},G0={class:"spm-control-header"},K0={class:"spm-control-title-group"},Y0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"分别控制正文中无序列表圆点与有序列表数字序号的呈现"},Z0={class:"spm-list-markers-toggles",style:{display:"flex",gap:"8px","margin-top":"8px"}},J0={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},X0=["aria-label"],Q0=["checked"],ek={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},tk=["aria-label"],ok=["checked"],ik=Pt({__name:"DocInspectorSection",props:{docTheme:{},docBackground:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{},isBatchProcessing:{type:Boolean}},emits:["update:docTheme","update:docBackground","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","addOrIdentifyNotes","clearNotes","autoAnimate","clearAnimations","aiAutoSplit","clearDividers","exportHtml","exportPdf"],setup(e){const t=Wt("plugin"),o=Yt,i=pe(!1),n=[{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"},{value:"tech",label:"科技 tech",desc:"科技风：现代无衬线排版、Emerald 绿青双色指示与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"}];function s(d){uo({enableWebServeJump:d}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({enableWebServeJump:d})}async function l(d){var f;uo({normalizeHeadingSizes:d}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({normalizeHeadingSizes:d}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((f=t.getActiveDocumentId)==null?void 0:f.call(t)))}async function r(d){var f;uo({showUnorderedListMarkers:d}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showUnorderedListMarkers:d}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((f=t.getActiveDocumentId)==null?void 0:f.call(t)))}async function a(d){var f;uo({showOrderedListMarkers:d}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showOrderedListMarkers:d}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((f=t.getActiveDocumentId)==null?void 0:f.call(t)))}function c(d){uo({webServeUrl:d})}function u(d){uo({webServeUrl:d}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({webServeUrl:d})}const h=[{label:"默认",value:"",mode:"auto",desc:"跟随当前幻灯片主题与明暗模式自适应底色"},{label:"极简白",value:"#ffffff",mode:"light",desc:"纯净高对比白底 (#ffffff)，自动切换深色文字"},{label:"暖羊皮",value:"#f5efe6",mode:"light",desc:"温润护眼米棕纸张底 (#f5efe6)，自动切换深色文字"},{label:"晴空薄荷",value:"linear-gradient(135deg, #e0f2fe 0%, #dcfce7 100%)",mode:"light",desc:"清透天蓝至薄荷微渐变，自动切换深色文字"},{label:"晨曦微光",value:"linear-gradient(135deg, #fef3c7 0%, #fce7f3 100%)",mode:"light",desc:"柔和暖金至淡樱微渐变，自动切换深色文字"},{label:"曜石炭黑",value:"#18181b",mode:"dark",desc:"中性深炭黑 (#18181b)，区别于默认深海蓝底"},{label:"松墨深绿",value:"#0d2621",mode:"dark",desc:"沉稳森林墨绿 (#0d2621)，自动切换浅色文字"},{label:"极光紫青",value:"linear-gradient(135deg, #1e1b4b 0%, #0f3d4c 100%)",mode:"dark",desc:"深邃靛紫至极光青渐变，自动切换浅色文字"},{label:"深空靛蓝",value:"linear-gradient(135deg, #172554 0%, #312e81 100%)",mode:"dark",desc:"科技深空蓝至暮色紫渐变，自动切换浅色文字"}];function y(d){const f=(d||"").trim();return f?/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(f)?{backgroundImage:`url("${f.startsWith("assets/")?`/${f}`:f.startsWith("./assets/")?f.slice(1):f}")`,backgroundSize:"cover",backgroundPosition:"center"}:{background:f}:{background:"linear-gradient(135deg, #f8fafc 50%, #090d16 50%)"}}return(d,f)=>(J(),ee("div",U1,[f[56]||(f[56]=m("div",{class:"spm-section-header"},[m("span",null,"全局演示配置")],-1)),m("div",V1,[m("div",q1,[m("div",G1,[m("div",K1,[se(de,{name:"palette"}),f[29]||(f[29]=m("span",null,"幻灯片主题",-1))])])]),m("div",Y1,[(J(),ee(Je,null,$t(n,(p,g)=>m("button",{key:p.value,type:"button",class:xe(["spm-theme-card b3-tooltips",["is-"+p.value,g===0?"b3-tooltips__ne":g===n.length-1?"b3-tooltips__nw":"b3-tooltips__n",{active:e.docTheme===p.value}]]),"aria-label":p.desc,onClick:b=>d.$emit("update:docTheme",p.value)},[m("span",{class:xe(["spm-theme-card-preview","theme-preview--"+p.value]),"aria-hidden":"true"},[f[30]||(f[30]=ht('<span class="spm-theme-card-canvas"><span class="spm-theme-card-title">Aa</span><span class="spm-theme-card-lines"><span class="spm-theme-card-line is-primary"></span><span class="spm-theme-card-line is-secondary"></span></span></span>',1)),e.docTheme===p.value?(J(),ee("span",J1,"✓")):Te("",!0)],2),m("span",X1,ke(p.label),1)],10,Z1)),64))])]),m("div",Q1,[m("div",e0,[m("div",t0,[m("div",o0,[se(de,{name:"palette"}),f[31]||(f[31]=m("span",null,"演示背景",-1))])])]),m("div",i0,[(J(),ee(Je,null,$t(h,p=>m("button",{key:p.value||"__default__",type:"button",class:xe(["spm-bg-swatch b3-tooltips b3-tooltips__n",{active:(e.docBackground||"")===p.value,"is-default":!p.value}]),"aria-label":p.desc,onClick:g=>d.$emit("update:docBackground",p.value)},[m("span",{class:"spm-bg-swatch-preview",style:Qt(y(p.value))},[m("span",{class:xe(["spm-bg-swatch-aa","is-"+p.mode])},"Aa",2),(e.docBackground||"")===p.value?(J(),ee("span",s0,"✓")):Te("",!0)],4),m("span",r0,ke(p.label),1)],10,n0)),64))]),m("div",l0,[m("span",{class:"spm-bg-input-preview",style:Qt(y(e.docBackground||"")),"aria-hidden":"true"},null,4),m("input",{value:e.docBackground||"",class:"spm-input spm-bg-input",placeholder:"自定义：#hex / gradient / assets/...",onInput:f[0]||(f[0]=p=>d.$emit("update:docBackground",p.target.value)),onChange:f[1]||(f[1]=p=>d.$emit("update:docBackground",p.target.value))},null,40,a0),e.docBackground?(J(),ee("button",{key:0,type:"button",class:"spm-bg-input-clear b3-tooltips b3-tooltips__nw","aria-label":"清除并恢复默认背景",onClick:f[2]||(f[2]=p=>d.$emit("update:docBackground",""))}," ✕ ")):Te("",!0)])]),m("div",c0,[m("div",d0,[m("div",u0,[m("div",f0,[se(de,{name:"ratio"}),f[32]||(f[32]=m("span",null,"画幅比例",-1))])])]),m("div",h0,[m("button",{class:xe(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:f[3]||(f[3]=p=>d.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),m("button",{class:xe(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:f[4]||(f[4]=p=>d.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),m("button",{class:xe(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:f[5]||(f[5]=p=>d.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),m("div",p0,[m("div",m0,[m("div",g0,[m("div",y0,[se(de,{name:"ratio"}),f[33]||(f[33]=m("span",null,"间距风格",-1))])])]),m("div",b0,[m("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__se",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：外衬 16/28px，块距 8px，行高 1.45",onClick:f[6]||(f[6]=p=>d.$emit("update:docSpacing","compact"))}," 紧凑 ",2),m("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：外衬 32/48px，块距 14px，行高 1.60（推荐默认）",onClick:f[7]||(f[7]=p=>d.$emit("update:docSpacing","normal"))}," 标准 ",2),m("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：外衬 52/72px，块距 22px，行高 1.75",onClick:f[8]||(f[8]=p=>d.$emit("update:docSpacing","loose"))}," 宽松 ",2)])]),m("div",v0,[m("div",k0,[m("div",w0,[m("div",x0,[se(de,{name:"transition"}),f[34]||(f[34]=m("span",null,"全局默认转场",-1))])])]),se(fc,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:f[9]||(f[9]=p=>d.$emit("update:docDefaultTransition",p))},null,8,["model-value"])]),m("div",S0,[f[45]||(f[45]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"演示全局操作")])],-1)),m("div",_0,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:f[10]||(f[10]=p=>d.$emit("openBottomPreview"))},[se(de,{name:"split-preview"}),f[35]||(f[35]=m("span",null,"分屏预览",-1))]),he(Dt)("presenterMode")?(J(),ee("button",{key:0,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:f[11]||(f[11]=p=>d.$emit("openPresenter"))},[se(de,{name:"presenter"}),f[36]||(f[36]=m("span",null,"演讲者视图",-1))])):Te("",!0),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"识别已有候选讲稿并为空白页新增默认讲稿块（不会重复添加）",disabled:e.isBatchProcessing,onClick:f[12]||(f[12]=p=>d.$emit("addOrIdentifyNotes"))},[se(de,{name:"notes"}),f[37]||(f[37]=m("span",null,"增加讲稿块",-1))],8,C0),m("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"物理删除文档中所有页面的全部讲稿备注块（需二次确认）",disabled:e.isBatchProcessing,onClick:f[13]||(f[13]=p=>d.$emit("clearNotes"))},[se(de,{name:"trash"}),f[38]||(f[38]=m("span",null,"清除讲稿块",-1))],8,I0),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"自动为正文各页标题及首块之外的后续内容块配置顺延 (+1) 逐步呈现动效",disabled:e.isBatchProcessing,onClick:f[14]||(f[14]=p=>d.$emit("autoAnimate"))},[se(de,{name:"step"}),f[39]||(f[39]=m("span",null,"智能动效",-1))],8,$0),m("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"清除所有页面内容块的逐步显现与入场微动效配置（需二次确认）",disabled:e.isBatchProcessing,onClick:f[15]||(f[15]=p=>d.$emit("clearAnimations"))},[se(de,{name:"trash"}),f[40]||(f[40]=m("span",null,"清除动效",-1))],8,A0),he(Dt)("aiScript")?(J(),ee("button",{key:1,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"智能分析长文本大纲与篇幅，自动插入分页线",onClick:f[16]||(f[16]=p=>d.$emit("aiAutoSplit"))},[se(de,{name:"sparkles"}),f[41]||(f[41]=m("span",null,"智能分页",-1))])):Te("",!0),he(Dt)("aiScript")?(J(),ee("button",{key:2,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键清除当前文档中的所有幻灯片分页线",onClick:f[17]||(f[17]=p=>d.$emit("clearDividers"))},[se(de,{name:"trash"}),f[42]||(f[42]=m("span",null,"清除分页",-1))])):Te("",!0),he(Dt)("exportHtml")?(J(),ee("button",{key:3,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:f[18]||(f[18]=p=>d.$emit("exportHtml"))},[se(de,{name:"export-html"}),f[43]||(f[43]=m("span",null,"导出 HTML",-1))])):Te("",!0),he(Dt)("exportPdf")?(J(),ee("button",{key:4,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:f[19]||(f[19]=p=>d.$emit("exportPdf"))},[se(de,{name:"export-pdf"}),f[44]||(f[44]=m("span",null,"导出 PDF",-1))])):Te("",!0)])]),m("div",{class:xe(["spm-advanced-menu",{"is-expanded":i.value}])},[m("button",{type:"button",class:"spm-advanced-toggle","aria-expanded":i.value,onClick:f[20]||(f[20]=p=>i.value=!i.value)},[m("span",M0,[se(de,{name:"settings"}),f[46]||(f[46]=m("span",null,"高级设置",-1))]),se(de,{name:"chevron-right",class:"spm-advanced-chevron"})],8,T0),i.value?(J(),ee("div",B0,[m("div",E0,[m("div",D0,[m("div",L0,[m("div",O0,[se(de,{name:"external-link"}),f[47]||(f[47]=m("span",null,"本地网络伺服预览",-1))])]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(o).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[m("input",{type:"checkbox",checked:he(o).enableWebServeJump,onChange:f[21]||(f[21]=p=>s(p.target.checked))},null,40,P0),f[48]||(f[48]=m("span",{class:"spm-switch-slider"},null,-1))],8,N0)]),he(o).enableWebServeJump?(J(),ee("div",R0,[m("input",{value:he(o).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:f[22]||(f[22]=eo(()=>{},["stop"])),onKeyup:f[23]||(f[23]=eo(()=>{},["stop"])),onInput:f[24]||(f[24]=p=>c(p.target.value)),onChange:f[25]||(f[25]=p=>u(p.target.value))},null,40,z0)])):Te("",!0)]),m("div",H0,[m("div",F0,[m("div",j0,[m("div",W0,[se(de,{name:"type"}),f[49]||(f[49]=m("span",null,"固定特定标题大小",-1))])]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(o).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[m("input",{type:"checkbox",checked:he(o).normalizeHeadingSizes,onChange:f[26]||(f[26]=p=>l(p.target.checked))},null,40,V0),f[50]||(f[50]=m("span",{class:"spm-switch-slider"},null,-1))],8,U0)])]),m("div",q0,[m("div",G0,[m("div",K0,[m("div",Y0,[se(de,{name:"list"}),f[51]||(f[51]=m("span",null,"列表前缀标记",-1))])])]),m("div",Z0,[m("div",J0,[f[53]||(f[53]=m("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"无序圆点",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(o).showUnorderedListMarkers?"关闭无序列表圆点显示":"开启无序列表圆点显示"},[m("input",{type:"checkbox",checked:he(o).showUnorderedListMarkers,onChange:f[27]||(f[27]=p=>r(p.target.checked))},null,40,Q0),f[52]||(f[52]=m("span",{class:"spm-switch-slider"},null,-1))],8,X0)]),m("div",ek,[f[55]||(f[55]=m("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"有序序号",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(o).showOrderedListMarkers?"关闭有序列表序号显示":"开启有序列表序号显示"},[m("input",{type:"checkbox",checked:he(o).showOrderedListMarkers,onChange:f[28]||(f[28]=p=>a(p.target.checked))},null,40,ok),f[54]||(f[54]=m("span",{class:"spm-switch-slider"},null,-1))],8,tk)])])])])):Te("",!0)],2)]))}}),nk=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,sk=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function rk(e){const t=await sc.loadAsync(e),o={},i=[];let n="",s="";const l=[];t.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(n=await r.file.async("string"),s=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||sk.test(c)||c.includes("snippets/")){const u=await a.file.async("string");o[c]=u;const h=c.split("/");h.length>1&&(o[h.slice(1).join("/")]=u)}else if(nk.test(c)){const u=await a.file.async("uint8array"),h=c.split("/").pop()||c,y=typeof Blob<"u"?new Blob([u]):void 0;i.push({zipPath:c,fileName:h,data:u,blob:y})}}return{entryMarkdown:n,entryMarkdownPath:s,virtualFiles:o,assets:i}}function lk(e,t){if(Object.keys(t).length===0)return e;function o(n){const s=n.trim().replace(/^['"]|['"]$/g,""),l=s.split("/").pop()||s;if(t[s])return t[s];const r=s.replace(/^\.?\//,"");return t[r]?t[r]:t[l]?t[l]:null}function i(n){let s=n;return s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=o(a);return c?`![${r}](${c})`:l}),s=s.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=o(r);return a?`src="${a}"`:l}),s}for(const n of e.slides)if(n.rawMarkdown=i(n.rawMarkdown),n.pageAttrs["custom-slides-background"]){const s=n.pageAttrs["custom-slides-background"],l=o(s);l&&(n.pageAttrs["custom-slides-background"]=l)}if(e.flattenedMarkdown=i(e.flattenedMarkdown),e.docRootAttrs["custom-slides-background"]){const n=e.docRootAttrs["custom-slides-background"],s=o(n);s&&(e.docRootAttrs["custom-slides-background"]=s)}return e}const ak={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`};function hc(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function ck(e,t){const o=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!o)return null;const i=o[1].trim(),n=i.indexOf("#"),s=n!==-1?i.slice(0,n):i,l=n!==-1?i.slice(n+1):"",r=s.replace(/^@\//,"").replace(/^\.\//,""),a=(t==null?void 0:t.virtualFiles)||{};let c=a[s]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const d=r.split("/").pop();for(const[f,p]of Object.entries(a))if(f.endsWith(`/${r}`)||d&&f.endsWith(`/${d}`)){c=p;break}}if(!c){const d=[];if(t!=null&&t.baseDir)try{const f=require("path");d.push(f.resolve(t.baseDir,r)),d.push(f.resolve(t.baseDir,s))}catch{}try{const f=require("path");d.push(f.resolve(process.cwd(),r))}catch{}for(const f of d){const p=hc(f);if(p!==null){c=p;break}}}if(!c){const d=ak||{};if(c=d[s]||d[r]||d[`snippets/${r}`],!c){const f=r.split("/").pop();for(const[p,g]of Object.entries(d))if(p.endsWith(`/${r}`)||f&&p.endsWith(`/${f}`)){c=g;break}}}if(!c)return null;let u=c;if(l){const d=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),f=c.match(d);if(f){const p=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);u=(p?p[1]:"")+f[1].trimEnd()}}const h=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${h?h[1]:""}
${u}
\`\`\``}function dk(e){let t=!1,o=!1;for(let i=0;i<e.length;i++){const n=e[i];if(n==="'"&&!o)t=!t;else if(n==='"'&&!t)o=!o;else if(n==="#"&&!t&&!o)return e.slice(0,i).trim()}return e.trim()}function bn(e){const t={},o=e.split(/\r?\n/);let i=0;for(;i<o.length;){const n=o[i],s=n.trim();if(!s||s.startsWith("#")){i++;continue}const l=n.indexOf(":");if(l>0){const r=n.slice(0,l).trim();let a=n.slice(l+1).trim();if(a==="|"||a===">"){i++;const c=[];let u=-1;for(;i<o.length;){const h=o[i];if(!h.trim()){c.push(""),i++;continue}const d=h.match(/^(\s+)/),f=d?d[1].length:0;if(u===-1&&(u=f),f<u)break;c.push(h.slice(u)),i++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=dk(a),!a){let c=i+1;const u=[];let h=-1;for(;c<o.length;){const y=o[c],d=y.trim();if(!d||d.startsWith("#")){h!==-1&&u.push(""),c++;continue}const f=y.match(/^(\s+)/),p=f?f[1].length:0;if(h===-1)if(p>0)h=p;else break;if(p<h)break;u.push(y.slice(h)),c++}if(u.length>0){t[r]=bn(u.join(`
`)),i=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),t[r]=a}i++}return t}const uk=/^\s*```ya?ml([\s\S]*?)```/;function Cl(e){let t={},o=e.trim();const i=o.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(i&&!i[1].includes("```")){const s=bn(i[1]);if(Object.keys(s).length>0||!i[1].trim())return t=s,o=o.slice(i[0].length).trim(),{frontmatter:t,content:o}}if(o.startsWith("---")){const s=o.match(/^---[^\n\r]*(?:\r?\n|$)/);s&&(o=o.slice(s[0].length).trim())}const n=o.match(uk);if(n)t=bn(n[1]),o=o.slice(n[0].length).trim();else{const s=o.split(/\r?\n/),l=[];let r=0;for(let a=0;a<s.length;a++){const c=s[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(t=bn(l.join(`
`)),o=s.slice(r).join(`
`).trim())}return{frontmatter:t,content:o}}function fk(e){const t=e.split(/\r?\n/),o=[];let i=0,n=!1;function s(l){if(i>=l)return;const r=t.slice(i,l).join(`
`).trim();r&&o.push(r),i=l+1}for(let l=0;l<t.length;l++){const a=t[l].trimEnd();if(n){a.includes("-->")&&(n=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(n=!0);continue}if(a.startsWith("---")){s(l);const c=t[l+1];let u=!1,h=-1;const y=c?c.trim():"";if(a.replace(/^-+/,"").trim()===""&&y.length>0){for(let d=l+1;d<t.length;d++){const f=t[d].trimEnd();if(f.startsWith("```"))break;if(f==="---"){h=d;break}}h!==-1&&h-l<=60&&t.slice(l+1,h).some(p=>{const g=p.trim();return g.length>0&&!g.startsWith("#")&&/^[a-zA-Z0-9_$-]+\s*:\s*.*/.test(g)})&&(u=!0)}u&&h!==-1&&(i=l,l=h)}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),u=c?c[0].trim():"```";let h=l+1;for(;h<t.length&&!t[h].trimStart().startsWith(u);h++);h<t.length&&(l=h)}}return i<t.length&&s(t.length),o}function vn(e,t={}){const{stripNotesFromMarkdown:o=!0,cleanVClicks:i=!0,cleanShikiLines:n=!0,cleanSlots:s=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=t;let u=e;u&&!u.trimStart().startsWith("---")&&(u=`---

${u.trimStart()}`);const h=fk(u),y={};let d="",f="",p=0;if(h.length>0){const j=h[0],B=Cl(j),D=Object.keys(B.frontmatter).length>0,x=B.content.length>0;D&&!x&&h.length>1?(p=1,b(B.frontmatter)):D&&b(B.frontmatter)}function g(j,B,D){const x=String(j);x==="two-cols-header"?B[be]="cols-header":x==="three-cols-header"?(B[be]="cols-header",!D.layoutRatio&&!D["layout-ratio"]&&(B[mt]="1:1:1")):B[be]=x}function b(j){d=j.title||"",j.theme&&(y[Wi]=String(j.theme)),j.aspectRatio&&(y[Ui]=String(j.aspectRatio)),j.transition&&(y[Vi]=String(j.transition)),j.colorSchema&&(y[Ol]=String(j.colorSchema)),j.layout&&g(j.layout,y,j),j.background&&(y[ct]=String(j.background)),j.image&&(y[Ft]=String(j.image)),j.class&&(y[ri]=String(j.class));for(const[B,D]of Object.entries(j))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(B)||(y[`custom-slides-${B}`]=typeof D=="object"?JSON.stringify(D):String(D))}const k=[];let w=0,_=0,M=0,A=0;const I=new Set,N={};let H=1;for(let j=p;j<h.length;j++){const B=h[j],{frontmatter:D,content:x}=Cl(B),V=B.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),W=D.src||(V?V[1]:void 0);if(W){const P=String(W).trim().replace(/^['"]|['"]$/g,"");let ie=c[P]||c[P.replace(/^\.\//,"")]||c[`pages/${P.replace(/^.*pages\//,"")}`];if(!ie){const F=P.replace(/^\.\//,""),v=[];if(t.baseDir)try{const U=require("path");v.push(U.resolve(t.baseDir,F)),v.push(U.resolve(t.baseDir,P))}catch{}try{const U=require("path");v.push(U.resolve(process.cwd(),F)),v.push(U.resolve(process.cwd(),P))}catch{}for(const U of v){const R=hc(U);if(R!==null){ie=R;break}}}const E={};D.layout&&g(D.layout,E,D),D.transition&&(E[wt]=String(D.transition)),D.background&&(E[ct]=String(D.background)),D.image&&(E[Ft]=String(D.image)),D.class&&(E[ri]=String(D.class));for(const[F,v]of Object.entries(D))["src","layout","transition","background","image","class"].includes(F)||(E[`custom-slides-${F}`]=typeof v=="object"?JSON.stringify(v):String(v));if(ie){const F=vn(ie,{...t,virtualFiles:c});for(const v of F.slides){v.pageIndex=H++,v.pageAttrs={...E,...v.pageAttrs},k.push(v);const U=v.pageAttrs[be]||"default";N[U]=(N[U]||0)+1}continue}else{k.push({pageIndex:H++,pageAttrs:{...E,"custom-slides-src":P},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${P}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const F=E[be]||"default";N[F]=(N[F]||0)+1;continue}}const $={};D.layout&&g(D.layout,$,D),D.transition&&($[wt]=String(D.transition)),D.background&&($[ct]=String(D.background)),D.image&&($[Ft]=String(D.image)),D.class&&($[ri]=String(D.class)),D.mask&&($[li]=String(D.mask)),(D.maskRatio||D["mask-ratio"])&&($[Ko]=String(D.maskRatio||D["mask-ratio"])),(D.maskStyle||D["mask-style"])&&($[ai]=String(D.maskStyle||D["mask-style"])),(D.maskInitial||D["mask-initial"])&&($[ci]=String(D.maskInitial||D["mask-initial"]));for(const[P,ie]of Object.entries(D))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(P)||($[`custom-slides-${P}`]=typeof ie=="object"?JSON.stringify(ie):String(ie));let T=x;const O=[];let te=T.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,P=>{const ie=`__CODE_TOKEN_NOTE_${O.length}__`;return O.push(P),ie});te=te.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,P=>{const ie=`__CODE_TOKEN_NOTE_${O.length}__`;return O.push(P),ie});let K="";const Z=Array.from(te.matchAll(/<!--([\s\S]*?)-->/g));if(Z.length>0){const P=Z[Z.length-1],ie=te.slice(P.index+P[0].length).trim();if(!ie||!ie.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const F=P[1].trim();F.startsWith("TODO:")||(K=F,w++),o&&(te=te.slice(0,P.index).trimEnd()+te.slice(P.index+P[0].length))}}o&&(te=te.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let P=0;P<O.length;P++)te=te.replace(`__CODE_TOKEN_NOTE_${P}__`,()=>O[P]);if(T=te,K){for(let E=0;E<O.length;E++)K=K.replace(`__CODE_TOKEN_NOTE_${E}__`,()=>O[E]);const ie=`> [!NOTE] 💡 演讲备注
${K.split(/\r?\n/).map(E=>`> ${E}`).join(`
`)}
{: custom-slides-note="true"}`;T=T?`${T}

${ie}`:ie}let ce=!1;if(/<style\b/i.test(T)){ce=!0;const P=T.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(P){for(const ie of P){const E=ie.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();f=f?`${f}

${E}`:E}l&&(T=T.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const oe=T.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);oe&&(_+=oe.length);const re=T.match(/```\w+\s+\{[^}]+\}/g);re&&(M+=re.length);const Se=T.match(/::\w+::|<template\s+#[^>]+>/g);if(Se&&(A+=Se.length),T=T.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,P=>ck(P,{...t,virtualFiles:c})||P),i&&(T=T.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),n&&(T=T.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),T=T.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),s&&(T=T.replace(/^::\w+::\s*$/gm,"")),r&&(T=lh(T)),a){let P=T.trim(),ie="";const E=P.lastIndexOf("> [!NOTE] 💡 演讲备注");if(E!==-1&&(ie=P.slice(E),P=P.slice(0,E).trim()),(D.layout==="image-left"||D.layout==="image-right")&&D.image){const F=String(D.image).trim(),v=D.layout==="image-left"?"image-left":"image-right",U=`![配图](${F})
{: custom-slides-layout="${v}" }`;D.layout==="image-left"?P=`{{{col

${U}

${P}

}}}`:P=`{{{col

${P}

${U}

}}}`}if(D.background){const v=`![背景图](${String(D.background).trim()})
{: custom-slides-role="background" }`;P=P?`${v}

${P}`:v}T=ie?`${P}

${ie}`:P}const Ie=hk(T);$[ct]&&Ie.push($[ct]),$[Ft]&&Ie.push($[Ft]);for(const P of Ie)I.add(P);const ve=/<[A-Z][a-zA-Z0-9]+/.test(T),_e=$[be]||(H===1?y[be]||"cover":"default");N[_e]=(N[_e]||0)+1,k.push({pageIndex:H++,pageAttrs:$,notes:K,rawMarkdown:T,hasVueComponent:ve,hasStyleTag:ce,assetReferences:Ie})}if(!d&&k.length>0){const j=k[0].rawMarkdown.match(/^#\s+(.+)$/m);j&&(d=j[1].trim())}f&&(y["custom-slides-custom-css"]=f);let z=k.map(j=>`---

${j.rawMarkdown}`).join(`

`);return z.trimStart().startsWith("---")||(z=`---

${z.trimStart()}`),{docTitle:d||"Slidev 演示文稿",docRootAttrs:y,slides:k,totalSlides:k.length,stats:{totalNotes:w,totalVClicks:_,totalShikiHighlights:M,totalSlots:A,discoveredAssets:Array.from(I),layoutDistribution:N},flattenedMarkdown:z,customCss:f}}function hk(e){const t=[],o=/!\[.*?\]\((.*?)\)/g;let i;for(;(i=o.exec(e))!==null;){const s=i[1].split(/\s+/)[0].trim();s&&t.push(s)}const n=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(i=n.exec(e))!==null;){const s=i[1].trim();s&&t.push(s)}return t}function pc(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),o=String(e.markdown||"").trim(),i=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||o==="---"||o==="***"||i==="---"||i==="***"}function pk(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function mk(e,t,o=ze){const i=e.filter(pc);let n=0;if(i.length>=t.length)for(let s=0;s<t.length;s++){const l=t[s],r=i[s];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await o(r.id,l.pageAttrs),n++)}else for(let s=1;s<t.length;s++){const l=t[s],r=i[s-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await o(r.id,l.pageAttrs),n++)}return n}async function gk(e,t=ze){let o=!1,i=0;for(const n of e){if(pc(n)){o=!1;continue}const s=(n.markdown||n.content||"").trim();if(s==="::right::"||s.startsWith("::right::")){o=!0;continue}o&&n.id&&(await t(n.id,{[Ae]:"right"}).catch(()=>{}),i++)}return i}async function yk(e,t,o=Bl){const i={};if(!t||t.length===0)return i;const n=[];for(const s of t){const l=new File([s.data],s.fileName,{type:"application/octet-stream"});n.push(l)}try{const s=await o("/data/assets",n);if(s!=null&&s.succMap)for(const[l,r]of Object.entries(s.succMap))i[l]=String(r)}catch(s){console.warn("上传本地静态资产失败，保留原路径:",s)}return Object.keys(i).length>0&&lk(e,i),i}async function bk(e){var k;const{presentation:t,notebookId:o,docTitle:i,extractedAssets:n=[],uploadAssets:s=!0,autoPreview:l=!0,plugin:r,api:a={}}=e,c=a.uploadFn||Bl,u=a.createDocFn||yd,h=a.setAttrsFn||ze,y=a.getChildBlocksFn||ki,d=a.openTabFn||le.openTab,f=a.showMessageFn||le.showMessage;s&&n.length>0&&await yk(t,n,c);const p=pk(i),g=`/${p}`,b=await u(o,g,t.flattenedMarkdown);if(!b)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");try{const w=((k=t.slides[0])==null?void 0:k.pageAttrs)||{};await h(b,{...w,...t.docRootAttrs});const _=await y(b).catch(()=>[]);Array.isArray(_)&&_.length>0&&(await mk(_,t.slides,h),await gk(_,h))}catch(w){console.warn("[SlidesImport] 版式属性回填阶段遇到警告:",w),f(`⚠️ 文档已创建(${p})，但部分版式属性回填未完全完成: ${w.message||String(w)}`,6e3)}return f(`🎉 成功导入 Slidev 演示文档《${p}》！`),l&&r&&(r.currentDocId=b,await d({app:r.app,doc:{id:b}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),b}function vk(e){const t=pe("file"),o=pe(!1),i=pe(!1),n=pe(""),s=pe(null),l=pe(null),r=pe(""),a=pe(0),c=pe(""),u=pe([]),h=pe(null),y=pe(""),d=pe([]),f=pe(""),p=pe(!0),g=pe(!0),b=pe(!0),k=pe(!0),w=ye(()=>{const $=a.value;if($===0)return"0 B";const T=1024,O=["B","KB","MB","GB"],te=Math.floor(Math.log($)/Math.log(T));return`${($/T**te).toFixed(1)} ${O[te]}`}),_=ye(()=>{var $;return(($=h.value)==null?void 0:$.docRootAttrs["custom-slides-theme"])||"default"}),M=ye(()=>{var $;return u.value.length>0?u.value.length:(($=h.value)==null?void 0:$.stats.discoveredAssets.length)||0}),A=ye(()=>{var T;const $=((T=h.value)==null?void 0:T.stats.layoutDistribution)||{};return Object.entries($).map(([O,te])=>({name:O,count:te}))});async function I($=gd){try{const T=await $();T!=null&&T.notebooks&&Array.isArray(T.notebooks)&&(d.value=T.notebooks.filter(O=>!O.closed),d.value.length>0&&!f.value&&(f.value=d.value[0].id))}catch(T){console.warn("获取笔记本列表失败:",T)}}function N(){var $;($=s.value)==null||$.click()}function H(){l.value=null,r.value="",a.value=0,h.value=null,u.value=[],n.value=""}let z=0;async function j($){const T=++z;n.value="",l.value=$,r.value=$.name,a.value=$.size;try{if($.name.toLowerCase().endsWith(".zip")){const te=await $.arrayBuffer();if(T!==z)return;const K=await rk(te);if(T!==z)return;if(!K.entryMarkdown){n.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=K.assets;const Z=vn(K.entryMarkdown,{stripNotesFromMarkdown:g.value,cleanHtmlToMarkdown:p.value,cleanSlots:!1,virtualFiles:K.virtualFiles});if(T!==z)return;h.value=Z,y.value=Z.docTitle||$.name.replace(/\.zip$/i,"")}else{const te=await $.text();if(T!==z)return;u.value=[];const K=$.path||"",Z=K?K.replace(/[\\/][^\\/]+$/,""):"",ce=vn(te,{stripNotesFromMarkdown:g.value,cleanHtmlToMarkdown:p.value,cleanSlots:!1,baseDir:Z||void 0});if(T!==z)return;h.value=ce,y.value=ce.docTitle||$.name.replace(/\.md$/i,"")}}catch(O){if(T!==z)return;console.error("解析文件失败:",O),n.value=`解析文件失败: ${O.message||String(O)}`}}function B(){if(n.value="",!c.value.trim()){h.value=null;return}try{const $=vn(c.value,{stripNotesFromMarkdown:g.value,cleanHtmlToMarkdown:p.value,cleanSlots:!1});h.value=$,y.value=$.docTitle||"Slidev 演示文稿"}catch($){n.value=`解析 Markdown 源码失败: ${$.message||String($)}`}}async function D(){l.value?await j(l.value):c.value&&B()}async function x($){const T=$.target;T.files&&T.files[0]&&await j(T.files[0])}async function V($){var T;o.value=!1,(T=$.dataTransfer)!=null&&T.files&&$.dataTransfer.files[0]&&await j($.dataTransfer.files[0])}async function W($=e){if(h.value){if(!f.value&&d.value.length>0&&(f.value=d.value[0].id),!f.value){n.value="请先选择目标笔记本";return}i.value=!0,n.value="";try{return await bk({presentation:h.value,notebookId:f.value,docTitle:y.value,extractedAssets:u.value,uploadAssets:b.value,autoPreview:k.value,plugin:$})}catch(T){console.error("导入 Slidev 演示失败:",T),n.value=`导入执行失败: ${T.message||String(T)}`}finally{i.value=!1}}}return{inputMode:t,isDragging:o,isImporting:i,errorMessage:n,fileInputRef:s,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:u,parsedPresentation:h,customDocTitle:y,notebooks:d,selectedNotebookId:f,optCleanHtml:p,optStripNotes:g,optUploadAssets:b,optAutoPreview:k,formattedFileSize:w,currentTheme:_,extractedAssetsCount:M,layoutChips:A,fetchNotebooks:I,triggerFileInput:N,clearFile:H,processFile:j,onFileSelected:x,onFileDrop:V,onTextChange:B,reprocessCurrentInput:D,handleConfirmImport:W}}const kk={class:"spm-import-dialog"},wk={class:"spm-tabs-header"},xk={class:"spm-dialog-body"},Sk={key:0,class:"spm-file-section"},_k={key:0,class:"spm-dropzone-prompt"},Ck={class:"spm-dropzone-icon"},Ik={key:1,class:"spm-dropzone-active"},$k={class:"spm-file-badge"},Ak={class:"spm-file-size"},Tk={key:1,class:"spm-text-section"},Mk={key:2,class:"spm-error-banner"},Bk={key:3,class:"spm-preview-card"},Ek={class:"spm-preview-card__header"},Dk={style:{display:"inline-flex","align-items":"center",gap:"4px"}},Lk={class:"spm-config-grid"},Ok={class:"spm-form-item"},Nk={class:"spm-form-item"},Pk=["value"],Rk={class:"spm-stats-grid"},zk={class:"spm-stat-box"},Hk={class:"spm-stat-value"},Fk={class:"spm-stat-box"},jk={class:"spm-stat-value"},Wk={class:"spm-stat-box"},Uk={class:"spm-stat-value"},Vk={class:"spm-stat-box"},qk={class:"spm-stat-value"},Gk={key:0,class:"spm-chips-row"},Kk={class:"spm-options-group"},Yk={class:"spm-checkbox-label"},Zk={class:"spm-checkbox-label"},Jk={class:"spm-checkbox-label"},Xk={class:"spm-checkbox-label"},Qk={class:"spm-dialog-footer"},ew=["disabled"],tw=["disabled"],ow={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},iw={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},nw=Pt({__name:"SlidesImportDialog",emits:["close","success"],setup(e,{emit:t}){const o=t,i=Wt("plugin"),{inputMode:n,isDragging:s,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:u,extractedAssetsCount:h,parsedPresentation:y,customDocTitle:d,notebooks:f,selectedNotebookId:p,optCleanHtml:g,optStripNotes:b,optUploadAssets:k,optAutoPreview:w,formattedFileSize:_,currentTheme:M,layoutChips:A,fetchNotebooks:I,triggerFileInput:N,clearFile:H,onFileSelected:z,onFileDrop:j,onTextChange:B,reprocessCurrentInput:D,handleConfirmImport:x}=vk(i);Qo(async()=>{await I()});async function V(){const $=await x();$&&(o("success",{docId:$}),o("close"))}function W(){o("close")}return($,T)=>(J(),ee("div",{class:"spm-modal-overlay",onClick:eo(W,["self"])},[m("div",kk,[m("div",{class:"spm-dialog-header"},[T[18]||(T[18]=m("div",{class:"spm-dialog-title"},[m("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[m("use",{"xlink:href":"#iconSlides"})]),m("span",null,"导入 Slidev 演示文档")],-1)),m("button",{class:"spm-close-btn",title:"关闭",onClick:W},"✕")]),m("div",wk,[m("button",{class:xe(["spm-tab-btn",{active:he(n)==="file"}]),onClick:T[0]||(T[0]=O=>n.value="file")},[se(de,{name:"package"}),T[19]||(T[19]=m("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),m("button",{class:xe(["spm-tab-btn",{active:he(n)==="text"}]),onClick:T[1]||(T[1]=O=>n.value="text")},[se(de,{name:"notes"}),T[20]||(T[20]=m("span",null,"粘贴 Markdown 源码",-1))],2)]),m("div",xk,[he(n)==="file"?(J(),ee("div",Sk,[m("div",{class:xe(["spm-dropzone",{dragover:he(s),"has-file":!!he(c)}]),onDragover:T[4]||(T[4]=eo(O=>s.value=!0,["prevent"])),onDragleave:T[5]||(T[5]=eo(O=>s.value=!1,["prevent"])),onDrop:T[6]||(T[6]=eo((...O)=>he(j)&&he(j)(...O),["prevent"])),onClick:T[7]||(T[7]=(...O)=>he(N)&&he(N)(...O))},[m("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:T[2]||(T[2]=(...O)=>he(z)&&he(z)(...O))},null,544),he(c)?(J(),ee("div",Ik,[m("span",$k,[se(de,{name:"notes"}),Et(" "+ke(he(c)),1)]),m("span",Ak,"("+ke(he(_))+")",1),m("button",{class:"spm-btn-text",onClick:T[3]||(T[3]=eo((...O)=>he(H)&&he(H)(...O),["stop"]))},"更换文件")])):(J(),ee("div",_k,[m("span",Ck,[se(de,{name:"folder",style:{"font-size":"32px"}})]),T[21]||(T[21]=m("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),T[22]||(T[22]=m("p",{class:"spm-dropzone-hint"},[Et(" 支持 Slidev 完整工程 "),m("strong",null,".zip"),Et("（自动解包 public/ 静态素材）或单文件 "),m("strong",null,".md")],-1))]))],34)])):(J(),ee("div",Tk,[Ht(m("textarea",{"onUpdate:modelValue":T[8]||(T[8]=O=>ot(u)?u.value=O:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:T[9]||(T[9]=(...O)=>he(B)&&he(B)(...O))},null,544),[[Ns,he(u)]])])),he(r)?(J(),ee("div",Mk," ⚠️ "+ke(he(r)),1)):Te("",!0),he(y)?(J(),ee("div",Bk,[m("div",Ek,[m("span",Dk,[se(de,{name:"sparkles"}),T[23]||(T[23]=Et(" 演示解析摘要",-1))]),T[24]||(T[24]=m("span",{class:"spm-badge-success"},"预检就绪",-1))]),m("div",Lk,[m("div",Ok,[T[25]||(T[25]=m("label",{class:"spm-form-label"},"笔记文档标题",-1)),Ht(m("input",{"onUpdate:modelValue":T[10]||(T[10]=O=>ot(d)?d.value=O:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[Ns,he(d)]])]),m("div",Nk,[T[26]||(T[26]=m("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Ht(m("select",{"onUpdate:modelValue":T[11]||(T[11]=O=>ot(p)?p.value=O:null),class:"spm-select"},[(J(!0),ee(Je,null,$t(he(f),O=>(J(),ee("option",{key:O.id,value:O.id},ke(O.name),9,Pk))),128))],512),[[jf,he(p)]])])]),m("div",Rk,[m("div",zk,[m("span",Hk,ke(he(y).totalSlides),1),T[27]||(T[27]=m("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),m("div",Fk,[m("span",jk,ke(he(M)),1),T[28]||(T[28]=m("span",{class:"spm-stat-label"},"演示主题",-1))]),m("div",Wk,[m("span",Uk,ke(he(y).stats.totalNotes),1),T[29]||(T[29]=m("span",{class:"spm-stat-label"},"演讲者提词",-1))]),m("div",Vk,[m("span",qk,ke(he(h)),1),T[30]||(T[30]=m("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),he(A).length>0?(J(),ee("div",Gk,[T[31]||(T[31]=m("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(J(!0),ee(Je,null,$t(he(A),O=>(J(),ee("span",{key:O.name,class:"spm-chip-badge"},ke(O.name)+": "+ke(O.count),1))),128))])):Te("",!0),m("div",Kk,[m("label",Yk,[Ht(m("input",{"onUpdate:modelValue":T[12]||(T[12]=O=>ot(g)?g.value=O:null),type:"checkbox",onChange:T[13]||(T[13]=(...O)=>he(D)&&he(D)(...O))},null,544),[[dn,he(g)]]),T[32]||(T[32]=m("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),m("label",Zk,[Ht(m("input",{"onUpdate:modelValue":T[14]||(T[14]=O=>ot(b)?b.value=O:null),type:"checkbox",onChange:T[15]||(T[15]=(...O)=>he(D)&&he(D)(...O))},null,544),[[dn,he(b)]]),T[33]||(T[33]=m("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),m("label",Jk,[Ht(m("input",{"onUpdate:modelValue":T[16]||(T[16]=O=>ot(k)?k.value=O:null),type:"checkbox"},null,512),[[dn,he(k)]]),T[34]||(T[34]=m("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),m("label",Xk,[Ht(m("input",{"onUpdate:modelValue":T[17]||(T[17]=O=>ot(w)?w.value=O:null),type:"checkbox"},null,512),[[dn,he(w)]]),T[35]||(T[35]=m("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Te("",!0)]),m("div",Qk,[m("button",{class:"spm-btn-secondary",disabled:he(l),onClick:W}," 取消 ",8,ew),m("button",{class:"spm-btn-primary",disabled:!he(y)||he(l),onClick:V},[he(l)?(J(),ee("span",ow,[se(de,{name:"refresh"}),T[36]||(T[36]=Et(" 正在导入生成中...",-1))])):(J(),ee("span",iw,[se(de,{name:"rocket"}),T[37]||(T[37]=Et(" 确认导入思源笔记",-1))]))],8,tw)])])]))}}),sw=so(nw,[["__scopeId","data-v-c56a3d7e"]]);function yr(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function rw(e,t){var r;if(!e||e.length===0)return null;const o=t.activeBlockId||"",i=t.currentTopBlockId||o,n=t.currentPageDividerId||"",s=t.activeBlockType||"";if(yr(s)&&o){let a=e.find(c=>c.startBlockId===o);if(a||(a=e.find(c=>{var u,h;return((h=(u=c.blocks)==null?void 0:u[0])==null?void 0:h.id)===o}),a)||(a=e.find(c=>{var u;return(u=c.allBlockIds)==null?void 0:u.includes(o)}),a))return a}if(n){let a=e.find(c=>c.startBlockId===n);if(a||(a=e.find(c=>{var u,h;return((h=(u=c.blocks)==null?void 0:u[0])==null?void 0:h.id)===n}),a))return a}if(o){let a=e.find(u=>u.startBlockId===o);if(a||(a=e.find(u=>{var h,y;return((h=u.blocks)==null?void 0:h.some(d=>d.id===o))||((y=u.allBlockIds)==null?void 0:y.includes(o))}),a)||i&&i!==o&&(a=e.find(u=>{var h,y;return((h=u.blocks)==null?void 0:h.some(d=>d.id===i))||((y=u.allBlockIds)==null?void 0:y.includes(i))}),a)||(a=e.find(u=>{var h;return(h=u.noteBlocks)==null?void 0:h.some(y=>y.id===o||y.id===i)}),a))return a;const c=(r=t.activeBlockAttrs)==null?void 0:r[Ae];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=e.find(u=>{var h,y;return((h=u.frontmatter)==null?void 0:h.layout)==="three-cols-header"||((y=u.blocks)==null?void 0:y.some(d=>d.slot==="col-1"||d.slot==="col-2"||d.slot==="col-3"))}),a))return a}return e[0]||null}function ms(){var s;if(typeof window<"u"&&typeof((s=window.Lute)==null?void 0:s.NewNodeID)=="function")return window.Lute.NewNodeID();const e=new Date,t=l=>l.toString().padStart(2,"0"),o=`${e.getFullYear()}${t(e.getMonth()+1)}${t(e.getDate())}${t(e.getHours())}${t(e.getMinutes())}${t(e.getSeconds())}`,i="0123456789abcdefghijklmnopqrstuvwxyz";let n="";for(let l=0;l<7;l++)n+=i[Math.floor(Math.random()*i.length)];return`${o}-${n}`}function mc(){return typeof document>"u"?null:document.querySelector(".layout__wnd--active .protyle-wysiwyg")||document.querySelector(".protyle:not(.fn__none) .protyle-wysiwyg")||document.querySelector(".protyle-wysiwyg")}function lw(e,t){var l;if(typeof document>"u")return!1;const o=mc();if(!o)return!1;const i=Array.from(o.querySelectorAll(".protyle-wysiwyg--select[data-node-id]"));if(i.length>=2)return!0;const n=((l=i[0])==null?void 0:l.getAttribute("data-node-id"))||e,s=t==="NodeList"||t==="l"||t==="list";if(n){const r=o.querySelector(`[data-node-id="${n}"]`);if(r){const a=(s||r.getAttribute("data-type")==="NodeList"||r.classList.contains("list"))&&r.getAttribute("data-type")==="NodeList"?r:r.closest('[data-type="NodeList"], .list');if(a&&a.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li").length>=2)return!0}}return!1}async function aw(e){const t=mc();if(!t)return{success:!1,error:"未找到主编辑区"};const o=Array.from(t.querySelectorAll(".protyle-wysiwyg--select[data-node-id]"));let i=!1,n=null,s=[];if(o.length>=2){const w=o[0].closest('[data-type="NodeList"], .list');if(w){const _=new Set;let M=!0;for(const A of o){const I=A.getAttribute("data-type")==="NodeListItem"||A.classList.contains("li")?A:A.closest('[data-type="NodeListItem"], .li');if(!I||I.closest('[data-type="NodeList"], .list')!==w){M=!1;break}_.add(I)}M&&_.size>=2&&(i=!0,n=w,s=Array.from(w.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li")).filter(A=>_.has(A)))}}let l=!1;if(!i){const w=(o.length===1?o[0]:null)||(e.activeBlockId?t.querySelector(`[data-node-id="${e.activeBlockId}"]`):null);if(w){const _=w.getAttribute("data-type")==="NodeList"||w.classList.contains("list")?w:w.closest('[data-type="NodeList"], .list');if(_){const M=Array.from(_.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li"));M.length>=2&&(l=!0,n=_,s=M)}}}if(i||l){if(!n||s.length<2)return{success:!1,error:"选中的列表项不足 2 项，无法合并为横向超级块"};const w=Array.from(n.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li")),_=s.length===w.length,M=n.getAttribute("data-subtype")||"u",A=n.getAttribute("data-node-id")||"",I=n.parentElement,N=(I==null?void 0:I.getAttribute("data-node-id"))||e.currentDocId;let H=n.previousElementSibling;for(;H&&!H.getAttribute("data-node-id");)H=H.previousElementSibling;const z=(H==null?void 0:H.getAttribute("data-node-id"))||"";let j=n.nextElementSibling;for(;j&&!j.getAttribute("data-node-id");)j=j.nextElementSibling;const B=(j==null?void 0:j.getAttribute("data-node-id"))||"",D=ms(),x=s.map($=>({li:$,liId:$.getAttribute("data-node-id")||"",newListId:ms()})),V=[],W=[];if(_){V.push({action:"insert",id:D,data:`<div data-node-id="${D}" data-type="NodeSuperBlock" class="sb" data-sb-layout="col"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:N,previousID:z||void 0,nextID:z?void 0:B||void 0});for(let $=0;$<x.length;$++){const{liId:T,newListId:O}=x[$];V.push({action:"insert",id:O,data:`<div data-node-id="${O}" data-type="NodeList" data-subtype="${M}" class="list"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:D,previousID:$===0?void 0:x[$-1].newListId}),V.push({action:"move",id:T,parentID:O})}A&&V.push({action:"delete",id:A}),A&&W.push({action:"insert",id:A,data:n.outerHTML,parentID:N,previousID:z||void 0,nextID:z?void 0:B||void 0});for(let $=0;$<x.length;$++)W.push({action:"move",id:x[$].liId,parentID:A,previousID:$===0?void 0:x[$-1].liId});for(const{newListId:$}of x)W.push({action:"delete",id:$});W.push({action:"delete",id:D})}else{V.push({action:"insert",id:D,data:`<div data-node-id="${D}" data-type="NodeSuperBlock" class="sb" data-sb-layout="col"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:N,previousID:A});for(let $=0;$<x.length;$++){const{liId:T,newListId:O}=x[$];V.push({action:"insert",id:O,data:`<div data-node-id="${O}" data-type="NodeList" data-subtype="${M}" class="list"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:D,previousID:$===0?void 0:x[$-1].newListId}),V.push({action:"move",id:T,parentID:O})}for(let $=0;$<x.length;$++)W.push({action:"move",id:x[$].liId,parentID:A});for(const{newListId:$}of x)W.push({action:"delete",id:$});W.push({action:"delete",id:D})}return await _r([{doOperations:V,undoOperations:W}]),t.querySelectorAll(".protyle-wysiwyg--select").forEach($=>$.classList.remove("protyle-wysiwyg--select")),{success:!0,colCount:x.length,superBlockId:D}}const r=o.filter(w=>{let _=w.parentElement;for(;_&&_!==t;){if(o.includes(_))return!1;_=_.parentElement}return!0});if(r.length<2)return{success:!1,error:"请在编辑区选中多个块，或选中一个包含多个列表项的列表"};const a=r[0],c=r[r.length-1],u=a.parentElement,h=(u==null?void 0:u.getAttribute("data-node-id"))||e.currentDocId;let y=a.previousElementSibling;for(;y&&!y.getAttribute("data-node-id");)y=y.previousElementSibling;const d=(y==null?void 0:y.getAttribute("data-node-id"))||"";let f=c.nextElementSibling;for(;f&&!f.getAttribute("data-node-id");)f=f.nextElementSibling;const p=(f==null?void 0:f.getAttribute("data-node-id"))||"",g=ms(),b=[],k=[];b.push({action:"insert",id:g,data:`<div data-node-id="${g}" data-type="NodeSuperBlock" class="sb" data-sb-layout="col"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:h,previousID:d||void 0,nextID:d?void 0:p||void 0});for(let w=0;w<r.length;w++){const _=r[w].getAttribute("data-node-id");b.push({action:"move",id:_,parentID:g,previousID:w===0?void 0:r[w-1].getAttribute("data-node-id")})}for(let w=0;w<r.length;w++){const _=r[w].getAttribute("data-node-id");k.push({action:"move",id:_,parentID:h,previousID:w===0?d||void 0:r[w-1].getAttribute("data-node-id")})}return k.push({action:"delete",id:g}),await _r([{doOperations:b,undoOperations:k}]),t.querySelectorAll(".protyle-wysiwyg--select").forEach(w=>w.classList.remove("protyle-wysiwyg--select")),{success:!0,colCount:r.length,superBlockId:g}}function et(e,t){var n;if(typeof document>"u"||!e)return;const o=(n=globalThis.CSS)!=null&&n.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),i=document.querySelectorAll(`[data-node-id="${o}"]`);!i||i.length===0||i.forEach(s=>{for(const[l,r]of Object.entries(t))r!=null&&r!==""?s.setAttribute(l,String(r)):s.removeAttribute(l)})}function cw(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${be}], .protyle-wysiwyg [${Ye}], .protyle-wysiwyg [custom-slides-layout], .protyle-wysiwyg [custom-slides-role]`,o=document.querySelectorAll(t);!o||o.length===0||o.forEach(i=>{const n=i.getAttribute("data-node-id");if(!n){i.removeAttribute(be),i.removeAttribute("custom-slides-layout"),i.removeAttribute(Ye),i.removeAttribute("custom-slides-role");return}const s=e.get(n),l=(s==null?void 0:s[be])||(s==null?void 0:s["custom-slides-layout"])||"",r=i.getAttribute(be)||i.getAttribute("custom-slides-layout");r&&r!==l&&(l?i.setAttribute(be,l):(i.removeAttribute(be),i.removeAttribute("custom-slides-layout")));const a=(s==null?void 0:s[Ye])||(s==null?void 0:s["custom-slides-role"])||"",c=i.getAttribute(Ye)||i.getAttribute("custom-slides-role");c&&c!==a&&(a?i.setAttribute(Ye,a):(i.removeAttribute(Ye),i.removeAttribute("custom-slides-role")))})}function dw(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const o=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!o)return!1;const i=o.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(i==null?void 0:i.getAttribute("data-node-id"))===e}function uw(e){let t=null;function o(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const u=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(u,1200):t=setTimeout(u,1200)}async function i(c){var d;const u=e.activeBlockId.value||e.currentDocId.value;if(!u)return;for(const[f,p]of Object.entries(c))e.activeBlockAttrs.value[f]=p;Ee.setBlockAttrOverride(u,c),et(u,c);const h=(d=e.parentContainerId)==null?void 0:d.value,y=!!(h&&dw(u,h));if(Oe in c&&y&&h){const f=c[Oe];e.parentContainerClicks&&(e.parentContainerClicks.value=f),Ee.setBlockAttrOverride(h,{[Oe]:f}),et(h,{[Oe]:f}),ze(h,{[Oe]:f}).catch(()=>{})}if(be in c){const f=c[be];e.currentPageDividerLayout.value=f,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=f)}if(mt in c){const f=c[mt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=f)}o("保存中...");try{await ze(u,c),o("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{o("同步失败")}}async function n(c,u){await i({[c]:u})}function s(){var u;return(e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak")&&e.activeBlockId.value?e.activeBlockId.value:e.currentPageDividerId.value?e.currentPageDividerId.value:(u=e.targetSlide.value)!=null&&u.startBlockId&&e.targetSlide.value.startBlockId!==e.currentDocId.value?e.targetSlide.value.startBlockId:e.currentDocId.value}async function l(c,u){const h=s();if(h){h===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=u),Ee.setBlockAttrOverride(h,{[c]:u}),et(h,{[c]:u}),c===be&&(e.currentPageDividerLayout.value=u,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=u)),c===mt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=u),o("保存中...");try{await ze(h,{[c]:u}),o("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{o("同步失败")}}}async function r(c,u){const h=s();if(!h)return;const y={[be]:c,[mt]:u};h===e.activeBlockId.value&&(e.activeBlockAttrs.value[be]=c,e.activeBlockAttrs.value[mt]=u),e.currentPageDividerLayout.value=c,Ee.setBlockAttrOverride(h,y),et(h,y),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=u),o("应用排版中...");try{await ze(h,y),o("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{o("应用失败")}}async function a(c,u){var y;const h=e.currentDocId.value||e.activeBlockId.value;if(h){e.activeBlockAttrs.value[c]=u,Ee.setBlockAttrOverride(h,{[c]:u}),et(h,{[c]:u}),(y=e.latestDoc.value)!=null&&y.config&&(c===Wi&&(e.latestDoc.value.config.theme=u),c===Ui&&(e.latestDoc.value.config.aspectRatio=u),c===Vi&&(e.latestDoc.value.config.defaultTransition=u),c===Sn&&(e.latestDoc.value.config.background=u)),o("更新中...");try{await ze(h,{[c]:u}),o("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(h)}catch{o("更新失败")}}}return{triggerSaveNotice:o,saveAttrs:i,saveAttr:n,getPageTargetBlockId:s,savePageAttr:l,applyPageLayoutAndRatio:r,saveDocAttr:a}}function Il(e){const t=(e.blocks||[]).filter(s=>{const l=(s.content||s.rawMarkdown||"").trim();return l&&l!=="---"});if(t.length===0)return"本页暂无内容，建议过渡承接上下文。";const o=[],i=[];for(const s of t){const l=(s.content||s.rawMarkdown||"").trim();l&&(s.type==="h"||l.startsWith("#")?o.push(l.replace(/^#+\s*/,"")):i.push(l.slice(0,50)))}const n=[];return o.length>0&&n.push(`【核心重点】：${o.join("、")}`),i.length>0&&(n.push("【口播要点】："),i.slice(0,3).forEach((s,l)=>{n.push(`${l+1}. 讲解 ${s}`)})),n.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),n.join(`
`)}async function gc(e,t){const o=e.blocks&&e.blocks.length>0?e.blocks.map(i=>(i.content||i.rawMarkdown||"").trim()).filter(i=>i&&i!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(t&&o){const i=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${o}`;try{const n=await t(i);if(n&&n.trim())return{notes:n.trim(),isAiGenerated:!0}}catch(n){return{notes:Il(e),isAiGenerated:!1,error:(n==null?void 0:n.message)||"AI 调用异常"}}}return{notes:Il(e),isAiGenerated:!1}}async function fw(e,t){return(await gc(e,t)).notes}function hw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return!!(t==="callout"||t==="nodecallout"||t==="b"||t==="nodeblockquote"||String(e.markdown||"").trim().startsWith(">"))}function pw(e,t){if(!((t==null?void 0:t[Ve])==="true"))return!1;const i=(e||"").trim();return/^>\s*\[!NOTE\]\s*(?:💡\s*)?(?:演讲备注|讲稿备注)/i.test(i)}async function yc(e,t){const i=await((t==null?void 0:t.getChildBlocksFn)||ki)(e).catch(()=>[]);if(!Array.isArray(i)||i.length===0)return[];const n=[];let s=[];for(const r of i){if(mo({...r,ial:{...r.ial||{},...Ee.getBlockAttrOverride(r.id)||{}}})){if(n.length===0&&s.length===0)continue;n.push(s),s=[];continue}s.push(r)}n.push(s);const l=[];for(let r=0;r<n.length;r++){const a=n[r];if(!a||a.length===0)continue;let c=null;for(let f=a.length-1;f>=0;f--){const p=a[f];if(!((p.type==="p"||p.type==="NodeParagraph")&&!(p.content||"").trim()&&!(p.markdown||"").trim())){c=p;break}}if(!c||!hw(c))continue;const u=Ee.getBlockAttrOverride(c.id)||{};let h={...c.ial||{},...u};if(!h[Ve]&&(t!=null&&t.getBlockAttrsFn)){const f=await t.getBlockAttrsFn(c.id).catch(()=>({}));h={...h,...f,...u}}let y=c.markdown||c.content||"";if(t!=null&&t.getBlockKramdownFn)try{const f=await t.getBlockKramdownFn(c.id);f!=null&&f.kramdown&&(y=f.kramdown)}catch{}if(pw(y,h))continue;const d=pr(y)||y.replace(/<[^>]+>/g,"").trim();l.push({id:c.id,pageIndex:r+1,type:c.type,sourceMarkdown:y,cleanContent:d||"在此输入本页讲稿提词..."})}return l}async function bc(e,t,o){const i=(o==null?void 0:o.updateBlockFn)||xs,n=(o==null?void 0:o.setBlockAttrsFn)||ze,s=(o==null?void 0:o.syncDomFn)||et,r=`> [!NOTE] 💡 演讲备注
${t.split(/\r?\n/).map(a=>`> ${a}`).join(`
`)}
{: ${Ve}="true"}`;await i("markdown",r,e),await n(e,{[Ve]:"true"}),Ee.setBlockAttrOverride(e,{[Ve]:"true"}),s(e,{[Ve]:"true"})}async function vc(e,t){const o=(t==null?void 0:t.showMessageFn)||le.showMessage,i=(t==null?void 0:t.confirmFn)||le.confirm;if(!e)return o("请先在主编辑区打开幻灯片文档"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const n=await yc(e,t);if(n.length===0)return o("未发现待规范化的候选讲稿块"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const s=n.length;return new Promise(l=>{i("识别讲稿块",`扫描检测到 ${s} 处候选讲稿块（提示块或引用块），是否确认将其规范化为标准演讲备注？`,async()=>{var c;o(`正在批量规范化 ${s} 个讲稿块...`);let r=0,a=0;for(const u of n)try{await bc(u.id,u.cleanContent,t),r++}catch(h){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${u.id} 失败:`,h),a++}(c=t==null?void 0:t.onSuccessNotice)==null||c.call(t,"已规范化讲稿"),o(`已成功识别并规范化 ${r} 个讲稿块`),t!=null&&t.compileFn&&await t.compileFn().catch(()=>{}),l({totalScanned:s,matchedCount:s,successCount:r,errorCount:a})},()=>{l({totalScanned:s,matchedCount:s,successCount:0,errorCount:0})})})}function mw(e,t){const o=pe(!1),{triggerSaveNotice:i}=t;async function n(g){var H,z,j,B,D,x,V,W;const w=`> [!NOTE] 💡 演讲备注
${(g||"在此输入本页讲稿提词...").split(/\r?\n/).map($=>`> ${$}`).join(`
`)}
{: custom-slides-note="true"}`,_=((H=e.latestDoc.value)==null?void 0:H.slides)||[],M=e.targetSlide.value,A=M?_.findIndex($=>$===M):-1;let I=null;if(A!==-1&&A<_.length-1){const $=_[A+1];I=await qo("markdown",w,$.startBlockId)}else{const $=((z=M==null?void 0:M.noteBlocks)==null?void 0:z.slice(-1)[0])||((j=M==null?void 0:M.blocks)==null?void 0:j.slice(-1)[0]),T=($==null?void 0:$.id)||(M==null?void 0:M.startBlockId);T?I=await qo("markdown",w,void 0,T):I=await ws("markdown",w,e.currentDocId.value)}const N=((x=(D=(B=I==null?void 0:I[0])==null?void 0:B.doOperations)==null?void 0:D[0])==null?void 0:x.id)||((V=I==null?void 0:I[0])==null?void 0:V.id);return N&&(await ze(N,{[Ve]:"true"}),Ee.setBlockAttrOverride(N,{[Ve]:"true"}),Jo(N,(W=e.plugin)==null?void 0:W.app)),e.plugin&&await e.plugin.compileCurrentDocument(),N}async function s(){const g=e.activeBlockId.value;if(g)if(e.isNoteBlock.value){i("取消中...");try{await ze(g,{[Ve]:""}),Ee.setBlockAttrOverride(g,{[Ve]:""}),et(g,{[Ve]:""}),delete e.activeBlockAttrs.value[Ve],i("已取消备注"),le.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(b){console.error("[SiYuanLiveSlides] 取消讲稿备注失败:",b),i("取消失败"),le.showMessage("取消讲稿备注失败")}}else{i("转换中...");try{let b=e.rawSnippet.value;try{const M=await bd(g);M!=null&&M.kramdown&&(b=M.kramdown)}catch{}const _=`> [!NOTE] 💡 演讲备注
${(pr(b)||b.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(M=>`> ${M}`).join(`
`)}
{: custom-slides-note="true"}`;await xs("markdown",_,g),await ze(g,{[Ve]:"true"}),Ee.setBlockAttrOverride(g,{[Ve]:"true"}),et(g,{[Ve]:"true"}),e.activeBlockAttrs.value[Ve]="true",e.activeBlockType.value="NodeCallout",i("已设为讲稿备注"),le.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(b){console.error("[SiYuanLiveSlides] 转换讲稿备注提示块失败:",b),i("设置失败"),le.showMessage("转为讲稿备注提示块失败")}}}async function l(){try{await n(),le.showMessage("已在正文末尾插入讲稿备注提示块")}catch(g){le.showMessage("插入讲稿备注块失败"),console.error(g)}}function r(){var k;const g=e.currentSlideNoteBlockId.value;if(!g){le.showMessage("未找到本页关联的讲稿备注块");return}Jo(g,(k=e.plugin)==null?void 0:k.app)?le.showMessage("已在编辑区定位讲稿备注块"):le.showMessage("定位讲稿备注块失败")}async function a(){var k;if(!e.currentDocId.value)return;const g=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};le.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const b=await gc(g,El);if(b.notes){const w=e.currentSlideNoteBlockId.value;if(w){const _=`> [!NOTE] 💡 演讲备注
${b.notes.split(/\r?\n/).map(M=>`> ${M}`).join(`
`)}
{: custom-slides-note="true"}`;await xs("markdown",_,w),await ze(w,{[Ve]:"true"}),Ee.setBlockAttrOverride(w,{[Ve]:"true"}),Jo(w,(k=e.plugin)==null?void 0:k.app)}else await n(b.notes);b.isAiGenerated?le.showMessage("思源 AI 演讲提词卡生成成功！"):le.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}const c=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(k=>`> ${k}`).join(`
`)}
{: custom-slides-note="true"}`;async function u(){var w,_;const g=e.currentDocId.value||((w=e.plugin)==null?void 0:w.currentDocId)||"",b=(_=e.latestDoc.value)==null?void 0:_.slides;if(Array.isArray(b)&&b.length>0)return{docId:g,slides:b};if(!g)return{docId:"",slides:[]};const k=await Ee.compile(g).catch(()=>null);return{docId:g,slides:(k==null?void 0:k.slides)||[]}}async function h(g,b,k,w){var A,I,N,H,z,j;let _=null;if(b<k.length-1){const B=k[b+1];_=await qo("markdown",c,B.startBlockId)}else{const B=((A=g==null?void 0:g.noteBlocks)==null?void 0:A.slice(-1)[0])||((I=g==null?void 0:g.blocks)==null?void 0:I.slice(-1)[0]),D=(B==null?void 0:B.id)||(g==null?void 0:g.startBlockId);D?_=await qo("markdown",c,void 0,D):_=await ws("markdown",c,w||e.currentDocId.value)}const M=((z=(H=(N=_==null?void 0:_[0])==null?void 0:N.doOperations)==null?void 0:H[0])==null?void 0:z.id)||((j=_==null?void 0:_[0])==null?void 0:j.id);M&&(await ze(M,{[Ve]:"true"}),Ee.setBlockAttrOverride(M,{[Ve]:"true"}))}async function y(){if(o.value)return;const{docId:g,slides:b}=await u();if(b.length===0){le.showMessage("当前文档无幻灯片页面");return}const k=b.map((_,M)=>({slide:_,idx:M})).filter(({slide:_})=>{var I;const M=Array.isArray(_.noteBlocks)&&_.noteBlocks.length>0,A=!!((I=_.notes)!=null&&I.trim());return!M&&!A});if(k.length===0){le.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const w=k.length;le.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${w} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{if(o.value)return;o.value=!0,le.showMessage("正在批量追加讲稿块...");let _=0;try{for(const{slide:M,idx:A}of k)try{await h(M,A,b,g),_++}catch(I){console.error(`[SiYuanLiveSlides] 为第 ${A+1} 页追加讲稿块失败:`,I)}e.plugin&&await e.plugin.compileCurrentDocument(),le.showMessage(`已成功为 ${_} 页追加讲稿备注块`)}catch(M){console.error("[SiYuanLiveSlides] 批量追加讲稿块失败:",M),le.showMessage("批量追加讲稿块时出现异常")}finally{o.value=!1}})}async function d(){if(o.value)return;const{slides:g}=await u();if(g.length===0){le.showMessage("当前文档无幻灯片页面");return}const b=[];for(const _ of g)if(_.noteBlocks&&_.noteBlocks.length>0)for(const M of _.noteBlocks)M.id&&b.push({id:M.id,pageIndex:_.pageIndex});if(b.length===0){le.showMessage("当前文档中没有讲稿备注块，无需删除");return}const k=new Set(b.map(_=>_.pageIndex)).size,w=b.length;le.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${w} 个讲稿备注块（涉及 ${k} 页），删除后无法撤销。是否确认继续？`,async()=>{if(o.value)return;o.value=!0,le.showMessage("正在批量删除讲稿块...");let _=0;try{for(const M of b)try{await Vs(M.id),Ee.clearBlockAttrOverride(M.id),_++}catch(A){console.error(`[SiYuanLiveSlides] 删除讲稿块 ${M.id} 失败:`,A)}e.activeBlockId.value&&b.some(M=>M.id===e.activeBlockId.value)&&delete e.activeBlockAttrs.value[Ve],e.plugin&&await e.plugin.compileCurrentDocument(),le.showMessage(`已成功删除全部 ${_} 个讲稿备注块`)}catch(M){console.error("[SiYuanLiveSlides] 批量删除讲稿块失败:",M),le.showMessage("批量删除讲稿块时出现异常")}finally{o.value=!1}})}async function f(){var b;const g=e.currentDocId.value||((b=e.plugin)==null?void 0:b.currentDocId);if(!g){le.showMessage("请先在主编辑区打开幻灯片文档");return}if(o.value){le.showMessage("正在批量处理中，请稍候...");return}o.value=!0;try{await vc(g,{onSuccessNotice:i,compileFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{o.value=!1}}async function p(){if(o.value){le.showMessage("正在批量处理中，请稍候...");return}const{docId:g,slides:b}=await u();if(!g){le.showMessage("请先在主编辑区打开幻灯片文档");return}if(b.length===0){le.showMessage("当前文档无幻灯片页面");return}const k=await yc(g),w=new Set(k.map(A=>A.pageIndex)),_=b.map((A,I)=>({slide:A,idx:I})).filter(({slide:A,idx:I})=>{var j;const N=Array.isArray(A.noteBlocks)&&A.noteBlocks.length>0,H=!!((j=A.notes)!=null&&j.trim()),z=A.pageIndex??I+1;return!N&&!H&&!w.has(z)});if(k.length===0&&_.length===0){le.showMessage("所有幻灯片页面均已存在讲稿备注块，无需重复操作");return}let M="";k.length>0&&_.length>0?M=`扫描检测到 ${k.length} 处已有候选讲稿待规范化，另有 ${_.length} 页暂无讲稿将新增默认讲稿块，是否继续？`:k.length>0?M=`扫描检测到 ${k.length} 处已有候选讲稿块（提示块或引用块），是否规范化为标准演讲备注？`:M=`将在未配置讲稿的 ${_.length} 页末尾自动增加默认讲稿提示块，是否继续？`,le.confirm("增加讲稿块",M,async()=>{if(o.value)return;o.value=!0,le.showMessage("正在处理讲稿块...");let A=0,I=0;try{for(const N of k)try{await bc(N.id,N.cleanContent),A++}catch(H){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${N.id} 失败:`,H)}for(const{slide:N,idx:H}of _)try{await h(N,H,b,g),I++}catch(z){console.error(`[SiYuanLiveSlides] 为第 ${H+1} 页增加讲稿块失败:`,z)}e.plugin&&await e.plugin.compileCurrentDocument(),i("已更新讲稿"),A>0&&I>0?le.showMessage(`已规范化 ${A} 处现有讲稿，并为 ${I} 页新增讲稿块`):A>0?le.showMessage(`已成功识别并规范化 ${A} 个讲稿块`):le.showMessage(`已成功为 ${I} 页增加讲稿备注块`)}catch(N){console.error("[SiYuanLiveSlides] 增加讲稿块失败:",N),le.showMessage("增加讲稿块时出现异常")}finally{o.value=!1}})}return{isBatchProcessing:o,createNoteBlockOnCurrentSlide:n,onToggleNoteBlock:s,onAddNoteBlock:l,onLocateNoteBlock:r,onGenerateNotesWithAI:a,onBatchAppendNotes:y,onBatchDeleteNotes:d,onIdentifyNotesBlocks:f,onAddOrIdentifyNotesBlocks:p}}function gw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading")return!0;const o=String(e.subType||"").toLowerCase();if(/^h[1-6]$/.test(o))return!0;const i=String(e.rawMarkdown||e.markdown||"").trim();return!!/^#{1,6}\s+/.test(i)}function yw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return t==="i"||t==="nodelistitem"}function bw(e){const t=[],o=i=>{var n,s,l,r,a,c,u,h,y;for(const d of i){if(!d||d.isNote||((n=d.attributes)==null?void 0:n[Ve])==="true"||((s=d.ial)==null?void 0:s[Ve])==="true"||d.type==="tb"||d.type==="thematic-break"||d.type==="NodeThematicBreak"||String(d.markdown||d.rawMarkdown||"").trim()==="---"||d.slot==="slot-divider-right"||String(d.rawMarkdown||d.markdown||"").trim()==="::right::")continue;if(gw(d)){t.push({id:d.id,type:d.type,isHeading:!0,currentClicks:d.clicks||((l=d.attributes)==null?void 0:l[Oe])||((r=d.ial)==null?void 0:r[Oe]),rawBlock:d});continue}if(yw(d)){t.push({id:d.id,type:d.type||"i",isHeading:!1,currentClicks:d.clicks||((a=d.attributes)==null?void 0:a[Oe])||((c=d.ial)==null?void 0:c[Oe]),rawBlock:d});continue}const f=d.children&&d.children.length>0?d.children:(u=d.rawNode)==null?void 0:u.children;if(Array.isArray(f)&&f.length>0){o(f);continue}t.push({id:d.id,type:d.type,isHeading:!1,currentClicks:d.clicks||((h=d.attributes)==null?void 0:h[Oe])||((y=d.ial)==null?void 0:y[Oe]),rawBlock:d})}};return o(e||[]),t}function vw(e){var n;if(e.pageIndex===1||((n=e.frontmatter)==null?void 0:n.layout)==="cover")return[];const t=bw(e.blocks||[]);if(t.length===0)return[];let o=-1;for(let s=0;s<t.length;s++)if(!t[s].isHeading){o=s;break}if(o===-1)return[];const i=[];for(let s=o+1;s<t.length;s++){const l=t[s];!!!(l.currentClicks&&String(l.currentClicks).trim()!=="")&&l.id&&i.push({blockId:l.id,pageIndex:e.pageIndex,targetClick:"+1"})}return i}async function kw(e,t){const i=await((t==null?void 0:t.compileDocFn)||(l=>Ee.compile(l)))(e).catch(()=>null);if(!i||!Array.isArray(i.slides)||i.slides.length===0)return{totalPages:0,animatedPagesCount:0,targets:[]};const n=[],s=new Set;for(const l of i.slides){const r=vw(l);r.length>0&&(n.push(...r),s.add(l.pageIndex))}return{totalPages:i.slides.length,animatedPagesCount:s.size,targets:n}}async function kc(e,t){const o=(t==null?void 0:t.showMessageFn)||le.showMessage,i=(t==null?void 0:t.confirmFn)||le.confirm,n=(t==null?void 0:t.setBlockAttrsFn)||ze,s=(t==null?void 0:t.syncDomFn)||et;if(!e)return o("请先在主编辑区打开幻灯片文档"),{totalPages:0,animatedPagesCount:0,targets:[],successCount:0,errorCount:0};const l=await kw(e,t);if(l.targets.length===0)return o("未检测到需要配置顺延动效的后续块"),{...l,successCount:0,errorCount:0};const r=l.targets.length,a=l.animatedPagesCount;return new Promise(c=>{i("智能设置动效",`扫描检测到可为 ${a} 页中的 ${r} 个后续块配置顺延 (+1) 动效，是否继续？`,async()=>{var y;o(`正在批量配置 ${r} 个后续块动效...`);let u=0,h=0;for(const d of l.targets)try{await n(d.blockId,{[Oe]:d.targetClick}),Ee.setBlockAttrOverride(d.blockId,{[Oe]:d.targetClick}),s(d.blockId,{[Oe]:d.targetClick}),u++}catch(f){console.error(`[SiYuanLiveSlides] 为块 ${d.blockId} 配置动效失败:`,f),h++}(y=t==null?void 0:t.onSuccessNotice)==null||y.call(t,"已配置智能动效"),o(`已成功为 ${u} 个后续块配置顺延 (+1) 动效`),t!=null&&t.compileCurrentDocFn&&await t.compileCurrentDocFn().catch(()=>{}),c({...l,successCount:u,errorCount:h})},()=>{c({...l,successCount:0,errorCount:0})})})}async function ww(e,t){const i=await((t==null?void 0:t.compileDocFn)||(a=>Ee.compile(a)))(e).catch(()=>null);if(!i||!Array.isArray(i.slides)||i.slides.length===0)return{totalPages:0,affectedPagesCount:0,targets:[]};const n=[],s=new Set,l=new Set,r=(a,c)=>{var u,h,y,d,f;for(const p of a){if(!p)continue;if(p.id&&!s.has(p.id)){const b=Ee.getBlockAttrOverride(p.id),k=(b==null?void 0:b[Oe])??p.clicks??((u=p.attributes)==null?void 0:u[Oe])??((h=p.ial)==null?void 0:h[Oe]),w=(b==null?void 0:b[At])??p.motion??((y=p.attributes)==null?void 0:y[At])??((d=p.ial)==null?void 0:d[At]),_=!!(k&&String(k).trim()!==""),M=!!(w&&String(w).trim()!=="");(_||M)&&(s.add(p.id),n.push({blockId:p.id,pageIndex:c,hasClick:_,hasMotion:M}),l.add(c))}const g=p.children&&p.children.length>0?p.children:(f=p.rawNode)==null?void 0:f.children;Array.isArray(g)&&g.length>0&&r(g,c)}};for(const a of i.slides)r(a.blocks||[],a.pageIndex);return{totalPages:i.slides.length,affectedPagesCount:l.size,targets:n}}async function xw(e,t){const o=(t==null?void 0:t.showMessageFn)||le.showMessage,i=(t==null?void 0:t.confirmFn)||le.confirm,n=(t==null?void 0:t.setBlockAttrsFn)||ze,s=(t==null?void 0:t.syncDomFn)||et;if(!e)return o("请先在主编辑区打开幻灯片文档"),{totalPages:0,affectedPagesCount:0,targets:[],successCount:0,errorCount:0};const l=await ww(e,t);if(l.targets.length===0)return o("当前文档未检测到已配置的页面动效，无需清除"),{...l,successCount:0,errorCount:0};const r=l.targets.length,a=l.affectedPagesCount;return new Promise(c=>{i("危险操作：清除所有页面动效",`此操作将清除 ${a} 页中全部 ${r} 个内容块的逐步显现（v-click）与入场微动效（v-motion）配置，清除后无法撤销。是否确认继续？`,async()=>{var d;o(`正在清除 ${r} 个内容块的动效配置...`);let u=0,h=0;const y={[Oe]:"",[At]:""};for(const f of l.targets)try{await n(f.blockId,y),Ee.setBlockAttrOverride(f.blockId,y),s(f.blockId,y),u++}catch(p){console.error(`[SiYuanLiveSlides] 清除块 ${f.blockId} 动效失败:`,p),h++}(d=t==null?void 0:t.onSuccessNotice)==null||d.call(t,"已清除动效"),o(`已成功清除 ${u} 个内容块的动效配置`),t!=null&&t.compileCurrentDocFn&&await t.compileCurrentDocFn().catch(()=>{}),c({...l,successCount:u,errorCount:h})},()=>{c({...l,successCount:0,errorCount:0})})})}function Sw(e,t){const{saveAttr:o,saveAttrs:i,savePageAttr:n}=t;async function s(){(e.videoAutoplay.value?"false":"true")==="true"?(await i({[Vo]:"true",[si]:"true"}),e.activeBlockAttrs.value[Vo]="true",e.activeBlockAttrs.value[si]="true"):(await o(Vo,"false"),e.activeBlockAttrs.value[Vo]="false")}async function l(){const z=e.videoLoop.value?"false":"true";await o(_n,z)}async function r(){const z=e.videoMuted.value?"false":"true";await o(si,z)}async function a(){const z=e.videoControls.value?"false":"true";await o(Cn,z)}async function c(z){var V,W;const j=e.activeBlockId.value;if(!j)return;const B=e.rawSnippet.value||"",D=bo(B)||"",x=e.currentPageDividerId.value||e.currentDocId.value;if(z)if(z==="background"){const $={[Ye]:"background",[be]:""};x&&D&&(e.pageBackground&&(e.pageBackground.value=D),await ze(x,{[ct]:D}).catch(()=>{}),Ee.setBlockAttrOverride(x,{[ct]:D}),et(x,{[ct]:D}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=D)),await i($)}else(z===In||z===$n)&&await i({[be]:z,[Ye]:""});else{const $={[Ye]:"",[be]:""};if(e.activeBlockAttrs.value[ct]==="true"&&($[ct]=""),x&&D&&((V=e.pageBackground)==null?void 0:V.value)===D&&(e.pageBackground&&(e.pageBackground.value=""),await ze(x,{[ct]:""}).catch(()=>{}),Ee.setBlockAttrOverride(x,{[ct]:""}),et(x,{[ct]:""}),(W=e.targetSlide.value)!=null&&W.frontmatter&&delete e.targetSlide.value.frontmatter.background),await i($),typeof document<"u"){const T=document.querySelector(`.protyle-wysiwyg [data-node-id="${j}"]`),O=T==null?void 0:T.closest('[data-type="NodeListItem"]'),te=O==null?void 0:O.getAttribute("data-node-id");if(te&&te!==j){const K={[be]:"",[Ye]:""};et(te,K),Ee.setBlockAttrOverride(te,K),await ze(te,K).catch(()=>{})}}}}function u(){e.elemClick.value?o(Oe,""):o(Oe,"+1")}function h(z){o(Oe,z)}function y(z){o(At,z)}function d(z){(e.activeBlockAttrs.value[Ae]||"")===z?o(Ae,""):o(Ae,z)}function f(z){e.elemShikiLines.value=z,o(Xo,z)}function p(z){const j=z?z.trim():"",B=/^\d+$/.test(j)?`${j}px`:j;e.elemMaxHeight.value=B,o(qi,B)}async function g(){const z=e.currentSlideLayout.value==="three-cols-header";await o(Ae,z?"col-1":"left"),le.showMessage(z?"已将当前块设置为第 1 栏":"已将当前块设置为双栏左栏")}async function b(){const z=e.activeBlockId.value;z&&le.confirm("清除块演示属性","确定要清除当前块的所有演示属性（包含动画、插槽、备注等）吗？此操作无法撤销。",async()=>{const j={[Oe]:"",[At]:"",[Ae]:"",[Xo]:"",[qi]:"",[Ve]:"",[be]:"",[mt]:"",[Ye]:"",[wt]:"",[ct]:"",[Ft]:"",[Vo]:"",[_n]:"",[si]:"",[Cn]:""};if(et(z,j),await ze(z,j),Ee.clearBlockAttrOverride(z),typeof document<"u"){const B=document.querySelector(`.protyle-wysiwyg [data-node-id="${z}"]`),D=B==null?void 0:B.closest('[data-type="NodeListItem"]'),x=D==null?void 0:D.getAttribute("data-node-id");x&&x!==z&&(et(x,j),await ze(x,j).catch(()=>{}),Ee.clearBlockAttrOverride(x))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground&&(e.pageBackground.value=""),e.pageImage.value="",le.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()})}async function k(){if(e.activeBlockId.value)try{await qo("markdown","---",e.activeBlockId.value,void 0),le.showMessage("已在上方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{le.showMessage("插入分页符失败")}}async function w(){const z=e.activeBlockId.value||e.currentDocId.value;if(z)try{await qo("markdown","---",void 0,z),le.showMessage("已在下方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{le.showMessage("插入分页符失败")}}async function _(){if(e.activeBlockId.value)try{await Vs(e.activeBlockId.value),le.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{le.showMessage("删除失败")}}async function M(){var z,j;try{let B=null;if(typeof document<"u"){const x=e.activeBlockId.value;if(x){const V=document.querySelector(`.protyle-wysiwyg [data-node-id="${x}"]`);V&&(B=V.getAttribute("data-type")==="NodeSuperBlock"?V:V.closest('[data-type="NodeSuperBlock"]'))}if(!B){const V=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(V){const W=document.querySelector(`.protyle-wysiwyg [data-node-id="${V}"]`);if(W){let $=W.nextElementSibling;for(;$&&!($.getAttribute("data-type")==="NodeThematicBreak"||(z=$.classList)!=null&&z.contains("protyle-wysiwyg__block--hr"));){const T=$.getAttribute("data-type")==="NodeSuperBlock"?$:$.querySelector('[data-type="NodeSuperBlock"]');if(T){B=T;break}$=$.nextElementSibling}}}else{const W=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),$=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const T of $)if(!W||T.compareDocumentPosition(W)&Node.DOCUMENT_POSITION_FOLLOWING){B=T;break}}}}const D=[];if(B){const x=Array.from(B.querySelectorAll(":scope > [data-node-id]"));for(const V of x){const W=V.getAttribute("data-node-id");W&&(D.push(W),V.removeAttribute("style"))}}else if((j=e.targetSlide.value)!=null&&j.blocks){for(const x of e.targetSlide.value.blocks)if(x.children&&x.children.length>=2){for(const V of x.children)V.id&&D.push(V.id);break}}if(D.length>0)for(const x of D)await ze(x,{style:""}).catch(()=>{});await n(mt,""),le.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(B){console.error("[layout-actions] resetSuperBlockWidth error:",B),le.showMessage("重置超级块比例失败")}}async function A(){var z,j,B;try{let D=null;if(typeof document<"u"){const V=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),W=e.activeBlockId.value;let $=[];if(V){const te=document.querySelector(`.protyle-wysiwyg [data-node-id="${V}"]`);if(te){let K=te.nextElementSibling;for(;K&&!(K.getAttribute("data-type")==="NodeThematicBreak"||(z=K.classList)!=null&&z.contains("protyle-wysiwyg__block--hr"));)$.push(K),K=K.nextElementSibling}}else{const te=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),K=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const Z of K)if(!te||Z.compareDocumentPosition(te)&Node.DOCUMENT_POSITION_FOLLOWING)$.push(Z);else break}const T=[];let O;for(const te of $){const K=te.getAttribute("data-type");K==="NodeHeading"&&(O=te.getAttribute("data-node-id")||void 0);const Z=[];K==="NodeSuperBlock"?Z.push(te):Z.push(...Array.from(te.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const ce of Z){if((ce.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const re=ce.getAttribute("data-node-id")||"";let Se=[];const Ie=Array.from(ce.querySelectorAll('[data-type="NodeListItem"]'));if(Ie.length===4&&(Se=Ie.map(ve=>ve.getAttribute("data-node-id")).filter(Boolean)),Se.length!==4){const ve=Array.from(ce.querySelectorAll(":scope > [data-node-id]"));ve.length===4&&(Se=ve.map(_e=>_e.getAttribute("data-node-id")).filter(Boolean))}Se.length===4&&T.push({sbId:re,itemIds:Se,headerId:O})}}T.length>0&&(W&&(D=T.find(te=>{if(te.sbId===W||te.itemIds.includes(W))return!0;const K=document.querySelector(`.protyle-wysiwyg [data-node-id="${te.sbId}"]`),Z=document.querySelector(`.protyle-wysiwyg [data-node-id="${W}"]`);return!!(K&&Z&&K.contains(Z))})||null),D||(D=T[0]))}if(!D&&((j=e.targetSlide.value)!=null&&j.blocks)){const V=e.targetSlide.value,W=[];for(const T of V.blocks)T.rawNode?W.push(T.rawNode):W.push({id:T.id,type:T.type,content:T.content,markdown:T.rawMarkdown,children:T.children,ial:T.attributes||T.ial||{}});const $=ih(W,e.activeBlockId.value);$&&$.items.length===4&&(D={sbId:$.superBlockNode.id,itemIds:$.items.map(T=>T.id),headerId:(B=$.headerNode)==null?void 0:B.id})}const x=e.currentPageDividerId.value||e.currentDocId.value;if(x&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Ee.setBlockAttrOverride(x,{[be]:"clover"}),et(x,{[be]:"clover"}),await ze(x,{[be]:"clover"}).catch(()=>{})),D&&D.itemIds.length>0){D.headerId&&(Ee.setBlockAttrOverride(D.headerId,{[Ae]:"header"}),et(D.headerId,{[Ae]:"header"}),await ze(D.headerId,{[Ae]:"header"}).catch(()=>{}));const V=Math.min(4,D.itemIds.length);for(let W=0;W<V;W++){const $=D.itemIds[W],T=`col-${W+1}`;Ee.setBlockAttrOverride($,{[Ae]:T}),et($,{[Ae]:T}),await ze($,{[Ae]:T}).catch(()=>{})}}return le.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(D){return console.error("[layout-actions] applyCloverLayout error:",D),le.showMessage("配置四叶草布局失败",4e3,"error"),!1}}async function I(){var j,B;const z=e.currentDocId.value||((j=e.plugin)==null?void 0:j.currentDocId);if(!z){le.showMessage("请先在主编辑区打开幻灯片文档");return}if((B=t.isBatchProcessing)!=null&&B.value){le.showMessage("正在批量处理中，请稍候...");return}t.isBatchProcessing&&(t.isBatchProcessing.value=!0);try{await kc(z,{onSuccessNotice:t.triggerSaveNotice,compileCurrentDocFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{t.isBatchProcessing&&(t.isBatchProcessing.value=!1)}}async function N(){var j,B;const z=e.currentDocId.value||((j=e.plugin)==null?void 0:j.currentDocId);if(!z){le.showMessage("请先在主编辑区打开幻灯片文档");return}if((B=t.isBatchProcessing)!=null&&B.value){le.showMessage("正在批量处理中，请稍候...");return}t.isBatchProcessing&&(t.isBatchProcessing.value=!0);try{const D=await xw(z,{onSuccessNotice:t.triggerSaveNotice,compileCurrentDocFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}});D.successCount>0&&e.activeBlockId.value&&D.targets.some(x=>x.blockId===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[Oe],delete e.activeBlockAttrs.value[At])}finally{t.isBatchProcessing&&(t.isBatchProcessing.value=!1)}}async function H(){var B,D,x,V;const z=await aw({currentDocId:((B=e.currentDocId)==null?void 0:B.value)||"",activeBlockId:((D=e.activeBlockId)==null?void 0:D.value)||""});if(!z.success){le.showMessage(z.error||"合并为横向超级块失败");return}const j=`🎉 已成功合并为横向超级块 (${z.colCount||2} 列)`;le.showMessage(j),t.triggerSaveNotice&&t.triggerSaveNotice(j),(x=e.plugin)!=null&&x.compileCurrentDocument&&await e.plugin.compileCurrentDocument((V=e.currentDocId)==null?void 0:V.value)}return{onToggleVideoAutoplay:s,onToggleVideoLoop:l,onToggleVideoMuted:r,onToggleVideoControls:a,onImageRoleChange:c,toggleElemClick:u,onElemClickStepChange:h,onElemMotionChange:y,onElemSlotChange:d,onElemShikiLinesChange:f,onElemMaxHeightChange:p,onSetTwoColsContrast:g,onClearBlockAttrs:b,onInsertDividerBefore:k,onInsertDividerAfter:w,onDeleteCurrentBlock:_,onConvertToSuperBlock:H,resetSuperBlockWidth:M,applyCloverLayout:A,onAutoAnimateDocument:I,onClearAnimationsDocument:N}}function _w(e){const{triggerSaveNotice:t,saveAttrs:o,saveAttr:i,savePageAttr:n,applyPageLayoutAndRatio:s,saveDocAttr:l}=uw(e),r=mw(e,{triggerSaveNotice:t}),a=Sw(e,{saveAttr:i,saveAttrs:o,savePageAttr:n,triggerSaveNotice:t,isBatchProcessing:r.isBatchProcessing});async function c(){var b;if(!e.latestDoc.value){le.showMessage("请先在主编辑区打开幻灯片文档");return}const d=e.latestDoc.value,f=await No(d,(b=e.currentDocId)==null?void 0:b.value,e.plugin);le.showMessage("正在导出单文件离线 HTML（内联媒体资源中...）",2e3);const p=await oc(d,{title:f});ic(`${f}.html`,p)&&le.showMessage(`已开始下载单文件离线 HTML 演示包 (${f}.html)`)}function u(){if(!e.latestDoc.value){le.showMessage("请先在主编辑区打开幻灯片文档");return}nc(e.latestDoc.value)&&le.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const h=pe(!1);async function y(){var d;if(h.value){le.showMessage("正在导出图片中，请稍候...",2e3);return}if(!e.latestDoc.value){le.showMessage("请先在主编辑区打开幻灯片文档");return}h.value=!0;try{le.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const f=e.latestDoc.value,p=await No(f,(d=e.currentDocId)==null?void 0:d.value,e.plugin),g=await cc(f,{title:p,onProgress:(b,k)=>{le.showMessage(`正在导出幻灯片图片 (${b} / ${k})...`,2e3)}});g.success?le.showMessage(`🎉 成功导出 ${g.total||0} 张幻灯片高清图片并已保存为 ${p}.zip！`,4e3):le.showMessage(`导出图片失败：${g.error||"未知异常"}`)}finally{h.value=!1}}return{triggerSaveNotice:t,saveAttrs:o,saveAttr:i,savePageAttr:n,applyPageLayoutAndRatio:s,saveDocAttr:l,onToggleVideoAutoplay:a.onToggleVideoAutoplay,onToggleVideoLoop:a.onToggleVideoLoop,onToggleVideoMuted:a.onToggleVideoMuted,onToggleVideoControls:a.onToggleVideoControls,onImageRoleChange:a.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,onIdentifyNotesBlocks:r.onIdentifyNotesBlocks,onAddOrIdentifyNotesBlocks:r.onAddOrIdentifyNotesBlocks,toggleElemClick:a.toggleElemClick,onElemClickStepChange:a.onElemClickStepChange,onElemMotionChange:a.onElemMotionChange,onElemSlotChange:a.onElemSlotChange,onElemShikiLinesChange:a.onElemShikiLinesChange,onElemMaxHeightChange:a.onElemMaxHeightChange,onSetTwoColsContrast:a.onSetTwoColsContrast,onClearBlockAttrs:a.onClearBlockAttrs,onInsertDividerBefore:a.onInsertDividerBefore,onInsertDividerAfter:a.onInsertDividerAfter,onDeleteCurrentBlock:a.onDeleteCurrentBlock,onConvertToSuperBlock:a.onConvertToSuperBlock,resetSuperBlockWidth:a.resetSuperBlockWidth,applyCloverLayout:a.applyCloverLayout,onAutoAnimateDocument:a.onAutoAnimateDocument,onClearAnimationsDocument:a.onClearAnimationsDocument,isExportingImages:h,onExportHtml:c,onExportPdf:u,onExportImages:y}}function Cw(e){const t=ye(()=>yr(e.activeBlockType.value));function o(i){const{attrKey:n,fallback:s,mode:l="defined"}=i,r=a=>l==="truthy"?a:a!==void 0;return ye(()=>{if(t.value){const c=e.activeBlockAttrs.value[n];if(r(c))return c}const a=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(a){const c=Ee.getBlockAttrOverride(a);if(r(c==null?void 0:c[n]))return c[n]}return s()})}return{isDivider:t,resolvePageAttr:o}}function gs(e){if(e.type==="h"){if(e.subType==="h1")return 1;if(e.subType==="h2")return 2;if(e.subType==="h3")return 3}const t=(e.markdown||e.content||"").trimStart();return t.startsWith("# ")?1:t.startsWith("## ")?2:t.startsWith("### ")?3:null}function Iw(e,t){for(let o=t-1;o>=0;o--){const i=e[o];if(mo(i)||(i.content||i.markdown||"").trim())return i}return null}function ys(e){const t=e.type;if(t==="c"||t==="code"||t==="t"||t==="table"||t==="s"||t==="super")return 3;if(t==="l"||t==="list"||t==="b"||t==="blockquote")return 2;const o=(e.markdown||e.content||"").trim();return o?o.includes("![")||o.includes("<img")||o.length>100?2:1:0}function $l(e,t){if(e===1)return"cover";let o=!1,i=-1;for(let r=0;r<t.length;r++){const a=t[r],c=(a.markdown||a.content||"").trim();if(c.includes("![")||c.includes("<img")||a.type==="img"){o=!0,i=r;break}}if(o)return i===0?"image-left":"image-right";let n=0,s=!1,l=!1;for(const r of t)(r.type==="i"||r.type==="l"||(r.markdown||"").trim().startsWith("- "))&&n++,r.type==="s"&&(s=!0),r.type==="b"&&(l=!0);return s||n>=3?"two-cols":l&&t.length<=2?"quote":"default"}function $w(e,t){const o=[],i=new Set,n=6,s=6;let l=0,r=0,a=0,c=0,u=null;function h(y){const d=[];for(let f=y+1;f<e.length;f++){const p=e[f];if(mo(p))break;const g=gs(p);if(g!==null&&(g===1||g===2||g===3))break;d.push(p)}return d}if(e.length>0){let y=!1,d=-1;for(let f=0;f<e.length;f++){const p=e[f];if(mo(p)){y=!0;break}if((p.content||p.markdown||"").trim()){d=f;break}}if(!y&&d>=0){const f=e[d],p=gs(f);let g=p===1?"cover":"default";if(p!==1){const k=h(d);g=$l(p,k)}const b=p===1?"作为第一页起点插入分页线 (封面大章)":"作为第一页起点插入分页线";o.push({blockId:f.id,recommendedLayout:g,reason:b}),i.add(f.id)}}for(let y=0;y<e.length;y++){const d=e[y];if(mo(d)){l=0,r=0,a=0,c=0,u=null;continue}const f=Iw(e,y),p=!f||mo(f),g=gs(d);if(g===1||g===2||g===3){if(!(a===1&&c===0&&u!==null&&!(u===1&&g===2))&&!p&&l>0&&!i.has(d.id)){let M=g===1?"cover":"default";{const I=h(y);M=$l(g,I)}let A=g===1?"检测到一级核心章节标题，建议作为新幻灯片封面/大章":g===2?"检测到二级分论点标题，建议开启新页":"检测到三级要点标题，建议开启新页";M==="image-right"||M==="image-left"?A+=" (推荐图文版式)":M==="two-cols"?A+=" (推荐双栏版式)":M==="quote"&&(A+=" (推荐引言版式)"),o.push({blockId:d.id,recommendedLayout:M,reason:A}),i.add(d.id),l=1,r=ys(d),a=1,c=0,u=g;continue}l++,r+=ys(d),a++,u=g;continue}const k=ys(d);if((l>=n||r+k>s&&l>0)&&!p&&l>0&&!i.has(d.id)){o.push({blockId:d.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),i.add(d.id),l=1,r=k,a=0,c=1,u=null;continue}l++,r+=k,c++}return o}async function wc(e){if(!e.currentDocId&&typeof document<"u"){const s=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}if(!e.currentDocId){le.showMessage("请先打开一篇思源笔记文档");return}const t=await ki(e.currentDocId).catch(()=>[]);if(!t||t.length===0){le.showMessage("当前文档无内容，无需断页");return}const o=t.map(s=>({id:s.id,type:s.type,subType:s.subType,content:s.content||"",markdown:s.markdown||""})),i=$w(o);if(i.length===0){le.showMessage("智能分析完毕：当前文档结构合理，暂无新增分页建议");return}le.showMessage(`智能分析完毕：发现 ${i.length} 处建议分页点，正在自动插入分页线...`);let n=0;for(const s of i)try{await qo("markdown","---",s.blockId,void 0),await ze(s.blockId,{"custom-slides-layout":s.recommendedLayout}),n++}catch(l){console.warn("Failed to insert divider:",l)}le.showMessage(`已成功在 ${n} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}async function xc(e){var s,l,r,a,c,u;if(!e.currentDocId&&typeof document<"u"){const h=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(h==null?void 0:h.getAttribute("data-doc-id"))||""}if(!e.currentDocId){le.showMessage("请先打开一篇思源笔记文档");return}const t=await ki(e.currentDocId).catch(()=>[]);if(!t||t.length===0){le.showMessage("当前文档无内容");return}const o=[],i=[];for(const h of t)h.type==="tb"||h.type==="thematic-break"||h.type==="NodeThematicBreak"||((s=h.markdown)==null?void 0:s.trim())==="---"||((l=h.markdown)==null?void 0:l.trim())==="***"||h.type==="b"&&(((r=h.markdown)==null?void 0:r.trim())==="---"||((a=h.content)==null?void 0:a.trim())==="---")?o.push(h.id):((c=h.ial)!=null&&c[fo]||(u=h.ial)!=null&&u[be])&&i.push(h.id);if(o.length===0&&i.length===0){le.showMessage("当前文档中未发现需要清除的幻灯片分页线");return}le.showMessage(`正在清除文档中的 ${o.length} 处分页线...`);let n=0;for(const h of o)try{await Vs(h),n++}catch(y){console.warn("Failed to delete divider block:",y)}for(const h of i)try{await ze(h,{[fo]:"",[be]:""})}catch(y){console.warn("Failed to clear slide attrs:",y)}le.showMessage(`已成功清除文档中的 ${n} 处分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}const Aw={class:"spm-slides-inspector"},Tw={class:"spm-inspector-topbar"},Mw={class:"spm-inspector-title"},Bw={class:"slides-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},Ew={class:"spm-inspector-topbar-actions"},Dw={class:"spm-target-banner"},Lw={class:"spm-target-info"},Ow=["aria-label"],Nw={key:0,class:"spm-save-status"},Pw=["title"],Rw={class:"spm-inspector-body"},zw=Pt({__name:"SlidesInspectorDockView",setup(e,{expose:t}){const o=Wt("plugin"),i=pe(!1);function n(Q){i.value=!1,c.value=Q.docId,o!=null&&o.compileCurrentDocument&&o.compileCurrentDocument(Q.docId)}const s=pe(""),l=pe(""),r=pe({}),a=pe(""),c=pe(""),u=pe(""),h=pe(""),y=pe(""),d=pe(""),f=pe(""),p=pe(""),g=pe(null),b=pe(""),k=pe("");function w(){var ge;const Q=s.value||c.value;Q&&typeof navigator<"u"&&(ge=navigator==null?void 0:navigator.clipboard)!=null&&ge.writeText&&navigator.clipboard.writeText(Q).then(()=>{k.value="已复制！",setTimeout(()=>{k.value=""},1500)}).catch(()=>{})}const _=ye(()=>yr(l.value)),M=ye(()=>l.value==="NodeCodeBlock"),A=pe(!1),I=ye(()=>{if(A.value||Ge.value)return!0;const Q=a.value||"";return!!bo(Q)}),N=ye(()=>{const Q=l.value||"";if(Q==="NodeVideo"||Q==="video")return!0;const ge=a.value||"";return!!(/<video\b/i.test(ge)||/\.mp4\b/i.test(ge))}),H=ye(()=>!s.value||s.value===c.value||l.value==="doc"||l.value==="NodeDocument"),z=ye(()=>{const Q=s.value||c.value||"";return Q.length>8?Q.slice(-8):Q||"无"}),j=ye(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),B=ye(()=>{if(_.value)return"分页符 (---)";if(H.value)return"全局文档";if(N.value)return"视频块";let Q="内容块";switch(l.value){case"NodeHeading":Q="标题块";break;case"NodeParagraph":Q="段落块";break;case"NodeCodeBlock":Q="代码块";break;case"NodeVideo":Q="视频块";break;case"NodeList":case"NodeListItem":Q="列表项";break;case"NodeBlockquote":Q="引述块";break;case"NodeTable":Q="表格块";break;case"NodeSuperBlock":case"s":case"sb":Q="超级块";break;default:Q="内容块";break}return d.value?f.value?`${f.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${Q}`:`分栏容器 › ${Q}`:Q}),D=ye(()=>_.value?"tag-divider":H.value?"tag-doc":"tag-block"),x=ye(()=>r.value[be]||"default"),V=ye(()=>r.value[wt]||"slide-left"),W=pe(""),$=pe(""),T=ye(()=>r.value[Di]||"inherit"),O=ye(()=>{var Q;return rw((Q=g.value)==null?void 0:Q.slides,{activeBlockId:s.value,activeBlockType:l.value,currentTopBlockId:u.value,currentPageDividerId:h.value,activeBlockAttrs:r.value})}),te=ye(()=>{var Q;return((Q=O.value)==null?void 0:Q.notes)||""}),K=ye(()=>{var Q,ge,Be;return((Be=(ge=(Q=O.value)==null?void 0:Q.noteBlocks)==null?void 0:ge[0])==null?void 0:Be.id)||""}),Z=ye(()=>{var We,Ue,Re,bt,sn,Co;if(_.value){const it=r.value[be]||r.value["custom-slides-layout"];if(it)return it}const Q=r.value[Ae]||r.value["custom-slides-slot"];if(Q&&(["col-1","col-2","col-3"].includes(Q)||/^col-\d+$/.test(Q)))return"cols-header";if(y.value)return y.value;const ge=h.value||(_.value?s.value:"");if(ge){const it=Ee.getBlockAttrOverride(ge);if(it!=null&&it[be])return it[be]}if(ge&&((We=g.value)!=null&&We.slides)){const it=g.value.slides.find(ei=>ei.startBlockId===ge);if((Ue=it==null?void 0:it.frontmatter)!=null&&Ue.layout)return it.frontmatter.layout}if((bt=(Re=O.value)==null?void 0:Re.frontmatter)!=null&&bt.layout)return O.value.frontmatter.layout;if((Co=(sn=O.value)==null?void 0:sn.blocks)!=null&&Co.some(it=>it.slot&&(["col-1","col-2","col-3"].includes(it.slot)||/^col-\d+$/.test(it.slot))))return"cols-header";const Be=Ee.getBlockAttrOverride(c.value);return Be!=null&&Be[be]?Be[be]:"default"}),ce=Cw({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,currentPageDividerId:h}),oe=ce.resolvePageAttr({attrKey:mt,mode:"truthy",fallback:()=>{var Q,ge;return((ge=(Q=O.value)==null?void 0:Q.frontmatter)==null?void 0:ge.layoutRatio)||""}}),re=ce.resolvePageAttr({attrKey:li,fallback:()=>{var Q,ge;return((ge=(Q=O.value)==null?void 0:Q.frontmatter)==null?void 0:ge.mask)||""}}),Se=ce.resolvePageAttr({attrKey:Ko,fallback:()=>{var Q,ge;return((ge=(Q=O.value)==null?void 0:Q.frontmatter)==null?void 0:ge.maskRatio)||""}}),Ie=ce.resolvePageAttr({attrKey:ai,fallback:()=>{var Q,ge;return((ge=(Q=O.value)==null?void 0:Q.frontmatter)==null?void 0:ge.maskStyle)||"solid"}}),ve=ce.resolvePageAttr({attrKey:ci,fallback:()=>{var Q,ge;return((ge=(Q=O.value)==null?void 0:Q.frontmatter)==null?void 0:ge.maskInitial)||"hidden"}});function _e(Q){if(!Q||(Q.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Be=Array.from(Q.querySelectorAll(":scope > [data-node-id]"));if(Be.length<2)return null;const We=Be.length,Ue=Be.map(Co=>{const it=Co.getAttribute("style")||"",ei=it.match(/calc\(\s*([\d.]+)%/);if(ei)return parseFloat(ei[1]);const Ci=it.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return Ci?parseFloat(Ci[1]):null});let Re="",bt=!1;if(Ue.some(Co=>Co!==null)){bt=!0;const Co=Ue.reduce((Ne,vt)=>Ne+(vt||0),0),it=Ue.filter(Ne=>Ne===null).length,ei=it>0?Math.max(0,100-Co)/it:100/Be.length,Ci=Ue.map(Ne=>Ne!==null?Ne:ei),hd=Ci.reduce((Ne,vt)=>Ne+vt,0)||1,Ii=Ci.map(Ne=>Ne/hd*100);if(Ii.length===2){const[Ne]=Ii;if(Ne>=48&&Ne<=52)Re="1:1";else if(Ne>=31&&Ne<=35)Re="1:2";else if(Ne>=65&&Ne<=69)Re="2:1";else if(Ne>=28&&Ne<=32)Re="3:7";else if(Ne>=68&&Ne<=72)Re="7:3";else if(Ne>=38&&Ne<=42)Re="4:6";else if(Ne>=58&&Ne<=62)Re="6:4";else{const vt=Math.round(Ne);Re=`${vt}:${100-vt}`}}else if(Ii.length===3){const[Ne,vt,Io]=Ii;if(Ne>=31&&Ne<=35&&vt>=31&&vt<=35&&Io>=31&&Io<=35)Re="1:1:1";else if(Ne>=23&&Ne<=27&&vt>=48&&vt<=52&&Io>=23&&Io<=27)Re="1:2:1";else if(Ne>=48&&Ne<=52&&vt>=23&&vt<=27&&Io>=23&&Io<=27)Re="2:1:1";else if(Ne>=23&&Ne<=27&&vt>=23&&vt<=27&&Io>=48&&Io<=52)Re="1:1:2";else{const xr=Math.round(Ne),Sr=Math.round(vt);Re=`${xr}:${Sr}:${100-xr-Sr}`}}else Re=Ii.map(Ne=>Math.round(Ne)).join(":")}else bt=!1,Re=Array.from({length:We},()=>1).join(":");const sn=We>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:We,ratio:Re,isCustomWidth:bt,recommendedLayout:sn}}function P(Q){if(!(Q!=null&&Q.blocks))return null;for(const ge of Q.blocks){const Be=ge.rawNode;if(Be&&ut(Be)&&io(Be)){const Ue=Si(Be).length,Re=hr(Be);return{hasSuperBlock:!0,colCount:Ue,ratio:Re||Array.from({length:Ue},()=>1).join(":"),isCustomWidth:!!Re,recommendedLayout:Ue>=2?"cols-header":"two-cols"}}}return null}const ie=ye(()=>{var Q;if(typeof document<"u"){const ge=s.value;if(ge){const We=document.querySelector(`.protyle-wysiwyg [data-node-id="${ge}"]`);if(We){const Ue=We.getAttribute("data-type")==="NodeSuperBlock"?We:We.closest('[data-type="NodeSuperBlock"]');if(Ue){const Re=_e(Ue);if(Re)return Re}}}const Be=h.value||(_.value?s.value:"");if(Be){const We=document.querySelector(`.protyle-wysiwyg [data-node-id="${Be}"]`);if(We){let Ue=We.nextElementSibling;for(;Ue&&!(Ue.getAttribute("data-type")==="NodeThematicBreak"||(Q=Ue.classList)!=null&&Q.contains("protyle-wysiwyg__block--hr"));){const Re=Ue.getAttribute("data-type")==="NodeSuperBlock"?Ue:Ue.querySelector('[data-type="NodeSuperBlock"]');if(Re){const bt=_e(Re);if(bt)return bt}Ue=Ue.nextElementSibling}}}else{const We=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Ue=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Re of Ue)if(!We||Re.compareDocumentPosition(We)&Node.DOCUMENT_POSITION_FOLLOWING){const bt=_e(Re);if(bt)return bt}}}return P(O.value)}),E=ye(()=>{var Q;return((Q=ie.value)==null?void 0:Q.ratio)||""}),F=ye(()=>{const Q=l.value||"";if(Q==="NodeSuperBlock"||Q==="s"||Q==="sb")return!0;if(typeof document<"u"&&s.value){const ge=document.querySelector(`.protyle-wysiwyg [data-node-id="${s.value}"]`);if(ge!=null&&ge.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),v=ye(()=>{var Q;return((Q=O.value)==null?void 0:Q.pageIndex)||1}),U=ye(()=>!!r.value[Ve]);function R(){if(!d.value)return!1;if(s.value===d.value||typeof document>"u")return!0;const Q=document.querySelector(`.protyle-wysiwyg [data-node-id="${d.value}"]`)||document.querySelector(`[data-node-id="${d.value}"]`);if(!Q)return!1;const ge=Q.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(ge==null?void 0:ge.getAttribute("data-node-id"))===s.value}const S=ye(()=>{var ge;if(r.value[Oe]!==void 0)return r.value[Oe]||"";if(d.value&&R())return p.value||"";if(d.value)return"";const Q=s.value;if(Q&&((ge=O.value)!=null&&ge.blocks)){const Be=O.value.blocks.find(We=>We.id===Q);if(Be!=null&&Be.clicks)return Be.clicks}return""}),C=ye(()=>{var ge;if(r.value[At])return r.value[At];const Q=s.value;if(Q&&((ge=O.value)!=null&&ge.blocks)){const Be=O.value.blocks.find(We=>We.id===Q);if(Be!=null&&Be.motion)return typeof Be.motion=="string"?Be.motion:JSON.stringify(Be.motion)}return""}),L=ye(()=>{var ge;if(r.value[Ae])return r.value[Ae];const Q=s.value;if(Q&&((ge=O.value)!=null&&ge.blocks)){const Be=O.value.blocks.find(We=>We.id===Q);if(Be!=null&&Be.slot)return Be.slot}return""}),G=pe(""),q=pe(""),Y=ye(()=>r.value[Vo]==="true"),X=ye(()=>r.value[_n]==="true"),ae=ye(()=>r.value[si]==="true"),ne=ye(()=>r.value[Cn]!=="false"),me=ye(()=>{var Q,ge;return((ge=(Q=g.value)==null?void 0:Q.config)==null?void 0:ge.theme)||r.value[Wi]||"apple-basic"}),Ce=ye(()=>{var Q,ge;return((ge=(Q=g.value)==null?void 0:Q.config)==null?void 0:ge.aspectRatio)||r.value[Ui]||"16/9"}),we=ye(()=>{var Q,ge;return((ge=(Q=g.value)==null?void 0:Q.config)==null?void 0:ge.defaultTransition)||r.value[Vi]||"slide-left"}),Le=ye(()=>{var Q,ge;return((ge=(Q=g.value)==null?void 0:Q.config)==null?void 0:ge.spacing)||r.value[Ss]||"normal"}),He=ye(()=>{var Q,ge;return((ge=(Q=g.value)==null?void 0:Q.config)==null?void 0:ge.background)||r.value[Sn]||""}),Ge=ye(()=>{var Ue,Re;if((r.value[Ye]||r.value["slides-role"])===Nl||r.value[ct]==="true")return"background";const ge=r.value[be]||r.value["slides-layout"];if(ge==="image-left"||ge==="image-right")return ge;const Be=a.value||"",We=bo(Be);if(We&&((Re=(Ue=O.value)==null?void 0:Ue.frontmatter)!=null&&Re.background)){const bt=O.value.frontmatter.background;if(bt===We||bt.endsWith(We)||We.endsWith(bt))return"background"}return""}),rt=ye(()=>!!(r.value[Oe]||r.value[At]||r.value[Ae]||r.value[Xo]||r.value[Ve]||r.value["slides-note"]||r.value[Ye]||r.value[be]||r.value[Vo]||r.value[_n]||r.value[si]||r.value[Cn])),{saveAttr:Pe,savePageAttr:ft,applyPageLayoutAndRatio:tt,applyCloverLayout:Ke,resetSuperBlockWidth:ue,saveDocAttr:fe,onToggleVideoAutoplay:Qe,onToggleVideoLoop:lt,onToggleVideoMuted:_t,onToggleVideoControls:at,onImageRoleChange:ro,onToggleNoteBlock:$c,onAddNoteBlock:Ac,onLocateNoteBlock:Tc,onGenerateNotesWithAI:Mc,isBatchProcessing:Bc,onBatchDeleteNotes:Ec,onAddOrIdentifyNotesBlocks:Dc,onAutoAnimateDocument:Lc,onClearAnimationsDocument:Oc,toggleElemClick:Nc,onElemClickStepChange:Pc,onElemMotionChange:Rc,onElemSlotChange:zc,onElemShikiLinesChange:Hc,onElemMaxHeightChange:Fc,onSetTwoColsContrast:jc,onClearBlockAttrs:Wc,onInsertDividerBefore:Uc,onInsertDividerAfter:br,onDeleteCurrentBlock:Vc,onConvertToSuperBlock:vr,onExportHtml:qc,onExportPdf:Gc}=_w({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:h,currentPageDividerLayout:y,parentContainerId:d,parentContainerClicks:p,latestDoc:g,targetSlide:O,currentSlideNoteBlockId:K,currentSlideLayout:Z,isNoteBlock:U,elemClick:S,videoAutoplay:Y,videoLoop:X,videoMuted:ae,videoControls:ne,pageBackground:W,pageImage:$,elemShikiLines:G,elemMaxHeight:q,saveStatus:b,plugin:o}),Xn=pe(!1);function _o(){Xn.value=lw(s.value,l.value)}Qo(()=>{typeof document<"u"&&(document.addEventListener("selectionchange",_o),document.addEventListener("mouseup",_o),document.addEventListener("keyup",_o)),_o()}),tn(()=>{typeof document<"u"&&(document.removeEventListener("selectionchange",_o),document.removeEventListener("mouseup",_o),document.removeEventListener("keyup",_o))}),Po([s,l],()=>{_o()});async function Kc(Q){if(Q==="clover"){if(!await Ke())return}else ft(be,Q)}function Yc(Q){ft(mt,Q)}async function Zc(Q){await ft(li,Q),(Q==="clockwise"||Q==="counter-clockwise"||Q==="cw"||Q==="ccw")&&(!Se.value||Se.value==="1:1")&&await ft(Ko,"1:1:1:1")}function Jc(Q){ft(Ko,Q)}function Xc(Q){ft(ai,Q)}function Qc(Q){ft(ci,Q)}function kr(Q){if(!Q)return;const ge=Q.recommendedLayout||(Q.colCount&&Q.colCount>=2?"cols-header":"two-cols"),Be=Q.ratio||(Q.colCount?Array(Q.colCount).fill(1).join(":"):"1:1");tt(ge,Be)}function ed(Q){ft(mt,Q)}async function td(){await ue()}function od(Q){Pe(wt,Q)}function id(Q){$.value=Q,Pe(Ft,Q)}function nd(Q){Pe(Di,Q==="inherit"?"":Q)}function sd(Q){fe(Wi,Q)}function rd(Q){fe(Sn,Q)}function ld(Q){fe(Ui,Q)}function ad(Q){fe(Vi,Q)}function cd(Q){fe(Ss,Q)}function wr(){o!=null&&o.openBottomPreviewTab&&o.openBottomPreviewTab()}function dd(){o!=null&&o.openPresenterTab&&o.openPresenterTab()}function ud(){o&&Dt("aiScript")&&wc(o)}function fd(){o&&Dt("aiScript")&&xc(o)}return t({setActiveBlock(Q){s.value=Q.id,l.value=Q.type,r.value={...Q.attrs},a.value=Q.content||Q.markdown||"",u.value=Q.topBlockId||Q.id,h.value=Q.pageDividerId||"",y.value=Q.pageDividerLayout||"",d.value=Q.parentContainerId||"",f.value=Q.parentContainerSlot||"",p.value=Q.parentContainerClicks||"",Q.rootId?c.value=Q.rootId:(Q.type==="doc"||Q.type==="NodeDocument")&&Q.id&&(c.value=Q.id),W.value=Q.attrs[ct]||"",$.value=Q.attrs[Ft]||"",G.value=Q.attrs[Xo]||"",q.value=Q.attrs[qi]||"",A.value=!!Q.isImage},updateDocument(Q){g.value=Q,c.value=Q.docId},openImportDialog(){i.value=!0},setCurrentDocId(Q){c.value=Q}}),(Q,ge)=>(J(),ee("div",Aw,[m("div",Tw,[m("div",Mw,[(J(),ee("svg",Bw,[...ge[2]||(ge[2]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),ge[3]||(ge[3]=m("span",null,"演示配置",-1))]),m("div",Ew,[he(Dt)("import")?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:ge[0]||(ge[0]=Be=>i.value=!0)},[se(de,{name:"import"}),ge[4]||(ge[4]=m("span",null,"导入",-1))])):Te("",!0),m("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__sw","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:wr},[se(de,{name:"split-preview"}),ge[5]||(ge[5]=m("span",null,"分屏预览",-1))])])]),m("div",Dw,[m("div",Lw,[m("span",{class:xe(["spm-target-tag",D.value])},ke(B.value),3),m("span",{class:"spm-target-id b3-tooltips b3-tooltips__se","aria-label":k.value||"点击复制 ID: "+(s.value||c.value),onClick:w},[se(de,{name:"copy"}),m("span",null,"#"+ke(z.value),1)],8,Ow)]),b.value?(J(),ee("span",Nw,"● "+ke(b.value),1)):Te("",!0)]),j.value?(J(),ee("div",{key:0,class:"spm-context-quote",title:a.value},ke(j.value),9,Pw)):Te("",!0),m("div",Rw,[_.value?(J(),to(dv,{key:0,"page-layout":x.value,"page-layout-ratio":he(oe),"page-mask":he(re),"page-mask-ratio":he(Se),"page-mask-style":he(Ie),"page-mask-initial":he(ve),"detected-sb-ratio":E.value,"detected-sb-info":ie.value,"page-transition":V.value,"page-spacing":T.value,"page-image":$.value,"page-notes":te.value,"page-index":v.value,"can-convert-to-super-block":Xn.value,"onUpdate:pageLayout":Kc,"onUpdate:pageLayoutRatio":Yc,"onUpdate:pageMask":Zc,"onUpdate:pageMaskRatio":Jc,"onUpdate:pageMaskStyle":Xc,"onUpdate:pageMaskInitial":Qc,onApplySuperBlockLayout:kr,onResetSuperblockRatio:td,"onUpdate:pageTransition":od,"onUpdate:pageSpacing":nd,"onUpdate:pageImage":id,onAddNoteBlock:he(Ac),onLocateNoteBlock:he(Tc),onGenerateNotes:he(Mc),onInsertDividerAfter:he(br),onDeleteDivider:he(Vc),onConvertToSuperBlock:he(vr)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-spacing","page-image","page-notes","page-index","can-convert-to-super-block","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onInsertDividerAfter","onDeleteDivider","onConvertToSuperBlock"])):s.value&&!H.value?(J(),to(W1,{key:1,"elem-click":S.value,"elem-motion":C.value,"elem-slot":L.value,"elem-shiki-lines":G.value,"elem-max-height":q.value,"is-code-block":M.value,"is-image":I.value,"is-video":N.value,"is-super-block":F.value,"detected-sb-info":ie.value,"video-autoplay":Y.value,"video-loop":X.value,"video-muted":ae.value,"video-controls":ne.value,"has-block-attrs":rt.value,"is-note":U.value,"image-role":Ge.value,"current-slide-layout":Z.value,"parent-elem-click":p.value,"parent-container-slot":f.value,"parent-container-id":d.value,"can-convert-to-super-block":Xn.value,onToggleNote:he($c),onToggleElemClick:he(Nc),onToggleVideoAutoplay:he(Qe),onToggleVideoLoop:he(lt),onToggleVideoMuted:he(_t),onToggleVideoControls:he(at),"onUpdate:imageRole":he(ro),"onUpdate:elemClick":he(Pc),"onUpdate:elemMotion":he(Rc),"onUpdate:elemSlot":he(zc),"onUpdate:elemShikiLines":he(Hc),"onUpdate:elemMaxHeight":he(Fc),onApplySuperBlockLayout:kr,onApplySuperBlockRatio:ed,onInsertDividerBefore:he(Uc),onInsertDividerAfter:he(br),onSetTwoColsContrast:he(jc),onClearBlockAttrs:he(Wc),onConvertToSuperBlock:he(vr)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","can-convert-to-super-block","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs","onConvertToSuperBlock"])):(J(),to(ik,{key:2,"doc-theme":me.value,"doc-background":He.value,"doc-aspect-ratio":Ce.value,"doc-default-transition":we.value,"doc-spacing":Le.value,"is-batch-processing":he(Bc),"onUpdate:docTheme":sd,"onUpdate:docBackground":rd,"onUpdate:docAspectRatio":ld,"onUpdate:docDefaultTransition":ad,"onUpdate:docSpacing":cd,onOpenBottomPreview:wr,onOpenPresenter:dd,onAddOrIdentifyNotes:he(Dc),onClearNotes:he(Ec),onAutoAnimate:he(Lc),onClearAnimations:he(Oc),onAiAutoSplit:ud,onClearDividers:fd,onExportHtml:he(qc),onExportPdf:he(Gc)},null,8,["doc-theme","doc-background","doc-aspect-ratio","doc-default-transition","doc-spacing","is-batch-processing","onAddOrIdentifyNotes","onClearNotes","onAutoAnimate","onClearAnimations","onExportHtml","onExportPdf"]))]),i.value&&he(Dt)("import")?(J(),to(sw,{key:1,onClose:ge[1]||(ge[1]=Be=>i.value=!1),onSuccess:n})):Te("",!0)]))}}),Hw=2e3,Fw=600;function jw(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function bs(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(Al(e))return!0;const t=e.firstElementChild;return!!(t&&Al(t))}function Al(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function Ww(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class Uw{constructor(){$e(this,"consumers",new Map);$e(this,"seq",0);$e(this,"verifyTimer",null)}register(t,o,i){if(!o)return()=>{};const n=++this.seq,s=Ww(),l={kind:t,element:o,visible:!1,measureOnDemand:!s,observer:null,onVisible:i};return s?(l.observer=new s(r=>{var u;const a=r[r.length-1];if(!a)return;const c=a.isIntersecting&&!l.visible;l.visible=a.isIntersecting,c&&((u=l.onVisible)==null||u.call(l))}),l.observer.observe(o)):l.visible=bs(o),this.consumers.set(n,l),()=>{var r;(r=l.observer)==null||r.disconnect(),this.consumers.delete(n),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const o of this.consumers.values())(t=o.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?bs(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!jw(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const o of this.consumers.values())if(!o.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var o;this.verifyTimer=null;for(const i of this.consumers.values())if(!i.visible&&bs(i.element)){i.visible=!0,(o=i.onVisible)==null||o.call(i);return}},Hw))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const kn=new Uw,_i=new Jn;function Sc(e,t,o){const i=()=>{var s;try{(s=o==null?void 0:o.flushDirtyCompile)==null||s.call(o)}catch{}},n=kn.register(e,t,i);return i(),n}let Eo=null,Rt=null,wn=null;function Vw(){return Rt}function qw(e,t){Eo&&_c(),Eo=ur(Lg),Eo.provide("plugin",t),Eo.provide("sandboxBridge",_i);const o=Eo.mount(e);return Rt=o,wn=Sc("preview",e,t),o}function _c(e){wn&&(wn(),wn=null),Eo&&(Eo.unmount(),Eo=null,Rt=null)}function Gw(){return Rt!==null}let Do=null,Go=null;function Kw(e,t){return Do&&Cc(),Do=ur(Uy),Do.provide("plugin",t),Do.provide("sandboxBridge",_i),Go=Do.mount(e),Go}function Cc(e){Do&&(Do.unmount(),Do=null,Go=null)}function Yw(e){var t;try{const o=new BroadcastChannel("siyuan-slides-sync");o.postMessage({type:"SYNC_SLIDES",slides:e.slides||[],config:{...e.config||{},hostThemeMode:((t=e.config)==null?void 0:t.hostThemeMode)||zo()}}),o.close()}catch{}}let Lo=null,Lt=null,xn=null;function Zw(e,t){Lo&&Ic(),Lo=ur(zw),Lo.provide("plugin",t),Lo.provide("sandboxBridge",_i);const o=Lo.mount(e);return Lt=o,xn=Sc("dock",e,t),o}function Ic(e){xn&&(xn(),xn=null),Lo&&(Lo.unmount(),Lo=null,Lt=null)}function Jw(e,t){Lt!=null&&Lt.updateDocument&&Lt.updateDocument(e),Rt!=null&&Rt.updateDocument?Rt.updateDocument(e,t):(_i.updateSlides(e.slides,e.config),Yw(e)),Go!=null&&Go.updateDocument&&Go.updateDocument(e)}function Us(e){Rt!=null&&Rt.navigateToBlock?Rt.navigateToBlock(e):_i.highlightElement(e)}function ni(e){Lt!=null&&Lt.setActiveBlock&&Lt.setActiveBlock(e)}function Xw(){return Bo("import")?!1:Lt!=null&&Lt.openImportDialog?(Lt.openImportDialog(),!0):!1}const Qw=[{id:"slides-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:fo,value:"true"},{key:be,value:"cover"},{key:wt,value:"fade"}]},{id:"slides-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:fo,value:"true"},{key:be,value:"two-cols"},{key:wt,value:"slide-left"}]},{id:"slides-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:fo,value:"true"},{key:be,value:"fact"},{key:wt,value:"zoom"}]},{id:"slides-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:fo,value:"true"},{key:be,value:"intro"},{key:wt,value:"slide-up"}]},{id:"slides-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:fo,value:"true"},{key:be,value:"quote"},{key:wt,value:"fade"}]},{id:"slides-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Oe,value:"+1"}]},{id:"slides-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Oe,value:"hide"}]},{id:"slides-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Ae,value:"right"}]},{id:"slides-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Xo,value:"1-3"}]}];class vs{getPresetTemplates(){return Qw}buildScanSlidesBlocksSql(t="custom-slides-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${wt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,o,i,n){const s=`SELECT block_id FROM attributes WHERE name = '${wt}' AND value = '${t}'`,l=await i(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{[wt]:o}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,o,i,n){const s=`SELECT block_id FROM attributes WHERE name = '${be}' AND value = '${t}'`,l=await i(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{[be]:o}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置即现转场效果的块":`全库即现转场分布统计：${t.map(i=>`${i.value}: ${i.count} 个`).join("，")}`}}function e2(e){if(e.addCommand({langKey:"slidesPresentation",langText:"即现: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),Bo("import")||e.addCommand({langKey:"slidesImport",langText:"即现: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{Xw()||le.showMessage("请先在右侧栏打开「即现演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidesInitAttrs",langText:"即现: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await ze(e.currentDocId,{"custom-slides-theme":"default","custom-slides-aspect-ratio":"16/9","custom-slides-default-transition":"slide-left"}),le.showMessage("已为当前文档初始化即现演示属性"),e.compileCurrentDocument(e.currentDocId))}}),Bo("aiScript")||(e.addCommand({langKey:"slidesAiSplit",langText:"即现: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:()=>wc(e)}),e.addCommand({langKey:"slidesClearDividers",langText:"即现: 清除当前文档分页线",hotkey:"",enabled:()=>!0,execute:()=>xc(e)})),Bo("aiScript")||e.addCommand({langKey:"slidesAiNotes",langText:"即现 AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,u,h;if(!e.currentDocId){const y=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(y==null?void 0:y.getAttribute("data-doc-id"))||""}if(!e.currentDocId){le.showMessage("请先打开一篇思源笔记文档");return}le.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await ki(e.currentDocId).catch(()=>[]),o={startBlockId:e.currentDocId,blocks:t.map(y=>({id:y.id,type:y.type,content:y.content||"",rawMarkdown:y.markdown||""})),rawMarkdown:""},s=`> [!NOTE] 💡 演讲备注
${(await fw(o,El)).split(/\r?\n/).map(y=>`> ${y}`).join(`
`)}
{: custom-slides-note="true"}`,l=await ws("markdown",s,e.currentDocId).catch(()=>null),r=((u=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:u.id)||((h=l==null?void 0:l[0])==null?void 0:h.id);r&&(await ze(r,{"custom-slides-note":"true"}),Ee.setBlockAttrOverride(r,{"custom-slides-note":"true"}),Jo(r,e.app)),le.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidesIdentifyNotes",langText:"即现演示: 识别正文讲稿块并规范化",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const o=document.querySelector(".protyle-content[data-doc-id]");t=(o==null?void 0:o.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){le.showMessage("请先在主编辑区打开幻灯片文档");return}await vc(t,{compileFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesAutoAnimate",langText:"即现演示: 智能配置演示动效",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const o=document.querySelector(".protyle-content[data-doc-id]");t=(o==null?void 0:o.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){le.showMessage("请先在主编辑区打开幻灯片文档");return}await kc(t,{compileCurrentDocFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesBatchTransitions",langText:"即现协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new vs,o=t.buildTransitionStatsSql(),i=await gi(o).catch(()=>[]),n=t.formatTransitionSummary(i||[]);le.showMessage(n)}}),e.addCommand({langKey:"slidesExportTemplates",langText:"即现协同: 复制即现预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const o=new vs().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(o),le.showMessage("已将即现属性模板 JSON 复制至剪贴板，可直接导入属性管家")):le.showMessage(`已生成模板数据（请在控制台查看）：
`+o)}}),e.addCommand({langKey:"slidesBatchReplaceTransition",langText:"即现协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const o=await new vs().batchUpdateTransitions("fade","slide-left",i=>gi(i).catch(()=>[]),(i,n)=>ze(i,n));le.showMessage(`全库批量替换完成：已将 ${o.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),Bo("presenterMode")||e.addCommand({langKey:"slidesPresenterMode",langText:"即现: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),!Bo("exportImage")){let t=!1;e.addCommand({langKey:"slidesExportImagesZip",langText:"即现: 逐页导出幻灯片为高清图片包 (ZIP)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t){le.showMessage("正在导出图片中，请稍候...",2e3);return}if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){le.showMessage("请先打开并放映一篇思源笔记文档");return}t=!0;try{le.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const o=e.latestCompiledDoc,i=await No(o,e.currentDocId,e),n=await cc(o,{title:i,onProgress:(s,l)=>{le.showMessage(`正在导出幻灯片图片 (${s} / ${l})...`,2e3)}});n.success?le.showMessage(`🎉 成功导出 ${n.total||0} 张幻灯片高清图片并已保存为 ${i}.zip！`,4e3):le.showMessage(`导出图片失败：${n.error||"未知异常"}`)}finally{t=!1}}})}}class t2{constructor(t=400){$e(this,"entries",new Map);this.ttlMs=t}get(t,o=Date.now()){if(!t)return;const i=this.entries.get(t);if(i){if(o-i.at>this.ttlMs){this.entries.delete(t);return}return i.attrs}}set(t,o,i=Date.now()){!t||!o||this.entries.set(t,{attrs:o,at:i})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function o2(e){const t=new Map;if(!(e!=null&&e.slides))return t;const o=i=>{for(const n of i||[])n!=null&&n.id&&n.ial&&t.set(n.id,n.ial)};for(const i of e.slides)o(i.blocks),o(i.noteBlocks);return t}class i2{constructor(t=150){$e(this,"lastBlockId","");$e(this,"lastAt",0);this.windowMs=t}shouldSkip(t,o=Date.now()){return t&&t===this.lastBlockId&&o-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=o,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class n2{constructor(){$e(this,"attrCache",new t2);$e(this,"compiledIalIndex",{doc:null,map:new Map});$e(this,"locatingLockUntil",0);$e(this,"lockedTargetBlockId","");$e(this,"lastKnownPageDividerId","");$e(this,"lastKnownDocId","")}isLocatingLocked(t){return Date.now()<this.locatingLockUntil?!(t&&t===this.lockedTargetBlockId):!1}async resolveBlockAttrs(t,o){if(!t)return{};const i=Ee.getBlockAttrOverride(t),n=this.getCompiledIal(o,t);if(i||n)return{...n||{},...i||{}};const s=this.attrCache.get(t);if(s)return s;const l=await qs(t).catch(()=>({}))||{};return this.attrCache.set(t,l),l}getCompiledIal(t,o){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:o2(t)}),this.compiledIalIndex.map.get(o)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),o=t==null?void 0:t.getAttribute("data-node-id");if(o)return o;const i=document.querySelector(".protyle .protyle-title[data-node-id]"),n=i==null?void 0:i.getAttribute("data-node-id");if(n)return n;const s=document.querySelector("[data-doc-id]"),l=s==null?void 0:s.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(t,o=""){const i=t.closest(".protyle-title"),n=i==null?void 0:i.getAttribute("data-node-id");if(n)return n;const s=t.closest(".protyle"),l=s==null?void 0:s.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=t.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const u=this.getActiveDocumentId();return u||o}async switchToDocGlobalInspector(t,o){var s;if(!t)return;let i=o||"";if(!i&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");i=((s=l==null?void 0:l.innerText)==null?void 0:s.trim())||""}const n=await this.resolveBlockAttrs(t,null);ni({id:t,rootId:t,type:"doc",content:i,attrs:n,isDivider:!1,isCode:!1}),Us(t)}handleBlockClickedFromSlide(t,o,i,n,s){var c,u,h,y;if(!t){ji();const d=typeof s=="number"&&s>0?s:1,f=((c=n==null?void 0:n.slides)==null?void 0:c[d-1])||((u=n==null?void 0:n.slides)==null?void 0:u[0]);if(f){const p=f.startBlockId||"",g=((h=f.frontmatter)==null?void 0:h.layout)||"",b={"custom-slides-layout":g,...f.frontmatter};return ni({id:p,rootId:i,type:"NodeThematicBreak",attrs:b,isDivider:!0,isCode:!1,isImage:!1,pageDividerId:p,pageDividerLayout:g}),this.resolveBlockAttrs(p,n).then(k=>{k&&Object.keys(k).length>0&&ni({id:p,rootId:i,type:"NodeThematicBreak",attrs:{...b,...k},isDivider:!0,isCode:!1,isImage:!1,pageDividerId:p,pageDividerLayout:g})}),!0}else return this.switchToDocGlobalInspector(i),!0}this.lockedTargetBlockId=t,this.locatingLockUntil=Date.now()+500;const l=Jo(t,o),r=typeof document<"u"?document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`):null,a=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,t,a,i,n);else{let d="",f="";if(n!=null&&n.slides){const p=n.slides.find(g=>{var b,k,w;return g.startBlockId===t||((b=g.blocks)==null?void 0:b.some(_=>_.id===t))||((k=g.allBlockIds)==null?void 0:k.includes(t))||((w=g.noteBlocks)==null?void 0:w.some(_=>_.id===t))});p!=null&&p.startBlockId&&(d=p.startBlockId),(y=p==null?void 0:p.frontmatter)!=null&&y.layout&&(f=p.frontmatter.layout)}this.resolveBlockAttrs(t,n).then(async p=>{if(d&&!f){const g=Ee.getBlockAttrOverride(d);if(g!=null&&g[be]||g!=null&&g["custom-slides-layout"])f=g[be]||g["custom-slides-layout"]||"";else{const b=await this.resolveBlockAttrs(d,n);f=b[be]||b["custom-slides-layout"]||"",b&&Object.keys(b).length>0&&Ee.setBlockAttrOverride(d,b)}}ni({id:t,rootId:i,type:a||"NodeParagraph",attrs:p||{},pageDividerId:d,pageDividerLayout:f})}).catch(()=>{})}return l}async syncInspectorBlock(t,o,i,n,s){var V,W,$,T,O,te,K,Z,ce;if(this.isLocatingLocked(o))return;let l=t,r=o,a=i;const c=typeof(t==null?void 0:t.closest)=="function"?t.closest('[data-type="NodeCallout"]'):null;if(c&&c!==t){const oe=c.getAttribute("data-node-id");if(oe){const re=await this.resolveBlockAttrs(oe,s),Se=Ee.getBlockAttrOverride(oe)||{};({...re,...Se})[Ve]&&(l=c,r=oe,a="NodeCallout")}}const u=l.closest(".protyle-wysiwyg > [data-node-id]")||l,h=(u==null?void 0:u.getAttribute("data-node-id"))||r,y=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(u==null?void 0:u.getAttribute("data-type"))==="NodeThematicBreak"||(u==null?void 0:u.getAttribute("data-type"))==="tb"||!!((V=u==null?void 0:u.classList)!=null&&V.contains("hr")),d=a==="NodeCodeBlock",f=((W=l.innerText)==null?void 0:W.trim())||"",p=await this.resolveBlockAttrs(r,s),g=Ee.getBlockAttrOverride(r)||{},b={...p,...g};let k="",w="";if(y)k=r,w=b[be]||b["custom-slides-layout"]||"";else{let oe=u.previousElementSibling;for(;oe;){const re=oe.getAttribute("data-type");if(re==="NodeThematicBreak"||re==="tb"||($=oe.classList)!=null&&$.contains("hr")){k=oe.getAttribute("data-node-id")||"";break}oe=oe.previousElementSibling}}if(s!=null&&s.slides){const oe=[r,h];let re=l.parentElement;for(;re&&!re.classList.contains("protyle-wysiwyg");){const Ie=re.getAttribute("data-node-id");Ie&&!oe.includes(Ie)&&oe.push(Ie),re=re.parentElement}const Se=s.slides.find(Ie=>{var ve,_e,P;return oe.includes(Ie.startBlockId)||((ve=Ie.blocks)==null?void 0:ve.some(ie=>oe.includes(ie.id)))||((_e=Ie.allBlockIds)==null?void 0:_e.some(ie=>oe.includes(ie)))||((P=Ie.noteBlocks)==null?void 0:P.some(ie=>oe.includes(ie.id)))});Se&&(!k&&Se.startBlockId&&(k=Se.startBlockId),!w&&((T=Se.frontmatter)!=null&&T.layout)&&(w=Se.frontmatter.layout))}if(k?(this.lastKnownDocId=n,this.lastKnownPageDividerId=k):n&&this.lastKnownDocId===n&&this.lastKnownPageDividerId&&(!u.previousElementSibling&&(((O=u.parentElement)==null?void 0:O.scrollTop)||0)===0||(k=this.lastKnownPageDividerId)),k){const oe=Ee.getBlockAttrOverride(k);if(oe&&(be in oe||"custom-slides-layout"in oe)&&(w=oe[be]||oe["custom-slides-layout"]||""),!w&&(s!=null&&s.slides)){const re=s.slides.find(Se=>Se.startBlockId===k);(te=re==null?void 0:re.frontmatter)!=null&&te.layout&&(w=re.frontmatter.layout)}if(!w){const re=await this.resolveBlockAttrs(k,s);w=re[be]||re["custom-slides-layout"]||"",re&&Object.keys(re).length>0&&Ee.setBlockAttrOverride(k,re)}et(k,{[be]:w||""})}else if(n){const oe=Ee.getBlockAttrOverride(n);oe&&(be in oe||"custom-slides-layout"in oe)?w=oe[be]||oe["custom-slides-layout"]||"":!w&&((ce=(Z=(K=s==null?void 0:s.slides)==null?void 0:K[0])==null?void 0:Z.frontmatter)!=null&&ce.layout)&&(w=s.slides[0].frontmatter.layout)}const _=l.getAttribute(be)||l.getAttribute("custom-slides-layout"),M=b[be]||b["custom-slides-layout"]||"";_&&_!==M&&et(r,{[be]:M});const A=l.getAttribute(Ye)||l.getAttribute("custom-slides-role"),I=b[Ye]||b["custom-slides-role"]||"";A&&A!==I&&et(r,{[Ye]:I});let N="",H="",z="";const j=l.closest('[data-type="NodeListItem"]');if(j&&j!==l){const oe=j.getAttribute("data-node-id");if(oe){N=oe;const re=await this.resolveBlockAttrs(oe,s),Se=Ee.getBlockAttrOverride(oe)||{},Ie={...re,...Se};H=Ie[Ae]||"",z=Ie[Oe]||"";const ve=Ie[be]||Ie["custom-slides-layout"]||"",_e=j.getAttribute(be)||j.getAttribute("custom-slides-layout");_e&&_e!==ve&&et(oe,{[be]:ve});const P=Ie[Ye]||Ie["custom-slides-role"]||"",ie=j.getAttribute(Ye)||j.getAttribute("custom-slides-role");ie&&ie!==P&&et(oe,{[Ye]:P})}}const B=!!l.querySelector("img, span[data-type='img']"),D=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),x=B&&D.length<=50;ni({id:r,rootId:n,type:a,content:f,attrs:b,isDivider:y,isCode:d,isImage:x,topBlockId:h,pageDividerId:k,pageDividerLayout:w,parentContainerId:N,parentContainerSlot:H,parentContainerClicks:z})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const o of t.data)if(Array.isArray(o==null?void 0:o.doOperations)){for(const i of o.doOperations)if((i==null?void 0:i.action)==="updateAttrs"&&i.id&&i.data){const n=i.data.old||{},s=i.data.new||{},l={};for(const r of Object.keys(n))r in s||(l[r]="");for(const[r,a]of Object.entries(s))l[r]=String(a??"");et(i.id,l),Ee.setBlockAttrOverride(i.id,l)}}}}purgeStaleDomSlidesAttrs(t){var n,s,l;if(typeof document>"u"||!t)return;const o=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const a=o.get(r.startBlockId)||{};(n=r.frontmatter)!=null&&n.layout&&(a[be]=r.frontmatter.layout),o.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=o.get(a.id)||{};(s=a.ial)!=null&&s[be]&&(c[be]=a.ial[be]),(l=a.ial)!=null&&l[Ye]&&(c[Ye]=a.ial[Ye]),Object.keys(c).length>0&&o.set(a.id,c)}}}const i=Ee.getAllAttrOverrides();for(const[r,a]of i.entries()){const c=o.get(r)||{};a[be]!==void 0&&(c[be]=a[be]),a[Ye]!==void 0&&(c[Ye]=a[Ye]),o.set(r,c)}cw(o)}}const Ao=new n2;class s2{constructor(){$e(this,"state","IDLE");$e(this,"inFlightDocId",null);$e(this,"pendingDocs",new Set);$e(this,"lastPendingDocId",null);$e(this,"generation",0)}get currentState(){return this.state}get isRunning(){return this.state==="COMPILING"}get runningDocId(){return this.inFlightDocId}get pending(){return this.lastPendingDocId}get pendingList(){return Array.from(this.pendingDocs)}tryBegin(t){return this.state==="COMPILING"||this.inFlightDocId!==null?(this.pendingDocs.add(t),this.lastPendingDocId=t,null):(this.state="COMPILING",this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finishBatch(){this.state="IDLE",this.inFlightDocId=null,this.lastPendingDocId=null;const t=Array.from(this.pendingDocs);return this.pendingDocs.clear(),t}finish(){const t=this.finishBatch();return t.length>0?t[t.length-1]:null}reset(){this.state="IDLE",this.inFlightDocId=null,this.pendingDocs.clear(),this.lastPendingDocId=null,this.generation=0}}const r2=150,l2=`<symbol id="iconSlides" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,a2="slides-dock",ks="slides-preview-tab",Tl="slides-presenter-tab",Ml=Jf;class c2 extends le.Plugin{constructor(){super(...arguments);$e(this,"isMobile",!1);$e(this,"currentDocId","");$e(this,"previewTab",null);$e(this,"latestCompiledDoc",null);$e(this,"debounceTimer",null);$e(this,"activeCursorBlockId","");$e(this,"cancelledCursorBlockId","");$e(this,"compileScheduler",new s2);$e(this,"dirtyDocId",null);$e(this,"inspectorSyncThrottle",new i2);$e(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));$e(this,"onWsMainBound",this.onWsMain.bind(this));$e(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));$e(this,"onEditorClickBound",this.onEditorClick.bind(this));$e(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));$e(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));$e(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const o=le.getFrontend();this.isMobile=o==="mobile"||o==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(l2),this.addTopBar({id:"slides-topbar-play",icon:"iconSlides",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),e2(this);const i=this;if(this.addTab({type:ks,init(n){var r;const s=this||n;i.previewTab=(s==null?void 0:s.tab)||null,qw(s.element,i);const l=(r=s==null?void 0:s.data)==null?void 0:r.docId;l&&!i.getActiveDocumentId()&&i.compileCurrentDocument(l,{reason:"explicit"}),i.updatePreviewTabHeader()},destroy(){i.previewTab===(this==null?void 0:this.tab)&&(i.previewTab=null),_c(this.element)}}),this.addTab({type:Tl,init(n){Kw((this||n).element,i)},destroy(){Cc(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlides",title:"即现演示配置"},data:{},type:a2,init(){Zw(this.element,i)},destroy(){Ic(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(n,s)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${n}`,{detail:s}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slides:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slides:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const n=()=>{const s=this.getActiveDocumentId();s&&(s!==this.currentDocId&&(this.currentDocId=s,this.updatePreviewTabHeader("",s)),this.latestCompiledDoc||this.markCompileDirty(s))};setTimeout(n,300),setTimeout(n,1e3)}}async onDataChanged(o){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const o=await this.loadData(Ml),i=Xf(o);return uo(i),i}catch{return uo(Oo),Oo}}async saveGlobalSettings(o){const i=Zn(),n=uo({...i,...o||{}});try{await this.saveData(Ml,n)}catch(l){console.error("保存即现全局配置失败",l)}const s=this.currentDocId||this.getActiveDocumentId();return s&&this.markCompileDirty(s),n}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,kn.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),_i.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const o=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",i=this.buildPreviewTabTitle(o);await le.openTab({app:this.app,custom:{id:this.name+ks,title:i,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(o,this.currentDocId)}async openPresenterTab(){Bo("presenterMode")||(Gw()||await this.openBottomPreviewTab(),await le.openTab({app:this.app,custom:{id:this.name+Tl,title:"演讲者控制台",icon:"iconSlides",data:{}},position:"right"}))}async openStandalonePreviewWindow(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),this.currentDocId&&!this.latestCompiledDoc&&await this.compileCurrentDocument(this.currentDocId,{reason:"explicit"});const o=le.getFrontend();if(o==="browser-desktop"||o==="browser-mobile"){typeof window<"u"&&typeof window.open=="function"&&window.open("/plugins/siyuan-live-slides/slides-client/index.html","SlidesBigScreenWindow","width=1280,height=760,menubar=no,toolbar=no,location=no,status=no");return}let i=this.previewTab;if(!i){const n=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",s=this.buildPreviewTabTitle(n),l=await le.openTab({app:this.app,custom:{id:this.name+ks,title:s,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"});i=this.previewTab||l}i&&(this.currentDocId&&i.model&&(i.model.data={...i.model.data||{},docId:this.currentDocId}),le.openWindow({tab:i,width:1280,height:760}))}async onSwitchProtyle(o){var l,r,a,c,u;const i=(l=o.detail)==null?void 0:l.protyle,n=(r=i==null?void 0:i.block)==null?void 0:r.rootID,s=((u=(c=(a=i==null?void 0:i.title)==null?void 0:a.editElement)==null?void 0:c.textContent)==null?void 0:u.trim())||"";if(n&&n!==this.currentDocId){this.cancelledCursorBlockId="",this.currentDocId=n,this.activeCursorBlockId=n;const h=await qs(n).catch(()=>({}));ni({id:n,rootId:n,type:"doc",attrs:h}),this.markCompileDirty(n),this.updatePreviewTabHeader(s,n)}}onClickEditorContent(o){var s,l;const i=o==null?void 0:o.detail;if(!i)return;const n=(l=(s=i.protyle)==null?void 0:s.block)==null?void 0:l.rootID;n&&(!this.currentDocId||this.currentDocId!==n)&&(this.currentDocId=n),i.event&&this.onEditorClick(i.event)}buildPreviewTabTitle(o){return rc(o)}async fetchDocumentTitle(o){return lc(this,o)}async updatePreviewTabHeader(o,i){return mg(this,o,i)}getActiveDocumentId(){return Ao.getActiveDocumentId()}resolveDocIdFromElement(o){return Ao.resolveDocIdFromElement(o,this.currentDocId)}async switchToDocGlobalInspector(o,i){o&&(this.activeCursorBlockId=o,this.currentDocId=o,await Ao.switchToDocGlobalInspector(o,i))}onWsMain(o){const i=o.detail;i&&i.cmd==="transactions"&&(Ao.patchThematicBreakTransactions(i),this.markCompileDirty())}markCompileDirty(o){const i=o||this.currentDocId||this.getActiveDocumentId();i&&(this.currentDocId||(this.currentDocId=i),this.dirtyDocId=i,this.scheduleDirtyCompile())}scheduleDirtyCompile(o=r2){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const i=kn.getVisibility();if(i==="none")return;const n=i==="visible"?o:Math.max(o,Fw);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const s=this.dirtyDocId;this.dirtyDocId=null,s&&this.compileCurrentDocument(s,{reason:"auto"})},n)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(o,i){return o?(this.cancelledCursorBlockId="",this.activeCursorBlockId=o):(this.cancelledCursorBlockId=this.activeCursorBlockId,this.activeCursorBlockId=""),Ao.handleBlockClickedFromSlide(o,this.app,this.currentDocId,this.latestCompiledDoc,i)}onBlockClickedFromSlide(o){const i=(o==null?void 0:o.detail)||o;i!=null&&i.blockId&&this.handleBlockClickedFromSlide(i.blockId,i.page)}onEditorClick(o){var h,y;const i=o.target;if(!i)return;const n=((h=i.closest)==null?void 0:h.call(i,".protyle"))||((y=i.closest)==null?void 0:y.call(i,".protyle-wysiwyg"));if(bl(n))return;const s=i.closest(".protyle-title")||i.closest(".protyle-background");if(!!s){const d=this.resolveDocIdFromElement(i);if(d&&this.activeCursorBlockId!==d){const f=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),p=f==null?void 0:f.querySelector(".protyle-title__input"),g=((p==null?void 0:p.innerText)||(f==null?void 0:f.innerText)||"").trim();this.switchToDocGlobalInspector(d,g)}return}if(!i.closest(".protyle-wysiwyg"))return;const a=i.closest("[data-node-id]");if(!a)return;const c=a.getAttribute("data-node-id"),u=a.getAttribute("data-type")||"";c&&(this.cancelledCursorBlockId="",this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(i)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),c!==this.activeCursorBlockId&&(this.activeCursorBlockId=c,Us(c)),this.syncInspectorBlock(a,c,u))}onSelectionChange(){var h,y;if(typeof window>"u")return;const o=window.getSelection();if(!o||o.rangeCount===0)return;const i=o.anchorNode;if(!i)return;const n=i.nodeType===Node.ELEMENT_NODE?i:i.parentElement;if(!n)return;const s=((h=n.closest)==null?void 0:h.call(n,".protyle"))||((y=n.closest)==null?void 0:y.call(n,".protyle-wysiwyg"));if(bl(s))return;const l=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!l){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const f=l||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),p=f==null?void 0:f.querySelector(".protyle-title__input"),g=((p==null?void 0:p.innerText)||(f==null?void 0:f.innerText)||"").trim();this.switchToDocGlobalInspector(d,g)}return}if(!n.closest(".protyle-wysiwyg"))return;const a=n.closest("[data-node-id]"),c=a==null?void 0:a.getAttribute("data-node-id"),u=(a==null?void 0:a.getAttribute("data-type"))||"";if(a&&c){if(Ao.isLocatingLocked(c))return;if(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),c!==this.activeCursorBlockId){if(c===this.cancelledCursorBlockId)return;this.activeCursorBlockId=c,Us(c)}this.syncInspectorBlock(a,c,u)}}async syncInspectorBlock(o,i,n){this.inspectorSyncThrottle.shouldSkip(i)||await Ao.syncInspectorBlock(o,i,n,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(o,i){const n=(i==null?void 0:i.reason)??"explicit";let s=o||this.currentDocId;if(!s){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,s=r;else return}if(n==="auto"&&kn.getVisibility()==="none"){this.dirtyDocId=s;return}const l=this.compileScheduler.tryBegin(s);if(l!==null){this.dirtyDocId===s&&(this.dirtyDocId=null);try{const r=await Ee.compile(s),a=!!this.currentDocId&&s!==this.currentDocId;!this.compileScheduler.isStale(l)&&!a&&(this.currentDocId||(this.currentDocId=s),this.latestCompiledDoc=r,Jw(r,s),this.updatePreviewTabHeader("",s),this.purgeStaleDomSlidesAttrs(r))}catch(r){console.error("[SiYuanLiveSlides] Failed to compile document:",r)}finally{const r=this.compileScheduler.finishBatch(),a=r.length>0?r[0]:this.compileScheduler.finish();a&&this.markCompileDirty(a);for(let c=1;c<r.length;c++)this.markCompileDirty(r[c])}}}purgeStaleDomSlidesAttrs(o){Ao.purgeStaleDomSlidesAttrs(o)}}module.exports=c2;
