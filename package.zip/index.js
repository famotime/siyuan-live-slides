"use strict";var la=Object.create;var yo=Object.defineProperty;var aa=Object.getOwnPropertyDescriptor;var ca=Object.getOwnPropertyNames;var da=Object.getPrototypeOf,ua=Object.prototype.hasOwnProperty;var fa=(t,i,e)=>i in t?yo(t,i,{enumerable:!0,configurable:!0,writable:!0,value:e}):t[i]=e;var pa=(t,i,e,n)=>{if(i&&typeof i=="object"||typeof i=="function")for(let o of ca(i))!ua.call(t,o)&&o!==e&&yo(t,o,{get:()=>i[o],enumerable:!(n=aa(i,o))||n.enumerable});return t};var An=(t,i,e)=>(e=t!=null?la(da(t)):{},pa(i||!t||!t.__esModule?yo(e,"default",{value:t,enumerable:!0}):e,t));var yt=(t,i,e)=>fa(t,typeof i!="symbol"?i+"":i,e);const gt=require("siyuan");async function de(t,i){const e=await gt.fetchSyncPost(t,i);return e.code===0?e.data:null}async function ha(){return de("/api/notebook/lsNotebooks","")}async function ma(t,i,e){return de("/api/filetree/createDocWithMd",{notebook:t,path:i,markdown:e})}async function ga(t,i){const e=new FormData;e.append("assetsDirPath",t);for(const o of i)e.append("file[]",o);return de("/api/asset/upload",e)}async function Qi(t,i,e,n,o){return de("/api/block/insertBlock",{dataType:t,data:i,nextID:e,previousID:n,parentID:o})}async function br(t,i,e){return de("/api/block/appendBlock",{dataType:t,data:i,parentID:e})}async function Ts(t,i,e){return de("/api/block/updateBlock",{dataType:t,data:i,id:e})}async function va(t){return de("/api/block/deleteBlock",{id:t})}async function ba(t){return de("/api/block/getBlockKramdown",{id:t})}async function Hn(t){return de("/api/block/getChildBlocks",{id:t})}async function Mt(t,i){return de("/api/attr/setBlockAttrs",{id:t,attrs:i})}async function Ue(t){return de("/api/attr/getBlockAttrs",{id:t})}async function dn(t){return de("/api/query/sql",{stmt:t})}async function Lo(t,i,e){const n=new FormData;return n.append("path",t),n.append("isDir",i.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",e),de("/api/file/putFile",n)}async function yr(t){const i="/api/ai/chatGPT";try{const e=await de(i,{msg:t});return typeof e=="string"&&e.trim().length>0?e.trim():e&&typeof e.content=="string"&&e.content.trim().length>0?e.content.trim():null}catch{return null}}async function ya(){return de("/api/storage/getInlineStyles","")}const kr=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function ka(t){const i=[];if(!t)return i;const e=new RegExp(kr.source,"g");let n;for(;(n=e.exec(t))!==null;){const o=n[2]??n[3]??n[4];i.push({fullMatch:n[0],blockId:n[1],anchorText:o?o.trim():void 0})}return i}function wa(t,i){if(!t)return"";const e=new RegExp(kr.source,"g");return t.replace(e,(n,o,r,l,s)=>{const a=(r??l??s??"").trim();if(i&&i[o]){const d=i[o].trim();return`<div class="slidev-block-ref" data-ref-id="${o}">${d}</div>`}const c=a||`Ref(${o.slice(0,8)})`;return`<a href="siyuan://blocks/${o}" data-ref-id="${o}" class="slidev-ref-tag">🔗 ${c}</a>`})}const un="custom-slidev-theme",fn="custom-slidev-aspect-ratio",wr="custom-slidev-highlighter",pn="custom-slidev-default-transition",xr="custom-slidev-color-schema",Oo="custom-slidev-spacing",vi="custom-slidev-slide",ut="custom-slidev-layout",Kt="custom-slidev-transition",zt="custom-slidev-background",Se="custom-slidev-image",Di="custom-slidev-notes",Li="custom-slidev-class",nn="custom-slidev-spacing",ke="custom-slidev-click",Ne="custom-slidev-motion",Ci="custom-slidev-shiki-lines",It="custom-slidev-slot",Yt="custom-slidev-note",jt="custom-slidev-role",hn="custom-slidev-max-height",bi="custom-slidev-autoplay",Un="custom-slidev-loop",Mi="custom-slidev-muted",Wn="custom-slidev-controls",_r="background",Vn="image-left",Kn="image-right";function xa(t){return t.markdown&&t.markdown.trim()?t.markdown.trim():t.content&&t.content.trim()?t.content.trim():""}function _a(t){const i={};if(!t)return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(e))!==null;){const r=o[1],l=o[2]??o[3]??o[4]??"";i[r]=l}return i}function Sa(t){if(!t)return!1;const i=t.trim();return i.startsWith("assets/")||i.startsWith("./assets/")||i.startsWith("/assets/")}function Ca(t){const i=t.trim();return i.startsWith("./assets/")?i.slice(2):i.startsWith("/assets/")?i.slice(1):i}function ye(t,i){if(!Sa(t))return t;const e=Ca(t);return i!=null&&i.base64Map&&i.base64Map[e]?i.base64Map[e]:i!=null&&i.baseUrl?`${i.baseUrl.replace(/\/+$/,"")}/${e}`:`/${e}`}function $a(t,i){if(!t)return"";let e=t;return e=e.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,o,r)=>{const l=ye(r,i);return`![${o}](${l})`}),e=e.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,o,r,l)=>{const s=ye(r,i);return`${o}${s}${l}`}),e=e.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,o,r,l)=>{const s=ye(r,i);return`${o}${s}${l}`}),e}const ui={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal"};function Ia(t){var i,e,n,o,r,l;return t?{theme:((i=t[un])==null?void 0:i.trim())||ui.theme,aspectRatio:((e=t[fn])==null?void 0:e.trim())||ui.aspectRatio,highlighter:((n=t[wr])==null?void 0:n.trim())||ui.highlighter,defaultTransition:((o=t[pn])==null?void 0:o.trim())||ui.defaultTransition,colorSchema:((r=t[xr])==null?void 0:r.trim())||ui.colorSchema,spacing:((l=t[Oo])==null?void 0:l.trim())||ui.spacing}:{...ui}}function qn(t){var e,n,o,r,l;const i=(e=t.ial)==null?void 0:e[vi];return!!(i&&(i==="true"||i==="page"||i==="cover"||i==="end")||t.type==="tb"||t.type==="thematic-break"||t.type==="NodeThematicBreak"||((n=t.markdown)==null?void 0:n.trim())==="---"||((o=t.markdown)==null?void 0:o.trim())==="***"||t.type==="b"&&(((r=t.markdown)==null?void 0:r.trim())==="---"||((l=t.content)==null?void 0:l.trim())==="---"))}function Es(t){const i={};let e="";if(!t)return{frontmatter:i,notes:e};t[ut]&&(i.layout=t[ut].trim()),t[Kt]&&(i.transition=t[Kt].trim()),t[zt]&&(i.background=t[zt].trim()),t[Se]&&(i.image=t[Se].trim()),t[Li]&&(i.class=t[Li].trim()),t[nn]&&(i.spacing=t[nn].trim()),t[Di]&&(e=t[Di].trim());for(const[n,o]of Object.entries(t))if(n.startsWith("custom-slidev-")&&![ut,Kt,zt,Se,Li,nn,Di,vi].includes(n)){const r=n.replace(/^custom-slidev-/,"");try{i[r]=JSON.parse(o)}catch{i[r]=o}}return{frontmatter:i,notes:e}}function Aa(t){const i={};if(!t)return i;const e=t[Yt]??t["slidev-note"];e!=null&&e!==""&&e!=="false"&&e!=="0"&&(i.isNote=!0);const n=t[jt]??t["slidev-role"],o=t[zt]??t["slidev-background"];(n===_r||o==="true"||o==="1")&&(i.isBackground=!0);const r=t[ut]??t["slidev-layout"];r===Vn||r===Kn?i.imageLayout=r:(n===Vn||n===Kn)&&(i.imageLayout=n);const l=t[ke]??t["custom-slidev-clicks"]??t["slidev-click"]??t["slidev-clicks"];if(l!=null&&(i.clicks=l.trim()),t[Ne])try{const s=JSON.parse(t[Ne]);typeof s=="object"&&s!==null?i.motion={preset:s.preset||s.type||"fade-in",...s}:i.motion={preset:String(s).trim()}}catch{i.motion={preset:t[Ne].trim()}}return t[Ci]&&(i.shikiLines=t[Ci].trim()),t[hn]&&(i.maxHeight=t[hn].trim()),t[It]&&(i.slot=t[It].trim()),t.style&&t.style.trim()&&(i.style=t.style.trim()),i}function li(t,i){const e=(t||i||"").trim();if(!e)return null;const n=e.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const o=e.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(o)return o[1].trim();const r=e.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(r)?r:null}function Po(t){if(!t)return"";const i=t.split(/\r?\n/);if(i.length===0)return"";const e=i[0],n=e.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return t;const o=n[1].length,r=n[2].trim(),l=e.length-n[2].length;if(i.length===1)return r;const s=[r];for(let a=1;a<i.length;a++){const c=i[a];if(!c.trim()){s.push("");continue}const d=c.match(/^(\s*)/),p=d?d[1].length:0;p>=l?s.push(c.slice(l)):p>o?s.push(c.slice(p)):s.push(c)}return s.join(`
`)}function ji(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="i"||i==="nodelistitem"||i==="l"||i==="nodelist")return!0;const e=(t.markdown||t.rawMarkdown||t.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(e)}function se(t){if(!t)return!1;const i=(t.type||"").toLowerCase();return i==="s"||i==="sb"||i==="nodesuperblock"}function $i(t){if(!se(t))return!1;const i=(t.subType||"").toLowerCase();if(i==="col"||i==="h"||i==="horizontal")return!0;if(i==="row"||i==="v"||i==="vertical")return!1;if(t.ial){const n=(t.ial["data-sb-layout"]||t.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(t.children&&t.children.length>0){for(const n of t.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const o=(n.content||n.markdown||"").trim().toLowerCase();if(o==="col"||o==="h")return!0;if(o==="row"||o==="v")return!1}}const e=(t.markdown||t.content||"").trim();return/^\{\{\{col\b/i.test(e)?!0:!/^\{\{\{row\b/i.test(e)}function Ro(t){return!t||ji(t)||se(t)||!li(t.markdown,t.content)?!1:(t.markdown||t.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function ai(t){if(!t||!se(t)||!$i(t))return null;const i=(t.children||[]).filter(o=>{const r=o.type||"";if(r==="NodeSuperBlockOpenMarker"||r==="NodeSuperBlockLayoutMarker"||r==="NodeSuperBlockCloseMarker"||r==="open-marker"||r==="layout-marker"||r==="close-marker")return!1;const l=(o.markdown||o.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(l)||l==="}}}")});if(i.length<2)return null;const e=Ro(i[0]),n=Ro(i[i.length-1]);if(e&&!n){const o=li(i[0].markdown,i[0].content);if(o)return{imageNode:i[0],imageUrl:o,layout:Vn,contentNodes:i.slice(1)}}if(!e&&n){const o=li(i[i.length-1].markdown,i[i.length-1].content);if(o)return{imageNode:i[i.length-1],imageUrl:o,layout:Kn,contentNodes:i.slice(0,i.length-1)}}return null}function Ta(t,i){const e=[];function n(o){for(const r of o){const l=ai(r);if(l){const{imageNode:s,layout:a}=l;s.ial||(s.ial={});const c=s.ial[ut];if(c!==a){const d={blockId:s.id,layout:a,previousLayout:c};s.ial[ut]=a,e.push(d),i&&i(d)}}r.children&&r.children.length>0&&n(r.children)}}return n(t),e}function Qo(t){return(t.children||[]).filter(i=>{const e=i.type||"";if(e==="NodeSuperBlockOpenMarker"||e==="NodeSuperBlockLayoutMarker"||e==="NodeSuperBlockCloseMarker"||e==="open-marker"||e==="layout-marker"||e==="close-marker")return!1;const n=(i.markdown||i.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function Ea(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="h"||i==="nodeheading"||/^h[1-6]$/i.test(t.subType||""))return!0;const e=(t.markdown||t.content||"").trim();return!!/^#{1,6}\s+/.test(e)}function yi(t){if(!t)return[];if(se(t)&&$i(t)&&!ai(t)){const n=Qo(t),o=[];for(const r of n)o.push(...yi(r));return o}const i=(t.type||"").toLowerCase();if(i==="l"||i==="nodelist"||i==="list"){if(t.children&&t.children.length>0){const l=t.children.filter(ji);if(l.length>0)return l}const o=(t.markdown||t.content||"").trim().split(/\r?\n/),r=[];for(let l=0;l<o.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(o[l])&&r.push(l);if(r.length>=2){const l=[];for(let s=0;s<r.length;s++){const a=r[s],c=s+1<r.length?r[s+1]:o.length,d=o.slice(a,c).join(`
`);l.push({id:`${t.id}-item-${s+1}`,type:"i",markdown:d,content:d,ial:{...t.ial||{}}})}return l}}return ji(t)?[t]:[]}function Sr(t){var n;if(!t||!se(t)||!$i(t)||ai(t))return null;const i=Qo(t);if(i.length===0)return null;if(i.length===1&&se(i[0])&&$i(i[0])){const o=Sr(i[0]);return o?{items:o.items,nestedSuperBlocks:[i[0],...o.nestedSuperBlocks]}:null}const e=[];for(const o of i)if(se(o)){e.push(o);const r=((n=o.children)==null?void 0:n.filter(se))||[];e.push(...r)}if(i.length===3){const o=yi(i[0]),r=yi(i[1]),l=yi(i[2]);if(o.length===1&&r.length===1&&l.length===1)return{items:[o[0],r[0],l[0]],nestedSuperBlocks:e}}if(i.length===2){const o=yi(i[0]),r=yi(i[1]);if(o.length===2&&r.length===1)return{items:[o[0],o[1],r[0]],nestedSuperBlocks:e};if(o.length===1&&r.length===2)return{items:[o[0],r[0],r[1]],nestedSuperBlocks:e};if(o.length===1&&r.length===1)return{items:[o[0],r[0]],nestedSuperBlocks:e}}return null}function Ba(t){if(!t||!se(t)||!$i(t)||ai(t))return null;const i=Sr(t);if(!i)return null;const{items:e,nestedSuperBlocks:n}=i;return e.length!==2&&e.length!==3?null:e.length===2?{superBlockNode:t,nestedSuperBlocks:n,count:2,layout:"two-cols-header",items:e,slots:["left","right"]}:{superBlockNode:t,nestedSuperBlocks:n,count:3,layout:"three-cols-header",items:e,slots:["col-1","col-2","col-3"]}}function Ma(t){if(!t||!se(t)||!$i(t)||ai(t))return null;const i=Qo(t);if(i.length===0)return null;const e=[];for(const n of i){const o=yi(n);if(o.length===0)return null;e.push(...o)}return e}function Da(t){if(!t||!se(t)||!$i(t)||ai(t))return null;const i=Ma(t);return!i||i.length===0||i.length===2||i.length===3?null:{superBlockNode:t,items:i}}function La(t,i,e){var d,p,g,u,w;const n=[],o=[],r=(e==null?void 0:e.tracked)||[],l=[];let s={pageTargetId:t,blocks:[]};l.push(s);for(let h=0;h<i.length;h++){const k=i[h];if(qn(k)){if(l.length===1&&s.blocks.length===0){s.pageTargetId=k.id,s.blocks.push(k);continue}s={pageTargetId:k.id,blocks:[k]},l.push(s)}else s.blocks.push(k)}function a(h){const k=[];for(const b of h)se(b)&&k.push(b),b.children&&b.children.length>0&&k.push(...a(b.children));return k}function c(h,k,b){const y={blockId:h,attrs:k,previousAttrs:b};n.push(y),e!=null&&e.onTagChange&&e.onTagChange(y)}for(const h of l){const k=h.pageTargetId,b=i.find(_=>_.id===k),y=r.find(_=>_.pageTargetId===k);if(h.blocks.some(_=>{var C,D;return!!(ai(_)||Ro(_)&&(((C=_.ial)==null?void 0:C[ut])==="image-left"||((D=_.ial)==null?void 0:D[ut])==="image-right"))})){if(y){const _=y.headerId;if(_){c(_,{[It]:""});const C=i.find(D=>D.id===_);C!=null&&C.ial&&(C.ial[It]="")}for(const C of y.itemIds){c(C,{[It]:""});const D=i.find(M=>M.id===C);D!=null&&D.ial&&(D.ial[It]="")}}continue}let T=null,x=-1;for(let _=0;_<h.blocks.length;_++){const C=h.blocks[_],D=se(C)?[C,...a(C.children||[])]:C.children?a(C.children):[];for(const M of D){const z=Ba(M);if(z){T=z,x=_;break}}if(T)break}if(T){const{superBlockNode:_,layout:C,items:D,slots:M}=T,J=h.blocks.slice(0,x).find(P=>Ea(P)),E=J==null?void 0:J.id,A=((d=b==null?void 0:b.ial)==null?void 0:d[ut])||"";if(A!==C&&(c(k,{[ut]:C},{[ut]:A}),b&&(b.ial||(b.ial={}),b.ial[ut]=C)),J){const P=((p=J.ial)==null?void 0:p[It])||"";P!=="header"&&(c(J.id,{[It]:"header"},{[It]:P}),J.ial||(J.ial={}),J.ial[It]="header")}if(y!=null&&y.headerId&&y.headerId!==E){c(y.headerId,{[It]:""});const P=i.find(G=>G.id===y.headerId);P&&(P.ial||(P.ial={}),P.ial[It]="")}const v=[];for(let P=0;P<D.length;P++){const G=D[P],F=M[P];v.push(G.id);const et=((g=G.ial)==null?void 0:g[It])||"";if(et!==F&&(c(G.id,{[It]:F},{[It]:et}),G.ial||(G.ial={}),G.ial[It]=F),G.children&&G.children.length>0)for(const H of G.children)H.ial||(H.ial={}),H.ial[It]!==F&&(H.ial[It]=F)}if(y!=null&&y.itemIds){for(const P of y.itemIds)if(!v.includes(P)){c(P,{[It]:""});const G=i.find(F=>F.id===P);G&&(G.ial||(G.ial={}),G.ial[It]="")}}o.push({superBlockId:_.id,nestedSuperBlockIds:(u=T.nestedSuperBlocks)==null?void 0:u.map(P=>P.id),pageTargetId:k,headerId:E,itemIds:v,layout:C})}else{let _=!1;const C=[];for(const z of h.blocks){const J=se(z)?[z,...a(z.children||[])]:z.children?a(z.children):[];for(const E of J){const A=Da(E);if(A){_=!0;for(const v of A.items)C.push(v.id)}}}const D=((w=b==null?void 0:b.ial)==null?void 0:w[ut])||"";if(y||_&&(D==="two-cols-header"||D==="three-cols-header")){c(k,{[ut]:""},{[ut]:D}),b&&(b.ial||(b.ial={}),b.ial[ut]="");const z=y==null?void 0:y.headerId;if(z){c(z,{[It]:""});const E=i.find(A=>A.id===z);E&&(E.ial||(E.ial={}),E.ial[It]="")}const J=new Set([...(y==null?void 0:y.itemIds)||[],...C]);for(const E of J){c(E,{[It]:""});const A=i.find(v=>v.id===E);A&&(A.ial||(A.ial={}),A.ial[It]="")}}}}return{changes:n,newTracked:o}}function fi(t,i,e){let n="",o=0;const r=/<div\b([^>]*)>/gi;for(;o<t.length;){r.lastIndex=o;let l,s=!1,a=-1,c=0;for(;(l=r.exec(t))!==null;){const b=l[1].match(/\bclass=["']([^"']*)["']/i);if(b){const y=b[1];if(typeof i=="string"?y.split(/\s+/).includes(i):i.test(y)){s=!0,a=l.index,c=l[0].length;break}}}if(!s){n+=t.slice(o);break}n+=t.slice(o,a);const d=a+c;let p=1,g=-1,u=-1;const w=/<\/?div\b[^>]*>/gi;w.lastIndex=d;let h;for(;(h=w.exec(t))!==null;)if(h[0].startsWith("</")){if(p--,p===0){g=h.index,u=h.index+h[0].length;break}}else p++;if(g!==-1&&u!==-1){const k=t.slice(d,g);n+=e(k),o=u}else n+=t.slice(a,d),o=d}return n}function Oa(t){const i=[];let e="",n=0;const o=/<div\b([^>]*)>/gi;for(;n<t.length;){o.lastIndex=n;let r,l=!1,s=-1,a=0;for(;(r=o.exec(t))!==null;){const h=r[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(h)){l=!0,s=r.index,a=r[0].length;break}}if(!l){e+=t.slice(n);break}e+=t.slice(n,s);const c=s+a;let d=1,p=-1,g=-1;const u=/<\/?div\b[^>]*>/gi;u.lastIndex=c;let w;for(;(w=u.exec(t))!==null;)if(w[0].startsWith("</")){if(d--,d===0){p=w.index,g=w.index+w[0].length;break}}else d++;if(p!==-1&&g!==-1){const h=t.slice(s,g),k=`__VUE_DIV_TOKEN_${i.length}__`;i.push(h),e+=k,n=g}else e+=t.slice(s,c),n=c}return{text:e,tokens:i}}function Pa(t){const i=[];let e=t.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,s=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(s),a});e=e.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,s=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(s),a});const n=[];e=e.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,s=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(s),a});const{text:o,tokens:r}=Oa(e);e=o;const l=[];e=e.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,s=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(s),a}),e=e.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,s=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(s),a}),e=e.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,s=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(s),a}),e=e.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,s=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(s),a}),e=e.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),e=e.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),e=e.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),e=e.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),e=e.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),e=e.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),e=e.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),e=e.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(s,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),e=e.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(s,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),e=e.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(s,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),e=e.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(s,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=fi(e,"diff-grid",s=>{const a=Array.from(s.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),p=c[3].trim();return`**${d}:**
\`\`\`yaml
${p}
\`\`\``}).join(`

`)+`
`:s}),e=fi(e,"before-after",s=>{const a=s.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=s.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:s}),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(s,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),e=fi(e,"timeline",s=>{const a=Array.from(s.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let p="-";return d.includes("warn")?p="- ⚠️":d.includes("bad")?p="- ❌":d.includes("ok")&&(p="- ✅"),`${p} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:s}),e=fi(e,"pipeline",s=>{const a=Array.from(s.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const g=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${g}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:s}),e=fi(e,"check-grid",s=>{const a=Array.from(s.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:s}),e=fi(e,"manifesto",s=>{const a=Array.from(s.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:s}),e=fi(e,"split-note",s=>{const a=Array.from(s.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:s}),e=e.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(s,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),e=e.replace(/<pre>([\s\S]*?)<\/pre>/gi,(s,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=e.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),e=e.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),e=e.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),e=e.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),e=e.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),e=e.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),e=e.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),e=e.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),e=e.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(s,a,c)=>/@|v-|:|class=/i.test(a)?s:`
${c.trim()}

`),e=e.replace(/<br\s*\/?>/gi,`
`),e=e.replace(/<hr\s*\/?>/gi,`
---
`),e=e.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),e=e.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),e=e.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),e=e.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(s,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((p,g)=>Math.max(p,g.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),e=e.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),e=e.replace(/\*{4}/g,"** **"),e=e.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),e=e.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),e=e.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(s,a,c,d,p)=>{const g=p.trim();return g.includes("<")||g.includes(`
`)?s:`[${g}](${c})`}),e=e.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(s,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),e=e.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(s,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),e=e.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(s,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),e=e.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),e=e.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),e=e.replace(/<\/?span\b[^>]*>/gi,"");for(let s=0;s<l.length;s++)e=e.replace(`__VUE_COMP_TOKEN_${s}__`,l[s]);for(let s=0;s<r.length;s++)e=e.replace(`__VUE_DIV_TOKEN_${s}__`,r[s]);for(let s=0;s<n.length;s++)e=e.replace(`__SCRIPT_TOKEN_${s}__`,n[s]);for(let s=0;s<i.length;s++)e=e.replace(`__CODE_TOKEN_${s}__`,i[s]);return e=e.replace(/\n{3,}/g,`

`).trim(),e}function Cr(t){if(!t||typeof t!="string")return"";const i=[];let e=t.replace(/`([^`]+)`/g,n=>(i.push(n),`%%INLINE_CODE_${i.length-1}%%`));return e=e.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),e=e.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),e=e.replace(/\{:[^}]*\}/g,""),e=e.replace(/%%INLINE_CODE_(\d+)%%/g,(n,o)=>i[parseInt(o,10)]||""),e}function Ra(t){const i=Object.entries(t).filter(([n,o])=>o!=null&&o!=="");return i.length===0?"":`---
${i.map(([n,o])=>typeof o=="string"?o.includes(":")||o.includes(`
`)||o.includes("#")?`${n}: "${o.replace(/"/g,'\\"')}"`:`${n}: ${o}`:`${n}: ${JSON.stringify(o)}`).join(`
`)}
---`}function za(t,i){if(!i||!t.startsWith("```"))return t;const e=t.indexOf(`
`);if(e===-1)return t;const n=t.slice(0,e).trim(),o=t.slice(e);return n.includes("{")?t:`${n} {${i}}${o}`}function Na(t,i){if(i==null)return t;const e=i.trim();return e===""||e==="+1"?`<v-click>

${t}

</v-click>`:e==="hide"?`<v-click hide>

${t}

</v-click>`:`<v-click at="${e}">

${t}

</v-click>`}function Fa(t){if(!t||!t.preset)return null;const i=t.preset.toLowerCase().trim();if(!i||i==="none")return null;let e={opacity:0},n={opacity:1};switch(i){case"slide-up":e={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":e={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":e={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":e={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":e={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":e={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:e={opacity:0},n={opacity:1};break}t.initial&&typeof t.initial=="object"&&(e={...e,...t.initial}),t.enter&&typeof t.enter=="object"&&(n={...n,...t.enter});const o={...n.transition||{}};return typeof t.duration=="number"&&t.duration>0&&(o.duration=t.duration),typeof t.delay=="number"&&t.delay>0&&(o.delay=t.delay),Object.keys(o).length>0&&(n.transition=o),{initial:e,enter:n}}function Bs(t,i,e,n){const o=i!=null&&i.trim()!=="",r=Fa(e),l=n==null?void 0:n.trim(),s=l!==void 0&&l!=="",a=s?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!r)return s?`<div${a}>

${t}

</div>`:t;if(o&&!r){if(s){const w=i.trim();let h="v-click";return w==="hide"?h="v-click.hide":w!==""&&w!=="+1"&&(h=`v-click="${w}"`),`<div ${h}${a}>

${t}

</div>`}return Na(t,i)}const c=JSON.stringify(r.initial).replace(/"/g,"'"),d=JSON.stringify(r.enter).replace(/"/g,"'"),p=`v-motion :initial="${c}" :enter="${d}"`;if(!o)return`<div ${p}${a}>

${t}

</div>`;const g=i.trim();let u="v-click";return g==="hide"?u="v-click.hide":g!==""&&g!=="+1"&&(u=`v-click="${g}"`),`<div ${u} ${p}${a}>

${t}

</div>`}function $r(t){if(!t)return"";let i=t.trim();i=i.replace(/\{:[^}]*\}/g,"").trim(),i=i.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),i=i.replace(/\r?\n?:::\s*$/g,"");let o=i.split(/\r?\n/).map(r=>r.trim().replace(/^>\s*/,"")).join(`
`).trim();return o=o.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),o=o.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),o=o.replace(/^[-*+]\s+/,""),o=o.replace(/^\d+\.\s+/,""),o.trim()}function ja(t){var n;if(t.subType&&/^h([1-6])$/i.test(t.subType))return parseInt(t.subType.slice(1),10);const e=(t.markdown||t.content||"").trim().match(/^(#{1,6})\s+/);return e?e[1].length:t.type==="h"?(n=t.ial)!=null&&n.subType&&/^h([1-6])$/i.test(t.ial.subType)?parseInt(t.ial.subType.slice(1),10):1:null}function Ir(t){if(!t||t.length===0)return{col1:[],col2:[],col3:[]};if(t.length===1&&t[0].children&&t[0].children.length>=2){const l=t[0].children;if(l.length>=3){const s=Math.ceil(l.length/3),a=Math.ceil((l.length-s)/2);return{col1:l.slice(0,s),col2:l.slice(s,s+a),col3:l.slice(s+a)}}else return{col1:[l[0]],col2:[l[1]],col3:[]}}const i=l=>{const s=l.slot||"";return s==="col-1"||s==="left"?1:s==="col-2"||s==="center"?2:s==="col-3"||s==="right"?3:null},e=t.map(i);if(e.some(l=>l!==null)){const l=e.includes(2),s=e.includes(3);if(l||s){const d=[],p=[],g=[];let u=1;for(const w of t){const h=i(w);h!==null&&(u=h),u===1?d.push(w):u===2?p.push(w):g.push(w)}return{col1:d,col2:p,col3:g}}const a=t.filter(d=>i(d)===1),c=t.filter(d=>i(d)===null);if(c.length>=2){const d=Math.ceil(c.length/2);return{col1:a,col2:c.slice(0,d),col3:c.slice(d)}}else return c.length===1?{col1:a,col2:c,col3:[]}:{col1:a,col2:[],col3:[]}}const o=l=>{if(l.type==="h"||l.subType&&/^h[1-6]$/i.test(l.subType))return!0;const s=(l.rawMarkdown||l.content||"").trim();return/^#{1,6}\s+/.test(s)},r=t.map((l,s)=>o(l)?s:-1).filter(l=>l!==-1);if(r.length>=3)return{col1:t.slice(0,r[1]),col2:t.slice(r[1],r[2]),col3:t.slice(r[2])};if(t.length>=3){const l=Math.ceil(t.length/3),s=Math.ceil((t.length-l)/2);return{col1:t.slice(0,l),col2:t.slice(l,l+s),col3:t.slice(l+s)}}if(t.length===2)return{col1:[t[0]],col2:[t[1]],col3:[]};if(t.length===1){const l=t[0],s=(l.rawMarkdown||l.content||"").trim(),a=s.split(/\r?\n/),c=[];for(let g=0;g<a.length;g++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(a[g])&&c.push(g);if(c.length>=3){const g=Math.ceil(c.length/3),u=Math.ceil((c.length-g)/2),w=a.slice(c[0],c[g]).join(`
`),h=a.slice(c[g],c[g+u]).join(`
`),k=a.slice(c[g+u]).join(`
`);return{col1:[{...l,rawMarkdown:w,content:w}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:h,content:h}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:k,content:k}]}}const d=s.match(/<li[\s\S]*?<\/li>/gi);if(d&&d.length>=3){const g=Math.ceil(d.length/3),u=Math.ceil((d.length-g)/2),w=`<ul>
${d.slice(0,g).join(`
`)}
</ul>`,h=`<ul>
${d.slice(g,g+u).join(`
`)}
</ul>`,k=`<ul>
${d.slice(g+u).join(`
`)}
</ul>`;return{col1:[{...l,rawMarkdown:w,content:w}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:h,content:h}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:k,content:k}]}}const p=s.split(/\r?\n\s*\r?\n/).filter(g=>g.trim()!=="");if(p.length>=3){const g=Math.ceil(p.length/3),u=Math.ceil((p.length-g)/2);return{col1:[{...l,rawMarkdown:p.slice(0,g).join(`

`),content:p.slice(0,g).join(`

`)}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:p.slice(g,g+u).join(`

`),content:p.slice(g,g+u).join(`

`)}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:p.slice(g+u).join(`

`),content:p.slice(g+u).join(`

`)}]}}}return{col1:t,col2:[],col3:[]}}function Ms(t,i,e,n){var d;const o=Ia(i),r=[],l=Es(i);let s={pageIndex:1,startBlockId:t,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[t]};s.frontmatter.background&&(s.frontmatter.background=ye(s.frontmatter.background,n)),s.frontmatter.image&&(s.frontmatter.image=ye(s.frontmatter.image,n)),r.push(s);let a=[];for(const p of e){if(qn(p)){a=[];const u=Es(p.ial);if(r.length===1&&s.blocks.length===0){s.startBlockId=p.id,s.allBlockIds||(s.allBlockIds=[]),s.allBlockIds.includes(p.id)||s.allBlockIds.push(p.id),u.frontmatter.layout&&(s.frontmatter.layout=u.frontmatter.layout),Object.assign(s.frontmatter,u.frontmatter),!u.frontmatter.image&&l.frontmatter.image&&(s.frontmatter.image=l.frontmatter.image),!u.frontmatter.background&&l.frontmatter.background&&(s.frontmatter.background=l.frontmatter.background),s.frontmatter.background&&(s.frontmatter.background=ye(s.frontmatter.background,n)),s.frontmatter.image&&(s.frontmatter.image=ye(s.frontmatter.image,n));continue}s={pageIndex:r.length+1,startBlockId:p.id,frontmatter:{layout:u.frontmatter.layout||"default",...u.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[p.id]},s.frontmatter.background&&(s.frontmatter.background=ye(s.frontmatter.background,n)),s.frontmatter.image&&(s.frontmatter.image=ye(s.frontmatter.image,n)),r.push(s);continue}const g=u=>{if(s.allBlockIds||(s.allBlockIds=[]),u.id&&!s.allBlockIds.includes(u.id)&&s.allBlockIds.push(u.id),u.children&&u.children.length>0){const A=v=>{for(const P of v)P.id&&!s.allBlockIds.includes(P.id)&&s.allBlockIds.push(P.id),P.children&&P.children.length>0&&A(P.children)};A(u.children)}let w=xa(u),h=u.ial?{...u.ial}:{};const k=w.match(/\{:\s*([^}]+)\s*\}\s*$/);k&&(h={..._a(k[0]),...h},w=w.slice(0,k.index).trim()),u.type!=="c"&&!w.startsWith("```")&&(w=Cr(w));let b=w.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(b)||b==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(b)&&/\r?\n\}\}\}$/.test(b)&&(w=b.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),b=w.trim());const y=Aa(h);if(w=$a(w,n),w=wa(w,n==null?void 0:n.refContentMap),u.children&&u.children.length>0){const A=v=>{for(const P of v){if(P.ial)for(const[G,F]of Object.entries(P.ial))G.startsWith("custom-slidev-")&&!h[G]&&(h[G]=F);P.children&&P.children.length>0&&A(P.children)}};A(u.children)}const S=u.type==="video"||u.type==="NodeVideo"||/<video\b/i.test(w);if(S){const A=h["custom-slidev-autoplay"]==="true",v=h["custom-slidev-loop"]==="true",P=h["custom-slidev-muted"]==="true"||A,G=h["custom-slidev-controls"]==="false";w=w.replace(/<video\b([^>]*)>/gi,(F,et)=>{let H=et;return G?H=H.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(H)||(H+=" controls"),A&&!/autoplay/i.test(H)?H+=" autoplay playsinline":!A&&h["custom-slidev-autoplay"]==="false"&&(H=H.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),v&&!/loop/i.test(H)?H+=" loop":!v&&h["custom-slidev-loop"]==="false"&&(H=H.replace(/\bloop\b/gi,"").trim()),P&&!/muted/i.test(H)?H+=" muted":!P&&h["custom-slidev-muted"]==="false"&&(H=H.replace(/\bmuted\b/gi,"").trim()),`<video ${H.trim()}>`})}if(y.isBackground){const A=li(w,u.content);if(A){s.frontmatter.background=ye(A,n);return}}const T=ai(u);if(T){s.frontmatter.layout=T.layout,s.frontmatter.image=ye(T.imageUrl,n);for(const A of T.contentNodes)g(A);return}if(y.imageLayout==="image-left"||y.imageLayout==="image-right"){const A=li(w,u.content);if(A){s.frontmatter.layout=y.imageLayout,s.frontmatter.image=ye(A,n);return}}if(se(u)&&u.children&&u.children.length>0){for(const A of u.children)g(A);return}if((u.type==="l"||u.type==="NodeList"||u.type==="list")&&u.children&&u.children.length>0&&(u.children.some(A=>{var v;return(v=A.ial)==null?void 0:v[It]})||y.slot)){for(const A of u.children)y.slot&&(!A.ial||!A.ial[It])&&(A.ial||(A.ial={}),A.ial[It]=y.slot),g(A);return}if(y.isNote){const A=$r(w);A&&(s.notes?s.notes+=`

`+A:s.notes=A),s.noteBlocks||(s.noteBlocks=[]),s.noteBlocks.push({id:u.id,type:u.type,content:A||u.content||"",rawMarkdown:w,isNote:!0,attributes:u.ial});return}y.shikiLines&&(w=za(w,y.shikiLines)),b=w.trim();const x=(u.content||"").trim();if(b==="::right::"||x==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(b)||b.startsWith("::right::")){s.blocks.push({id:u.id,type:u.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:u.ial});return}const C=ja(u);let D=y.slot,M=y.clicks,z=y.motion,J={...u.ial||{}};if(C!==null){for(;a.length>0&&a[a.length-1].level>=C;)a.pop();const A=a.length>0?a[a.length-1]:void 0;!D&&(A!=null&&A.slot)&&(D=A.slot),!M&&(A!=null&&A.clicks)&&(M=A.clicks),!z&&(A!=null&&A.motion)&&(z=A.motion);const v={...(A==null?void 0:A.customAttrs)||{}};if(u.ial)for(const[P,G]of Object.entries(u.ial))P.startsWith("custom-slidev-")&&!P.startsWith("custom-slidev-slide")&&(v[P]=G);a.push({level:C,slot:D,clicks:M,motion:z,customAttrs:v})}else{const A=a.length>0?a[a.length-1]:void 0;A&&(!D&&A.slot&&A.slot!=="header"&&(D=A.slot),!M&&A.clicks&&(M=A.clicks),!z&&A.motion&&(z=A.motion),A.customAttrs&&(J={...A.customAttrs,...J}))}!D&&s.blocks.some(A=>A.slot==="slot-divider-right")&&(D="right"),D&&(J[It]=D),M&&!J[ke]&&(J[ke]=M),z&&!J[Ne]&&(J[Ne]=JSON.stringify(z)),(S||h["custom-slidev-autoplay"]||h["custom-slidev-muted"])&&(h["custom-slidev-autoplay"]&&(J["custom-slidev-autoplay"]=h["custom-slidev-autoplay"],h["custom-slidev-autoplay"]==="true"&&!h["custom-slidev-muted"]&&(J["custom-slidev-muted"]="true")),h["custom-slidev-loop"]&&(J["custom-slidev-loop"]=h["custom-slidev-loop"]),h["custom-slidev-muted"]&&(J["custom-slidev-muted"]=h["custom-slidev-muted"]),h["custom-slidev-controls"]&&(J["custom-slidev-controls"]=h["custom-slidev-controls"]));const E={id:u.id,type:u.type,content:u.content||"",rawMarkdown:w,clicks:M,motion:z,shikiLines:y.shikiLines,slot:D,attributes:J};s.blocks.push(E)};g(p)}for(let p=0;p<r.length;p++){const g=r[p],u=[],w={...g.frontmatter};p===0&&(w.theme=o.theme,w.aspectRatio=o.aspectRatio,w.highlighter=o.highlighter,w.transition=g.frontmatter.transition||o.defaultTransition);const h=Ra(w);h&&u.push(h);const k=g.blocks.filter(x=>x.slot!=="slot-divider-right"),b=x=>x.filter(_=>!!(_.rawMarkdown||_.content||"").trim()).map(_=>{var C;return Bs(_.rawMarkdown,_.clicks,_.motion,(C=_.attributes)==null?void 0:C.style)}).join(`

`),y=x=>{const _=x.filter(z=>!!(z.rawMarkdown||z.content||"").trim());if(_.length===0)return;const C=_[0],D=(C.rawMarkdown||C.content||"").trim();(ji(C)||/^(?:[-*+]|\d+\.)\s+/.test(D))&&(C.rawMarkdown=Po(C.rawMarkdown||C.content||""),C.content=C.rawMarkdown)},S=x=>x.length===0?"":(y(x),b(x)),T=g.frontmatter.layout||"default";if(T==="two-cols-header"){let x=[];const _=k.filter(A=>A.slot==="header");if(_.length>0)x=_;else if(k.length>0){const A=k.find(v=>v.type==="h"&&(!v.slot||v.slot==="default"));A&&(x=[A])}const C=k.filter(A=>!x.includes(A)),D=C.filter(A=>A.slot==="right"||A.slot==="col-2"),M=C.filter(A=>!D.includes(A));y(M),y(D);const z=b(x),J=S(M),E=S(D);z&&u.push(z),J&&u.push(`::left::

${J}`),E&&u.push(`::right::

${E}`)}else if(T==="three-cols-header"){let x=[];const _=k.filter(G=>G.slot==="header");if(_.length>0)x=_;else if(k.length>0){const G=k.find(F=>F.type==="h"&&(!F.slot||F.slot==="default"));G&&(x=[G])}const C=k.filter(G=>!x.includes(G)),D=Ir(C),M=D.col1,z=D.col2,J=D.col3;for(const G of M)G.slot||(G.slot="col-1");for(const G of z)G.slot||(G.slot="col-2");for(const G of J)G.slot||(G.slot="col-3");if(y(M),y(z),y(J),C.length===1&&(z.length>0||J.length>0)){const G=g.blocks.findIndex(F=>F.id===C[0].id);G!==-1&&g.blocks.splice(G,1,...M,...z,...J)}const E=b(x),A=S(M),v=S(z),P=S(J);E&&u.push(E),A&&u.push(`::col-1::

${A}`),v&&u.push(`::col-2::

${v}`),P&&u.push(`::col-3::

${P}`)}else if(T==="two-cols"){const x=k.filter(M=>M.slot==="left"),_=k.filter(M=>M.slot==="right");y(x),y(_);const C=b(x.length>0?x:k.filter(M=>M.slot!=="right")),D=b(_);u.push(C),D&&u.push(`::right::

${D}`)}else for(const x of k)u.push(Bs(x.rawMarkdown,x.clicks,x.motion,(d=x.attributes)==null?void 0:d.style));g.notes&&u.push(`<!--
${g.notes}
-->`),g.rawMarkdown=u.join(`

`).trim()}const c=r.map(p=>p.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:t,config:o,slides:r,fullMarkdown:c}}const zo=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function Ha(t){var o,r,l,s,a,c,d,p,g,u,w,h;if(!t||typeof t!="object")return"";const i=[],e=[];if(Array.isArray(t.styles))for(const k of t.styles){if(!k||!k.id)continue;const b=`--b3-inline-style-${k.id}`;(o=k.light)!=null&&o.color&&i.push(`  ${b}-color: ${k.light.color};`),(r=k.light)!=null&&r.backgroundColor&&i.push(`  ${b}-background-color: ${k.light.backgroundColor};`),(l=k.dark)!=null&&l.color&&e.push(`  ${b}-color: ${k.dark.color};`),(s=k.dark)!=null&&s.backgroundColor&&e.push(`  ${b}-background-color: ${k.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.colors))for(const k of t.builtin.colors){if(!k||typeof k.index!="number")continue;const b=k.index;(a=k.light)!=null&&a.color&&i.push(`  --b3-font-color${b}: ${k.light.color};`),(c=k.light)!=null&&c.backgroundColor&&i.push(`  --b3-font-background${b}: ${k.light.backgroundColor};`),(d=k.dark)!=null&&d.color&&e.push(`  --b3-font-color${b}: ${k.dark.color};`),(p=k.dark)!=null&&p.backgroundColor&&e.push(`  --b3-font-background${b}: ${k.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.styles))for(const k of t.builtin.styles){if(!k||!k.id)continue;const b=k.id;(g=k.light)!=null&&g.color&&i.push(`  --b3-card-${b}-color: ${k.light.color};`),(u=k.light)!=null&&u.backgroundColor&&i.push(`  --b3-card-${b}-background: ${k.light.backgroundColor};`),(w=k.dark)!=null&&w.color&&e.push(`  --b3-card-${b}-color: ${k.dark.color};`),(h=k.dark)!=null&&h.backgroundColor&&e.push(`  --b3-card-${b}-background: ${k.dark.backgroundColor};`)}if(i.length===0&&e.length===0)return"";const n=[];return i.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${i.join(`
`)}
}`),e.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${e.join(`
`)}
}`),n.join(`

`)}function on(t){const i=Ha(t);return i?`${zo}

/* Custom Workspace Inline Styles */
${i}`:zo}function ko(t){const i={};if(!t||typeof t!="string")return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(e))!==null;){const r=o[1],l=o[2]??o[3]??o[4]??"";i[r]=l}return i}const Ua={getBlockAttrs:Ue,getChildBlocks:Hn,setBlockAttrs:Mt,sql:dn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:ya};class Wa{constructor(i){yt(this,"deps");yt(this,"attrOverrides",new Map);yt(this,"trackedListSuperBlocks",new Map);this.deps={...Ua,...i||{}}}setBlockAttrOverride(i,e){if(!i||!e)return;const o={...this.attrOverrides.get(i)||{}};for(const[r,l]of Object.entries(e))l===""||l===null||l===void 0?delete o[r]:o[r]=String(l);Object.keys(o).length===0?this.attrOverrides.delete(i):this.attrOverrides.set(i,o)}getBlockAttrOverride(i){return this.attrOverrides.get(i)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(i){return this.trackedListSuperBlocks.get(i)||[]}clearBlockAttrOverride(i,e){if(!i)return;if(!e){this.attrOverrides.delete(i);return}const n=this.attrOverrides.get(i);n&&(delete n[e],Object.keys(n).length===0&&this.attrOverrides.delete(i))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(i){try{const e=await this.deps.getBlockAttrs(i).catch(()=>({}))||{},n=this.attrOverrides.get(i);n&&Object.assign(e,n);let o=await this.deps.getChildBlocks(i).catch(()=>[]);const r=`SELECT id, ial FROM blocks WHERE root_id = '${i}' LIMIT 99999`,l=await this.deps.sql(r).catch(()=>[])||[],s=new Map;if(Array.isArray(l))for(const S of l)S.id&&S.ial&&s.set(S.id,ko(S.ial));const a=`SELECT block_id, name, value FROM attributes WHERE root_id = '${i}' AND type = 'b' LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[];if(Array.isArray(c)){for(const S of c)if(S.block_id&&S.name){let T=s.get(S.block_id);T||(T={},s.set(S.block_id,T)),T[S.name]=S.value||""}}if(!o||o.length===0){const S=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE root_id = '${i}' AND id != '${i}' ORDER BY created ASC LIMIT 99999`;o=await this.deps.sql(S).catch(()=>[])||[]}const d=(o||[]).map(S=>{const T=s.get(S.id)||(S.ial?ko(S.ial):{}),x=this.attrOverrides.get(S.id);return x&&Object.assign(T,x),{id:S.id,parent_id:S.parent_id,root_id:S.root_id||i,type:S.type,subType:S.subType,content:S.content||"",markdown:S.markdown||"",ial:T,children:S.children}}),p=async(S,T=0)=>{if(!(!S||S.length===0||T>8))for(const x of S){if((se(x)||x.type==="l"||x.type==="NodeList"||x.type==="i"||x.type==="NodeListItem"||x.type==="b"||x.type==="NodeBlockquote")&&(!x.children||x.children.length===0)){let C=await this.deps.getChildBlocks(x.id).catch(()=>[]);if(!C||C.length===0){const D=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE parent_id = '${x.id}' ORDER BY sort ASC, created ASC`;C=await this.deps.sql(D).catch(()=>[])||[]}Array.isArray(C)&&C.length>0&&(x.children=C.map(D=>{const M=s.get(D.id)||(D.ial?ko(D.ial):{}),z=this.attrOverrides.get(D.id);return z&&Object.assign(M,z),{id:D.id,parent_id:D.parent_id||x.id,root_id:D.root_id||i,type:D.type,subType:D.subType,content:D.content||"",markdown:D.markdown||"",ial:M}}))}x.children&&x.children.length>0&&await p(x.children,T+1)}};await p(d);const g=S=>{var T,x;for(const _ of S)if(_.children&&_.children.length>0){g(_.children);for(const C of _.children)if(C.ial)for(const[D,M]of Object.entries(C.ial))D.startsWith("custom-slidev-")&&!((T=_.ial)!=null&&T[D])&&(_.ial||(_.ial={}),_.ial[D]=M);if(_.ial){for(const[C,D]of Object.entries(_.ial))if(C.startsWith("custom-slidev-"))for(const M of _.children)(M.type==="video"||M.type==="NodeVideo"||/<video\b/i.test(M.markdown||M.content||""))&&!((x=M.ial)!=null&&x[C])&&(M.ial||(M.ial={}),M.ial[C]=D)}}};g(d),Ta(d,S=>{this.setBlockAttrOverride(S.blockId,{[ut]:S.layout}),(this.deps.setBlockAttrs||Mt)(S.blockId,{[ut]:S.layout}).catch(x=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",x)})});const u=this.trackedListSuperBlocks.get(i)||[],w=La(i,d,{tracked:u,onTagChange:S=>{this.setBlockAttrOverride(S.blockId,S.attrs),S.blockId===i&&Object.assign(e,S.attrs);const T=_=>{for(const C of _)C.id===S.blockId&&(C.ial||(C.ial={}),Object.assign(C.ial,S.attrs)),C.children&&C.children.length>0&&T(C.children)};T(d),(this.deps.setBlockAttrs||Mt)(S.blockId,S.attrs).catch(_=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",_)})}});this.trackedListSuperBlocks.set(i,w.newTracked);const h=new Set;for(const S of d){const T=S.markdown||S.content||"";if(T.includes("((")){const x=ka(T);for(const _ of x)h.add(_.blockId)}}const k={};if(h.size>0){const S=Array.from(h).map(x=>`'${x}'`).join(","),T=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${S})`).catch(()=>[])||[];if(Array.isArray(T))for(const x of T)x.id&&(k[x.id]=x.markdown||x.content||"")}const b=this.deps.getBaseUrl?this.deps.getBaseUrl():"",y=Ms(i,e,d,{baseUrl:b,refContentMap:k});try{const S=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;y.customThemeCss=on(S)}catch{y.customThemeCss=on(null)}return y}catch(e){console.error("[DocumentCompilerService] Failed to compile document:",e);const n=Ms(i,{},[],{});return n.customThemeCss=on(null),n}}}const Rt=new Wa;class ts{constructor(i){yt(this,"devServerUrl","http://localhost:3030");yt(this,"isConnected",!1);yt(this,"lastSyncTime",null);i&&(this.devServerUrl=i)}getUrl(){return this.devServerUrl}setUrl(i){this.devServerUrl=i.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(i=1500){try{const e=new AbortController,n=setTimeout(()=>e.abort(),i),o=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:e.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!o,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(i){const e=i.config,n=["---",`theme: ${e.theme||"default"}`,`aspectRatio: "${e.aspectRatio||"16/9"}"`,`highlighter: ${e.highlighter||"shiki"}`,`transition: ${e.defaultTransition||"slide-left"}`];e.colorSchema&&e.colorSchema!=="auto"&&n.push(`colorSchema: ${e.colorSchema}`),n.push("drawings:","  persist: false","---","");const o=n.join(`
`),r=i.slides.map((l,s)=>{const a=l.frontmatter||{},c=[],d=s===0;a.layout&&a.layout!=="default"&&c.push(`layout: ${a.layout}`),a.transition&&c.push(`transition: ${a.transition}`),a.background&&c.push(`background: ${a.background}`),a.class&&c.push(`class: "${a.class}"`);let p="";c.length>0?p=d?"":`---
${c.join(`
`)}
---

`:d||(p=`---

`);let g="";if(a.layout==="two-cols"){const w=l.blocks.filter(y=>y.slot!=="right"),h=l.blocks.filter(y=>y.slot==="right"),k=w.map(y=>y.rawMarkdown||y.content||"").join(`

`),b=h.map(y=>y.rawMarkdown||y.content||"").join(`

`);g=`${k}

::right::

${b}`}else g=l.blocks.map(w=>w.rawMarkdown||w.content||"").join(`

`);let u="";return l.notes&&l.notes.trim()&&(u=`

<!--
${l.notes.trim()}
-->`),`${p}${g}${u}`}).join(`

`);return`${o}${r}
`}async syncToWorkspaceFile(i,e="/data/storage/petal/siyuan-slidev/slides.md",n){const o=this.buildStandardSlidevMarkdown(i);if(this.lastSyncTime=Date.now(),n)try{const r=typeof Blob<"u"?new Blob([o],{type:"text/markdown;charset=utf-8"}):Buffer.from(o,"utf-8");return await n(e,!1,r),{success:!0,path:e}}catch(r){return{success:!1,path:e,error:String(r)}}return{success:!0,path:e}}downloadSlidesMd(i,e="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(i),o=new Blob([n],{type:"text/markdown;charset=utf-8"}),r=URL.createObjectURL(o),l=document.createElement("a");return l.href=r,l.download=e,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(r),!0}}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function es(t){const i=Object.create(null);for(const e of t.split(","))i[e]=1;return e=>e in i}const Nt={},Oi=[],Fe=()=>{},Ar=()=>!1,no=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&(t.charCodeAt(2)>122||t.charCodeAt(2)<97),oo=t=>t.startsWith("onUpdate:"),ee=Object.assign,is=(t,i)=>{const e=t.indexOf(i);e>-1&&t.splice(e,1)},Va=Object.prototype.hasOwnProperty,Bt=(t,i)=>Va.call(t,i),St=Array.isArray,Pi=t=>xn(t)==="[object Map]",Ki=t=>xn(t)==="[object Set]",Ds=t=>xn(t)==="[object Date]",$t=t=>typeof t=="function",qt=t=>typeof t=="string",Ae=t=>typeof t=="symbol",Pt=t=>t!==null&&typeof t=="object",Tr=t=>(Pt(t)||$t(t))&&$t(t.then)&&$t(t.catch),Er=Object.prototype.toString,xn=t=>Er.call(t),Ka=t=>xn(t).slice(8,-1),Br=t=>xn(t)==="[object Object]",ns=t=>qt(t)&&t!=="NaN"&&t[0]!=="-"&&""+parseInt(t,10)===t,sn=es(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),so=t=>{const i=Object.create(null);return(e=>i[e]||(i[e]=t(e)))},qa=/-\w/g,ce=so(t=>t.replace(qa,i=>i.slice(1).toUpperCase())),Ga=/\B([A-Z])/g,ci=so(t=>t.replace(Ga,"-$1").toLowerCase()),ro=so(t=>t.charAt(0).toUpperCase()+t.slice(1)),wo=so(t=>t?`on${ro(t)}`:""),Re=(t,i)=>!Object.is(t,i),Pn=(t,...i)=>{for(let e=0;e<t.length;e++)t[e](...i)},Mr=(t,i,e,n=!1)=>{Object.defineProperty(t,i,{configurable:!0,enumerable:!1,writable:n,value:e})},lo=t=>{const i=parseFloat(t);return isNaN(i)?t:i};let Ls;const ao=()=>Ls||(Ls=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function os(t){if(St(t)){const i={};for(let e=0;e<t.length;e++){const n=t[e],o=qt(n)?Xa(n):os(n);if(o)for(const r in o)i[r]=o[r]}return i}else if(qt(t)||Pt(t))return t}const Za=/;(?![^(]*\))/g,Ya=/:([^]+)/,Ja=/\/\*[^]*?\*\//g;function Xa(t){const i={};return t.replace(Ja,"").split(Za).forEach(e=>{if(e){const n=e.split(Ya);n.length>1&&(i[n[0].trim()]=n[1].trim())}}),i}function Ct(t){let i="";if(qt(t))i=t;else if(St(t))for(let e=0;e<t.length;e++){const n=Ct(t[e]);n&&(i+=n+" ")}else if(Pt(t))for(const e in t)t[e]&&(i+=e+" ");return i.trim()}const Qa="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",tc=es(Qa);function Dr(t){return!!t||t===""}function ec(t,i){if(t.length!==i.length)return!1;let e=!0;for(let n=0;e&&n<t.length;n++)e=qi(t[n],i[n]);return e}function qi(t,i){if(t===i)return!0;let e=Ds(t),n=Ds(i);if(e||n)return e&&n?t.getTime()===i.getTime():!1;if(e=Ae(t),n=Ae(i),e||n)return t===i;if(e=St(t),n=St(i),e||n)return e&&n?ec(t,i):!1;if(e=Pt(t),n=Pt(i),e||n){if(!e||!n)return!1;const o=Object.keys(t).length,r=Object.keys(i).length;if(o!==r)return!1;for(const l in t){const s=t.hasOwnProperty(l),a=i.hasOwnProperty(l);if(s&&!a||!s&&a||!qi(t[l],i[l]))return!1}}return String(t)===String(i)}function ss(t,i){return t.findIndex(e=>qi(e,i))}const Lr=t=>!!(t&&t.__v_isRef===!0),xt=t=>qt(t)?t:t==null?"":St(t)||Pt(t)&&(t.toString===Er||!$t(t.toString))?Lr(t)?xt(t.value):JSON.stringify(t,Or,2):String(t),Or=(t,i)=>Lr(i)?Or(t,i.value):Pi(i)?{[`Map(${i.size})`]:[...i.entries()].reduce((e,[n,o],r)=>(e[xo(n,r)+" =>"]=o,e),{})}:Ki(i)?{[`Set(${i.size})`]:[...i.values()].map(e=>xo(e))}:Ae(i)?xo(i):Pt(i)&&!St(i)&&!Br(i)?String(i):i,xo=(t,i="")=>{var e;return Ae(t)?`Symbol(${(e=t.description)!=null?e:i})`:t};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Jt;class ic{constructor(i=!1){this.detached=i,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!i&&Jt&&(Jt.active?(this.parent=Jt,this.index=(Jt.scopes||(Jt.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let i,e;if(this.scopes){const n=this.scopes.slice();for(i=0,e=n.length;i<e;i++)n[i].pause()}for(i=0,e=this.effects.length;i<e;i++)this.effects[i].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let i,e;if(this.scopes){const o=this.scopes.slice();for(i=0,e=o.length;i<e;i++)o[i].resume()}const n=this.effects.slice();for(i=0,e=n.length;i<e;i++)n[i].resume()}}run(i){if(this._active){const e=Jt;try{return Jt=this,i()}finally{Jt=e}}}on(){++this._on===1&&(this.prevScope=Jt,Jt=this)}off(){if(this._on>0&&--this._on===0){if(Jt===this)Jt=this.prevScope;else{let i=Jt;for(;i;){if(i.prevScope===this){i.prevScope=this.prevScope;break}i=i.prevScope}}this.prevScope=void 0}}stop(i){if(this._active){this._active=!1;let e,n;for(e=0,n=this.effects.length;e<n;e++)this.effects[e].stop();for(this.effects.length=0,e=0,n=this.cleanups.length;e<n;e++)this.cleanups[e]();if(this.cleanups.length=0,this.scopes){const o=this.scopes.slice();for(e=0,n=o.length;e<n;e++)o[e].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!i){const o=this.parent.scopes.pop();o&&o!==this&&(this.parent.scopes[this.index]=o,o.index=this.index)}this.parent=void 0}}}function nc(){return Jt}let Ft;const _o=new WeakSet;class Pr{constructor(i){this.fn=i,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,Jt&&(Jt.active?Jt.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,_o.has(this)&&(_o.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||zr(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Os(this),Nr(this);const i=Ft,e=Ie;Ft=this,Ie=!0;try{return this.fn()}finally{Fr(this),Ft=i,Ie=e,this.flags&=-3}}stop(){if(this.flags&1){for(let i=this.deps;i;i=i.nextDep)as(i);this.deps=this.depsTail=void 0,Os(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?_o.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){No(this)&&this.run()}get dirty(){return No(this)}}let Rr=0,rn,ln;function zr(t,i=!1){if(t.flags|=8,i){t.next=ln,ln=t;return}t.next=rn,rn=t}function rs(){Rr++}function ls(){if(--Rr>0)return;if(ln){let i=ln;for(ln=void 0;i;){const e=i.next;i.next=void 0,i.flags&=-9,i=e}}let t;for(;rn;){let i=rn;for(rn=void 0;i;){const e=i.next;if(i.next=void 0,i.flags&=-9,i.flags&1)try{i.trigger()}catch(n){t||(t=n)}i=e}}if(t)throw t}function Nr(t){for(let i=t.deps;i;i=i.nextDep)i.version=-1,i.prevActiveLink=i.dep.activeLink,i.dep.activeLink=i}function Fr(t){let i,e=t.depsTail,n=e;for(;n;){const o=n.prevDep;n.version===-1?(n===e&&(e=o),as(n),oc(n)):i=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=o}t.deps=i,t.depsTail=e}function No(t){for(let i=t.deps;i;i=i.nextDep)if(i.dep.version!==i.version||i.dep.computed&&(jr(i.dep.computed)||i.dep.version!==i.version))return!0;return!!t._dirty}function jr(t){if(t.flags&4&&!(t.flags&16)||(t.flags&=-17,t.globalVersion===mn)||(t.globalVersion=mn,!t.isSSR&&t.flags&128&&(!t.deps&&!t._dirty||!No(t))))return;t.flags|=2;const i=t.dep,e=Ft,n=Ie;Ft=t,Ie=!0;try{Nr(t);const o=t.fn(t._value);(i.version===0||Re(o,t._value))&&(t.flags|=128,t._value=o,i.version++)}catch(o){throw i.version++,o}finally{Ft=e,Ie=n,Fr(t),t.flags&=-3}}function as(t,i=!1){const{dep:e,prevSub:n,nextSub:o}=t;if(n&&(n.nextSub=o,t.prevSub=void 0),o&&(o.prevSub=n,t.nextSub=void 0),e.subs===t&&(e.subs=n,!n&&e.computed)){e.computed.flags&=-5;for(let r=e.computed.deps;r;r=r.nextDep)as(r,!0)}!i&&!--e.sc&&e.map&&e.map.delete(e.key)}function oc(t){const{prevDep:i,nextDep:e}=t;i&&(i.nextDep=e,t.prevDep=void 0),e&&(e.prevDep=i,t.nextDep=void 0)}let Ie=!0;const Hr=[];function Je(){Hr.push(Ie),Ie=!1}function Xe(){const t=Hr.pop();Ie=t===void 0?!0:t}function Os(t){const{cleanup:i}=t;if(t.cleanup=void 0,i){const e=Ft;Ft=void 0;try{i()}finally{Ft=e}}}let mn=0;class sc{constructor(i,e){this.sub=i,this.dep=e,this.version=e.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class cs{constructor(i){this.computed=i,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(i){if(!Ft||!Ie||Ft===this.computed)return;let e=this.activeLink;if(e===void 0||e.sub!==Ft)e=this.activeLink=new sc(Ft,this),Ft.deps?(e.prevDep=Ft.depsTail,Ft.depsTail.nextDep=e,Ft.depsTail=e):Ft.deps=Ft.depsTail=e,Ur(e);else if(e.version===-1&&(e.version=this.version,e.nextDep)){const n=e.nextDep;n.prevDep=e.prevDep,e.prevDep&&(e.prevDep.nextDep=n),e.prevDep=Ft.depsTail,e.nextDep=void 0,Ft.depsTail.nextDep=e,Ft.depsTail=e,Ft.deps===e&&(Ft.deps=n)}return e}trigger(i){this.version++,mn++,this.notify(i)}notify(i){rs();try{for(let e=this.subs;e;e=e.prevSub)e.sub.notify()&&e.sub.dep.notify()}finally{ls()}}}function Ur(t){if(t.dep.sc++,t.sub.flags&4){const i=t.dep.computed;if(i&&!t.dep.subs){i.flags|=20;for(let n=i.deps;n;n=n.nextDep)Ur(n)}const e=t.dep.subs;e!==t&&(t.prevSub=e,e&&(e.nextSub=t)),t.dep.subs=t}}const Fo=new WeakMap,wi=Symbol(""),jo=Symbol(""),gn=Symbol("");function ne(t,i,e){if(Ie&&Ft){let n=Fo.get(t);n||Fo.set(t,n=new Map);let o=n.get(e);o||(n.set(e,o=new cs),o.map=n,o.key=e),o.track()}}function Ke(t,i,e,n,o,r){const l=Fo.get(t);if(!l){mn++;return}const s=a=>{a&&a.trigger()};if(rs(),i==="clear")l.forEach(s);else{const a=St(t),c=a&&ns(e);if(a&&e==="length"){const d=Number(n);l.forEach((p,g)=>{(g==="length"||g===gn||!Ae(g)&&g>=d)&&s(p)})}else switch((e!==void 0||l.has(void 0))&&s(l.get(e)),c&&s(l.get(gn)),i){case"add":a?c&&s(l.get("length")):(s(l.get(wi)),Pi(t)&&s(l.get(jo)));break;case"delete":a||(s(l.get(wi)),Pi(t)&&s(l.get(jo)));break;case"set":Pi(t)&&s(l.get(wi));break}}ls()}function Ei(t){const i=Et(t);return i===t?i:(ne(i,"iterate",gn),we(t)?i:i.map(Te))}function co(t){return ne(t=Et(t),"iterate",gn),t}function Oe(t,i){return Qe(t)?Hi(xi(t)?Te(i):i):Te(i)}const rc={__proto__:null,[Symbol.iterator](){return So(this,Symbol.iterator,t=>Oe(this,t))},concat(...t){return Ei(this).concat(...t.map(i=>St(i)?Ei(i):i))},entries(){return So(this,"entries",t=>(t[1]=Oe(this,t[1]),t))},every(t,i){return He(this,"every",t,i,void 0,arguments)},filter(t,i){return He(this,"filter",t,i,e=>e.map(n=>Oe(this,n)),arguments)},find(t,i){return He(this,"find",t,i,e=>Oe(this,e),arguments)},findIndex(t,i){return He(this,"findIndex",t,i,void 0,arguments)},findLast(t,i){return He(this,"findLast",t,i,e=>Oe(this,e),arguments)},findLastIndex(t,i){return He(this,"findLastIndex",t,i,void 0,arguments)},forEach(t,i){return He(this,"forEach",t,i,void 0,arguments)},includes(...t){return Co(this,"includes",t)},indexOf(...t){return Co(this,"indexOf",t)},join(t){return Ei(this).join(t)},lastIndexOf(...t){return Co(this,"lastIndexOf",t)},map(t,i){return He(this,"map",t,i,void 0,arguments)},pop(){return Yi(this,"pop")},push(...t){return Yi(this,"push",t)},reduce(t,...i){return Ps(this,"reduce",t,i)},reduceRight(t,...i){return Ps(this,"reduceRight",t,i)},shift(){return Yi(this,"shift")},some(t,i){return He(this,"some",t,i,void 0,arguments)},splice(...t){return Yi(this,"splice",t)},toReversed(){return Ei(this).toReversed()},toSorted(t){return Ei(this).toSorted(t)},toSpliced(...t){return Ei(this).toSpliced(...t)},unshift(...t){return Yi(this,"unshift",t)},values(){return So(this,"values",t=>Oe(this,t))}};function So(t,i,e){const n=co(t),o=n[i]();return n!==t&&!we(t)&&(o._next=o.next,o.next=()=>{const r=o._next();return r.done||(r.value=e(r.value)),r}),o}const lc=Array.prototype;function He(t,i,e,n,o,r){const l=co(t),s=l!==t&&!we(t),a=l[i];if(a!==lc[i]){const p=a.apply(t,r);return s?Te(p):p}let c=e;l!==t&&(s?c=function(p,g){return e.call(this,Oe(t,p),g,t)}:e.length>2&&(c=function(p,g){return e.call(this,p,g,t)}));const d=a.call(l,c,n);return s&&o?o(d):d}function Ps(t,i,e,n){const o=co(t),r=o!==t&&!we(t);let l=e,s=!1;o!==t&&(r?(s=n.length===0,l=function(c,d,p){return s&&(s=!1,c=Oe(t,c)),e.call(this,c,Oe(t,d),p,t)}):e.length>3&&(l=function(c,d,p){return e.call(this,c,d,p,t)}));const a=o[i](l,...n);return s?Oe(t,a):a}function Co(t,i,e){const n=Et(t);ne(n,"iterate",gn);const o=n[i](...e);return(o===-1||o===!1)&&fs(e[0])?(e[0]=Et(e[0]),n[i](...e)):o}function Yi(t,i,e=[]){Je(),rs();const n=Et(t)[i].apply(t,e);return ls(),Xe(),n}const ac=es("__proto__,__v_isRef,__isVue"),Wr=new Set(Object.getOwnPropertyNames(Symbol).filter(t=>t!=="arguments"&&t!=="caller").map(t=>Symbol[t]).filter(Ae));function cc(t){Ae(t)||(t=String(t));const i=Et(this);return ne(i,"has",t),i.hasOwnProperty(t)}class Vr{constructor(i=!1,e=!1){this._isReadonly=i,this._isShallow=e}get(i,e,n){if(e==="__v_skip")return i.__v_skip;const o=this._isReadonly,r=this._isShallow;if(e==="__v_isReactive")return!o;if(e==="__v_isReadonly")return o;if(e==="__v_isShallow")return r;if(e==="__v_raw")return n===(o?r?yc:Zr:r?Gr:qr).get(i)||Object.getPrototypeOf(i)===Object.getPrototypeOf(n)?i:void 0;const l=St(i);if(!o){let a;if(l&&(a=rc[e]))return a;if(e==="hasOwnProperty")return cc}const s=Reflect.get(i,e,re(i)?i:n);if((Ae(e)?Wr.has(e):ac(e))||(o||ne(i,"get",e),r))return s;if(re(s)){const a=l&&ns(e)?s:s.value;return o&&Pt(a)?Uo(a):a}return Pt(s)?o?Uo(s):uo(s):s}}class Kr extends Vr{constructor(i=!1){super(!1,i)}set(i,e,n,o){let r=i[e];const l=St(i)&&ns(e);if(!this._isShallow){const c=Qe(r);if(!we(n)&&!Qe(n)&&(r=Et(r),n=Et(n)),!l&&re(r)&&!re(n))return c||(r.value=n),!0}const s=l?Number(e)<i.length:Bt(i,e),a=Reflect.set(i,e,n,re(i)?i:o);return i===Et(o)&&a&&(s?Re(n,r)&&Ke(i,"set",e,n):Ke(i,"add",e,n)),a}deleteProperty(i,e){const n=Bt(i,e);i[e];const o=Reflect.deleteProperty(i,e);return o&&n&&Ke(i,"delete",e,void 0),o}has(i,e){const n=Reflect.has(i,e);return(!Ae(e)||!Wr.has(e))&&ne(i,"has",e),n}ownKeys(i){return ne(i,"iterate",St(i)?"length":wi),Reflect.ownKeys(i)}}class dc extends Vr{constructor(i=!1){super(!0,i)}set(i,e){return!0}deleteProperty(i,e){return!0}}const uc=new Kr,fc=new dc,pc=new Kr(!0);const Ho=t=>t,Tn=t=>Reflect.getPrototypeOf(t);function hc(t,i,e){return function(...n){const o=this.__v_raw,r=Et(o),l=Pi(r),s=t==="entries"||t===Symbol.iterator&&l,a=t==="keys"&&l,c=o[t](...n),d=e?Ho:i?Hi:Te;return!i&&ne(r,"iterate",a?jo:wi),ee(Object.create(c),{next(){const{value:p,done:g}=c.next();return g?{value:p,done:g}:{value:s?[d(p[0]),d(p[1])]:d(p),done:g}}})}}function En(t){return function(...i){return t==="delete"?!1:t==="clear"?void 0:this}}function mc(t,i){const e={get(o){const r=this.__v_raw,l=Et(r),s=Et(o);t||(Re(o,s)&&ne(l,"get",o),ne(l,"get",s));const{has:a}=Tn(l),c=i?Ho:t?Hi:Te;if(a.call(l,o))return c(r.get(o));if(a.call(l,s))return c(r.get(s));r!==l&&r.get(o)},get size(){const o=this.__v_raw;return!t&&ne(Et(o),"iterate",wi),o.size},has(o){const r=this.__v_raw,l=Et(r),s=Et(o);return t||(Re(o,s)&&ne(l,"has",o),ne(l,"has",s)),o===s?r.has(o):r.has(o)||r.has(s)},forEach(o,r){const l=this,s=l.__v_raw,a=Et(s),c=i?Ho:t?Hi:Te;return!t&&ne(a,"iterate",wi),s.forEach((d,p)=>o.call(r,c(d),c(p),l))}};return ee(e,t?{add:En("add"),set:En("set"),delete:En("delete"),clear:En("clear")}:{add(o){const r=Et(this),l=Tn(r),s=Et(o),a=!i&&!we(o)&&!Qe(o)?s:o;return l.has.call(r,a)||Re(o,a)&&l.has.call(r,o)||Re(s,a)&&l.has.call(r,s)||(r.add(a),Ke(r,"add",a,a)),this},set(o,r){!i&&!we(r)&&!Qe(r)&&(r=Et(r));const l=Et(this),{has:s,get:a}=Tn(l);let c=s.call(l,o);c||(o=Et(o),c=s.call(l,o));const d=a.call(l,o);return l.set(o,r),c?Re(r,d)&&Ke(l,"set",o,r):Ke(l,"add",o,r),this},delete(o){const r=Et(this),{has:l,get:s}=Tn(r);let a=l.call(r,o);a||(o=Et(o),a=l.call(r,o)),s&&s.call(r,o);const c=r.delete(o);return a&&Ke(r,"delete",o,void 0),c},clear(){const o=Et(this),r=o.size!==0,l=o.clear();return r&&Ke(o,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(o=>{e[o]=hc(o,t,i)}),e}function ds(t,i){const e=mc(t,i);return(n,o,r)=>o==="__v_isReactive"?!t:o==="__v_isReadonly"?t:o==="__v_raw"?n:Reflect.get(Bt(e,o)&&o in n?e:n,o,r)}const gc={get:ds(!1,!1)},vc={get:ds(!1,!0)},bc={get:ds(!0,!1)};const qr=new WeakMap,Gr=new WeakMap,Zr=new WeakMap,yc=new WeakMap;function kc(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function uo(t){return Qe(t)?t:us(t,!1,uc,gc,qr)}function wc(t){return us(t,!1,pc,vc,Gr)}function Uo(t){return us(t,!0,fc,bc,Zr)}function us(t,i,e,n,o){if(!Pt(t)||t.__v_raw&&!(i&&t.__v_isReactive)||t.__v_skip||!Object.isExtensible(t))return t;const r=o.get(t);if(r)return r;const l=kc(Ka(t));if(l===0)return t;const s=new Proxy(t,l===2?n:e);return o.set(t,s),s}function xi(t){return Qe(t)?xi(t.__v_raw):!!(t&&t.__v_isReactive)}function Qe(t){return!!(t&&t.__v_isReadonly)}function we(t){return!!(t&&t.__v_isShallow)}function fs(t){return t?!!t.__v_raw:!1}function Et(t){const i=t&&t.__v_raw;return i?Et(i):t}function xc(t){return!Bt(t,"__v_skip")&&Object.isExtensible(t)&&Mr(t,"__v_skip",!0),t}const Te=t=>Pt(t)?uo(t):t,Hi=t=>Pt(t)?Uo(t):t;function re(t){return t?t.__v_isRef===!0:!1}function ht(t){return _c(t,!1)}function _c(t,i){return re(t)?t:new Sc(t,i)}class Sc{constructor(i,e){this.dep=new cs,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=e?i:Et(i),this._value=e?i:Te(i),this.__v_isShallow=e}get value(){return this.dep.track(),this._value}set value(i){const e=this._rawValue,n=this.__v_isShallow||we(i)||Qe(i);i=n?i:Et(i),Re(i,e)&&(this._rawValue=i,this._value=n?i:Te(i),this.dep.trigger())}}function Tt(t){return re(t)?t.value:t}const Cc={get:(t,i,e)=>i==="__v_raw"?t:Tt(Reflect.get(t,i,e)),set:(t,i,e,n)=>{const o=t[i];return re(o)&&!re(e)?(o.value=e,!0):Reflect.set(t,i,e,n)}};function Yr(t){return xi(t)?t:new Proxy(t,Cc)}class $c{constructor(i,e,n){this.fn=i,this.setter=e,this._value=void 0,this.dep=new cs(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=mn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!e,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Ft!==this)return zr(this,!0),!0}get value(){const i=this.dep.track();return jr(this),i&&(i.version=this.dep.version),this._value}set value(i){this.setter&&this.setter(i)}}function Ic(t,i,e=!1){let n,o;return $t(t)?n=t:(n=t.get,o=t.set),new $c(n,o,e)}const Bn={},Gn=new WeakMap;let gi;function Ac(t,i=!1,e=gi){if(e){let n=Gn.get(e);n||Gn.set(e,n=[]),n.push(t)}}function Tc(t,i,e=Nt){const{immediate:n,deep:o,once:r,scheduler:l,augmentJob:s,call:a}=e,c=T=>o?T:we(T)||o===!1||o===0?qe(T,1):qe(T);let d,p,g,u,w=!1,h=!1;if(re(t)?(p=()=>t.value,w=we(t)):xi(t)?(p=()=>c(t),w=!0):St(t)?(h=!0,w=t.some(T=>xi(T)||we(T)),p=()=>t.map(T=>{if(re(T))return T.value;if(xi(T))return c(T);if($t(T))return a?a(T,2):T()})):$t(t)?i?p=a?()=>a(t,2):t:p=()=>{if(g){Je();try{g()}finally{Xe()}}const T=gi;gi=d;try{return a?a(t,3,[u]):t(u)}finally{gi=T}}:p=Fe,i&&o){const T=p,x=o===!0?1/0:o;p=()=>qe(T(),x)}const k=nc(),b=()=>{d.stop(),k&&k.active&&is(k.effects,d)};if(r&&i){const T=i;i=(...x)=>{const _=T(...x);return b(),_}}let y=h?new Array(t.length).fill(Bn):Bn;const S=T=>{if(!(!(d.flags&1)||!d.dirty&&!T))if(i){const x=d.run();if(T||o||w||(h?x.some((_,C)=>Re(_,y[C])):Re(x,y))){g&&g();const _=gi;gi=d;try{const C=[x,y===Bn?void 0:h&&y[0]===Bn?[]:y,u];y=x,a?a(i,3,C):i(...C)}finally{gi=_}}}else d.run()};return s&&s(S),d=new Pr(p),d.scheduler=l?()=>l(S,!1):S,u=T=>Ac(T,!1,d),g=d.onStop=()=>{const T=Gn.get(d);if(T){if(a)a(T,4);else for(const x of T)x();Gn.delete(d)}},i?n?S(!0):y=d.run():l?l(S.bind(null,!0),!0):d.run(),b.pause=d.pause.bind(d),b.resume=d.resume.bind(d),b.stop=b,b}function qe(t,i=1/0,e){if(i<=0||!Pt(t)||t.__v_skip||(e=e||new Map,(e.get(t)||0)>=i))return t;if(e.set(t,i),i--,re(t))qe(t.value,i,e);else if(St(t))for(let n=0;n<t.length;n++)qe(t[n],i,e);else if(Ki(t)||Pi(t))t.forEach(n=>{qe(n,i,e)});else if(Br(t)){for(const n in t)qe(t[n],i,e);for(const n of Object.getOwnPropertySymbols(t))Object.prototype.propertyIsEnumerable.call(t,n)&&qe(t[n],i,e)}return t}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function _n(t,i,e,n){try{return n?t(...n):t()}catch(o){fo(o,i,e)}}function Ee(t,i,e,n){if($t(t)){const o=_n(t,i,e,n);return o&&Tr(o)&&o.catch(r=>{fo(r,i,e)}),o}if(St(t)){const o=[];for(let r=0;r<t.length;r++)o.push(Ee(t[r],i,e,n));return o}}function fo(t,i,e,n=!0){const o=i?i.vnode:null,{errorHandler:r,throwUnhandledErrorInProduction:l}=i&&i.appContext.config||Nt;if(i){let s=i.parent;const a=i.proxy,c=`https://vuejs.org/error-reference/#runtime-${e}`;for(;s;){const d=s.ec;if(d){for(let p=0;p<d.length;p++)if(d[p](t,a,c)===!1)return}s=s.parent}if(r){Je(),_n(r,null,10,[t,a,c]),Xe();return}}Ec(t,e,o,n,l)}function Ec(t,i,e,n=!0,o=!1){if(o)throw t;console.error(t)}const ae=[];let Le=-1;const Ri=[];let ni=null,Bi=0;const Jr=Promise.resolve();let Zn=null;function Xr(t){const i=Zn||Jr;return t?i.then(this?t.bind(this):t):i}function Bc(t){let i=Le+1,e=ae.length;for(;i<e;){const n=i+e>>>1,o=ae[n],r=vn(o);r<t||r===t&&o.flags&2?i=n+1:e=n}return i}function ps(t){if(!(t.flags&1)){const i=vn(t),e=ae[ae.length-1];!e||!(t.flags&2)&&i>=vn(e)?ae.push(t):ae.splice(Bc(i),0,t),t.flags|=1,Qr()}}function Qr(){Zn||(Zn=Jr.then(el))}function Mc(t){St(t)?Ri.push(...t):ni&&t.id===-1?ni.splice(Bi+1,0,t):t.flags&1||(Ri.push(t),t.flags|=1),Qr()}function Rs(t,i,e=Le+1){for(;e<ae.length;e++){const n=ae[e];if(n&&n.flags&2){if(t&&n.id!==t.uid)continue;ae.splice(e,1),e--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function tl(t){if(Ri.length){const i=[...new Set(Ri)].sort((e,n)=>vn(e)-vn(n));if(Ri.length=0,ni){ni.push(...i);return}for(ni=i,Bi=0;Bi<ni.length;Bi++){const e=ni[Bi];e.flags&4&&(e.flags&=-2),e.flags&8||e(),e.flags&=-2}ni=null,Bi=0}}const vn=t=>t.id==null?t.flags&2?-1:1/0:t.id;function el(t){try{for(Le=0;Le<ae.length;Le++){const i=ae[Le];i&&!(i.flags&8)&&(i.flags&4&&(i.flags&=-2),_n(i,i.i,i.i?15:14),i.flags&4||(i.flags&=-2))}}finally{for(;Le<ae.length;Le++){const i=ae[Le];i&&(i.flags&=-2)}Le=-1,ae.length=0,tl(),Zn=null,(ae.length||Ri.length)&&el()}}let te=null,il=null;function Yn(t){const i=te;return te=t,il=t&&t.type.__scopeId||null,i}function nl(t,i=te,e){if(!i||t._n)return t;const n=(...o)=>{n._d&&Zs(-1);const r=Yn(i),l=Ze.length;let s;try{s=t(...o)}finally{for(let a=Ze.length;a>l;a--)ys();Yn(r),n._d&&Zs(1)}return s};return n._n=!0,n._c=!0,n._d=!0,n}function _e(t,i){if(te===null)return t;const e=go(te),n=t.dirs||(t.dirs=[]);for(let o=0;o<i.length;o++){let[r,l,s,a=Nt]=i[o];r&&($t(r)&&(r={mounted:r,updated:r}),r.deep&&qe(l),n.push({dir:r,instance:e,value:l,oldValue:void 0,arg:s,modifiers:a}))}return t}function pi(t,i,e,n){const o=t.dirs,r=i&&i.dirs;for(let l=0;l<o.length;l++){const s=o[l];r&&(s.oldValue=r[l].value);let a=s.dir[n];a&&(Je(),Ee(a,e,8,[t.el,s,t,i]),Xe())}}function Dc(t,i){if(oe){let e=oe.provides;const n=oe.parent&&oe.parent.provides;n===e&&(e=oe.provides=Object.create(n)),e[t]=i}}function Ge(t,i,e=!1){const n=Bd();if(n||Ni){let o=Ni?Ni._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(o&&t in o)return o[t];if(arguments.length>1)return e&&$t(i)?i.call(n&&n.proxy):i}}const Lc=Symbol.for("v-scx"),Oc=()=>Ge(Lc);function _i(t,i,e){return ol(t,i,e)}function ol(t,i,e=Nt){const{immediate:n,deep:o,flush:r,once:l}=e,s=ee({},e),a=i&&n||!i&&r!=="post";let c;if(yn){if(r==="sync"){const u=Oc();c=u.__watcherHandles||(u.__watcherHandles=[])}else if(!a){const u=()=>{};return u.stop=Fe,u.resume=Fe,u.pause=Fe,u}}const d=oe;s.call=(u,w,h)=>Ee(u,d,w,h);let p=!1;r==="post"?s.scheduler=u=>{ue(u,d&&d.suspense)}:r!=="sync"&&(p=!0,s.scheduler=(u,w)=>{w?u():ps(u)}),s.augmentJob=u=>{i&&(u.flags|=4),p&&(u.flags|=2,d&&(u.id=d.uid,u.i=d))};const g=Tc(t,i,s);return yn&&(c?c.push(g):a&&g()),g}function Pc(t,i,e){const n=this.proxy,o=qt(t)?t.includes(".")?sl(n,t):()=>n[t]:t.bind(n,n);let r;$t(i)?r=i:(r=i.handler,e=i);const l=Cn(this),s=ol(o,r.bind(n),e);return l(),s}function sl(t,i){const e=i.split(".");return()=>{let n=t;for(let o=0;o<e.length&&n;o++)n=n[e[o]];return n}}const Rc=Symbol("_vte"),zc=t=>t.__isTeleport,$o=Symbol("_leaveCb");function hs(t,i){t.shapeFlag&6&&t.component?(t.transition=i,hs(t.component.subTree,i)):t.shapeFlag&128?(t.ssContent.transition=i.clone(t.ssContent),t.ssFallback.transition=i.clone(t.ssFallback)):t.transition=i}function he(t,i){return $t(t)?ee({name:t.name},i,{setup:t}):t}function rl(t){t.ids=[t.ids[0]+t.ids[2]+++"-",0,0]}function zs(t,i){let e;return!!((e=Object.getOwnPropertyDescriptor(t,i))&&!e.configurable)}const Jn=new WeakMap;function an(t,i,e,n,o=!1){if(St(t)){t.forEach((h,k)=>an(h,i&&(St(i)?i[k]:i),e,n,o));return}if(zi(n)&&!o){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&an(t,i,e,n.component.subTree);return}const r=n.shapeFlag&4?go(n.component):n.el,l=o?null:r,{i:s,r:a}=t,c=i&&i.r,d=s.refs===Nt?s.refs={}:s.refs,p=s.setupState,g=Et(p),u=p===Nt?Ar:h=>zs(d,h)?!1:Bt(g,h),w=(h,k)=>!(k&&zs(d,k));if(c!=null&&c!==a){if(Ns(i),qt(c))d[c]=null,u(c)&&(p[c]=null);else if(re(c)){const h=i;w(c,h.k)&&(c.value=null),h.k&&(d[h.k]=null)}}if($t(a))_n(a,s,12,[l,d]);else{const h=qt(a),k=re(a);if(h||k){const b=()=>{if(t.f){const y=h?u(a)?p[a]:d[a]:w()||!t.k?a.value:d[t.k];if(o)St(y)&&is(y,r);else if(St(y))y.includes(r)||y.push(r);else if(h)d[a]=[r],u(a)&&(p[a]=d[a]);else{const S=[r];w(a,t.k)&&(a.value=S),t.k&&(d[t.k]=S)}}else h?(d[a]=l,u(a)&&(p[a]=l)):k&&(w(a,t.k)&&(a.value=l),t.k&&(d[t.k]=l))};if(l){const y=()=>{b(),Jn.delete(t)};y.id=-1,Jn.set(t,y),ue(y,e)}else Ns(t),b()}}}function Ns(t){const i=Jn.get(t);i&&(i.flags|=8,Jn.delete(t))}ao().requestIdleCallback;ao().cancelIdleCallback;const zi=t=>!!t.type.__asyncLoader,ll=t=>t.type.__isKeepAlive;function Nc(t,i){al(t,"a",i)}function Fc(t,i){al(t,"da",i)}function al(t,i,e=oe){const n=t.__wdc||(t.__wdc=()=>{let o=e;for(;o;){if(o.isDeactivated)return;o=o.parent}return t()});if(po(i,n,e),e){let o=e.parent;for(;o&&o.parent;)ll(o.parent.vnode)&&jc(n,i,e,o),o=o.parent}}function jc(t,i,e,n){const o=po(i,t,n,!0);gs(()=>{is(n[i],o)},e)}function po(t,i,e=oe,n=!1){if(e){const o=e[t]||(e[t]=[]),r=i.__weh||(i.__weh=(...l)=>{Je();const s=Cn(e),a=Ee(i,e,t,l);return s(),Xe(),a});return n?o.unshift(r):o.push(r),r}}const ei=t=>(i,e=oe)=>{(!yn||t==="sp")&&po(t,(...n)=>i(...n),e)},Hc=ei("bm"),Sn=ei("m"),Uc=ei("bu"),Wc=ei("u"),ms=ei("bum"),gs=ei("um"),Vc=ei("sp"),Kc=ei("rtg"),qc=ei("rtc");function Gc(t,i=oe){po("ec",t,i)}const Zc="components";function Yc(t,i){return Xc(Zc,t,!0,i)||t}const Jc=Symbol.for("v-ndc");function Xc(t,i,e=!0,n=!1){const o=te||oe;if(o){const r=o.type;{const s=Pd(r,!1);if(s&&(s===i||s===ce(i)||s===ro(ce(i))))return r}const l=Fs(o[t]||r[t],i)||Fs(o.appContext[t],i);return!l&&n?r:l}}function Fs(t,i){return t&&(t[i]||t[ce(i)]||t[ro(ce(i))])}function ge(t,i,e,n){let o;const r=e,l=St(t);if(l||qt(t)){const s=l&&xi(t);let a=!1,c=!1;s&&(a=!we(t),c=Qe(t),t=co(t)),o=new Array(t.length);for(let d=0,p=t.length;d<p;d++)o[d]=i(a?c?Hi(Te(t[d])):Te(t[d]):t[d],d,void 0,r)}else if(typeof t=="number"){o=new Array(t);for(let s=0;s<t;s++)o[s]=i(s+1,s,void 0,r)}else if(Pt(t))if(t[Symbol.iterator])o=Array.from(t,(s,a)=>i(s,a,void 0,r));else{const s=Object.keys(t);o=new Array(s.length);for(let a=0,c=s.length;a<c;a++){const d=s[a];o[a]=i(t[d],d,a,r)}}else o=[];return o}function Mn(t,i,e={},n,o,r){if(te.ce||te.parent&&zi(te.parent)&&te.parent.ce){const c=e,d=Object.keys(c).length>0;return i!=="default"&&(c.name=i),tt(),$e(Ut,null,[ft("slot",c,n&&n())],d?-2:64)}let l=t[i];l&&l._c&&(l._d=!1);const s=Ze.length;tt();let a;try{const c=l&&cl(l(e)),d=e.key||r||c&&c.key;a=$e(Ut,{key:(d&&!Ae(d)?d:`_${i}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&t._===1?64:-2)}catch(c){for(let d=Ze.length;d>s;d--)ys();throw c}finally{l&&l._c&&(l._d=!0)}return a}function cl(t){return t.some(i=>ks(i)?!(i.type===ti||i.type===Ut&&!cl(i.children)):!0)?t:null}const Wo=t=>t?Tl(t)?go(t):Wo(t.parent):null,cn=ee(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>Wo(t.parent),$root:t=>Wo(t.root),$host:t=>t.ce,$emit:t=>t.emit,$options:t=>ul(t),$forceUpdate:t=>t.f||(t.f=()=>{ps(t.update)}),$nextTick:t=>t.n||(t.n=Xr.bind(t.proxy)),$watch:t=>Pc.bind(t)}),Io=(t,i)=>t!==Nt&&!t.__isScriptSetup&&Bt(t,i),Qc={get({_:t},i){if(i==="__v_skip")return!0;const{ctx:e,setupState:n,data:o,props:r,accessCache:l,type:s,appContext:a}=t;if(i[0]!=="$"){const g=l[i];if(g!==void 0)switch(g){case 1:return n[i];case 2:return o[i];case 4:return e[i];case 3:return r[i]}else{if(Io(n,i))return l[i]=1,n[i];if(o!==Nt&&Bt(o,i))return l[i]=2,o[i];if(Bt(r,i))return l[i]=3,r[i];if(e!==Nt&&Bt(e,i))return l[i]=4,e[i];Vo&&(l[i]=0)}}const c=cn[i];let d,p;if(c)return i==="$attrs"&&ne(t.attrs,"get",""),c(t);if((d=s.__cssModules)&&(d=d[i]))return d;if(e!==Nt&&Bt(e,i))return l[i]=4,e[i];if(p=a.config.globalProperties,Bt(p,i))return p[i]},set({_:t},i,e){const{data:n,setupState:o,ctx:r}=t;return Io(o,i)?(o[i]=e,!0):n!==Nt&&Bt(n,i)?(n[i]=e,!0):Bt(t.props,i)||i[0]==="$"&&i.slice(1)in t?!1:(r[i]=e,!0)},has({_:{data:t,setupState:i,accessCache:e,ctx:n,appContext:o,props:r,type:l}},s){let a;return!!(e[s]||t!==Nt&&s[0]!=="$"&&Bt(t,s)||Io(i,s)||Bt(r,s)||Bt(n,s)||Bt(cn,s)||Bt(o.config.globalProperties,s)||(a=l.__cssModules)&&a[s])},defineProperty(t,i,e){return e.get!=null?t._.accessCache[i]=0:Bt(e,"value")&&this.set(t,i,e.value,null),Reflect.defineProperty(t,i,e)}};function js(t){return St(t)?t.reduce((i,e)=>(i[e]=null,i),{}):t}let Vo=!0;function td(t){const i=ul(t),e=t.proxy,n=t.ctx;Vo=!1,i.beforeCreate&&Hs(i.beforeCreate,t,"bc");const{data:o,computed:r,methods:l,watch:s,provide:a,inject:c,created:d,beforeMount:p,mounted:g,beforeUpdate:u,updated:w,activated:h,deactivated:k,beforeDestroy:b,beforeUnmount:y,destroyed:S,unmounted:T,render:x,renderTracked:_,renderTriggered:C,errorCaptured:D,serverPrefetch:M,expose:z,inheritAttrs:J,components:E,directives:A,filters:v}=i;if(c&&ed(c,n,null),l)for(const F in l){const et=l[F];$t(et)&&(n[F]=et.bind(e))}if(o){const F=o.call(e,e);Pt(F)&&(t.data=uo(F))}if(Vo=!0,r)for(const F in r){const et=r[F],H=$t(et)?et.bind(e,e):$t(et.get)?et.get.bind(e,e):Fe,V=!$t(et)&&$t(et.set)?et.set.bind(e):Fe,R=_t({get:H,set:V});Object.defineProperty(n,F,{enumerable:!0,configurable:!0,get:()=>R.value,set:U=>R.value=U})}if(s)for(const F in s)dl(s[F],n,e,F);if(a){const F=$t(a)?a.call(e):a;Reflect.ownKeys(F).forEach(et=>{Dc(et,F[et])})}d&&Hs(d,t,"c");function G(F,et){St(et)?et.forEach(H=>F(H.bind(e))):et&&F(et.bind(e))}if(G(Hc,p),G(Sn,g),G(Uc,u),G(Wc,w),G(Nc,h),G(Fc,k),G(Gc,D),G(qc,_),G(Kc,C),G(ms,y),G(gs,T),G(Vc,M),St(z))if(z.length){const F=t.exposed||(t.exposed={});z.forEach(et=>{Object.defineProperty(F,et,{get:()=>e[et],set:H=>e[et]=H,enumerable:!0})})}else t.exposed||(t.exposed={});x&&t.render===Fe&&(t.render=x),J!=null&&(t.inheritAttrs=J),E&&(t.components=E),A&&(t.directives=A),M&&rl(t)}function ed(t,i,e=Fe){St(t)&&(t=Ko(t));for(const n in t){const o=t[n];let r;Pt(o)?"default"in o?r=Ge(o.from||n,o.default,!0):r=Ge(o.from||n):r=Ge(o),re(r)?Object.defineProperty(i,n,{enumerable:!0,configurable:!0,get:()=>r.value,set:l=>r.value=l}):i[n]=r}}function Hs(t,i,e){Ee(St(t)?t.map(n=>n.bind(i.proxy)):t.bind(i.proxy),i,e)}function dl(t,i,e,n){let o=n.includes(".")?sl(e,n):()=>e[n];if(qt(t)){const r=i[t];$t(r)&&_i(o,r)}else if($t(t))_i(o,t.bind(e));else if(Pt(t))if(St(t))t.forEach(r=>dl(r,i,e,n));else{const r=$t(t.handler)?t.handler.bind(e):i[t.handler];$t(r)&&_i(o,r,t)}}function ul(t){const i=t.type,{mixins:e,extends:n}=i,{mixins:o,optionsCache:r,config:{optionMergeStrategies:l}}=t.appContext,s=r.get(i);let a;return s?a=s:!o.length&&!e&&!n?a=i:(a={},o.length&&o.forEach(c=>Xn(a,c,l,!0)),Xn(a,i,l)),Pt(i)&&r.set(i,a),a}function Xn(t,i,e,n=!1){const{mixins:o,extends:r}=i;r&&Xn(t,r,e,!0),o&&o.forEach(l=>Xn(t,l,e,!0));for(const l in i)if(!(n&&l==="expose")){const s=id[l]||e&&e[l];t[l]=s?s(t[l],i[l]):i[l]}return t}const id={data:Us,props:Ws,emits:Ws,methods:tn,computed:tn,beforeCreate:le,created:le,beforeMount:le,mounted:le,beforeUpdate:le,updated:le,beforeDestroy:le,beforeUnmount:le,destroyed:le,unmounted:le,activated:le,deactivated:le,errorCaptured:le,serverPrefetch:le,components:tn,directives:tn,watch:od,provide:Us,inject:nd};function Us(t,i){return i?t?function(){return ee($t(t)?t.call(this,this):t,$t(i)?i.call(this,this):i)}:i:t}function nd(t,i){return tn(Ko(t),Ko(i))}function Ko(t){if(St(t)){const i={};for(let e=0;e<t.length;e++)i[t[e]]=t[e];return i}return t}function le(t,i){return t?[...new Set([].concat(t,i))]:i}function tn(t,i){return t?ee(Object.create(null),t,i):i}function Ws(t,i){return t?St(t)&&St(i)?[...new Set([...t,...i])]:ee(Object.create(null),js(t),js(i??{})):i}function od(t,i){if(!t)return i;if(!i)return t;const e=ee(Object.create(null),t);for(const n in i)e[n]=le(t[n],i[n]);return e}function fl(){return{app:null,config:{isNativeTag:Ar,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let sd=0;function rd(t,i){return function(n,o=null){$t(n)||(n=ee({},n)),o!=null&&!Pt(o)&&(o=null);const r=fl(),l=new WeakSet,s=[];let a=!1;const c=r.app={_uid:sd++,_component:n,_props:o,_container:null,_context:r,_instance:null,version:zd,get config(){return r.config},set config(d){},use(d,...p){return l.has(d)||(d&&$t(d.install)?(l.add(d),d.install(c,...p)):$t(d)&&(l.add(d),d(c,...p))),c},mixin(d){return r.mixins.includes(d)||r.mixins.push(d),c},component(d,p){return p?(r.components[d]=p,c):r.components[d]},directive(d,p){return p?(r.directives[d]=p,c):r.directives[d]},mount(d,p,g){if(!a){const u=c._ceVNode||ft(n,o);return u.appContext=r,g===!0?g="svg":g===!1&&(g=void 0),t(u,d,g),a=!0,c._container=d,d.__vue_app__=c,go(u.component)}},onUnmount(d){s.push(d)},unmount(){a&&(Ee(s,c._instance,16),t(null,c._container),delete c._container.__vue_app__)},provide(d,p){return r.provides[d]=p,c},runWithContext(d){const p=Ni;Ni=c;try{return d()}finally{Ni=p}}};return c}}let Ni=null;const ld=(t,i)=>i==="modelValue"||i==="model-value"?t.modelModifiers:t[`${i}Modifiers`]||t[`${ce(i)}Modifiers`]||t[`${ci(i)}Modifiers`];function ad(t,i,...e){if(t.isUnmounted)return;const n=t.vnode.props||Nt;let o=e;const r=i.startsWith("update:"),l=r&&ld(n,i.slice(7));l&&(l.trim&&(o=e.map(d=>qt(d)?d.trim():d)),l.number&&(o=e.map(lo)));let s,a=n[s=wo(i)]||n[s=wo(ce(i))];!a&&r&&(a=n[s=wo(ci(i))]),a&&Ee(a,t,6,o);const c=n[s+"Once"];if(c){if(!t.emitted)t.emitted={};else if(t.emitted[s])return;t.emitted[s]=!0,Ee(c,t,6,o)}}const cd=new WeakMap;function pl(t,i,e=!1){const n=e?cd:i.emitsCache,o=n.get(t);if(o!==void 0)return o;const r=t.emits;let l={},s=!1;if(!$t(t)){const a=c=>{const d=pl(c,i,!0);d&&(s=!0,ee(l,d))};!e&&i.mixins.length&&i.mixins.forEach(a),t.extends&&a(t.extends),t.mixins&&t.mixins.forEach(a)}return!r&&!s?(Pt(t)&&n.set(t,null),null):(St(r)?r.forEach(a=>l[a]=null):ee(l,r),Pt(t)&&n.set(t,l),l)}function ho(t,i){return!t||!no(i)?!1:(i=i.slice(2),i=i==="Once"?i:i.replace(/Once$/,""),Bt(t,i[0].toLowerCase()+i.slice(1))||Bt(t,ci(i))||Bt(t,i))}function Vs(t){const{type:i,vnode:e,proxy:n,withProxy:o,propsOptions:[r],slots:l,attrs:s,emit:a,render:c,renderCache:d,props:p,data:g,setupState:u,ctx:w,inheritAttrs:h}=t,k=Yn(t);let b,y;try{if(e.shapeFlag&4){const T=o||n,x=T;b=Pe(c.call(x,T,d,p,u,g,w)),y=s}else{const T=i;b=Pe(T.length>1?T(p,{attrs:s,slots:l,emit:a}):T(p,null)),y=i.props?s:dd(s)}}catch(T){Ze.length=0,fo(T,t,1),b=ft(ti)}let S=b;if(y&&h!==!1){const T=Object.keys(y),{shapeFlag:x}=S;T.length&&x&7&&(r&&T.some(oo)&&(y=ud(y,r)),S=Ui(S,y,!1,!0))}return e.dirs&&(S=Ui(S,null,!1,!0),S.dirs=S.dirs?S.dirs.concat(e.dirs):e.dirs),e.transition&&hs(S,e.transition),b=S,Yn(k),b}const dd=t=>{let i;for(const e in t)(e==="class"||e==="style"||no(e))&&((i||(i={}))[e]=t[e]);return i},ud=(t,i)=>{const e={};for(const n in t)(!oo(n)||!(n.slice(9)in i))&&(e[n]=t[n]);return e};function fd(t,i,e){const{props:n,children:o,component:r}=t,{props:l,children:s,patchFlag:a}=i,c=r.emitsOptions;if(i.dirs||i.transition)return!0;if(e&&a>=0){if(a&1024)return!0;if(a&16)return n?Ks(n,l,c):!!l;if(a&8){const d=i.dynamicProps;for(let p=0;p<d.length;p++){const g=d[p];if(hl(l,n,g)&&!ho(c,g))return!0}}}else return(o||s)&&(!s||!s.$stable)?!0:n===l?!1:n?l?Ks(n,l,c):!0:!!l;return!1}function Ks(t,i,e){const n=Object.keys(i);if(n.length!==Object.keys(t).length)return!0;for(let o=0;o<n.length;o++){const r=n[o];if(hl(i,t,r)&&!ho(e,r))return!0}return!1}function hl(t,i,e){const n=t[e],o=i[e];return e==="style"&&Pt(n)&&Pt(o)?!qi(n,o):n!==o}function pd({vnode:t,parent:i,suspense:e},n){for(;i;){const o=i.subTree;if(o.suspense&&o.suspense.activeBranch===t&&(o.suspense.vnode.el=o.el=n,t=o),o===t)(t=i.vnode).el=n,i=i.parent;else break}e&&e.activeBranch===t&&(e.vnode.el=n)}const ml={},gl=()=>Object.create(ml),vl=t=>Object.getPrototypeOf(t)===ml;function hd(t,i,e,n=!1){const o={},r=gl();t.propsDefaults=Object.create(null),bl(t,i,o,r);for(const l in t.propsOptions[0])l in o||(o[l]=void 0);e?t.props=n?o:wc(o):t.type.props?t.props=o:t.props=r,t.attrs=r}function md(t,i,e,n){const{props:o,attrs:r,vnode:{patchFlag:l}}=t,s=Et(o),[a]=t.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const d=t.vnode.dynamicProps;for(let p=0;p<d.length;p++){let g=d[p];if(ho(t.emitsOptions,g))continue;const u=i[g];if(a)if(Bt(r,g))u!==r[g]&&(r[g]=u,c=!0);else{const w=ce(g);o[w]=qo(a,s,w,u,t,!1)}else u!==r[g]&&(r[g]=u,c=!0)}}}else{bl(t,i,o,r)&&(c=!0);let d;for(const p in s)(!i||!Bt(i,p)&&((d=ci(p))===p||!Bt(i,d)))&&(a?e&&(e[p]!==void 0||e[d]!==void 0)&&(o[p]=qo(a,s,p,void 0,t,!0)):delete o[p]);if(r!==s)for(const p in r)(!i||!Bt(i,p))&&(delete r[p],c=!0)}c&&Ke(t.attrs,"set","")}function bl(t,i,e,n){const[o,r]=t.propsOptions;let l=!1,s;if(i)for(let a in i){if(sn(a))continue;const c=i[a];let d;o&&Bt(o,d=ce(a))?!r||!r.includes(d)?e[d]=c:(s||(s={}))[d]=c:ho(t.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(r){const a=Et(e),c=s||Nt;for(let d=0;d<r.length;d++){const p=r[d];e[p]=qo(o,a,p,c[p],t,!Bt(c,p))}}return l}function qo(t,i,e,n,o,r){const l=t[e];if(l!=null){const s=Bt(l,"default");if(s&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&$t(a)){const{propsDefaults:c}=o;if(e in c)n=c[e];else{const d=Cn(o);n=c[e]=a.call(null,i),d()}}else n=a;o.ce&&o.ce._setProp(e,n)}l[0]&&(r&&!s?n=!1:l[1]&&(n===""||n===ci(e))&&(n=!0))}return n}const gd=new WeakMap;function yl(t,i,e=!1){const n=e?gd:i.propsCache,o=n.get(t);if(o)return o;const r=t.props,l={},s=[];let a=!1;if(!$t(t)){const d=p=>{a=!0;const[g,u]=yl(p,i,!0);ee(l,g),u&&s.push(...u)};!e&&i.mixins.length&&i.mixins.forEach(d),t.extends&&d(t.extends),t.mixins&&t.mixins.forEach(d)}if(!r&&!a)return Pt(t)&&n.set(t,Oi),Oi;if(St(r))for(let d=0;d<r.length;d++){const p=ce(r[d]);qs(p)&&(l[p]=Nt)}else if(r)for(const d in r){const p=ce(d);if(qs(p)){const g=r[d],u=l[p]=St(g)||$t(g)?{type:g}:ee({},g),w=u.type;let h=!1,k=!0;if(St(w))for(let b=0;b<w.length;++b){const y=w[b],S=$t(y)&&y.name;if(S==="Boolean"){h=!0;break}else S==="String"&&(k=!1)}else h=$t(w)&&w.name==="Boolean";u[0]=h,u[1]=k,(h||Bt(u,"default"))&&s.push(p)}}const c=[l,s];return Pt(t)&&n.set(t,c),c}function qs(t){return t[0]!=="$"&&!sn(t)}const vs=t=>t==="_"||t==="_ctx"||t==="$stable",bs=t=>St(t)?t.map(Pe):[Pe(t)],vd=(t,i,e)=>{if(i._n)return i;const n=nl((...o)=>bs(i(...o)),e);return n._c=!1,n},kl=(t,i,e)=>{const n=t._ctx;for(const o in t){if(vs(o))continue;const r=t[o];if($t(r))i[o]=vd(o,r,n);else if(r!=null){const l=bs(r);i[o]=()=>l}}},wl=(t,i)=>{const e=bs(i);t.slots.default=()=>e},xl=(t,i,e)=>{for(const n in i)(e||!vs(n))&&(t[n]=i[n])},bd=(t,i,e)=>{const n=t.slots=gl();if(t.vnode.shapeFlag&32){const o=i._;o?(xl(n,i,e),e&&Mr(n,"_",o,!0)):kl(i,n)}else i&&wl(t,i)},yd=(t,i,e)=>{const{vnode:n,slots:o}=t;let r=!0,l=Nt;if(n.shapeFlag&32){const s=i._;s?e&&s===1?r=!1:xl(o,i,e):(r=!i.$stable,kl(i,o)),l=i}else i&&(wl(t,i),l={default:1});if(r)for(const s in o)!vs(s)&&l[s]==null&&delete o[s]},ue=Sd;function kd(t){return wd(t)}function wd(t,i){const e=ao();e.__VUE__=!0;const{insert:n,remove:o,patchProp:r,createElement:l,createText:s,createComment:a,setText:c,setElementText:d,parentNode:p,nextSibling:g,setScopeId:u=Fe,insertStaticContent:w}=t,h=(B,N,f,j=null,O=null,$=null,I=void 0,L=null,q=!!N.dynamicChildren)=>{if(B===N)return;B&&!Ji(B,N)&&(j=pt(B),U(B,O,$,!0),B=null),N.patchFlag===-2&&(q=!1,N.dynamicChildren=null);const{type:K,ref:W,shapeFlag:Y}=N;switch(K){case mo:k(B,N,f,j);break;case ti:b(B,N,f,j);break;case Rn:B==null&&y(N,f,j,I);break;case Ut:E(B,N,f,j,O,$,I,L,q);break;default:Y&1?x(B,N,f,j,O,$,I,L,q):Y&6?A(B,N,f,j,O,$,I,L,q):(Y&64||Y&128)&&K.process(B,N,f,j,O,$,I,L,q,ot)}W!=null&&O?an(W,B&&B.ref,$,N||B,!N):W==null&&B&&B.ref!=null&&an(B.ref,null,$,B,!0)},k=(B,N,f,j)=>{if(B==null)n(N.el=s(N.children),f,j);else{const O=N.el=B.el;N.children!==B.children&&c(O,N.children)}},b=(B,N,f,j)=>{B==null?n(N.el=a(N.children||""),f,j):N.el=B.el},y=(B,N,f,j)=>{[B.el,B.anchor]=w(B.children,N,f,j,B.el,B.anchor)},S=({el:B,anchor:N},f,j)=>{let O;for(;B&&B!==N;)O=g(B),n(B,f,j),B=O;n(N,f,j)},T=({el:B,anchor:N})=>{let f;for(;B&&B!==N;)f=g(B),o(B),B=f;o(N)},x=(B,N,f,j,O,$,I,L,q)=>{if(N.type==="svg"?I="svg":N.type==="math"&&(I="mathml"),B==null)_(N,f,j,O,$,I,L,q);else{const K=B.el&&B.el._isVueCE?B.el:null;try{K&&K._beginPatch(),M(B,N,O,$,I,L,q)}finally{K&&K._endPatch()}}},_=(B,N,f,j,O,$,I,L)=>{let q,K;const{props:W,shapeFlag:Y,transition:it,dirs:Q}=B;if(q=B.el=l(B.type,$,W&&W.is,W),Y&8?d(q,B.children):Y&16&&D(B.children,q,null,j,O,Ao(B,$),I,L),Q&&pi(B,null,j,"created"),C(q,B,B.scopeId,I,j),W){for(const kt in W)kt!=="value"&&!sn(kt)&&r(q,kt,null,W[kt],$,j);"value"in W&&r(q,"value",null,W.value,$),(K=W.onVnodeBeforeMount)&&Me(K,j,B)}Q&&pi(B,null,j,"beforeMount");const dt=xd(O,it);dt&&it.beforeEnter(q),n(q,N,f),((K=W&&W.onVnodeMounted)||dt||Q)&&ue(()=>{try{K&&Me(K,j,B),dt&&it.enter(q),Q&&pi(B,null,j,"mounted")}finally{}},O)},C=(B,N,f,j,O)=>{if(f&&u(B,f),j)for(let $=0;$<j.length;$++)u(B,j[$]);if(O){let $=O.subTree;if(N===$||$l($.type)&&($.ssContent===N||$.ssFallback===N)){const I=O.vnode;C(B,I,I.scopeId,I.slotScopeIds,O.parent)}}},D=(B,N,f,j,O,$,I,L,q=0)=>{for(let K=q;K<B.length;K++){const W=B[K]=L?Ve(B[K]):Pe(B[K]);h(null,W,N,f,j,O,$,I,L)}},M=(B,N,f,j,O,$,I)=>{const L=N.el=B.el;let{patchFlag:q,dynamicChildren:K,dirs:W}=N;q|=B.patchFlag&16;const Y=B.props||Nt,it=N.props||Nt;let Q;if(f&&hi(f,!1),(Q=it.onVnodeBeforeUpdate)&&Me(Q,f,N,B),W&&pi(N,B,f,"beforeUpdate"),f&&hi(f,!0),K&&(!B.dynamicChildren||B.dynamicChildren.length!==K.length)&&(q=0,I=!1,K=null),(Y.innerHTML&&it.innerHTML==null||Y.textContent&&it.textContent==null)&&d(L,""),K?z(B.dynamicChildren,K,L,f,j,Ao(N,O),$):I||et(B,N,L,null,f,j,Ao(N,O),$,!1),q>0){if(q&16)J(L,Y,it,f,O);else if(q&2&&Y.class!==it.class&&r(L,"class",null,it.class,O),q&4&&r(L,"style",Y.style,it.style,O),q&8){const dt=N.dynamicProps;for(let kt=0;kt<dt.length;kt++){const vt=dt[kt],At=Y[vt],Ht=it[vt];(Ht!==At||vt==="value")&&r(L,vt,At,Ht,O,f)}}q&1&&B.children!==N.children&&d(L,N.children)}else!I&&K==null&&J(L,Y,it,f,O);((Q=it.onVnodeUpdated)||W)&&ue(()=>{Q&&Me(Q,f,N,B),W&&pi(N,B,f,"updated")},j)},z=(B,N,f,j,O,$,I)=>{for(let L=0;L<N.length;L++){const q=B[L],K=N[L],W=q.el&&(q.type===Ut||!Ji(q,K)||q.shapeFlag&198)?p(q.el):f;h(q,K,W,null,j,O,$,I,!0)}},J=(B,N,f,j,O)=>{if(N!==f){if(N!==Nt)for(const $ in N)!sn($)&&!($ in f)&&r(B,$,N[$],null,O,j);for(const $ in f){if(sn($))continue;const I=f[$],L=N[$];I!==L&&$!=="value"&&r(B,$,L,I,O,j)}"value"in f&&r(B,"value",N.value,f.value,O)}},E=(B,N,f,j,O,$,I,L,q)=>{const K=N.el=B?B.el:s(""),W=N.anchor=B?B.anchor:s("");let{patchFlag:Y,dynamicChildren:it,slotScopeIds:Q}=N;Q&&(L=L?L.concat(Q):Q),B==null?(n(K,f,j),n(W,f,j),D(N.children||[],f,W,O,$,I,L,q)):Y>0&&Y&64&&it&&B.dynamicChildren&&B.dynamicChildren.length===it.length?(z(B.dynamicChildren,it,f,O,$,I,L),(N.key!=null||O&&N===O.subTree)&&_l(B,N,!0)):et(B,N,f,W,O,$,I,L,q)},A=(B,N,f,j,O,$,I,L,q)=>{N.slotScopeIds=L,B==null?N.shapeFlag&512?O.ctx.activate(N,f,j,I,q):v(N,f,j,O,$,I,q):P(B,N,q)},v=(B,N,f,j,O,$,I)=>{const L=B.component=Ed(B,j,O);if(ll(B)&&(L.ctx.renderer=ot),Md(L,!1,I),L.asyncDep){if(O&&O.registerDep(L,G,I),!B.el){const q=L.subTree=ft(ti);b(null,q,N,f),B.placeholder=q.el}}else G(L,B,N,f,O,$,I)},P=(B,N,f)=>{const j=N.component=B.component;if(fd(B,N,f))if(j.asyncDep&&!j.asyncResolved){F(j,N,f);return}else j.next=N,j.update();else N.el=B.el,j.vnode=N},G=(B,N,f,j,O,$,I)=>{const L=()=>{if(B.isMounted){let{next:Y,bu:it,u:Q,parent:dt,vnode:kt}=B;{const Zt=Sl(B);if(Zt){Y&&(Y.el=kt.el,F(B,Y,I)),Zt.asyncDep.then(()=>{ue(()=>{B.isUnmounted||K()},O)});return}}let vt=Y,At;hi(B,!1),Y?(Y.el=kt.el,F(B,Y,I)):Y=kt,it&&Pn(it),(At=Y.props&&Y.props.onVnodeBeforeUpdate)&&Me(At,dt,Y,kt),hi(B,!0);const Ht=Vs(B),Wt=B.subTree;B.subTree=Ht,h(Wt,Ht,p(Wt.el),pt(Wt),B,O,$),Y.el=Ht.el,vt===null&&pd(B,Ht.el),Q&&ue(Q,O),(At=Y.props&&Y.props.onVnodeUpdated)&&ue(()=>Me(At,dt,Y,kt),O)}else{let Y;const{el:it,props:Q}=N,{bm:dt,m:kt,parent:vt,root:At,type:Ht}=B,Wt=zi(N);hi(B,!1),dt&&Pn(dt),!Wt&&(Y=Q&&Q.onVnodeBeforeMount)&&Me(Y,vt,N),hi(B,!0);{At.ce&&At.ce._hasShadowRoot()&&At.ce._injectChildStyle(Ht,B.parent?B.parent.type:void 0);const Zt=B.subTree=Vs(B);h(null,Zt,f,j,B,O,$),N.el=Zt.el}if(kt&&ue(kt,O),!Wt&&(Y=Q&&Q.onVnodeMounted)){const Zt=N;ue(()=>Me(Y,vt,Zt),O)}(N.shapeFlag&256||vt&&zi(vt.vnode)&&vt.vnode.shapeFlag&256)&&B.a&&ue(B.a,O),B.isMounted=!0,N=f=j=null}};B.scope.on();const q=B.effect=new Pr(L);B.scope.off();const K=B.update=q.run.bind(q),W=B.job=q.runIfDirty.bind(q);W.i=B,W.id=B.uid,q.scheduler=()=>ps(W),hi(B,!0),K()},F=(B,N,f)=>{N.component=B;const j=B.vnode.props;B.vnode=N,B.next=null,md(B,N.props,j,f),yd(B,N.children,f),Je(),Rs(B),Xe()},et=(B,N,f,j,O,$,I,L,q=!1)=>{const K=B&&B.children,W=B?B.shapeFlag:0,Y=N.children,{patchFlag:it,shapeFlag:Q}=N;if(it>0){if(it&128){V(K,Y,f,j,O,$,I,L,q);return}else if(it&256){H(K,Y,f,j,O,$,I,L,q);return}}Q&8?(W&16&&X(K,O,$),Y!==K&&d(f,Y)):W&16?Q&16?V(K,Y,f,j,O,$,I,L,q):X(K,O,$,!0):(W&8&&d(f,""),Q&16&&D(Y,f,j,O,$,I,L,q))},H=(B,N,f,j,O,$,I,L,q)=>{B=B||Oi,N=N||Oi;const K=B.length,W=N.length,Y=Math.min(K,W);let it;for(it=0;it<Y;it++){const Q=N[it]=q?Ve(N[it]):Pe(N[it]);h(B[it],Q,f,null,O,$,I,L,q)}K>W?X(B,O,$,!0,!1,Y):D(N,f,j,O,$,I,L,q,Y)},V=(B,N,f,j,O,$,I,L,q)=>{let K=0;const W=N.length;let Y=B.length-1,it=W-1;for(;K<=Y&&K<=it;){const Q=B[K],dt=N[K]=q?Ve(N[K]):Pe(N[K]);if(Ji(Q,dt))h(Q,dt,f,null,O,$,I,L,q);else break;K++}for(;K<=Y&&K<=it;){const Q=B[Y],dt=N[it]=q?Ve(N[it]):Pe(N[it]);if(Ji(Q,dt))h(Q,dt,f,null,O,$,I,L,q);else break;Y--,it--}if(K>Y){if(K<=it){const Q=it+1,dt=Q<W?N[Q].el:j;for(;K<=it;)h(null,N[K]=q?Ve(N[K]):Pe(N[K]),f,dt,O,$,I,L,q),K++}}else if(K>it)for(;K<=Y;)U(B[K],O,$,!0),K++;else{const Q=K,dt=K,kt=new Map;for(K=dt;K<=it;K++){const Gt=N[K]=q?Ve(N[K]):Pe(N[K]);Gt.key!=null&&kt.set(Gt.key,K)}let vt,At=0;const Ht=it-dt+1;let Wt=!1,Zt=0;const Dt=new Array(Ht);for(K=0;K<Ht;K++)Dt[K]=0;for(K=Q;K<=Y;K++){const Gt=B[K];if(At>=Ht){U(Gt,O,$,!0);continue}let Vt;if(Gt.key!=null)Vt=kt.get(Gt.key);else for(vt=dt;vt<=it;vt++)if(Dt[vt-dt]===0&&Ji(Gt,N[vt])){Vt=vt;break}Vt===void 0?U(Gt,O,$,!0):(Dt[Vt-dt]=K+1,Vt>=Zt?Zt=Vt:Wt=!0,h(Gt,N[Vt],f,null,O,$,I,L,q),At++)}const je=Wt?_d(Dt):Oi;for(vt=je.length-1,K=Ht-1;K>=0;K--){const Gt=dt+K,Vt=N[Gt],ii=N[Gt+1],Ii=Gt+1<W?ii.el||Cl(ii):j;Dt[K]===0?h(null,Vt,f,Ii,O,$,I,L,q):Wt&&(vt<0||K!==je[vt]?R(Vt,f,Ii,2):vt--)}}},R=(B,N,f,j,O=null)=>{const{el:$,type:I,transition:L,children:q,shapeFlag:K}=B;if(K&6){R(B.component.subTree,N,f,j);return}if(K&128){B.suspense.move(N,f,j);return}if(K&64){I.move(B,N,f,ot);return}if(I===Ut){n($,N,f);for(let Y=0;Y<q.length;Y++)R(q[Y],N,f,j);n(B.anchor,N,f);return}if(I===Rn){S(B,N,f);return}if(j!==2&&K&1&&L)if(j===0)L.persisted&&!$[$o]?n($,N,f):(L.beforeEnter($),n($,N,f),ue(()=>L.enter($),O));else{const{leave:Y,delayLeave:it,afterLeave:Q}=L,dt=()=>{B.ctx.isUnmounted?o($):n($,N,f)},kt=()=>{const vt=$._isLeaving||!!$[$o];$._isLeaving&&$[$o](!0),L.persisted&&!vt?dt():Y($,()=>{dt(),Q&&Q()})};it?it($,dt,kt):kt()}else n($,N,f)},U=(B,N,f,j=!1,O=!1)=>{const{type:$,props:I,ref:L,children:q,dynamicChildren:K,shapeFlag:W,patchFlag:Y,dirs:it,cacheIndex:Q,memo:dt}=B;if(Y===-2&&(O=!1),L!=null&&(Je(),an(L,null,f,B,!0),Xe()),Q!=null&&(N.renderCache[Q]=void 0),W&256){N.ctx.deactivate(B);return}const kt=W&1&&it,vt=!zi(B);let At;if(vt&&(At=I&&I.onVnodeBeforeUnmount)&&Me(At,N,B),W&6)st(B.component,f,j);else{if(W&128){B.suspense.unmount(f,j);return}kt&&pi(B,null,N,"beforeUnmount"),W&64?B.type.remove(B,N,f,ot,j):K&&!K.hasOnce&&($!==Ut||Y>0&&Y&64)?X(K,N,f,!1,!0):($===Ut&&Y&384||!O&&W&16)&&X(q,N,f),j&&at(B)}const Ht=dt!=null&&Q==null;(vt&&(At=I&&I.onVnodeUnmounted)||kt||Ht)&&ue(()=>{At&&Me(At,N,B),kt&&pi(B,null,N,"unmounted"),Ht&&(B.el=null)},f)},at=B=>{const{type:N,el:f,anchor:j,transition:O}=B;if(N===Ut){rt(f,j);return}if(N===Rn){T(B);return}const $=()=>{o(f),O&&!O.persisted&&O.afterLeave&&O.afterLeave()};if(B.shapeFlag&1&&O&&!O.persisted){const{leave:I,delayLeave:L}=O,q=()=>I(f,$);L?L(B.el,$,q):q()}else $()},rt=(B,N)=>{let f;for(;B!==N;)f=g(B),o(B),B=f;o(N)},st=(B,N,f)=>{const{bum:j,scope:O,job:$,subTree:I,um:L,m:q,a:K}=B;Gs(q),Gs(K),j&&Pn(j),O.stop(),$&&($.flags|=8,U(I,B,N,f)),L&&ue(L,N),ue(()=>{B.isUnmounted=!0},N)},X=(B,N,f,j=!1,O=!1,$=0)=>{for(let I=$;I<B.length;I++)U(B[I],N,f,j,O)},pt=B=>{if(B.shapeFlag&6)return pt(B.component.subTree);if(B.shapeFlag&128)return B.suspense.next();const N=g(B.anchor||B.el),f=N&&N[Rc];return f?g(f):N};let mt=!1;const Z=(B,N,f)=>{let j;B==null?N._vnode&&(U(N._vnode,null,null,!0),j=N._vnode.component):h(N._vnode||null,B,N,null,null,null,f),N._vnode=B,mt||(mt=!0,Rs(j),tl(),mt=!1)},ot={p:h,um:U,m:R,r:at,mt:v,mc:D,pc:et,pbc:z,n:pt,o:t};return{render:Z,hydrate:void 0,createApp:rd(Z)}}function Ao({type:t,props:i},e){return e==="svg"&&t==="foreignObject"||e==="mathml"&&t==="annotation-xml"&&i&&i.encoding&&i.encoding.includes("html")?void 0:e}function hi({effect:t,job:i},e){e?(t.flags|=32,i.flags|=4):(t.flags&=-33,i.flags&=-5)}function xd(t,i){return(!t||t&&!t.pendingBranch)&&i&&!i.persisted}function _l(t,i,e=!1){const n=t.children,o=i.children;if(St(n)&&St(o))for(let r=0;r<n.length;r++){const l=n[r];let s=o[r];s.shapeFlag&1&&!s.dynamicChildren&&((s.patchFlag<=0||s.patchFlag===32)&&(s=o[r]=Ve(o[r]),s.el=l.el),!e&&s.patchFlag!==-2&&_l(l,s)),s.type===mo&&(s.patchFlag===-1&&(s=o[r]=Ve(s)),s.el=l.el),s.type===ti&&!s.el&&(s.el=l.el)}}function _d(t){const i=t.slice(),e=[0];let n,o,r,l,s;const a=t.length;for(n=0;n<a;n++){const c=t[n];if(c!==0){if(o=e[e.length-1],t[o]<c){i[n]=o,e.push(n);continue}for(r=0,l=e.length-1;r<l;)s=r+l>>1,t[e[s]]<c?r=s+1:l=s;c<t[e[r]]&&(r>0&&(i[n]=e[r-1]),e[r]=n)}}for(r=e.length,l=e[r-1];r-- >0;)e[r]=l,l=i[l];return e}function Sl(t){const i=t.subTree.component;if(i)return i.asyncDep&&!i.asyncResolved?i:Sl(i)}function Gs(t){if(t)for(let i=0;i<t.length;i++)t[i].flags|=8}function Cl(t){if(t.placeholder)return t.placeholder;const i=t.component;return i?Cl(i.subTree):null}const $l=t=>t.__isSuspense;function Sd(t,i){i&&i.pendingBranch?St(t)?i.effects.push(...t):i.effects.push(t):Mc(t)}const Ut=Symbol.for("v-fgt"),mo=Symbol.for("v-txt"),ti=Symbol.for("v-cmt"),Rn=Symbol.for("v-stc"),Ze=[];let ve=null;function tt(t=!1){Ze.push(ve=t?null:[])}function ys(){Ze.pop(),ve=Ze[Ze.length-1]||null}let bn=1;function Zs(t,i=!1){bn+=t,t<0&&ve&&i&&(ve.hasOnce=!0)}function Il(t){return t.dynamicChildren=bn>0?ve||Oi:null,ys(),bn>0&&ve&&ve.push(t),t}function nt(t,i,e,n,o,r){return Il(m(t,i,e,n,o,r,!0))}function $e(t,i,e,n,o){return Il(ft(t,i,e,n,o,!0))}function ks(t){return t?t.__v_isVNode===!0:!1}function Ji(t,i){return t.type===i.type&&t.key===i.key}const Al=({key:t})=>t??null,zn=({ref:t,ref_key:i,ref_for:e})=>(typeof t=="number"&&(t=""+t),t!=null?qt(t)||re(t)||$t(t)?{i:te,r:t,k:i,f:!!e}:t:null);function m(t,i=null,e=null,n=0,o=null,r=t===Ut?0:1,l=!1,s=!1){const a={__v_isVNode:!0,__v_skip:!0,type:t,props:i,key:i&&Al(i),ref:i&&zn(i),scopeId:il,slotScopeIds:null,children:e,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:r,patchFlag:n,dynamicProps:o,dynamicChildren:null,appContext:null,ctx:te};return s?(Qn(a,e),r&128&&t.normalize(a)):e&&(a.shapeFlag|=qt(e)?8:16),bn>0&&!l&&ve&&(a.patchFlag>0||r&6)&&a.patchFlag!==32&&ve.push(a),a}const ft=Cd;function Cd(t,i=null,e=null,n=0,o=null,r=!1){if((!t||t===Jc)&&(t=ti),ks(t)){const s=Ui(t,i,!0);return e&&Qn(s,e),bn>0&&!r&&ve&&(s.shapeFlag&6?ve[ve.indexOf(t)]=s:ve.push(s)),s.patchFlag=-2,s}if(Rd(t)&&(t=t.__vccOpts),i){i=$d(i);let{class:s,style:a}=i;s&&!qt(s)&&(i.class=Ct(s)),Pt(a)&&(fs(a)&&!St(a)&&(a=ee({},a)),i.style=os(a))}const l=qt(t)?1:$l(t)?128:zc(t)?64:Pt(t)?4:$t(t)?2:0;return m(t,i,e,n,o,l,r,!0)}function $d(t){return t?fs(t)||vl(t)?ee({},t):t:null}function Ui(t,i,e=!1,n=!1){const{props:o,ref:r,patchFlag:l,children:s,transition:a}=t,c=i?Id(o||{},i):o,d={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&Al(c),ref:i&&i.ref?e&&r?St(r)?r.concat(zn(i)):[r,zn(i)]:zn(i):r,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:s,target:t.target,targetStart:t.targetStart,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:i&&t.type!==Ut?l===-1?16:l|16:l,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:a,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&Ui(t.ssContent),ssFallback:t.ssFallback&&Ui(t.ssFallback),placeholder:t.placeholder,el:t.el,anchor:t.anchor,ctx:t.ctx,ce:t.ce};return a&&n&&hs(d,a.clone(d)),d}function Go(t=" ",i=0){return ft(mo,null,t,i)}function xe(t,i){const e=ft(Rn,null,t);return e.staticCount=i,e}function Ot(t="",i=!1){return i?(tt(),$e(ti,null,t)):ft(ti,null,t)}function Pe(t){return t==null||typeof t=="boolean"?ft(ti):St(t)?ft(Ut,null,t.slice()):ks(t)?Ve(t):ft(mo,null,String(t))}function Ve(t){return t.el===null&&t.patchFlag!==-1||t.memo?t:Ui(t)}function Qn(t,i){let e=0;const{shapeFlag:n}=t;if(i==null)i=null;else if(St(i))e=16;else if(typeof i=="object")if(n&65){const o=i.default;o&&(o._c&&(o._d=!1),Qn(t,o()),o._c&&(o._d=!0));return}else{e=32;const o=i._;!o&&!vl(i)?i._ctx=te:o===3&&te&&(te.slots._===1?i._=1:(i._=2,t.patchFlag|=1024))}else if($t(i)){if(n&65){Qn(t,{default:i});return}i={default:i,_ctx:te},e=32}else i=String(i),n&64?(e=16,i=[Go(i)]):e=8;t.children=i,t.shapeFlag|=e}function Id(...t){const i={};for(let e=0;e<t.length;e++){const n=t[e];for(const o in n)if(o==="class")i.class!==n.class&&(i.class=Ct([i.class,n.class]));else if(o==="style")i.style=os([i.style,n.style]);else if(no(o)){const r=i[o],l=n[o];l&&r!==l&&!(St(r)&&r.includes(l))?i[o]=r?[].concat(r,l):l:l==null&&r==null&&!oo(o)&&(i[o]=l)}else o!==""&&(i[o]=n[o])}return i}function Me(t,i,e,n=null){Ee(t,i,7,[e,n])}const Ad=fl();let Td=0;function Ed(t,i,e){const n=t.type,o=(i?i.appContext:t.appContext)||Ad,r={uid:Td++,vnode:t,type:n,parent:i,appContext:o,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new ic(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:i?i.provides:Object.create(o.provides),ids:i?i.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:yl(n,o),emitsOptions:pl(n,o),emit:null,emitted:null,propsDefaults:Nt,inheritAttrs:n.inheritAttrs,ctx:Nt,data:Nt,props:Nt,attrs:Nt,slots:Nt,refs:Nt,setupState:Nt,setupContext:null,suspense:e,suspenseId:e?e.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return r.ctx={_:r},r.root=i?i.root:r,r.emit=ad.bind(null,r),t.ce&&t.ce(r),r}let oe=null;const Bd=()=>oe||te;let to,Zo;{const t=ao(),i=(e,n)=>{let o;return(o=t[e])||(o=t[e]=[]),o.push(n),r=>{o.length>1?o.forEach(l=>l(r)):o[0](r)}};to=i("__VUE_INSTANCE_SETTERS__",e=>oe=e),Zo=i("__VUE_SSR_SETTERS__",e=>yn=e)}const Cn=t=>{const i=oe;return to(t),t.scope.on(),()=>{t.scope.off(),to(i)}},Ys=()=>{oe&&oe.scope.off(),to(null)};function Tl(t){return t.vnode.shapeFlag&4}let yn=!1;function Md(t,i=!1,e=!1){i&&Zo(i);const{props:n,children:o}=t.vnode,r=Tl(t);hd(t,n,r,i),bd(t,o,e||i);const l=r?Dd(t,i):void 0;return i&&Zo(!1),l}function Dd(t,i){const e=t.type;t.accessCache=Object.create(null),t.proxy=new Proxy(t.ctx,Qc);const{setup:n}=e;if(n){Je();const o=t.setupContext=n.length>1?Od(t):null,r=Cn(t),l=_n(n,t,0,[t.props,o]),s=Tr(l);if(Xe(),r(),(s||t.sp)&&!zi(t)&&rl(t),s){if(l.then(Ys,Ys),i)return l.then(a=>{Js(t,a)}).catch(a=>{fo(a,t,0)});t.asyncDep=l}else Js(t,l)}else El(t)}function Js(t,i,e){$t(i)?t.type.__ssrInlineRender?t.ssrRender=i:t.render=i:Pt(i)&&(t.setupState=Yr(i)),El(t)}function El(t,i,e){const n=t.type;t.render||(t.render=n.render||Fe);{const o=Cn(t);Je();try{td(t)}finally{Xe(),o()}}}const Ld={get(t,i){return ne(t,"get",""),t[i]}};function Od(t){const i=e=>{t.exposed=e||{}};return{attrs:new Proxy(t.attrs,Ld),slots:t.slots,emit:t.emit,expose:i}}function go(t){return t.exposed?t.exposeProxy||(t.exposeProxy=new Proxy(Yr(xc(t.exposed)),{get(i,e){if(e in i)return i[e];if(e in cn)return cn[e](t)},has(i,e){return e in i||e in cn}})):t.proxy}function Pd(t,i=!0){return $t(t)?t.displayName||t.name:t.name||i&&t.__name}function Rd(t){return $t(t)&&"__vccOpts"in t}const _t=(t,i)=>Ic(t,i,yn),zd="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Yo;const Xs=typeof window<"u"&&window.trustedTypes;if(Xs)try{Yo=Xs.createPolicy("vue",{createHTML:t=>t})}catch{}const Bl=Yo?t=>Yo.createHTML(t):t=>t,Nd="http://www.w3.org/2000/svg",Fd="http://www.w3.org/1998/Math/MathML",We=typeof document<"u"?document:null,Qs=We&&We.createElement("template"),jd={insert:(t,i,e)=>{i.insertBefore(t,e||null)},remove:t=>{const i=t.parentNode;i&&i.removeChild(t)},createElement:(t,i,e,n)=>{const o=i==="svg"?We.createElementNS(Nd,t):i==="mathml"?We.createElementNS(Fd,t):e?We.createElement(t,{is:e}):We.createElement(t);return t==="select"&&n&&n.multiple!=null&&o.setAttribute("multiple",n.multiple),o},createText:t=>We.createTextNode(t),createComment:t=>We.createComment(t),setText:(t,i)=>{t.nodeValue=i},setElementText:(t,i)=>{t.textContent=i},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>We.querySelector(t),setScopeId(t,i){t.setAttribute(i,"")},insertStaticContent(t,i,e,n,o,r){const l=e?e.previousSibling:i.lastChild;if(o&&(o===r||o.nextSibling))for(;i.insertBefore(o.cloneNode(!0),e),!(o===r||!(o=o.nextSibling)););else{Qs.innerHTML=Bl(n==="svg"?`<svg>${t}</svg>`:n==="mathml"?`<math>${t}</math>`:t);const s=Qs.content;if(n==="svg"||n==="mathml"){const a=s.firstChild;for(;a.firstChild;)s.appendChild(a.firstChild);s.removeChild(a)}i.insertBefore(s,e)}return[l?l.nextSibling:i.firstChild,e?e.previousSibling:i.lastChild]}},Hd=Symbol("_vtc");function Ud(t,i,e){const n=t[Hd];n&&(i=(i?[i,...n]:[...n]).join(" ")),i==null?t.removeAttribute("class"):e?t.setAttribute("class",i):t.className=i}const eo=Symbol("_vod"),Ml=Symbol("_vsh"),Dl={name:"show",beforeMount(t,{value:i},{transition:e}){t[eo]=t.style.display==="none"?"":t.style.display,e&&i?e.beforeEnter(t):Xi(t,i)},mounted(t,{value:i},{transition:e}){e&&i&&e.enter(t)},updated(t,{value:i,oldValue:e},{transition:n}){!i!=!e&&(n?i?(n.beforeEnter(t),Xi(t,!0),n.enter(t)):n.leave(t,()=>{Xi(t,!1)}):Xi(t,i))},beforeUnmount(t,{value:i}){Xi(t,i)}};function Xi(t,i){t.style.display=i?t[eo]:"none",t[Ml]=!i}const Wd=Symbol(""),Vd=/(?:^|;)\s*display\s*:/;function Kd(t,i,e){const n=t.style,o=qt(e);let r=!1;if(e&&!o){if(i)if(qt(i))for(const l of i.split(";")){const s=l.slice(0,l.indexOf(":")).trim();e[s]==null&&en(n,s,"")}else for(const l in i)e[l]==null&&en(n,l,"");for(const l in e){l==="display"&&(r=!0);const s=e[l];s!=null?Gd(t,l,!qt(i)&&i?i[l]:void 0,s)||en(n,l,s):en(n,l,"")}}else if(o){if(i!==e){const l=n[Wd];l&&(e+=";"+l),n.cssText=e,r=Vd.test(e)}}else i&&t.removeAttribute("style");eo in t&&(t[eo]=r?n.display:"",t[Ml]&&(n.display="none"))}const tr=/\s*!important$/;function en(t,i,e){if(St(e))e.forEach(n=>en(t,i,n));else if(e==null&&(e=""),i.startsWith("--"))t.setProperty(i,e);else{const n=qd(t,i);tr.test(e)?t.setProperty(ci(n),e.replace(tr,""),"important"):t[n]=e}}const er=["Webkit","Moz","ms"],To={};function qd(t,i){const e=To[i];if(e)return e;let n=ce(i);if(n!=="filter"&&n in t)return To[i]=n;n=ro(n);for(let o=0;o<er.length;o++){const r=er[o]+n;if(r in t)return To[i]=r}return i}function Gd(t,i,e,n){return t.tagName==="TEXTAREA"&&(i==="width"||i==="height")&&qt(n)&&e===n}const ir="http://www.w3.org/1999/xlink";function nr(t,i,e,n,o,r=tc(i)){n&&i.startsWith("xlink:")?e==null?t.removeAttributeNS(ir,i.slice(6,i.length)):t.setAttributeNS(ir,i,e):e==null||r&&!Dr(e)?t.removeAttribute(i):t.setAttribute(i,r?"":Ae(e)?String(e):e)}function or(t,i,e,n,o){if(i==="innerHTML"||i==="textContent"){e!=null&&(t[i]=i==="innerHTML"?Bl(e):e);return}const r=t.tagName;if(i==="value"&&r!=="PROGRESS"&&!r.includes("-")){const s=r==="OPTION"?t.getAttribute("value")||"":t.value,a=e==null?t.type==="checkbox"?"on":"":String(e);(s!==a||!("_value"in t))&&(t.value=a),e==null&&t.removeAttribute(i),t._value=e;return}let l=!1;if(e===""||e==null){const s=typeof t[i];s==="boolean"?e=Dr(e):e==null&&s==="string"?(e="",l=!0):s==="number"&&(e=0,l=!0)}try{t[i]=e}catch{}l&&t.removeAttribute(o||i)}function oi(t,i,e,n){t.addEventListener(i,e,n)}function Zd(t,i,e,n){t.removeEventListener(i,e,n)}const sr=Symbol("_vei");function Yd(t,i,e,n,o=null){const r=t[sr]||(t[sr]={}),l=r[i];if(n&&l)l.value=n;else{const[s,a]=Qd(i);if(n){const c=r[i]=iu(n,o);oi(t,s,c,a)}else l&&(Zd(t,s,l,a),r[i]=void 0)}}const Jd=/(Once|Passive|Capture)$/,Xd=/^on:?(?:Once|Passive|Capture)$/;function Qd(t){let i,e;for(;(e=t.match(Jd))&&!Xd.test(t);)i||(i={}),t=t.slice(0,t.length-e[1].length),i[e[1].toLowerCase()]=!0;return[t[2]===":"?t.slice(3):ci(t.slice(2)),i]}let Eo=0;const tu=Promise.resolve(),eu=()=>Eo||(tu.then(()=>Eo=0),Eo=Date.now());function iu(t,i){const e=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=e.attached)return;const o=e.value;if(St(o)){const r=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{r.call(n),n._stopped=!0};const l=o.slice(),s=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Ee(c,i,5,s)}}else Ee(o,i,5,[n])};return e.value=t,e.attached=eu(),e}const rr=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&t.charCodeAt(2)>96&&t.charCodeAt(2)<123,nu=(t,i,e,n,o,r)=>{const l=o==="svg";i==="class"?Ud(t,n,l):i==="style"?Kd(t,e,n):no(i)?oo(i)||Yd(t,i,e,n,r):(i[0]==="."?(i=i.slice(1),!0):i[0]==="^"?(i=i.slice(1),!1):ou(t,i,n,l))?(or(t,i,n),!t.tagName.includes("-")&&(i==="value"||i==="checked"||i==="selected")&&nr(t,i,n,l,r,i!=="value")):t._isVueCE&&(su(t,i)||t._def.__asyncLoader&&(/[A-Z]/.test(i)||!qt(n)))?or(t,ce(i),n,r,i):(i==="true-value"?t._trueValue=n:i==="false-value"&&(t._falseValue=n),nr(t,i,n,l))};function ou(t,i,e,n){if(n)return!!(i==="innerHTML"||i==="textContent"||i in t&&rr(i)&&$t(e));if(i==="spellcheck"||i==="draggable"||i==="translate"||i==="autocorrect"||i==="sandbox"&&t.tagName==="IFRAME"||i==="form"||i==="list"&&t.tagName==="INPUT"||i==="type"&&t.tagName==="TEXTAREA")return!1;if(i==="width"||i==="height"){const o=t.tagName;if(o==="IMG"||o==="VIDEO"||o==="CANVAS"||o==="SOURCE")return!1}return rr(i)&&qt(e)?!1:i in t}function su(t,i){const e=t._def.props;if(!e)return!1;const n=ce(i);return Array.isArray(e)?e.some(o=>ce(o)===n):Object.keys(e).some(o=>ce(o)===n)}const Wi=t=>{const i=t.props["onUpdate:modelValue"]||!1;return St(i)?e=>Pn(i,e):i};function ru(t){t.target.composing=!0}function lr(t){const i=t.target;i.composing&&(i.composing=!1,i.dispatchEvent(new Event("input")))}const Ye=Symbol("_assign");function ar(t,i,e){return i&&(t=t.trim()),e&&(t=lo(t)),t}const io={created(t,{modifiers:{lazy:i,trim:e,number:n}},o){t[Ye]=Wi(o);const r=n||o.props&&o.props.type==="number";oi(t,i?"change":"input",l=>{l.target.composing||t[Ye](ar(t.value,e,r))}),(e||r)&&oi(t,"change",()=>{t.value=ar(t.value,e,r)}),i||(oi(t,"compositionstart",ru),oi(t,"compositionend",lr),oi(t,"change",lr))},mounted(t,{value:i}){t.value=i??""},beforeUpdate(t,{value:i,oldValue:e,modifiers:{lazy:n,trim:o,number:r}},l){if(t[Ye]=Wi(l),t.composing)return;const s=(r||t.type==="number")&&!/^0\d/.test(t.value)?lo(t.value):t.value,a=i??"";if(s===a)return;const c=t.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===t&&t.type!=="range"&&(n&&i===e||o&&t.value.trim()===a)||(t.value=a)}},Dn={deep:!0,created(t,i,e){t[Ye]=Wi(e),oi(t,"change",()=>{const n=t._modelValue,o=kn(t),r=t.checked,l=t[Ye];if(St(n)){const s=ss(n,o),a=s!==-1;if(r&&!a)l(n.concat(o));else if(!r&&a){const c=[...n];c.splice(s,1),l(c)}}else if(Ki(n)){const s=new Set(n);r?s.add(o):s.delete(o),l(s)}else l(Ll(t,r))})},mounted:cr,beforeUpdate(t,i,e){t[Ye]=Wi(e),cr(t,i,e)}};function cr(t,{value:i,oldValue:e},n){t._modelValue=i;let o;if(St(i))o=ss(i,n.props.value)>-1;else if(Ki(i))o=i.has(n.props.value);else{if(i===e)return;o=qi(i,Ll(t,!0))}t.checked!==o&&(t.checked=o)}const lu={deep:!0,created(t,{value:i,modifiers:{number:e}},n){t._modelValue=i,oi(t,"change",()=>{const o=Array.prototype.filter.call(t.options,r=>r.selected).map(r=>e?lo(kn(r)):kn(r));t[Ye](t.multiple?Ki(t._modelValue)?new Set(o):o:o[0]),t._assigning=!0,Xr(()=>{t._assigning=!1})}),t[Ye]=Wi(n)},mounted(t,{value:i}){dr(t,i)},beforeUpdate(t,{value:i},e){t._modelValue=i,t[Ye]=Wi(e)},updated(t,{value:i}){t._assigning||dr(t,i)}};function dr(t,i){const e=t.multiple,n=St(i);if(!(e&&!n&&!Ki(i))){for(let o=0,r=t.options.length;o<r;o++){const l=t.options[o],s=kn(l);if(e)if(n){const a=typeof s;a==="string"||a==="number"?l.selected=i.some(c=>String(c)===String(s)):l.selected=ss(i,s)>-1}else l.selected=i.has(s);else if(qi(kn(l),i)){t.selectedIndex!==o&&(t.selectedIndex=o);return}}!e&&t.selectedIndex!==-1&&(t.selectedIndex=-1)}}function kn(t){return"_value"in t?t._value:t.value}function Ll(t,i){const e=i?"_trueValue":"_falseValue";return e in t?t[e]:i}const au=["ctrl","shift","alt","meta"],cu={stop:t=>t.stopPropagation(),prevent:t=>t.preventDefault(),self:t=>t.target!==t.currentTarget,ctrl:t=>!t.ctrlKey,shift:t=>!t.shiftKey,alt:t=>!t.altKey,meta:t=>!t.metaKey,left:t=>"button"in t&&t.button!==0,middle:t=>"button"in t&&t.button!==1,right:t=>"button"in t&&t.button!==2,exact:(t,i)=>au.some(e=>t[`${e}Key`]&&!i.includes(e))},Ce=(t,i)=>{if(!t)return t;const e=t._withMods||(t._withMods={}),n=i.join(".");return e[n]||(e[n]=((o,...r)=>{for(let l=0;l<i.length;l++){const s=cu[i[l]];if(s&&s(o,i))return}return t(o,...r)}))},du={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},uu=(t,i)=>{const e=t._withKeys||(t._withKeys={}),n=i.join(".");return e[n]||(e[n]=(o=>{if(!("key"in o))return;const r=ci(o.key);if(i.some(l=>l===r||du[l]===r))return t(o)}))},fu=ee({patchProp:nu},jd);let ur;function pu(){return ur||(ur=kd(fu))}const Ol=((...t)=>{const i=pu().createApp(...t),{mount:e}=i;return i.mount=n=>{const o=mu(n);if(!o)return;const r=i._component;!$t(r)&&!r.render&&!r.template&&(r.template=o.innerHTML),o.nodeType===1&&(o.textContent="");const l=e(o,!1,hu(o));return o instanceof Element&&(o.removeAttribute("v-cloak"),o.setAttribute("data-v-app","")),l},i});function hu(t){if(t instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&t instanceof MathMLElement)return"mathml"}function mu(t){return qt(t)?document.querySelector(t):t}function gu(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function be(t){const i=gu();if(i)try{return i(t)}catch{try{const e=t.startsWith("node:")?t.slice(5):`node:${t}`;return i(e)}catch{}}}function ws(){var i;if(typeof window<"u"&&window.process)return window.process;const t=be("process");return t&&t.versions?t:typeof process<"u"&&((i=process.versions)!=null&&i.node)?process:globalThis.process}function Pl(){var i,e;const t=ws();if(t&&((i=t.versions)!=null&&i.node))return!0;if(typeof window<"u"&&window.siyuan){const n=be("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((e=process.versions)!=null&&e.node))}function wn(){const t=ws();if(t!=null&&t.platform)return t.platform;if(typeof process<"u"&&process.platform)return process.platform;const i=be("os");if(i&&typeof i.platform=="function")return i.platform();if(typeof navigator<"u"){const e=navigator.userAgent.toLowerCase();if(e.includes("win"))return"win32";if(e.includes("mac"))return"darwin";if(e.includes("linux"))return"linux"}return"web"}function Rl(){var n,o;const t=ws(),i={...(t==null?void 0:t.env)||{}};if(wn()==="win32"){const r=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=t==null?void 0:t.env)!=null&&n.APPDATA?`${t.env.APPDATA}\\npm`:"",(o=t==null?void 0:t.env)!=null&&o.USERPROFILE?`${t.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(i).find(c=>c.toLowerCase()==="path")||"PATH",a=(i[l]||"").split(";").filter(Boolean);for(const c of r)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);i[l]=a.join(";")}return i}function Jo(t){var e,n,o;if(!t)return"";if(/^[a-zA-Z]:[/\\]/.test(t))return t.replace(/\\/g,"/");let i="";if(typeof window<"u"&&((o=(n=(e=window.siyuan)==null?void 0:e.config)==null?void 0:n.system)!=null&&o.dataDir)&&(i=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),i&&t.startsWith("/data/")){const r=t.slice(6);return`${i}/${r}`.replace(/\\/g,"/")}return t}function vu(){const t=be("os"),i=be("path");if(t&&typeof t.tmpdir=="function"){const e=t.tmpdir();return i&&typeof i.join=="function"?i.join(e,"siyuan-slidev-pro").replace(/\\/g,"/"):`${e}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class xs{constructor(i){yt(this,"runner");this.runner=i||xs.defaultRunner}static async defaultRunner(i,e){var n;try{let o=(n=be("child_process"))==null?void 0:n.execFile;if(!o){const a=await import("node:child_process").catch(()=>({}));o=a==null?void 0:a.execFile}if(!o)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=wn()==="win32",s=Rl();return await new Promise(a=>{o(i,e,{timeout:5e3,shell:l,env:s},(c,d,p)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:p?String(p).trim():""})})})}catch(o){return{code:-1,stdout:"",stderr:String(o)}}}async detect(){const i=Pl(),e=wn();if(!i)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,o,r=!1,l;try{const s=await this.runner("node",["-v"]);s.code===0&&s.stdout.startsWith("v")&&(n=!0,o=s.stdout)}catch{}if(n){try{const s=e==="win32"?"slidev.cmd":"slidev",a=await this.runner(s,["--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}if(!r)try{const s=e==="win32"?"npx.cmd":"npx",a=await this.runner(s,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:o,hasSlidevCli:r,slidevVersion:l,platform:e,isDesktop:i}}}class bu{constructor(){yt(this,"iframe",null);yt(this,"isReady",!1);yt(this,"pageChangedHandlers",[]);yt(this,"readyHandlers",[]);yt(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(i,e){var o;if(!((o=this.iframe)!=null&&o.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:i,...e};try{this.iframe.contentWindow.postMessage(n,"*")}catch(r){console.warn("[NativeSlidevBridge] postMessage error:",r)}}navigateToPage(i){this.postMessage("navigate",{no:i})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(i){return this.pageChangedHandlers.push(i),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(e=>e!==i)}}onReady(i){return this.readyHandlers.push(i),()=>{this.readyHandlers=this.readyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){const e=i.data;if(!(!e||e.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(e.type==="update-state"&&e.navState){const n=e.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const o of this.pageChangedHandlers)o(this.currentState.no,this.currentState.total||1,this.currentState)}else if(e.type==="navigate"&&typeof e.no=="number"){this.currentState.no=e.no;for(const n of this.pageChangedHandlers)n(e.no,this.currentState.total||1,this.currentState)}}}}class yu{constructor(i){yt(this,"childProcess",null);yt(this,"activePort",null);yt(this,"isRunning",!1);yt(this,"defaultPort");yt(this,"maxPortRetries");yt(this,"probeTimeoutMs");yt(this,"customSpawner");yt(this,"customPortChecker");this.defaultPort=(i==null?void 0:i.defaultPort)||3030,this.maxPortRetries=(i==null?void 0:i.maxPortRetries)||20,this.probeTimeoutMs=(i==null?void 0:i.probeTimeoutMs)||1e4,this.customSpawner=i==null?void 0:i.customSpawner,this.customPortChecker=i==null?void 0:i.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(i){if(this.customPortChecker)return this.customPortChecker(i);try{let e=be("net");return e||(e=await import("node:net").catch(()=>({}))),e!=null&&e.createServer?await new Promise(n=>{const o=e.createServer();o.once("error",()=>n(!1)),o.once("listening",()=>{o.close(()=>n(!0))}),o.listen(i,"127.0.0.1")}):!0}catch{return!0}}async allocPort(i){const e=i||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const o=e+n;if(await this.isPortAvailable(o))return o}return e}async pollServerReady(i,e=8e3,n=300){const o=Date.now();for(;Date.now()-o<e;){try{const r=new AbortController,l=setTimeout(()=>r.abort(),n),s=await fetch(i,{method:"HEAD",mode:"no-cors",signal:r.signal}).catch(()=>null);if(clearTimeout(l),s)return!0}catch{}await new Promise(r=>setTimeout(r,n))}return!1}async startServer(i,e){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(e);this.activePort=n;const r=wn()==="win32"?"npx.cmd":"npx",l=Jo(i),s=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(r,s,{detached:!1});else{let p=(a=be("child_process"))==null?void 0:a.spawn;if(!p){const w=await import("node:child_process").catch(()=>({}));p=w==null?void 0:w.spawn}if(!p)throw new Error("child_process spawn not available in current runtime");const g=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,u=Rl();this.childProcess=p(r,s,{cwd:g,detached:!1,shell:!0,env:{...u,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var i;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),wn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(i=be("child_process"))==null?void 0:i.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:o})=>{var r;o(`taskkill /pid ${(r=this.childProcess)==null?void 0:r.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class _s{constructor(){yt(this,"iframe",null);yt(this,"isReady",!1);yt(this,"pendingMessages",[]);yt(this,"slideChangedHandlers",[]);yt(this,"blockClickedHandlers",[]);yt(this,"openInEditorHandlers",[]);yt(this,"clientReadyHandlers",[]);yt(this,"openPeekDrawerHandlers",[]);yt(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(i,e){var o;const n={source:"siyuan-slidev-host",action:i,payload:e};if(!((o=this.iframe)!=null&&o.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(r){console.warn("[WebSandboxBridge] postMessage error:",r)}}updateSlides(i,e,n,o){this.postMessage("UPDATE_SLIDES",{slides:i,config:e,fullMarkdown:n,customThemeCss:o})}navigatePage(i){this.postMessage("NAVIGATE_PAGE",{pageIndex:i})}highlightElement(i){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:i})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(i){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:i})}onSlideChanged(i){return this.slideChangedHandlers.push(i),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(e=>e!==i)}}onBlockClicked(i){return this.blockClickedHandlers.push(i),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(e=>e!==i)}}onOpenInEditor(i){return this.openInEditorHandlers.push(i),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(e=>e!==i)}}onOpenPeekDrawer(i){return this.openPeekDrawerHandlers.push(i),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(e=>e!==i)}}onRequestToggleFullscreen(i){return this.toggleFullscreenHandlers.push(i),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(e=>e!==i)}}onClientReady(i){return this.clientReadyHandlers.push(i),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){var n;const e=i.data;if(!(!e||e.source!=="siyuan-slidev-client"))switch(e.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(e.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)o(e.payload.currentPage,e.payload.totalPages||1,e.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(e.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(e.payload.clickedBlockId,e.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(e.payload.blockId||e.payload.clickedBlockId){const o=e.payload.blockId||e.payload.clickedBlockId||"";for(const r of this.openInEditorHandlers)r(o,e.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(e.payload.peekType){const o=e.payload.blockId||e.payload.url||"",r={peekType:e.payload.peekType,target:o,title:e.payload.title};for(const l of this.openPeekDrawerHandlers)l(r)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break}}}const zl={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},ku=`<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-3 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,wu=`// Auto-generated by SiYuan Slidev Studio
export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,xu=`${zo}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function _u(t){var o;const i=[],e=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=e.exec(t))!==null;){const r=(o=n[1])==null?void 0:o.trim();r&&!i.includes(r)&&i.push(r)}return i}class Su{constructor(i){yt(this,"workspacePath");yt(this,"slidesFileName");yt(this,"cliBridge",new ts);const e=vu();!(i!=null&&i.workspacePath)||i.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=e:this.workspacePath=i.workspacePath,this.slidesFileName=(i==null?void 0:i.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(i="default"){const e={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return i&&i!=="default"&&(e.dependencies[`@slidev/theme-${i}`]="latest"),JSON.stringify(e,null,2)}buildSlidesMarkdown(i){return this.cliBridge.buildStandardSlidevMarkdown(i)}async scaffold(i,e){const n=this.buildSlidesMarkdown(i),o=this.generatePackageJson(i.config.theme),r=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,s=Jo(r),a=Jo(l),c=_u(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const b of c){const y=zl[b]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${b}
// #endregion snippet
`;d.set(b,y)}i.slides.some(b=>{var y;return((y=b.frontmatter)==null?void 0:y.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",ku),d.set("setup/root.ts",wu),d.set("styles/index.css",xu);const g=be("fs"),u=be("path");let w=!1;const h=u!=null&&u.dirname?u.dirname(s):"",k=/^[a-zA-Z]:[/\\]/.test(s)||s.includes("siyuan-slidev-pro");if(g&&u&&k)try{g.existsSync(h)||g.mkdirSync(h,{recursive:!0}),g.writeFileSync(a,o,"utf-8"),g.writeFileSync(s,n,"utf-8");for(const[b,y]of d.entries()){const S=u.join(h,b),T=u.dirname(S);g.existsSync(T)||g.mkdirSync(T,{recursive:!0}),g.existsSync(S)||g.writeFileSync(S,y,"utf-8")}w=!0}catch{}if(!w&&e)try{const b=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),y=typeof Blob<"u"?new Blob([o],{type:"application/json;charset=utf-8"}):Buffer.from(o,"utf-8");await e(l,!1,y),await e(r,!1,b);for(const[S,T]of d.entries()){const x=`${this.workspacePath}/${S}`,_=typeof Blob<"u"?new Blob([T],{type:"text/plain;charset=utf-8"}):Buffer.from(T,"utf-8");await e(x,!1,_).catch(()=>{})}return{success:!0,slidesPath:r,physicalSlidesPath:s,packageJsonPath:l}}catch(b){return{success:!1,slidesPath:r,physicalSlidesPath:s,packageJsonPath:l,error:String(b)}}return{success:!0,slidesPath:r,physicalSlidesPath:s,packageJsonPath:l}}}class Cu{constructor(){yt(this,"mode","web-sandbox");yt(this,"webBridge");yt(this,"cliBridge");yt(this,"nativeBridge");yt(this,"processManager");yt(this,"scaffolder");yt(this,"envDetector");this.webBridge=new _s,this.cliBridge=new ts,this.nativeBridge=new bu,this.processManager=new yu,this.scaffolder=new Su,this.envDetector=new xs}getMode(){return this.mode}setMode(i){this.mode=i}async startProMode(i,e){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const o=await this.scaffolder.scaffold(i,e);if(!o.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${o.error}`};const r=o.physicalSlidesPath||o.slidesPath,l=await this.processManager.startServer(r);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const $u={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Iu={key:0},Au={key:1},Tu={key:2},Eu={key:3},Bu={key:4},Mu={key:5},Du={key:6},Lu={key:7},Ou={key:8},Pu={key:9},Ru={key:10},zu={key:11},Nu={key:12},Fu={key:13},ju={key:14},Hu={key:15},Uu={key:16},Wu={key:17},Vu={key:18},Ku={key:19},qu={key:20},Gu={key:21},Zu={key:22},Yu={key:23},Ju={key:24},Xu={key:25},Qu={key:26},tf={key:27},ef={key:28},nf={key:29},of={key:30},sf={key:31},rf={key:32},lf={key:33},af={key:34},cf={key:35},df={key:36},uf={key:37},ff={key:38},pf={key:39},hf={key:40},mf={key:41},gf={key:42},vf={key:43},bf={key:44},yf={key:45},kf={key:46},wf={key:47},xf={key:48},_f={key:49},Sf={key:50},Cf={key:51},$f={key:52},If=he({__name:"SlidevIcon",props:{name:{}},setup(t){return(i,e)=>(tt(),nt("svg",$u,[t.name==="fullscreen"||t.name==="maximize"?(tt(),nt("g",Iu,[...e[0]||(e[0]=[m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("polyline",{points:"9 21 3 21 3 15"},null,-1),m("polyline",{points:"21 15 21 21 15 21"},null,-1),m("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):t.name==="minimize"?(tt(),nt("g",Au,[...e[1]||(e[1]=[m("polyline",{points:"4 14 10 14 10 20"},null,-1),m("polyline",{points:"20 10 14 10 14 4"},null,-1),m("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),m("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):t.name==="close"||t.name==="x"?(tt(),nt("g",Tu,[...e[2]||(e[2]=[m("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),m("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):t.name==="edit"?(tt(),nt("g",Eu,[...e[3]||(e[3]=[m("path",{d:"M12 20h9"},null,-1),m("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):t.name==="eye"?(tt(),nt("g",Bu,[...e[4]||(e[4]=[m("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),m("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):t.name==="external-link"||t.name==="window"?(tt(),nt("g",Mu,[...e[5]||(e[5]=[m("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):t.name==="arrow-left"?(tt(),nt("g",Du,[...e[6]||(e[6]=[m("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),m("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):t.name==="arrow-right"?(tt(),nt("g",Lu,[...e[7]||(e[7]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):t.name==="plus"?(tt(),nt("g",Ou,[...e[8]||(e[8]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="minus"?(tt(),nt("g",Pu,[...e[9]||(e[9]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="split-preview"?(tt(),nt("g",Ru,[...e[10]||(e[10]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),m("path",{d:"M12 3v18"},null,-1)])])):t.name==="import"?(tt(),nt("g",zu,[...e[11]||(e[11]=[m("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),m("polyline",{points:"7 9 12 14 17 9"},null,-1),m("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):t.name==="presenter"?(tt(),nt("g",Nu,[...e[12]||(e[12]=[m("path",{d:"M2 3h20"},null,-1),m("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),m("path",{d:"m7 21 5-5 5 5"},null,-1)])])):t.name==="video"?(tt(),nt("g",Fu,[...e[13]||(e[13]=[m("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),m("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):t.name==="step"?(tt(),nt("g",ju,[...e[14]||(e[14]=[m("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):t.name==="motion"?(tt(),nt("g",Hu,[...e[15]||(e[15]=[m("path",{d:"M5 12h14"},null,-1),m("path",{d:"m12 5 7 7-7 7"},null,-1),m("path",{d:"M5 6h4"},null,-1),m("path",{d:"M5 18h4"},null,-1)])])):t.name==="columns"?(tt(),nt("g",Uu,[...e[16]||(e[16]=[m("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),m("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):t.name==="code"?(tt(),nt("g",Wu,[...e[17]||(e[17]=[m("polyline",{points:"16 18 22 12 16 6"},null,-1),m("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):t.name==="insert-above"?(tt(),nt("g",Vu,[...e[18]||(e[18]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),m("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),m("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):t.name==="insert-below"?(tt(),nt("g",Ku,[...e[19]||(e[19]=[m("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),m("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="broom"?(tt(),nt("g",qu,[...e[20]||(e[20]=[m("path",{d:"m18 15-6-6"},null,-1),m("path",{d:"M4 20h16"},null,-1),m("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):t.name==="trash"?(tt(),nt("g",Gu,[...e[21]||(e[21]=[m("path",{d:"M3 6h18"},null,-1),m("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),m("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):t.name==="ai"||t.name==="sparkles"?(tt(),nt("g",Zu,[...e[22]||(e[22]=[m("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):t.name==="palette"?(tt(),nt("g",Yu,[...e[23]||(e[23]=[xe('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-b8552023></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-b8552023></path>',5)])])):t.name==="ratio"?(tt(),nt("g",Ju,[...e[24]||(e[24]=[m("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):t.name==="transition"?(tt(),nt("g",Xu,[...e[25]||(e[25]=[m("path",{d:"M8 3 4 7l4 4"},null,-1),m("path",{d:"M4 7h16"},null,-1),m("path",{d:"m16 21 4-4-4-4"},null,-1),m("path",{d:"M20 17H4"},null,-1)])])):t.name==="export-html"?(tt(),nt("g",Qu,[...e[26]||(e[26]=[m("polyline",{points:"16 16 12 12 8 16"},null,-1),m("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),m("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):t.name==="export-pdf"?(tt(),nt("g",tf,[...e[27]||(e[27]=[m("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),m("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),m("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):t.name==="pin"?(tt(),nt("g",ef,[...e[28]||(e[28]=[m("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),m("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):t.name==="refresh"?(tt(),nt("g",nf,[...e[29]||(e[29]=[m("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),m("path",{d:"M21 3v5h-5"},null,-1),m("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),m("path",{d:"M8 16H3v5"},null,-1)])])):t.name==="outline"?(tt(),nt("g",of,[...e[30]||(e[30]=[m("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),m("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),m("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):t.name==="chevron-left"?(tt(),nt("g",sf,[...e[31]||(e[31]=[m("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):t.name==="chevron-right"?(tt(),nt("g",rf,[...e[32]||(e[32]=[m("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):t.name==="copy"?(tt(),nt("g",lf,[...e[33]||(e[33]=[m("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),m("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):t.name==="image"?(tt(),nt("g",af,[...e[34]||(e[34]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),m("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),m("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):t.name==="search"?(tt(),nt("g",cf,[...e[35]||(e[35]=[m("circle",{cx:"11",cy:"11",r:"7"},null,-1),m("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):t.name==="settings"||t.name==="gear"?(tt(),nt("g",df,[...e[36]||(e[36]=[m("circle",{cx:"12",cy:"12",r:"3"},null,-1),m("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):t.name==="notes"||t.name==="file-text"?(tt(),nt("g",uf,[...e[37]||(e[37]=[xe('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-b8552023></path><polyline points="14 2 14 8 20 8" data-v-b8552023></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-b8552023></line><line x1="16" y1="17" x2="8" y2="17" data-v-b8552023></line><line x1="10" y1="9" x2="8" y2="9" data-v-b8552023></line>',5)])])):t.name==="focus"||t.name==="target"?(tt(),nt("g",ff,[...e[38]||(e[38]=[m("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),m("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),m("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):t.name==="layout-cover"||t.name==="cover"?(tt(),nt("g",pf,[...e[39]||(e[39]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),m("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),m("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):t.name==="layout-default"||t.name==="default"?(tt(),nt("g",hf,[...e[40]||(e[40]=[xe('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-b8552023></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-b8552023></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-b8552023></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-b8552023></line>',5)])])):t.name==="layout-two-cols"||t.name==="two-cols"?(tt(),nt("g",mf,[...e[41]||(e[41]=[xe('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-b8552023></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-b8552023></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-b8552023></line><line x1="5" y1="15" x2="8" y2="15" data-v-b8552023></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-b8552023></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-b8552023></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-b8552023></line>',8)])])):t.name==="layout-two-cols-header"||t.name==="two-cols-header"?(tt(),nt("g",gf,[...e[42]||(e[42]=[xe('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b8552023></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-b8552023></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-b8552023></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-b8552023></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-b8552023></line>',7)])])):t.name==="layout-three-cols-header"||t.name==="three-cols-header"?(tt(),nt("g",vf,[...e[43]||(e[43]=[xe('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b8552023></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-b8552023></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-b8552023></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-b8552023></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-b8552023></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-b8552023></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-b8552023></line>',10)])])):t.name==="layout-image-right"||t.name==="image-right"?(tt(),nt("g",bf,[...e[44]||(e[44]=[xe('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b8552023></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-b8552023></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-b8552023></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-b8552023></line><circle cx="15.5" cy="8.5" r="1.2" data-v-b8552023></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-b8552023></polyline>',7)])])):t.name==="layout-image-left"||t.name==="image-left"?(tt(),nt("g",yf,[...e[45]||(e[45]=[xe('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b8552023></line><circle cx="6" cy="8.5" r="1.2" data-v-b8552023></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-b8552023></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-b8552023></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-b8552023></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-b8552023></line>',7)])])):t.name==="layout-center"||t.name==="center"?(tt(),nt("g",kf,[...e[46]||(e[46]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="layout-fact"||t.name==="fact"?(tt(),nt("g",wf,[...e[47]||(e[47]=[xe('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><circle cx="8" cy="9" r="1.5" data-v-b8552023></circle><line x1="14" y1="8" x2="9" y2="14" data-v-b8552023></line><circle cx="15" cy="13" r="1.5" data-v-b8552023></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-b8552023></line>',5)])])):t.name==="layout-intro"||t.name==="intro"?(tt(),nt("g",xf,[...e[48]||(e[48]=[xe('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><circle cx="7.5" cy="9.5" r="2" data-v-b8552023></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-b8552023></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-b8552023></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-b8552023></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-b8552023></line>',6)])])):t.name==="layout-quote"||t.name==="quote"?(tt(),nt("g",_f,[...e[49]||(e[49]=[xe('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-b8552023></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-b8552023></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-b8552023></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-b8552023></line>',5)])])):t.name==="desktop"||t.name==="monitor"?(tt(),nt("g",Sf,[...e[50]||(e[50]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):t.name==="mobile"||t.name==="smartphone"||t.name==="phone"?(tt(),nt("g",Cf,[...e[51]||(e[51]=[m("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),m("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):(tt(),nt("g",$f,[...e[52]||(e[52]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Be=(t,i)=>{const e=t.__vccOpts||t;for(const[n,o]of i)e[n]=o;return e},bt=Be(If,[["__scopeId","data-v-b8552023"]]);function Xt(t,i){var o;if(typeof document>"u"||!t)return;const e=(o=globalThis.CSS)!=null&&o.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${e}"]`);!n||n.length===0||n.forEach(r=>{for(const[l,s]of Object.entries(i))s!=null&&s!==""?r.setAttribute(l,String(s)):r.removeAttribute(l)})}function Af(t){if(typeof document>"u")return;const i=`.protyle-wysiwyg [${ut}], .protyle-wysiwyg [${jt}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,e=document.querySelectorAll(i);!e||e.length===0||e.forEach(n=>{const o=n.getAttribute("data-node-id");if(!o){n.removeAttribute(ut),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(jt),n.removeAttribute("custom-slidev-role");return}const r=t.get(o),l=(r==null?void 0:r[ut])||(r==null?void 0:r["custom-slidev-layout"])||"",s=n.getAttribute(ut)||n.getAttribute("custom-slidev-layout");s&&s!==l&&(l?n.setAttribute(ut,l):(n.removeAttribute(ut),n.removeAttribute("custom-slidev-layout")));const a=(r==null?void 0:r[jt])||(r==null?void 0:r["custom-slidev-role"])||"",c=n.getAttribute(jt)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(jt,a):(n.removeAttribute(jt),n.removeAttribute("custom-slidev-role")))})}const Tf={class:"spm-layout-picker"},Ef={class:"spm-layout-picker__grid"},Bf=["title","onClick"],Mf={class:"spm-layout-icon"},Df={class:"spm-layout-label"},Lf=he({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,n=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"two-cols-header",label:"表头双栏",desc:"顶部通栏标题，下方左右双栏"},{name:"three-cols-header",label:"表头三栏",desc:"顶部通栏标题，下方等宽三栏"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function o(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(tt(),nt("div",Tf,[l[0]||(l[0]=m("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),m("div",Ef,[(tt(),nt(Ut,null,ge(n,s=>m("div",{key:s.name,class:Ct(["spm-layout-item",{active:t.modelValue===s.name}]),title:s.desc,onClick:a=>o(s.name)},[m("div",Mf,[ft(bt,{name:"layout-"+s.name},null,8,["name"])]),m("span",Df,xt(s.label),1)],10,Bf)),64))])]))}}),Nl=Be(Lf,[["__scopeId","data-v-c57441d5"]]),Of={key:0,class:"spm-transition-selector__header"},Pf={class:"spm-transition-list"},Rf=["onClick"],zf={class:"spm-transition-meta"},Nf={class:"spm-transition-label"},Ff={class:"spm-transition-name"},jf={class:"spm-transition-preview-box"},Hf=he({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function o(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(tt(),nt("div",{class:Ct(["spm-transition-selector",{"spm-transition-selector--no-header":t.hideHeader}])},[t.hideHeader?Ot("",!0):(tt(),nt("div",Of,xt(t.title||"转场动效"),1)),m("div",Pf,[(tt(),nt(Ut,null,ge(n,s=>m("div",{key:s.name,class:Ct(["spm-transition-item",{active:t.modelValue===s.name}]),onClick:a=>o(s.name)},[m("div",zf,[m("span",Nf,xt(s.label),1),m("span",Ff,"("+xt(s.name)+")",1)]),m("div",jf,[m("div",{class:Ct(["spm-anim-cube","anim-"+s.name])},null,2)])],10,Rf)),64))])],2))}}),Ss=Be(Hf,[["__scopeId","data-v-b0aa61ff"]]),Uf={class:"spm-divider-popover"},Wf={class:"spm-divider-popover__title"},Vf={class:"spm-form-item"},Kf={class:"spm-popover-footer"},qf={class:"spm-save-hint"},Gf=he({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(t,{emit:i}){var g,u,w;const e=t,n=i,o=ht(((g=e.initialAttrs)==null?void 0:g[ut])||"default"),r=ht(((u=e.initialAttrs)==null?void 0:u[Kt])||"slide-left"),l=ht(((w=e.initialAttrs)==null?void 0:w[zt])||""),s=ht("");_i(()=>e.initialAttrs,h=>{o.value=(h==null?void 0:h[ut])||"default",r.value=(h==null?void 0:h[Kt])||"slide-left",l.value=(h==null?void 0:h[zt])||""},{deep:!0});async function a(h,k){if(e.blockId){s.value="正在同步...",Rt.setBlockAttrOverride(e.blockId,{[h]:k}),Xt(e.blockId,{[h]:k});try{await Mt(e.blockId,{[h]:k}),s.value="已同步至块属性",n("updated",{[h]:k}),setTimeout(()=>{s.value=""},1500)}catch{s.value="同步失败"}}}function c(h){a(ut,h)}function d(h){a(Kt,h)}function p(){a(zt,l.value.trim())}return(h,k)=>(tt(),nt("div",Uf,[m("div",Wf,[k[4]||(k[4]=m("span",null,"幻灯片页面设置",-1)),m("button",{class:"spm-close-btn",onClick:k[0]||(k[0]=b=>n("close"))},"✕")]),ft(Nl,{modelValue:o.value,"onUpdate:modelValue":k[1]||(k[1]=b=>o.value=b),onChange:c},null,8,["modelValue"]),ft(Ss,{modelValue:r.value,"onUpdate:modelValue":k[2]||(k[2]=b=>r.value=b),onChange:d},null,8,["modelValue"]),m("div",Vf,[k[5]||(k[5]=m("label",{class:"spm-form-label"},"页面背景",-1)),_e(m("input",{"onUpdate:modelValue":k[3]||(k[3]=b=>l.value=b),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:p},null,544),[[io,l.value]])]),m("div",Kf,[m("span",qf,xt(s.value),1)])]))}}),Zf=Be(Gf,[["__scopeId","data-v-e4871368"]]),Yf={class:"spm-slide-inspector"},Jf={class:"spm-inspector-header"},Xf={class:"spm-inspector-list"},Qf=["onClick"],tp={class:"spm-card-top"},ep={class:"spm-card-badge"},ip={class:"spm-card-layout"},np=["onClick"],op={class:"spm-card-preview"},sp={key:0,class:"spm-card-notes",title:"演讲备忘录"},rp={class:"spm-inspector-modal-content"},lp=he({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(t,{emit:i}){const e=i,n=ht(null);function o(c){n.value=c}function r(c){const d={};return c.frontmatter.layout&&(d[ut]=c.frontmatter.layout),c.frontmatter.transition&&(d[Kt]=c.frontmatter.transition),c.frontmatter.background&&(d[zt]=c.frontmatter.background),c.notes&&(d[Di]=c.notes),d}function l(c){n.value&&(c[ut]&&(n.value.frontmatter.layout=c[ut]),c[Kt]&&(n.value.frontmatter.transition=c[Kt]),c[zt]&&(n.value.frontmatter.background=c[zt]),c[Di]&&(n.value.notes=c[Di]),e("refresh"))}function s(c){e("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const d=c.blocks[0],p=d.content||d.rawMarkdown||"";return p.slice(0,40)+(p.length>40?"...":"")}return(c,d)=>(tt(),nt("div",Yf,[m("div",Jf,[m("span",null,"幻灯片大纲 ("+xt(t.slides.length)+" 页)",1)]),m("div",Xf,[(tt(!0),nt(Ut,null,ge(t.slides,p=>(tt(),nt("div",{key:p.pageIndex,class:Ct(["spm-card",{active:t.currentActivePage===p.pageIndex}]),onClick:g=>s(p.pageIndex)},[m("div",tp,[m("span",ep,"P"+xt(p.pageIndex),1),m("span",ip,xt(p.frontmatter.layout||"default"),1),m("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Ce(g=>o(p),["stop"])},[ft(bt,{name:"settings"})],8,np)]),m("div",op,xt(a(p)),1),p.notes?(tt(),nt("div",sp,[ft(bt,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),m("span",null,xt(p.notes),1)])):Ot("",!0)],10,Qf))),128))]),n.value?(tt(),nt("div",{key:0,class:"spm-inspector-modal-mask",onClick:d[1]||(d[1]=Ce(p=>n.value=null,["self"]))},[m("div",rp,[ft(Zf,{"block-id":n.value.startBlockId,"initial-attrs":r(n.value),onClose:d[0]||(d[0]=p=>n.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Ot("",!0)]))}}),ap=Be(lp,[["__scopeId","data-v-68b25edd"]]),cp={class:"spm-immersion-header"},dp={class:"spm-immersion-header__left"},up={class:"spm-immersion-title"},fp={class:"spm-immersion-header__center"},pp={class:"spm-immersion-header__actions"},hp=["aria-label"],mp={class:"spm-immersion-body"},gp=he({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(t,{emit:i}){const e=t,n=i;function o(){n("update:visible",!1),n("close")}function r(){e.closeOnClickMask&&o()}function l(){n("update:isMaximized",!e.isMaximized),n("toggle-maximize")}function s(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),o())}return(a,c)=>_e((tt(),nt("div",{class:Ct(["spm-immersion-container",{"is-maximized":t.isMaximized}]),onKeydown:Ce(s,["stop"])},[m("div",{class:"spm-immersion-mask",onClick:r}),m("div",{class:Ct(["spm-immersion-drawer",{"is-maximized":t.isMaximized}])},[m("div",cp,[m("div",dp,[Mn(a.$slots,"header-left",{},()=>[m("span",up,xt(t.title),1)])]),m("div",fp,[Mn(a.$slots,"header-center",{},void 0)]),m("div",pp,[Mn(a.$slots,"header-actions",{},void 0),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":t.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[ft(bt,{name:t.isMaximized?"minimize":"maximize"},null,8,["name"])],8,hp),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:o},[ft(bt,{name:"close"})])])]),m("div",mp,[Mn(a.$slots,"default",{},void 0)])],2)],34)),[[Dl,t.visible]])}}),vp=Be(gp,[["__scopeId","data-v-3f1665db"]]),bp="slidev-config.json",Vi={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806"},ki=uo({...Vi});function yp(t){if(!t||typeof t!="object")return{...Vi};const i=t;return{enableWebServeJump:!!i.enableWebServeJump,webServeUrl:typeof i.webServeUrl=="string"&&i.webServeUrl.trim()?i.webServeUrl.trim():Vi.webServeUrl}}function Fi(t){if(!t||typeof t!="object")return{...ki};const i=t;return i.enableWebServeJump!==void 0&&(ki.enableWebServeJump=!!i.enableWebServeJump),i.webServeUrl!==void 0&&(ki.webServeUrl=String(i.webServeUrl)),{...ki}}function Cs(){return{...ki}}function Fl(t,i,e){const n=(t||Vi.webServeUrl).trim(),o=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,r=(e==null?void 0:e.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(o);let s=l.pathname.replace(/\/+$/,"");return s.endsWith("/stage/build/desktop")||(s=s?`${s}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${s}/`,l.searchParams.set("id",i),e!=null&&e.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",r),l.toString()}catch{const l=e!=null&&e.focus?"&focus=1":"";return`${o.replace(/\/+$/,"")}/stage/build/desktop/?id=${i}${l}&r=${r}`}}const kp={class:"spm-protyle-drawer"},wp={class:"spm-protyle-drawer__subbar"},xp={class:"spm-protyle-drawer__nav"},_p=["title"],Sp={class:"spm-protyle-drawer__actions"},Cp=["aria-label"],$p=["aria-label"],Ip=he({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(t,{emit:i}){const e=i,n=t,o=ht(n.blockId),r=ht(n.title||""),l=ht(!1),s=ht(!0),a=ht(!1),c=ht(""),d=ki,p=ht([]),g=ht(null);let u=null;_i(()=>n.blockId,C=>{C&&C!==o.value&&(o.value=C,r.value=n.title||"",p.value=[],h(C))}),Sn(()=>{o.value&&h(o.value)}),ms(()=>{k()});async function w(C){try{const D=await dn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${C}' LIMIT 1`);if(Array.isArray(D)&&D.length>0){const M=D[0];c.value=M.root_id||"";const z=M.id===M.root_id||M.type==="d";a.value=z,s.value=!z,!r.value&&M.content&&(r.value=M.content.trim().slice(0,30));return}}catch(D){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",D)}a.value=!1,s.value=!0}async function h(C,D){if(!g.value||!C)return;k(),await w(C),typeof D=="boolean"&&(s.value=!a.value&&D);let M,z;s.value&&!a.value?(M=["cb-get-all","cb-get-hl","cb-get-focus"],z={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(M=["cb-get-context","cb-get-hl"],z={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{u=new gt.Protyle(n.plugin.app,g.value,{blockId:C,action:M,render:z}),!l.value&&u&&typeof u.disable=="function"&&u.disable()}catch(J){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",J)}}function k(){if(u){try{typeof u.destroy=="function"&&u.destroy()}catch(C){console.warn("[ProtylePeekDrawer] Error destroying protyle:",C)}u=null}g.value&&(g.value.innerHTML="")}function b(){a.value||(s.value=!s.value,h(o.value,s.value))}function y(){l.value=!l.value,u&&(l.value?(typeof u.enable=="function"&&u.enable(),typeof u.focus=="function"&&u.focus()):typeof u.disable=="function"&&u.disable())}function S(){if(o.value)try{gt.openWindow({doc:{id:o.value},alwaysOnTop:!0})}catch(C){console.warn("[ProtylePeekDrawer] openWindow failed:",C)}}function T(){var M;if(!o.value)return;const C=Cs(),D=Fl(C.webServeUrl,o.value,{focus:!a.value});if(typeof window<"u"){const z=be("electron");(M=z==null?void 0:z.shell)!=null&&M.openExternal?z.shell.openExternal(D).catch(()=>{window.open(D,"_blank")}):window.open(D,"_blank")}e("external-jump",D)}function x(){if(p.value.length>0){const C=p.value.pop();C&&(o.value=C.blockId,r.value=C.title,s.value=C.isFocusMode,a.value=C.isDoc,h(C.blockId,C.isFocusMode))}}function _(C){const D=C.target;if(!D)return;const M=D.closest('[data-type="block-ref"]');if(M){const J=M.getAttribute("data-id");if(J&&J!==o.value){C.preventDefault(),C.stopPropagation(),p.value.push({blockId:o.value,title:r.value||o.value,isFocusMode:s.value,isDoc:a.value}),o.value=J,r.value=M.innerText.trim()||J,h(J);return}}const z=D.closest("a");if(z&&z.href&&z.href.startsWith("siyuan://blocks/")){C.preventDefault(),C.stopPropagation();const J=z.href.replace("siyuan://blocks/","").split("?")[0];J&&J!==o.value&&(p.value.push({blockId:o.value,title:r.value||o.value,isFocusMode:s.value,isDoc:a.value}),o.value=J,r.value=z.innerText.trim()||J,h(J))}}return(C,D)=>(tt(),nt("div",kp,[m("div",wp,[m("div",xp,[p.value.length>0?(tt(),nt("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:x},[ft(bt,{name:"arrow-left"}),D[0]||(D[0]=m("span",null,"返回",-1))])):Ot("",!0),m("span",{class:Ct(["spm-protyle-badge",{"is-focus":s.value&&!a.value}])},xt(s.value&&!a.value?"思源块聚焦":"思源文档速览"),3),m("span",{class:"spm-protyle-id",title:r.value||o.value},xt(r.value||o.value),9,_p)]),m("div",Sp,[a.value?Ot("",!0):(tt(),nt("button",{key:0,class:Ct(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":s.value}]),"aria-label":s.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:b},[ft(bt,{name:s.value?"focus":"file-text"},null,8,["name"]),m("span",null,xt(s.value?"块聚焦":"展开全文"),1)],10,Cp)),m("button",{class:Ct(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:y},[ft(bt,{name:l.value?"edit":"eye"},null,8,["name"]),m("span",null,xt(l.value?"编辑中":"只读"),1)],10,$p),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:S},[ft(bt,{name:"window"}),D[1]||(D[1]=m("span",null,"独立窗口",-1))]),Tt(d).enableWebServeJump?(tt(),nt("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:T},[ft(bt,{name:"external-link"}),D[2]||(D[2]=m("span",null,"外跳",-1))])):Ot("",!0)])]),m("div",{ref_key:"mountEl",ref:g,class:Ct(["spm-protyle-mount",{"is-focus-mode":s.value&&!a.value}]),onClick:_},null,2)]))}}),Ap=Be(Ip,[["__scopeId","data-v-7e586ef3"]]),Tp={class:"spm-webview-drawer"},Ep={class:"spm-webview-toolbar"},Bp={class:"spm-webview-toolbar__nav"},Mp=["disabled"],Dp=["disabled"],Lp=["aria-label"],Op={class:"spm-webview-toolbar__address"},Pp=["aria-label"],Rp={class:"spm-webview-toolbar__actions"},zp=["aria-label"],Np={class:"spm-zoom-controller"},Fp=["disabled"],jp=["disabled"],Hp={key:1,class:"spm-webview-fallback"},Up=["src"],fr="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",jl="siyuan-slidev-peek-view-mode";let Hl="desktop";function Wp(){if(typeof window<"u"&&window.localStorage)try{const t=window.localStorage.getItem(jl);if(t==="mobile"||t==="desktop")return t}catch{}return Hl}function Vp(t){if(Hl=t,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(jl,t)}catch{}}const Kp=he({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(t,{emit:i}){const e=i,n=t,o=ht(Pl()),r=ht(n.url),l=ht(n.url),s=ht(!1),a=ht(!1),c=ht(!1),d=ht(1),p=ht(!1),g=ht(Wp());let u=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const w=_t(()=>g.value==="mobile"?fr:u||void 0),h=ht(null),k=ht(null);let b=null,y=null,S=null;_i(()=>n.url,X=>{X&&X!==r.value&&(r.value=X,l.value=X,g.value==="mobile"&&D(!1),h.value&&typeof h.value.loadURL=="function"&&h.value.loadURL(X))}),_i(()=>n.visible,X=>{if(X)H(),g.value==="mobile"&&D(!1);else if(h.value)try{typeof h.value.stop=="function"&&h.value.stop()}catch{}}),Sn(()=>{T(),k.value&&typeof ResizeObserver<"u"&&(b=new ResizeObserver(()=>{const X=h.value;if(X&&typeof X.invalidate=="function")try{X.invalidate()}catch{}}),b.observe(k.value)),y=X=>{var mt;const pt=X.message||((mt=X.error)==null?void 0:mt.message);if(typeof pt=="string"&&pt.includes("Invalid guestInstanceId"))return X.preventDefault(),X.stopImmediatePropagation(),!0},window.addEventListener("error",y,!0),S=X=>{const pt=X.reason,mt=typeof pt=="string"?pt:pt==null?void 0:pt.message;typeof mt=="string"&&mt.includes("Invalid guestInstanceId")&&X.preventDefault()},window.addEventListener("unhandledrejection",S)}),ms(()=>{if(x(),b&&(b.disconnect(),b=null),y&&(window.removeEventListener("error",y,!0),y=null),S&&(window.removeEventListener("unhandledrejection",S),S=null),h.value)try{typeof h.value.stop=="function"&&h.value.stop()}catch{}});function T(){const X=h.value;X&&(X.addEventListener("dom-ready",_),X.addEventListener("did-start-loading",M),X.addEventListener("did-stop-loading",z),X.addEventListener("did-navigate",J),X.addEventListener("did-navigate-in-page",E),X.addEventListener("new-window",A))}function x(){const X=h.value;if(X)try{X.removeEventListener("dom-ready",_),X.removeEventListener("did-start-loading",M),X.removeEventListener("did-stop-loading",z),X.removeEventListener("did-navigate",J),X.removeEventListener("did-navigate-in-page",E),X.removeEventListener("new-window",A)}catch{}}function _(){const X=h.value;if(X&&typeof X.getUserAgent=="function"&&!u)try{const pt=X.getUserAgent();pt&&!pt.includes("iPhone")&&(u=pt)}catch{}g.value==="mobile"&&D(!1),H(),v()}function C(){const X=g.value==="mobile"?"desktop":"mobile";g.value=X,Vp(X),D(!0)}function D(X=!1){const pt=h.value;if(!pt)return;const mt=g.value==="mobile"?fr:u;if(typeof pt.setUserAgent=="function"&&mt)try{pt.setUserAgent(mt)}catch(Z){console.warn("[WebviewPeekDrawer] setUserAgent error:",Z)}if(X&&typeof pt.reload=="function")try{pt.reload()}catch(Z){console.warn("[WebviewPeekDrawer] reload error:",Z)}}function M(){s.value=!0}function z(){if(s.value=!1,v(),h.value&&typeof h.value.getURL=="function"){const X=h.value.getURL();X&&X!=="about:blank"&&(r.value=X,l.value=X)}}function J(X){X!=null&&X.url&&(r.value=X.url,l.value=X.url),v()}function E(X){X!=null&&X.url&&(r.value=X.url,l.value=X.url),v()}function A(X){X&&X.url&&(X.preventDefault(),h.value&&typeof h.value.loadURL=="function"&&h.value.loadURL(X.url))}function v(){const X=h.value;X&&(typeof X.canGoBack=="function"&&(a.value=X.canGoBack()),typeof X.canGoForward=="function"&&(c.value=X.canGoForward()))}function P(){h.value&&typeof h.value.goBack=="function"&&h.value.goBack()}function G(){h.value&&typeof h.value.goForward=="function"&&h.value.goForward()}function F(){h.value&&typeof h.value.reload=="function"&&h.value.reload()}function et(){let X=l.value.trim();X&&(/^https?:\/\//i.test(X)||(X=`https://${X}`),r.value=X,l.value=X,h.value&&typeof h.value.loadURL=="function"&&h.value.loadURL(X))}function H(){const X=h.value;if(X&&typeof X.setZoomFactor=="function")try{X.setZoomFactor(d.value)}catch(pt){console.warn("[WebviewPeekDrawer] setZoomFactor error:",pt)}}function V(){d.value=Math.min(2.5,Math.round((d.value+.1)*10)/10),H()}function R(){d.value=Math.max(.5,Math.round((d.value-.1)*10)/10),H()}function U(){d.value=1,H()}function at(X){X.preventDefault(),X.deltaY<0?V():X.deltaY>0&&R()}async function rt(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(r.value),p.value=!0,setTimeout(()=>{p.value=!1},2e3)}catch(X){console.warn("Copy url failed:",X)}}function st(){var pt;const X=r.value;if(typeof window<"u"){const mt=be("electron");(pt=mt==null?void 0:mt.shell)!=null&&pt.openExternal?mt.shell.openExternal(X).catch(()=>{window.open(X,"_blank")}):window.open(X,"_blank")}e("external-jump",X)}return(X,pt)=>{const mt=Yc("webview");return tt(),nt("div",Tp,[m("div",Ep,[m("div",Bp,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!a.value,"aria-label":"后退",onClick:P},[ft(bt,{name:"arrow-left"})],8,Mp),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"前进",onClick:G},[ft(bt,{name:"arrow-right"})],8,Dp),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":s.value?"正在加载...":"刷新页面",onClick:F},[ft(bt,{name:"refresh"})],8,Lp)]),m("div",Op,[_e(m("input",{"onUpdate:modelValue":pt[0]||(pt[0]=Z=>l.value=Z),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:uu(et,["enter"])},null,544),[[io,l.value]]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":p.value?"已复制地址！":"复制网址",onClick:rt},[ft(bt,{name:"copy"})],8,Pp)]),m("div",Rp,[m("button",{class:Ct(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":g.value==="mobile"}]),"aria-label":g.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:C},[ft(bt,{name:g.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,zp),m("div",Np,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:d.value<=.5,onClick:R},[ft(bt,{name:"minus"})],8,Fp),m("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:U},xt(Math.round(d.value*100))+"% ",1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:d.value>=2.5,onClick:V},[ft(bt,{name:"plus"})],8,jp)]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:st},[ft(bt,{name:"external-link"}),pt[1]||(pt[1]=m("span",null,"外跳",-1))])])]),m("div",{ref_key:"containerEl",ref:k,class:Ct(["spm-webview-body",{"is-mobile":g.value==="mobile"}]),onWheel:Ce(at,["ctrl"])},[m("div",{class:Ct(["spm-webview-viewport",{"is-mobile":g.value==="mobile"}])},[o.value?(tt(),$e(mt,{key:0,ref_key:"webviewRef",ref:h,class:"spm-webview-frame",src:r.value,useragent:w.value,allowpopups:"true",partition:"persist:slidev-peek",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(tt(),nt("div",Hp,[m("iframe",{class:"spm-webview-fallback-frame",src:r.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Up),m("div",{class:"spm-fallback-bar"},[pt[2]||(pt[2]=m("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),m("button",{class:"spm-icon-btn is-primary",onClick:st}," 在新标签页中打开 ↗ ")])]))],2)],34)])}}}),qp=Be(Kp,[["__scopeId","data-v-40e35375"]]);class Gp{constructor(){yt(this,"timers",new Map)}debounce(i,e,n=150){this.cancel(i);const o=setTimeout(()=>{this.timers.delete(i),e()},n);this.timers.set(i,o)}cancel(i){this.timers.has(i)&&(clearTimeout(this.timers.get(i)),this.timers.delete(i))}cancelAll(){for(const i of this.timers.values())clearTimeout(i);this.timers.clear()}hasPending(i){return this.timers.has(i)}}class Zp{constructor(i){yt(this,"blockToPageMap",new Map);yt(this,"debounceCtrl",new Gp);yt(this,"activeBlockId","");yt(this,"activePageIndex",1);yt(this,"currentDocId","");yt(this,"bridge",null);i&&(this.bridge=i)}setBridge(i){this.bridge=i}setDocId(i){this.currentDocId=i}updateSlidesIndex(i){this.blockToPageMap.clear();for(const e of i){e.startBlockId&&this.blockToPageMap.set(e.startBlockId,e.pageIndex);for(const n of e.blocks)this.blockToPageMap.set(n.id,e.pageIndex)}}getPageByBlockId(i){return this.blockToPageMap.get(i)??null}onCursorFocusBlock(i){if(!i||i===this.activeBlockId)return;this.activeBlockId=i;let e=this.getPageByBlockId(i);!e&&(i===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(e=1),e&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=e,this.bridge&&(this.bridge.navigatePage(e),this.bridge.highlightElement(i))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(i){this.activeBlockId=i;const e=this.getPageByBlockId(i);e&&(this.activePageIndex=e)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Si(t,i){var r,l;if(!t||typeof document>"u")return!1;const e=(r=globalThis.CSS)!=null&&r.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`);if(!n){if(i)try{return gt.openTab({app:i,doc:{id:t,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(s){console.warn("[SelectionMirror] openTab fallback failed:",s)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const o=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=o},1200),!0}function Qt(t){return t?t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Yp(t){if(!t||t.trim()===""||t.trim()==="all")return"all";const i=new Set,e=t.split("|");for(const n of e){const o=n.trim();if(o==="all")return"all";if(o.includes("-")){const[r,l]=o.split("-"),s=parseInt(r,10),a=parseInt(l,10);if(!isNaN(s)&&!isNaN(a))for(let c=Math.min(s,a);c<=Math.max(s,a);c++)i.add(c)}else{const r=parseInt(o,10);isNaN(r)||i.add(r)}}return i}const Jp=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function fe(t){if(!t)return"";const i=Cr(t),e=[],n=i.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(r,l)=>{const s=l.toLowerCase();if(!Jp.has(s)||/on\w+\s*=|javascript:/i.test(r))return r;if(s==="v-mark"){const a=r.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return r.startsWith("</")?e.push("</mark>"):e.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${e.length-1}%%`}return e.push(r),`%%SAFE_HTML_${e.length-1}%%`});let o=Qt(n);return o=o.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(r,l,s,a,c,d,p)=>{const u=(s??a??c??d??p??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${u}</a>`}),o=o.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(r,l,s)=>{const c=/\.gif(?:\?|$)/i.test(s)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${s}" class="${c}" />`}),o=o.replace(/\[(.*?)\]\((.*?)\)/g,(r,l,s)=>{if(s.startsWith("siyuan://blocks/")){const a=s.replace("siyuan://blocks/","").split("?")[0];return`<a href="${s}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${s}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),o=o.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(r,l,s,a)=>`${l}<a href="${s}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${s}</a>`),o=o.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),o=o.replace(/\*(.*?)\*/g,"<em>$1</em>"),o=o.replace(/~~(.*?)~~/g,"<del>$1</del>"),o=o.replace(/`([^`]+)`/g,"<code>$1</code>"),o=o.replace(/%%SAFE_HTML_(\d+)%%/g,(r,l)=>{const s=parseInt(l,10);return e[s]||""}),o}function Xp(t,i="pdf-table"){if(t.length<2)return"";const e=t.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=e[0];let o=[],r=1;t.length>=2&&e[1].every(a=>/^:?-+:?$/.test(a))&&(o=e[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),r=2);const l=`<thead><tr>${n.map((a,c)=>`<th${o[c]?` style="text-align: ${o[c]}"`:""}>${fe(a)}</th>`).join("")}</tr></thead>`,s=e.slice(r).map(a=>`<tr>${a.map((c,d)=>`<td${o[d]?` style="text-align: ${o[d]}"`:""}>${fe(c)}</td>`).join("")}</tr>`).join("");return`<table class="${i}">${l}<tbody>${s}</tbody></table>`}function Bo(t){return String(t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Qp(t,i="ts"){if(!t)return"";if(t.trim().startsWith("//"))return`<span class="token-comment">${Bo(t)}</span>`;const e=[];function n(r,l){return e.push(`<span class="${r}">${Bo(l)}</span>`),`__TOK_${e.length-1}__`}let o=t.replace(/(['"`])(.*?)\1/g,(r,l,s)=>n("token-string",`${l}${s}${l}`));return o=o.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,r=>n("token-keyword",r)),o=o.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,r=>n("token-type",r)),o=o.replace(/\b(\d+)\b/g,r=>n("token-number",r)),o=Bo(o),o=o.replace(/__TOK_(\d+)__/g,(r,l)=>e[parseInt(l,10)]||""),o}function th(t,i){if(!t)return null;const e=t.frontmatter||{};if(e.hideInToc===!0||e.hideInToc==="true")return null;let n=(e.title||"").trim(),o=e.level?parseInt(e.level,10):0;if(!n){const r=t.blocks||[];for(const l of r){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){o||(o=a[1].length),n=a[2].trim();break}}}return n?((!o||isNaN(o))&&(o=1),{pageIndex:t.pageIndex||i,title:n,level:o}):null}function eh(t,i=1,e={}){const n=e.minDepth!==void 0?Number(e.minDepth):1,o=e.maxDepth!==void 0?Number(e.maxDepth):1/0,r=[];Array.isArray(t)&&t.forEach((c,d)=>{const p=th(c,d+1);p&&r.push(p)});const l=[];let s=null;for(const c of r){const d={...c,active:c.pageIndex===i,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),s=d):s?(d.active&&(s.hasActiveChild=!0),s.children.push(d)):l.push(d)}function a(c,d=1){if(d>o)return[];const p=[];for(const g of c){const u=a(g.children,d+1);d>=n?p.push({...g,children:u}):p.push(...u)}return p}return a(l,1)}function ih(t,i=1,e={}){const n=eh(t,i,e),o=e.columns?Number(e.columns):1,r=o>1?` style="column-count: ${o};"`:"",l=e.textSm?" text-sm":"";function s(c,d=1){if(!c||c.length===0)return"";const p=`slidev-toc-list slidev-toc-list-level-${d}`,g=c.map(u=>{const w=u.active?" slidev-toc-item-active":u.hasActiveChild?" slidev-toc-item-parent-active":"",h=u.children&&u.children.length>0?s(u.children,d+1):"";let k=fe(u.title);return k.includes("LaTeX")&&(k=k.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${w}" data-page="${u.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${k}</span>
          </a>
          ${h}
        </li>
      `}).join("");return`<ol class="${p}">${g}</ol>`}const a=s(n,1);return`<div class="slidev-toc${l}"${r}>${a}</div>`}function Ul(t,i,e){var w,h,k,b;const n=t.split(`
`);if(!n.some(y=>/^(\s*)([-*+]|\d+\.)\s+/.test(y)))return null;const r=[],l=[];let s=!1;for(let y=0;y<n.length;y++){const S=n[y];if(!S.trim())continue;const T=S.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(T){const D=T[1].length,M=Math.floor(D/2);l.push({type:"task",level:M,checked:T[2].toLowerCase()==="x",text:T[3],media:[]});continue}const x=S.match(/^(\s*)[-*+]\s+(.*)$/);if(x){const D=x[1].length,M=Math.floor(D/2);l.push({type:"unordered",level:M,text:x[2],media:[]});continue}const _=S.match(/^(\s*)\d+\.\s+(.*)$/);if(_){l.length===0&&(s=!0);const D=_[1].length,M=Math.floor(D/2);l.push({type:"ordered",level:M,text:_[2],media:[]});continue}const C=S.trim();if(!(!C||/^\{:.*?\}$/.test(C)))if(l.length>0){const D=C.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(D){const J=/\.gif(?:\?|$)/i.test(D[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${Qt(D[1])}" src="${D[2]}" class="${J}" /></div>`);continue}if(C.match(/^<img\b[\s\S]*?\/?>$/i)){const z=C.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${z}</div>`);continue}if(/<video\b/i.test(C)){let z=C;if(!/<\/video>/i.test(z))for(;y+1<n.length&&!/<\/video>/i.test(z);)y++,z+=" "+n[y].trim();const J=((w=e==null?void 0:e.attributes)==null?void 0:w["custom-slidev-autoplay"])==="true"||/autoplay/i.test(z),E=((h=e==null?void 0:e.attributes)==null?void 0:h["custom-slidev-loop"])==="true"||/loop/i.test(z),A=((k=e==null?void 0:e.attributes)==null?void 0:k["custom-slidev-muted"])==="true"||J||/muted/i.test(z),v=((b=e==null?void 0:e.attributes)==null?void 0:b["custom-slidev-controls"])==="false",P=z.match(/\bsrc=["']([^"']+)["']/i),G=P?P[1]:"",F=['class="slide-video-player"'];v||F.push("controls"),J&&(F.push("autoplay"),F.push("playsinline")),E&&F.push("loop"),A&&F.push("muted"),F.push('preload="metadata"'),G&&F.push(`src="${G}"`);const et=z.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let H=et?et[1].trim():"";!H&&G&&(H=`<source src="${G}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${J?"true":"false"}" data-muted="${A?"true":"false"}"><video ${F.join(" ")}>${H}</video></div>`);continue}l[l.length-1].text+=`
`+C}else r.push(C)}if(l.length===0)return null;function a(y){if(!y)return"";const S=y.split(`
`).map(D=>D.trim()).filter(Boolean);if(S.length===0)return"";if(!S.some(D=>/^#{1,6}\s+/.test(D)))return fe(S.join(" "));const x=[];let _=[];const C=()=>{if(_.length>0){const D=_.join(" ");x.push(`<p class="slide-list-item-desc">${fe(D)}</p>`),_=[]}};for(const D of S){const M=D.match(/^(#{1,6})\s+(.*)$/);if(M){C();const z=M[1].length,J=M[2].trim();x.push(`<h${z} class="slide-list-item-title">${fe(J)}</h${z}>`)}else _.push(D)}return C(),x.join(`
`)}function c(y){if(y.length===0)return"";const S=[];let T=[];const x=C=>{if(T.length>0){const D=T.join(" "),M=C?"slide-list-item-title":"slide-list-item-desc";S.push(`<p class="${M}">${fe(D)}</p>`),T=[]}};let _=!0;for(const C of y){const D=C.match(/^(#{1,6})\s+(.*)$/);if(D){x(_);const M=D[1].length,z=D[2].trim();S.push(`<h${M} class="slide-list-item-title">${fe(z)}</h${M}>`),_=!1}else T.push(C)}return x(_),S.join(`
`)+(S.length>0?`
`:"")}const d=s?"ol":"ul",p=s?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered",g=l.map(y=>{const S=a(y.text),T=y.media&&y.media.length>0?`
${y.media.join(`
`)}`:"",x=y.level||0,_=x>0?` style="margin-left:${(x*1.25).toFixed(2)}em;${y.type==="unordered"?`list-style-type:${x%2===1?"circle":"square"} !important;`:""}"`:"",C=x>0?" slide-list-item--nested":"";if(y.type==="task"){const M=y.checked?' checked=""':"";return`<li class="pdf-task-item${C}"${_}><label><input type="checkbox" disabled=""${M}/> <span>${S}</span></label>${T}</li>`}return`<li${C?` class="${C.trim()}"`:""}${_}>${S}${T}</li>`}).join(`
`);return`${c(r)}<${d} class="${p}">
${g}
</${d}>`}function De(t,i){var k,b,y,S,T,x,_,C,D;let e="",n="",o="";const r=[];(k=t.motion)!=null&&k.preset&&t.motion.preset!=="none"&&(e=` slidev-motion-${t.motion.preset.toLowerCase()}`,typeof t.motion.duration=="number"&&t.motion.duration>0&&r.push(`--motion-duration:${t.motion.duration}ms`),typeof t.motion.delay=="number"&&t.motion.delay>0&&r.push(`--motion-delay:${t.motion.delay}ms`));const l=((b=t.attributes)==null?void 0:b.style)||"";l&&(r.push(l),o=" slide-styled-block"),r.length>0&&(n=` style="${Qt(r.join(";"))}"`);const a=`pdf-block${e}${o}`,c=(t.rawMarkdown||t.content||"").trim();if(!c)return`<div class="${a}"${n}></div>`;if(c.includes('class="slidev-block-ref"')||c.includes('class="slidev-ref-tag"'))return`<div class="${a}"${n}>${c}</div>`;if(c.startsWith("$$")&&c.endsWith("$$")){const M=c.slice(2,-2).trim();return`<div class="${a} katex-display-container"${n}><div class="katex-display font-math"><em>${Qt(M)}</em></div></div>`}const d=c.match(/^(#{1,6})\s+(.*)$/);if(d){const M=d[1].length,z=fe(d[2]);return`<div class="${a}"${n}><h${M}>${z}</h${M}></div>`}if(c.startsWith(":::")){const M=c.split(`
`),J=M[0].replace(/^:::\s*/,"").trim()||"info",E=M.slice(1,M[M.length-1].startsWith(":::")?-1:void 0).join(`
`),A="pdf-callout";return`<div class="${a}"${n}><div class="${A} ${A}--${J}"><div class="${A}-title">${J.toUpperCase()}</div><div class="${A}-body">${fe(E)}</div></div></div>`}if(c.startsWith("<<<")){const J=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((P,G)=>`<span class="code-line shiki-focus"><span class="line-no">${G+1}</span><span class="line-content">${Qp(P,"ts")}</span></span>`).join(`
`),E="pdf-code shiki-container",A=((y=t.attrs)==null?void 0:y["custom-slidev-max-height"])||t.maxHeight||"",v=A?` style="max-height:${Qt(A)};overflow-y:auto;"`:"";return`<div class="${a}"${n}><pre class="${E}"${v}><span class="lang-badge">TS</span><code>${J}</code></pre></div>`}if(c.startsWith("<style")||c.startsWith("<!-- Inline style -->")||c.startsWith(`<!--
Notes`))return"";if(c.startsWith("```")){const M=c.split(`
`),z=M[0].slice(3).trim(),J=z.match(/^([^\s{\[]+)/),E=J?J[1]:"",A=z.match(/\[([^\]]+)\]/),v=A?A[1]:"",P=z.includes("twoslash"),G=t.shikiLines||((S=z.match(/\{([^}]+)\}/))==null?void 0:S[1])||"",F=Yp(G),et=M.length>2?M[M.length-1]==="```"?M.slice(1,-1):M.slice(1):[c.slice(3).replace(/```$/,"")],H="pdf-code shiki-container",V=v?`${H} has-filename`:H,R=F!=="all",U=et.map((pt,mt)=>{const Z=mt+1,ct=F==="all"||F.has(Z)?"code-line shiki-focus":R?"code-line shiki-dimmed":"code-line";let B=Qt(pt);return P&&pt.includes("doubled.value = 2")?(B=B.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${ct}"><span class="line-no">${Z}</span><span class="line-content">${B}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${ct}"><span class="line-no">${Z}</span><span class="line-content">${B}</span></span>`}).join(`
`),at=E?`<span class="lang-badge">${Qt(E)}</span>`:"",rt=v?`<span class="code-filename">${Qt(v)}</span>`:"",st=((T=t.attrs)==null?void 0:T["custom-slidev-max-height"])||t.maxHeight||"",X=st?` style="max-height:${Qt(st)};overflow-y:auto;"`:"";return`<div class="${a}"${n}><pre class="${V}"${X}>${rt}${at}<code>${U}</code></pre></div>`}if(c.includes("|")&&c.split(`
`).filter(M=>M.trim().startsWith("|")).length>=2){const M=c.split(`
`).filter(J=>J.trim().startsWith("|")),z=Xp(M,i==null?void 0:i.tableClassName);return`<div class="${a}"${n}>${z}</div>`}if(c.startsWith("> "))return`<div class="${a}"${n}><blockquote class="pdf-quote"><p>${fe(c.slice(2))}</p></blockquote></div>`;const p=/<video\b/i.test(c)||t.type==="video"||t.type==="NodeVideo",g=/^(\s*)([-*+]|\d+\.)\s+/m.test(c),u=/(?:^|\n)\s*#{1,6}\s+/.test(c);if(p&&!g&&!u&&!c.includes(`
`)){const M=((x=t.attributes)==null?void 0:x["custom-slidev-autoplay"])==="true"||/autoplay/i.test(c),z=((_=t.attributes)==null?void 0:_["custom-slidev-loop"])==="true"||/loop/i.test(c),J=((C=t.attributes)==null?void 0:C["custom-slidev-muted"])==="true"||M||/muted/i.test(c),E=((D=t.attributes)==null?void 0:D["custom-slidev-controls"])==="false",A=c.match(/\bsrc=["']([^"']+)["']/i),v=A?A[1]:"",P=['class="slide-video-player"'];E||P.push("controls"),M&&(P.push("autoplay"),P.push("playsinline")),z&&P.push("loop"),J&&P.push("muted"),P.push('preload="metadata"'),v&&P.push(`src="${v}"`);const G=c.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let F=G?G[1].trim():"";return!F&&v&&(F=`<source src="${v}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${a} ${a}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${M?"true":"false"}" data-muted="${J?"true":"false"}"${n}><video ${P.join(" ")}>${F}</video></div>`}const w=c.match(/^!\[(.*?)\]\((.*?)\)$/);if(w)return`<div class="${a} ${a}--image slide-media-block slide-media-container"${n}><img alt="${Qt(w[1])}" src="${w[2]}" class="pdf-image slide-media-img" /></div>`;const h=Ul(c,i,t);if(h)return`<div class="${a} pdf-list-item"${n}>${h}</div>`;if(/<(?:Toc|toc)\b/i.test(c)&&!c.startsWith("```")){const M=c.match(/minDepth=["']?(\d+)["']?/i),z=c.match(/maxDepth=["']?(\d+)["']?/i),J=c.match(/columns=["']?(\d+)["']?/i);return`<div class="${a}"${n}>${ih([],1,{minDepth:M?parseInt(M[1],10):1,maxDepth:z?parseInt(z[1],10):1/0,columns:J?parseInt(J[1],10):1,textSm:c.includes("text-sm")})}</div>`}if(c.includes(`
`)||u){const M=nh(c,i,t);if(M)return`<div class="${a}"${n}>${M}</div>`}return`<div class="${a}"${n}><p>${fe(c)}</p></div>`}function nh(t,i,e){const n="pdf-block",o=t.split(/\r?\n/),r=[];let l=[];for(let a=0;a<o.length;a++){const c=o[a],d=c.trim();if(/^#{1,6}\s+/.test(d)){l.length>0&&(r.push(l.join(`
`)),l=[]),r.push(d);continue}if(!d){l.length>0&&(r.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(d)){l.length>0&&(r.push(l.join(`
`)),l=[]),r.push(d);continue}if(/<video\b/i.test(d)){l.length>0&&(r.push(l.join(`
`)),l=[]);let p=d;if(!/<\/video>/i.test(p))for(;a+1<o.length&&!/<\/video>/i.test(p);)a++,p+=`
`+o[a];r.push(p);continue}l.push(c)}return l.length>0&&r.push(l.join(`
`)),r.map(a=>{var u,w,h,k;const c=a.trim();if(!c)return"";const d=c.match(/^(#{1,6})\s+(.*)$/);if(d){const b=d[1].length;return`<h${b} class="slide-list-item-title">${fe(d[2].trim())}</h${b}>`}const p=c.match(/^!\[(.*?)\]\((.*?)\)$/);if(p){const y=/\.gif(?:\?|$)/i.test(p[2])?"list-item-gif":"pdf-image slide-media-img";return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${Qt(p[1])}" src="${p[2]}" class="${y}" /></div>`}if(/<video\b/i.test(c)){const b=((u=e==null?void 0:e.attributes)==null?void 0:u["custom-slidev-autoplay"])==="true"||/autoplay/i.test(c),y=((w=e==null?void 0:e.attributes)==null?void 0:w["custom-slidev-loop"])==="true"||/loop/i.test(c),S=((h=e==null?void 0:e.attributes)==null?void 0:h["custom-slidev-muted"])==="true"||b||/muted/i.test(c),T=((k=e==null?void 0:e.attributes)==null?void 0:k["custom-slidev-controls"])==="false",x=c.match(/\bsrc=["']([^"']+)["']/i),_=x?x[1]:"",C=['class="slide-video-player"'];T||C.push("controls"),b&&C.push("autoplay playsinline"),y&&C.push("loop"),S&&C.push("muted"),C.push('preload="metadata"'),_&&C.push(`src="${_}"`);const D=c.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let M=D?D[1].trim():"";return!M&&_&&(M=`<source src="${_}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${b?"true":"false"}" data-muted="${S?"true":"false"}"><video ${C.join(" ")}>${M}</video></div>`}const g=Ul(c,i,e);return g||`<p class="slide-list-item-desc">${fe(c)}</p>`}).filter(Boolean).join(`
`)}function oh(t,i){var r,l,s,a;const e=((r=t.frontmatter)==null?void 0:r.layout)||"default",o=(t.blocks||[]).filter(c=>c.slot!=="slot-divider-right");if(e==="two-cols"){const c=o.some(y=>y.slot==="right");let d=[],p=[];if(c)d=o.filter(y=>y.slot!=="right"),p=o.filter(y=>y.slot==="right");else{const y=Math.ceil(o.length/2);d=o.slice(0,y),p=o.slice(y)}const g=d.map(y=>De(y,i)).join(`
`),u=p.map(y=>De(y,i)).join(`
`),w="pdf-two-cols-wrapper layout-two-cols-grid",h=(l=t.frontmatter)!=null&&l.layoutClass?` ${t.frontmatter.layoutClass}`:"";return`
      <div class="${w}${h}">
        <div class="pdf-col pdf-col--left">${g}</div>
        <div class="pdf-col pdf-col--right">${u}</div>
      </div>
    `}if(e==="two-cols-header"){let c=[];const d=o.filter(y=>y.slot==="header");if(d.length>0)c=d;else if(o.length>0){const y=o.find(S=>S.type==="h"&&(!S.slot||S.slot==="default"));y&&(c=[y])}const p=o.filter(y=>!c.includes(y)),g=p.filter(y=>y.slot==="right"||y.slot==="col-2"),u=p.filter(y=>!g.includes(y)),w=y=>{const S=y.filter(T=>!!(T.rawMarkdown||T.content||"").trim());if(S.length>0){const T=S[0],x=(T.rawMarkdown||T.content||"").trim();(ji(T)||/^(?:[-*+]|\d+\.)\s+/.test(x))&&(T.rawMarkdown=Po(T.rawMarkdown||T.content||""),T.content=T.rawMarkdown)}return S.map(T=>De(T,i)).join(`
`)},h=c.map(y=>De(y,i)).join(`
`),k=w(u),b=w(g);return`
      <div class="layout-two-cols-header-container">
        <div class="layout-header-section">${h}</div>
        <div class="pdf-two-cols-wrapper layout-two-cols-grid">
          <div class="pdf-col pdf-col--left">${k}</div>
          <div class="pdf-col pdf-col--right">${b}</div>
        </div>
      </div>
    `}if(e==="three-cols-header"){let c=[];const d=o.filter(T=>T.slot==="header");if(d.length>0)c=d;else if(o.length>0){const T=o.find(x=>x.type==="h"&&(!x.slot||x.slot==="default"));T&&(c=[T])}const p=o.filter(T=>!c.includes(T)),{col1:g,col2:u,col3:w}=Ir(p),h=T=>{const x=T.filter(_=>!!(_.rawMarkdown||_.content||"").trim());if(x.length>0){const _=x[0],C=(_.rawMarkdown||_.content||"").trim();(ji(_)||/^(?:[-*+]|\d+\.)\s+/.test(C))&&(_.rawMarkdown=Po(_.rawMarkdown||_.content||""),_.content=_.rawMarkdown)}return x.map(_=>De(_,i)).join(`
`)},k=c.map(T=>De(T,i)).join(`
`),b=h(g),y=h(u),S=h(w);return`
      <div class="layout-three-cols-header-container">
        <div class="layout-header-section">${k}</div>
        <div class="pdf-three-cols-wrapper layout-three-cols-grid">
          <div class="pdf-col pdf-col--1">${b}</div>
          <div class="pdf-col pdf-col--2">${y}</div>
          <div class="pdf-col pdf-col--3">${S}</div>
        </div>
      </div>
    `}if(e==="image-right"||e==="image-left"){const c=e==="image-right",d=o.map(h=>De(h,i)).join(`
`),p=((s=t.frontmatter)==null?void 0:s.image)||((a=t.frontmatter)==null?void 0:a.background)||"",g=`<div class="pdf-image-col" style="background-image:url('${Qt(p)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${Qt(p)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,u=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${d}</div>`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:1fr 1fr;grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${c?`${u}
${g}`:`${g}
${u}`}
      </div>
    `}return e==="fact"?`<div class="layout-fact-container">${o.map(d=>De(d,i)).join(`
`)}</div>`:e==="cover"?`<div class="layout-cover-container">${o.map(d=>De(d,i)).join(`
`)}</div>`:o.map(c=>De(c,i)).join(`
`)}function sh(t){return`
    ${on(t)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      overflow-y: hidden !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }`}function rh(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block) {
        const div = document.createElement("div");
        div.className = "slide-block";
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);

        if (md.startsWith("### ")) div.innerHTML = "<h3>" + md.slice(4) + "</h3>";
        else if (md.startsWith("## ")) div.innerHTML = "<h2>" + md.slice(3) + "</h2>";
        else if (md.startsWith("# ")) div.innerHTML = "<h1>" + md.slice(2) + "</h1>";
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            let pL = [];
            const flushLeadP = (isF) => {
              if (pL.length > 0) {
                let txt = pL.join(" ").replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                lParts.push('<p class="' + (isF ? "slide-list-item-title" : "slide-list-item-desc") + '">' + txt + '</p>');
                pL = [];
              }
            };
            let isF = true;
            for (const l of leadLines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushLeadP(isF);
                const lvl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                isF = false;
              } else {
                pL.push(l);
              }
            }
            flushLeadP(isF);
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = it.text.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.join(" ").replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              div.innerHTML = "<p>" + html + "</p>";
            }
          }
        }
        return div;
      }

      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          for (const b of leftList) leftCol.appendChild(renderBlock(b));
          for (const b of rightList) rightCol.appendChild(renderBlock(b));
          container.appendChild(leftCol);
          container.appendChild(rightCol);
        } else if (slide.frontmatter?.layout === "two-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-two-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-two-cols-wrapper layout-two-cols-grid";
          const leftCol = document.createElement("div");
          leftCol.className = "pdf-col pdf-col--left";
          const rightCol = document.createElement("div");
          rightCol.className = "pdf-col pdf-col--right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          let leftList = [];
          let rightList = [];
          for (const b of rem) {
            if (b.slot === "right" || b.slot === "col-2") rightList.push(b);
            else leftList.push(b);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of leftList) leftCol.appendChild(renderBlock(b));
          for (const b of rightList) rightCol.appendChild(renderBlock(b));
          gridDiv.appendChild(leftCol);
          gridDiv.appendChild(rightCol);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "three-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-three-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-three-cols-wrapper layout-three-cols-grid";
          const col1 = document.createElement("div");
          col1.className = "pdf-col pdf-col--1";
          const col2 = document.createElement("div");
          col2.className = "pdf-col pdf-col--2";
          const col3 = document.createElement("div");
          col3.className = "pdf-col pdf-col--3";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          let c1 = [], c2 = [], c3 = [];
          const hasExplicitCols = rem.some(b => b.slot === "col-1" || b.slot === "col-2" || b.slot === "col-3" || b.slot === "center" || b.slot === "left" || b.slot === "right");
          if (hasExplicitCols) {
            c2 = rem.filter(b => b.slot === "col-2" || b.slot === "center");
            c3 = rem.filter(b => b.slot === "col-3" || b.slot === "right");
            c1 = rem.filter(b => !c2.includes(b) && !c3.includes(b));
          } else if (rem.length >= 3) {
            const count1 = Math.ceil(rem.length / 3);
            const count2 = Math.ceil((rem.length - count1) / 2);
            c1 = rem.slice(0, count1);
            c2 = rem.slice(count1, count1 + count2);
            c3 = rem.slice(count1 + count2);
          } else if (rem.length === 2) {
            c1 = [rem[0]];
            c2 = [rem[1]];
            c3 = [];
          } else if (rem.length === 1) {
            const lines = (rem[0].rawMarkdown || rem[0].content || "").trim().split(/\r?
/);
            const itemStartIndices = [];
            for (let i = 0; i < lines.length; i++) {
              if (/^[ 	]*[-*+]s+|^[ 	]*d+.s+/.test(lines[i])) itemStartIndices.push(i);
            }
            if (itemStartIndices.length >= 3) {
              const count1 = Math.ceil(itemStartIndices.length / 3);
              const count2 = Math.ceil((itemStartIndices.length - count1) / 2);
              const items1 = lines.slice(itemStartIndices[0], itemStartIndices[count1]).join("
");
              const items2 = lines.slice(itemStartIndices[count1], itemStartIndices[count1 + count2]).join("
");
              const items3 = lines.slice(itemStartIndices[count1 + count2]).join("
");
              c1 = [{ ...rem[0], rawMarkdown: items1, content: items1 }];
              c2 = [{ ...rem[0], id: rem[0].id + "-col2", rawMarkdown: items2, content: items2 }];
              c3 = [{ ...rem[0], id: rem[0].id + "-col3", rawMarkdown: items3, content: items3 }];
            } else {
              c1 = rem;
            }
          } else {
            c1 = rem;
          }
          c1 = cleanColList(c1);
          c2 = cleanColList(c2);
          c3 = cleanColList(c3);
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of c1) col1.appendChild(renderBlock(b));
          for (const b of c2) col2.appendChild(renderBlock(b));
          for (const b of c3) col3.appendChild(renderBlock(b));
          gridDiv.appendChild(col1);
          gridDiv.appendChild(col2);
          gridDiv.appendChild(col3);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of (slide.blocks || [])) {
            contentCol.appendChild(renderBlock(block));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          if (isImageRight) {
            container.appendChild(contentCol);
            container.appendChild(imgCol);
          } else {
            container.appendChild(imgCol);
            container.appendChild(contentCol);
          }
        } else {
          for (const block of (slide.blocks || [])) {
            container.appendChild(renderBlock(block));
          }
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => renderSlide(currentIndex - 1));
      btnNext.addEventListener("click", () => renderSlide(currentIndex + 1));
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        if (e.key === "ArrowRight" || e.key === " ") renderSlide(currentIndex + 1);
        if (e.key === "ArrowLeft") renderSlide(currentIndex - 1);
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          renderSlide(currentIndex - 1);
        } else {
          renderSlide(currentIndex + 1);
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function Wl(t,i){const e="Slidev 演示文稿";let n=t.slides;const o=JSON.stringify(n),r=JSON.stringify(t.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${Qt(e)}</title>
  <style>
${sh(i==null?void 0:i.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(t.docId)},
      slides: ${o},
      config: ${r}
    };
  <\/script>
</head>
<body>
  <div id="app">
    <div class="slide-viewport slidev-theme-${t.config.theme||"default"}" id="viewport" data-slidev-theme="${t.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">⛶ 全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${rh()}
  <\/script>
</body>
</html>`}function Vl(t,i){if(typeof document>"u")return!1;const e=new Blob([i],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(e),o=document.createElement("a");return o.href=n,o.download=t.endsWith(".html")?t:`${t}.html`,document.body.appendChild(o),o.click(),document.body.removeChild(o),URL.revokeObjectURL(n),!0}function lh(t){switch(t){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function ah(t,i){const e="Slidev 演示讲义",n="16:9",o="light",r=lh(n),l=t.slides.map((s,a)=>{const c=s.frontmatter.layout||"default",d=s.frontmatter.spacing,p=d&&d!=="inherit"?d:t.config.spacing||"normal",g=oh(s),u=`${a+1} / ${t.slides.length}`;return`
      <section class="pdf-slide-page layout-${c} theme-${o} spacing-${p}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${Qt(e)}</span>
          ${`<span class="pdf-page-badge">P. ${u}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${g}
        </div>
        ${s.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${Qt(s.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${Qt(e)} - 高保真讲义</title>
  <style>
    ${on(i==null?void 0:i.customInlineStyles)}

    @page {
      ${r}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
    }
  </style>
</head>
<body>
  ${l}
</body>
</html>`}function Kl(t,i){var o;if(typeof window>"u"||typeof document>"u")return!1;const e=ah(t,i);try{const r=document.createElement("iframe");r.style.position="fixed",r.style.right="0",r.style.bottom="0",r.style.width="0",r.style.height="0",r.style.border="none",r.style.visibility="hidden",document.body.appendChild(r);const l=(o=r.contentWindow)==null?void 0:o.document;if(l)return l.open(),l.write(e),l.close(),setTimeout(()=>{var s,a;try{(s=r.contentWindow)==null||s.focus(),(a=r.contentWindow)==null||a.print()}finally{setTimeout(()=>{r.remove()},2e3)}},350),!0}catch(r){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",r)}const n=window.open("","_blank");return n?(n.document.write(e),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const ch={class:"spm-slidev-preview-tab"},dh={class:"spm-slidev-tab__toolbar"},uh={class:"spm-slidev-tab__actions"},fh=["disabled"],ph={class:"spm-page-badge"},hh=["disabled"],mh=["aria-label"],gh=["aria-label"],vh=["src"],bh=he({__name:"SlidevPreviewTab",setup(t,{expose:i}){const e=Ge("plugin"),n=Ge("sandboxBridge",new _s),o=new Zp(n),r=new Cu,l=ht("web-sandbox"),s=ht(3030),a=ht(null),c=ht(!1),d=ht(null),p=ht(1),g=ht(1),u=ht([]),w=ht(!1),h=ht(!1),k=ht(!1),b=ht("siyuan"),y=ht(""),S=ht(""),T=ht(""),x=ht(!1),_=ht(!1),C=ht(""),D=ht("/plugins/siyuan-slidev/slidev-client/index.html");let M=null,z=null,J=null,E=null,A=null,v=null,P=null;Sn(()=>{d.value&&(n.attach(d.value),r.nativeBridge.attach(d.value)),M=n.onSlideChanged((Z,ot)=>{p.value=Z,g.value=ot}),z=n.onBlockClicked((Z,ot)=>{p.value=ot,o.setActiveBlockId(Z),e&&typeof e.handleBlockClickedFromSlide=="function"?e.handleBlockClickedFromSlide(Z,ot):Si(Z,e==null?void 0:e.app)}),J=n.onOpenInEditor((Z,ot)=>{p.value=ot,o.setActiveBlockId(Z),Si(Z,e==null?void 0:e.app)}),E=r.nativeBridge.onPageChanged((Z,ot)=>{p.value=Z,g.value=ot}),A=n.onOpenPeekDrawer(async Z=>{const ot=Cs();if(Z.peekType==="siyuan"&&ot.enableWebServeJump){let ct=!1;if(P&&P.docId===Z.target)ct=!0;else if(P&&P.slides&&P.slides.some(B=>{var N;return(N=B.blocks)==null?void 0:N.some(f=>f.id===Z.target)}))ct=!1;else try{const B=await dn(`SELECT id, root_id, type FROM blocks WHERE id = '${Z.target}' LIMIT 1`);B&&B.length>0&&(ct=B[0].type==="d"||B[0].id===B[0].root_id)}catch(B){console.warn("[SlidevPreviewTab] detect block type failed:",B)}b.value="web",x.value=!0,S.value=Fl(ot.webServeUrl,Z.target,{focus:!ct}),T.value=Z.title||`${ct?"思源文档":"思源块"}: ${Z.target.slice(0,8)}`,h.value=!0,n.freezeKeyboardNav(!0)}else b.value=Z.peekType,Z.peekType==="siyuan"?(y.value=Z.target,T.value=Z.title||`块速览: ${Z.target.slice(0,8)}`):(x.value=!0,S.value=Z.target,T.value=Z.title||Z.target),h.value=!0,n.freezeKeyboardNav(!0)}),v=n.onRequestToggleFullscreen(()=>{st()}),typeof document<"u"&&document.addEventListener("fullscreenchange",rt)}),gs(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",rt),A&&A(),v&&v(),M&&M(),z&&z(),J&&J(),E&&E(),n.detach(),o.destroy(),r.destroy()});async function G(){if(l.value==="web-sandbox"){if(!P){gt.showMessage("请先在主编辑区打开演示文档");return}gt.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const Z=await r.startProMode(P,Lo);if(!Z.success){gt.showMessage(`无法启动官方 Pro 模式：${Z.error}`);return}l.value="pro-cli",s.value=Z.port||3030,D.value=Z.url,d.value&&r.nativeBridge.attach(d.value),gt.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${s.value})`)}else r.stopProMode(),l.value="web-sandbox",D.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&n.attach(d.value),gt.showMessage("已切回内置高保真沙箱")}function F(){_.value=!_.value,_.value?C.value=(P==null?void 0:P.docId)||"":(C.value="",R())}function et(){p.value>1&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(p.value-1):n.navigatePage(p.value-1))}function H(){p.value<g.value&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(p.value+1):n.navigatePage(p.value+1))}function V(Z){p.value=Z,l.value==="pro-cli"?r.nativeBridge.navigateToPage(Z):n.navigatePage(Z)}function R(){e&&typeof e.compileCurrentDocument=="function"?e.compileCurrentDocument():e!=null&&e.eventBus&&typeof e.eventBus.emit=="function"&&e.eventBus.emit("slidev:request-compile")}function U(){h.value=!1,n.freezeKeyboardNav(!1)}function at(){U()}function rt(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function st(){const Z=a.value||d.value;Z&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):Z.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function X(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function pt(){if(!P){gt.showMessage("请先在主编辑区打开幻灯片文档");return}const Z=Wl(P);Vl("presentation.html",Z)&&gt.showMessage("已开始下载单文件离线 HTML 演示包")}function mt(){if(!P){gt.showMessage("请先在主编辑区打开幻灯片文档");return}Kl(P)&&gt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({updateDocument(Z,ot){_.value&&C.value&&ot&&ot!==C.value||(P=Z,_.value&&!C.value&&(C.value=Z.docId),u.value=Z.slides,g.value=Z.slides.length,o.setDocId(Z.docId),o.updateSlidesIndex(Z.slides),l.value==="pro-cli"?r.scaffolder.scaffold(Z,Lo).catch(()=>{}):n.updateSlides(Z.slides,Z.config,Z.fullMarkdown,Z.customThemeCss))},navigateToBlock(Z){o.onCursorFocusBlock(Z)},isPinned:_,pinnedDocId:C,engineMode:l,toggleEngineMode:G}),(Z,ot)=>(tt(),nt("div",ch,[m("div",dh,[ot[4]||(ot[4]=m("div",{class:"spm-slidev-tab__title"},[m("svg",{class:"spm-slidev-tab__icon","aria-hidden":"true"},[m("use",{"xlink:href":"#iconSlidev"})]),m("span",null,"Slidev 演示预览")],-1)),m("div",uh,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value<=1,"aria-label":"上一页",onClick:et},[ft(bt,{name:"chevron-left"})],8,fh),m("span",ph,xt(p.value)+" / "+xt(g.value||1),1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value>=g.value,"aria-label":"下一页",onClick:H},[ft(bt,{name:"chevron-right"})],8,hh),m("button",{class:Ct(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":_.value}]),"aria-label":_.value?"已锁定当前文档（点击解除）："+C.value:"点击锁定当前文档（不随主编辑区切换）",onClick:F},[ft(bt,{name:"pin"}),m("span",null,xt(_.value?"已锁定":"跟随"),1)],10,mh),m("button",{class:Ct(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+s.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:G},[ft(bt,{name:"step"}),m("span",null,xt(l.value==="pro-cli"?"Pro ("+s.value+")":"沙箱"),1)],10,gh),ot[3]||(ot[3]=m("span",{class:"spm-toolbar-divider"},null,-1)),m("button",{class:Ct(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":w.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:ot[0]||(ot[0]=ct=>w.value=!w.value)},[ft(bt,{name:"outline"})],2),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:X},[ft(bt,{name:"presenter"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:pt},[ft(bt,{name:"export-html"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:mt},[ft(bt,{name:"export-pdf"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:R},[ft(bt,{name:"refresh"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:st},[ft(bt,{name:"fullscreen"})])])]),m("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container"},[m("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:D.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,vh),ft(vp,{visible:h.value,"onUpdate:visible":ot[1]||(ot[1]=ct=>h.value=ct),"is-maximized":k.value,"onUpdate:isMaximized":ot[2]||(ot[2]=ct=>k.value=ct),title:T.value,onClose:U},{default:nl(()=>[b.value==="siyuan"&&y.value?(tt(),$e(Ap,{key:0,"block-id":y.value,title:T.value,plugin:Tt(e),onExternalJump:at},null,8,["block-id","title","plugin"])):Ot("",!0),x.value?_e((tt(),$e(qp,{key:1,visible:h.value&&b.value==="web",url:S.value,title:T.value,onExternalJump:at},null,8,["visible","url","title"])),[[Dl,b.value==="web"]]):Ot("",!0)]),_:1},8,["visible","is-maximized","title"])],512),w.value&&u.value.length>0?(tt(),$e(ap,{key:0,slides:u.value,"current-active-page":p.value,onNavigate:V,onRefresh:R},null,8,["slides","current-active-page"])):Ot("",!0)]))}}),yh=Be(bh,[["__scopeId","data-v-2622f6d8"]]),kh={class:"spm-section spm-section--page"},wh={class:"spm-section-header"},xh={class:"spm-card-control"},_h={class:"spm-control-header"},Sh={class:"spm-control-title-group"},Ch={class:"spm-control-title"},$h={class:"spm-segmented-group"},Ih={class:"spm-card-control"},Ah={class:"spm-control-header"},Th={class:"spm-control-title-group"},Eh={class:"spm-control-title"},Bh={class:"spm-quick-chips"},Mh=["onClick"],Dh=["value"],Lh={key:0,class:"spm-card-control"},Oh={class:"spm-control-header"},Ph={class:"spm-control-title-group"},Rh={class:"spm-control-title"},zh={class:"spm-quick-chips"},Nh=["onClick"],Fh=["value"],jh={class:"spm-card-control"},Hh={class:"spm-control-header"},Uh={class:"spm-control-title-group"},Wh={class:"spm-control-title"},Vh={key:0,class:"spm-note-status-box"},Kh=["title"],qh={class:"spm-action-grid",style:{"margin-top":"6px"}},Gh={key:1,class:"spm-note-empty-box"},Zh={class:"spm-card-control"},Yh={class:"spm-action-grid"},Jh=he({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","addNoteBlock","locateNoteBlock","generateNotes","insertDividerAfter","deleteDivider"],setup(t,{emit:i}){const e=t,n=_t(()=>{if(!e.pageNotes)return"";const l=e.pageNotes.replace(/[\r\n]+/g," ").trim();return l.length>50?l.slice(0,50)+"...":l}),o=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],r=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(l,s)=>(tt(),nt("div",kh,[m("div",wh,[m("span",null,"幻灯片页面设置"+xt(t.pageIndex?` (第 ${t.pageIndex} 页)`:""),1)]),ft(Nl,{"model-value":t.pageLayout,onChange:s[0]||(s[0]=a=>l.$emit("update:pageLayout",a))},null,8,["model-value"]),ft(Ss,{"model-value":t.pageTransition,onChange:s[1]||(s[1]=a=>l.$emit("update:pageTransition",a))},null,8,["model-value"]),m("div",xh,[m("div",_h,[m("div",Sh,[m("div",Ch,[ft(bt,{name:"ratio"}),s[16]||(s[16]=m("span",null,"页面间距 (Spacing)",-1))]),s[17]||(s[17]=m("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),m("div",$h,[m("button",{class:Ct(["spm-segmented-item",{active:!t.pageSpacing||t.pageSpacing==="inherit"}]),onClick:s[2]||(s[2]=a=>l.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),m("button",{class:Ct(["spm-segmented-item",{active:t.pageSpacing==="compact"}]),onClick:s[3]||(s[3]=a=>l.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),m("button",{class:Ct(["spm-segmented-item",{active:t.pageSpacing==="normal"}]),onClick:s[4]||(s[4]=a=>l.$emit("update:pageSpacing","normal"))}," 标准 ",2),m("button",{class:Ct(["spm-segmented-item",{active:t.pageSpacing==="loose"}]),onClick:s[5]||(s[5]=a=>l.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),m("div",Ih,[m("div",Ah,[m("div",Th,[m("div",Eh,[ft(bt,{name:"palette"}),s[18]||(s[18]=m("span",null,"页面背景 (Background)",-1))]),s[19]||(s[19]=m("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),m("div",Bh,[(tt(),nt(Ut,null,ge(o,a=>m("button",{key:a.value,class:Ct(["spm-chip",{active:t.pageBackground===a.value}]),onClick:c=>l.$emit("update:pageBackground",a.value)},xt(a.label),11,Mh)),64))]),m("input",{value:t.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:s[6]||(s[6]=a=>l.$emit("update:pageBackground",a.target.value)),onChange:s[7]||(s[7]=a=>l.$emit("update:pageBackground",a.target.value))},null,40,Dh)]),t.pageLayout==="image-right"||t.pageLayout==="image-left"||t.pageImage?(tt(),nt("div",Lh,[m("div",Oh,[m("div",Ph,[m("div",Rh,[ft(bt,{name:"image"}),s[20]||(s[20]=m("span",null,"页面图片 (Image)",-1))]),s[21]||(s[21]=m("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),m("div",zh,[(tt(),nt(Ut,null,ge(r,a=>m("button",{key:a.value,class:Ct(["spm-chip",{active:t.pageImage===a.value}]),onClick:c=>l.$emit("update:pageImage",a.value)},xt(a.label),11,Nh)),64))]),m("input",{value:t.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:s[8]||(s[8]=a=>l.$emit("update:pageImage",a.target.value)),onChange:s[9]||(s[9]=a=>l.$emit("update:pageImage",a.target.value))},null,40,Fh)])):Ot("",!0),m("div",jh,[m("div",Hh,[m("div",Uh,[m("div",Wh,[ft(bt,{name:"presenter"}),s[22]||(s[22]=m("span",null,"演讲者提词 (Notes)",-1))]),s[23]||(s[23]=m("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),m("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:s[10]||(s[10]=a=>l.$emit("generateNotes"))},[ft(bt,{name:"sparkles"}),s[24]||(s[24]=m("span",null,"AI 讲稿",-1))])]),t.pageNotes?(tt(),nt("div",Vh,[s[27]||(s[27]=m("div",{class:"spm-note-status-badge"},[m("span",{class:"spm-badge-dot"}),m("span",null,"已配置正文讲稿")],-1)),m("div",{class:"spm-note-preview-text",title:t.pageNotes},xt(n.value),9,Kh),m("div",qh,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:s[11]||(s[11]=a=>l.$emit("locateNoteBlock"))},[ft(bt,{name:"search"}),s[25]||(s[25]=m("span",null,"定位讲稿块",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:s[12]||(s[12]=a=>l.$emit("addNoteBlock"))},[ft(bt,{name:"insert-below"}),s[26]||(s[26]=m("span",null,"追加讲稿块",-1))])])])):(tt(),nt("div",Gh,[s[29]||(s[29]=m("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:s[13]||(s[13]=a=>l.$emit("addNoteBlock"))},[ft(bt,{name:"insert-below"}),s[28]||(s[28]=m("span",null,"添加讲稿备注块",-1))])]))]),m("div",Zh,[s[32]||(s[32]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),m("div",Yh,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:s[14]||(s[14]=a=>l.$emit("insertDividerAfter"))},[ft(bt,{name:"insert-below"}),s[30]||(s[30]=m("span",null,"插入新页",-1))]),m("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:s[15]||(s[15]=a=>l.$emit("deleteDivider"))},[ft(bt,{name:"trash"}),s[31]||(s[31]=m("span",null,"删除此页",-1))])])])]))}}),Xh=Be(Jh,[["__scopeId","data-v-4f1fa626"]]),Qh={class:"spm-section spm-section--block"},tm={class:"spm-card-control"},em={class:"spm-control-header"},im={class:"spm-control-title-group"},nm={class:"spm-control-title"},om=["aria-label"],sm=["checked"],rm={key:0,class:"spm-card-control"},lm={class:"spm-control-header"},am={class:"spm-control-title-group"},cm={class:"spm-control-title"},dm={class:"spm-quick-chips"},um={key:1,class:"spm-card-control"},fm={class:"spm-control-header"},pm={class:"spm-control-title-group"},hm={class:"spm-control-title"},mm={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},gm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},vm=["aria-label"],bm=["checked"],ym={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},km=["aria-label"],wm=["checked"],xm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},_m=["aria-label"],Sm=["checked"],Cm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},$m=["aria-label"],Im=["checked"],Am={class:"spm-card-control"},Tm={class:"spm-control-header"},Em={class:"spm-control-title-group"},Bm={class:"spm-control-title"},Mm=["aria-label"],Dm=["checked"],Lm={key:0,class:"spm-quick-chips"},Om=["onClick"],Pm={class:"spm-card-control"},Rm={class:"spm-control-header"},zm={class:"spm-control-title-group"},Nm={class:"spm-control-title"},Fm=["aria-label"],jm=["checked"],Hm={key:0,class:"spm-quick-chips"},Um=["onClick"],Wm={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},Vm={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},Km={style:{display:"flex",gap:"6px"}},qm=["value"],Gm=["value"],Zm={key:2,class:"spm-card-control"},Ym={class:"spm-control-header"},Jm={class:"spm-control-title-group"},Xm={class:"spm-control-title"},Qm={class:"spm-control-desc"},tg={class:"spm-segmented-group"},eg=["onClick"],ig={key:3,class:"spm-card-control"},ng={class:"spm-control-header"},og={class:"spm-control-title-group"},sg={class:"spm-control-title"},rg={class:"spm-quick-chips"},lg=["onClick"],ag=["value"],cg={key:4,class:"spm-card-control"},dg={class:"spm-control-header"},ug={class:"spm-control-title-group"},fg={class:"spm-control-title"},pg={class:"spm-quick-chips"},hg=["onClick"],mg=["value"],gg={class:"spm-card-control"},vg={class:"spm-action-grid"},bg=["aria-label"],yg=he({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(t,{emit:i}){const e=t,n=_t(()=>{const x=e.currentSlideLayout||"";return["col-1","col-2","col-3"].includes(e.elemSlot)?"three-cols-header":x}),o=_t(()=>{const x=n.value;return["two-cols","two-cols-header","three-cols-header"].includes(x)}),r=_t(()=>{const x=n.value;return x==="three-cols-header"?"三栏插槽归属 (Slot)":x==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),l=_t(()=>{const x=n.value;return x==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":x==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":x==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),s=_t(()=>{const x=n.value;return x==="three-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}]:x==="two-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]:x==="two-cols"?[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}]:[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]});function a(x){const _=e.elemSlot||"";return x?_===x||x==="col-1"&&_==="left"||x==="col-2"&&_==="center"||x==="col-3"&&_==="right"||x==="left"&&_==="col-1"||x==="right"&&(_==="col-2"||_==="col-3"):!_||_==="default"}const c=i,d=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],p=_t(()=>{if(!e.elemMotion||e.elemMotion.trim()===""||e.elemMotion.trim()==="none")return null;try{const x=JSON.parse(e.elemMotion);if(typeof x=="object"&&x!==null)return{preset:x.preset||x.type||"slide-up",duration:typeof x.duration=="number"?x.duration:0,delay:typeof x.delay=="number"?x.delay:0}}catch{}return{preset:e.elemMotion.trim(),duration:0,delay:0}}),g=_t(()=>!!p.value),u=_t(()=>{var x;return((x=p.value)==null?void 0:x.preset)||"slide-up"}),w=_t(()=>{var x;return((x=p.value)==null?void 0:x.duration)||0}),h=_t(()=>{var x;return((x=p.value)==null?void 0:x.delay)||0});function k(){g.value?c("update:elemMotion",""):c("update:elemMotion","slide-up")}function b(x){T(x,w.value,h.value)}function y(x){T(u.value,x,h.value)}function S(x){T(u.value,w.value,x)}function T(x,_,C){if(!x||x==="none"){c("update:elemMotion","");return}if(!_&&!C){c("update:elemMotion",x);return}const D={preset:x};_>0&&(D.duration=_),C>0&&(D.delay=C),c("update:elemMotion",JSON.stringify(D))}return(x,_)=>(tt(),nt("div",Qh,[_[53]||(_[53]=m("div",{class:"spm-section-header"},[m("span",null,"元素动效与排版")],-1)),m("div",tm,[m("div",em,[m("div",im,[m("div",nm,[ft(bt,{name:"presenter"}),_[22]||(_[22]=m("span",null,"设为讲稿备注 (slidev-note)",-1))]),_[23]||(_[23]=m("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.isNote?"取消讲稿备注":"设为讲稿备注"},[m("input",{type:"checkbox",checked:!!t.isNote,onChange:_[0]||(_[0]=C=>x.$emit("toggleNote"))},null,40,sm),_[24]||(_[24]=m("span",{class:"spm-switch-slider"},null,-1))],8,om)])]),t.isImage||t.imageRole?(tt(),nt("div",rm,[m("div",lm,[m("div",am,[m("div",cm,[ft(bt,{name:"image"}),_[25]||(_[25]=m("span",null,"图片角色与分栏 (Image & Layout)",-1))]),_[26]||(_[26]=m("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),m("div",dm,[m("button",{class:Ct(["spm-chip",{active:!t.imageRole}]),onClick:_[1]||(_[1]=C=>x.$emit("update:imageRole",""))}," 普通内容 ",2),m("button",{class:Ct(["spm-chip",{active:t.imageRole==="background"}]),onClick:_[2]||(_[2]=C=>x.$emit("update:imageRole","background"))}," 🖼️ 背景图 ",2),m("button",{class:Ct(["spm-chip",{active:t.imageRole==="image-left"}]),onClick:_[3]||(_[3]=C=>x.$emit("update:imageRole","image-left"))}," 🎨 图左 ",2),m("button",{class:Ct(["spm-chip",{active:t.imageRole==="image-right"}]),onClick:_[4]||(_[4]=C=>x.$emit("update:imageRole","image-right"))}," 🖼️ 图右 ",2)])])):Ot("",!0),t.isVideo?(tt(),nt("div",um,[m("div",fm,[m("div",pm,[m("div",hm,[ft(bt,{name:"video"}),_[27]||(_[27]=m("span",null,"视频播放设置 (Video Playback)",-1))]),_[28]||(_[28]=m("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),m("div",mm,[m("div",gm,[_[30]||(_[30]=m("span",{style:{"font-size":"11px"}},"🎛️ 控制条",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoControls?"关闭控制条":"开启控制条"},[m("input",{type:"checkbox",checked:!!t.videoControls,onChange:_[5]||(_[5]=C=>x.$emit("toggleVideoControls"))},null,40,bm),_[29]||(_[29]=m("span",{class:"spm-switch-slider"},null,-1))],8,vm)]),m("div",ym,[_[32]||(_[32]=m("span",{style:{"font-size":"11px"}},"▶️ 自动播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoAutoplay?"关闭自动播放":"开启自动播放"},[m("input",{type:"checkbox",checked:!!t.videoAutoplay,onChange:_[6]||(_[6]=C=>x.$emit("toggleVideoAutoplay"))},null,40,wm),_[31]||(_[31]=m("span",{class:"spm-switch-slider"},null,-1))],8,km)]),m("div",xm,[_[34]||(_[34]=m("span",{style:{"font-size":"11px"}},"🔁 循环播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoLoop?"关闭循环播放":"开启循环播放"},[m("input",{type:"checkbox",checked:!!t.videoLoop,onChange:_[7]||(_[7]=C=>x.$emit("toggleVideoLoop"))},null,40,Sm),_[33]||(_[33]=m("span",{class:"spm-switch-slider"},null,-1))],8,_m)]),m("div",Cm,[_[36]||(_[36]=m("span",{style:{"font-size":"11px"}},"🔇 静音播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoMuted?"关闭静音":"开启静音"},[m("input",{type:"checkbox",checked:!!t.videoMuted,onChange:_[8]||(_[8]=C=>x.$emit("toggleVideoMuted"))},null,40,Im),_[35]||(_[35]=m("span",{class:"spm-switch-slider"},null,-1))],8,$m)])])])):Ot("",!0),m("div",Am,[m("div",Tm,[m("div",Em,[m("div",Bm,[ft(bt,{name:"step"}),_[37]||(_[37]=m("span",null,"逐步呈现 (v-click)",-1))]),_[38]||(_[38]=m("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[m("input",{type:"checkbox",checked:!!t.elemClick,onChange:_[9]||(_[9]=C=>x.$emit("toggleElemClick"))},null,40,Dm),_[39]||(_[39]=m("span",{class:"spm-switch-slider"},null,-1))],8,Mm)]),t.elemClick?(tt(),nt("div",Lm,[(tt(),nt(Ut,null,ge(["+1","1","2","hide"],C=>m("button",{key:C,class:Ct(["spm-chip",{active:t.elemClick===C}]),onClick:D=>x.$emit("update:elemClick",C)},xt(C==="+1"?"顺延 (+1)":C==="hide"?"隐藏 (hide)":"第 "+C+" 步"),11,Om)),64))])):Ot("",!0)]),m("div",Pm,[m("div",Rm,[m("div",zm,[m("div",Nm,[ft(bt,{name:"motion"}),_[40]||(_[40]=m("span",null,"入场微动效 (v-motion)",-1))]),_[41]||(_[41]=m("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":g.value?"关闭微动效":"开启微动效 (slide-up)"},[m("input",{type:"checkbox",checked:g.value,onChange:k},null,40,jm),_[42]||(_[42]=m("span",{class:"spm-switch-slider"},null,-1))],8,Fm)]),g.value?(tt(),nt("div",Hm,[(tt(),nt(Ut,null,ge(d,C=>m("button",{key:C.value,class:Ct(["spm-chip",{active:u.value===C.value}]),onClick:D=>b(C.value)},xt(C.label),11,Um)),64))])):Ot("",!0),g.value?(tt(),nt("div",Wm,[m("div",Vm,[m("span",null,"时长: "+xt(w.value?w.value+"ms":"默认 (450ms)"),1),m("span",null,"延迟: "+xt(h.value?h.value+"ms":"0ms"),1)]),m("div",Km,[m("select",{class:"spm-select",style:{flex:"1"},value:w.value,onChange:_[10]||(_[10]=C=>y(Number(C.target.value)))},[..._[43]||(_[43]=[m("option",{value:0},"默认耗时",-1),m("option",{value:200},"极速 (200ms)",-1),m("option",{value:350},"较快 (350ms)",-1),m("option",{value:500},"平滑 (500ms)",-1),m("option",{value:800},"缓慢 (800ms)",-1)])],40,qm),m("select",{class:"spm-select",style:{flex:"1"},value:h.value,onChange:_[11]||(_[11]=C=>S(Number(C.target.value)))},[..._[44]||(_[44]=[m("option",{value:0},"无延迟",-1),m("option",{value:150},"延迟 150ms",-1),m("option",{value:300},"延迟 300ms",-1),m("option",{value:500},"延迟 500ms",-1)])],40,Gm)])])):Ot("",!0)]),o.value||t.elemSlot?(tt(),nt("div",Zm,[m("div",Ym,[m("div",Jm,[m("div",Xm,[ft(bt,{name:"columns"}),m("span",null,xt(r.value),1)]),m("span",Qm,xt(l.value),1)])]),m("div",tg,[(tt(!0),nt(Ut,null,ge(s.value,C=>(tt(),nt("button",{key:C.value,class:Ct(["spm-segmented-item",{active:a(C.value)}]),onClick:D=>x.$emit("update:elemSlot",C.value)},xt(C.label),11,eg))),128))])])):Ot("",!0),t.isCodeBlock?(tt(),nt("div",ig,[m("div",ng,[m("div",og,[m("div",sg,[ft(bt,{name:"code"}),_[45]||(_[45]=m("span",null,"代码逐行聚光 (Shiki)",-1))]),_[46]||(_[46]=m("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),m("div",rg,[(tt(),nt(Ut,null,ge(["1-3","all","1|2|3","2-5"],C=>m("button",{key:C,class:Ct(["spm-chip",{active:t.elemShikiLines===C}]),onClick:D=>x.$emit("update:elemShikiLines",C)},xt(C),11,lg)),64)),t.elemShikiLines?(tt(),nt("button",{key:0,class:"spm-chip spm-chip-clear",onClick:_[12]||(_[12]=C=>x.$emit("update:elemShikiLines",""))}," 清空 ")):Ot("",!0)]),m("input",{value:t.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:_[13]||(_[13]=C=>x.$emit("update:elemShikiLines",C.target.value)),onChange:_[14]||(_[14]=C=>x.$emit("update:elemShikiLines",C.target.value))},null,40,ag)])):Ot("",!0),t.isCodeBlock?(tt(),nt("div",cg,[m("div",dg,[m("div",ug,[m("div",fg,[ft(bt,{name:"code"}),_[47]||(_[47]=m("span",null,"代码块限高 (Max Height)",-1))]),_[48]||(_[48]=m("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),m("div",pg,[(tt(),nt(Ut,null,ge(["240px","320px","400px","50vh"],C=>m("button",{key:C,class:Ct(["spm-chip",{active:t.elemMaxHeight===C}]),onClick:D=>x.$emit("update:elemMaxHeight",C)},xt(C),11,hg)),64)),t.elemMaxHeight?(tt(),nt("button",{key:0,class:"spm-chip spm-chip-clear",onClick:_[15]||(_[15]=C=>x.$emit("update:elemMaxHeight",""))}," 自适应 ")):Ot("",!0)]),m("input",{value:t.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:_[16]||(_[16]=C=>x.$emit("update:elemMaxHeight",C.target.value)),onChange:_[17]||(_[17]=C=>x.$emit("update:elemMaxHeight",C.target.value))},null,40,mg)])):Ot("",!0),m("div",gg,[_[52]||(_[52]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"快捷操作")])],-1)),m("div",vg,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:_[18]||(_[18]=C=>x.$emit("insertDividerBefore"))},[ft(bt,{name:"insert-above"}),_[49]||(_[49]=m("span",null,"上方分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:_[19]||(_[19]=C=>x.$emit("insertDividerAfter"))},[ft(bt,{name:"insert-below"}),_[50]||(_[50]=m("span",null,"下方分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:_[20]||(_[20]=C=>x.$emit("setTwoColsContrast"))},[ft(bt,{name:"columns"}),m("span",null,xt(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,bg),t.hasBlockAttrs?(tt(),nt("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:_[21]||(_[21]=C=>x.$emit("clearBlockAttrs"))},[ft(bt,{name:"broom"}),_[51]||(_[51]=m("span",null,"清除属性",-1))])):Ot("",!0)])])]))}}),kg={class:"spm-section spm-section--doc"},wg={class:"spm-card-control"},xg={class:"spm-control-header"},_g={class:"spm-control-title-group"},Sg={class:"spm-control-title"},Cg={class:"spm-segmented-group"},$g=["aria-label","onClick"],Ig={class:"spm-card-control"},Ag={class:"spm-control-header"},Tg={class:"spm-control-title-group"},Eg={class:"spm-control-title"},Bg={class:"spm-segmented-group"},Mg={class:"spm-card-control"},Dg={class:"spm-control-header"},Lg={class:"spm-control-title-group"},Og={class:"spm-control-title"},Pg={class:"spm-segmented-group"},Rg={class:"spm-card-control"},zg={class:"spm-control-header"},Ng={class:"spm-control-title-group"},Fg={class:"spm-control-title"},jg={class:"spm-card-control"},Hg={class:"spm-control-header"},Ug={class:"spm-control-title-group"},Wg={class:"spm-control-title"},Vg=["aria-label"],Kg=["checked"],qg={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},Gg=["value"],Zg={class:"spm-card-control"},Yg={class:"spm-action-grid"},Jg=he({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(t){const i=Ge("plugin"),e=ki,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function o(s){Fi({enableWebServeJump:s}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({enableWebServeJump:s})}function r(s){Fi({webServeUrl:s})}function l(s){Fi({webServeUrl:s}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({webServeUrl:s})}return(s,a)=>(tt(),nt("div",kg,[a[35]||(a[35]=m("div",{class:"spm-section-header"},[m("span",null,"全局演示配置")],-1)),m("div",wg,[m("div",xg,[m("div",_g,[m("div",Sg,[ft(bt,{name:"palette"}),a[17]||(a[17]=m("span",null,"幻灯片主题 (Theme)",-1))]),a[18]||(a[18]=m("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),m("div",Cg,[(tt(),nt(Ut,null,ge(n,c=>m("button",{key:c.value,class:Ct(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:t.docTheme===c.value}]),"aria-label":c.desc,onClick:d=>s.$emit("update:docTheme",c.value)},xt(c.label),11,$g)),64))])]),m("div",Ig,[m("div",Ag,[m("div",Tg,[m("div",Eg,[ft(bt,{name:"ratio"}),a[19]||(a[19]=m("span",null,"画幅比例 (Aspect Ratio)",-1))]),a[20]||(a[20]=m("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),m("div",Bg,[m("button",{class:Ct(["spm-segmented-item",{active:t.docAspectRatio==="16/9"}]),onClick:a[0]||(a[0]=c=>s.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),m("button",{class:Ct(["spm-segmented-item",{active:t.docAspectRatio==="4/3"}]),onClick:a[1]||(a[1]=c=>s.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),m("button",{class:Ct(["spm-segmented-item",{active:t.docAspectRatio==="16/10"}]),onClick:a[2]||(a[2]=c=>s.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),m("div",Mg,[m("div",Dg,[m("div",Lg,[m("div",Og,[ft(bt,{name:"ratio"}),a[21]||(a[21]=m("span",null,"间距风格 (Spacing)",-1))]),a[22]||(a[22]=m("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),m("div",Pg,[m("button",{class:Ct(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:a[3]||(a[3]=c=>s.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),m("button",{class:Ct(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:a[4]||(a[4]=c=>s.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),m("button",{class:Ct(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:a[5]||(a[5]=c=>s.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),m("div",Rg,[m("div",zg,[m("div",Ng,[m("div",Fg,[ft(bt,{name:"transition"}),a[23]||(a[23]=m("span",null,"全局默认转场",-1))]),a[24]||(a[24]=m("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),ft(Ss,{"model-value":t.docDefaultTransition,"hide-header":!0,onChange:a[6]||(a[6]=c=>s.$emit("update:docDefaultTransition",c))},null,8,["model-value"])]),m("div",jg,[m("div",Hg,[m("div",Ug,[m("div",Wg,[ft(bt,{name:"external-link"}),a[25]||(a[25]=m("span",null,"本地网络伺服预览 (Web Serve)",-1))]),a[26]||(a[26]=m("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":Tt(e).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[m("input",{type:"checkbox",checked:Tt(e).enableWebServeJump,onChange:a[7]||(a[7]=c=>o(c.target.checked))},null,40,Kg),a[27]||(a[27]=m("span",{class:"spm-switch-slider"},null,-1))],8,Vg)]),Tt(e).enableWebServeJump?(tt(),nt("div",qg,[m("input",{value:Tt(e).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:a[8]||(a[8]=Ce(()=>{},["stop"])),onKeyup:a[9]||(a[9]=Ce(()=>{},["stop"])),onInput:a[10]||(a[10]=c=>r(c.target.value)),onChange:a[11]||(a[11]=c=>l(c.target.value))},null,40,Gg),a[28]||(a[28]=m("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Ot("",!0)]),m("div",Zg,[a[34]||(a[34]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"演示全局操作")])],-1)),m("div",Yg,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:a[12]||(a[12]=c=>s.$emit("openBottomPreview"))},[ft(bt,{name:"split-preview"}),a[29]||(a[29]=m("span",null,"分屏预览",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:a[13]||(a[13]=c=>s.$emit("openPresenter"))},[ft(bt,{name:"presenter"}),a[30]||(a[30]=m("span",null,"演讲者视图",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:a[14]||(a[14]=c=>s.$emit("aiAutoSplit"))},[ft(bt,{name:"sparkles"}),a[31]||(a[31]=m("span",null,"AI 智能分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:a[15]||(a[15]=c=>s.$emit("exportHtml"))},[ft(bt,{name:"export-html"}),a[32]||(a[32]=m("span",null,"导出 HTML",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:a[16]||(a[16]=c=>s.$emit("exportPdf"))},[ft(bt,{name:"export-pdf"}),a[33]||(a[33]=m("span",null,"导出 PDF",-1))])])])]))}});var Ln=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function Xg(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}function On(t){throw new Error('Could not dynamically require "'+t+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Mo={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var pr;function Qg(){return pr||(pr=1,(function(t,i){(function(e){t.exports=e()})(function(){return(function e(n,o,r){function l(c,d){if(!o[c]){if(!n[c]){var p=typeof On=="function"&&On;if(!d&&p)return p(c,!0);if(s)return s(c,!0);var g=new Error("Cannot find module '"+c+"'");throw g.code="MODULE_NOT_FOUND",g}var u=o[c]={exports:{}};n[c][0].call(u.exports,function(w){var h=n[c][1][w];return l(h||w)},u,u.exports,e,n,o,r)}return o[c].exports}for(var s=typeof On=="function"&&On,a=0;a<r.length;a++)l(r[a]);return l})({1:[function(e,n,o){var r=e("./utils"),l=e("./support"),s="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";o.encode=function(a){for(var c,d,p,g,u,w,h,k=[],b=0,y=a.length,S=y,T=r.getTypeOf(a)!=="string";b<a.length;)S=y-b,p=T?(c=a[b++],d=b<y?a[b++]:0,b<y?a[b++]:0):(c=a.charCodeAt(b++),d=b<y?a.charCodeAt(b++):0,b<y?a.charCodeAt(b++):0),g=c>>2,u=(3&c)<<4|d>>4,w=1<S?(15&d)<<2|p>>6:64,h=2<S?63&p:64,k.push(s.charAt(g)+s.charAt(u)+s.charAt(w)+s.charAt(h));return k.join("")},o.decode=function(a){var c,d,p,g,u,w,h=0,k=0,b="data:";if(a.substr(0,b.length)===b)throw new Error("Invalid base64 input, it looks like a data url.");var y,S=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===s.charAt(64)&&S--,a.charAt(a.length-2)===s.charAt(64)&&S--,S%1!=0)throw new Error("Invalid base64 input, bad content length.");for(y=l.uint8array?new Uint8Array(0|S):new Array(0|S);h<a.length;)c=s.indexOf(a.charAt(h++))<<2|(g=s.indexOf(a.charAt(h++)))>>4,d=(15&g)<<4|(u=s.indexOf(a.charAt(h++)))>>2,p=(3&u)<<6|(w=s.indexOf(a.charAt(h++))),y[k++]=c,u!==64&&(y[k++]=d),w!==64&&(y[k++]=p);return y}},{"./support":30,"./utils":32}],2:[function(e,n,o){var r=e("./external"),l=e("./stream/DataWorker"),s=e("./stream/Crc32Probe"),a=e("./stream/DataLengthProbe");function c(d,p,g,u,w){this.compressedSize=d,this.uncompressedSize=p,this.crc32=g,this.compression=u,this.compressedContent=w}c.prototype={getContentWorker:function(){var d=new l(r.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),p=this;return d.on("end",function(){if(this.streamInfo.data_length!==p.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(r.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,p,g){return d.pipe(new s).pipe(new a("uncompressedSize")).pipe(p.compressWorker(g)).pipe(new a("compressedSize")).withStreamInfo("compression",p)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(e,n,o){var r=e("./stream/GenericWorker");o.STORE={magic:"\0\0",compressWorker:function(){return new r("STORE compression")},uncompressWorker:function(){return new r("STORE decompression")}},o.DEFLATE=e("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(e,n,o){var r=e("./utils"),l=(function(){for(var s,a=[],c=0;c<256;c++){s=c;for(var d=0;d<8;d++)s=1&s?3988292384^s>>>1:s>>>1;a[c]=s}return a})();n.exports=function(s,a){return s!==void 0&&s.length?r.getTypeOf(s)!=="string"?(function(c,d,p,g){var u=l,w=g+p;c^=-1;for(var h=g;h<w;h++)c=c>>>8^u[255&(c^d[h])];return-1^c})(0|a,s,s.length,0):(function(c,d,p,g){var u=l,w=g+p;c^=-1;for(var h=g;h<w;h++)c=c>>>8^u[255&(c^d.charCodeAt(h))];return-1^c})(0|a,s,s.length,0):0}},{"./utils":32}],5:[function(e,n,o){o.base64=!1,o.binary=!1,o.dir=!1,o.createFolders=!0,o.date=null,o.compression=null,o.compressionOptions=null,o.comment=null,o.unixPermissions=null,o.dosPermissions=null},{}],6:[function(e,n,o){var r=null;r=typeof Promise<"u"?Promise:e("lie"),n.exports={Promise:r}},{lie:37}],7:[function(e,n,o){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=e("pako"),s=e("./utils"),a=e("./stream/GenericWorker"),c=r?"uint8array":"array";function d(p,g){a.call(this,"FlateWorker/"+p),this._pako=null,this._pakoAction=p,this._pakoOptions=g,this.meta={}}o.magic="\b\0",s.inherits(d,a),d.prototype.processChunk=function(p){this.meta=p.meta,this._pako===null&&this._createPako(),this._pako.push(s.transformTo(c,p.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var p=this;this._pako.onData=function(g){p.push({data:g,meta:p.meta})}},o.compressWorker=function(p){return new d("Deflate",p)},o.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(e,n,o){function r(u,w){var h,k="";for(h=0;h<w;h++)k+=String.fromCharCode(255&u),u>>>=8;return k}function l(u,w,h,k,b,y){var S,T,x=u.file,_=u.compression,C=y!==c.utf8encode,D=s.transformTo("string",y(x.name)),M=s.transformTo("string",c.utf8encode(x.name)),z=x.comment,J=s.transformTo("string",y(z)),E=s.transformTo("string",c.utf8encode(z)),A=M.length!==x.name.length,v=E.length!==z.length,P="",G="",F="",et=x.dir,H=x.date,V={crc32:0,compressedSize:0,uncompressedSize:0};w&&!h||(V.crc32=u.crc32,V.compressedSize=u.compressedSize,V.uncompressedSize=u.uncompressedSize);var R=0;w&&(R|=8),C||!A&&!v||(R|=2048);var U=0,at=0;et&&(U|=16),b==="UNIX"?(at=798,U|=(function(st,X){var pt=st;return st||(pt=X?16893:33204),(65535&pt)<<16})(x.unixPermissions,et)):(at=20,U|=(function(st){return 63&(st||0)})(x.dosPermissions)),S=H.getUTCHours(),S<<=6,S|=H.getUTCMinutes(),S<<=5,S|=H.getUTCSeconds()/2,T=H.getUTCFullYear()-1980,T<<=4,T|=H.getUTCMonth()+1,T<<=5,T|=H.getUTCDate(),A&&(G=r(1,1)+r(d(D),4)+M,P+="up"+r(G.length,2)+G),v&&(F=r(1,1)+r(d(J),4)+E,P+="uc"+r(F.length,2)+F);var rt="";return rt+=`
\0`,rt+=r(R,2),rt+=_.magic,rt+=r(S,2),rt+=r(T,2),rt+=r(V.crc32,4),rt+=r(V.compressedSize,4),rt+=r(V.uncompressedSize,4),rt+=r(D.length,2),rt+=r(P.length,2),{fileRecord:p.LOCAL_FILE_HEADER+rt+D+P,dirRecord:p.CENTRAL_FILE_HEADER+r(at,2)+rt+r(J.length,2)+"\0\0\0\0"+r(U,4)+r(k,4)+D+P+J}}var s=e("../utils"),a=e("../stream/GenericWorker"),c=e("../utf8"),d=e("../crc32"),p=e("../signature");function g(u,w,h,k){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=w,this.zipPlatform=h,this.encodeFileName=k,this.streamFiles=u,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}s.inherits(g,a),g.prototype.push=function(u){var w=u.meta.percent||0,h=this.entriesCount,k=this._sources.length;this.accumulate?this.contentBuffer.push(u):(this.bytesWritten+=u.data.length,a.prototype.push.call(this,{data:u.data,meta:{currentFile:this.currentFile,percent:h?(w+100*(h-k-1))/h:100}}))},g.prototype.openedSource=function(u){this.currentSourceOffset=this.bytesWritten,this.currentFile=u.file.name;var w=this.streamFiles&&!u.file.dir;if(w){var h=l(u,w,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:h.fileRecord,meta:{percent:0}})}else this.accumulate=!0},g.prototype.closedSource=function(u){this.accumulate=!1;var w=this.streamFiles&&!u.file.dir,h=l(u,w,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(h.dirRecord),w)this.push({data:(function(k){return p.DATA_DESCRIPTOR+r(k.crc32,4)+r(k.compressedSize,4)+r(k.uncompressedSize,4)})(u),meta:{percent:100}});else for(this.push({data:h.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},g.prototype.flush=function(){for(var u=this.bytesWritten,w=0;w<this.dirRecords.length;w++)this.push({data:this.dirRecords[w],meta:{percent:100}});var h=this.bytesWritten-u,k=(function(b,y,S,T,x){var _=s.transformTo("string",x(T));return p.CENTRAL_DIRECTORY_END+"\0\0\0\0"+r(b,2)+r(b,2)+r(y,4)+r(S,4)+r(_.length,2)+_})(this.dirRecords.length,h,u,this.zipComment,this.encodeFileName);this.push({data:k,meta:{percent:100}})},g.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},g.prototype.registerPrevious=function(u){this._sources.push(u);var w=this;return u.on("data",function(h){w.processChunk(h)}),u.on("end",function(){w.closedSource(w.previous.streamInfo),w._sources.length?w.prepareNextSource():w.end()}),u.on("error",function(h){w.error(h)}),this},g.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},g.prototype.error=function(u){var w=this._sources;if(!a.prototype.error.call(this,u))return!1;for(var h=0;h<w.length;h++)try{w[h].error(u)}catch{}return!0},g.prototype.lock=function(){a.prototype.lock.call(this);for(var u=this._sources,w=0;w<u.length;w++)u[w].lock()},n.exports=g},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(e,n,o){var r=e("../compressions"),l=e("./ZipFileWorker");o.generateWorker=function(s,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),p=0;try{s.forEach(function(g,u){p++;var w=(function(y,S){var T=y||S,x=r[T];if(!x)throw new Error(T+" is not a valid compression method !");return x})(u.options.compression,a.compression),h=u.options.compressionOptions||a.compressionOptions||{},k=u.dir,b=u.date;u._compressWorker(w,h).withStreamInfo("file",{name:g,dir:k,date:b,comment:u.comment||"",unixPermissions:u.unixPermissions,dosPermissions:u.dosPermissions}).pipe(d)}),d.entriesCount=p}catch(g){d.error(g)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(e,n,o){function r(){if(!(this instanceof r))return new r;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new r;for(var s in this)typeof this[s]!="function"&&(l[s]=this[s]);return l}}(r.prototype=e("./object")).loadAsync=e("./load"),r.support=e("./support"),r.defaults=e("./defaults"),r.version="3.10.1",r.loadAsync=function(l,s){return new r().loadAsync(l,s)},r.external=e("./external"),n.exports=r},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(e,n,o){var r=e("./utils"),l=e("./external"),s=e("./utf8"),a=e("./zipEntries"),c=e("./stream/Crc32Probe"),d=e("./nodejsUtils");function p(g){return new l.Promise(function(u,w){var h=g.decompressed.getContentWorker().pipe(new c);h.on("error",function(k){w(k)}).on("end",function(){h.streamInfo.crc32!==g.decompressed.crc32?w(new Error("Corrupted zip : CRC32 mismatch")):u()}).resume()})}n.exports=function(g,u){var w=this;return u=r.extend(u||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:s.utf8decode}),d.isNode&&d.isStream(g)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):r.prepareContent("the loaded zip file",g,!0,u.optimizedBinaryString,u.base64).then(function(h){var k=new a(u);return k.load(h),k}).then(function(h){var k=[l.Promise.resolve(h)],b=h.files;if(u.checkCRC32)for(var y=0;y<b.length;y++)k.push(p(b[y]));return l.Promise.all(k)}).then(function(h){for(var k=h.shift(),b=k.files,y=0;y<b.length;y++){var S=b[y],T=S.fileNameStr,x=r.resolve(S.fileNameStr);w.file(x,S.decompressed,{binary:!0,optimizedBinaryString:!0,date:S.date,dir:S.dir,comment:S.fileCommentStr.length?S.fileCommentStr:null,unixPermissions:S.unixPermissions,dosPermissions:S.dosPermissions,createFolders:u.createFolders}),S.dir||(w.file(x).unsafeOriginalName=T)}return k.zipComment.length&&(w.comment=k.zipComment),w})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(e,n,o){var r=e("../utils"),l=e("../stream/GenericWorker");function s(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}r.inherits(s,l),s.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},s.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},s.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=s},{"../stream/GenericWorker":28,"../utils":32}],13:[function(e,n,o){var r=e("readable-stream").Readable;function l(s,a,c){r.call(this,a),this._helper=s;var d=this;s.on("data",function(p,g){d.push(p)||d._helper.pause(),c&&c(g)}).on("error",function(p){d.emit("error",p)}).on("end",function(){d.push(null)})}e("../utils").inherits(l,r),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(e,n,o){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(r,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(r,l);if(typeof r=="number")throw new Error('The "data" argument must not be a number');return new Buffer(r,l)},allocBuffer:function(r){if(Buffer.alloc)return Buffer.alloc(r);var l=new Buffer(r);return l.fill(0),l},isBuffer:function(r){return Buffer.isBuffer(r)},isStream:function(r){return r&&typeof r.on=="function"&&typeof r.pause=="function"&&typeof r.resume=="function"}}},{}],15:[function(e,n,o){function r(x,_,C){var D,M=s.getTypeOf(_),z=s.extend(C||{},d);z.date=z.date||new Date,z.compression!==null&&(z.compression=z.compression.toUpperCase()),typeof z.unixPermissions=="string"&&(z.unixPermissions=parseInt(z.unixPermissions,8)),z.unixPermissions&&16384&z.unixPermissions&&(z.dir=!0),z.dosPermissions&&16&z.dosPermissions&&(z.dir=!0),z.dir&&(x=b(x)),z.createFolders&&(D=k(x))&&y.call(this,D,!0);var J=M==="string"&&z.binary===!1&&z.base64===!1;C&&C.binary!==void 0||(z.binary=!J),(_ instanceof p&&_.uncompressedSize===0||z.dir||!_||_.length===0)&&(z.base64=!1,z.binary=!0,_="",z.compression="STORE",M="string");var E=null;E=_ instanceof p||_ instanceof a?_:w.isNode&&w.isStream(_)?new h(x,_):s.prepareContent(x,_,z.binary,z.optimizedBinaryString,z.base64);var A=new g(x,E,z);this.files[x]=A}var l=e("./utf8"),s=e("./utils"),a=e("./stream/GenericWorker"),c=e("./stream/StreamHelper"),d=e("./defaults"),p=e("./compressedObject"),g=e("./zipObject"),u=e("./generate"),w=e("./nodejsUtils"),h=e("./nodejs/NodejsStreamInputAdapter"),k=function(x){x.slice(-1)==="/"&&(x=x.substring(0,x.length-1));var _=x.lastIndexOf("/");return 0<_?x.substring(0,_):""},b=function(x){return x.slice(-1)!=="/"&&(x+="/"),x},y=function(x,_){return _=_!==void 0?_:d.createFolders,x=b(x),this.files[x]||r.call(this,x,null,{dir:!0,createFolders:_}),this.files[x]};function S(x){return Object.prototype.toString.call(x)==="[object RegExp]"}var T={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(x){var _,C,D;for(_ in this.files)D=this.files[_],(C=_.slice(this.root.length,_.length))&&_.slice(0,this.root.length)===this.root&&x(C,D)},filter:function(x){var _=[];return this.forEach(function(C,D){x(C,D)&&_.push(D)}),_},file:function(x,_,C){if(arguments.length!==1)return x=this.root+x,r.call(this,x,_,C),this;if(S(x)){var D=x;return this.filter(function(z,J){return!J.dir&&D.test(z)})}var M=this.files[this.root+x];return M&&!M.dir?M:null},folder:function(x){if(!x)return this;if(S(x))return this.filter(function(M,z){return z.dir&&x.test(M)});var _=this.root+x,C=y.call(this,_),D=this.clone();return D.root=C.name,D},remove:function(x){x=this.root+x;var _=this.files[x];if(_||(x.slice(-1)!=="/"&&(x+="/"),_=this.files[x]),_&&!_.dir)delete this.files[x];else for(var C=this.filter(function(M,z){return z.name.slice(0,x.length)===x}),D=0;D<C.length;D++)delete this.files[C[D].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(x){var _,C={};try{if((C=s.extend(x||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=C.type.toLowerCase(),C.compression=C.compression.toUpperCase(),C.type==="binarystring"&&(C.type="string"),!C.type)throw new Error("No output type specified.");s.checkSupport(C.type),C.platform!=="darwin"&&C.platform!=="freebsd"&&C.platform!=="linux"&&C.platform!=="sunos"||(C.platform="UNIX"),C.platform==="win32"&&(C.platform="DOS");var D=C.comment||this.comment||"";_=u.generateWorker(this,C,D)}catch(M){(_=new a("error")).error(M)}return new c(_,C.type||"string",C.mimeType)},generateAsync:function(x,_){return this.generateInternalStream(x).accumulate(_)},generateNodeStream:function(x,_){return(x=x||{}).type||(x.type="nodebuffer"),this.generateInternalStream(x).toNodejsStream(_)}};n.exports=T},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(e,n,o){n.exports=e("stream")},{stream:void 0}],17:[function(e,n,o){var r=e("./DataReader");function l(s){r.call(this,s);for(var a=0;a<this.data.length;a++)s[a]=255&s[a]}e("../utils").inherits(l,r),l.prototype.byteAt=function(s){return this.data[this.zero+s]},l.prototype.lastIndexOfSignature=function(s){for(var a=s.charCodeAt(0),c=s.charCodeAt(1),d=s.charCodeAt(2),p=s.charCodeAt(3),g=this.length-4;0<=g;--g)if(this.data[g]===a&&this.data[g+1]===c&&this.data[g+2]===d&&this.data[g+3]===p)return g-this.zero;return-1},l.prototype.readAndCheckSignature=function(s){var a=s.charCodeAt(0),c=s.charCodeAt(1),d=s.charCodeAt(2),p=s.charCodeAt(3),g=this.readData(4);return a===g[0]&&c===g[1]&&d===g[2]&&p===g[3]},l.prototype.readData=function(s){if(this.checkOffset(s),s===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+s);return this.index+=s,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(e,n,o){var r=e("../utils");function l(s){this.data=s,this.length=s.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(s){this.checkIndex(this.index+s)},checkIndex:function(s){if(this.length<this.zero+s||s<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+s+"). Corrupted zip ?")},setIndex:function(s){this.checkIndex(s),this.index=s},skip:function(s){this.setIndex(this.index+s)},byteAt:function(){},readInt:function(s){var a,c=0;for(this.checkOffset(s),a=this.index+s-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=s,c},readString:function(s){return r.transformTo("string",this.readData(s))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var s=this.readInt(4);return new Date(Date.UTC(1980+(s>>25&127),(s>>21&15)-1,s>>16&31,s>>11&31,s>>5&63,(31&s)<<1))}},n.exports=l},{"../utils":32}],19:[function(e,n,o){var r=e("./Uint8ArrayReader");function l(s){r.call(this,s)}e("../utils").inherits(l,r),l.prototype.readData=function(s){this.checkOffset(s);var a=this.data.slice(this.zero+this.index,this.zero+this.index+s);return this.index+=s,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(e,n,o){var r=e("./DataReader");function l(s){r.call(this,s)}e("../utils").inherits(l,r),l.prototype.byteAt=function(s){return this.data.charCodeAt(this.zero+s)},l.prototype.lastIndexOfSignature=function(s){return this.data.lastIndexOf(s)-this.zero},l.prototype.readAndCheckSignature=function(s){return s===this.readData(4)},l.prototype.readData=function(s){this.checkOffset(s);var a=this.data.slice(this.zero+this.index,this.zero+this.index+s);return this.index+=s,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(e,n,o){var r=e("./ArrayReader");function l(s){r.call(this,s)}e("../utils").inherits(l,r),l.prototype.readData=function(s){if(this.checkOffset(s),s===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+s);return this.index+=s,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(e,n,o){var r=e("../utils"),l=e("../support"),s=e("./ArrayReader"),a=e("./StringReader"),c=e("./NodeBufferReader"),d=e("./Uint8ArrayReader");n.exports=function(p){var g=r.getTypeOf(p);return r.checkSupport(g),g!=="string"||l.uint8array?g==="nodebuffer"?new c(p):l.uint8array?new d(r.transformTo("uint8array",p)):new s(r.transformTo("array",p)):new a(p)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(e,n,o){o.LOCAL_FILE_HEADER="PK",o.CENTRAL_FILE_HEADER="PK",o.CENTRAL_DIRECTORY_END="PK",o.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",o.ZIP64_CENTRAL_DIRECTORY_END="PK",o.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(e,n,o){var r=e("./GenericWorker"),l=e("../utils");function s(a){r.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(s,r),s.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=s},{"../utils":32,"./GenericWorker":28}],25:[function(e,n,o){var r=e("./GenericWorker"),l=e("../crc32");function s(){r.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}e("../utils").inherits(s,r),s.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=s},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(e,n,o){var r=e("../utils"),l=e("./GenericWorker");function s(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}r.inherits(s,l),s.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=s},{"../utils":32,"./GenericWorker":28}],27:[function(e,n,o){var r=e("../utils"),l=e("./GenericWorker");function s(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=r.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}r.inherits(s,l),s.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},s.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,r.delay(this._tickAndRepeat,[],this)),!0)},s.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(r.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},s.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=s},{"../utils":32,"./GenericWorker":28}],28:[function(e,n,o){function r(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}r.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,s){return this._listeners[l].push(s),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,s){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,s)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var s=this;return l.on("data",function(a){s.processChunk(a)}),l.on("end",function(){s.end()}),l.on("error",function(a){s.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,s){return this.extraStreamInfo[l]=s,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=r},{}],29:[function(e,n,o){var r=e("../utils"),l=e("./ConvertWorker"),s=e("./GenericWorker"),a=e("../base64"),c=e("../support"),d=e("../external"),p=null;if(c.nodestream)try{p=e("../nodejs/NodejsStreamOutputAdapter")}catch{}function g(w,h){return new d.Promise(function(k,b){var y=[],S=w._internalType,T=w._outputType,x=w._mimeType;w.on("data",function(_,C){y.push(_),h&&h(C)}).on("error",function(_){y=[],b(_)}).on("end",function(){try{var _=(function(C,D,M){switch(C){case"blob":return r.newBlob(r.transformTo("arraybuffer",D),M);case"base64":return a.encode(D);default:return r.transformTo(C,D)}})(T,(function(C,D){var M,z=0,J=null,E=0;for(M=0;M<D.length;M++)E+=D[M].length;switch(C){case"string":return D.join("");case"array":return Array.prototype.concat.apply([],D);case"uint8array":for(J=new Uint8Array(E),M=0;M<D.length;M++)J.set(D[M],z),z+=D[M].length;return J;case"nodebuffer":return Buffer.concat(D);default:throw new Error("concat : unsupported type '"+C+"'")}})(S,y),x);k(_)}catch(C){b(C)}y=[]}).resume()})}function u(w,h,k){var b=h;switch(h){case"blob":case"arraybuffer":b="uint8array";break;case"base64":b="string"}try{this._internalType=b,this._outputType=h,this._mimeType=k,r.checkSupport(b),this._worker=w.pipe(new l(b)),w.lock()}catch(y){this._worker=new s("error"),this._worker.error(y)}}u.prototype={accumulate:function(w){return g(this,w)},on:function(w,h){var k=this;return w==="data"?this._worker.on(w,function(b){h.call(k,b.data,b.meta)}):this._worker.on(w,function(){r.delay(h,arguments,k)}),this},resume:function(){return r.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(w){if(r.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new p(this,{objectMode:this._outputType!=="nodebuffer"},w)}},n.exports=u},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(e,n,o){if(o.base64=!0,o.array=!0,o.string=!0,o.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",o.nodebuffer=typeof Buffer<"u",o.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")o.blob=!1;else{var r=new ArrayBuffer(0);try{o.blob=new Blob([r],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(r),o.blob=l.getBlob("application/zip").size===0}catch{o.blob=!1}}}try{o.nodestream=!!e("readable-stream").Readable}catch{o.nodestream=!1}},{"readable-stream":16}],31:[function(e,n,o){for(var r=e("./utils"),l=e("./support"),s=e("./nodejsUtils"),a=e("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function p(){a.call(this,"utf-8 decode"),this.leftOver=null}function g(){a.call(this,"utf-8 encode")}o.utf8encode=function(u){return l.nodebuffer?s.newBufferFrom(u,"utf-8"):(function(w){var h,k,b,y,S,T=w.length,x=0;for(y=0;y<T;y++)(64512&(k=w.charCodeAt(y)))==55296&&y+1<T&&(64512&(b=w.charCodeAt(y+1)))==56320&&(k=65536+(k-55296<<10)+(b-56320),y++),x+=k<128?1:k<2048?2:k<65536?3:4;for(h=l.uint8array?new Uint8Array(x):new Array(x),y=S=0;S<x;y++)(64512&(k=w.charCodeAt(y)))==55296&&y+1<T&&(64512&(b=w.charCodeAt(y+1)))==56320&&(k=65536+(k-55296<<10)+(b-56320),y++),k<128?h[S++]=k:(k<2048?h[S++]=192|k>>>6:(k<65536?h[S++]=224|k>>>12:(h[S++]=240|k>>>18,h[S++]=128|k>>>12&63),h[S++]=128|k>>>6&63),h[S++]=128|63&k);return h})(u)},o.utf8decode=function(u){return l.nodebuffer?r.transformTo("nodebuffer",u).toString("utf-8"):(function(w){var h,k,b,y,S=w.length,T=new Array(2*S);for(h=k=0;h<S;)if((b=w[h++])<128)T[k++]=b;else if(4<(y=c[b]))T[k++]=65533,h+=y-1;else{for(b&=y===2?31:y===3?15:7;1<y&&h<S;)b=b<<6|63&w[h++],y--;1<y?T[k++]=65533:b<65536?T[k++]=b:(b-=65536,T[k++]=55296|b>>10&1023,T[k++]=56320|1023&b)}return T.length!==k&&(T.subarray?T=T.subarray(0,k):T.length=k),r.applyFromCharCode(T)})(u=r.transformTo(l.uint8array?"uint8array":"array",u))},r.inherits(p,a),p.prototype.processChunk=function(u){var w=r.transformTo(l.uint8array?"uint8array":"array",u.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var h=w;(w=new Uint8Array(h.length+this.leftOver.length)).set(this.leftOver,0),w.set(h,this.leftOver.length)}else w=this.leftOver.concat(w);this.leftOver=null}var k=(function(y,S){var T;for((S=S||y.length)>y.length&&(S=y.length),T=S-1;0<=T&&(192&y[T])==128;)T--;return T<0||T===0?S:T+c[y[T]]>S?T:S})(w),b=w;k!==w.length&&(l.uint8array?(b=w.subarray(0,k),this.leftOver=w.subarray(k,w.length)):(b=w.slice(0,k),this.leftOver=w.slice(k,w.length))),this.push({data:o.utf8decode(b),meta:u.meta})},p.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:o.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},o.Utf8DecodeWorker=p,r.inherits(g,a),g.prototype.processChunk=function(u){this.push({data:o.utf8encode(u.data),meta:u.meta})},o.Utf8EncodeWorker=g},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(e,n,o){var r=e("./support"),l=e("./base64"),s=e("./nodejsUtils"),a=e("./external");function c(h){return h}function d(h,k){for(var b=0;b<h.length;++b)k[b]=255&h.charCodeAt(b);return k}e("setimmediate"),o.newBlob=function(h,k){o.checkSupport("blob");try{return new Blob([h],{type:k})}catch{try{var b=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return b.append(h),b.getBlob(k)}catch{throw new Error("Bug : can't construct the Blob.")}}};var p={stringifyByChunk:function(h,k,b){var y=[],S=0,T=h.length;if(T<=b)return String.fromCharCode.apply(null,h);for(;S<T;)k==="array"||k==="nodebuffer"?y.push(String.fromCharCode.apply(null,h.slice(S,Math.min(S+b,T)))):y.push(String.fromCharCode.apply(null,h.subarray(S,Math.min(S+b,T)))),S+=b;return y.join("")},stringifyByChar:function(h){for(var k="",b=0;b<h.length;b++)k+=String.fromCharCode(h[b]);return k},applyCanBeUsed:{uint8array:(function(){try{return r.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return r.nodebuffer&&String.fromCharCode.apply(null,s.allocBuffer(1)).length===1}catch{return!1}})()}};function g(h){var k=65536,b=o.getTypeOf(h),y=!0;if(b==="uint8array"?y=p.applyCanBeUsed.uint8array:b==="nodebuffer"&&(y=p.applyCanBeUsed.nodebuffer),y)for(;1<k;)try{return p.stringifyByChunk(h,b,k)}catch{k=Math.floor(k/2)}return p.stringifyByChar(h)}function u(h,k){for(var b=0;b<h.length;b++)k[b]=h[b];return k}o.applyFromCharCode=g;var w={};w.string={string:c,array:function(h){return d(h,new Array(h.length))},arraybuffer:function(h){return w.string.uint8array(h).buffer},uint8array:function(h){return d(h,new Uint8Array(h.length))},nodebuffer:function(h){return d(h,s.allocBuffer(h.length))}},w.array={string:g,array:c,arraybuffer:function(h){return new Uint8Array(h).buffer},uint8array:function(h){return new Uint8Array(h)},nodebuffer:function(h){return s.newBufferFrom(h)}},w.arraybuffer={string:function(h){return g(new Uint8Array(h))},array:function(h){return u(new Uint8Array(h),new Array(h.byteLength))},arraybuffer:c,uint8array:function(h){return new Uint8Array(h)},nodebuffer:function(h){return s.newBufferFrom(new Uint8Array(h))}},w.uint8array={string:g,array:function(h){return u(h,new Array(h.length))},arraybuffer:function(h){return h.buffer},uint8array:c,nodebuffer:function(h){return s.newBufferFrom(h)}},w.nodebuffer={string:g,array:function(h){return u(h,new Array(h.length))},arraybuffer:function(h){return w.nodebuffer.uint8array(h).buffer},uint8array:function(h){return u(h,new Uint8Array(h.length))},nodebuffer:c},o.transformTo=function(h,k){if(k=k||"",!h)return k;o.checkSupport(h);var b=o.getTypeOf(k);return w[b][h](k)},o.resolve=function(h){for(var k=h.split("/"),b=[],y=0;y<k.length;y++){var S=k[y];S==="."||S===""&&y!==0&&y!==k.length-1||(S===".."?b.pop():b.push(S))}return b.join("/")},o.getTypeOf=function(h){return typeof h=="string"?"string":Object.prototype.toString.call(h)==="[object Array]"?"array":r.nodebuffer&&s.isBuffer(h)?"nodebuffer":r.uint8array&&h instanceof Uint8Array?"uint8array":r.arraybuffer&&h instanceof ArrayBuffer?"arraybuffer":void 0},o.checkSupport=function(h){if(!r[h.toLowerCase()])throw new Error(h+" is not supported by this platform")},o.MAX_VALUE_16BITS=65535,o.MAX_VALUE_32BITS=-1,o.pretty=function(h){var k,b,y="";for(b=0;b<(h||"").length;b++)y+="\\x"+((k=h.charCodeAt(b))<16?"0":"")+k.toString(16).toUpperCase();return y},o.delay=function(h,k,b){setImmediate(function(){h.apply(b||null,k||[])})},o.inherits=function(h,k){function b(){}b.prototype=k.prototype,h.prototype=new b},o.extend=function(){var h,k,b={};for(h=0;h<arguments.length;h++)for(k in arguments[h])Object.prototype.hasOwnProperty.call(arguments[h],k)&&b[k]===void 0&&(b[k]=arguments[h][k]);return b},o.prepareContent=function(h,k,b,y,S){return a.Promise.resolve(k).then(function(T){return r.blob&&(T instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(T))!==-1)&&typeof FileReader<"u"?new a.Promise(function(x,_){var C=new FileReader;C.onload=function(D){x(D.target.result)},C.onerror=function(D){_(D.target.error)},C.readAsArrayBuffer(T)}):T}).then(function(T){var x=o.getTypeOf(T);return x?(x==="arraybuffer"?T=o.transformTo("uint8array",T):x==="string"&&(S?T=l.decode(T):b&&y!==!0&&(T=(function(_){return d(_,r.uint8array?new Uint8Array(_.length):new Array(_.length))})(T))),T):a.Promise.reject(new Error("Can't read the data of '"+h+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(e,n,o){var r=e("./reader/readerFor"),l=e("./utils"),s=e("./signature"),a=e("./zipEntry"),c=e("./support");function d(p){this.files=[],this.loadOptions=p}d.prototype={checkSignature:function(p){if(!this.reader.readAndCheckSignature(p)){this.reader.index-=4;var g=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(g)+", expected "+l.pretty(p)+")")}},isSignature:function(p,g){var u=this.reader.index;this.reader.setIndex(p);var w=this.reader.readString(4)===g;return this.reader.setIndex(u),w},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var p=this.reader.readData(this.zipCommentLength),g=c.uint8array?"uint8array":"array",u=l.transformTo(g,p);this.zipComment=this.loadOptions.decodeFileName(u)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var p,g,u,w=this.zip64EndOfCentralSize-44;0<w;)p=this.reader.readInt(2),g=this.reader.readInt(4),u=this.reader.readData(g),this.zip64ExtensibleData[p]={id:p,length:g,value:u}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var p,g;for(p=0;p<this.files.length;p++)g=this.files[p],this.reader.setIndex(g.localHeaderOffset),this.checkSignature(s.LOCAL_FILE_HEADER),g.readLocalPart(this.reader),g.handleUTF8(),g.processAttributes()},readCentralDir:function(){var p;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(s.CENTRAL_FILE_HEADER);)(p=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(p);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var p=this.reader.lastIndexOfSignature(s.CENTRAL_DIRECTORY_END);if(p<0)throw this.isSignature(0,s.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(p);var g=p;if(this.checkSignature(s.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(p=this.reader.lastIndexOfSignature(s.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(p),this.checkSignature(s.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,s.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(s.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(s.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var u=this.centralDirOffset+this.centralDirSize;this.zip64&&(u+=20,u+=12+this.zip64EndOfCentralSize);var w=g-u;if(0<w)this.isSignature(g,s.CENTRAL_FILE_HEADER)||(this.reader.zero=w);else if(w<0)throw new Error("Corrupted zip: missing "+Math.abs(w)+" bytes.")},prepareReader:function(p){this.reader=r(p)},load:function(p){this.prepareReader(p),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(e,n,o){var r=e("./reader/readerFor"),l=e("./utils"),s=e("./compressedObject"),a=e("./crc32"),c=e("./utf8"),d=e("./compressions"),p=e("./support");function g(u,w){this.options=u,this.loadOptions=w}g.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(u){var w,h;if(u.skip(22),this.fileNameLength=u.readInt(2),h=u.readInt(2),this.fileName=u.readData(this.fileNameLength),u.skip(h),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((w=(function(k){for(var b in d)if(Object.prototype.hasOwnProperty.call(d,b)&&d[b].magic===k)return d[b];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new s(this.compressedSize,this.uncompressedSize,this.crc32,w,u.readData(this.compressedSize))},readCentralPart:function(u){this.versionMadeBy=u.readInt(2),u.skip(2),this.bitFlag=u.readInt(2),this.compressionMethod=u.readString(2),this.date=u.readDate(),this.crc32=u.readInt(4),this.compressedSize=u.readInt(4),this.uncompressedSize=u.readInt(4);var w=u.readInt(2);if(this.extraFieldsLength=u.readInt(2),this.fileCommentLength=u.readInt(2),this.diskNumberStart=u.readInt(2),this.internalFileAttributes=u.readInt(2),this.externalFileAttributes=u.readInt(4),this.localHeaderOffset=u.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");u.skip(w),this.readExtraFields(u),this.parseZIP64ExtraField(u),this.fileComment=u.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var u=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),u==0&&(this.dosPermissions=63&this.externalFileAttributes),u==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var u=r(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=u.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=u.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=u.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=u.readInt(4))}},readExtraFields:function(u){var w,h,k,b=u.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});u.index+4<b;)w=u.readInt(2),h=u.readInt(2),k=u.readData(h),this.extraFields[w]={id:w,length:h,value:k};u.setIndex(b)},handleUTF8:function(){var u=p.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var w=this.findExtraFieldUnicodePath();if(w!==null)this.fileNameStr=w;else{var h=l.transformTo(u,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(h)}var k=this.findExtraFieldUnicodeComment();if(k!==null)this.fileCommentStr=k;else{var b=l.transformTo(u,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(b)}}},findExtraFieldUnicodePath:function(){var u=this.extraFields[28789];if(u){var w=r(u.value);return w.readInt(1)!==1||a(this.fileName)!==w.readInt(4)?null:c.utf8decode(w.readData(u.length-5))}return null},findExtraFieldUnicodeComment:function(){var u=this.extraFields[25461];if(u){var w=r(u.value);return w.readInt(1)!==1||a(this.fileComment)!==w.readInt(4)?null:c.utf8decode(w.readData(u.length-5))}return null}},n.exports=g},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(e,n,o){function r(w,h,k){this.name=w,this.dir=k.dir,this.date=k.date,this.comment=k.comment,this.unixPermissions=k.unixPermissions,this.dosPermissions=k.dosPermissions,this._data=h,this._dataBinary=k.binary,this.options={compression:k.compression,compressionOptions:k.compressionOptions}}var l=e("./stream/StreamHelper"),s=e("./stream/DataWorker"),a=e("./utf8"),c=e("./compressedObject"),d=e("./stream/GenericWorker");r.prototype={internalStream:function(w){var h=null,k="string";try{if(!w)throw new Error("No output type specified.");var b=(k=w.toLowerCase())==="string"||k==="text";k!=="binarystring"&&k!=="text"||(k="string"),h=this._decompressWorker();var y=!this._dataBinary;y&&!b&&(h=h.pipe(new a.Utf8EncodeWorker)),!y&&b&&(h=h.pipe(new a.Utf8DecodeWorker))}catch(S){(h=new d("error")).error(S)}return new l(h,k,"")},async:function(w,h){return this.internalStream(w).accumulate(h)},nodeStream:function(w,h){return this.internalStream(w||"nodebuffer").toNodejsStream(h)},_compressWorker:function(w,h){if(this._data instanceof c&&this._data.compression.magic===w.magic)return this._data.getCompressedWorker();var k=this._decompressWorker();return this._dataBinary||(k=k.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(k,w,h)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new s(this._data)}};for(var p=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],g=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},u=0;u<p.length;u++)r.prototype[p[u]]=g;n.exports=r},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(e,n,o){(function(r){var l,s,a=r.MutationObserver||r.WebKitMutationObserver;if(a){var c=0,d=new a(w),p=r.document.createTextNode("");d.observe(p,{characterData:!0}),l=function(){p.data=c=++c%2}}else if(r.setImmediate||r.MessageChannel===void 0)l="document"in r&&"onreadystatechange"in r.document.createElement("script")?function(){var h=r.document.createElement("script");h.onreadystatechange=function(){w(),h.onreadystatechange=null,h.parentNode.removeChild(h),h=null},r.document.documentElement.appendChild(h)}:function(){setTimeout(w,0)};else{var g=new r.MessageChannel;g.port1.onmessage=w,l=function(){g.port2.postMessage(0)}}var u=[];function w(){var h,k;s=!0;for(var b=u.length;b;){for(k=u,u=[],h=-1;++h<b;)k[h]();b=u.length}s=!1}n.exports=function(h){u.push(h)!==1||s||l()}}).call(this,typeof Ln<"u"?Ln:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(e,n,o){var r=e("immediate");function l(){}var s={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function p(b){if(typeof b!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,b!==l&&h(this,b)}function g(b,y,S){this.promise=b,typeof y=="function"&&(this.onFulfilled=y,this.callFulfilled=this.otherCallFulfilled),typeof S=="function"&&(this.onRejected=S,this.callRejected=this.otherCallRejected)}function u(b,y,S){r(function(){var T;try{T=y(S)}catch(x){return s.reject(b,x)}T===b?s.reject(b,new TypeError("Cannot resolve promise with itself")):s.resolve(b,T)})}function w(b){var y=b&&b.then;if(b&&(typeof b=="object"||typeof b=="function")&&typeof y=="function")return function(){y.apply(b,arguments)}}function h(b,y){var S=!1;function T(C){S||(S=!0,s.reject(b,C))}function x(C){S||(S=!0,s.resolve(b,C))}var _=k(function(){y(x,T)});_.status==="error"&&T(_.value)}function k(b,y){var S={};try{S.value=b(y),S.status="success"}catch(T){S.status="error",S.value=T}return S}(n.exports=p).prototype.finally=function(b){if(typeof b!="function")return this;var y=this.constructor;return this.then(function(S){return y.resolve(b()).then(function(){return S})},function(S){return y.resolve(b()).then(function(){throw S})})},p.prototype.catch=function(b){return this.then(null,b)},p.prototype.then=function(b,y){if(typeof b!="function"&&this.state===c||typeof y!="function"&&this.state===a)return this;var S=new this.constructor(l);return this.state!==d?u(S,this.state===c?b:y,this.outcome):this.queue.push(new g(S,b,y)),S},g.prototype.callFulfilled=function(b){s.resolve(this.promise,b)},g.prototype.otherCallFulfilled=function(b){u(this.promise,this.onFulfilled,b)},g.prototype.callRejected=function(b){s.reject(this.promise,b)},g.prototype.otherCallRejected=function(b){u(this.promise,this.onRejected,b)},s.resolve=function(b,y){var S=k(w,y);if(S.status==="error")return s.reject(b,S.value);var T=S.value;if(T)h(b,T);else{b.state=c,b.outcome=y;for(var x=-1,_=b.queue.length;++x<_;)b.queue[x].callFulfilled(y)}return b},s.reject=function(b,y){b.state=a,b.outcome=y;for(var S=-1,T=b.queue.length;++S<T;)b.queue[S].callRejected(y);return b},p.resolve=function(b){return b instanceof this?b:s.resolve(new this(l),b)},p.reject=function(b){var y=new this(l);return s.reject(y,b)},p.all=function(b){var y=this;if(Object.prototype.toString.call(b)!=="[object Array]")return this.reject(new TypeError("must be an array"));var S=b.length,T=!1;if(!S)return this.resolve([]);for(var x=new Array(S),_=0,C=-1,D=new this(l);++C<S;)M(b[C],C);return D;function M(z,J){y.resolve(z).then(function(E){x[J]=E,++_!==S||T||(T=!0,s.resolve(D,x))},function(E){T||(T=!0,s.reject(D,E))})}},p.race=function(b){var y=this;if(Object.prototype.toString.call(b)!=="[object Array]")return this.reject(new TypeError("must be an array"));var S=b.length,T=!1;if(!S)return this.resolve([]);for(var x=-1,_=new this(l);++x<S;)C=b[x],y.resolve(C).then(function(D){T||(T=!0,s.resolve(_,D))},function(D){T||(T=!0,s.reject(_,D))});var C;return _}},{immediate:36}],38:[function(e,n,o){var r={};(0,e("./lib/utils/common").assign)(r,e("./lib/deflate"),e("./lib/inflate"),e("./lib/zlib/constants")),n.exports=r},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(e,n,o){var r=e("./zlib/deflate"),l=e("./utils/common"),s=e("./utils/strings"),a=e("./zlib/messages"),c=e("./zlib/zstream"),d=Object.prototype.toString,p=0,g=-1,u=0,w=8;function h(b){if(!(this instanceof h))return new h(b);this.options=l.assign({level:g,method:w,chunkSize:16384,windowBits:15,memLevel:8,strategy:u,to:""},b||{});var y=this.options;y.raw&&0<y.windowBits?y.windowBits=-y.windowBits:y.gzip&&0<y.windowBits&&y.windowBits<16&&(y.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var S=r.deflateInit2(this.strm,y.level,y.method,y.windowBits,y.memLevel,y.strategy);if(S!==p)throw new Error(a[S]);if(y.header&&r.deflateSetHeader(this.strm,y.header),y.dictionary){var T;if(T=typeof y.dictionary=="string"?s.string2buf(y.dictionary):d.call(y.dictionary)==="[object ArrayBuffer]"?new Uint8Array(y.dictionary):y.dictionary,(S=r.deflateSetDictionary(this.strm,T))!==p)throw new Error(a[S]);this._dict_set=!0}}function k(b,y){var S=new h(y);if(S.push(b,!0),S.err)throw S.msg||a[S.err];return S.result}h.prototype.push=function(b,y){var S,T,x=this.strm,_=this.options.chunkSize;if(this.ended)return!1;T=y===~~y?y:y===!0?4:0,typeof b=="string"?x.input=s.string2buf(b):d.call(b)==="[object ArrayBuffer]"?x.input=new Uint8Array(b):x.input=b,x.next_in=0,x.avail_in=x.input.length;do{if(x.avail_out===0&&(x.output=new l.Buf8(_),x.next_out=0,x.avail_out=_),(S=r.deflate(x,T))!==1&&S!==p)return this.onEnd(S),!(this.ended=!0);x.avail_out!==0&&(x.avail_in!==0||T!==4&&T!==2)||(this.options.to==="string"?this.onData(s.buf2binstring(l.shrinkBuf(x.output,x.next_out))):this.onData(l.shrinkBuf(x.output,x.next_out)))}while((0<x.avail_in||x.avail_out===0)&&S!==1);return T===4?(S=r.deflateEnd(this.strm),this.onEnd(S),this.ended=!0,S===p):T!==2||(this.onEnd(p),!(x.avail_out=0))},h.prototype.onData=function(b){this.chunks.push(b)},h.prototype.onEnd=function(b){b===p&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=b,this.msg=this.strm.msg},o.Deflate=h,o.deflate=k,o.deflateRaw=function(b,y){return(y=y||{}).raw=!0,k(b,y)},o.gzip=function(b,y){return(y=y||{}).gzip=!0,k(b,y)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(e,n,o){var r=e("./zlib/inflate"),l=e("./utils/common"),s=e("./utils/strings"),a=e("./zlib/constants"),c=e("./zlib/messages"),d=e("./zlib/zstream"),p=e("./zlib/gzheader"),g=Object.prototype.toString;function u(h){if(!(this instanceof u))return new u(h);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},h||{});var k=this.options;k.raw&&0<=k.windowBits&&k.windowBits<16&&(k.windowBits=-k.windowBits,k.windowBits===0&&(k.windowBits=-15)),!(0<=k.windowBits&&k.windowBits<16)||h&&h.windowBits||(k.windowBits+=32),15<k.windowBits&&k.windowBits<48&&(15&k.windowBits)==0&&(k.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var b=r.inflateInit2(this.strm,k.windowBits);if(b!==a.Z_OK)throw new Error(c[b]);this.header=new p,r.inflateGetHeader(this.strm,this.header)}function w(h,k){var b=new u(k);if(b.push(h,!0),b.err)throw b.msg||c[b.err];return b.result}u.prototype.push=function(h,k){var b,y,S,T,x,_,C=this.strm,D=this.options.chunkSize,M=this.options.dictionary,z=!1;if(this.ended)return!1;y=k===~~k?k:k===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof h=="string"?C.input=s.binstring2buf(h):g.call(h)==="[object ArrayBuffer]"?C.input=new Uint8Array(h):C.input=h,C.next_in=0,C.avail_in=C.input.length;do{if(C.avail_out===0&&(C.output=new l.Buf8(D),C.next_out=0,C.avail_out=D),(b=r.inflate(C,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&M&&(_=typeof M=="string"?s.string2buf(M):g.call(M)==="[object ArrayBuffer]"?new Uint8Array(M):M,b=r.inflateSetDictionary(this.strm,_)),b===a.Z_BUF_ERROR&&z===!0&&(b=a.Z_OK,z=!1),b!==a.Z_STREAM_END&&b!==a.Z_OK)return this.onEnd(b),!(this.ended=!0);C.next_out&&(C.avail_out!==0&&b!==a.Z_STREAM_END&&(C.avail_in!==0||y!==a.Z_FINISH&&y!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(S=s.utf8border(C.output,C.next_out),T=C.next_out-S,x=s.buf2string(C.output,S),C.next_out=T,C.avail_out=D-T,T&&l.arraySet(C.output,C.output,S,T,0),this.onData(x)):this.onData(l.shrinkBuf(C.output,C.next_out)))),C.avail_in===0&&C.avail_out===0&&(z=!0)}while((0<C.avail_in||C.avail_out===0)&&b!==a.Z_STREAM_END);return b===a.Z_STREAM_END&&(y=a.Z_FINISH),y===a.Z_FINISH?(b=r.inflateEnd(this.strm),this.onEnd(b),this.ended=!0,b===a.Z_OK):y!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(C.avail_out=0))},u.prototype.onData=function(h){this.chunks.push(h)},u.prototype.onEnd=function(h){h===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=h,this.msg=this.strm.msg},o.Inflate=u,o.inflate=w,o.inflateRaw=function(h,k){return(k=k||{}).raw=!0,w(h,k)},o.ungzip=w},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(e,n,o){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";o.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var p in d)d.hasOwnProperty(p)&&(a[p]=d[p])}}return a},o.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,p,g){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+p),g);else for(var u=0;u<p;u++)a[g+u]=c[d+u]},flattenChunks:function(a){var c,d,p,g,u,w;for(c=p=0,d=a.length;c<d;c++)p+=a[c].length;for(w=new Uint8Array(p),c=g=0,d=a.length;c<d;c++)u=a[c],w.set(u,g),g+=u.length;return w}},s={arraySet:function(a,c,d,p,g){for(var u=0;u<p;u++)a[g+u]=c[d+u]},flattenChunks:function(a){return[].concat.apply([],a)}};o.setTyped=function(a){a?(o.Buf8=Uint8Array,o.Buf16=Uint16Array,o.Buf32=Int32Array,o.assign(o,l)):(o.Buf8=Array,o.Buf16=Array,o.Buf32=Array,o.assign(o,s))},o.setTyped(r)},{}],42:[function(e,n,o){var r=e("./common"),l=!0,s=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{s=!1}for(var a=new r.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(p,g){if(g<65537&&(p.subarray&&s||!p.subarray&&l))return String.fromCharCode.apply(null,r.shrinkBuf(p,g));for(var u="",w=0;w<g;w++)u+=String.fromCharCode(p[w]);return u}a[254]=a[254]=1,o.string2buf=function(p){var g,u,w,h,k,b=p.length,y=0;for(h=0;h<b;h++)(64512&(u=p.charCodeAt(h)))==55296&&h+1<b&&(64512&(w=p.charCodeAt(h+1)))==56320&&(u=65536+(u-55296<<10)+(w-56320),h++),y+=u<128?1:u<2048?2:u<65536?3:4;for(g=new r.Buf8(y),h=k=0;k<y;h++)(64512&(u=p.charCodeAt(h)))==55296&&h+1<b&&(64512&(w=p.charCodeAt(h+1)))==56320&&(u=65536+(u-55296<<10)+(w-56320),h++),u<128?g[k++]=u:(u<2048?g[k++]=192|u>>>6:(u<65536?g[k++]=224|u>>>12:(g[k++]=240|u>>>18,g[k++]=128|u>>>12&63),g[k++]=128|u>>>6&63),g[k++]=128|63&u);return g},o.buf2binstring=function(p){return d(p,p.length)},o.binstring2buf=function(p){for(var g=new r.Buf8(p.length),u=0,w=g.length;u<w;u++)g[u]=p.charCodeAt(u);return g},o.buf2string=function(p,g){var u,w,h,k,b=g||p.length,y=new Array(2*b);for(u=w=0;u<b;)if((h=p[u++])<128)y[w++]=h;else if(4<(k=a[h]))y[w++]=65533,u+=k-1;else{for(h&=k===2?31:k===3?15:7;1<k&&u<b;)h=h<<6|63&p[u++],k--;1<k?y[w++]=65533:h<65536?y[w++]=h:(h-=65536,y[w++]=55296|h>>10&1023,y[w++]=56320|1023&h)}return d(y,w)},o.utf8border=function(p,g){var u;for((g=g||p.length)>p.length&&(g=p.length),u=g-1;0<=u&&(192&p[u])==128;)u--;return u<0||u===0?g:u+a[p[u]]>g?u:g}},{"./common":41}],43:[function(e,n,o){n.exports=function(r,l,s,a){for(var c=65535&r|0,d=r>>>16&65535|0,p=0;s!==0;){for(s-=p=2e3<s?2e3:s;d=d+(c=c+l[a++]|0)|0,--p;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(e,n,o){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(e,n,o){var r=(function(){for(var l,s=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;s[a]=l}return s})();n.exports=function(l,s,a,c){var d=r,p=c+a;l^=-1;for(var g=c;g<p;g++)l=l>>>8^d[255&(l^s[g])];return-1^l}},{}],46:[function(e,n,o){var r,l=e("../utils/common"),s=e("./trees"),a=e("./adler32"),c=e("./crc32"),d=e("./messages"),p=0,g=4,u=0,w=-2,h=-1,k=4,b=2,y=8,S=9,T=286,x=30,_=19,C=2*T+1,D=15,M=3,z=258,J=z+M+1,E=42,A=113,v=1,P=2,G=3,F=4;function et(f,j){return f.msg=d[j],j}function H(f){return(f<<1)-(4<f?9:0)}function V(f){for(var j=f.length;0<=--j;)f[j]=0}function R(f){var j=f.state,O=j.pending;O>f.avail_out&&(O=f.avail_out),O!==0&&(l.arraySet(f.output,j.pending_buf,j.pending_out,O,f.next_out),f.next_out+=O,j.pending_out+=O,f.total_out+=O,f.avail_out-=O,j.pending-=O,j.pending===0&&(j.pending_out=0))}function U(f,j){s._tr_flush_block(f,0<=f.block_start?f.block_start:-1,f.strstart-f.block_start,j),f.block_start=f.strstart,R(f.strm)}function at(f,j){f.pending_buf[f.pending++]=j}function rt(f,j){f.pending_buf[f.pending++]=j>>>8&255,f.pending_buf[f.pending++]=255&j}function st(f,j){var O,$,I=f.max_chain_length,L=f.strstart,q=f.prev_length,K=f.nice_match,W=f.strstart>f.w_size-J?f.strstart-(f.w_size-J):0,Y=f.window,it=f.w_mask,Q=f.prev,dt=f.strstart+z,kt=Y[L+q-1],vt=Y[L+q];f.prev_length>=f.good_match&&(I>>=2),K>f.lookahead&&(K=f.lookahead);do if(Y[(O=j)+q]===vt&&Y[O+q-1]===kt&&Y[O]===Y[L]&&Y[++O]===Y[L+1]){L+=2,O++;do;while(Y[++L]===Y[++O]&&Y[++L]===Y[++O]&&Y[++L]===Y[++O]&&Y[++L]===Y[++O]&&Y[++L]===Y[++O]&&Y[++L]===Y[++O]&&Y[++L]===Y[++O]&&Y[++L]===Y[++O]&&L<dt);if($=z-(dt-L),L=dt-z,q<$){if(f.match_start=j,K<=(q=$))break;kt=Y[L+q-1],vt=Y[L+q]}}while((j=Q[j&it])>W&&--I!=0);return q<=f.lookahead?q:f.lookahead}function X(f){var j,O,$,I,L,q,K,W,Y,it,Q=f.w_size;do{if(I=f.window_size-f.lookahead-f.strstart,f.strstart>=Q+(Q-J)){for(l.arraySet(f.window,f.window,Q,Q,0),f.match_start-=Q,f.strstart-=Q,f.block_start-=Q,j=O=f.hash_size;$=f.head[--j],f.head[j]=Q<=$?$-Q:0,--O;);for(j=O=Q;$=f.prev[--j],f.prev[j]=Q<=$?$-Q:0,--O;);I+=Q}if(f.strm.avail_in===0)break;if(q=f.strm,K=f.window,W=f.strstart+f.lookahead,Y=I,it=void 0,it=q.avail_in,Y<it&&(it=Y),O=it===0?0:(q.avail_in-=it,l.arraySet(K,q.input,q.next_in,it,W),q.state.wrap===1?q.adler=a(q.adler,K,it,W):q.state.wrap===2&&(q.adler=c(q.adler,K,it,W)),q.next_in+=it,q.total_in+=it,it),f.lookahead+=O,f.lookahead+f.insert>=M)for(L=f.strstart-f.insert,f.ins_h=f.window[L],f.ins_h=(f.ins_h<<f.hash_shift^f.window[L+1])&f.hash_mask;f.insert&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[L+M-1])&f.hash_mask,f.prev[L&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=L,L++,f.insert--,!(f.lookahead+f.insert<M)););}while(f.lookahead<J&&f.strm.avail_in!==0)}function pt(f,j){for(var O,$;;){if(f.lookahead<J){if(X(f),f.lookahead<J&&j===p)return v;if(f.lookahead===0)break}if(O=0,f.lookahead>=M&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+M-1])&f.hash_mask,O=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart),O!==0&&f.strstart-O<=f.w_size-J&&(f.match_length=st(f,O)),f.match_length>=M)if($=s._tr_tally(f,f.strstart-f.match_start,f.match_length-M),f.lookahead-=f.match_length,f.match_length<=f.max_lazy_match&&f.lookahead>=M){for(f.match_length--;f.strstart++,f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+M-1])&f.hash_mask,O=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart,--f.match_length!=0;);f.strstart++}else f.strstart+=f.match_length,f.match_length=0,f.ins_h=f.window[f.strstart],f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+1])&f.hash_mask;else $=s._tr_tally(f,0,f.window[f.strstart]),f.lookahead--,f.strstart++;if($&&(U(f,!1),f.strm.avail_out===0))return v}return f.insert=f.strstart<M-1?f.strstart:M-1,j===g?(U(f,!0),f.strm.avail_out===0?G:F):f.last_lit&&(U(f,!1),f.strm.avail_out===0)?v:P}function mt(f,j){for(var O,$,I;;){if(f.lookahead<J){if(X(f),f.lookahead<J&&j===p)return v;if(f.lookahead===0)break}if(O=0,f.lookahead>=M&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+M-1])&f.hash_mask,O=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart),f.prev_length=f.match_length,f.prev_match=f.match_start,f.match_length=M-1,O!==0&&f.prev_length<f.max_lazy_match&&f.strstart-O<=f.w_size-J&&(f.match_length=st(f,O),f.match_length<=5&&(f.strategy===1||f.match_length===M&&4096<f.strstart-f.match_start)&&(f.match_length=M-1)),f.prev_length>=M&&f.match_length<=f.prev_length){for(I=f.strstart+f.lookahead-M,$=s._tr_tally(f,f.strstart-1-f.prev_match,f.prev_length-M),f.lookahead-=f.prev_length-1,f.prev_length-=2;++f.strstart<=I&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+M-1])&f.hash_mask,O=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart),--f.prev_length!=0;);if(f.match_available=0,f.match_length=M-1,f.strstart++,$&&(U(f,!1),f.strm.avail_out===0))return v}else if(f.match_available){if(($=s._tr_tally(f,0,f.window[f.strstart-1]))&&U(f,!1),f.strstart++,f.lookahead--,f.strm.avail_out===0)return v}else f.match_available=1,f.strstart++,f.lookahead--}return f.match_available&&($=s._tr_tally(f,0,f.window[f.strstart-1]),f.match_available=0),f.insert=f.strstart<M-1?f.strstart:M-1,j===g?(U(f,!0),f.strm.avail_out===0?G:F):f.last_lit&&(U(f,!1),f.strm.avail_out===0)?v:P}function Z(f,j,O,$,I){this.good_length=f,this.max_lazy=j,this.nice_length=O,this.max_chain=$,this.func=I}function ot(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=y,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*C),this.dyn_dtree=new l.Buf16(2*(2*x+1)),this.bl_tree=new l.Buf16(2*(2*_+1)),V(this.dyn_ltree),V(this.dyn_dtree),V(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(D+1),this.heap=new l.Buf16(2*T+1),V(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*T+1),V(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ct(f){var j;return f&&f.state?(f.total_in=f.total_out=0,f.data_type=b,(j=f.state).pending=0,j.pending_out=0,j.wrap<0&&(j.wrap=-j.wrap),j.status=j.wrap?E:A,f.adler=j.wrap===2?0:1,j.last_flush=p,s._tr_init(j),u):et(f,w)}function B(f){var j=ct(f);return j===u&&(function(O){O.window_size=2*O.w_size,V(O.head),O.max_lazy_match=r[O.level].max_lazy,O.good_match=r[O.level].good_length,O.nice_match=r[O.level].nice_length,O.max_chain_length=r[O.level].max_chain,O.strstart=0,O.block_start=0,O.lookahead=0,O.insert=0,O.match_length=O.prev_length=M-1,O.match_available=0,O.ins_h=0})(f.state),j}function N(f,j,O,$,I,L){if(!f)return w;var q=1;if(j===h&&(j=6),$<0?(q=0,$=-$):15<$&&(q=2,$-=16),I<1||S<I||O!==y||$<8||15<$||j<0||9<j||L<0||k<L)return et(f,w);$===8&&($=9);var K=new ot;return(f.state=K).strm=f,K.wrap=q,K.gzhead=null,K.w_bits=$,K.w_size=1<<K.w_bits,K.w_mask=K.w_size-1,K.hash_bits=I+7,K.hash_size=1<<K.hash_bits,K.hash_mask=K.hash_size-1,K.hash_shift=~~((K.hash_bits+M-1)/M),K.window=new l.Buf8(2*K.w_size),K.head=new l.Buf16(K.hash_size),K.prev=new l.Buf16(K.w_size),K.lit_bufsize=1<<I+6,K.pending_buf_size=4*K.lit_bufsize,K.pending_buf=new l.Buf8(K.pending_buf_size),K.d_buf=1*K.lit_bufsize,K.l_buf=3*K.lit_bufsize,K.level=j,K.strategy=L,K.method=O,B(f)}r=[new Z(0,0,0,0,function(f,j){var O=65535;for(O>f.pending_buf_size-5&&(O=f.pending_buf_size-5);;){if(f.lookahead<=1){if(X(f),f.lookahead===0&&j===p)return v;if(f.lookahead===0)break}f.strstart+=f.lookahead,f.lookahead=0;var $=f.block_start+O;if((f.strstart===0||f.strstart>=$)&&(f.lookahead=f.strstart-$,f.strstart=$,U(f,!1),f.strm.avail_out===0)||f.strstart-f.block_start>=f.w_size-J&&(U(f,!1),f.strm.avail_out===0))return v}return f.insert=0,j===g?(U(f,!0),f.strm.avail_out===0?G:F):(f.strstart>f.block_start&&(U(f,!1),f.strm.avail_out),v)}),new Z(4,4,8,4,pt),new Z(4,5,16,8,pt),new Z(4,6,32,32,pt),new Z(4,4,16,16,mt),new Z(8,16,32,32,mt),new Z(8,16,128,128,mt),new Z(8,32,128,256,mt),new Z(32,128,258,1024,mt),new Z(32,258,258,4096,mt)],o.deflateInit=function(f,j){return N(f,j,y,15,8,0)},o.deflateInit2=N,o.deflateReset=B,o.deflateResetKeep=ct,o.deflateSetHeader=function(f,j){return f&&f.state?f.state.wrap!==2?w:(f.state.gzhead=j,u):w},o.deflate=function(f,j){var O,$,I,L;if(!f||!f.state||5<j||j<0)return f?et(f,w):w;if($=f.state,!f.output||!f.input&&f.avail_in!==0||$.status===666&&j!==g)return et(f,f.avail_out===0?-5:w);if($.strm=f,O=$.last_flush,$.last_flush=j,$.status===E)if($.wrap===2)f.adler=0,at($,31),at($,139),at($,8),$.gzhead?(at($,($.gzhead.text?1:0)+($.gzhead.hcrc?2:0)+($.gzhead.extra?4:0)+($.gzhead.name?8:0)+($.gzhead.comment?16:0)),at($,255&$.gzhead.time),at($,$.gzhead.time>>8&255),at($,$.gzhead.time>>16&255),at($,$.gzhead.time>>24&255),at($,$.level===9?2:2<=$.strategy||$.level<2?4:0),at($,255&$.gzhead.os),$.gzhead.extra&&$.gzhead.extra.length&&(at($,255&$.gzhead.extra.length),at($,$.gzhead.extra.length>>8&255)),$.gzhead.hcrc&&(f.adler=c(f.adler,$.pending_buf,$.pending,0)),$.gzindex=0,$.status=69):(at($,0),at($,0),at($,0),at($,0),at($,0),at($,$.level===9?2:2<=$.strategy||$.level<2?4:0),at($,3),$.status=A);else{var q=y+($.w_bits-8<<4)<<8;q|=(2<=$.strategy||$.level<2?0:$.level<6?1:$.level===6?2:3)<<6,$.strstart!==0&&(q|=32),q+=31-q%31,$.status=A,rt($,q),$.strstart!==0&&(rt($,f.adler>>>16),rt($,65535&f.adler)),f.adler=1}if($.status===69)if($.gzhead.extra){for(I=$.pending;$.gzindex<(65535&$.gzhead.extra.length)&&($.pending!==$.pending_buf_size||($.gzhead.hcrc&&$.pending>I&&(f.adler=c(f.adler,$.pending_buf,$.pending-I,I)),R(f),I=$.pending,$.pending!==$.pending_buf_size));)at($,255&$.gzhead.extra[$.gzindex]),$.gzindex++;$.gzhead.hcrc&&$.pending>I&&(f.adler=c(f.adler,$.pending_buf,$.pending-I,I)),$.gzindex===$.gzhead.extra.length&&($.gzindex=0,$.status=73)}else $.status=73;if($.status===73)if($.gzhead.name){I=$.pending;do{if($.pending===$.pending_buf_size&&($.gzhead.hcrc&&$.pending>I&&(f.adler=c(f.adler,$.pending_buf,$.pending-I,I)),R(f),I=$.pending,$.pending===$.pending_buf_size)){L=1;break}L=$.gzindex<$.gzhead.name.length?255&$.gzhead.name.charCodeAt($.gzindex++):0,at($,L)}while(L!==0);$.gzhead.hcrc&&$.pending>I&&(f.adler=c(f.adler,$.pending_buf,$.pending-I,I)),L===0&&($.gzindex=0,$.status=91)}else $.status=91;if($.status===91)if($.gzhead.comment){I=$.pending;do{if($.pending===$.pending_buf_size&&($.gzhead.hcrc&&$.pending>I&&(f.adler=c(f.adler,$.pending_buf,$.pending-I,I)),R(f),I=$.pending,$.pending===$.pending_buf_size)){L=1;break}L=$.gzindex<$.gzhead.comment.length?255&$.gzhead.comment.charCodeAt($.gzindex++):0,at($,L)}while(L!==0);$.gzhead.hcrc&&$.pending>I&&(f.adler=c(f.adler,$.pending_buf,$.pending-I,I)),L===0&&($.status=103)}else $.status=103;if($.status===103&&($.gzhead.hcrc?($.pending+2>$.pending_buf_size&&R(f),$.pending+2<=$.pending_buf_size&&(at($,255&f.adler),at($,f.adler>>8&255),f.adler=0,$.status=A)):$.status=A),$.pending!==0){if(R(f),f.avail_out===0)return $.last_flush=-1,u}else if(f.avail_in===0&&H(j)<=H(O)&&j!==g)return et(f,-5);if($.status===666&&f.avail_in!==0)return et(f,-5);if(f.avail_in!==0||$.lookahead!==0||j!==p&&$.status!==666){var K=$.strategy===2?(function(W,Y){for(var it;;){if(W.lookahead===0&&(X(W),W.lookahead===0)){if(Y===p)return v;break}if(W.match_length=0,it=s._tr_tally(W,0,W.window[W.strstart]),W.lookahead--,W.strstart++,it&&(U(W,!1),W.strm.avail_out===0))return v}return W.insert=0,Y===g?(U(W,!0),W.strm.avail_out===0?G:F):W.last_lit&&(U(W,!1),W.strm.avail_out===0)?v:P})($,j):$.strategy===3?(function(W,Y){for(var it,Q,dt,kt,vt=W.window;;){if(W.lookahead<=z){if(X(W),W.lookahead<=z&&Y===p)return v;if(W.lookahead===0)break}if(W.match_length=0,W.lookahead>=M&&0<W.strstart&&(Q=vt[dt=W.strstart-1])===vt[++dt]&&Q===vt[++dt]&&Q===vt[++dt]){kt=W.strstart+z;do;while(Q===vt[++dt]&&Q===vt[++dt]&&Q===vt[++dt]&&Q===vt[++dt]&&Q===vt[++dt]&&Q===vt[++dt]&&Q===vt[++dt]&&Q===vt[++dt]&&dt<kt);W.match_length=z-(kt-dt),W.match_length>W.lookahead&&(W.match_length=W.lookahead)}if(W.match_length>=M?(it=s._tr_tally(W,1,W.match_length-M),W.lookahead-=W.match_length,W.strstart+=W.match_length,W.match_length=0):(it=s._tr_tally(W,0,W.window[W.strstart]),W.lookahead--,W.strstart++),it&&(U(W,!1),W.strm.avail_out===0))return v}return W.insert=0,Y===g?(U(W,!0),W.strm.avail_out===0?G:F):W.last_lit&&(U(W,!1),W.strm.avail_out===0)?v:P})($,j):r[$.level].func($,j);if(K!==G&&K!==F||($.status=666),K===v||K===G)return f.avail_out===0&&($.last_flush=-1),u;if(K===P&&(j===1?s._tr_align($):j!==5&&(s._tr_stored_block($,0,0,!1),j===3&&(V($.head),$.lookahead===0&&($.strstart=0,$.block_start=0,$.insert=0))),R(f),f.avail_out===0))return $.last_flush=-1,u}return j!==g?u:$.wrap<=0?1:($.wrap===2?(at($,255&f.adler),at($,f.adler>>8&255),at($,f.adler>>16&255),at($,f.adler>>24&255),at($,255&f.total_in),at($,f.total_in>>8&255),at($,f.total_in>>16&255),at($,f.total_in>>24&255)):(rt($,f.adler>>>16),rt($,65535&f.adler)),R(f),0<$.wrap&&($.wrap=-$.wrap),$.pending!==0?u:1)},o.deflateEnd=function(f){var j;return f&&f.state?(j=f.state.status)!==E&&j!==69&&j!==73&&j!==91&&j!==103&&j!==A&&j!==666?et(f,w):(f.state=null,j===A?et(f,-3):u):w},o.deflateSetDictionary=function(f,j){var O,$,I,L,q,K,W,Y,it=j.length;if(!f||!f.state||(L=(O=f.state).wrap)===2||L===1&&O.status!==E||O.lookahead)return w;for(L===1&&(f.adler=a(f.adler,j,it,0)),O.wrap=0,it>=O.w_size&&(L===0&&(V(O.head),O.strstart=0,O.block_start=0,O.insert=0),Y=new l.Buf8(O.w_size),l.arraySet(Y,j,it-O.w_size,O.w_size,0),j=Y,it=O.w_size),q=f.avail_in,K=f.next_in,W=f.input,f.avail_in=it,f.next_in=0,f.input=j,X(O);O.lookahead>=M;){for($=O.strstart,I=O.lookahead-(M-1);O.ins_h=(O.ins_h<<O.hash_shift^O.window[$+M-1])&O.hash_mask,O.prev[$&O.w_mask]=O.head[O.ins_h],O.head[O.ins_h]=$,$++,--I;);O.strstart=$,O.lookahead=M-1,X(O)}return O.strstart+=O.lookahead,O.block_start=O.strstart,O.insert=O.lookahead,O.lookahead=0,O.match_length=O.prev_length=M-1,O.match_available=0,f.next_in=K,f.input=W,f.avail_in=q,O.wrap=L,u},o.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(e,n,o){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(e,n,o){n.exports=function(r,l){var s,a,c,d,p,g,u,w,h,k,b,y,S,T,x,_,C,D,M,z,J,E,A,v,P;s=r.state,a=r.next_in,v=r.input,c=a+(r.avail_in-5),d=r.next_out,P=r.output,p=d-(l-r.avail_out),g=d+(r.avail_out-257),u=s.dmax,w=s.wsize,h=s.whave,k=s.wnext,b=s.window,y=s.hold,S=s.bits,T=s.lencode,x=s.distcode,_=(1<<s.lenbits)-1,C=(1<<s.distbits)-1;t:do{S<15&&(y+=v[a++]<<S,S+=8,y+=v[a++]<<S,S+=8),D=T[y&_];e:for(;;){if(y>>>=M=D>>>24,S-=M,(M=D>>>16&255)===0)P[d++]=65535&D;else{if(!(16&M)){if((64&M)==0){D=T[(65535&D)+(y&(1<<M)-1)];continue e}if(32&M){s.mode=12;break t}r.msg="invalid literal/length code",s.mode=30;break t}z=65535&D,(M&=15)&&(S<M&&(y+=v[a++]<<S,S+=8),z+=y&(1<<M)-1,y>>>=M,S-=M),S<15&&(y+=v[a++]<<S,S+=8,y+=v[a++]<<S,S+=8),D=x[y&C];i:for(;;){if(y>>>=M=D>>>24,S-=M,!(16&(M=D>>>16&255))){if((64&M)==0){D=x[(65535&D)+(y&(1<<M)-1)];continue i}r.msg="invalid distance code",s.mode=30;break t}if(J=65535&D,S<(M&=15)&&(y+=v[a++]<<S,(S+=8)<M&&(y+=v[a++]<<S,S+=8)),u<(J+=y&(1<<M)-1)){r.msg="invalid distance too far back",s.mode=30;break t}if(y>>>=M,S-=M,(M=d-p)<J){if(h<(M=J-M)&&s.sane){r.msg="invalid distance too far back",s.mode=30;break t}if(A=b,(E=0)===k){if(E+=w-M,M<z){for(z-=M;P[d++]=b[E++],--M;);E=d-J,A=P}}else if(k<M){if(E+=w+k-M,(M-=k)<z){for(z-=M;P[d++]=b[E++],--M;);if(E=0,k<z){for(z-=M=k;P[d++]=b[E++],--M;);E=d-J,A=P}}}else if(E+=k-M,M<z){for(z-=M;P[d++]=b[E++],--M;);E=d-J,A=P}for(;2<z;)P[d++]=A[E++],P[d++]=A[E++],P[d++]=A[E++],z-=3;z&&(P[d++]=A[E++],1<z&&(P[d++]=A[E++]))}else{for(E=d-J;P[d++]=P[E++],P[d++]=P[E++],P[d++]=P[E++],2<(z-=3););z&&(P[d++]=P[E++],1<z&&(P[d++]=P[E++]))}break}}break}}while(a<c&&d<g);a-=z=S>>3,y&=(1<<(S-=z<<3))-1,r.next_in=a,r.next_out=d,r.avail_in=a<c?c-a+5:5-(a-c),r.avail_out=d<g?g-d+257:257-(d-g),s.hold=y,s.bits=S}},{}],49:[function(e,n,o){var r=e("../utils/common"),l=e("./adler32"),s=e("./crc32"),a=e("./inffast"),c=e("./inftrees"),d=1,p=2,g=0,u=-2,w=1,h=852,k=592;function b(E){return(E>>>24&255)+(E>>>8&65280)+((65280&E)<<8)+((255&E)<<24)}function y(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new r.Buf16(320),this.work=new r.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function S(E){var A;return E&&E.state?(A=E.state,E.total_in=E.total_out=A.total=0,E.msg="",A.wrap&&(E.adler=1&A.wrap),A.mode=w,A.last=0,A.havedict=0,A.dmax=32768,A.head=null,A.hold=0,A.bits=0,A.lencode=A.lendyn=new r.Buf32(h),A.distcode=A.distdyn=new r.Buf32(k),A.sane=1,A.back=-1,g):u}function T(E){var A;return E&&E.state?((A=E.state).wsize=0,A.whave=0,A.wnext=0,S(E)):u}function x(E,A){var v,P;return E&&E.state?(P=E.state,A<0?(v=0,A=-A):(v=1+(A>>4),A<48&&(A&=15)),A&&(A<8||15<A)?u:(P.window!==null&&P.wbits!==A&&(P.window=null),P.wrap=v,P.wbits=A,T(E))):u}function _(E,A){var v,P;return E?(P=new y,(E.state=P).window=null,(v=x(E,A))!==g&&(E.state=null),v):u}var C,D,M=!0;function z(E){if(M){var A;for(C=new r.Buf32(512),D=new r.Buf32(32),A=0;A<144;)E.lens[A++]=8;for(;A<256;)E.lens[A++]=9;for(;A<280;)E.lens[A++]=7;for(;A<288;)E.lens[A++]=8;for(c(d,E.lens,0,288,C,0,E.work,{bits:9}),A=0;A<32;)E.lens[A++]=5;c(p,E.lens,0,32,D,0,E.work,{bits:5}),M=!1}E.lencode=C,E.lenbits=9,E.distcode=D,E.distbits=5}function J(E,A,v,P){var G,F=E.state;return F.window===null&&(F.wsize=1<<F.wbits,F.wnext=0,F.whave=0,F.window=new r.Buf8(F.wsize)),P>=F.wsize?(r.arraySet(F.window,A,v-F.wsize,F.wsize,0),F.wnext=0,F.whave=F.wsize):(P<(G=F.wsize-F.wnext)&&(G=P),r.arraySet(F.window,A,v-P,G,F.wnext),(P-=G)?(r.arraySet(F.window,A,v-P,P,0),F.wnext=P,F.whave=F.wsize):(F.wnext+=G,F.wnext===F.wsize&&(F.wnext=0),F.whave<F.wsize&&(F.whave+=G))),0}o.inflateReset=T,o.inflateReset2=x,o.inflateResetKeep=S,o.inflateInit=function(E){return _(E,15)},o.inflateInit2=_,o.inflate=function(E,A){var v,P,G,F,et,H,V,R,U,at,rt,st,X,pt,mt,Z,ot,ct,B,N,f,j,O,$,I=0,L=new r.Buf8(4),q=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!E||!E.state||!E.output||!E.input&&E.avail_in!==0)return u;(v=E.state).mode===12&&(v.mode=13),et=E.next_out,G=E.output,V=E.avail_out,F=E.next_in,P=E.input,H=E.avail_in,R=v.hold,U=v.bits,at=H,rt=V,j=g;t:for(;;)switch(v.mode){case w:if(v.wrap===0){v.mode=13;break}for(;U<16;){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}if(2&v.wrap&&R===35615){L[v.check=0]=255&R,L[1]=R>>>8&255,v.check=s(v.check,L,2,0),U=R=0,v.mode=2;break}if(v.flags=0,v.head&&(v.head.done=!1),!(1&v.wrap)||(((255&R)<<8)+(R>>8))%31){E.msg="incorrect header check",v.mode=30;break}if((15&R)!=8){E.msg="unknown compression method",v.mode=30;break}if(U-=4,f=8+(15&(R>>>=4)),v.wbits===0)v.wbits=f;else if(f>v.wbits){E.msg="invalid window size",v.mode=30;break}v.dmax=1<<f,E.adler=v.check=1,v.mode=512&R?10:12,U=R=0;break;case 2:for(;U<16;){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}if(v.flags=R,(255&v.flags)!=8){E.msg="unknown compression method",v.mode=30;break}if(57344&v.flags){E.msg="unknown header flags set",v.mode=30;break}v.head&&(v.head.text=R>>8&1),512&v.flags&&(L[0]=255&R,L[1]=R>>>8&255,v.check=s(v.check,L,2,0)),U=R=0,v.mode=3;case 3:for(;U<32;){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}v.head&&(v.head.time=R),512&v.flags&&(L[0]=255&R,L[1]=R>>>8&255,L[2]=R>>>16&255,L[3]=R>>>24&255,v.check=s(v.check,L,4,0)),U=R=0,v.mode=4;case 4:for(;U<16;){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}v.head&&(v.head.xflags=255&R,v.head.os=R>>8),512&v.flags&&(L[0]=255&R,L[1]=R>>>8&255,v.check=s(v.check,L,2,0)),U=R=0,v.mode=5;case 5:if(1024&v.flags){for(;U<16;){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}v.length=R,v.head&&(v.head.extra_len=R),512&v.flags&&(L[0]=255&R,L[1]=R>>>8&255,v.check=s(v.check,L,2,0)),U=R=0}else v.head&&(v.head.extra=null);v.mode=6;case 6:if(1024&v.flags&&(H<(st=v.length)&&(st=H),st&&(v.head&&(f=v.head.extra_len-v.length,v.head.extra||(v.head.extra=new Array(v.head.extra_len)),r.arraySet(v.head.extra,P,F,st,f)),512&v.flags&&(v.check=s(v.check,P,st,F)),H-=st,F+=st,v.length-=st),v.length))break t;v.length=0,v.mode=7;case 7:if(2048&v.flags){if(H===0)break t;for(st=0;f=P[F+st++],v.head&&f&&v.length<65536&&(v.head.name+=String.fromCharCode(f)),f&&st<H;);if(512&v.flags&&(v.check=s(v.check,P,st,F)),H-=st,F+=st,f)break t}else v.head&&(v.head.name=null);v.length=0,v.mode=8;case 8:if(4096&v.flags){if(H===0)break t;for(st=0;f=P[F+st++],v.head&&f&&v.length<65536&&(v.head.comment+=String.fromCharCode(f)),f&&st<H;);if(512&v.flags&&(v.check=s(v.check,P,st,F)),H-=st,F+=st,f)break t}else v.head&&(v.head.comment=null);v.mode=9;case 9:if(512&v.flags){for(;U<16;){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}if(R!==(65535&v.check)){E.msg="header crc mismatch",v.mode=30;break}U=R=0}v.head&&(v.head.hcrc=v.flags>>9&1,v.head.done=!0),E.adler=v.check=0,v.mode=12;break;case 10:for(;U<32;){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}E.adler=v.check=b(R),U=R=0,v.mode=11;case 11:if(v.havedict===0)return E.next_out=et,E.avail_out=V,E.next_in=F,E.avail_in=H,v.hold=R,v.bits=U,2;E.adler=v.check=1,v.mode=12;case 12:if(A===5||A===6)break t;case 13:if(v.last){R>>>=7&U,U-=7&U,v.mode=27;break}for(;U<3;){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}switch(v.last=1&R,U-=1,3&(R>>>=1)){case 0:v.mode=14;break;case 1:if(z(v),v.mode=20,A!==6)break;R>>>=2,U-=2;break t;case 2:v.mode=17;break;case 3:E.msg="invalid block type",v.mode=30}R>>>=2,U-=2;break;case 14:for(R>>>=7&U,U-=7&U;U<32;){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}if((65535&R)!=(R>>>16^65535)){E.msg="invalid stored block lengths",v.mode=30;break}if(v.length=65535&R,U=R=0,v.mode=15,A===6)break t;case 15:v.mode=16;case 16:if(st=v.length){if(H<st&&(st=H),V<st&&(st=V),st===0)break t;r.arraySet(G,P,F,st,et),H-=st,F+=st,V-=st,et+=st,v.length-=st;break}v.mode=12;break;case 17:for(;U<14;){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}if(v.nlen=257+(31&R),R>>>=5,U-=5,v.ndist=1+(31&R),R>>>=5,U-=5,v.ncode=4+(15&R),R>>>=4,U-=4,286<v.nlen||30<v.ndist){E.msg="too many length or distance symbols",v.mode=30;break}v.have=0,v.mode=18;case 18:for(;v.have<v.ncode;){for(;U<3;){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}v.lens[q[v.have++]]=7&R,R>>>=3,U-=3}for(;v.have<19;)v.lens[q[v.have++]]=0;if(v.lencode=v.lendyn,v.lenbits=7,O={bits:v.lenbits},j=c(0,v.lens,0,19,v.lencode,0,v.work,O),v.lenbits=O.bits,j){E.msg="invalid code lengths set",v.mode=30;break}v.have=0,v.mode=19;case 19:for(;v.have<v.nlen+v.ndist;){for(;Z=(I=v.lencode[R&(1<<v.lenbits)-1])>>>16&255,ot=65535&I,!((mt=I>>>24)<=U);){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}if(ot<16)R>>>=mt,U-=mt,v.lens[v.have++]=ot;else{if(ot===16){for($=mt+2;U<$;){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}if(R>>>=mt,U-=mt,v.have===0){E.msg="invalid bit length repeat",v.mode=30;break}f=v.lens[v.have-1],st=3+(3&R),R>>>=2,U-=2}else if(ot===17){for($=mt+3;U<$;){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}U-=mt,f=0,st=3+(7&(R>>>=mt)),R>>>=3,U-=3}else{for($=mt+7;U<$;){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}U-=mt,f=0,st=11+(127&(R>>>=mt)),R>>>=7,U-=7}if(v.have+st>v.nlen+v.ndist){E.msg="invalid bit length repeat",v.mode=30;break}for(;st--;)v.lens[v.have++]=f}}if(v.mode===30)break;if(v.lens[256]===0){E.msg="invalid code -- missing end-of-block",v.mode=30;break}if(v.lenbits=9,O={bits:v.lenbits},j=c(d,v.lens,0,v.nlen,v.lencode,0,v.work,O),v.lenbits=O.bits,j){E.msg="invalid literal/lengths set",v.mode=30;break}if(v.distbits=6,v.distcode=v.distdyn,O={bits:v.distbits},j=c(p,v.lens,v.nlen,v.ndist,v.distcode,0,v.work,O),v.distbits=O.bits,j){E.msg="invalid distances set",v.mode=30;break}if(v.mode=20,A===6)break t;case 20:v.mode=21;case 21:if(6<=H&&258<=V){E.next_out=et,E.avail_out=V,E.next_in=F,E.avail_in=H,v.hold=R,v.bits=U,a(E,rt),et=E.next_out,G=E.output,V=E.avail_out,F=E.next_in,P=E.input,H=E.avail_in,R=v.hold,U=v.bits,v.mode===12&&(v.back=-1);break}for(v.back=0;Z=(I=v.lencode[R&(1<<v.lenbits)-1])>>>16&255,ot=65535&I,!((mt=I>>>24)<=U);){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}if(Z&&(240&Z)==0){for(ct=mt,B=Z,N=ot;Z=(I=v.lencode[N+((R&(1<<ct+B)-1)>>ct)])>>>16&255,ot=65535&I,!(ct+(mt=I>>>24)<=U);){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}R>>>=ct,U-=ct,v.back+=ct}if(R>>>=mt,U-=mt,v.back+=mt,v.length=ot,Z===0){v.mode=26;break}if(32&Z){v.back=-1,v.mode=12;break}if(64&Z){E.msg="invalid literal/length code",v.mode=30;break}v.extra=15&Z,v.mode=22;case 22:if(v.extra){for($=v.extra;U<$;){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}v.length+=R&(1<<v.extra)-1,R>>>=v.extra,U-=v.extra,v.back+=v.extra}v.was=v.length,v.mode=23;case 23:for(;Z=(I=v.distcode[R&(1<<v.distbits)-1])>>>16&255,ot=65535&I,!((mt=I>>>24)<=U);){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}if((240&Z)==0){for(ct=mt,B=Z,N=ot;Z=(I=v.distcode[N+((R&(1<<ct+B)-1)>>ct)])>>>16&255,ot=65535&I,!(ct+(mt=I>>>24)<=U);){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}R>>>=ct,U-=ct,v.back+=ct}if(R>>>=mt,U-=mt,v.back+=mt,64&Z){E.msg="invalid distance code",v.mode=30;break}v.offset=ot,v.extra=15&Z,v.mode=24;case 24:if(v.extra){for($=v.extra;U<$;){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}v.offset+=R&(1<<v.extra)-1,R>>>=v.extra,U-=v.extra,v.back+=v.extra}if(v.offset>v.dmax){E.msg="invalid distance too far back",v.mode=30;break}v.mode=25;case 25:if(V===0)break t;if(st=rt-V,v.offset>st){if((st=v.offset-st)>v.whave&&v.sane){E.msg="invalid distance too far back",v.mode=30;break}X=st>v.wnext?(st-=v.wnext,v.wsize-st):v.wnext-st,st>v.length&&(st=v.length),pt=v.window}else pt=G,X=et-v.offset,st=v.length;for(V<st&&(st=V),V-=st,v.length-=st;G[et++]=pt[X++],--st;);v.length===0&&(v.mode=21);break;case 26:if(V===0)break t;G[et++]=v.length,V--,v.mode=21;break;case 27:if(v.wrap){for(;U<32;){if(H===0)break t;H--,R|=P[F++]<<U,U+=8}if(rt-=V,E.total_out+=rt,v.total+=rt,rt&&(E.adler=v.check=v.flags?s(v.check,G,rt,et-rt):l(v.check,G,rt,et-rt)),rt=V,(v.flags?R:b(R))!==v.check){E.msg="incorrect data check",v.mode=30;break}U=R=0}v.mode=28;case 28:if(v.wrap&&v.flags){for(;U<32;){if(H===0)break t;H--,R+=P[F++]<<U,U+=8}if(R!==(4294967295&v.total)){E.msg="incorrect length check",v.mode=30;break}U=R=0}v.mode=29;case 29:j=1;break t;case 30:j=-3;break t;case 31:return-4;case 32:default:return u}return E.next_out=et,E.avail_out=V,E.next_in=F,E.avail_in=H,v.hold=R,v.bits=U,(v.wsize||rt!==E.avail_out&&v.mode<30&&(v.mode<27||A!==4))&&J(E,E.output,E.next_out,rt-E.avail_out)?(v.mode=31,-4):(at-=E.avail_in,rt-=E.avail_out,E.total_in+=at,E.total_out+=rt,v.total+=rt,v.wrap&&rt&&(E.adler=v.check=v.flags?s(v.check,G,rt,E.next_out-rt):l(v.check,G,rt,E.next_out-rt)),E.data_type=v.bits+(v.last?64:0)+(v.mode===12?128:0)+(v.mode===20||v.mode===15?256:0),(at==0&&rt===0||A===4)&&j===g&&(j=-5),j)},o.inflateEnd=function(E){if(!E||!E.state)return u;var A=E.state;return A.window&&(A.window=null),E.state=null,g},o.inflateGetHeader=function(E,A){var v;return E&&E.state?(2&(v=E.state).wrap)==0?u:((v.head=A).done=!1,g):u},o.inflateSetDictionary=function(E,A){var v,P=A.length;return E&&E.state?(v=E.state).wrap!==0&&v.mode!==11?u:v.mode===11&&l(1,A,P,0)!==v.check?-3:J(E,A,P,P)?(v.mode=31,-4):(v.havedict=1,g):u},o.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(e,n,o){var r=e("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],s=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(d,p,g,u,w,h,k,b){var y,S,T,x,_,C,D,M,z,J=b.bits,E=0,A=0,v=0,P=0,G=0,F=0,et=0,H=0,V=0,R=0,U=null,at=0,rt=new r.Buf16(16),st=new r.Buf16(16),X=null,pt=0;for(E=0;E<=15;E++)rt[E]=0;for(A=0;A<u;A++)rt[p[g+A]]++;for(G=J,P=15;1<=P&&rt[P]===0;P--);if(P<G&&(G=P),P===0)return w[h++]=20971520,w[h++]=20971520,b.bits=1,0;for(v=1;v<P&&rt[v]===0;v++);for(G<v&&(G=v),E=H=1;E<=15;E++)if(H<<=1,(H-=rt[E])<0)return-1;if(0<H&&(d===0||P!==1))return-1;for(st[1]=0,E=1;E<15;E++)st[E+1]=st[E]+rt[E];for(A=0;A<u;A++)p[g+A]!==0&&(k[st[p[g+A]]++]=A);if(C=d===0?(U=X=k,19):d===1?(U=l,at-=257,X=s,pt-=257,256):(U=a,X=c,-1),E=v,_=h,et=A=R=0,T=-1,x=(V=1<<(F=G))-1,d===1&&852<V||d===2&&592<V)return 1;for(;;){for(D=E-et,z=k[A]<C?(M=0,k[A]):k[A]>C?(M=X[pt+k[A]],U[at+k[A]]):(M=96,0),y=1<<E-et,v=S=1<<F;w[_+(R>>et)+(S-=y)]=D<<24|M<<16|z|0,S!==0;);for(y=1<<E-1;R&y;)y>>=1;if(y!==0?(R&=y-1,R+=y):R=0,A++,--rt[E]==0){if(E===P)break;E=p[g+k[A]]}if(G<E&&(R&x)!==T){for(et===0&&(et=G),_+=v,H=1<<(F=E-et);F+et<P&&!((H-=rt[F+et])<=0);)F++,H<<=1;if(V+=1<<F,d===1&&852<V||d===2&&592<V)return 1;w[T=R&x]=G<<24|F<<16|_-h|0}}return R!==0&&(w[_+R]=E-et<<24|64<<16|0),b.bits=G,0}},{"../utils/common":41}],51:[function(e,n,o){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(e,n,o){var r=e("../utils/common"),l=0,s=1;function a(I){for(var L=I.length;0<=--L;)I[L]=0}var c=0,d=29,p=256,g=p+1+d,u=30,w=19,h=2*g+1,k=15,b=16,y=7,S=256,T=16,x=17,_=18,C=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],D=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],M=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],z=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],J=new Array(2*(g+2));a(J);var E=new Array(2*u);a(E);var A=new Array(512);a(A);var v=new Array(256);a(v);var P=new Array(d);a(P);var G,F,et,H=new Array(u);function V(I,L,q,K,W){this.static_tree=I,this.extra_bits=L,this.extra_base=q,this.elems=K,this.max_length=W,this.has_stree=I&&I.length}function R(I,L){this.dyn_tree=I,this.max_code=0,this.stat_desc=L}function U(I){return I<256?A[I]:A[256+(I>>>7)]}function at(I,L){I.pending_buf[I.pending++]=255&L,I.pending_buf[I.pending++]=L>>>8&255}function rt(I,L,q){I.bi_valid>b-q?(I.bi_buf|=L<<I.bi_valid&65535,at(I,I.bi_buf),I.bi_buf=L>>b-I.bi_valid,I.bi_valid+=q-b):(I.bi_buf|=L<<I.bi_valid&65535,I.bi_valid+=q)}function st(I,L,q){rt(I,q[2*L],q[2*L+1])}function X(I,L){for(var q=0;q|=1&I,I>>>=1,q<<=1,0<--L;);return q>>>1}function pt(I,L,q){var K,W,Y=new Array(k+1),it=0;for(K=1;K<=k;K++)Y[K]=it=it+q[K-1]<<1;for(W=0;W<=L;W++){var Q=I[2*W+1];Q!==0&&(I[2*W]=X(Y[Q]++,Q))}}function mt(I){var L;for(L=0;L<g;L++)I.dyn_ltree[2*L]=0;for(L=0;L<u;L++)I.dyn_dtree[2*L]=0;for(L=0;L<w;L++)I.bl_tree[2*L]=0;I.dyn_ltree[2*S]=1,I.opt_len=I.static_len=0,I.last_lit=I.matches=0}function Z(I){8<I.bi_valid?at(I,I.bi_buf):0<I.bi_valid&&(I.pending_buf[I.pending++]=I.bi_buf),I.bi_buf=0,I.bi_valid=0}function ot(I,L,q,K){var W=2*L,Y=2*q;return I[W]<I[Y]||I[W]===I[Y]&&K[L]<=K[q]}function ct(I,L,q){for(var K=I.heap[q],W=q<<1;W<=I.heap_len&&(W<I.heap_len&&ot(L,I.heap[W+1],I.heap[W],I.depth)&&W++,!ot(L,K,I.heap[W],I.depth));)I.heap[q]=I.heap[W],q=W,W<<=1;I.heap[q]=K}function B(I,L,q){var K,W,Y,it,Q=0;if(I.last_lit!==0)for(;K=I.pending_buf[I.d_buf+2*Q]<<8|I.pending_buf[I.d_buf+2*Q+1],W=I.pending_buf[I.l_buf+Q],Q++,K===0?st(I,W,L):(st(I,(Y=v[W])+p+1,L),(it=C[Y])!==0&&rt(I,W-=P[Y],it),st(I,Y=U(--K),q),(it=D[Y])!==0&&rt(I,K-=H[Y],it)),Q<I.last_lit;);st(I,S,L)}function N(I,L){var q,K,W,Y=L.dyn_tree,it=L.stat_desc.static_tree,Q=L.stat_desc.has_stree,dt=L.stat_desc.elems,kt=-1;for(I.heap_len=0,I.heap_max=h,q=0;q<dt;q++)Y[2*q]!==0?(I.heap[++I.heap_len]=kt=q,I.depth[q]=0):Y[2*q+1]=0;for(;I.heap_len<2;)Y[2*(W=I.heap[++I.heap_len]=kt<2?++kt:0)]=1,I.depth[W]=0,I.opt_len--,Q&&(I.static_len-=it[2*W+1]);for(L.max_code=kt,q=I.heap_len>>1;1<=q;q--)ct(I,Y,q);for(W=dt;q=I.heap[1],I.heap[1]=I.heap[I.heap_len--],ct(I,Y,1),K=I.heap[1],I.heap[--I.heap_max]=q,I.heap[--I.heap_max]=K,Y[2*W]=Y[2*q]+Y[2*K],I.depth[W]=(I.depth[q]>=I.depth[K]?I.depth[q]:I.depth[K])+1,Y[2*q+1]=Y[2*K+1]=W,I.heap[1]=W++,ct(I,Y,1),2<=I.heap_len;);I.heap[--I.heap_max]=I.heap[1],(function(vt,At){var Ht,Wt,Zt,Dt,je,Gt,Vt=At.dyn_tree,ii=At.max_code,Ii=At.stat_desc.static_tree,vo=At.stat_desc.has_stree,bo=At.stat_desc.extra_bits,In=At.stat_desc.extra_base,di=At.stat_desc.max_length,Ai=0;for(Dt=0;Dt<=k;Dt++)vt.bl_count[Dt]=0;for(Vt[2*vt.heap[vt.heap_max]+1]=0,Ht=vt.heap_max+1;Ht<h;Ht++)di<(Dt=Vt[2*Vt[2*(Wt=vt.heap[Ht])+1]+1]+1)&&(Dt=di,Ai++),Vt[2*Wt+1]=Dt,ii<Wt||(vt.bl_count[Dt]++,je=0,In<=Wt&&(je=bo[Wt-In]),Gt=Vt[2*Wt],vt.opt_len+=Gt*(Dt+je),vo&&(vt.static_len+=Gt*(Ii[2*Wt+1]+je)));if(Ai!==0){do{for(Dt=di-1;vt.bl_count[Dt]===0;)Dt--;vt.bl_count[Dt]--,vt.bl_count[Dt+1]+=2,vt.bl_count[di]--,Ai-=2}while(0<Ai);for(Dt=di;Dt!==0;Dt--)for(Wt=vt.bl_count[Dt];Wt!==0;)ii<(Zt=vt.heap[--Ht])||(Vt[2*Zt+1]!==Dt&&(vt.opt_len+=(Dt-Vt[2*Zt+1])*Vt[2*Zt],Vt[2*Zt+1]=Dt),Wt--)}})(I,L),pt(Y,kt,I.bl_count)}function f(I,L,q){var K,W,Y=-1,it=L[1],Q=0,dt=7,kt=4;for(it===0&&(dt=138,kt=3),L[2*(q+1)+1]=65535,K=0;K<=q;K++)W=it,it=L[2*(K+1)+1],++Q<dt&&W===it||(Q<kt?I.bl_tree[2*W]+=Q:W!==0?(W!==Y&&I.bl_tree[2*W]++,I.bl_tree[2*T]++):Q<=10?I.bl_tree[2*x]++:I.bl_tree[2*_]++,Y=W,kt=(Q=0)===it?(dt=138,3):W===it?(dt=6,3):(dt=7,4))}function j(I,L,q){var K,W,Y=-1,it=L[1],Q=0,dt=7,kt=4;for(it===0&&(dt=138,kt=3),K=0;K<=q;K++)if(W=it,it=L[2*(K+1)+1],!(++Q<dt&&W===it)){if(Q<kt)for(;st(I,W,I.bl_tree),--Q!=0;);else W!==0?(W!==Y&&(st(I,W,I.bl_tree),Q--),st(I,T,I.bl_tree),rt(I,Q-3,2)):Q<=10?(st(I,x,I.bl_tree),rt(I,Q-3,3)):(st(I,_,I.bl_tree),rt(I,Q-11,7));Y=W,kt=(Q=0)===it?(dt=138,3):W===it?(dt=6,3):(dt=7,4)}}a(H);var O=!1;function $(I,L,q,K){rt(I,(c<<1)+(K?1:0),3),(function(W,Y,it,Q){Z(W),at(W,it),at(W,~it),r.arraySet(W.pending_buf,W.window,Y,it,W.pending),W.pending+=it})(I,L,q)}o._tr_init=function(I){O||((function(){var L,q,K,W,Y,it=new Array(k+1);for(W=K=0;W<d-1;W++)for(P[W]=K,L=0;L<1<<C[W];L++)v[K++]=W;for(v[K-1]=W,W=Y=0;W<16;W++)for(H[W]=Y,L=0;L<1<<D[W];L++)A[Y++]=W;for(Y>>=7;W<u;W++)for(H[W]=Y<<7,L=0;L<1<<D[W]-7;L++)A[256+Y++]=W;for(q=0;q<=k;q++)it[q]=0;for(L=0;L<=143;)J[2*L+1]=8,L++,it[8]++;for(;L<=255;)J[2*L+1]=9,L++,it[9]++;for(;L<=279;)J[2*L+1]=7,L++,it[7]++;for(;L<=287;)J[2*L+1]=8,L++,it[8]++;for(pt(J,g+1,it),L=0;L<u;L++)E[2*L+1]=5,E[2*L]=X(L,5);G=new V(J,C,p+1,g,k),F=new V(E,D,0,u,k),et=new V(new Array(0),M,0,w,y)})(),O=!0),I.l_desc=new R(I.dyn_ltree,G),I.d_desc=new R(I.dyn_dtree,F),I.bl_desc=new R(I.bl_tree,et),I.bi_buf=0,I.bi_valid=0,mt(I)},o._tr_stored_block=$,o._tr_flush_block=function(I,L,q,K){var W,Y,it=0;0<I.level?(I.strm.data_type===2&&(I.strm.data_type=(function(Q){var dt,kt=4093624447;for(dt=0;dt<=31;dt++,kt>>>=1)if(1&kt&&Q.dyn_ltree[2*dt]!==0)return l;if(Q.dyn_ltree[18]!==0||Q.dyn_ltree[20]!==0||Q.dyn_ltree[26]!==0)return s;for(dt=32;dt<p;dt++)if(Q.dyn_ltree[2*dt]!==0)return s;return l})(I)),N(I,I.l_desc),N(I,I.d_desc),it=(function(Q){var dt;for(f(Q,Q.dyn_ltree,Q.l_desc.max_code),f(Q,Q.dyn_dtree,Q.d_desc.max_code),N(Q,Q.bl_desc),dt=w-1;3<=dt&&Q.bl_tree[2*z[dt]+1]===0;dt--);return Q.opt_len+=3*(dt+1)+5+5+4,dt})(I),W=I.opt_len+3+7>>>3,(Y=I.static_len+3+7>>>3)<=W&&(W=Y)):W=Y=q+5,q+4<=W&&L!==-1?$(I,L,q,K):I.strategy===4||Y===W?(rt(I,2+(K?1:0),3),B(I,J,E)):(rt(I,4+(K?1:0),3),(function(Q,dt,kt,vt){var At;for(rt(Q,dt-257,5),rt(Q,kt-1,5),rt(Q,vt-4,4),At=0;At<vt;At++)rt(Q,Q.bl_tree[2*z[At]+1],3);j(Q,Q.dyn_ltree,dt-1),j(Q,Q.dyn_dtree,kt-1)})(I,I.l_desc.max_code+1,I.d_desc.max_code+1,it+1),B(I,I.dyn_ltree,I.dyn_dtree)),mt(I),K&&Z(I)},o._tr_tally=function(I,L,q){return I.pending_buf[I.d_buf+2*I.last_lit]=L>>>8&255,I.pending_buf[I.d_buf+2*I.last_lit+1]=255&L,I.pending_buf[I.l_buf+I.last_lit]=255&q,I.last_lit++,L===0?I.dyn_ltree[2*q]++:(I.matches++,L--,I.dyn_ltree[2*(v[q]+p+1)]++,I.dyn_dtree[2*U(L)]++),I.last_lit===I.lit_bufsize-1},o._tr_align=function(I){rt(I,2,3),st(I,S,J),(function(L){L.bi_valid===16?(at(L,L.bi_buf),L.bi_buf=0,L.bi_valid=0):8<=L.bi_valid&&(L.pending_buf[L.pending++]=255&L.bi_buf,L.bi_buf>>=8,L.bi_valid-=8)})(I)}},{"../utils/common":41}],53:[function(e,n,o){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(e,n,o){(function(r){(function(l,s){if(!l.setImmediate){var a,c,d,p,g=1,u={},w=!1,h=l.document,k=Object.getPrototypeOf&&Object.getPrototypeOf(l);k=k&&k.setTimeout?k:l,a={}.toString.call(l.process)==="[object process]"?function(T){process.nextTick(function(){y(T)})}:(function(){if(l.postMessage&&!l.importScripts){var T=!0,x=l.onmessage;return l.onmessage=function(){T=!1},l.postMessage("","*"),l.onmessage=x,T}})()?(p="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",S,!1):l.attachEvent("onmessage",S),function(T){l.postMessage(p+T,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(T){y(T.data)},function(T){d.port2.postMessage(T)}):h&&"onreadystatechange"in h.createElement("script")?(c=h.documentElement,function(T){var x=h.createElement("script");x.onreadystatechange=function(){y(T),x.onreadystatechange=null,c.removeChild(x),x=null},c.appendChild(x)}):function(T){setTimeout(y,0,T)},k.setImmediate=function(T){typeof T!="function"&&(T=new Function(""+T));for(var x=new Array(arguments.length-1),_=0;_<x.length;_++)x[_]=arguments[_+1];var C={callback:T,args:x};return u[g]=C,a(g),g++},k.clearImmediate=b}function b(T){delete u[T]}function y(T){if(w)setTimeout(y,0,T);else{var x=u[T];if(x){w=!0;try{(function(_){var C=_.callback,D=_.args;switch(D.length){case 0:C();break;case 1:C(D[0]);break;case 2:C(D[0],D[1]);break;case 3:C(D[0],D[1],D[2]);break;default:C.apply(s,D)}})(x)}finally{b(T),w=!1}}}}function S(T){T.source===l&&typeof T.data=="string"&&T.data.indexOf(p)===0&&y(+T.data.slice(p.length))}})(typeof self>"u"?r===void 0?this:r:self)}).call(this,typeof Ln<"u"?Ln:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Mo)),Mo.exports}var tv=Qg();const ev=Xg(tv),iv=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,nv=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function ov(t){const i=await ev.loadAsync(t),e={},n=[];let o="",r="";const l=[];i.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let s=l.find(a=>a.path.toLowerCase()==="slides.md");s||(s=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),s||(s=l.find(a=>a.path.toLowerCase().endsWith(".md"))),s&&(o=await s.file.async("string"),r=s.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||nv.test(c)||c.includes("snippets/")){const d=await a.file.async("string");e[c]=d;const p=c.split("/");p.length>1&&(e[p.slice(1).join("/")]=d)}else if(iv.test(c)){const d=await a.file.async("uint8array"),p=c.split("/").pop()||c,g=typeof Blob<"u"?new Blob([d]):void 0;n.push({zipPath:c,fileName:p,data:d,blob:g})}}return{entryMarkdown:o,entryMarkdownPath:r,virtualFiles:e,assets:n}}function sv(t,i){if(Object.keys(i).length===0)return t;function e(o){const r=o.trim().replace(/^['"]|['"]$/g,""),l=r.split("/").pop()||r;if(i[r])return i[r];const s=r.replace(/^\.?\//,"");return i[s]?i[s]:i[l]?i[l]:null}function n(o){let r=o;return r=r.replace(/!\[(.*?)\]\((.*?)\)/g,(l,s,a)=>{const c=e(a);return c?`![${s}](${c})`:l}),r=r.replace(/\bsrc=["'](.*?)["']/gi,(l,s)=>{const a=e(s);return a?`src="${a}"`:l}),r}for(const o of t.slides)if(o.rawMarkdown=n(o.rawMarkdown),o.pageAttrs["custom-slidev-background"]){const r=o.pageAttrs["custom-slidev-background"],l=e(r);l&&(o.pageAttrs["custom-slidev-background"]=l)}if(t.flattenedMarkdown=n(t.flattenedMarkdown),t.docRootAttrs["custom-slidev-background"]){const o=t.docRootAttrs["custom-slidev-background"],r=e(o);r&&(t.docRootAttrs["custom-slidev-background"]=r)}return t}function ql(t){try{if(typeof process<"u"&&typeof require<"u"){const i=require("fs");if(i.existsSync(t))return i.readFileSync(t,"utf-8")}}catch{}return null}function rv(t,i){const e=t.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!e)return null;const n=e[1].trim(),o=n.indexOf("#"),r=o!==-1?n.slice(0,o):n,l=o!==-1?n.slice(o+1):"",s=r.replace(/^@\//,"").replace(/^\.\//,""),a=(i==null?void 0:i.virtualFiles)||{};let c=a[r]||a[s]||a[`./${s}`]||a[`@/${s}`];if(!c&&Object.keys(a).length>0){const u=s.split("/").pop();for(const[w,h]of Object.entries(a))if(w.endsWith(`/${s}`)||u&&w.endsWith(`/${u}`)){c=h;break}}if(!c){const u=[];if(i!=null&&i.baseDir)try{const w=require("path");u.push(w.resolve(i.baseDir,s)),u.push(w.resolve(i.baseDir,r))}catch{}try{const w=require("path");u.push(w.resolve(process.cwd(),s))}catch{}for(const w of u){const h=ql(w);if(h!==null){c=h;break}}}if(!c){const u=zl||{};if(c=u[r]||u[s]||u[`snippets/${s}`],!c){const w=s.split("/").pop();for(const[h,k]of Object.entries(u))if(h.endsWith(`/${s}`)||w&&h.endsWith(`/${w}`)){c=k;break}}}if(!c)return null;let d=c;if(l){const u=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),w=c.match(u);if(w){const h=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(h?h[1]:"")+w[1].trimEnd()}}const p=s.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${p?p[1]:""}
${d}
\`\`\``}function lv(t){let i=!1,e=!1;for(let n=0;n<t.length;n++){const o=t[n];if(o==="'"&&!e)i=!i;else if(o==='"'&&!i)e=!e;else if(o==="#"&&!i&&!e)return t.slice(0,n).trim()}return t.trim()}function Nn(t){const i={},e=t.split(/\r?\n/);let n=0;for(;n<e.length;){const o=e[n],r=o.trim();if(!r||r.startsWith("#")){n++;continue}const l=o.indexOf(":");if(l>0){const s=o.slice(0,l).trim();let a=o.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let d=-1;for(;n<e.length;){const p=e[n];if(!p.trim()){c.push(""),n++;continue}const u=p.match(/^(\s+)/),w=u?u[1].length:0;if(d===-1&&(d=w),w<d)break;c.push(p.slice(d)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();i[s]=a===">"?c.join(" "):c.join(`
`);continue}if(a=lv(a),!a){let c=n+1;const d=[];let p=-1;for(;c<e.length;){const g=e[c],u=g.trim();if(!u||u.startsWith("#")){p!==-1&&d.push(""),c++;continue}const w=g.match(/^(\s+)/),h=w?w[1].length:0;if(p===-1)if(h>0)p=h;else break;if(h<p)break;d.push(g.slice(p)),c++}if(d.length>0){i[s]=Nn(d.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),i[s]=a}n++}return i}const av=/^\s*```ya?ml([\s\S]*?)```/;function hr(t){let i={},e=t.trim();const n=e.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const r=Nn(n[1]);if(Object.keys(r).length>0||!n[1].trim())return i=r,e=e.slice(n[0].length).trim(),{frontmatter:i,content:e}}if(e.startsWith("---")){const r=e.match(/^---[^\n\r]*(?:\r?\n|$)/);r&&(e=e.slice(r[0].length).trim())}const o=e.match(av);if(o)i=Nn(o[1]),e=e.slice(o[0].length).trim();else{const r=e.split(/\r?\n/),l=[];let s=0;for(let a=0;a<r.length;a++){const c=r[a].trim();if(!c){if(l.length>0){s=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{s=a;break}}l.length>0&&(i=Nn(l.join(`
`)),e=r.slice(s).join(`
`).trim())}return{frontmatter:i,content:e}}function cv(t){const i=t.split(/\r?\n/),e=[];let n=0,o=!1;function r(l){if(n>=l)return;const s=i.slice(n,l).join(`
`).trim();s&&e.push(s),n=l+1}for(let l=0;l<i.length;l++){const a=i[l].trimEnd();if(o){a.includes("-->")&&(o=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(o=!0);continue}if(a.startsWith("---")){r(l);const c=i[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<i.length&&i[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let p=l+1;for(;p<i.length&&!i[p].trimStart().startsWith(d);p++);p<i.length&&(l=p)}}return n<i.length&&r(i.length),e}function Fn(t,i={}){const{stripNotesFromMarkdown:e=!0,cleanVClicks:n=!0,cleanShikiLines:o=!0,cleanSlots:r=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:s=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=i;let d=t;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const p=cv(d),g={};let u="",w="",h=0;if(p.length>0){const z=p[0],J=hr(z),E=Object.keys(J.frontmatter).length>0,A=J.content.length>0;E&&!A&&p.length>1?(h=1,k(J.frontmatter)):E&&k(J.frontmatter)}function k(z){u=z.title||"",z.theme&&(g[un]=String(z.theme)),z.aspectRatio&&(g[fn]=String(z.aspectRatio)),z.highlighter&&(g[wr]=String(z.highlighter)),z.transition&&(g[pn]=String(z.transition)),z.colorSchema&&(g[xr]=String(z.colorSchema)),z.layout&&(g[ut]=String(z.layout)),z.background&&(g[zt]=String(z.background)),z.image&&(g[Se]=String(z.image)),z.class&&(g[Li]=String(z.class));for(const[J,E]of Object.entries(z))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(J)||(g[`custom-slidev-${J}`]=typeof E=="object"?JSON.stringify(E):String(E))}const b=[];let y=0,S=0,T=0,x=0;const _=new Set,C={};let D=1;for(let z=h;z<p.length;z++){const J=p[z],{frontmatter:E,content:A}=hr(J),v=J.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),P=E.src||(v?v[1]:void 0);if(P){const Z=String(P).trim().replace(/^['"]|['"]$/g,"");let ot=c[Z]||c[Z.replace(/^\.\//,"")]||c[`pages/${Z.replace(/^.*pages\//,"")}`];if(!ot){const B=Z.replace(/^\.\//,""),N=[];if(i.baseDir)try{const f=require("path");N.push(f.resolve(i.baseDir,B)),N.push(f.resolve(i.baseDir,Z))}catch{}try{const f=require("path");N.push(f.resolve(process.cwd(),B)),N.push(f.resolve(process.cwd(),Z))}catch{}for(const f of N){const j=ql(f);if(j!==null){ot=j;break}}}const ct={};E.layout&&(ct[ut]=String(E.layout)),E.transition&&(ct[Kt]=String(E.transition)),E.background&&(ct[zt]=String(E.background)),E.image&&(ct[Se]=String(E.image)),E.class&&(ct[Li]=String(E.class));for(const[B,N]of Object.entries(E))["src","layout","transition","background","image","class"].includes(B)||(ct[`custom-slidev-${B}`]=typeof N=="object"?JSON.stringify(N):String(N));if(ot){const B=Fn(ot,{...i,virtualFiles:c});for(const N of B.slides){N.pageIndex=D++,N.pageAttrs={...ct,...N.pageAttrs},b.push(N);const f=N.pageAttrs[ut]||"default";C[f]=(C[f]||0)+1}continue}else{b.push({pageIndex:D++,pageAttrs:{...ct,"custom-slidev-src":Z},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${Z}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const B=ct[ut]||"default";C[B]=(C[B]||0)+1;continue}}const G={};E.layout&&(G[ut]=String(E.layout)),E.transition&&(G[Kt]=String(E.transition)),E.background&&(G[zt]=String(E.background)),E.image&&(G[Se]=String(E.image)),E.class&&(G[Li]=String(E.class));for(const[Z,ot]of Object.entries(E))["layout","transition","background","image","class"].includes(Z)||(G[`custom-slidev-${Z}`]=typeof ot=="object"?JSON.stringify(ot):String(ot));let F=A;const et=[];let H=F.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,Z=>{const ot=`__CODE_TOKEN_NOTE_${et.length}__`;return et.push(Z),ot});H=H.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,Z=>{const ot=`__CODE_TOKEN_NOTE_${et.length}__`;return et.push(Z),ot});let V="";const R=Array.from(H.matchAll(/<!--([\s\S]*?)-->/g));if(R.length>0){const Z=R[R.length-1],ot=H.slice(Z.index+Z[0].length).trim();if(!ot||!ot.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const B=Z[1].trim();B.startsWith("TODO:")||(V=B,y++),e&&(H=H.slice(0,Z.index).trimEnd()+H.slice(Z.index+Z[0].length))}}e&&(H=H.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let Z=0;Z<et.length;Z++)H=H.replace(`__CODE_TOKEN_NOTE_${Z}__`,et[Z]);if(F=H,V){for(let ct=0;ct<et.length;ct++)V=V.replace(`__CODE_TOKEN_NOTE_${ct}__`,et[ct]);const ot=`> [!NOTE] 💡 演讲备注
${V.split(/\r?\n/).map(ct=>`> ${ct}`).join(`
`)}
{: custom-slidev-note="true"}`;F=F?`${F}

${ot}`:ot}let U=!1;if(/<style\b/i.test(F)){U=!0;const Z=F.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(Z){for(const ot of Z){const ct=ot.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();w=w?`${w}

${ct}`:ct}l&&(F=F.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const at=F.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);at&&(S+=at.length);const rt=F.match(/```\w+\s+\{[^}]+\}/g);rt&&(T+=rt.length);const st=F.match(/::\w+::|<template\s+#[^>]+>/g);if(st&&(x+=st.length),F=F.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,Z=>rv(Z,{...i,virtualFiles:c})||Z),n&&(F=F.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),o&&(F=F.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),F=F.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),r&&(F=F.replace(/^::\w+::\s*$/gm,"")),s&&(F=Pa(F)),a){let Z=F.trim(),ot="";const ct=Z.lastIndexOf("> [!NOTE] 💡 演讲备注");if(ct!==-1&&(ot=Z.slice(ct),Z=Z.slice(0,ct).trim()),(E.layout==="image-left"||E.layout==="image-right")&&E.image){const B=String(E.image).trim(),N=E.layout==="image-left"?"image-left":"image-right",f=`![配图](${B})
{: custom-slidev-layout="${N}" }`;E.layout==="image-left"?Z=`{{{col

${f}

${Z}

}}}`:Z=`{{{col

${Z}

${f}

}}}`}if(E.background){const N=`![背景图](${String(E.background).trim()})
{: custom-slidev-role="background" }`;Z=Z?`${N}

${Z}`:N}F=ot?`${Z}

${ot}`:Z}const X=dv(F);G[zt]&&X.push(G[zt]),G[Se]&&X.push(G[Se]);for(const Z of X)_.add(Z);const pt=/<[A-Z][a-zA-Z0-9]+/.test(F),mt=G[ut]||(D===1?g[ut]||"cover":"default");C[mt]=(C[mt]||0)+1,b.push({pageIndex:D++,pageAttrs:G,notes:V,rawMarkdown:F,hasVueComponent:pt,hasStyleTag:U,assetReferences:X})}if(!u&&b.length>0){const z=b[0].rawMarkdown.match(/^#\s+(.+)$/m);z&&(u=z[1].trim())}w&&(g["custom-slidev-custom-css"]=w);let M=b.map(z=>`---

${z.rawMarkdown}`).join(`

`);return M.trimStart().startsWith("---")||(M=`---

${M.trimStart()}`),{docTitle:u||"Slidev 演示文稿",docRootAttrs:g,slides:b,totalSlides:b.length,stats:{totalNotes:y,totalVClicks:S,totalShikiHighlights:T,totalSlots:x,discoveredAssets:Array.from(_),layoutDistribution:C},flattenedMarkdown:M,customCss:w}}function dv(t){const i=[],e=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=e.exec(t))!==null;){const r=n[1].split(/\s+/)[0].trim();r&&i.push(r)}const o=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=o.exec(t))!==null;){const r=n[1].trim();r&&i.push(r)}return i}const uv={class:"spm-import-dialog"},fv={class:"spm-tabs-header"},pv={class:"spm-dialog-body"},hv={key:0,class:"spm-file-section"},mv={key:0,class:"spm-dropzone-prompt"},gv={key:1,class:"spm-dropzone-active"},vv={class:"spm-file-badge"},bv={class:"spm-file-size"},yv={key:1,class:"spm-text-section"},kv={key:2,class:"spm-error-banner"},wv={key:3,class:"spm-preview-card"},xv={class:"spm-config-grid"},_v={class:"spm-form-item"},Sv={class:"spm-form-item"},Cv=["value"],$v={class:"spm-stats-grid"},Iv={class:"spm-stat-box"},Av={class:"spm-stat-value"},Tv={class:"spm-stat-box"},Ev={class:"spm-stat-value"},Bv={class:"spm-stat-box"},Mv={class:"spm-stat-value"},Dv={class:"spm-stat-box"},Lv={class:"spm-stat-value"},Ov={key:0,class:"spm-chips-row"},Pv={class:"spm-options-group"},Rv={class:"spm-checkbox-label"},zv={class:"spm-checkbox-label"},Nv={class:"spm-checkbox-label"},Fv={class:"spm-checkbox-label"},jv={class:"spm-dialog-footer"},Hv=["disabled"],Uv=["disabled"],Wv={key:0},Vv={key:1},Kv=he({__name:"SlidevImportDialog",emits:["close","success"],setup(t,{emit:i}){const e=i,n=Ge("plugin"),o=ht("file"),r=ht(!1),l=ht(!1),s=ht(""),a=ht(null),c=ht(null),d=ht(""),p=ht(0),g=ht(""),u=ht([]),w=ht(null),h=ht(""),k=ht([]),b=ht(""),y=ht(!0),S=ht(!0),T=ht(!0),x=ht(!0);async function _(){c.value?await P(c.value):g.value&&G()}const C=_t(()=>{const H=p.value;if(H===0)return"0 B";const V=1024,R=["B","KB","MB","GB"],U=Math.floor(Math.log(H)/Math.log(V));return`${(H/V**U).toFixed(1)} ${R[U]}`}),D=_t(()=>{var H;return((H=w.value)==null?void 0:H.docRootAttrs["custom-slidev-theme"])||"default"}),M=_t(()=>{var H;return u.value.length>0?u.value.length:((H=w.value)==null?void 0:H.stats.discoveredAssets.length)||0}),z=_t(()=>{var V;const H=((V=w.value)==null?void 0:V.stats.layoutDistribution)||{};return Object.entries(H).map(([R,U])=>({name:R,count:U}))});Sn(async()=>{try{const H=await ha();H!=null&&H.notebooks&&Array.isArray(H.notebooks)&&(k.value=H.notebooks.filter(V=>!V.closed),k.value.length>0&&(b.value=k.value[0].id))}catch(H){console.warn("获取笔记本列表失败:",H)}});function J(){var H;(H=a.value)==null||H.click()}function E(){c.value=null,d.value="",p.value=0,w.value=null,u.value=[],s.value=""}async function A(H){const V=H.target;V.files&&V.files[0]&&await P(V.files[0])}async function v(H){var V;r.value=!1,(V=H.dataTransfer)!=null&&V.files&&H.dataTransfer.files[0]&&await P(H.dataTransfer.files[0])}async function P(H){s.value="",c.value=H,d.value=H.name,p.value=H.size;try{if(H.name.toLowerCase().endsWith(".zip")){const R=await H.arrayBuffer(),U=await ov(R);if(!U.entryMarkdown){s.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=U.assets;const at=Fn(U.entryMarkdown,{stripNotesFromMarkdown:S.value,cleanHtmlToMarkdown:y.value,cleanSlots:!1,virtualFiles:U.virtualFiles});w.value=at,h.value=at.docTitle||H.name.replace(/\.zip$/i,"")}else{const R=await H.text();u.value=[];const U=H.path||"",at=U?U.replace(/[\\/][^\\/]+$/,""):"",rt=Fn(R,{stripNotesFromMarkdown:S.value,cleanHtmlToMarkdown:y.value,cleanSlots:!1,baseDir:at||void 0});w.value=rt,h.value=rt.docTitle||H.name.replace(/\.md$/i,"")}}catch(V){console.error("解析文件失败:",V),s.value=`解析文件失败: ${V.message||String(V)}`}}function G(){if(s.value="",!g.value.trim()){w.value=null;return}try{const H=Fn(g.value,{stripNotesFromMarkdown:S.value,cleanHtmlToMarkdown:y.value,cleanSlots:!1});w.value=H,h.value=H.docTitle||"Slidev 演示文稿"}catch(H){s.value=`解析 Markdown 源码失败: ${H.message||String(H)}`}}async function F(){var H;if(w.value){if(!b.value&&k.value.length>0&&(b.value=k.value[0].id),!b.value){s.value="请先选择目标笔记本";return}l.value=!0,s.value="";try{const V=w.value,R={};if(T.value&&u.value.length>0){const ot=[];for(const ct of u.value){const B=new File([ct.data],ct.fileName,{type:"application/octet-stream"});ot.push(B)}try{const ct=await ga("/data/assets",ot);if(ct!=null&&ct.succMap)for(const[B,N]of Object.entries(ct.succMap))R[B]=String(N)}catch(ct){console.warn("上传本地静态资产失败，保留原路径:",ct)}}Object.keys(R).length>0&&sv(V,R);const U=(h.value.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_"),at=`/${U}`,rt=await ma(b.value,at,V.flattenedMarkdown);if(!rt)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const st=((H=V.slides[0])==null?void 0:H.pageAttrs)||{};await Mt(rt,{...st,...V.docRootAttrs});const X=await Hn(rt).catch(()=>[]),pt=ot=>{if(!ot)return!1;const ct=String(ot.type||"").toLowerCase(),B=String(ot.markdown||"").trim(),N=String(ot.content||"").trim();return ct==="tb"||ct==="thematic-break"||ct==="nodethematicbreak"||B==="---"||B==="***"||N==="---"||N==="***"},mt=X.filter(pt);if(mt.length>=V.slides.length)for(let ot=0;ot<V.slides.length;ot++){const ct=V.slides[ot],B=mt[ot];B&&B.id&&Object.keys(ct.pageAttrs).length>0&&await Mt(B.id,ct.pageAttrs)}else for(let ot=1;ot<V.slides.length;ot++){const ct=V.slides[ot],B=mt[ot-1];B&&B.id&&Object.keys(ct.pageAttrs).length>0&&await Mt(B.id,ct.pageAttrs)}let Z=!1;for(const ot of X){if(pt(ot)){Z=!1;continue}const ct=(ot.markdown||ot.content||"").trim();if(ct==="::right::"||ct.startsWith("::right::")){Z=!0;continue}Z&&ot.id&&await Mt(ot.id,{[It]:"right"}).catch(()=>{})}gt.showMessage(`🎉 成功导入 Slidev 演示文档《${U}》！`),e("success",{docId:rt}),e("close"),x.value&&n&&(n.currentDocId=rt,await gt.openTab({app:n.app,doc:{id:rt}}),n.openBottomPreviewTab&&n.openBottomPreviewTab())}catch(V){console.error("导入 Slidev 演示失败:",V),s.value=`导入执行失败: ${V.message||String(V)}`}finally{l.value=!1}}}function et(){e("close")}return(H,V)=>(tt(),nt("div",{class:"spm-modal-overlay",onClick:Ce(et,["self"])},[m("div",uv,[m("div",{class:"spm-dialog-header"},[V[11]||(V[11]=m("div",{class:"spm-dialog-title"},[m("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[m("use",{"xlink:href":"#iconSlidev"})]),m("span",null,"导入 Slidev 演示文档")],-1)),m("button",{class:"spm-close-btn",title:"关闭",onClick:et},"✕")]),m("div",fv,[m("button",{class:Ct(["spm-tab-btn",{active:o.value==="file"}]),onClick:V[0]||(V[0]=R=>o.value="file")}," 📦 文件 / 压缩包导入 (.zip / .md) ",2),m("button",{class:Ct(["spm-tab-btn",{active:o.value==="text"}]),onClick:V[1]||(V[1]=R=>o.value="text")}," 📝 粘贴 Markdown 源码 ",2)]),m("div",pv,[o.value==="file"?(tt(),nt("div",hv,[m("div",{class:Ct(["spm-dropzone",{dragover:r.value,"has-file":!!d.value}]),onDragover:V[2]||(V[2]=Ce(R=>r.value=!0,["prevent"])),onDragleave:V[3]||(V[3]=Ce(R=>r.value=!1,["prevent"])),onDrop:Ce(v,["prevent"]),onClick:J},[m("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:A},null,544),d.value?(tt(),nt("div",gv,[m("span",vv,"📄 "+xt(d.value),1),m("span",bv,"("+xt(C.value)+")",1),m("button",{class:"spm-btn-text",onClick:Ce(E,["stop"])},"更换文件")])):(tt(),nt("div",mv,[...V[12]||(V[12]=[m("span",{class:"spm-dropzone-icon"},"📁",-1),m("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1),m("p",{class:"spm-dropzone-hint"},[Go(" 支持 Slidev 完整工程 "),m("strong",null,".zip"),Go("（自动解包 public/ 静态素材）或单文件 "),m("strong",null,".md")],-1)])]))],34)])):(tt(),nt("div",yv,[_e(m("textarea",{"onUpdate:modelValue":V[4]||(V[4]=R=>g.value=R),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:G},null,544),[[io,g.value]])])),s.value?(tt(),nt("div",kv," ⚠️ "+xt(s.value),1)):Ot("",!0),w.value?(tt(),nt("div",wv,[V[24]||(V[24]=m("div",{class:"spm-preview-card__header"},[m("span",null,"✨ 演示解析摘要"),m("span",{class:"spm-badge-success"},"预检就绪")],-1)),m("div",xv,[m("div",_v,[V[13]||(V[13]=m("label",{class:"spm-form-label"},"笔记文档标题",-1)),_e(m("input",{"onUpdate:modelValue":V[5]||(V[5]=R=>h.value=R),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[io,h.value]])]),m("div",Sv,[V[14]||(V[14]=m("label",{class:"spm-form-label"},"存放目标笔记本",-1)),_e(m("select",{"onUpdate:modelValue":V[6]||(V[6]=R=>b.value=R),class:"spm-select"},[(tt(!0),nt(Ut,null,ge(k.value,R=>(tt(),nt("option",{key:R.id,value:R.id},xt(R.name),9,Cv))),128))],512),[[lu,b.value]])])]),m("div",$v,[m("div",Iv,[m("span",Av,xt(w.value.totalSlides),1),V[15]||(V[15]=m("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),m("div",Tv,[m("span",Ev,xt(D.value),1),V[16]||(V[16]=m("span",{class:"spm-stat-label"},"演示主题",-1))]),m("div",Bv,[m("span",Mv,xt(w.value.stats.totalNotes),1),V[17]||(V[17]=m("span",{class:"spm-stat-label"},"演讲者提词",-1))]),m("div",Dv,[m("span",Lv,xt(M.value),1),V[18]||(V[18]=m("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),z.value.length>0?(tt(),nt("div",Ov,[V[19]||(V[19]=m("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(tt(!0),nt(Ut,null,ge(z.value,R=>(tt(),nt("span",{key:R.name,class:"spm-chip-badge"},xt(R.name)+": "+xt(R.count),1))),128))])):Ot("",!0),m("div",Pv,[m("label",Rv,[_e(m("input",{"onUpdate:modelValue":V[7]||(V[7]=R=>y.value=R),type:"checkbox",onChange:_},null,544),[[Dn,y.value]]),V[20]||(V[20]=m("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),m("label",zv,[_e(m("input",{"onUpdate:modelValue":V[8]||(V[8]=R=>S.value=R),type:"checkbox",onChange:_},null,544),[[Dn,S.value]]),V[21]||(V[21]=m("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),m("label",Nv,[_e(m("input",{"onUpdate:modelValue":V[9]||(V[9]=R=>T.value=R),type:"checkbox"},null,512),[[Dn,T.value]]),V[22]||(V[22]=m("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),m("label",Fv,[_e(m("input",{"onUpdate:modelValue":V[10]||(V[10]=R=>x.value=R),type:"checkbox"},null,512),[[Dn,x.value]]),V[23]||(V[23]=m("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Ot("",!0)]),m("div",jv,[m("button",{class:"spm-btn-secondary",disabled:l.value,onClick:et}," 取消 ",8,Hv),m("button",{class:"spm-btn-primary",disabled:!w.value||l.value,onClick:F},[l.value?(tt(),nt("span",Wv,"⏳ 正在导入生成中...")):(tt(),nt("span",Vv,"🚀 确认导入思源笔记"))],8,Uv)])])]))}}),qv=Be(Kv,[["__scopeId","data-v-8771dc8a"]]);function Gl(t){return t?t==="NodeThematicBreak"||t==="tb"||t==="thematic-break":!1}function Gv(t,i){var s;if(!t||t.length===0)return null;const e=i.activeBlockId||"",n=i.currentTopBlockId||e,o=i.currentPageDividerId||"",r=i.activeBlockType||"";if(Gl(r)&&e){let a=t.find(c=>c.startBlockId===e);if(a||(a=t.find(c=>{var d,p;return((p=(d=c.blocks)==null?void 0:d[0])==null?void 0:p.id)===e}),a)||(a=t.find(c=>{var d;return(d=c.allBlockIds)==null?void 0:d.includes(e)}),a))return a}if(o){let a=t.find(c=>c.startBlockId===o);if(a||(a=t.find(c=>{var d,p;return((p=(d=c.blocks)==null?void 0:d[0])==null?void 0:p.id)===o}),a))return a}if(e){let a=t.find(d=>d.startBlockId===e);if(a||(a=t.find(d=>{var p,g;return((p=d.blocks)==null?void 0:p.some(u=>u.id===e))||((g=d.allBlockIds)==null?void 0:g.includes(e))}),a)||n&&n!==e&&(a=t.find(d=>{var p,g;return((p=d.blocks)==null?void 0:p.some(u=>u.id===n))||((g=d.allBlockIds)==null?void 0:g.includes(n))}),a)||(a=t.find(d=>{var p;return(p=d.noteBlocks)==null?void 0:p.some(g=>g.id===e||g.id===n)}),a))return a;const c=(s=i.activeBlockAttrs)==null?void 0:s[It];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=t.find(d=>{var p,g;return((p=d.frontmatter)==null?void 0:p.layout)==="three-cols-header"||((g=d.blocks)==null?void 0:g.some(u=>u.slot==="col-1"||u.slot==="col-2"||u.slot==="col-3"))}),a))return a}return t[0]||null}function mr(t,i){const e=(t.blocks||[]).filter(l=>{const s=(l.content||l.rawMarkdown||"").trim();return s&&s!=="---"});if(e.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],o=[];for(const l of e){const s=(l.content||l.rawMarkdown||"").trim();s&&(l.type==="h"||s.startsWith("#")?n.push(s.replace(/^#+\s*/,"")):o.push(s.slice(0,50)))}const r=[];return n.length>0&&r.push(`【核心重点】：${n.join("、")}`),o.length>0&&(r.push("【口播要点】："),o.slice(0,3).forEach((l,s)=>{r.push(`${s+1}. 讲解 ${l}`)})),r.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),r.join(`
`)}async function Zl(t,i){const e=t.blocks&&t.blocks.length>0?t.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(t.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(i&&e){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${e}`;try{const o=await i(n);if(o&&o.trim())return{notes:o.trim(),isAiGenerated:!0}}catch(o){return{notes:mr(t),isAiGenerated:!1,error:(o==null?void 0:o.message)||"AI 调用异常"}}}return{notes:mr(t),isAiGenerated:!1}}async function Zv(t,i){return(await Zl(t,i)).notes}function Yv(t){let i=null;function e(A="已同步"){t.saveStatus.value=A,i&&(typeof window<"u"?window.clearTimeout(i):clearTimeout(i));const v=()=>{t.saveStatus.value=""};typeof window<"u"?i=window.setTimeout(v,1200):i=setTimeout(v,1200)}async function n(A){const v=t.activeBlockId.value||t.currentDocId.value;if(v){for(const[P,G]of Object.entries(A))t.activeBlockAttrs.value[P]=G;if(Rt.setBlockAttrOverride(v,A),Xt(v,A),ut in A){const P=A[ut];t.currentPageDividerLayout.value=P,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=P)}e("保存中...");try{await Mt(v,A),e("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{e("同步失败")}}}async function o(A,v){const P=t.activeBlockId.value||t.currentDocId.value;if(P){t.activeBlockAttrs.value[A]=v,Rt.setBlockAttrOverride(P,{[A]:v}),Xt(P,{[A]:v}),A===ut&&(t.currentPageDividerLayout.value=v,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=v)),e("保存中...");try{await Mt(P,{[A]:v}),e("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{e("同步失败")}}}async function r(A,v){var G;const P=t.currentDocId.value||t.activeBlockId.value;if(P){t.activeBlockAttrs.value[A]=v,Rt.setBlockAttrOverride(P,{[A]:v}),Xt(P,{[A]:v}),(G=t.latestDoc.value)!=null&&G.config&&(A===un&&(t.latestDoc.value.config.theme=v),A===fn&&(t.latestDoc.value.config.aspectRatio=v),A===pn&&(t.latestDoc.value.config.defaultTransition=v)),e("更新中...");try{await Mt(P,{[A]:v}),e("已更新"),t.plugin&&await t.plugin.compileCurrentDocument(P)}catch{e("更新失败")}}}async function l(){(t.videoAutoplay.value?"false":"true")==="true"?(await n({[bi]:"true",[Mi]:"true"}),t.activeBlockAttrs.value[bi]="true",t.activeBlockAttrs.value[Mi]="true"):(await o(bi,"false"),t.activeBlockAttrs.value[bi]="false")}async function s(){const A=t.videoLoop.value?"false":"true";await o(Un,A)}async function a(){const A=t.videoMuted.value?"false":"true";await o(Mi,A)}async function c(){const A=t.videoControls.value?"false":"true";await o(Wn,A)}async function d(A){var et;const v=t.activeBlockId.value;if(!v)return;const P=t.rawSnippet.value||"",G=li(P)||"",F=t.currentPageDividerId.value||t.currentDocId.value;if(A)if(A==="background"){const H={[jt]:"background",[ut]:""};F&&G&&(t.pageBackground.value=G,await Mt(F,{[zt]:G}).catch(()=>{}),Rt.setBlockAttrOverride(F,{[zt]:G}),Xt(F,{[zt]:G}),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.background=G)),await n(H)}else(A===Vn||A===Kn)&&await n({[ut]:A,[jt]:""});else{const H={[jt]:"",[ut]:""};if(t.activeBlockAttrs.value[zt]==="true"&&(H[zt]=""),F&&G&&t.pageBackground.value===G&&(t.pageBackground.value="",await Mt(F,{[zt]:""}).catch(()=>{}),Rt.setBlockAttrOverride(F,{[zt]:""}),Xt(F,{[zt]:""}),(et=t.targetSlide.value)!=null&&et.frontmatter&&delete t.targetSlide.value.frontmatter.background),await n(H),typeof document<"u"){const V=document.querySelector(`.protyle-wysiwyg [data-node-id="${v}"]`),R=V==null?void 0:V.closest('[data-type="NodeListItem"]'),U=R==null?void 0:R.getAttribute("data-node-id");if(U&&U!==v){const at={[ut]:"",[jt]:""};Xt(U,at),Rt.setBlockAttrOverride(U,at),await Mt(U,at).catch(()=>{})}}}}async function p(A){var U,at,rt,st,X,pt,mt,Z;const G=`> [!NOTE] 💡 演讲备注
${(A||"在此输入本页讲稿提词...").split(/\r?\n/).map(ot=>`> ${ot}`).join(`
`)}
{: custom-slidev-note="true"}`,F=((U=t.latestDoc.value)==null?void 0:U.slides)||[],et=t.targetSlide.value,H=et?F.findIndex(ot=>ot===et):-1;let V=null;if(H!==-1&&H<F.length-1){const ot=F[H+1];V=await Qi("markdown",G,ot.startBlockId)}else{const ot=((at=et==null?void 0:et.noteBlocks)==null?void 0:at.slice(-1)[0])||((rt=et==null?void 0:et.blocks)==null?void 0:rt.slice(-1)[0]),ct=(ot==null?void 0:ot.id)||(et==null?void 0:et.startBlockId);ct?V=await Qi("markdown",G,void 0,ct):V=await br("markdown",G,t.currentDocId.value)}const R=((pt=(X=(st=V==null?void 0:V[0])==null?void 0:st.doOperations)==null?void 0:X[0])==null?void 0:pt.id)||((mt=V==null?void 0:V[0])==null?void 0:mt.id);return R&&(await Mt(R,{[Yt]:"true"}),Rt.setBlockAttrOverride(R,{[Yt]:"true"}),Si(R,(Z=t.plugin)==null?void 0:Z.app)),t.plugin&&await t.plugin.compileCurrentDocument(),R}async function g(){const A=t.activeBlockId.value;if(A)if(t.isNoteBlock.value){e("取消中...");try{await Mt(A,{[Yt]:"","slidev-note":""}),Rt.setBlockAttrOverride(A,{[Yt]:"","slidev-note":""}),Xt(A,{[Yt]:"","slidev-note":""}),delete t.activeBlockAttrs.value[Yt],delete t.activeBlockAttrs.value["slidev-note"],e("已取消备注"),gt.showMessage("已取消讲稿备注"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(v){console.error("[SiYuanSlidev] 取消讲稿备注失败:",v),e("取消失败"),gt.showMessage("取消讲稿备注失败")}}else{e("转换中...");try{let v=t.rawSnippet.value;try{const et=await ba(A);et!=null&&et.kramdown&&(v=et.kramdown)}catch{}const F=`> [!NOTE] 💡 演讲备注
${($r(v)||v.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(et=>`> ${et}`).join(`
`)}
{: custom-slidev-note="true"}`;await Ts("markdown",F,A),await Mt(A,{[Yt]:"true"}),Rt.setBlockAttrOverride(A,{[Yt]:"true"}),Xt(A,{[Yt]:"true"}),t.activeBlockAttrs.value[Yt]="true",t.activeBlockType.value="NodeCallout",e("已设为讲稿备注"),gt.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(v){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",v),e("设置失败"),gt.showMessage("转为讲稿备注提示块失败")}}}async function u(){try{await p(),gt.showMessage("已在正文末尾插入讲稿备注提示块")}catch(A){gt.showMessage("插入讲稿备注块失败"),console.error(A)}}function w(){var P;const A=t.currentSlideNoteBlockId.value;if(!A){gt.showMessage("未找到本页关联的讲稿备注块");return}Si(A,(P=t.plugin)==null?void 0:P.app)?gt.showMessage("已在编辑区定位讲稿备注块"):gt.showMessage("定位讲稿备注块失败")}async function h(){var P;if(!t.currentDocId.value)return;const A=t.targetSlide.value||{startBlockId:t.activeBlockId.value||t.currentDocId.value,blocks:t.rawSnippet.value&&t.rawSnippet.value!=="---"?[{id:t.activeBlockId.value,type:t.activeBlockType.value,content:t.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:t.rawSnippet.value&&t.rawSnippet.value!=="---"?t.rawSnippet.value:""};gt.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const v=await Zl(A,yr);if(v.notes){const G=t.currentSlideNoteBlockId.value;if(G){const F=`> [!NOTE] 💡 演讲备注
${v.notes.split(/\r?\n/).map(et=>`> ${et}`).join(`
`)}
{: custom-slidev-note="true"}`;await Ts("markdown",F,G),await Mt(G,{[Yt]:"true"}),Rt.setBlockAttrOverride(G,{[Yt]:"true"}),Si(G,(P=t.plugin)==null?void 0:P.app)}else await p(v.notes);v.isAiGenerated?gt.showMessage("思源 AI 演讲提词卡生成成功！"):gt.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),t.plugin&&await t.plugin.compileCurrentDocument()}}function k(){t.elemClick.value?o(ke,""):o(ke,"+1")}function b(A){o(ke,A)}function y(A){o(Ne,A)}function S(A){(t.activeBlockAttrs.value[It]||"")===A?o(It,""):o(It,A)}function T(A){t.elemShikiLines.value=A,o(Ci,A)}function x(A){t.elemMaxHeight.value=A,o(hn,A)}async function _(){const A=t.currentSlideLayout.value==="three-cols-header";await o(It,A?"col-1":"left"),gt.showMessage(A?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function C(){const A=t.activeBlockId.value;if(!A)return;const v={[ke]:"",[Ne]:"",[It]:"",[Ci]:"",[hn]:"",[Yt]:"","slidev-note":"",[ut]:"",[jt]:"",[Kt]:"",[zt]:"",[Se]:"",[bi]:"",[Un]:"",[Mi]:"",[Wn]:""};if(Xt(A,v),await Mt(A,v),Rt.clearBlockAttrOverride(A),typeof document<"u"){const P=document.querySelector(`.protyle-wysiwyg [data-node-id="${A}"]`),G=P==null?void 0:P.closest('[data-type="NodeListItem"]'),F=G==null?void 0:G.getAttribute("data-node-id");F&&F!==A&&(Xt(F,v),await Mt(F,v).catch(()=>{}),Rt.clearBlockAttrOverride(F))}t.activeBlockAttrs.value={},t.elemShikiLines.value="",t.elemMaxHeight.value="",t.pageBackground.value="",t.pageImage.value="",gt.showMessage("已清除本块演示属性"),t.plugin&&await t.plugin.compileCurrentDocument()}async function D(){if(t.activeBlockId.value)try{await Qi("markdown","---",t.activeBlockId.value,void 0),gt.showMessage("已在上方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{gt.showMessage("插入分页符失败")}}async function M(){const A=t.activeBlockId.value||t.currentDocId.value;if(A)try{await Qi("markdown","---",void 0,A),gt.showMessage("已在下方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{gt.showMessage("插入分页符失败")}}async function z(){if(t.activeBlockId.value)try{await va(t.activeBlockId.value),gt.showMessage("已删除该分页符"),t.activeBlockId.value="",t.activeBlockType.value="",t.plugin&&t.plugin.compileCurrentDocument()}catch{gt.showMessage("删除失败")}}function J(){if(!t.latestDoc.value){gt.showMessage("请先在主编辑区打开幻灯片文档");return}const A=Wl(t.latestDoc.value);Vl("presentation.html",A)&&gt.showMessage("已开始下载单文件离线 HTML 演示包")}function E(){if(!t.latestDoc.value){gt.showMessage("请先在主编辑区打开幻灯片文档");return}Kl(t.latestDoc.value)&&gt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return{triggerSaveNotice:e,saveAttrs:n,saveAttr:o,saveDocAttr:r,onToggleVideoAutoplay:l,onToggleVideoLoop:s,onToggleVideoMuted:a,onToggleVideoControls:c,onImageRoleChange:d,onToggleNoteBlock:g,createNoteBlockOnCurrentSlide:p,onAddNoteBlock:u,onLocateNoteBlock:w,onGenerateNotesWithAI:h,toggleElemClick:k,onElemClickStepChange:b,onElemMotionChange:y,onElemSlotChange:S,onElemShikiLinesChange:T,onElemMaxHeightChange:x,onSetTwoColsContrast:_,onClearBlockAttrs:C,onInsertDividerBefore:D,onInsertDividerAfter:M,onDeleteCurrentBlock:z,onExportHtml:J,onExportPdf:E}}const Jv={class:"spm-slidev-inspector"},Xv={class:"spm-inspector-topbar"},Qv={class:"spm-inspector-title"},tb={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},eb={class:"spm-inspector-topbar-actions"},ib={class:"spm-target-banner"},nb={class:"spm-target-info"},ob=["aria-label"],sb={key:0,class:"spm-save-status"},rb=["title"],lb={class:"spm-inspector-body"},ab=he({__name:"SlidevInspectorDockView",setup(t,{expose:i}){const e=Ge("plugin"),n=ht(!1);function o(lt){n.value=!1,c.value=lt.docId,e!=null&&e.compileCurrentDocument&&e.compileCurrentDocument(lt.docId)}const r=ht(""),l=ht(""),s=ht({}),a=ht(""),c=ht(""),d=ht(""),p=ht(""),g=ht(""),u=ht(null),w=ht(""),h=ht("");function k(){var wt;const lt=r.value||c.value;lt&&typeof navigator<"u"&&(wt=navigator==null?void 0:navigator.clipboard)!=null&&wt.writeText&&navigator.clipboard.writeText(lt).then(()=>{h.value="已复制！",setTimeout(()=>{h.value=""},1500)}).catch(()=>{})}const b=_t(()=>Gl(l.value)),y=_t(()=>l.value==="NodeCodeBlock"),S=ht(!1),T=_t(()=>{if(S.value||j.value)return!0;const lt=a.value||"";return!!li(lt)}),x=_t(()=>{const lt=l.value||"";if(lt==="NodeVideo"||lt==="video")return!0;const wt=a.value||"";return!!(/<video\b/i.test(wt)||/\.mp4\b/i.test(wt))}),_=_t(()=>!r.value||r.value===c.value||l.value==="doc"||l.value==="NodeDocument"),C=_t(()=>{const lt=r.value||c.value||"";return lt.length>8?lt.slice(-8):lt||"无"}),D=_t(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),M=_t(()=>{if(b.value)return"分页符 (---)";if(_.value)return"全局文档";if(x.value)return"视频块";switch(l.value){case"NodeHeading":return"标题块";case"NodeParagraph":return"段落块";case"NodeCodeBlock":return"代码块";case"NodeVideo":return"视频块";case"NodeList":case"NodeListItem":return"列表项";case"NodeBlockquote":return"引述块";case"NodeTable":return"表格块";case"NodeSuperBlock":case"s":case"sb":return"超级块";default:return"内容块"}}),z=_t(()=>b.value?"tag-divider":_.value?"tag-doc":"tag-block"),J=_t(()=>s.value[ut]||"default"),E=_t(()=>s.value[Kt]||"slide-left"),A=ht(""),v=ht(""),P=_t(()=>s.value[nn]||"inherit"),G=_t(()=>{var lt;return Gv((lt=u.value)==null?void 0:lt.slides,{activeBlockId:r.value,activeBlockType:l.value,currentTopBlockId:d.value,currentPageDividerId:p.value,activeBlockAttrs:s.value})}),F=_t(()=>{var lt;return((lt=G.value)==null?void 0:lt.notes)||""}),et=_t(()=>{var lt,wt,Lt;return((Lt=(wt=(lt=G.value)==null?void 0:lt.noteBlocks)==null?void 0:wt[0])==null?void 0:Lt.id)||""}),H=_t(()=>{var me,Gi,Zi,Ti,Is,As;if(b.value){const ie=s.value[ut]||s.value["custom-slidev-layout"];if(ie)return ie}const lt=s.value[It]||s.value["custom-slidev-slot"];if(lt&&["col-1","col-2","col-3"].includes(lt))return"three-cols-header";if(g.value)return g.value;const wt=p.value||(b.value?r.value:"");if(wt){const ie=Rt.getBlockAttrOverride(wt);if(ie!=null&&ie[ut])return ie[ut]}if(wt&&((me=u.value)!=null&&me.slides)){const ie=u.value.slides.find(ra=>ra.startBlockId===wt);if((Gi=ie==null?void 0:ie.frontmatter)!=null&&Gi.layout)return ie.frontmatter.layout}if((Ti=(Zi=G.value)==null?void 0:Zi.frontmatter)!=null&&Ti.layout)return G.value.frontmatter.layout;if((As=(Is=G.value)==null?void 0:Is.blocks)!=null&&As.some(ie=>ie.slot==="col-1"||ie.slot==="col-2"||ie.slot==="col-3"))return"three-cols-header";const Lt=Rt.getBlockAttrOverride(c.value);return Lt!=null&&Lt[ut]?Lt[ut]:"default"}),V=_t(()=>{var lt;return((lt=G.value)==null?void 0:lt.pageIndex)||1}),R=_t(()=>!!(s.value[Yt]||s.value["slidev-note"])),U=_t(()=>{var wt;if(s.value[ke])return s.value[ke];const lt=r.value;if(lt&&((wt=G.value)!=null&&wt.blocks)){const Lt=G.value.blocks.find(me=>me.id===lt);if(Lt!=null&&Lt.clicks)return Lt.clicks}return""}),at=_t(()=>{var wt;if(s.value[Ne])return s.value[Ne];const lt=r.value;if(lt&&((wt=G.value)!=null&&wt.blocks)){const Lt=G.value.blocks.find(me=>me.id===lt);if(Lt!=null&&Lt.motion)return typeof Lt.motion=="string"?Lt.motion:JSON.stringify(Lt.motion)}return""}),rt=_t(()=>{var wt;if(s.value[It])return s.value[It];const lt=r.value;if(lt&&((wt=G.value)!=null&&wt.blocks)){const Lt=G.value.blocks.find(me=>me.id===lt);if(Lt!=null&&Lt.slot)return Lt.slot}return""}),st=ht(""),X=ht(""),pt=_t(()=>s.value[bi]==="true"),mt=_t(()=>s.value[Un]==="true"),Z=_t(()=>s.value[Mi]==="true"),ot=_t(()=>s.value[Wn]!=="false"),ct=_t(()=>{var lt,wt;return((wt=(lt=u.value)==null?void 0:lt.config)==null?void 0:wt.theme)||s.value[un]||"default"}),B=_t(()=>{var lt,wt;return((wt=(lt=u.value)==null?void 0:lt.config)==null?void 0:wt.aspectRatio)||s.value[fn]||"16/9"}),N=_t(()=>{var lt,wt;return((wt=(lt=u.value)==null?void 0:lt.config)==null?void 0:wt.defaultTransition)||s.value[pn]||"slide-left"}),f=_t(()=>{var lt,wt;return((wt=(lt=u.value)==null?void 0:lt.config)==null?void 0:wt.spacing)||s.value[Oo]||"normal"}),j=_t(()=>{var Gi,Zi;if((s.value[jt]||s.value["slidev-role"])===_r||s.value[zt]==="true")return"background";const wt=s.value[ut]||s.value["slidev-layout"];if(wt==="image-left"||wt==="image-right")return wt;const Lt=a.value||"",me=li(Lt);if(me&&((Zi=(Gi=G.value)==null?void 0:Gi.frontmatter)!=null&&Zi.background)){const Ti=G.value.frontmatter.background;if(Ti===me||Ti.endsWith(me)||me.endsWith(Ti))return"background"}return""}),O=_t(()=>!!(s.value[ke]||s.value[Ne]||s.value[It]||s.value[Ci]||s.value[Yt]||s.value["slidev-note"]||s.value[jt]||s.value[ut]||s.value[bi]||s.value[Un]||s.value[Mi]||s.value[Wn])),{saveAttr:$,saveDocAttr:I,onToggleVideoAutoplay:L,onToggleVideoLoop:q,onToggleVideoMuted:K,onToggleVideoControls:W,onImageRoleChange:Y,onToggleNoteBlock:it,onAddNoteBlock:Q,onLocateNoteBlock:dt,onGenerateNotesWithAI:kt,toggleElemClick:vt,onElemClickStepChange:At,onElemMotionChange:Ht,onElemSlotChange:Wt,onElemShikiLinesChange:Zt,onElemMaxHeightChange:Dt,onSetTwoColsContrast:je,onClearBlockAttrs:Gt,onInsertDividerBefore:Vt,onInsertDividerAfter:ii,onDeleteCurrentBlock:Ii,onExportHtml:vo,onExportPdf:bo}=Yv({activeBlockId:r,activeBlockType:l,activeBlockAttrs:s,rawSnippet:a,currentDocId:c,currentPageDividerId:p,currentPageDividerLayout:g,latestDoc:u,targetSlide:G,currentSlideNoteBlockId:et,currentSlideLayout:H,isNoteBlock:R,elemClick:U,videoAutoplay:pt,videoLoop:mt,videoMuted:Z,videoControls:ot,pageBackground:A,pageImage:v,elemShikiLines:st,elemMaxHeight:X,saveStatus:w,plugin:e});function In(lt){$(ut,lt)}function di(lt){$(Kt,lt)}function Ai(lt){A.value=lt,$(zt,lt)}function Xl(lt){v.value=lt,$(Se,lt)}function Ql(lt){$(nn,lt==="inherit"?"":lt)}function ta(lt){I(un,lt)}function ea(lt){I(fn,lt)}function ia(lt){I(pn,lt)}function na(lt){I(Oo,lt)}function $s(){e!=null&&e.openBottomPreviewTab&&e.openBottomPreviewTab()}function oa(){typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function sa(){e!=null&&e.executeCommand&&e.executeCommand("slidevAiSplit")}return i({setActiveBlock(lt){r.value=lt.id,l.value=lt.type,s.value={...lt.attrs},a.value=lt.content||lt.markdown||"",d.value=lt.topBlockId||lt.id,p.value=lt.pageDividerId||"",g.value=lt.pageDividerLayout||"",lt.rootId?c.value=lt.rootId:(lt.type==="doc"||lt.type==="NodeDocument")&&lt.id&&(c.value=lt.id),A.value=lt.attrs[zt]||"",v.value=lt.attrs[Se]||"",st.value=lt.attrs[Ci]||"",X.value=lt.attrs[hn]||"",S.value=!!lt.isImage},updateDocument(lt){u.value=lt,c.value=lt.docId},openImportDialog(){n.value=!0},setCurrentDocId(lt){c.value=lt}}),(lt,wt)=>(tt(),nt("div",Jv,[m("div",Xv,[m("div",Qv,[(tt(),nt("svg",tb,[...wt[2]||(wt[2]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),wt[3]||(wt[3]=m("span",null,"演示配置",-1))]),m("div",eb,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:wt[0]||(wt[0]=Lt=>n.value=!0)},[ft(bt,{name:"import"}),wt[4]||(wt[4]=m("span",null,"导入",-1))]),m("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:$s},[ft(bt,{name:"split-preview"}),wt[5]||(wt[5]=m("span",null,"分屏预览",-1))])])]),m("div",ib,[m("div",nb,[m("span",{class:Ct(["spm-target-tag",z.value])},xt(M.value),3),m("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":h.value||"点击复制 ID: "+(r.value||c.value),onClick:k},[ft(bt,{name:"copy"}),m("span",null,"#"+xt(C.value),1)],8,ob)]),w.value?(tt(),nt("span",sb,"● "+xt(w.value),1)):Ot("",!0)]),D.value?(tt(),nt("div",{key:0,class:"spm-context-quote",title:a.value},xt(D.value),9,rb)):Ot("",!0),m("div",lb,[b.value?(tt(),$e(Xh,{key:0,"page-layout":J.value,"page-transition":E.value,"page-background":A.value,"page-spacing":P.value,"page-image":v.value,"page-notes":F.value,"page-index":V.value,"onUpdate:pageLayout":In,"onUpdate:pageTransition":di,"onUpdate:pageBackground":Ai,"onUpdate:pageSpacing":Ql,"onUpdate:pageImage":Xl,onAddNoteBlock:Tt(Q),onLocateNoteBlock:Tt(dt),onGenerateNotes:Tt(kt),onInsertDividerAfter:Tt(ii),onDeleteDivider:Tt(Ii)},null,8,["page-layout","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onInsertDividerAfter","onDeleteDivider"])):r.value&&!_.value?(tt(),$e(yg,{key:1,"elem-click":U.value,"elem-motion":at.value,"elem-slot":rt.value,"elem-shiki-lines":st.value,"elem-max-height":X.value,"is-code-block":y.value,"is-image":T.value,"is-video":x.value,"video-autoplay":pt.value,"video-loop":mt.value,"video-muted":Z.value,"video-controls":ot.value,"has-block-attrs":O.value,"is-note":R.value,"image-role":j.value,"current-slide-layout":H.value,onToggleNote:Tt(it),onToggleElemClick:Tt(vt),onToggleVideoAutoplay:Tt(L),onToggleVideoLoop:Tt(q),onToggleVideoMuted:Tt(K),onToggleVideoControls:Tt(W),"onUpdate:imageRole":Tt(Y),"onUpdate:elemClick":Tt(At),"onUpdate:elemMotion":Tt(Ht),"onUpdate:elemSlot":Tt(Wt),"onUpdate:elemShikiLines":Tt(Zt),"onUpdate:elemMaxHeight":Tt(Dt),onInsertDividerBefore:Tt(Vt),onInsertDividerAfter:Tt(ii),onSetTwoColsContrast:Tt(je),onClearBlockAttrs:Tt(Gt)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(tt(),$e(Jg,{key:2,"doc-theme":ct.value,"doc-aspect-ratio":B.value,"doc-default-transition":N.value,"doc-spacing":f.value,"onUpdate:docTheme":ta,"onUpdate:docAspectRatio":ea,"onUpdate:docDefaultTransition":ia,"onUpdate:docSpacing":na,onOpenBottomPreview:$s,onOpenPresenter:oa,onAiAutoSplit:sa,onExportHtml:Tt(vo),onExportPdf:Tt(bo)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf"]))]),n.value?(tt(),$e(qv,{key:1,onClose:wt[1]||(wt[1]=Lt=>n.value=!1),onSuccess:o})):Ot("",!0)]))}}),$n=new _s;let si=null,ze=null;function cb(t,i){si&&Yl(),si=Ol(yh),si.provide("plugin",i),si.provide("sandboxBridge",$n);const e=si.mount(t);return ze=e,e}function Yl(t){si&&(si.unmount(),si=null,ze=null)}let ri=null,pe=null;function db(t,i){ri&&Jl(),ri=Ol(ab),ri.provide("plugin",i),ri.provide("sandboxBridge",$n);const e=ri.mount(t);return pe=e,e}function Jl(t){ri&&(ri.unmount(),ri=null,pe=null)}function ub(t,i){pe!=null&&pe.updateDocument&&pe.updateDocument(t),ze!=null&&ze.updateDocument?ze.updateDocument(t,i):$n.updateSlides(t.slides,t.config,t.fullMarkdown)}function Xo(t){ze!=null&&ze.navigateToBlock?ze.navigateToBlock(t):$n.highlightElement(t)}function jn(t){pe!=null&&pe.setActiveBlock&&pe.setActiveBlock(t)}function fb(){return pe!=null&&pe.openImportDialog?(pe.openImportDialog(),!0):!1}function pb(t,i){const e=[];let o=0;for(let r=0;r<t.length;r++){const l=t[r];if(qn(l)){o=0;continue}const s=l.markdown||l.content||"";if(!(r===0)){if(l.type==="h"&&(l.subType==="h1"||s.startsWith("# "))){e.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),o=0;continue}if(l.type==="h"&&(l.subType==="h2"||s.startsWith("## "))){e.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),o=0;continue}}if(o++,o>=6&&r<t.length-1){const c=t[r+1];qn(c)||(e.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),o=0)}}return e}const hb=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:vi,value:"true"},{key:ut,value:"cover"},{key:Kt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:vi,value:"true"},{key:ut,value:"two-cols"},{key:Kt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:vi,value:"true"},{key:ut,value:"fact"},{key:Kt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:vi,value:"true"},{key:ut,value:"intro"},{key:Kt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:vi,value:"true"},{key:ut,value:"quote"},{key:Kt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:ke,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:ke,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:It,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Ci,value:"1-3"}]}];class Do{getPresetTemplates(){return hb}buildScanSlidevBlocksSql(i="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${i}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${Kt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(i,e,n,o){const r=`SELECT block_id FROM attributes WHERE name = '${Kt}' AND value = '${i}'`,l=await n(r);let s=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{[Kt]:e}),s++)}return{updatedCount:s}}async batchUpdateLayout(i,e,n,o){const r=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${i}'`,l=await n(r);let s=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{"custom-slidev-layout":e}),s++)}return{updatedCount:s}}exportTemplatesJson(){const i=this.getPresetTemplates();return JSON.stringify({templates:i,counter:i.length},null,2)}formatTransitionSummary(i){return!i||i.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${i.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function mb(t){t.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{t.openBottomPreviewTab()}}),t.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{fb()||gt.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),t.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const i=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(i==null?void 0:i.getAttribute("data-doc-id"))||""}t.currentDocId&&(await Mt(t.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),gt.showMessage("已为当前文档初始化 Slidev 演示属性"),t.compileCurrentDocument(t.currentDocId))}}),t.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const r=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(r==null?void 0:r.getAttribute("data-doc-id"))||""}if(!t.currentDocId){gt.showMessage("请先打开一篇思源笔记文档");return}const i=await Hn(t.currentDocId).catch(()=>[]);if(!i||i.length===0){gt.showMessage("当前文档无内容，无需断页");return}const e=i.map(r=>({id:r.id,type:r.type,subType:r.subType,content:r.content||"",markdown:r.markdown||""})),n=pb(e);if(n.length===0){gt.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}gt.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const r of n)try{await Qi("markdown","---",void 0,r.blockId),await Mt(r.blockId,{"custom-slidev-layout":r.recommendedLayout}),o++}catch(l){console.warn("Failed to insert divider:",l)}gt.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,d,p;if(!t.currentDocId){const g=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(g==null?void 0:g.getAttribute("data-doc-id"))||""}if(!t.currentDocId){gt.showMessage("请先打开一篇思源笔记文档");return}gt.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const i=await Hn(t.currentDocId).catch(()=>[]),e={startBlockId:t.currentDocId,blocks:i.map(g=>({id:g.id,type:g.type,content:g.content||"",rawMarkdown:g.markdown||""})),rawMarkdown:""},r=`> [!NOTE] 💡 演讲备注
${(await Zv(e,yr)).split(/\r?\n/).map(g=>`> ${g}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await br("markdown",r,t.currentDocId).catch(()=>null),s=((d=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:d.id)||((p=l==null?void 0:l[0])==null?void 0:p.id);s&&(await Mt(s,{"custom-slidev-note":"true"}),Rt.setBlockAttrOverride(s,{"custom-slidev-note":"true"}),Si(s,t.app)),gt.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new Do,e=i.buildTransitionStatsSql(),n=await dn(e).catch(()=>[]),o=i.formatTransitionSummary(n||[]);gt.showMessage(o)}}),t.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const e=new Do().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(e),gt.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):gt.showMessage(`已生成模板数据（请在控制台查看）：
`+e)}}),t.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const e=await new Do().batchUpdateTransitions("fade","slide-left",n=>dn(n).catch(()=>[]),(n,o)=>Mt(n,o));gt.showMessage(`全库批量替换完成：已将 ${e.updatedCount} 处 fade 转场更新为 slide-left`),t.compileCurrentDocument()}}),t.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),t.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){gt.showMessage("请先打开并放映一篇思源笔记文档");return}t.cliBridge.downloadSlidesMd(t.latestCompiledDoc,`slides-${t.currentDocId||"demo"}.md`)&&gt.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),t.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{gt.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await t.cliBridge.probeServer(1500)?gt.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):gt.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),t.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){gt.showMessage("请先打开并放映一篇思源笔记文档");return}const i=await t.cliBridge.syncToWorkspaceFile(t.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",Lo);i.success?gt.showMessage(`已成功同步最新 slides.md 至工作空间：${i.path}`):gt.showMessage(`同步失败：${i.error}`)}})}class gb{getActiveDocumentId(){if(typeof document>"u")return"";const i=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),e=i==null?void 0:i.getAttribute("data-node-id");if(e)return e;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const r=document.querySelector("[data-doc-id]"),l=r==null?void 0:r.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(i,e=""){const n=i.closest(".protyle-title"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const r=i.closest(".protyle"),l=r==null?void 0:r.querySelector(".protyle-title"),s=l==null?void 0:l.getAttribute("data-node-id");if(s)return s;const a=i.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||e}async switchToDocGlobalInspector(i,e){var r;if(!i)return;let n=e||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${i}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${i}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((r=l==null?void 0:l.innerText)==null?void 0:r.trim())||""}const o=await Ue(i).catch(()=>({}));jn({id:i,rootId:i,type:"doc",content:n,attrs:o,isDivider:!1,isCode:!1}),Xo(i)}handleBlockClickedFromSlide(i,e,n,o){var a;if(!i)return!1;const r=Si(i,e),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`),s=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,i,s,n,o);else{let c="",d="";if(o!=null&&o.slides){const p=o.slides.find(g=>{var u,w,h;return g.startBlockId===i||((u=g.blocks)==null?void 0:u.some(k=>k.id===i))||((w=g.allBlockIds)==null?void 0:w.includes(i))||((h=g.noteBlocks)==null?void 0:h.some(k=>k.id===i))});p!=null&&p.startBlockId&&(c=p.startBlockId),(a=p==null?void 0:p.frontmatter)!=null&&a.layout&&(d=p.frontmatter.layout)}Ue(i).then(async p=>{if(c&&!d){const g=Rt.getBlockAttrOverride(c);if(g!=null&&g[ut]||g!=null&&g["custom-slidev-layout"])d=g[ut]||g["custom-slidev-layout"]||"";else{const u=await Ue(c).catch(()=>({}))||{};d=u[ut]||u["custom-slidev-layout"]||"",u&&Object.keys(u).length>0&&Rt.setBlockAttrOverride(c,u)}}jn({id:i,rootId:n,type:s||"NodeParagraph",attrs:p||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return r}async syncInspectorBlock(i,e,n,o,r){var E,A,v,P,G,F,et,H;let l=i,s=e,a=n;const c=i.closest('[data-type="NodeCallout"]');if(c&&c!==i){const V=c.getAttribute("data-node-id");if(V){const R=await Ue(V).catch(()=>({}))||{},U=Rt.getBlockAttrOverride(V)||{},at={...R,...U};(at[Yt]||at["slidev-note"])&&(l=c,s=V,a="NodeCallout")}}const d=l.closest(".protyle-wysiwyg > [data-node-id]")||l,p=(d==null?void 0:d.getAttribute("data-node-id"))||s,g=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(d==null?void 0:d.getAttribute("data-type"))==="NodeThematicBreak"||(d==null?void 0:d.getAttribute("data-type"))==="tb"||!!((E=d==null?void 0:d.classList)!=null&&E.contains("hr")),u=a==="NodeCodeBlock",w=((A=l.innerText)==null?void 0:A.trim())||"",h=await Ue(s).catch(()=>({}))||{},k=Rt.getBlockAttrOverride(s)||{},b={...h,...k};let y="",S="";if(g)y=s,S=b[ut]||b["custom-slidev-layout"]||"";else{let V=d.previousElementSibling;for(;V;){const R=V.getAttribute("data-type");if(R==="NodeThematicBreak"||R==="tb"||(v=V.classList)!=null&&v.contains("hr")){y=V.getAttribute("data-node-id")||"";break}V=V.previousElementSibling}}if(r!=null&&r.slides){const V=[s,p];let R=l.parentElement;for(;R&&!R.classList.contains("protyle-wysiwyg");){const at=R.getAttribute("data-node-id");at&&!V.includes(at)&&V.push(at),R=R.parentElement}const U=r.slides.find(at=>{var rt,st,X;return V.includes(at.startBlockId)||((rt=at.blocks)==null?void 0:rt.some(pt=>V.includes(pt.id)))||((st=at.allBlockIds)==null?void 0:st.some(pt=>V.includes(pt)))||((X=at.noteBlocks)==null?void 0:X.some(pt=>V.includes(pt.id)))});U&&(!y&&U.startBlockId&&(y=U.startBlockId),!S&&((P=U.frontmatter)!=null&&P.layout)&&(S=U.frontmatter.layout))}if(y){const V=Rt.getBlockAttrOverride(y);if(V&&(ut in V||"custom-slidev-layout"in V)&&(S=V[ut]||V["custom-slidev-layout"]||""),!S&&(r!=null&&r.slides)){const R=r.slides.find(U=>U.startBlockId===y);(G=R==null?void 0:R.frontmatter)!=null&&G.layout&&(S=R.frontmatter.layout)}if(!S){const R=await Ue(y).catch(()=>({}))||{};S=R[ut]||R["custom-slidev-layout"]||"",R&&Object.keys(R).length>0&&Rt.setBlockAttrOverride(y,R)}Xt(y,{[ut]:S||""})}else if(o){const V=Rt.getBlockAttrOverride(o);V&&(ut in V||"custom-slidev-layout"in V)?S=V[ut]||V["custom-slidev-layout"]||"":!S&&((H=(et=(F=r==null?void 0:r.slides)==null?void 0:F[0])==null?void 0:et.frontmatter)!=null&&H.layout)&&(S=r.slides[0].frontmatter.layout)}const T=l.getAttribute(ut)||l.getAttribute("custom-slidev-layout"),x=b[ut]||b["custom-slidev-layout"]||"";T&&T!==x&&Xt(s,{[ut]:x});const _=l.getAttribute(jt)||l.getAttribute("custom-slidev-role"),C=b[jt]||b["custom-slidev-role"]||"";_&&_!==C&&Xt(s,{[jt]:C});const D=l.closest('[data-type="NodeListItem"]');if(D&&D!==l){const V=D.getAttribute("data-node-id");if(V){const R=await Ue(V).catch(()=>({}))||{},U=Rt.getBlockAttrOverride(V)||{},at={...R,...U},rt=at[ut]||at["custom-slidev-layout"]||"",st=D.getAttribute(ut)||D.getAttribute("custom-slidev-layout");st&&st!==rt&&Xt(V,{[ut]:rt});const X=at[jt]||at["custom-slidev-role"]||"",pt=D.getAttribute(jt)||D.getAttribute("custom-slidev-role");pt&&pt!==X&&Xt(V,{[jt]:X})}}const M=!!l.querySelector("img, span[data-type='img']"),z=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),J=M&&z.length<=50;jn({id:s,rootId:o,type:a,content:w,attrs:b,isDivider:g,isCode:u,isImage:J,topBlockId:p,pageDividerId:y,pageDividerLayout:S})}patchThematicBreakTransactions(i){if((i==null?void 0:i.cmd)==="transactions"&&Array.isArray(i.data)){for(const e of i.data)if(Array.isArray(e==null?void 0:e.doOperations)){for(const n of e.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const o=n.data.old||{},r=n.data.new||{},l={};for(const s of Object.keys(o))s in r||(l[s]="");for(const[s,a]of Object.entries(r))l[s]=String(a??"");Xt(n.id,l),Rt.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidevAttrs(i){var o,r,l;if(typeof document>"u"||!i)return;const e=new Map;if(Array.isArray(i.slides))for(const s of i.slides){if(s.startBlockId){const a=e.get(s.startBlockId)||{};(o=s.frontmatter)!=null&&o.layout&&(a[ut]=s.frontmatter.layout),e.set(s.startBlockId,a)}if(Array.isArray(s.blocks)){for(const a of s.blocks)if(a.id){const c=e.get(a.id)||{};(r=a.ial)!=null&&r[ut]&&(c[ut]=a.ial[ut]),(l=a.ial)!=null&&l[jt]&&(c[jt]=a.ial[jt]),Object.keys(c).length>0&&e.set(a.id,c)}}}const n=Rt.getAllAttrOverrides();for(const[s,a]of n.entries()){const c=e.get(s)||{};a[ut]!==void 0&&(c[ut]=a[ut]),a[jt]!==void 0&&(c[jt]=a[jt]),e.set(s,c)}Af(e)}}const mi=new gb,vb=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,bb="slidev-dock",gr="slidev-preview-tab",vr=bp;class yb extends gt.Plugin{constructor(){super(...arguments);yt(this,"isMobile",!1);yt(this,"currentDocId","");yt(this,"latestCompiledDoc",null);yt(this,"cliBridge",new ts);yt(this,"debounceTimer",null);yt(this,"activeCursorBlockId","");yt(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));yt(this,"onWsMainBound",this.onWsMain.bind(this));yt(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));yt(this,"onClickEditorTitleIconBound",this.onClickEditorTitleIcon.bind(this));yt(this,"onEditorClickBound",this.onEditorClick.bind(this));yt(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));yt(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this))}async onload(){const e=gt.getFrontend();this.isMobile=e==="mobile"||e==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(vb),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"Slidev 演示 (下方分屏)",position:"right",callback:()=>{this.openBottomPreviewTab()}}),mb(this);const n=this;if(this.addTab({type:gr,init(){cb(this.element,n)},destroy(){Yl(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:bb,init(){db(this.element,n)},destroy(){Jl(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(o,r)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${o}`,{detail:r}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound)),typeof document<"u"){const o=()=>{const r=this.getActiveDocumentId();r&&(r!==this.currentDocId&&(this.currentDocId=r),this.latestCompiledDoc||this.compileCurrentDocument(r))};setTimeout(o,300),setTimeout(o,1e3)}}async onDataChanged(e){await this.loadGlobalSettings(),this.currentDocId&&await this.compileCurrentDocument(this.currentDocId)}async loadGlobalSettings(){try{const e=await this.loadData(vr),n=yp(e);return Fi(n),n}catch{return Fi(Vi),Vi}}async saveGlobalSettings(e){const n=Cs(),o=Fi({...n,...e||{}});try{await this.saveData(vr,o)}catch(r){console.error("保存 Slidev 全局配置失败",r)}return o}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound)),$n.detach()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),await gt.openTab({app:this.app,custom:{id:this.name+gr,title:"Slidev 演示预览",icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId)}onClickEditorTitleIcon(e){var l;const n=e.detail,o=n==null?void 0:n.menu,r=((l=n==null?void 0:n.data)==null?void 0:l.id)||this.currentDocId;!o||!r||o.addItem({icon:"iconSlidev",label:"Slidev 全局演示配置",submenu:[{label:"初始化演示属性 (custom-slidev-*)",click:async()=>{await Mt(r,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),gt.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"主题: 默认 (default)",click:async()=>{await Mt(r,{"custom-slidev-theme":"default"}),gt.showMessage("已切换为 default 主题"),this.compileCurrentDocument(r)}},{label:"主题: 优雅衬线 (seriph)",click:async()=>{await Mt(r,{"custom-slidev-theme":"seriph"}),gt.showMessage("已切换为 seriph 主题"),this.compileCurrentDocument(r)}},{label:"主题: 苹果极简 (apple-basic)",click:async()=>{await Mt(r,{"custom-slidev-theme":"apple-basic"}),gt.showMessage("已切换为 apple-basic 主题"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"画幅: 16 / 9 (宽屏)",click:async()=>{await Mt(r,{"custom-slidev-aspect-ratio":"16/9"}),gt.showMessage("已切换画幅为 16/9"),this.compileCurrentDocument(r)}},{label:"画幅: 4 / 3 (标屏)",click:async()=>{await Mt(r,{"custom-slidev-aspect-ratio":"4/3"}),gt.showMessage("已切换画幅为 4/3"),this.compileCurrentDocument(r)}}]})}async onSwitchProtyle(e){var r,l;const n=(r=e.detail)==null?void 0:r.protyle,o=(l=n==null?void 0:n.block)==null?void 0:l.rootID;if(o&&o!==this.currentDocId){this.currentDocId=o,this.activeCursorBlockId=o;const s=await Ue(o).catch(()=>({}));jn({id:o,rootId:o,type:"doc",attrs:s}),this.compileCurrentDocument(o)}}onClickEditorContent(e){var r,l;const n=e==null?void 0:e.detail;if(!n)return;const o=(l=(r=n.protyle)==null?void 0:r.block)==null?void 0:l.rootID;o&&(!this.currentDocId||this.currentDocId!==o)&&(this.currentDocId=o),n.event&&this.onEditorClick(n.event)}getActiveDocumentId(){return mi.getActiveDocumentId()}resolveDocIdFromElement(e){return mi.resolveDocIdFromElement(e,this.currentDocId)}async switchToDocGlobalInspector(e,n){e&&(this.activeCursorBlockId=e,this.currentDocId=e,await mi.switchToDocGlobalInspector(e,n))}onWsMain(e){const n=e.detail;n&&(mi.patchThematicBreakTransactions(n),this.debounceTimer&&window.clearTimeout(this.debounceTimer),this.debounceTimer=window.setTimeout(()=>{this.compileCurrentDocument()},150))}handleBlockClickedFromSlide(e,n){return e?(this.activeCursorBlockId=e,mi.handleBlockClickedFromSlide(e,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(e){const n=(e==null?void 0:e.detail)||e;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(e){const n=e.target;if(!n)return;const o=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(o||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const p=o||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=p==null?void 0:p.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!n.closest(".protyle-wysiwyg"))return;const s=n.closest("[data-node-id]");if(!s)return;const a=s.getAttribute("data-node-id"),c=s.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Xo(a)),this.syncInspectorBlock(s,a,c))}onSelectionChange(){if(typeof window>"u")return;const e=window.getSelection();if(!e||e.rangeCount===0)return;const n=e.anchorNode;if(!n)return;const o=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!o)return;const r=o.closest(".protyle-title");if(!!(r||o.closest(".protyle-content")&&!o.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(o);if(d&&this.activeCursorBlockId!==d){const p=r||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=p==null?void 0:p.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!o.closest(".protyle-wysiwyg"))return;const s=o.closest("[data-node-id]"),a=s==null?void 0:s.getAttribute("data-node-id"),c=(s==null?void 0:s.getAttribute("data-type"))||"";s&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(o)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Xo(a)),this.syncInspectorBlock(s,a,c))}async syncInspectorBlock(e,n,o){await mi.syncInspectorBlock(e,n,o,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(e){let n=e||this.currentDocId;if(!n){const o=this.getActiveDocumentId();if(o)this.currentDocId=o,n=o;else return}try{const o=await Rt.compile(n);this.latestCompiledDoc=o,ub(o,n),this.purgeStaleDomSlidevAttrs(o)}catch(o){console.error("[SiYuanSlidev] Failed to compile document:",o)}}purgeStaleDomSlidevAttrs(e){mi.purgeStaleDomSlidevAttrs(e)}}module.exports=yb;
