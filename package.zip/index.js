"use strict";var aa=Object.create;var bs=Object.defineProperty;var ca=Object.getOwnPropertyDescriptor;var da=Object.getOwnPropertyNames;var ua=Object.getPrototypeOf,fa=Object.prototype.hasOwnProperty;var ha=(t,i,e)=>i in t?bs(t,i,{enumerable:!0,configurable:!0,writable:!0,value:e}):t[i]=e;var pa=(t,i,e,s)=>{if(i&&typeof i=="object"||typeof i=="function")for(let n of da(i))!fa.call(t,n)&&n!==e&&bs(t,n,{get:()=>i[n],enumerable:!(s=ca(i,n))||s.enumerable});return t};var En=(t,i,e)=>(e=t!=null?aa(ua(t)):{},pa(i||!t||!t.__esModule?bs(e,"default",{value:t,enumerable:!0}):e,t));var wt=(t,i,e)=>ha(t,typeof i!="symbol"?i+"":i,e);const vt=require("siyuan");async function me(t,i){const e=await vt.fetchSyncPost(t,i);return e.code===0?e.data:null}async function ma(){return me("/api/notebook/lsNotebooks","")}async function ga(t,i,e){return me("/api/filetree/createDocWithMd",{notebook:t,path:i,markdown:e})}async function va(t,i){const e=new FormData;e.append("assetsDirPath",t);for(const n of i)e.append("file[]",n);return me("/api/asset/upload",e)}async function nn(t,i,e,s,n){return me("/api/block/insertBlock",{dataType:t,data:i,nextID:e,previousID:s,parentID:n})}async function _r(t,i,e){return me("/api/block/appendBlock",{dataType:t,data:i,parentID:e})}async function Po(t,i,e){return me("/api/block/updateBlock",{dataType:t,data:i,id:e})}async function ba(t){return me("/api/block/deleteBlock",{id:t})}async function ya(t){return me("/api/block/getBlockKramdown",{id:t})}async function Kn(t){return me("/api/block/getChildBlocks",{id:t})}async function zt(t,i){return me("/api/attr/setBlockAttrs",{id:t,attrs:i})}async function Ge(t){return me("/api/attr/getBlockAttrs",{id:t})}async function gn(t){return me("/api/query/sql",{stmt:t})}async function Ps(t,i,e){const s=new FormData;return s.append("path",t),s.append("isDir",i.toString()),s.append("modTime",Math.floor(Date.now()/1e3).toString()),s.append("file",e),me("/api/file/putFile",s)}async function Sr(t){const i="/api/ai/chatGPT";try{const e=await me(i,{msg:t});return typeof e=="string"&&e.trim().length>0?e.trim():e&&typeof e.content=="string"&&e.content.trim().length>0?e.content.trim():null}catch{return null}}async function ka(){return me("/api/storage/getInlineStyles","")}const rn="custom-slidev-theme",ln="custom-slidev-aspect-ratio",Cr="custom-slidev-highlighter",an="custom-slidev-default-transition",$r="custom-slidev-color-schema",xi="custom-slidev-slide",ft="custom-slidev-layout",Xt="custom-slidev-transition",Ut="custom-slidev-background",Ae="custom-slidev-image",zi="custom-slidev-notes",Ni="custom-slidev-class",Se="custom-slidev-click",He="custom-slidev-motion",Si="custom-slidev-shiki-lines",Tt="custom-slidev-slot",ie="custom-slidev-note",qt="custom-slidev-role",cn="custom-slidev-max-height",vi="custom-slidev-autoplay",Mn="custom-slidev-loop",Oi="custom-slidev-muted",Bn="custom-slidev-controls",Ir="background",Ls="image-left",Rs="image-right",Pi={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto"};function wa(t){var i,e,s,n,r;return t?{theme:((i=t[rn])==null?void 0:i.trim())||Pi.theme,aspectRatio:((e=t[ln])==null?void 0:e.trim())||Pi.aspectRatio,highlighter:((s=t[Cr])==null?void 0:s.trim())||Pi.highlighter,defaultTransition:((n=t[an])==null?void 0:n.trim())||Pi.defaultTransition,colorSchema:((r=t[$r])==null?void 0:r.trim())||Pi.colorSchema}:{...Pi}}function qn(t){var e,s,n,r,l;const i=(e=t.ial)==null?void 0:e[xi];return!!(i&&(i==="true"||i==="page"||i==="cover"||i==="end")||t.type==="tb"||t.type==="thematic-break"||t.type==="NodeThematicBreak"||((s=t.markdown)==null?void 0:s.trim())==="---"||((n=t.markdown)==null?void 0:n.trim())==="***"||t.type==="b"&&(((r=t.markdown)==null?void 0:r.trim())==="---"||((l=t.content)==null?void 0:l.trim())==="---"))}function Lo(t){const i={};let e="";if(!t)return{frontmatter:i,notes:e};t[ft]&&(i.layout=t[ft].trim()),t[Xt]&&(i.transition=t[Xt].trim()),t[Ut]&&(i.background=t[Ut].trim()),t[Ae]&&(i.image=t[Ae].trim()),t[Ni]&&(i.class=t[Ni].trim()),t[zi]&&(e=t[zi].trim());for(const[s,n]of Object.entries(t))if(s.startsWith("custom-slidev-")&&![ft,Xt,Ut,Ae,Ni,zi,xi].includes(s)){const r=s.replace(/^custom-slidev-/,"");try{i[r]=JSON.parse(n)}catch{i[r]=n}}return{frontmatter:i,notes:e}}function xa(t){const i={};if(!t)return i;const e=t[ie]??t["slidev-note"];e!=null&&e!==""&&e!=="false"&&e!=="0"&&(i.isNote=!0);const s=t[qt]??t["slidev-role"],n=t[Ut]??t["slidev-background"];(s===Ir||n==="true"||n==="1")&&(i.isBackground=!0);const r=t[ft]??t["slidev-layout"];r===Ls||r===Rs?i.imageLayout=r:(s===Ls||s===Rs)&&(i.imageLayout=s);const l=t[Se]??t["custom-slidev-clicks"]??t["slidev-click"]??t["slidev-clicks"];if(l!=null&&(i.clicks=l.trim()),t[He])try{const o=JSON.parse(t[He]);typeof o=="object"&&o!==null?i.motion={preset:o.preset||o.type||"fade-in",...o}:i.motion={preset:String(o).trim()}}catch{i.motion={preset:t[He].trim()}}return t[Si]&&(i.shikiLines=t[Si].trim()),t[cn]&&(i.maxHeight=t[cn].trim()),t[Tt]&&(i.slot=t[Tt].trim()),t.style&&t.style.trim()&&(i.style=t.style.trim()),i}function _a(t,i){const e=[];let n=0;for(let r=0;r<t.length;r++){const l=t[r];if(qn(l)){n=0;continue}const o=l.markdown||l.content||"";if(!(r===0)){if(l.type==="h"&&(l.subType==="h1"||o.startsWith("# "))){e.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),n=0;continue}if(l.type==="h"&&(l.subType==="h2"||o.startsWith("## "))){e.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),n=0;continue}}if(n++,n>=6&&r<t.length-1){const c=t[r+1];qn(c)||(e.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),n=0)}}return e}function Ro(t,i){const e=(t.blocks||[]).filter(l=>{const o=(l.content||l.rawMarkdown||"").trim();return o&&o!=="---"});if(e.length===0)return"本页暂无内容，建议过渡承接上下文。";const s=[],n=[];for(const l of e){const o=(l.content||l.rawMarkdown||"").trim();o&&(l.type==="h"||o.startsWith("#")?s.push(o.replace(/^#+\s*/,"")):n.push(o.slice(0,50)))}const r=[];return s.length>0&&r.push(`【核心重点】：${s.join("、")}`),n.length>0&&(r.push("【口播要点】："),n.slice(0,3).forEach((l,o)=>{r.push(`${o+1}. 讲解 ${l}`)})),r.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),r.join(`
`)}async function Ar(t,i){const e=t.blocks&&t.blocks.length>0?t.blocks.map(s=>(s.content||s.rawMarkdown||"").trim()).filter(s=>s&&s!=="---").join(`
`):(t.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(i&&e){const s=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${e}`;try{const n=await i(s);if(n&&n.trim())return{notes:n.trim(),isAiGenerated:!0}}catch(n){return{notes:Ro(t),isAiGenerated:!1,error:(n==null?void 0:n.message)||"AI 调用异常"}}}return{notes:Ro(t),isAiGenerated:!1}}async function Sa(t,i){return(await Ar(t,i)).notes}const Tr=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function Ca(t){const i=[];if(!t)return i;const e=new RegExp(Tr.source,"g");let s;for(;(s=e.exec(t))!==null;){const n=s[2]??s[3]??s[4];i.push({fullMatch:s[0],blockId:s[1],anchorText:n?n.trim():void 0})}return i}function $a(t,i){if(!t)return"";const e=new RegExp(Tr.source,"g");return t.replace(e,(s,n,r,l,o)=>{const a=(r??l??o??"").trim();if(i&&i[n]){const d=i[n].trim();return`<div class="slidev-block-ref" data-ref-id="${n}">${d}</div>`}const c=a||`Ref(${n.slice(0,8)})`;return`<a href="siyuan://blocks/${n}" data-ref-id="${n}" class="slidev-ref-tag">🔗 ${c}</a>`})}function Ia(t){return t.markdown&&t.markdown.trim()?t.markdown.trim():t.content&&t.content.trim()?t.content.trim():""}function Aa(t){const i={};if(!t)return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),s=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let n;for(;(n=s.exec(e))!==null;){const r=n[1],l=n[2]??n[3]??n[4]??"";i[r]=l}return i}function Ta(t){if(!t)return!1;const i=t.trim();return i.startsWith("assets/")||i.startsWith("./assets/")||i.startsWith("/assets/")}function Ea(t){const i=t.trim();return i.startsWith("./assets/")?i.slice(2):i.startsWith("/assets/")?i.slice(1):i}function _e(t,i){if(!Ta(t))return t;const e=Ea(t);return i!=null&&i.base64Map&&i.base64Map[e]?i.base64Map[e]:i!=null&&i.baseUrl?`${i.baseUrl.replace(/\/+$/,"")}/${e}`:`/${e}`}function Ma(t,i){if(!t)return"";let e=t;return e=e.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(s,n,r)=>{const l=_e(r,i);return`![${n}](${l})`}),e=e.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(s,n,r,l)=>{const o=_e(r,i);return`${n}${o}${l}`}),e=e.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(s,n,r,l)=>{const o=_e(r,i);return`${n}${o}${l}`}),e}function fi(t,i){const e=(t||i||"").trim();if(!e)return null;const s=e.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(s)return s[1].trim();const n=e.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(n)return n[1].trim();const r=e.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(r)?r:null}function de(t){if(!t)return!1;const i=(t.type||"").toLowerCase();return i==="s"||i==="sb"||i==="nodesuperblock"}function Mi(t){if(!de(t))return!1;const i=(t.subType||"").toLowerCase();if(i==="col"||i==="h"||i==="horizontal")return!0;if(i==="row"||i==="v"||i==="vertical")return!1;if(t.ial){const s=(t.ial["data-sb-layout"]||t.ial.layout||"").toLowerCase();if(s==="col"||s==="h")return!0;if(s==="row"||s==="v")return!1}if(t.children&&t.children.length>0){for(const s of t.children)if(s.type==="NodeSuperBlockLayoutMarker"||s.type==="layout-marker"){const n=(s.content||s.markdown||"").trim().toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}}const e=(t.markdown||t.content||"").trim();return/^\{\{\{col\b/i.test(e)?!0:!/^\{\{\{row\b/i.test(e)}function Ki(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="i"||i==="nodelistitem"||i==="l"||i==="nodelist")return!0;const e=(t.markdown||t.rawMarkdown||t.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(e)}function zs(t){return!t||Ki(t)||de(t)||!fi(t.markdown,t.content)?!1:(t.markdown||t.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function hi(t){if(!t||!de(t)||!Mi(t))return null;const i=(t.children||[]).filter(n=>{const r=n.type||"";if(r==="NodeSuperBlockOpenMarker"||r==="NodeSuperBlockLayoutMarker"||r==="NodeSuperBlockCloseMarker"||r==="open-marker"||r==="layout-marker"||r==="close-marker")return!1;const l=(n.markdown||n.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(l)||l==="}}}")});if(i.length<2)return null;const e=zs(i[0]),s=zs(i[i.length-1]);if(e&&!s){const n=fi(i[0].markdown,i[0].content);if(n)return{imageNode:i[0],imageUrl:n,layout:Ls,contentNodes:i.slice(1)}}if(!e&&s){const n=fi(i[i.length-1].markdown,i[i.length-1].content);if(n)return{imageNode:i[i.length-1],imageUrl:n,layout:Rs,contentNodes:i.slice(0,i.length-1)}}return null}function Ba(t,i){const e=[];function s(n){for(const r of n){const l=hi(r);if(l){const{imageNode:o,layout:a}=l;o.ial||(o.ial={});const c=o.ial[ft];if(c!==a){const d={blockId:o.id,layout:a,previousLayout:c};o.ial[ft]=a,e.push(d),i&&i(d)}}r.children&&r.children.length>0&&s(r.children)}}return s(t),e}function to(t){return(t.children||[]).filter(i=>{const e=i.type||"";if(e==="NodeSuperBlockOpenMarker"||e==="NodeSuperBlockLayoutMarker"||e==="NodeSuperBlockCloseMarker"||e==="open-marker"||e==="layout-marker"||e==="close-marker")return!1;const s=(i.markdown||i.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(s)||s==="}}}")})}function Da(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="h"||i==="nodeheading"||/^h[1-6]$/i.test(t.subType||""))return!0;const e=(t.markdown||t.content||"").trim();return!!/^#{1,6}\s+/.test(e)}function Ns(t){if(!t)return"";const i=t.split(/\r?\n/);if(i.length===0)return"";const e=i[0],s=e.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!s)return t;const n=s[1].length,r=s[2].trim(),l=e.length-s[2].length;if(i.length===1)return r;const o=[r];for(let a=1;a<i.length;a++){const c=i[a];if(!c.trim()){o.push("");continue}const d=c.match(/^(\s*)/),p=d?d[1].length:0;p>=l?o.push(c.slice(l)):p>n?o.push(c.slice(p)):o.push(c)}return o.join(`
`)}function _i(t){if(!t)return[];if(de(t)&&Mi(t)&&!hi(t)){const s=to(t),n=[];for(const r of s)n.push(..._i(r));return n}const i=(t.type||"").toLowerCase();if(i==="l"||i==="nodelist"||i==="list"){if(t.children&&t.children.length>0){const l=t.children.filter(Ki);if(l.length>0)return l}const n=(t.markdown||t.content||"").trim().split(/\r?\n/),r=[];for(let l=0;l<n.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(n[l])&&r.push(l);if(r.length>=2){const l=[];for(let o=0;o<r.length;o++){const a=r[o],c=o+1<r.length?r[o+1]:n.length,d=n.slice(a,c).join(`
`);l.push({id:`${t.id}-item-${o+1}`,type:"i",markdown:d,content:d,ial:{...t.ial||{}}})}return l}}return Ki(t)?[t]:[]}function Er(t){var s;if(!t||!de(t)||!Mi(t)||hi(t))return null;const i=to(t);if(i.length===0)return null;if(i.length===1&&de(i[0])&&Mi(i[0])){const n=Er(i[0]);return n?{items:n.items,nestedSuperBlocks:[i[0],...n.nestedSuperBlocks]}:null}const e=[];for(const n of i)if(de(n)){e.push(n);const r=((s=n.children)==null?void 0:s.filter(de))||[];e.push(...r)}if(i.length===3){const n=_i(i[0]),r=_i(i[1]),l=_i(i[2]);if(n.length===1&&r.length===1&&l.length===1)return{items:[n[0],r[0],l[0]],nestedSuperBlocks:e}}if(i.length===2){const n=_i(i[0]),r=_i(i[1]);if(n.length===2&&r.length===1)return{items:[n[0],n[1],r[0]],nestedSuperBlocks:e};if(n.length===1&&r.length===2)return{items:[n[0],r[0],r[1]],nestedSuperBlocks:e};if(n.length===1&&r.length===1)return{items:[n[0],r[0]],nestedSuperBlocks:e}}return null}function Oa(t){if(!t||!de(t)||!Mi(t)||hi(t))return null;const i=Er(t);if(!i)return null;const{items:e,nestedSuperBlocks:s}=i;return e.length!==2&&e.length!==3?null:e.length===2?{superBlockNode:t,nestedSuperBlocks:s,count:2,layout:"two-cols-header",items:e,slots:["left","right"]}:{superBlockNode:t,nestedSuperBlocks:s,count:3,layout:"three-cols-header",items:e,slots:["col-1","col-2","col-3"]}}function Pa(t){if(!t||!de(t)||!Mi(t)||hi(t))return null;const i=to(t);if(i.length===0)return null;const e=[];for(const s of i){const n=_i(s);if(n.length===0)return null;e.push(...n)}return e}function La(t){if(!t||!de(t)||!Mi(t)||hi(t))return null;const i=Pa(t);return!i||i.length===0||i.length===2||i.length===3?null:{superBlockNode:t,items:i}}function Ra(t,i,e){var d,p,g,u,k;const s=[],n=[],r=(e==null?void 0:e.tracked)||[],l=[];let o={pageTargetId:t,blocks:[]};l.push(o);for(let h=0;h<i.length;h++){const b=i[h];if(qn(b)){if(l.length===1&&o.blocks.length===0){o.pageTargetId=b.id,o.blocks.push(b);continue}o={pageTargetId:b.id,blocks:[b]},l.push(o)}else o.blocks.push(b)}function a(h){const b=[];for(const v of h)de(v)&&b.push(v),v.children&&v.children.length>0&&b.push(...a(v.children));return b}function c(h,b,v){const w={blockId:h,attrs:b,previousAttrs:v};s.push(w),e!=null&&e.onTagChange&&e.onTagChange(w)}for(const h of l){const b=h.pageTargetId,v=i.find(C=>C.id===b),w=r.find(C=>C.pageTargetId===b);if(h.blocks.some(C=>{var A,M;return!!(hi(C)||zs(C)&&(((A=C.ial)==null?void 0:A[ft])==="image-left"||((M=C.ial)==null?void 0:M[ft])==="image-right"))})){if(w){const C=w.headerId;if(C){c(C,{[Tt]:""});const A=i.find(M=>M.id===C);A!=null&&A.ial&&(A.ial[Tt]="")}for(const A of w.itemIds){c(A,{[Tt]:""});const M=i.find(P=>P.id===A);M!=null&&M.ial&&(M.ial[Tt]="")}}continue}let I=null,x=-1;for(let C=0;C<h.blocks.length;C++){const A=h.blocks[C],M=de(A)?[A,...a(A.children||[])]:A.children?a(A.children):[];for(const P of M){const N=Oa(P);if(N){I=N,x=C;break}}if(I)break}if(I){const{superBlockNode:C,layout:A,items:M,slots:P}=I,X=h.blocks.slice(0,x).find(R=>Da(R)),T=X==null?void 0:X.id,D=((d=v==null?void 0:v.ial)==null?void 0:d[ft])||"";if(D!==A&&(c(b,{[ft]:A},{[ft]:D}),v&&(v.ial||(v.ial={}),v.ial[ft]=A)),X){const R=((p=X.ial)==null?void 0:p[Tt])||"";R!=="header"&&(c(X.id,{[Tt]:"header"},{[Tt]:R}),X.ial||(X.ial={}),X.ial[Tt]="header")}if(w!=null&&w.headerId&&w.headerId!==T){c(w.headerId,{[Tt]:""});const R=i.find(Q=>Q.id===w.headerId);R&&(R.ial||(R.ial={}),R.ial[Tt]="")}const y=[];for(let R=0;R<M.length;R++){const Q=M[R],U=P[R];y.push(Q.id);const at=((g=Q.ial)==null?void 0:g[Tt])||"";if(at!==U&&(c(Q.id,{[Tt]:U},{[Tt]:at}),Q.ial||(Q.ial={}),Q.ial[Tt]=U),Q.children&&Q.children.length>0)for(const V of Q.children)V.ial||(V.ial={}),V.ial[Tt]!==U&&(V.ial[Tt]=U)}if(w!=null&&w.itemIds){for(const R of w.itemIds)if(!y.includes(R)){c(R,{[Tt]:""});const Q=i.find(U=>U.id===R);Q&&(Q.ial||(Q.ial={}),Q.ial[Tt]="")}}n.push({superBlockId:C.id,nestedSuperBlockIds:(u=I.nestedSuperBlocks)==null?void 0:u.map(R=>R.id),pageTargetId:b,headerId:T,itemIds:y,layout:A})}else{let C=!1;const A=[];for(const N of h.blocks){const X=de(N)?[N,...a(N.children||[])]:N.children?a(N.children):[];for(const T of X){const D=La(T);if(D){C=!0;for(const y of D.items)A.push(y.id)}}}const M=((k=v==null?void 0:v.ial)==null?void 0:k[ft])||"";if(w||C&&(M==="two-cols-header"||M==="three-cols-header")){c(b,{[ft]:""},{[ft]:M}),v&&(v.ial||(v.ial={}),v.ial[ft]="");const N=w==null?void 0:w.headerId;if(N){c(N,{[Tt]:""});const T=i.find(D=>D.id===N);T&&(T.ial||(T.ial={}),T.ial[Tt]="")}const X=new Set([...(w==null?void 0:w.itemIds)||[],...A]);for(const T of X){c(T,{[Tt]:""});const D=i.find(y=>y.id===T);D&&(D.ial||(D.ial={}),D.ial[Tt]="")}}}}return{changes:s,newTracked:n}}function bi(t,i,e){let s="",n=0;const r=/<div\b([^>]*)>/gi;for(;n<t.length;){r.lastIndex=n;let l,o=!1,a=-1,c=0;for(;(l=r.exec(t))!==null;){const v=l[1].match(/\bclass=["']([^"']*)["']/i);if(v){const w=v[1];if(typeof i=="string"?w.split(/\s+/).includes(i):i.test(w)){o=!0,a=l.index,c=l[0].length;break}}}if(!o){s+=t.slice(n);break}s+=t.slice(n,a);const d=a+c;let p=1,g=-1,u=-1;const k=/<\/?div\b[^>]*>/gi;k.lastIndex=d;let h;for(;(h=k.exec(t))!==null;)if(h[0].startsWith("</")){if(p--,p===0){g=h.index,u=h.index+h[0].length;break}}else p++;if(g!==-1&&u!==-1){const b=t.slice(d,g);s+=e(b),n=u}else s+=t.slice(a,d),n=d}return s}function za(t){const i=[];let e="",s=0;const n=/<div\b([^>]*)>/gi;for(;s<t.length;){n.lastIndex=s;let r,l=!1,o=-1,a=0;for(;(r=n.exec(t))!==null;){const h=r[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(h)){l=!0,o=r.index,a=r[0].length;break}}if(!l){e+=t.slice(s);break}e+=t.slice(s,o);const c=o+a;let d=1,p=-1,g=-1;const u=/<\/?div\b[^>]*>/gi;u.lastIndex=c;let k;for(;(k=u.exec(t))!==null;)if(k[0].startsWith("</")){if(d--,d===0){p=k.index,g=k.index+k[0].length;break}}else d++;if(p!==-1&&g!==-1){const h=t.slice(o,g),b=`__VUE_DIV_TOKEN_${i.length}__`;i.push(h),e+=b,s=g}else e+=t.slice(o,c),s=c}return{text:e,tokens:i}}function Na(t){const i=[];let e=t.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,o=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(o),a});e=e.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,o=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(o),a});const s=[];e=e.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,o=>{const a=`__SCRIPT_TOKEN_${s.length}__`;return s.push(o),a});const{text:n,tokens:r}=za(e);e=n;const l=[];e=e.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),e=e.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),e=e.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),e=e.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),e=e.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),e=e.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),e=e.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),e=e.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(o,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),e=e.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(o,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),e=e.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(o,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),e=e.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(o,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=bi(e,"diff-grid",o=>{const a=Array.from(o.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),p=c[3].trim();return`**${d}:**
\`\`\`yaml
${p}
\`\`\``}).join(`

`)+`
`:o}),e=bi(e,"before-after",o=>{const a=o.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=o.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:o}),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(o,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),e=bi(e,"timeline",o=>{const a=Array.from(o.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let p="-";return d.includes("warn")?p="- ⚠️":d.includes("bad")?p="- ❌":d.includes("ok")&&(p="- ✅"),`${p} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:o}),e=bi(e,"pipeline",o=>{const a=Array.from(o.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const g=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${g}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:o}),e=bi(e,"check-grid",o=>{const a=Array.from(o.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:o}),e=bi(e,"manifesto",o=>{const a=Array.from(o.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:o}),e=bi(e,"split-note",o=>{const a=Array.from(o.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:o}),e=e.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(o,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),e=e.replace(/<pre>([\s\S]*?)<\/pre>/gi,(o,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=e.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),e=e.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),e=e.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),e=e.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),e=e.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),e=e.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),e=e.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),e=e.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),e=e.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(o,a,c)=>/@|v-|:|class=/i.test(a)?o:`
${c.trim()}

`),e=e.replace(/<br\s*\/?>/gi,`
`),e=e.replace(/<hr\s*\/?>/gi,`
---
`),e=e.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),e=e.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),e=e.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),e=e.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(o,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((p,g)=>Math.max(p,g.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),e=e.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),e=e.replace(/\*{4}/g,"** **"),e=e.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),e=e.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),e=e.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(o,a,c,d,p)=>{const g=p.trim();return g.includes("<")||g.includes(`
`)?o:`[${g}](${c})`}),e=e.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(o,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),e=e.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(o,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),e=e.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(o,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),e=e.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),e=e.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),e=e.replace(/<\/?span\b[^>]*>/gi,"");for(let o=0;o<l.length;o++)e=e.replace(`__VUE_COMP_TOKEN_${o}__`,l[o]);for(let o=0;o<r.length;o++)e=e.replace(`__VUE_DIV_TOKEN_${o}__`,r[o]);for(let o=0;o<s.length;o++)e=e.replace(`__SCRIPT_TOKEN_${o}__`,s[o]);for(let o=0;o<i.length;o++)e=e.replace(`__CODE_TOKEN_${o}__`,i[o]);return e=e.replace(/\n{3,}/g,`

`).trim(),e}function Mr(t){if(!t||typeof t!="string")return"";const i=[];let e=t.replace(/`([^`]+)`/g,s=>(i.push(s),`%%INLINE_CODE_${i.length-1}%%`));return e=e.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),e=e.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),e=e.replace(/\{:[^}]*\}/g,""),e=e.replace(/%%INLINE_CODE_(\d+)%%/g,(s,n)=>i[parseInt(n,10)]||""),e}function Fa(t){const i=Object.entries(t).filter(([s,n])=>n!=null&&n!=="");return i.length===0?"":`---
${i.map(([s,n])=>typeof n=="string"?n.includes(":")||n.includes(`
`)||n.includes("#")?`${s}: "${n.replace(/"/g,'\\"')}"`:`${s}: ${n}`:`${s}: ${JSON.stringify(n)}`).join(`
`)}
---`}function ja(t,i){if(!i||!t.startsWith("```"))return t;const e=t.indexOf(`
`);if(e===-1)return t;const s=t.slice(0,e).trim(),n=t.slice(e);return s.includes("{")?t:`${s} {${i}}${n}`}function Ha(t,i){if(i==null)return t;const e=i.trim();return e===""||e==="+1"?`<v-click>

${t}

</v-click>`:e==="hide"?`<v-click hide>

${t}

</v-click>`:`<v-click at="${e}">

${t}

</v-click>`}function Ua(t){if(!t||!t.preset)return null;const i=t.preset.toLowerCase().trim();if(!i||i==="none")return null;let e={opacity:0},s={opacity:1};switch(i){case"slide-up":e={y:40,opacity:0},s={y:0,opacity:1};break;case"slide-down":e={y:-40,opacity:0},s={y:0,opacity:1};break;case"slide-left":e={x:40,opacity:0},s={x:0,opacity:1};break;case"slide-right":e={x:-40,opacity:0},s={x:0,opacity:1};break;case"zoom-in":case"pop":e={scale:.8,opacity:0},s={scale:1,opacity:1};break;case"bounce":e={y:40,opacity:0},s={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:e={opacity:0},s={opacity:1};break}t.initial&&typeof t.initial=="object"&&(e={...e,...t.initial}),t.enter&&typeof t.enter=="object"&&(s={...s,...t.enter});const n={...s.transition||{}};return typeof t.duration=="number"&&t.duration>0&&(n.duration=t.duration),typeof t.delay=="number"&&t.delay>0&&(n.delay=t.delay),Object.keys(n).length>0&&(s.transition=n),{initial:e,enter:s}}function ys(t,i,e,s){const n=i!=null&&i.trim()!=="",r=Ua(e),l=s==null?void 0:s.trim(),o=l!==void 0&&l!=="",a=o?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!n&&!r)return o?`<div${a}>

${t}

</div>`:t;if(n&&!r){if(o){const k=i.trim();let h="v-click";return k==="hide"?h="v-click.hide":k!==""&&k!=="+1"&&(h=`v-click="${k}"`),`<div ${h}${a}>

${t}

</div>`}return Ha(t,i)}const c=JSON.stringify(r.initial).replace(/"/g,"'"),d=JSON.stringify(r.enter).replace(/"/g,"'"),p=`v-motion :initial="${c}" :enter="${d}"`;if(!n)return`<div ${p}${a}>

${t}

</div>`;const g=i.trim();let u="v-click";return g==="hide"?u="v-click.hide":g!==""&&g!=="+1"&&(u=`v-click="${g}"`),`<div ${u} ${p}${a}>

${t}

</div>`}function Br(t){if(!t)return"";let i=t.trim();i=i.replace(/\{:[^}]*\}/g,"").trim(),i=i.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),i=i.replace(/\r?\n?:::\s*$/g,"");let n=i.split(/\r?\n/).map(r=>r.trim().replace(/^>\s*/,"")).join(`
`).trim();return n=n.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),n=n.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),n=n.replace(/^[-*+]\s+/,""),n=n.replace(/^\d+\.\s+/,""),n.trim()}function Wa(t){var s;if(t.subType&&/^h([1-6])$/i.test(t.subType))return parseInt(t.subType.slice(1),10);const e=(t.markdown||t.content||"").trim().match(/^(#{1,6})\s+/);return e?e[1].length:t.type==="h"?(s=t.ial)!=null&&s.subType&&/^h([1-6])$/i.test(t.ial.subType)?parseInt(t.ial.subType.slice(1),10):1:null}function Dr(t){if(!t||t.length===0)return{col1:[],col2:[],col3:[]};if(t.length===1&&t[0].children&&t[0].children.length>=2){const l=t[0].children;if(l.length>=3){const o=Math.ceil(l.length/3),a=Math.ceil((l.length-o)/2);return{col1:l.slice(0,o),col2:l.slice(o,o+a),col3:l.slice(o+a)}}else return{col1:[l[0]],col2:[l[1]],col3:[]}}const i=l=>{const o=l.slot||"";return o==="col-1"||o==="left"?1:o==="col-2"||o==="center"?2:o==="col-3"||o==="right"?3:null},e=t.map(i);if(e.some(l=>l!==null)){const l=e.includes(2),o=e.includes(3);if(l||o){const d=[],p=[],g=[];let u=1;for(const k of t){const h=i(k);h!==null&&(u=h),u===1?d.push(k):u===2?p.push(k):g.push(k)}return{col1:d,col2:p,col3:g}}const a=t.filter(d=>i(d)===1),c=t.filter(d=>i(d)===null);if(c.length>=2){const d=Math.ceil(c.length/2);return{col1:a,col2:c.slice(0,d),col3:c.slice(d)}}else return c.length===1?{col1:a,col2:c,col3:[]}:{col1:a,col2:[],col3:[]}}const n=l=>{if(l.type==="h"||l.subType&&/^h[1-6]$/i.test(l.subType))return!0;const o=(l.rawMarkdown||l.content||"").trim();return/^#{1,6}\s+/.test(o)},r=t.map((l,o)=>n(l)?o:-1).filter(l=>l!==-1);if(r.length>=3)return{col1:t.slice(0,r[1]),col2:t.slice(r[1],r[2]),col3:t.slice(r[2])};if(t.length>=3){const l=Math.ceil(t.length/3),o=Math.ceil((t.length-l)/2);return{col1:t.slice(0,l),col2:t.slice(l,l+o),col3:t.slice(l+o)}}if(t.length===2)return{col1:[t[0]],col2:[t[1]],col3:[]};if(t.length===1){const l=t[0],o=(l.rawMarkdown||l.content||"").trim(),a=o.split(/\r?\n/),c=[];for(let g=0;g<a.length;g++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(a[g])&&c.push(g);if(c.length>=3){const g=Math.ceil(c.length/3),u=Math.ceil((c.length-g)/2),k=a.slice(c[0],c[g]).join(`
`),h=a.slice(c[g],c[g+u]).join(`
`),b=a.slice(c[g+u]).join(`
`);return{col1:[{...l,rawMarkdown:k,content:k}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:h,content:h}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:b,content:b}]}}const d=o.match(/<li[\s\S]*?<\/li>/gi);if(d&&d.length>=3){const g=Math.ceil(d.length/3),u=Math.ceil((d.length-g)/2),k=`<ul>
${d.slice(0,g).join(`
`)}
</ul>`,h=`<ul>
${d.slice(g,g+u).join(`
`)}
</ul>`,b=`<ul>
${d.slice(g+u).join(`
`)}
</ul>`;return{col1:[{...l,rawMarkdown:k,content:k}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:h,content:h}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:b,content:b}]}}const p=o.split(/\r?\n\s*\r?\n/).filter(g=>g.trim()!=="");if(p.length>=3){const g=Math.ceil(p.length/3),u=Math.ceil((p.length-g)/2);return{col1:[{...l,rawMarkdown:p.slice(0,g).join(`

`),content:p.slice(0,g).join(`

`)}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:p.slice(g,g+u).join(`

`),content:p.slice(g,g+u).join(`

`)}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:p.slice(g+u).join(`

`),content:p.slice(g+u).join(`

`)}]}}}return{col1:t,col2:[],col3:[]}}function zo(t,i,e,s){var d;const n=wa(i),r=[],l=Lo(i);let o={pageIndex:1,startBlockId:t,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[t]};o.frontmatter.background&&(o.frontmatter.background=_e(o.frontmatter.background,s)),o.frontmatter.image&&(o.frontmatter.image=_e(o.frontmatter.image,s)),r.push(o);let a=[];for(const p of e){if(qn(p)){a=[];const u=Lo(p.ial);if(r.length===1&&o.blocks.length===0){o.startBlockId=p.id,o.allBlockIds||(o.allBlockIds=[]),o.allBlockIds.includes(p.id)||o.allBlockIds.push(p.id),u.frontmatter.layout&&(o.frontmatter.layout=u.frontmatter.layout),Object.assign(o.frontmatter,u.frontmatter),!u.frontmatter.image&&l.frontmatter.image&&(o.frontmatter.image=l.frontmatter.image),!u.frontmatter.background&&l.frontmatter.background&&(o.frontmatter.background=l.frontmatter.background),o.frontmatter.background&&(o.frontmatter.background=_e(o.frontmatter.background,s)),o.frontmatter.image&&(o.frontmatter.image=_e(o.frontmatter.image,s));continue}o={pageIndex:r.length+1,startBlockId:p.id,frontmatter:{layout:u.frontmatter.layout||"default",...u.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[p.id]},o.frontmatter.background&&(o.frontmatter.background=_e(o.frontmatter.background,s)),o.frontmatter.image&&(o.frontmatter.image=_e(o.frontmatter.image,s)),r.push(o);continue}const g=u=>{if(o.allBlockIds||(o.allBlockIds=[]),u.id&&!o.allBlockIds.includes(u.id)&&o.allBlockIds.push(u.id),u.children&&u.children.length>0){const D=y=>{for(const R of y)R.id&&!o.allBlockIds.includes(R.id)&&o.allBlockIds.push(R.id),R.children&&R.children.length>0&&D(R.children)};D(u.children)}let k=Ia(u),h=u.ial?{...u.ial}:{};const b=k.match(/\{:\s*([^}]+)\s*\}\s*$/);b&&(h={...Aa(b[0]),...h},k=k.slice(0,b.index).trim()),u.type!=="c"&&!k.startsWith("```")&&(k=Mr(k));let v=k.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(v)||v==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(v)&&/\r?\n\}\}\}$/.test(v)&&(k=v.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),v=k.trim());const w=xa(h);if(k=Ma(k,s),k=$a(k,s==null?void 0:s.refContentMap),u.children&&u.children.length>0){const D=y=>{for(const R of y){if(R.ial)for(const[Q,U]of Object.entries(R.ial))Q.startsWith("custom-slidev-")&&!h[Q]&&(h[Q]=U);R.children&&R.children.length>0&&D(R.children)}};D(u.children)}const $=u.type==="video"||u.type==="NodeVideo"||/<video\b/i.test(k);if($){const D=h["custom-slidev-autoplay"]==="true",y=h["custom-slidev-loop"]==="true",R=h["custom-slidev-muted"]==="true"||D,Q=h["custom-slidev-controls"]==="false";k=k.replace(/<video\b([^>]*)>/gi,(U,at)=>{let V=at;return Q?V=V.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(V)||(V+=" controls"),D&&!/autoplay/i.test(V)?V+=" autoplay playsinline":!D&&h["custom-slidev-autoplay"]==="false"&&(V=V.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),y&&!/loop/i.test(V)?V+=" loop":!y&&h["custom-slidev-loop"]==="false"&&(V=V.replace(/\bloop\b/gi,"").trim()),R&&!/muted/i.test(V)?V+=" muted":!R&&h["custom-slidev-muted"]==="false"&&(V=V.replace(/\bmuted\b/gi,"").trim()),`<video ${V.trim()}>`})}if(w.isBackground){const D=fi(k,u.content);if(D){o.frontmatter.background=_e(D,s);return}}const I=hi(u);if(I){o.frontmatter.layout=I.layout,o.frontmatter.image=_e(I.imageUrl,s);for(const D of I.contentNodes)g(D);return}if(w.imageLayout==="image-left"||w.imageLayout==="image-right"){const D=fi(k,u.content);if(D){o.frontmatter.layout=w.imageLayout,o.frontmatter.image=_e(D,s);return}}if(de(u)&&u.children&&u.children.length>0){for(const D of u.children)g(D);return}if((u.type==="l"||u.type==="NodeList"||u.type==="list")&&u.children&&u.children.length>0&&(u.children.some(D=>{var y;return(y=D.ial)==null?void 0:y[Tt]})||w.slot)){for(const D of u.children)w.slot&&(!D.ial||!D.ial[Tt])&&(D.ial||(D.ial={}),D.ial[Tt]=w.slot),g(D);return}if(w.isNote){const D=Br(k);D&&(o.notes?o.notes+=`

`+D:o.notes=D),o.noteBlocks||(o.noteBlocks=[]),o.noteBlocks.push({id:u.id,type:u.type,content:D||u.content||"",rawMarkdown:k,isNote:!0,attributes:u.ial});return}w.shikiLines&&(k=ja(k,w.shikiLines)),v=k.trim();const x=(u.content||"").trim();if(v==="::right::"||x==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(v)||v.startsWith("::right::")){o.blocks.push({id:u.id,type:u.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:u.ial});return}const A=Wa(u);let M=w.slot,P=w.clicks,N=w.motion,X={...u.ial||{}};if(A!==null){for(;a.length>0&&a[a.length-1].level>=A;)a.pop();const D=a.length>0?a[a.length-1]:void 0;!M&&(D!=null&&D.slot)&&(M=D.slot),!P&&(D!=null&&D.clicks)&&(P=D.clicks),!N&&(D!=null&&D.motion)&&(N=D.motion);const y={...(D==null?void 0:D.customAttrs)||{}};if(u.ial)for(const[R,Q]of Object.entries(u.ial))R.startsWith("custom-slidev-")&&!R.startsWith("custom-slidev-slide")&&(y[R]=Q);a.push({level:A,slot:M,clicks:P,motion:N,customAttrs:y})}else{const D=a.length>0?a[a.length-1]:void 0;D&&(!M&&D.slot&&D.slot!=="header"&&(M=D.slot),!P&&D.clicks&&(P=D.clicks),!N&&D.motion&&(N=D.motion),D.customAttrs&&(X={...D.customAttrs,...X}))}!M&&o.blocks.some(D=>D.slot==="slot-divider-right")&&(M="right"),M&&(X[Tt]=M),P&&!X[Se]&&(X[Se]=P),N&&!X[He]&&(X[He]=JSON.stringify(N)),($||h["custom-slidev-autoplay"]||h["custom-slidev-muted"])&&(h["custom-slidev-autoplay"]&&(X["custom-slidev-autoplay"]=h["custom-slidev-autoplay"],h["custom-slidev-autoplay"]==="true"&&!h["custom-slidev-muted"]&&(X["custom-slidev-muted"]="true")),h["custom-slidev-loop"]&&(X["custom-slidev-loop"]=h["custom-slidev-loop"]),h["custom-slidev-muted"]&&(X["custom-slidev-muted"]=h["custom-slidev-muted"]),h["custom-slidev-controls"]&&(X["custom-slidev-controls"]=h["custom-slidev-controls"]));const T={id:u.id,type:u.type,content:u.content||"",rawMarkdown:k,clicks:P,motion:N,shikiLines:w.shikiLines,slot:M,attributes:X};o.blocks.push(T)};g(p)}for(let p=0;p<r.length;p++){const g=r[p],u=[],k={...g.frontmatter};p===0&&(k.theme=n.theme,k.aspectRatio=n.aspectRatio,k.highlighter=n.highlighter,k.transition=g.frontmatter.transition||n.defaultTransition);const h=Fa(k);h&&u.push(h);const b=g.blocks.filter(I=>I.slot!=="slot-divider-right"),v=I=>I.map(x=>{var C;return ys(x.rawMarkdown,x.clicks,x.motion,(C=x.attributes)==null?void 0:C.style)}).join(`

`),w=I=>{var x;if(I.length===0)return"";if(I.length===1&&Ki(I[0])){const C=Ns(I[0].rawMarkdown);return ys(C,I[0].clicks,I[0].motion,(x=I[0].attributes)==null?void 0:x.style)}return v(I)},$=g.frontmatter.layout||"default";if($==="two-cols-header"){let I=[];const x=b.filter(T=>T.slot==="header");if(x.length>0)I=x;else if(b.length>0){const T=b.find(D=>D.type==="h"&&(!D.slot||D.slot==="default"));T&&(I=[T])}const C=b.filter(T=>!I.includes(T)),A=C.filter(T=>T.slot==="right"||T.slot==="col-2"),M=C.filter(T=>!A.includes(T)),P=v(I),N=w(M),X=w(A);P&&u.push(P),N&&u.push(`::left::

${N}`),X&&u.push(`::right::

${X}`)}else if($==="three-cols-header"){let I=[];const x=b.filter(R=>R.slot==="header");if(x.length>0)I=x;else if(b.length>0){const R=b.find(Q=>Q.type==="h"&&(!Q.slot||Q.slot==="default"));R&&(I=[R])}const C=b.filter(R=>!I.includes(R)),A=Dr(C),M=A.col1,P=A.col2,N=A.col3;for(const R of M)R.slot||(R.slot="col-1");for(const R of P)R.slot||(R.slot="col-2");for(const R of N)R.slot||(R.slot="col-3");if(C.length===1&&(P.length>0||N.length>0)){const R=g.blocks.findIndex(Q=>Q.id===C[0].id);R!==-1&&g.blocks.splice(R,1,...M,...P,...N)}const X=v(I),T=w(M),D=w(P),y=w(N);X&&u.push(X),T&&u.push(`::col-1::

${T}`),D&&u.push(`::col-2::

${D}`),y&&u.push(`::col-3::

${y}`)}else if($==="two-cols"){const I=b.filter(M=>M.slot==="left"),x=b.filter(M=>M.slot==="right"),C=v(I.length>0?I:b.filter(M=>M.slot!=="right")),A=v(x);u.push(C),A&&u.push(`::right::

${A}`)}else for(const I of b)u.push(ys(I.rawMarkdown,I.clicks,I.motion,(d=I.attributes)==null?void 0:d.style));g.notes&&u.push(`<!--
${g.notes}
-->`),g.rawMarkdown=u.join(`

`).trim()}const c=r.map(p=>p.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:t,config:n,slides:r,fullMarkdown:c}}const Fs=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function Va(t){var n,r,l,o,a,c,d,p,g,u,k,h;if(!t||typeof t!="object")return"";const i=[],e=[];if(Array.isArray(t.styles))for(const b of t.styles){if(!b||!b.id)continue;const v=`--b3-inline-style-${b.id}`;(n=b.light)!=null&&n.color&&i.push(`  ${v}-color: ${b.light.color};`),(r=b.light)!=null&&r.backgroundColor&&i.push(`  ${v}-background-color: ${b.light.backgroundColor};`),(l=b.dark)!=null&&l.color&&e.push(`  ${v}-color: ${b.dark.color};`),(o=b.dark)!=null&&o.backgroundColor&&e.push(`  ${v}-background-color: ${b.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.colors))for(const b of t.builtin.colors){if(!b||typeof b.index!="number")continue;const v=b.index;(a=b.light)!=null&&a.color&&i.push(`  --b3-font-color${v}: ${b.light.color};`),(c=b.light)!=null&&c.backgroundColor&&i.push(`  --b3-font-background${v}: ${b.light.backgroundColor};`),(d=b.dark)!=null&&d.color&&e.push(`  --b3-font-color${v}: ${b.dark.color};`),(p=b.dark)!=null&&p.backgroundColor&&e.push(`  --b3-font-background${v}: ${b.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.styles))for(const b of t.builtin.styles){if(!b||!b.id)continue;const v=b.id;(g=b.light)!=null&&g.color&&i.push(`  --b3-card-${v}-color: ${b.light.color};`),(u=b.light)!=null&&u.backgroundColor&&i.push(`  --b3-card-${v}-background: ${b.light.backgroundColor};`),(k=b.dark)!=null&&k.color&&e.push(`  --b3-card-${v}-color: ${b.dark.color};`),(h=b.dark)!=null&&h.backgroundColor&&e.push(`  --b3-card-${v}-background: ${b.dark.backgroundColor};`)}if(i.length===0&&e.length===0)return"";const s=[];return i.length>0&&s.push(`:root, html:not(.dark), [data-theme="light"] {
${i.join(`
`)}
}`),e.length>0&&s.push(`html.dark, [data-theme="dark"], .dark {
${e.join(`
`)}
}`),s.join(`

`)}function dn(t){const i=Va(t);return i?`${Fs}

/* Custom Workspace Inline Styles */
${i}`:Fs}function ks(t){const i={};if(!t||typeof t!="string")return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),s=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let n;for(;(n=s.exec(e))!==null;){const r=n[1],l=n[2]??n[3]??n[4]??"";i[r]=l}return i}const Ka={getBlockAttrs:Ge,getChildBlocks:Kn,setBlockAttrs:zt,sql:gn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:ka};class qa{constructor(i){wt(this,"deps");wt(this,"attrOverrides",new Map);wt(this,"trackedListSuperBlocks",new Map);this.deps={...Ka,...i||{}}}setBlockAttrOverride(i,e){if(!i||!e)return;const n={...this.attrOverrides.get(i)||{}};for(const[r,l]of Object.entries(e))l===""||l===null||l===void 0?delete n[r]:n[r]=String(l);Object.keys(n).length===0?this.attrOverrides.delete(i):this.attrOverrides.set(i,n)}getBlockAttrOverride(i){return this.attrOverrides.get(i)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(i){return this.trackedListSuperBlocks.get(i)||[]}clearBlockAttrOverride(i,e){if(!i)return;if(!e){this.attrOverrides.delete(i);return}const s=this.attrOverrides.get(i);s&&(delete s[e],Object.keys(s).length===0&&this.attrOverrides.delete(i))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(i){try{const e=await this.deps.getBlockAttrs(i).catch(()=>({}))||{},s=this.attrOverrides.get(i);s&&Object.assign(e,s);let n=await this.deps.getChildBlocks(i).catch(()=>[]);const r=`SELECT id, ial FROM blocks WHERE root_id = '${i}' LIMIT 99999`,l=await this.deps.sql(r).catch(()=>[])||[],o=new Map;if(Array.isArray(l))for(const $ of l)$.id&&$.ial&&o.set($.id,ks($.ial));const a=`SELECT block_id, name, value FROM attributes WHERE root_id = '${i}' AND type = 'b' LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[];if(Array.isArray(c)){for(const $ of c)if($.block_id&&$.name){let I=o.get($.block_id);I||(I={},o.set($.block_id,I)),I[$.name]=$.value||""}}if(!n||n.length===0){const $=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE root_id = '${i}' AND id != '${i}' ORDER BY created ASC LIMIT 99999`;n=await this.deps.sql($).catch(()=>[])||[]}const d=(n||[]).map($=>{const I=o.get($.id)||($.ial?ks($.ial):{}),x=this.attrOverrides.get($.id);return x&&Object.assign(I,x),{id:$.id,parent_id:$.parent_id,root_id:$.root_id||i,type:$.type,subType:$.subType,content:$.content||"",markdown:$.markdown||"",ial:I,children:$.children}}),p=async($,I=0)=>{if(!(!$||$.length===0||I>8))for(const x of $){if((de(x)||x.type==="l"||x.type==="NodeList"||x.type==="i"||x.type==="NodeListItem"||x.type==="b"||x.type==="NodeBlockquote")&&(!x.children||x.children.length===0)){let A=await this.deps.getChildBlocks(x.id).catch(()=>[]);if(!A||A.length===0){const M=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE parent_id = '${x.id}' ORDER BY sort ASC, created ASC`;A=await this.deps.sql(M).catch(()=>[])||[]}Array.isArray(A)&&A.length>0&&(x.children=A.map(M=>{const P=o.get(M.id)||(M.ial?ks(M.ial):{}),N=this.attrOverrides.get(M.id);return N&&Object.assign(P,N),{id:M.id,parent_id:M.parent_id||x.id,root_id:M.root_id||i,type:M.type,subType:M.subType,content:M.content||"",markdown:M.markdown||"",ial:P}}))}x.children&&x.children.length>0&&await p(x.children,I+1)}};await p(d);const g=$=>{var I,x;for(const C of $)if(C.children&&C.children.length>0){g(C.children);for(const A of C.children)if(A.ial)for(const[M,P]of Object.entries(A.ial))M.startsWith("custom-slidev-")&&!((I=C.ial)!=null&&I[M])&&(C.ial||(C.ial={}),C.ial[M]=P);if(C.ial){for(const[A,M]of Object.entries(C.ial))if(A.startsWith("custom-slidev-"))for(const P of C.children)(P.type==="video"||P.type==="NodeVideo"||/<video\b/i.test(P.markdown||P.content||""))&&!((x=P.ial)!=null&&x[A])&&(P.ial||(P.ial={}),P.ial[A]=M)}}};g(d),Ba(d,$=>{this.setBlockAttrOverride($.blockId,{[ft]:$.layout}),(this.deps.setBlockAttrs||zt)($.blockId,{[ft]:$.layout}).catch(x=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",x)})});const u=this.trackedListSuperBlocks.get(i)||[],k=Ra(i,d,{tracked:u,onTagChange:$=>{this.setBlockAttrOverride($.blockId,$.attrs),$.blockId===i&&Object.assign(e,$.attrs);const I=C=>{for(const A of C)A.id===$.blockId&&(A.ial||(A.ial={}),Object.assign(A.ial,$.attrs)),A.children&&A.children.length>0&&I(A.children)};I(d),(this.deps.setBlockAttrs||zt)($.blockId,$.attrs).catch(C=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",C)})}});this.trackedListSuperBlocks.set(i,k.newTracked);const h=new Set;for(const $ of d){const I=$.markdown||$.content||"";if(I.includes("((")){const x=Ca(I);for(const C of x)h.add(C.blockId)}}const b={};if(h.size>0){const $=Array.from(h).map(x=>`'${x}'`).join(","),I=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${$})`).catch(()=>[])||[];if(Array.isArray(I))for(const x of I)x.id&&(b[x.id]=x.markdown||x.content||"")}const v=this.deps.getBaseUrl?this.deps.getBaseUrl():"",w=zo(i,e,d,{baseUrl:v,refContentMap:b});try{const $=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;w.customThemeCss=dn($)}catch{w.customThemeCss=dn(null)}return w}catch(e){console.error("[DocumentCompilerService] Failed to compile document:",e);const s=zo(i,{},[],{});return s.customThemeCss=dn(null),s}}}const Ht=new qa;class eo{constructor(i){wt(this,"devServerUrl","http://localhost:3030");wt(this,"isConnected",!1);wt(this,"lastSyncTime",null);i&&(this.devServerUrl=i)}getUrl(){return this.devServerUrl}setUrl(i){this.devServerUrl=i.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(i=1500){try{const e=new AbortController,s=setTimeout(()=>e.abort(),i),n=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:e.signal}).catch(()=>null);return clearTimeout(s),this.isConnected=!!n,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(i){const e=i.config,s=["---",`theme: ${e.theme||"default"}`,`aspectRatio: "${e.aspectRatio||"16/9"}"`,`highlighter: ${e.highlighter||"shiki"}`,`transition: ${e.defaultTransition||"slide-left"}`];e.colorSchema&&e.colorSchema!=="auto"&&s.push(`colorSchema: ${e.colorSchema}`),s.push("drawings:","  persist: false","---","");const n=s.join(`
`),r=i.slides.map((l,o)=>{const a=l.frontmatter||{},c=[],d=o===0;a.layout&&a.layout!=="default"&&c.push(`layout: ${a.layout}`),a.transition&&c.push(`transition: ${a.transition}`),a.background&&c.push(`background: ${a.background}`),a.class&&c.push(`class: "${a.class}"`);let p="";c.length>0?p=d?"":`---
${c.join(`
`)}
---

`:d||(p=`---

`);let g="";if(a.layout==="two-cols"){const k=l.blocks.filter(w=>w.slot!=="right"),h=l.blocks.filter(w=>w.slot==="right"),b=k.map(w=>w.rawMarkdown||w.content||"").join(`

`),v=h.map(w=>w.rawMarkdown||w.content||"").join(`

`);g=`${b}

::right::

${v}`}else g=l.blocks.map(k=>k.rawMarkdown||k.content||"").join(`

`);let u="";return l.notes&&l.notes.trim()&&(u=`

<!--
${l.notes.trim()}
-->`),`${p}${g}${u}`}).join(`

`);return`${n}${r}
`}async syncToWorkspaceFile(i,e="/data/storage/petal/siyuan-slidev/slides.md",s){const n=this.buildStandardSlidevMarkdown(i);if(this.lastSyncTime=Date.now(),s)try{const r=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8");return await s(e,!1,r),{success:!0,path:e}}catch(r){return{success:!1,path:e,error:String(r)}}return{success:!0,path:e}}downloadSlidesMd(i,e="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const s=this.buildStandardSlidevMarkdown(i),n=new Blob([s],{type:"text/markdown;charset=utf-8"}),r=URL.createObjectURL(n),l=document.createElement("a");return l.href=r,l.download=e,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(r),!0}}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function io(t){const i=Object.create(null);for(const e of t.split(","))i[e]=1;return e=>e in i}const Wt={},Fi=[],Ve=()=>{},Or=()=>!1,ns=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&(t.charCodeAt(2)>122||t.charCodeAt(2)<97),ss=t=>t.startsWith("onUpdate:"),re=Object.assign,no=(t,i)=>{const e=t.indexOf(i);e>-1&&t.splice(e,1)},Ga=Object.prototype.hasOwnProperty,Rt=(t,i)=>Ga.call(t,i),Ct=Array.isArray,ji=t=>Sn(t)==="[object Map]",Ji=t=>Sn(t)==="[object Set]",No=t=>Sn(t)==="[object Date]",It=t=>typeof t=="function",Qt=t=>typeof t=="string",De=t=>typeof t=="symbol",jt=t=>t!==null&&typeof t=="object",Pr=t=>(jt(t)||It(t))&&It(t.then)&&It(t.catch),Lr=Object.prototype.toString,Sn=t=>Lr.call(t),Za=t=>Sn(t).slice(8,-1),Rr=t=>Sn(t)==="[object Object]",so=t=>Qt(t)&&t!=="NaN"&&t[0]!=="-"&&""+parseInt(t,10)===t,un=io(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),os=t=>{const i=Object.create(null);return(e=>i[e]||(i[e]=t(e)))},Ya=/-\w/g,pe=os(t=>t.replace(Ya,i=>i.slice(1).toUpperCase())),Ja=/\B([A-Z])/g,pi=os(t=>t.replace(Ja,"-$1").toLowerCase()),rs=os(t=>t.charAt(0).toUpperCase()+t.slice(1)),ws=os(t=>t?`on${rs(t)}`:""),Ue=(t,i)=>!Object.is(t,i),jn=(t,...i)=>{for(let e=0;e<t.length;e++)t[e](...i)},zr=(t,i,e,s=!1)=>{Object.defineProperty(t,i,{configurable:!0,enumerable:!1,writable:s,value:e})},ls=t=>{const i=parseFloat(t);return isNaN(i)?t:i};let Fo;const as=()=>Fo||(Fo=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function oo(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++){const s=t[e],n=Qt(s)?ec(s):oo(s);if(n)for(const r in n)i[r]=n[r]}return i}else if(Qt(t)||jt(t))return t}const Xa=/;(?![^(]*\))/g,Qa=/:([^]+)/,tc=/\/\*[^]*?\*\//g;function ec(t){const i={};return t.replace(tc,"").split(Xa).forEach(e=>{if(e){const s=e.split(Qa);s.length>1&&(i[s[0].trim()]=s[1].trim())}}),i}function Et(t){let i="";if(Qt(t))i=t;else if(Ct(t))for(let e=0;e<t.length;e++){const s=Et(t[e]);s&&(i+=s+" ")}else if(jt(t))for(const e in t)t[e]&&(i+=e+" ");return i.trim()}const ic="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",nc=io(ic);function Nr(t){return!!t||t===""}function sc(t,i){if(t.length!==i.length)return!1;let e=!0;for(let s=0;e&&s<t.length;s++)e=Xi(t[s],i[s]);return e}function Xi(t,i){if(t===i)return!0;let e=No(t),s=No(i);if(e||s)return e&&s?t.getTime()===i.getTime():!1;if(e=De(t),s=De(i),e||s)return t===i;if(e=Ct(t),s=Ct(i),e||s)return e&&s?sc(t,i):!1;if(e=jt(t),s=jt(i),e||s){if(!e||!s)return!1;const n=Object.keys(t).length,r=Object.keys(i).length;if(n!==r)return!1;for(const l in t){const o=t.hasOwnProperty(l),a=i.hasOwnProperty(l);if(o&&!a||!o&&a||!Xi(t[l],i[l]))return!1}}return String(t)===String(i)}function ro(t,i){return t.findIndex(e=>Xi(e,i))}const Fr=t=>!!(t&&t.__v_isRef===!0),St=t=>Qt(t)?t:t==null?"":Ct(t)||jt(t)&&(t.toString===Lr||!It(t.toString))?Fr(t)?St(t.value):JSON.stringify(t,jr,2):String(t),jr=(t,i)=>Fr(i)?jr(t,i.value):ji(i)?{[`Map(${i.size})`]:[...i.entries()].reduce((e,[s,n],r)=>(e[xs(s,r)+" =>"]=n,e),{})}:Ji(i)?{[`Set(${i.size})`]:[...i.values()].map(e=>xs(e))}:De(i)?xs(i):jt(i)&&!Ct(i)&&!Rr(i)?String(i):i,xs=(t,i="")=>{var e;return De(t)?`Symbol(${(e=t.description)!=null?e:i})`:t};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let ne;class oc{constructor(i=!1){this.detached=i,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!i&&ne&&(ne.active?(this.parent=ne,this.index=(ne.scopes||(ne.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let i,e;if(this.scopes){const s=this.scopes.slice();for(i=0,e=s.length;i<e;i++)s[i].pause()}for(i=0,e=this.effects.length;i<e;i++)this.effects[i].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let i,e;if(this.scopes){const n=this.scopes.slice();for(i=0,e=n.length;i<e;i++)n[i].resume()}const s=this.effects.slice();for(i=0,e=s.length;i<e;i++)s[i].resume()}}run(i){if(this._active){const e=ne;try{return ne=this,i()}finally{ne=e}}}on(){++this._on===1&&(this.prevScope=ne,ne=this)}off(){if(this._on>0&&--this._on===0){if(ne===this)ne=this.prevScope;else{let i=ne;for(;i;){if(i.prevScope===this){i.prevScope=this.prevScope;break}i=i.prevScope}}this.prevScope=void 0}}stop(i){if(this._active){this._active=!1;let e,s;for(e=0,s=this.effects.length;e<s;e++)this.effects[e].stop();for(this.effects.length=0,e=0,s=this.cleanups.length;e<s;e++)this.cleanups[e]();if(this.cleanups.length=0,this.scopes){const n=this.scopes.slice();for(e=0,s=n.length;e<s;e++)n[e].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!i){const n=this.parent.scopes.pop();n&&n!==this&&(this.parent.scopes[this.index]=n,n.index=this.index)}this.parent=void 0}}}function rc(){return ne}let Kt;const _s=new WeakSet;class Hr{constructor(i){this.fn=i,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,ne&&(ne.active?ne.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,_s.has(this)&&(_s.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Wr(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,jo(this),Vr(this);const i=Kt,e=Be;Kt=this,Be=!0;try{return this.fn()}finally{Kr(this),Kt=i,Be=e,this.flags&=-3}}stop(){if(this.flags&1){for(let i=this.deps;i;i=i.nextDep)co(i);this.deps=this.depsTail=void 0,jo(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?_s.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){js(this)&&this.run()}get dirty(){return js(this)}}let Ur=0,fn,hn;function Wr(t,i=!1){if(t.flags|=8,i){t.next=hn,hn=t;return}t.next=fn,fn=t}function lo(){Ur++}function ao(){if(--Ur>0)return;if(hn){let i=hn;for(hn=void 0;i;){const e=i.next;i.next=void 0,i.flags&=-9,i=e}}let t;for(;fn;){let i=fn;for(fn=void 0;i;){const e=i.next;if(i.next=void 0,i.flags&=-9,i.flags&1)try{i.trigger()}catch(s){t||(t=s)}i=e}}if(t)throw t}function Vr(t){for(let i=t.deps;i;i=i.nextDep)i.version=-1,i.prevActiveLink=i.dep.activeLink,i.dep.activeLink=i}function Kr(t){let i,e=t.depsTail,s=e;for(;s;){const n=s.prevDep;s.version===-1?(s===e&&(e=n),co(s),lc(s)):i=s,s.dep.activeLink=s.prevActiveLink,s.prevActiveLink=void 0,s=n}t.deps=i,t.depsTail=e}function js(t){for(let i=t.deps;i;i=i.nextDep)if(i.dep.version!==i.version||i.dep.computed&&(qr(i.dep.computed)||i.dep.version!==i.version))return!0;return!!t._dirty}function qr(t){if(t.flags&4&&!(t.flags&16)||(t.flags&=-17,t.globalVersion===vn)||(t.globalVersion=vn,!t.isSSR&&t.flags&128&&(!t.deps&&!t._dirty||!js(t))))return;t.flags|=2;const i=t.dep,e=Kt,s=Be;Kt=t,Be=!0;try{Vr(t);const n=t.fn(t._value);(i.version===0||Ue(n,t._value))&&(t.flags|=128,t._value=n,i.version++)}catch(n){throw i.version++,n}finally{Kt=e,Be=s,Kr(t),t.flags&=-3}}function co(t,i=!1){const{dep:e,prevSub:s,nextSub:n}=t;if(s&&(s.nextSub=n,t.prevSub=void 0),n&&(n.prevSub=s,t.nextSub=void 0),e.subs===t&&(e.subs=s,!s&&e.computed)){e.computed.flags&=-5;for(let r=e.computed.deps;r;r=r.nextDep)co(r,!0)}!i&&!--e.sc&&e.map&&e.map.delete(e.key)}function lc(t){const{prevDep:i,nextDep:e}=t;i&&(i.nextDep=e,t.prevDep=void 0),e&&(e.prevDep=i,t.nextDep=void 0)}let Be=!0;const Gr=[];function ii(){Gr.push(Be),Be=!1}function ni(){const t=Gr.pop();Be=t===void 0?!0:t}function jo(t){const{cleanup:i}=t;if(t.cleanup=void 0,i){const e=Kt;Kt=void 0;try{i()}finally{Kt=e}}}let vn=0;class ac{constructor(i,e){this.sub=i,this.dep=e,this.version=e.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class uo{constructor(i){this.computed=i,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(i){if(!Kt||!Be||Kt===this.computed)return;let e=this.activeLink;if(e===void 0||e.sub!==Kt)e=this.activeLink=new ac(Kt,this),Kt.deps?(e.prevDep=Kt.depsTail,Kt.depsTail.nextDep=e,Kt.depsTail=e):Kt.deps=Kt.depsTail=e,Zr(e);else if(e.version===-1&&(e.version=this.version,e.nextDep)){const s=e.nextDep;s.prevDep=e.prevDep,e.prevDep&&(e.prevDep.nextDep=s),e.prevDep=Kt.depsTail,e.nextDep=void 0,Kt.depsTail.nextDep=e,Kt.depsTail=e,Kt.deps===e&&(Kt.deps=s)}return e}trigger(i){this.version++,vn++,this.notify(i)}notify(i){lo();try{for(let e=this.subs;e;e=e.prevSub)e.sub.notify()&&e.sub.dep.notify()}finally{ao()}}}function Zr(t){if(t.dep.sc++,t.sub.flags&4){const i=t.dep.computed;if(i&&!t.dep.subs){i.flags|=20;for(let s=i.deps;s;s=s.nextDep)Zr(s)}const e=t.dep.subs;e!==t&&(t.prevSub=e,e&&(e.nextSub=t)),t.dep.subs=t}}const Hs=new WeakMap,Ii=Symbol(""),Us=Symbol(""),bn=Symbol("");function ae(t,i,e){if(Be&&Kt){let s=Hs.get(t);s||Hs.set(t,s=new Map);let n=s.get(e);n||(s.set(e,n=new uo),n.map=s,n.key=e),n.track()}}function Je(t,i,e,s,n,r){const l=Hs.get(t);if(!l){vn++;return}const o=a=>{a&&a.trigger()};if(lo(),i==="clear")l.forEach(o);else{const a=Ct(t),c=a&&so(e);if(a&&e==="length"){const d=Number(s);l.forEach((p,g)=>{(g==="length"||g===bn||!De(g)&&g>=d)&&o(p)})}else switch((e!==void 0||l.has(void 0))&&o(l.get(e)),c&&o(l.get(bn)),i){case"add":a?c&&o(l.get("length")):(o(l.get(Ii)),ji(t)&&o(l.get(Us)));break;case"delete":a||(o(l.get(Ii)),ji(t)&&o(l.get(Us)));break;case"set":ji(t)&&o(l.get(Ii));break}}ao()}function Li(t){const i=Lt(t);return i===t?i:(ae(i,"iterate",bn),Ce(t)?i:i.map(Oe))}function cs(t){return ae(t=Lt(t),"iterate",bn),t}function Fe(t,i){return si(t)?qi(Ai(t)?Oe(i):i):Oe(i)}const cc={__proto__:null,[Symbol.iterator](){return Ss(this,Symbol.iterator,t=>Fe(this,t))},concat(...t){return Li(this).concat(...t.map(i=>Ct(i)?Li(i):i))},entries(){return Ss(this,"entries",t=>(t[1]=Fe(this,t[1]),t))},every(t,i){return qe(this,"every",t,i,void 0,arguments)},filter(t,i){return qe(this,"filter",t,i,e=>e.map(s=>Fe(this,s)),arguments)},find(t,i){return qe(this,"find",t,i,e=>Fe(this,e),arguments)},findIndex(t,i){return qe(this,"findIndex",t,i,void 0,arguments)},findLast(t,i){return qe(this,"findLast",t,i,e=>Fe(this,e),arguments)},findLastIndex(t,i){return qe(this,"findLastIndex",t,i,void 0,arguments)},forEach(t,i){return qe(this,"forEach",t,i,void 0,arguments)},includes(...t){return Cs(this,"includes",t)},indexOf(...t){return Cs(this,"indexOf",t)},join(t){return Li(this).join(t)},lastIndexOf(...t){return Cs(this,"lastIndexOf",t)},map(t,i){return qe(this,"map",t,i,void 0,arguments)},pop(){return Qi(this,"pop")},push(...t){return Qi(this,"push",t)},reduce(t,...i){return Ho(this,"reduce",t,i)},reduceRight(t,...i){return Ho(this,"reduceRight",t,i)},shift(){return Qi(this,"shift")},some(t,i){return qe(this,"some",t,i,void 0,arguments)},splice(...t){return Qi(this,"splice",t)},toReversed(){return Li(this).toReversed()},toSorted(t){return Li(this).toSorted(t)},toSpliced(...t){return Li(this).toSpliced(...t)},unshift(...t){return Qi(this,"unshift",t)},values(){return Ss(this,"values",t=>Fe(this,t))}};function Ss(t,i,e){const s=cs(t),n=s[i]();return s!==t&&!Ce(t)&&(n._next=n.next,n.next=()=>{const r=n._next();return r.done||(r.value=e(r.value)),r}),n}const dc=Array.prototype;function qe(t,i,e,s,n,r){const l=cs(t),o=l!==t&&!Ce(t),a=l[i];if(a!==dc[i]){const p=a.apply(t,r);return o?Oe(p):p}let c=e;l!==t&&(o?c=function(p,g){return e.call(this,Fe(t,p),g,t)}:e.length>2&&(c=function(p,g){return e.call(this,p,g,t)}));const d=a.call(l,c,s);return o&&n?n(d):d}function Ho(t,i,e,s){const n=cs(t),r=n!==t&&!Ce(t);let l=e,o=!1;n!==t&&(r?(o=s.length===0,l=function(c,d,p){return o&&(o=!1,c=Fe(t,c)),e.call(this,c,Fe(t,d),p,t)}):e.length>3&&(l=function(c,d,p){return e.call(this,c,d,p,t)}));const a=n[i](l,...s);return o?Fe(t,a):a}function Cs(t,i,e){const s=Lt(t);ae(s,"iterate",bn);const n=s[i](...e);return(n===-1||n===!1)&&po(e[0])?(e[0]=Lt(e[0]),s[i](...e)):n}function Qi(t,i,e=[]){ii(),lo();const s=Lt(t)[i].apply(t,e);return ao(),ni(),s}const uc=io("__proto__,__v_isRef,__isVue"),Yr=new Set(Object.getOwnPropertyNames(Symbol).filter(t=>t!=="arguments"&&t!=="caller").map(t=>Symbol[t]).filter(De));function fc(t){De(t)||(t=String(t));const i=Lt(this);return ae(i,"has",t),i.hasOwnProperty(t)}class Jr{constructor(i=!1,e=!1){this._isReadonly=i,this._isShallow=e}get(i,e,s){if(e==="__v_skip")return i.__v_skip;const n=this._isReadonly,r=this._isShallow;if(e==="__v_isReactive")return!n;if(e==="__v_isReadonly")return n;if(e==="__v_isShallow")return r;if(e==="__v_raw")return s===(n?r?xc:el:r?tl:Qr).get(i)||Object.getPrototypeOf(i)===Object.getPrototypeOf(s)?i:void 0;const l=Ct(i);if(!n){let a;if(l&&(a=cc[e]))return a;if(e==="hasOwnProperty")return fc}const o=Reflect.get(i,e,ue(i)?i:s);if((De(e)?Yr.has(e):uc(e))||(n||ae(i,"get",e),r))return o;if(ue(o)){const a=l&&so(e)?o:o.value;return n&&jt(a)?Vs(a):a}return jt(o)?n?Vs(o):ds(o):o}}class Xr extends Jr{constructor(i=!1){super(!1,i)}set(i,e,s,n){let r=i[e];const l=Ct(i)&&so(e);if(!this._isShallow){const c=si(r);if(!Ce(s)&&!si(s)&&(r=Lt(r),s=Lt(s)),!l&&ue(r)&&!ue(s))return c||(r.value=s),!0}const o=l?Number(e)<i.length:Rt(i,e),a=Reflect.set(i,e,s,ue(i)?i:n);return i===Lt(n)&&a&&(o?Ue(s,r)&&Je(i,"set",e,s):Je(i,"add",e,s)),a}deleteProperty(i,e){const s=Rt(i,e);i[e];const n=Reflect.deleteProperty(i,e);return n&&s&&Je(i,"delete",e,void 0),n}has(i,e){const s=Reflect.has(i,e);return(!De(e)||!Yr.has(e))&&ae(i,"has",e),s}ownKeys(i){return ae(i,"iterate",Ct(i)?"length":Ii),Reflect.ownKeys(i)}}class hc extends Jr{constructor(i=!1){super(!0,i)}set(i,e){return!0}deleteProperty(i,e){return!0}}const pc=new Xr,mc=new hc,gc=new Xr(!0);const Ws=t=>t,Dn=t=>Reflect.getPrototypeOf(t);function vc(t,i,e){return function(...s){const n=this.__v_raw,r=Lt(n),l=ji(r),o=t==="entries"||t===Symbol.iterator&&l,a=t==="keys"&&l,c=n[t](...s),d=e?Ws:i?qi:Oe;return!i&&ae(r,"iterate",a?Us:Ii),re(Object.create(c),{next(){const{value:p,done:g}=c.next();return g?{value:p,done:g}:{value:o?[d(p[0]),d(p[1])]:d(p),done:g}}})}}function On(t){return function(...i){return t==="delete"?!1:t==="clear"?void 0:this}}function bc(t,i){const e={get(n){const r=this.__v_raw,l=Lt(r),o=Lt(n);t||(Ue(n,o)&&ae(l,"get",n),ae(l,"get",o));const{has:a}=Dn(l),c=i?Ws:t?qi:Oe;if(a.call(l,n))return c(r.get(n));if(a.call(l,o))return c(r.get(o));r!==l&&r.get(n)},get size(){const n=this.__v_raw;return!t&&ae(Lt(n),"iterate",Ii),n.size},has(n){const r=this.__v_raw,l=Lt(r),o=Lt(n);return t||(Ue(n,o)&&ae(l,"has",n),ae(l,"has",o)),n===o?r.has(n):r.has(n)||r.has(o)},forEach(n,r){const l=this,o=l.__v_raw,a=Lt(o),c=i?Ws:t?qi:Oe;return!t&&ae(a,"iterate",Ii),o.forEach((d,p)=>n.call(r,c(d),c(p),l))}};return re(e,t?{add:On("add"),set:On("set"),delete:On("delete"),clear:On("clear")}:{add(n){const r=Lt(this),l=Dn(r),o=Lt(n),a=!i&&!Ce(n)&&!si(n)?o:n;return l.has.call(r,a)||Ue(n,a)&&l.has.call(r,n)||Ue(o,a)&&l.has.call(r,o)||(r.add(a),Je(r,"add",a,a)),this},set(n,r){!i&&!Ce(r)&&!si(r)&&(r=Lt(r));const l=Lt(this),{has:o,get:a}=Dn(l);let c=o.call(l,n);c||(n=Lt(n),c=o.call(l,n));const d=a.call(l,n);return l.set(n,r),c?Ue(r,d)&&Je(l,"set",n,r):Je(l,"add",n,r),this},delete(n){const r=Lt(this),{has:l,get:o}=Dn(r);let a=l.call(r,n);a||(n=Lt(n),a=l.call(r,n)),o&&o.call(r,n);const c=r.delete(n);return a&&Je(r,"delete",n,void 0),c},clear(){const n=Lt(this),r=n.size!==0,l=n.clear();return r&&Je(n,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(n=>{e[n]=vc(n,t,i)}),e}function fo(t,i){const e=bc(t,i);return(s,n,r)=>n==="__v_isReactive"?!t:n==="__v_isReadonly"?t:n==="__v_raw"?s:Reflect.get(Rt(e,n)&&n in s?e:s,n,r)}const yc={get:fo(!1,!1)},kc={get:fo(!1,!0)},wc={get:fo(!0,!1)};const Qr=new WeakMap,tl=new WeakMap,el=new WeakMap,xc=new WeakMap;function _c(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function ds(t){return si(t)?t:ho(t,!1,pc,yc,Qr)}function Sc(t){return ho(t,!1,gc,kc,tl)}function Vs(t){return ho(t,!0,mc,wc,el)}function ho(t,i,e,s,n){if(!jt(t)||t.__v_raw&&!(i&&t.__v_isReactive)||t.__v_skip||!Object.isExtensible(t))return t;const r=n.get(t);if(r)return r;const l=_c(Za(t));if(l===0)return t;const o=new Proxy(t,l===2?s:e);return n.set(t,o),o}function Ai(t){return si(t)?Ai(t.__v_raw):!!(t&&t.__v_isReactive)}function si(t){return!!(t&&t.__v_isReadonly)}function Ce(t){return!!(t&&t.__v_isShallow)}function po(t){return t?!!t.__v_raw:!1}function Lt(t){const i=t&&t.__v_raw;return i?Lt(i):t}function Cc(t){return!Rt(t,"__v_skip")&&Object.isExtensible(t)&&zr(t,"__v_skip",!0),t}const Oe=t=>jt(t)?ds(t):t,qi=t=>jt(t)?Vs(t):t;function ue(t){return t?t.__v_isRef===!0:!1}function pt(t){return $c(t,!1)}function $c(t,i){return ue(t)?t:new Ic(t,i)}class Ic{constructor(i,e){this.dep=new uo,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=e?i:Lt(i),this._value=e?i:Oe(i),this.__v_isShallow=e}get value(){return this.dep.track(),this._value}set value(i){const e=this._rawValue,s=this.__v_isShallow||Ce(i)||si(i);i=s?i:Lt(i),Ue(i,e)&&(this._rawValue=i,this._value=s?i:Oe(i),this.dep.trigger())}}function Ci(t){return ue(t)?t.value:t}const Ac={get:(t,i,e)=>i==="__v_raw"?t:Ci(Reflect.get(t,i,e)),set:(t,i,e,s)=>{const n=t[i];return ue(n)&&!ue(e)?(n.value=e,!0):Reflect.set(t,i,e,s)}};function il(t){return Ai(t)?t:new Proxy(t,Ac)}class Tc{constructor(i,e,s){this.fn=i,this.setter=e,this._value=void 0,this.dep=new uo(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=vn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!e,this.isSSR=s}notify(){if(this.flags|=16,!(this.flags&8)&&Kt!==this)return Wr(this,!0),!0}get value(){const i=this.dep.track();return qr(this),i&&(i.version=this.dep.version),this._value}set value(i){this.setter&&this.setter(i)}}function Ec(t,i,e=!1){let s,n;return It(t)?s=t:(s=t.get,n=t.set),new Tc(s,n,e)}const Pn={},Gn=new WeakMap;let wi;function Mc(t,i=!1,e=wi){if(e){let s=Gn.get(e);s||Gn.set(e,s=[]),s.push(t)}}function Bc(t,i,e=Wt){const{immediate:s,deep:n,once:r,scheduler:l,augmentJob:o,call:a}=e,c=I=>n?I:Ce(I)||n===!1||n===0?Xe(I,1):Xe(I);let d,p,g,u,k=!1,h=!1;if(ue(t)?(p=()=>t.value,k=Ce(t)):Ai(t)?(p=()=>c(t),k=!0):Ct(t)?(h=!0,k=t.some(I=>Ai(I)||Ce(I)),p=()=>t.map(I=>{if(ue(I))return I.value;if(Ai(I))return c(I);if(It(I))return a?a(I,2):I()})):It(t)?i?p=a?()=>a(t,2):t:p=()=>{if(g){ii();try{g()}finally{ni()}}const I=wi;wi=d;try{return a?a(t,3,[u]):t(u)}finally{wi=I}}:p=Ve,i&&n){const I=p,x=n===!0?1/0:n;p=()=>Xe(I(),x)}const b=rc(),v=()=>{d.stop(),b&&b.active&&no(b.effects,d)};if(r&&i){const I=i;i=(...x)=>{const C=I(...x);return v(),C}}let w=h?new Array(t.length).fill(Pn):Pn;const $=I=>{if(!(!(d.flags&1)||!d.dirty&&!I))if(i){const x=d.run();if(I||n||k||(h?x.some((C,A)=>Ue(C,w[A])):Ue(x,w))){g&&g();const C=wi;wi=d;try{const A=[x,w===Pn?void 0:h&&w[0]===Pn?[]:w,u];w=x,a?a(i,3,A):i(...A)}finally{wi=C}}}else d.run()};return o&&o($),d=new Hr(p),d.scheduler=l?()=>l($,!1):$,u=I=>Mc(I,!1,d),g=d.onStop=()=>{const I=Gn.get(d);if(I){if(a)a(I,4);else for(const x of I)x();Gn.delete(d)}},i?s?$(!0):w=d.run():l?l($.bind(null,!0),!0):d.run(),v.pause=d.pause.bind(d),v.resume=d.resume.bind(d),v.stop=v,v}function Xe(t,i=1/0,e){if(i<=0||!jt(t)||t.__v_skip||(e=e||new Map,(e.get(t)||0)>=i))return t;if(e.set(t,i),i--,ue(t))Xe(t.value,i,e);else if(Ct(t))for(let s=0;s<t.length;s++)Xe(t[s],i,e);else if(Ji(t)||ji(t))t.forEach(s=>{Xe(s,i,e)});else if(Rr(t)){for(const s in t)Xe(t[s],i,e);for(const s of Object.getOwnPropertySymbols(t))Object.prototype.propertyIsEnumerable.call(t,s)&&Xe(t[s],i,e)}return t}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Cn(t,i,e,s){try{return s?t(...s):t()}catch(n){us(n,i,e)}}function Pe(t,i,e,s){if(It(t)){const n=Cn(t,i,e,s);return n&&Pr(n)&&n.catch(r=>{us(r,i,e)}),n}if(Ct(t)){const n=[];for(let r=0;r<t.length;r++)n.push(Pe(t[r],i,e,s));return n}}function us(t,i,e,s=!0){const n=i?i.vnode:null,{errorHandler:r,throwUnhandledErrorInProduction:l}=i&&i.appContext.config||Wt;if(i){let o=i.parent;const a=i.proxy,c=`https://vuejs.org/error-reference/#runtime-${e}`;for(;o;){const d=o.ec;if(d){for(let p=0;p<d.length;p++)if(d[p](t,a,c)===!1)return}o=o.parent}if(r){ii(),Cn(r,null,10,[t,a,c]),ni();return}}Dc(t,e,n,s,l)}function Dc(t,i,e,s=!0,n=!1){if(n)throw t;console.error(t)}const he=[];let Ne=-1;const Hi=[];let ai=null,Ri=0;const nl=Promise.resolve();let Zn=null;function sl(t){const i=Zn||nl;return t?i.then(this?t.bind(this):t):i}function Oc(t){let i=Ne+1,e=he.length;for(;i<e;){const s=i+e>>>1,n=he[s],r=yn(n);r<t||r===t&&n.flags&2?i=s+1:e=s}return i}function mo(t){if(!(t.flags&1)){const i=yn(t),e=he[he.length-1];!e||!(t.flags&2)&&i>=yn(e)?he.push(t):he.splice(Oc(i),0,t),t.flags|=1,ol()}}function ol(){Zn||(Zn=nl.then(ll))}function Pc(t){Ct(t)?Hi.push(...t):ai&&t.id===-1?ai.splice(Ri+1,0,t):t.flags&1||(Hi.push(t),t.flags|=1),ol()}function Uo(t,i,e=Ne+1){for(;e<he.length;e++){const s=he[e];if(s&&s.flags&2){if(t&&s.id!==t.uid)continue;he.splice(e,1),e--,s.flags&4&&(s.flags&=-2),s(),s.flags&4||(s.flags&=-2)}}}function rl(t){if(Hi.length){const i=[...new Set(Hi)].sort((e,s)=>yn(e)-yn(s));if(Hi.length=0,ai){ai.push(...i);return}for(ai=i,Ri=0;Ri<ai.length;Ri++){const e=ai[Ri];e.flags&4&&(e.flags&=-2),e.flags&8||e(),e.flags&=-2}ai=null,Ri=0}}const yn=t=>t.id==null?t.flags&2?-1:1/0:t.id;function ll(t){try{for(Ne=0;Ne<he.length;Ne++){const i=he[Ne];i&&!(i.flags&8)&&(i.flags&4&&(i.flags&=-2),Cn(i,i.i,i.i?15:14),i.flags&4||(i.flags&=-2))}}finally{for(;Ne<he.length;Ne++){const i=he[Ne];i&&(i.flags&=-2)}Ne=-1,he.length=0,rl(),Zn=null,(he.length||Hi.length)&&ll()}}let oe=null,al=null;function Yn(t){const i=oe;return oe=t,al=t&&t.type.__scopeId||null,i}function cl(t,i=oe,e){if(!i||t._n)return t;const s=(...n)=>{s._d&&er(-1);const r=Yn(i),l=ti.length;let o;try{o=t(...n)}finally{for(let a=ti.length;a>l;a--)wo();Yn(r),s._d&&er(1)}return o};return s._n=!0,s._c=!0,s._d=!0,s}function Ie(t,i){if(oe===null)return t;const e=ms(oe),s=t.dirs||(t.dirs=[]);for(let n=0;n<i.length;n++){let[r,l,o,a=Wt]=i[n];r&&(It(r)&&(r={mounted:r,updated:r}),r.deep&&Xe(l),s.push({dir:r,instance:e,value:l,oldValue:void 0,arg:o,modifiers:a}))}return t}function yi(t,i,e,s){const n=t.dirs,r=i&&i.dirs;for(let l=0;l<n.length;l++){const o=n[l];r&&(o.oldValue=r[l].value);let a=o.dir[s];a&&(ii(),Pe(a,e,8,[t.el,o,t,i]),ni())}}function Lc(t,i){if(ce){let e=ce.provides;const s=ce.parent&&ce.parent.provides;s===e&&(e=ce.provides=Object.create(s)),e[t]=i}}function Qe(t,i,e=!1){const s=Od();if(s||Wi){let n=Wi?Wi._context.provides:s?s.parent==null||s.ce?s.vnode.appContext&&s.vnode.appContext.provides:s.parent.provides:void 0;if(n&&t in n)return n[t];if(arguments.length>1)return e&&It(i)?i.call(s&&s.proxy):i}}const Rc=Symbol.for("v-scx"),zc=()=>Qe(Rc);function Ti(t,i,e){return dl(t,i,e)}function dl(t,i,e=Wt){const{immediate:s,deep:n,flush:r,once:l}=e,o=re({},e),a=i&&s||!i&&r!=="post";let c;if(wn){if(r==="sync"){const u=zc();c=u.__watcherHandles||(u.__watcherHandles=[])}else if(!a){const u=()=>{};return u.stop=Ve,u.resume=Ve,u.pause=Ve,u}}const d=ce;o.call=(u,k,h)=>Pe(u,d,k,h);let p=!1;r==="post"?o.scheduler=u=>{ge(u,d&&d.suspense)}:r!=="sync"&&(p=!0,o.scheduler=(u,k)=>{k?u():mo(u)}),o.augmentJob=u=>{i&&(u.flags|=4),p&&(u.flags|=2,d&&(u.id=d.uid,u.i=d))};const g=Bc(t,i,o);return wn&&(c?c.push(g):a&&g()),g}function Nc(t,i,e){const s=this.proxy,n=Qt(t)?t.includes(".")?ul(s,t):()=>s[t]:t.bind(s,s);let r;It(i)?r=i:(r=i.handler,e=i);const l=In(this),o=dl(n,r.bind(s),e);return l(),o}function ul(t,i){const e=i.split(".");return()=>{let s=t;for(let n=0;n<e.length&&s;n++)s=s[e[n]];return s}}const Fc=Symbol("_vte"),jc=t=>t.__isTeleport,$s=Symbol("_leaveCb");function go(t,i){t.shapeFlag&6&&t.component?(t.transition=i,go(t.component.subTree,i)):t.shapeFlag&128?(t.ssContent.transition=i.clone(t.ssContent),t.ssFallback.transition=i.clone(t.ssFallback)):t.transition=i}function be(t,i){return It(t)?re({name:t.name},i,{setup:t}):t}function fl(t){t.ids=[t.ids[0]+t.ids[2]+++"-",0,0]}function Wo(t,i){let e;return!!((e=Object.getOwnPropertyDescriptor(t,i))&&!e.configurable)}const Jn=new WeakMap;function pn(t,i,e,s,n=!1){if(Ct(t)){t.forEach((h,b)=>pn(h,i&&(Ct(i)?i[b]:i),e,s,n));return}if(Ui(s)&&!n){s.shapeFlag&512&&s.type.__asyncResolved&&s.component.subTree.component&&pn(t,i,e,s.component.subTree);return}const r=s.shapeFlag&4?ms(s.component):s.el,l=n?null:r,{i:o,r:a}=t,c=i&&i.r,d=o.refs===Wt?o.refs={}:o.refs,p=o.setupState,g=Lt(p),u=p===Wt?Or:h=>Wo(d,h)?!1:Rt(g,h),k=(h,b)=>!(b&&Wo(d,b));if(c!=null&&c!==a){if(Vo(i),Qt(c))d[c]=null,u(c)&&(p[c]=null);else if(ue(c)){const h=i;k(c,h.k)&&(c.value=null),h.k&&(d[h.k]=null)}}if(It(a))Cn(a,o,12,[l,d]);else{const h=Qt(a),b=ue(a);if(h||b){const v=()=>{if(t.f){const w=h?u(a)?p[a]:d[a]:k()||!t.k?a.value:d[t.k];if(n)Ct(w)&&no(w,r);else if(Ct(w))w.includes(r)||w.push(r);else if(h)d[a]=[r],u(a)&&(p[a]=d[a]);else{const $=[r];k(a,t.k)&&(a.value=$),t.k&&(d[t.k]=$)}}else h?(d[a]=l,u(a)&&(p[a]=l)):b&&(k(a,t.k)&&(a.value=l),t.k&&(d[t.k]=l))};if(l){const w=()=>{v(),Jn.delete(t)};w.id=-1,Jn.set(t,w),ge(w,e)}else Vo(t),v()}}}function Vo(t){const i=Jn.get(t);i&&(i.flags|=8,Jn.delete(t))}as().requestIdleCallback;as().cancelIdleCallback;const Ui=t=>!!t.type.__asyncLoader,hl=t=>t.type.__isKeepAlive;function Hc(t,i){pl(t,"a",i)}function Uc(t,i){pl(t,"da",i)}function pl(t,i,e=ce){const s=t.__wdc||(t.__wdc=()=>{let n=e;for(;n;){if(n.isDeactivated)return;n=n.parent}return t()});if(fs(i,s,e),e){let n=e.parent;for(;n&&n.parent;)hl(n.parent.vnode)&&Wc(s,i,e,n),n=n.parent}}function Wc(t,i,e,s){const n=fs(i,t,s,!0);bo(()=>{no(s[i],n)},e)}function fs(t,i,e=ce,s=!1){if(e){const n=e[t]||(e[t]=[]),r=i.__weh||(i.__weh=(...l)=>{ii();const o=In(e),a=Pe(i,e,t,l);return o(),ni(),a});return s?n.unshift(r):n.push(r),r}}const ri=t=>(i,e=ce)=>{(!wn||t==="sp")&&fs(t,(...s)=>i(...s),e)},Vc=ri("bm"),$n=ri("m"),Kc=ri("bu"),qc=ri("u"),vo=ri("bum"),bo=ri("um"),Gc=ri("sp"),Zc=ri("rtg"),Yc=ri("rtc");function Jc(t,i=ce){fs("ec",t,i)}const Xc="components";function Qc(t,i){return ed(Xc,t,!0,i)||t}const td=Symbol.for("v-ndc");function ed(t,i,e=!0,s=!1){const n=oe||ce;if(n){const r=n.type;{const o=Nd(r,!1);if(o&&(o===i||o===pe(i)||o===rs(pe(i))))return r}const l=Ko(n[t]||r[t],i)||Ko(n.appContext[t],i);return!l&&s?r:l}}function Ko(t,i){return t&&(t[i]||t[pe(i)]||t[rs(pe(i))])}function ye(t,i,e,s){let n;const r=e,l=Ct(t);if(l||Qt(t)){const o=l&&Ai(t);let a=!1,c=!1;o&&(a=!Ce(t),c=si(t),t=cs(t)),n=new Array(t.length);for(let d=0,p=t.length;d<p;d++)n[d]=i(a?c?qi(Oe(t[d])):Oe(t[d]):t[d],d,void 0,r)}else if(typeof t=="number"){n=new Array(t);for(let o=0;o<t;o++)n[o]=i(o+1,o,void 0,r)}else if(jt(t))if(t[Symbol.iterator])n=Array.from(t,(o,a)=>i(o,a,void 0,r));else{const o=Object.keys(t);n=new Array(o.length);for(let a=0,c=o.length;a<c;a++){const d=o[a];n[a]=i(t[d],d,a,r)}}else n=[];return n}function Ln(t,i,e={},s,n,r){if(oe.ce||oe.parent&&Ui(oe.parent)&&oe.parent.ce){const c=e,d=Object.keys(c).length>0;return i!=="default"&&(c.name=i),et(),Ee(Gt,null,[ht("slot",c,s&&s())],d?-2:64)}let l=t[i];l&&l._c&&(l._d=!1);const o=ti.length;et();let a;try{const c=l&&ml(l(e)),d=e.key||r||c&&c.key;a=Ee(Gt,{key:(d&&!De(d)?d:`_${i}`)+(!c&&s?"_fb":"")},c||(s?s():[]),c&&t._===1?64:-2)}catch(c){for(let d=ti.length;d>o;d--)wo();throw c}finally{l&&l._c&&(l._d=!0)}return a}function ml(t){return t.some(i=>xo(i)?!(i.type===oi||i.type===Gt&&!ml(i.children)):!0)?t:null}const Ks=t=>t?Pl(t)?ms(t):Ks(t.parent):null,mn=re(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>Ks(t.parent),$root:t=>Ks(t.root),$host:t=>t.ce,$emit:t=>t.emit,$options:t=>vl(t),$forceUpdate:t=>t.f||(t.f=()=>{mo(t.update)}),$nextTick:t=>t.n||(t.n=sl.bind(t.proxy)),$watch:t=>Nc.bind(t)}),Is=(t,i)=>t!==Wt&&!t.__isScriptSetup&&Rt(t,i),id={get({_:t},i){if(i==="__v_skip")return!0;const{ctx:e,setupState:s,data:n,props:r,accessCache:l,type:o,appContext:a}=t;if(i[0]!=="$"){const g=l[i];if(g!==void 0)switch(g){case 1:return s[i];case 2:return n[i];case 4:return e[i];case 3:return r[i]}else{if(Is(s,i))return l[i]=1,s[i];if(n!==Wt&&Rt(n,i))return l[i]=2,n[i];if(Rt(r,i))return l[i]=3,r[i];if(e!==Wt&&Rt(e,i))return l[i]=4,e[i];qs&&(l[i]=0)}}const c=mn[i];let d,p;if(c)return i==="$attrs"&&ae(t.attrs,"get",""),c(t);if((d=o.__cssModules)&&(d=d[i]))return d;if(e!==Wt&&Rt(e,i))return l[i]=4,e[i];if(p=a.config.globalProperties,Rt(p,i))return p[i]},set({_:t},i,e){const{data:s,setupState:n,ctx:r}=t;return Is(n,i)?(n[i]=e,!0):s!==Wt&&Rt(s,i)?(s[i]=e,!0):Rt(t.props,i)||i[0]==="$"&&i.slice(1)in t?!1:(r[i]=e,!0)},has({_:{data:t,setupState:i,accessCache:e,ctx:s,appContext:n,props:r,type:l}},o){let a;return!!(e[o]||t!==Wt&&o[0]!=="$"&&Rt(t,o)||Is(i,o)||Rt(r,o)||Rt(s,o)||Rt(mn,o)||Rt(n.config.globalProperties,o)||(a=l.__cssModules)&&a[o])},defineProperty(t,i,e){return e.get!=null?t._.accessCache[i]=0:Rt(e,"value")&&this.set(t,i,e.value,null),Reflect.defineProperty(t,i,e)}};function qo(t){return Ct(t)?t.reduce((i,e)=>(i[e]=null,i),{}):t}let qs=!0;function nd(t){const i=vl(t),e=t.proxy,s=t.ctx;qs=!1,i.beforeCreate&&Go(i.beforeCreate,t,"bc");const{data:n,computed:r,methods:l,watch:o,provide:a,inject:c,created:d,beforeMount:p,mounted:g,beforeUpdate:u,updated:k,activated:h,deactivated:b,beforeDestroy:v,beforeUnmount:w,destroyed:$,unmounted:I,render:x,renderTracked:C,renderTriggered:A,errorCaptured:M,serverPrefetch:P,expose:N,inheritAttrs:X,components:T,directives:D,filters:y}=i;if(c&&sd(c,s,null),l)for(const U in l){const at=l[U];It(at)&&(s[U]=at.bind(e))}if(n){const U=n.call(e,e);jt(U)&&(t.data=ds(U))}if(qs=!0,r)for(const U in r){const at=r[U],V=It(at)?at.bind(e,e):It(at.get)?at.get.bind(e,e):Ve,Y=!It(at)&&It(at.set)?at.set.bind(e):Ve,W=$t({get:V,set:Y});Object.defineProperty(s,U,{enumerable:!0,configurable:!0,get:()=>W.value,set:z=>W.value=z})}if(o)for(const U in o)gl(o[U],s,e,U);if(a){const U=It(a)?a.call(e):a;Reflect.ownKeys(U).forEach(at=>{Lc(at,U[at])})}d&&Go(d,t,"c");function Q(U,at){Ct(at)?at.forEach(V=>U(V.bind(e))):at&&U(at.bind(e))}if(Q(Vc,p),Q($n,g),Q(Kc,u),Q(qc,k),Q(Hc,h),Q(Uc,b),Q(Jc,M),Q(Yc,C),Q(Zc,A),Q(vo,w),Q(bo,I),Q(Gc,P),Ct(N))if(N.length){const U=t.exposed||(t.exposed={});N.forEach(at=>{Object.defineProperty(U,at,{get:()=>e[at],set:V=>e[at]=V,enumerable:!0})})}else t.exposed||(t.exposed={});x&&t.render===Ve&&(t.render=x),X!=null&&(t.inheritAttrs=X),T&&(t.components=T),D&&(t.directives=D),P&&fl(t)}function sd(t,i,e=Ve){Ct(t)&&(t=Gs(t));for(const s in t){const n=t[s];let r;jt(n)?"default"in n?r=Qe(n.from||s,n.default,!0):r=Qe(n.from||s):r=Qe(n),ue(r)?Object.defineProperty(i,s,{enumerable:!0,configurable:!0,get:()=>r.value,set:l=>r.value=l}):i[s]=r}}function Go(t,i,e){Pe(Ct(t)?t.map(s=>s.bind(i.proxy)):t.bind(i.proxy),i,e)}function gl(t,i,e,s){let n=s.includes(".")?ul(e,s):()=>e[s];if(Qt(t)){const r=i[t];It(r)&&Ti(n,r)}else if(It(t))Ti(n,t.bind(e));else if(jt(t))if(Ct(t))t.forEach(r=>gl(r,i,e,s));else{const r=It(t.handler)?t.handler.bind(e):i[t.handler];It(r)&&Ti(n,r,t)}}function vl(t){const i=t.type,{mixins:e,extends:s}=i,{mixins:n,optionsCache:r,config:{optionMergeStrategies:l}}=t.appContext,o=r.get(i);let a;return o?a=o:!n.length&&!e&&!s?a=i:(a={},n.length&&n.forEach(c=>Xn(a,c,l,!0)),Xn(a,i,l)),jt(i)&&r.set(i,a),a}function Xn(t,i,e,s=!1){const{mixins:n,extends:r}=i;r&&Xn(t,r,e,!0),n&&n.forEach(l=>Xn(t,l,e,!0));for(const l in i)if(!(s&&l==="expose")){const o=od[l]||e&&e[l];t[l]=o?o(t[l],i[l]):i[l]}return t}const od={data:Zo,props:Yo,emits:Yo,methods:sn,computed:sn,beforeCreate:fe,created:fe,beforeMount:fe,mounted:fe,beforeUpdate:fe,updated:fe,beforeDestroy:fe,beforeUnmount:fe,destroyed:fe,unmounted:fe,activated:fe,deactivated:fe,errorCaptured:fe,serverPrefetch:fe,components:sn,directives:sn,watch:ld,provide:Zo,inject:rd};function Zo(t,i){return i?t?function(){return re(It(t)?t.call(this,this):t,It(i)?i.call(this,this):i)}:i:t}function rd(t,i){return sn(Gs(t),Gs(i))}function Gs(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++)i[t[e]]=t[e];return i}return t}function fe(t,i){return t?[...new Set([].concat(t,i))]:i}function sn(t,i){return t?re(Object.create(null),t,i):i}function Yo(t,i){return t?Ct(t)&&Ct(i)?[...new Set([...t,...i])]:re(Object.create(null),qo(t),qo(i??{})):i}function ld(t,i){if(!t)return i;if(!i)return t;const e=re(Object.create(null),t);for(const s in i)e[s]=fe(t[s],i[s]);return e}function bl(){return{app:null,config:{isNativeTag:Or,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let ad=0;function cd(t,i){return function(s,n=null){It(s)||(s=re({},s)),n!=null&&!jt(n)&&(n=null);const r=bl(),l=new WeakSet,o=[];let a=!1;const c=r.app={_uid:ad++,_component:s,_props:n,_container:null,_context:r,_instance:null,version:jd,get config(){return r.config},set config(d){},use(d,...p){return l.has(d)||(d&&It(d.install)?(l.add(d),d.install(c,...p)):It(d)&&(l.add(d),d(c,...p))),c},mixin(d){return r.mixins.includes(d)||r.mixins.push(d),c},component(d,p){return p?(r.components[d]=p,c):r.components[d]},directive(d,p){return p?(r.directives[d]=p,c):r.directives[d]},mount(d,p,g){if(!a){const u=c._ceVNode||ht(s,n);return u.appContext=r,g===!0?g="svg":g===!1&&(g=void 0),t(u,d,g),a=!0,c._container=d,d.__vue_app__=c,ms(u.component)}},onUnmount(d){o.push(d)},unmount(){a&&(Pe(o,c._instance,16),t(null,c._container),delete c._container.__vue_app__)},provide(d,p){return r.provides[d]=p,c},runWithContext(d){const p=Wi;Wi=c;try{return d()}finally{Wi=p}}};return c}}let Wi=null;const dd=(t,i)=>i==="modelValue"||i==="model-value"?t.modelModifiers:t[`${i}Modifiers`]||t[`${pe(i)}Modifiers`]||t[`${pi(i)}Modifiers`];function ud(t,i,...e){if(t.isUnmounted)return;const s=t.vnode.props||Wt;let n=e;const r=i.startsWith("update:"),l=r&&dd(s,i.slice(7));l&&(l.trim&&(n=e.map(d=>Qt(d)?d.trim():d)),l.number&&(n=e.map(ls)));let o,a=s[o=ws(i)]||s[o=ws(pe(i))];!a&&r&&(a=s[o=ws(pi(i))]),a&&Pe(a,t,6,n);const c=s[o+"Once"];if(c){if(!t.emitted)t.emitted={};else if(t.emitted[o])return;t.emitted[o]=!0,Pe(c,t,6,n)}}const fd=new WeakMap;function yl(t,i,e=!1){const s=e?fd:i.emitsCache,n=s.get(t);if(n!==void 0)return n;const r=t.emits;let l={},o=!1;if(!It(t)){const a=c=>{const d=yl(c,i,!0);d&&(o=!0,re(l,d))};!e&&i.mixins.length&&i.mixins.forEach(a),t.extends&&a(t.extends),t.mixins&&t.mixins.forEach(a)}return!r&&!o?(jt(t)&&s.set(t,null),null):(Ct(r)?r.forEach(a=>l[a]=null):re(l,r),jt(t)&&s.set(t,l),l)}function hs(t,i){return!t||!ns(i)?!1:(i=i.slice(2),i=i==="Once"?i:i.replace(/Once$/,""),Rt(t,i[0].toLowerCase()+i.slice(1))||Rt(t,pi(i))||Rt(t,i))}function Jo(t){const{type:i,vnode:e,proxy:s,withProxy:n,propsOptions:[r],slots:l,attrs:o,emit:a,render:c,renderCache:d,props:p,data:g,setupState:u,ctx:k,inheritAttrs:h}=t,b=Yn(t);let v,w;try{if(e.shapeFlag&4){const I=n||s,x=I;v=je(c.call(x,I,d,p,u,g,k)),w=o}else{const I=i;v=je(I.length>1?I(p,{attrs:o,slots:l,emit:a}):I(p,null)),w=i.props?o:hd(o)}}catch(I){ti.length=0,us(I,t,1),v=ht(oi)}let $=v;if(w&&h!==!1){const I=Object.keys(w),{shapeFlag:x}=$;I.length&&x&7&&(r&&I.some(ss)&&(w=pd(w,r)),$=Gi($,w,!1,!0))}return e.dirs&&($=Gi($,null,!1,!0),$.dirs=$.dirs?$.dirs.concat(e.dirs):e.dirs),e.transition&&go($,e.transition),v=$,Yn(b),v}const hd=t=>{let i;for(const e in t)(e==="class"||e==="style"||ns(e))&&((i||(i={}))[e]=t[e]);return i},pd=(t,i)=>{const e={};for(const s in t)(!ss(s)||!(s.slice(9)in i))&&(e[s]=t[s]);return e};function md(t,i,e){const{props:s,children:n,component:r}=t,{props:l,children:o,patchFlag:a}=i,c=r.emitsOptions;if(i.dirs||i.transition)return!0;if(e&&a>=0){if(a&1024)return!0;if(a&16)return s?Xo(s,l,c):!!l;if(a&8){const d=i.dynamicProps;for(let p=0;p<d.length;p++){const g=d[p];if(kl(l,s,g)&&!hs(c,g))return!0}}}else return(n||o)&&(!o||!o.$stable)?!0:s===l?!1:s?l?Xo(s,l,c):!0:!!l;return!1}function Xo(t,i,e){const s=Object.keys(i);if(s.length!==Object.keys(t).length)return!0;for(let n=0;n<s.length;n++){const r=s[n];if(kl(i,t,r)&&!hs(e,r))return!0}return!1}function kl(t,i,e){const s=t[e],n=i[e];return e==="style"&&jt(s)&&jt(n)?!Xi(s,n):s!==n}function gd({vnode:t,parent:i,suspense:e},s){for(;i;){const n=i.subTree;if(n.suspense&&n.suspense.activeBranch===t&&(n.suspense.vnode.el=n.el=s,t=n),n===t)(t=i.vnode).el=s,i=i.parent;else break}e&&e.activeBranch===t&&(e.vnode.el=s)}const wl={},xl=()=>Object.create(wl),_l=t=>Object.getPrototypeOf(t)===wl;function vd(t,i,e,s=!1){const n={},r=xl();t.propsDefaults=Object.create(null),Sl(t,i,n,r);for(const l in t.propsOptions[0])l in n||(n[l]=void 0);e?t.props=s?n:Sc(n):t.type.props?t.props=n:t.props=r,t.attrs=r}function bd(t,i,e,s){const{props:n,attrs:r,vnode:{patchFlag:l}}=t,o=Lt(n),[a]=t.propsOptions;let c=!1;if((s||l>0)&&!(l&16)){if(l&8){const d=t.vnode.dynamicProps;for(let p=0;p<d.length;p++){let g=d[p];if(hs(t.emitsOptions,g))continue;const u=i[g];if(a)if(Rt(r,g))u!==r[g]&&(r[g]=u,c=!0);else{const k=pe(g);n[k]=Zs(a,o,k,u,t,!1)}else u!==r[g]&&(r[g]=u,c=!0)}}}else{Sl(t,i,n,r)&&(c=!0);let d;for(const p in o)(!i||!Rt(i,p)&&((d=pi(p))===p||!Rt(i,d)))&&(a?e&&(e[p]!==void 0||e[d]!==void 0)&&(n[p]=Zs(a,o,p,void 0,t,!0)):delete n[p]);if(r!==o)for(const p in r)(!i||!Rt(i,p))&&(delete r[p],c=!0)}c&&Je(t.attrs,"set","")}function Sl(t,i,e,s){const[n,r]=t.propsOptions;let l=!1,o;if(i)for(let a in i){if(un(a))continue;const c=i[a];let d;n&&Rt(n,d=pe(a))?!r||!r.includes(d)?e[d]=c:(o||(o={}))[d]=c:hs(t.emitsOptions,a)||(!(a in s)||c!==s[a])&&(s[a]=c,l=!0)}if(r){const a=Lt(e),c=o||Wt;for(let d=0;d<r.length;d++){const p=r[d];e[p]=Zs(n,a,p,c[p],t,!Rt(c,p))}}return l}function Zs(t,i,e,s,n,r){const l=t[e];if(l!=null){const o=Rt(l,"default");if(o&&s===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&It(a)){const{propsDefaults:c}=n;if(e in c)s=c[e];else{const d=In(n);s=c[e]=a.call(null,i),d()}}else s=a;n.ce&&n.ce._setProp(e,s)}l[0]&&(r&&!o?s=!1:l[1]&&(s===""||s===pi(e))&&(s=!0))}return s}const yd=new WeakMap;function Cl(t,i,e=!1){const s=e?yd:i.propsCache,n=s.get(t);if(n)return n;const r=t.props,l={},o=[];let a=!1;if(!It(t)){const d=p=>{a=!0;const[g,u]=Cl(p,i,!0);re(l,g),u&&o.push(...u)};!e&&i.mixins.length&&i.mixins.forEach(d),t.extends&&d(t.extends),t.mixins&&t.mixins.forEach(d)}if(!r&&!a)return jt(t)&&s.set(t,Fi),Fi;if(Ct(r))for(let d=0;d<r.length;d++){const p=pe(r[d]);Qo(p)&&(l[p]=Wt)}else if(r)for(const d in r){const p=pe(d);if(Qo(p)){const g=r[d],u=l[p]=Ct(g)||It(g)?{type:g}:re({},g),k=u.type;let h=!1,b=!0;if(Ct(k))for(let v=0;v<k.length;++v){const w=k[v],$=It(w)&&w.name;if($==="Boolean"){h=!0;break}else $==="String"&&(b=!1)}else h=It(k)&&k.name==="Boolean";u[0]=h,u[1]=b,(h||Rt(u,"default"))&&o.push(p)}}const c=[l,o];return jt(t)&&s.set(t,c),c}function Qo(t){return t[0]!=="$"&&!un(t)}const yo=t=>t==="_"||t==="_ctx"||t==="$stable",ko=t=>Ct(t)?t.map(je):[je(t)],kd=(t,i,e)=>{if(i._n)return i;const s=cl((...n)=>ko(i(...n)),e);return s._c=!1,s},$l=(t,i,e)=>{const s=t._ctx;for(const n in t){if(yo(n))continue;const r=t[n];if(It(r))i[n]=kd(n,r,s);else if(r!=null){const l=ko(r);i[n]=()=>l}}},Il=(t,i)=>{const e=ko(i);t.slots.default=()=>e},Al=(t,i,e)=>{for(const s in i)(e||!yo(s))&&(t[s]=i[s])},wd=(t,i,e)=>{const s=t.slots=xl();if(t.vnode.shapeFlag&32){const n=i._;n?(Al(s,i,e),e&&zr(s,"_",n,!0)):$l(i,s)}else i&&Il(t,i)},xd=(t,i,e)=>{const{vnode:s,slots:n}=t;let r=!0,l=Wt;if(s.shapeFlag&32){const o=i._;o?e&&o===1?r=!1:Al(n,i,e):(r=!i.$stable,$l(i,n)),l=i}else i&&(Il(t,i),l={default:1});if(r)for(const o in n)!yo(o)&&l[o]==null&&delete n[o]},ge=Id;function _d(t){return Sd(t)}function Sd(t,i){const e=as();e.__VUE__=!0;const{insert:s,remove:n,patchProp:r,createElement:l,createText:o,createComment:a,setText:c,setElementText:d,parentNode:p,nextSibling:g,setScopeId:u=Ve,insertStaticContent:k}=t,h=(E,L,f,F=null,O=null,_=null,S=void 0,B=null,K=!!L.dynamicChildren)=>{if(E===L)return;E&&!tn(E,L)&&(F=gt(E),z(E,O,_,!0),E=null),L.patchFlag===-2&&(K=!1,L.dynamicChildren=null);const{type:j,ref:H,shapeFlag:G}=L;switch(j){case ps:b(E,L,f,F);break;case oi:v(E,L,f,F);break;case Hn:E==null&&w(L,f,F,S);break;case Gt:T(E,L,f,F,O,_,S,B,K);break;default:G&1?x(E,L,f,F,O,_,S,B,K):G&6?D(E,L,f,F,O,_,S,B,K):(G&64||G&128)&&j.process(E,L,f,F,O,_,S,B,K,ot)}H!=null&&O?pn(H,E&&E.ref,_,L||E,!L):H==null&&E&&E.ref!=null&&pn(E.ref,null,_,E,!0)},b=(E,L,f,F)=>{if(E==null)s(L.el=o(L.children),f,F);else{const O=L.el=E.el;L.children!==E.children&&c(O,L.children)}},v=(E,L,f,F)=>{E==null?s(L.el=a(L.children||""),f,F):L.el=E.el},w=(E,L,f,F)=>{[E.el,E.anchor]=k(E.children,L,f,F,E.el,E.anchor)},$=({el:E,anchor:L},f,F)=>{let O;for(;E&&E!==L;)O=g(E),s(E,f,F),E=O;s(L,f,F)},I=({el:E,anchor:L})=>{let f;for(;E&&E!==L;)f=g(E),n(E),E=f;n(L)},x=(E,L,f,F,O,_,S,B,K)=>{if(L.type==="svg"?S="svg":L.type==="math"&&(S="mathml"),E==null)C(L,f,F,O,_,S,B,K);else{const j=E.el&&E.el._isVueCE?E.el:null;try{j&&j._beginPatch(),P(E,L,O,_,S,B,K)}finally{j&&j._endPatch()}}},C=(E,L,f,F,O,_,S,B)=>{let K,j;const{props:H,shapeFlag:G,transition:it,dirs:tt}=E;if(K=E.el=l(E.type,_,H&&H.is,H),G&8?d(K,E.children):G&16&&M(E.children,K,null,F,O,As(E,_),S,B),tt&&yi(E,null,F,"created"),A(K,E,E.scopeId,S,F),H){for(const xt in H)xt!=="value"&&!un(xt)&&r(K,xt,null,H[xt],_,F);"value"in H&&r(K,"value",null,H.value,_),(j=H.onVnodeBeforeMount)&&ze(j,F,E)}tt&&yi(E,null,F,"beforeMount");const ut=Cd(O,it);ut&&it.beforeEnter(K),s(K,L,f),((j=H&&H.onVnodeMounted)||ut||tt)&&ge(()=>{try{j&&ze(j,F,E),ut&&it.enter(K),tt&&yi(E,null,F,"mounted")}finally{}},O)},A=(E,L,f,F,O)=>{if(f&&u(E,f),F)for(let _=0;_<F.length;_++)u(E,F[_]);if(O){let _=O.subTree;if(L===_||Bl(_.type)&&(_.ssContent===L||_.ssFallback===L)){const S=O.vnode;A(E,S,S.scopeId,S.slotScopeIds,O.parent)}}},M=(E,L,f,F,O,_,S,B,K=0)=>{for(let j=K;j<E.length;j++){const H=E[j]=B?Ye(E[j]):je(E[j]);h(null,H,L,f,F,O,_,S,B)}},P=(E,L,f,F,O,_,S)=>{const B=L.el=E.el;let{patchFlag:K,dynamicChildren:j,dirs:H}=L;K|=E.patchFlag&16;const G=E.props||Wt,it=L.props||Wt;let tt;if(f&&ki(f,!1),(tt=it.onVnodeBeforeUpdate)&&ze(tt,f,L,E),H&&yi(L,E,f,"beforeUpdate"),f&&ki(f,!0),j&&(!E.dynamicChildren||E.dynamicChildren.length!==j.length)&&(K=0,S=!1,j=null),(G.innerHTML&&it.innerHTML==null||G.textContent&&it.textContent==null)&&d(B,""),j?N(E.dynamicChildren,j,B,f,F,As(L,O),_):S||at(E,L,B,null,f,F,As(L,O),_,!1),K>0){if(K&16)X(B,G,it,f,O);else if(K&2&&G.class!==it.class&&r(B,"class",null,it.class,O),K&4&&r(B,"style",G.style,it.style,O),K&8){const ut=L.dynamicProps;for(let xt=0;xt<ut.length;xt++){const bt=ut[xt],Mt=G[bt],Vt=it[bt];(Vt!==Mt||bt==="value")&&r(B,bt,Mt,Vt,O,f)}}K&1&&E.children!==L.children&&d(B,L.children)}else!S&&j==null&&X(B,G,it,f,O);((tt=it.onVnodeUpdated)||H)&&ge(()=>{tt&&ze(tt,f,L,E),H&&yi(L,E,f,"updated")},F)},N=(E,L,f,F,O,_,S)=>{for(let B=0;B<L.length;B++){const K=E[B],j=L[B],H=K.el&&(K.type===Gt||!tn(K,j)||K.shapeFlag&198)?p(K.el):f;h(K,j,H,null,F,O,_,S,!0)}},X=(E,L,f,F,O)=>{if(L!==f){if(L!==Wt)for(const _ in L)!un(_)&&!(_ in f)&&r(E,_,L[_],null,O,F);for(const _ in f){if(un(_))continue;const S=f[_],B=L[_];S!==B&&_!=="value"&&r(E,_,B,S,O,F)}"value"in f&&r(E,"value",L.value,f.value,O)}},T=(E,L,f,F,O,_,S,B,K)=>{const j=L.el=E?E.el:o(""),H=L.anchor=E?E.anchor:o("");let{patchFlag:G,dynamicChildren:it,slotScopeIds:tt}=L;tt&&(B=B?B.concat(tt):tt),E==null?(s(j,f,F),s(H,f,F),M(L.children||[],f,H,O,_,S,B,K)):G>0&&G&64&&it&&E.dynamicChildren&&E.dynamicChildren.length===it.length?(N(E.dynamicChildren,it,f,O,_,S,B),(L.key!=null||O&&L===O.subTree)&&Tl(E,L,!0)):at(E,L,f,H,O,_,S,B,K)},D=(E,L,f,F,O,_,S,B,K)=>{L.slotScopeIds=B,E==null?L.shapeFlag&512?O.ctx.activate(L,f,F,S,K):y(L,f,F,O,_,S,K):R(E,L,K)},y=(E,L,f,F,O,_,S)=>{const B=E.component=Dd(E,F,O);if(hl(E)&&(B.ctx.renderer=ot),Pd(B,!1,S),B.asyncDep){if(O&&O.registerDep(B,Q,S),!E.el){const K=B.subTree=ht(oi);v(null,K,L,f),E.placeholder=K.el}}else Q(B,E,L,f,O,_,S)},R=(E,L,f)=>{const F=L.component=E.component;if(md(E,L,f))if(F.asyncDep&&!F.asyncResolved){U(F,L,f);return}else F.next=L,F.update();else L.el=E.el,F.vnode=L},Q=(E,L,f,F,O,_,S)=>{const B=()=>{if(E.isMounted){let{next:G,bu:it,u:tt,parent:ut,vnode:xt}=E;{const ee=El(E);if(ee){G&&(G.el=xt.el,U(E,G,S)),ee.asyncDep.then(()=>{ge(()=>{E.isUnmounted||j()},O)});return}}let bt=G,Mt;ki(E,!1),G?(G.el=xt.el,U(E,G,S)):G=xt,it&&jn(it),(Mt=G.props&&G.props.onVnodeBeforeUpdate)&&ze(Mt,ut,G,xt),ki(E,!0);const Vt=Jo(E),Yt=E.subTree;E.subTree=Vt,h(Yt,Vt,p(Yt.el),gt(Yt),E,O,_),G.el=Vt.el,bt===null&&gd(E,Vt.el),tt&&ge(tt,O),(Mt=G.props&&G.props.onVnodeUpdated)&&ge(()=>ze(Mt,ut,G,xt),O)}else{let G;const{el:it,props:tt}=L,{bm:ut,m:xt,parent:bt,root:Mt,type:Vt}=E,Yt=Ui(L);ki(E,!1),ut&&jn(ut),!Yt&&(G=tt&&tt.onVnodeBeforeMount)&&ze(G,bt,L),ki(E,!0);{Mt.ce&&Mt.ce._hasShadowRoot()&&Mt.ce._injectChildStyle(Vt,E.parent?E.parent.type:void 0);const ee=E.subTree=Jo(E);h(null,ee,f,F,E,O,_),L.el=ee.el}if(xt&&ge(xt,O),!Yt&&(G=tt&&tt.onVnodeMounted)){const ee=L;ge(()=>ze(G,bt,ee),O)}(L.shapeFlag&256||bt&&Ui(bt.vnode)&&bt.vnode.shapeFlag&256)&&E.a&&ge(E.a,O),E.isMounted=!0,L=f=F=null}};E.scope.on();const K=E.effect=new Hr(B);E.scope.off();const j=E.update=K.run.bind(K),H=E.job=K.runIfDirty.bind(K);H.i=E,H.id=E.uid,K.scheduler=()=>mo(H),ki(E,!0),j()},U=(E,L,f)=>{L.component=E;const F=E.vnode.props;E.vnode=L,E.next=null,bd(E,L.props,F,f),xd(E,L.children,f),ii(),Uo(E),ni()},at=(E,L,f,F,O,_,S,B,K=!1)=>{const j=E&&E.children,H=E?E.shapeFlag:0,G=L.children,{patchFlag:it,shapeFlag:tt}=L;if(it>0){if(it&128){Y(j,G,f,F,O,_,S,B,K);return}else if(it&256){V(j,G,f,F,O,_,S,B,K);return}}tt&8?(H&16&&J(j,O,_),G!==j&&d(f,G)):H&16?tt&16?Y(j,G,f,F,O,_,S,B,K):J(j,O,_,!0):(H&8&&d(f,""),tt&16&&M(G,f,F,O,_,S,B,K))},V=(E,L,f,F,O,_,S,B,K)=>{E=E||Fi,L=L||Fi;const j=E.length,H=L.length,G=Math.min(j,H);let it;for(it=0;it<G;it++){const tt=L[it]=K?Ye(L[it]):je(L[it]);h(E[it],tt,f,null,O,_,S,B,K)}j>H?J(E,O,_,!0,!1,G):M(L,f,F,O,_,S,B,K,G)},Y=(E,L,f,F,O,_,S,B,K)=>{let j=0;const H=L.length;let G=E.length-1,it=H-1;for(;j<=G&&j<=it;){const tt=E[j],ut=L[j]=K?Ye(L[j]):je(L[j]);if(tn(tt,ut))h(tt,ut,f,null,O,_,S,B,K);else break;j++}for(;j<=G&&j<=it;){const tt=E[G],ut=L[it]=K?Ye(L[it]):je(L[it]);if(tn(tt,ut))h(tt,ut,f,null,O,_,S,B,K);else break;G--,it--}if(j>G){if(j<=it){const tt=it+1,ut=tt<H?L[tt].el:F;for(;j<=it;)h(null,L[j]=K?Ye(L[j]):je(L[j]),f,ut,O,_,S,B,K),j++}}else if(j>it)for(;j<=G;)z(E[j],O,_,!0),j++;else{const tt=j,ut=j,xt=new Map;for(j=ut;j<=it;j++){const te=L[j]=K?Ye(L[j]):je(L[j]);te.key!=null&&xt.set(te.key,j)}let bt,Mt=0;const Vt=it-ut+1;let Yt=!1,ee=0;const Nt=new Array(Vt);for(j=0;j<Vt;j++)Nt[j]=0;for(j=tt;j<=G;j++){const te=E[j];if(Mt>=Vt){z(te,O,_,!0);continue}let Jt;if(te.key!=null)Jt=xt.get(te.key);else for(bt=ut;bt<=it;bt++)if(Nt[bt-ut]===0&&tn(te,L[bt])){Jt=bt;break}Jt===void 0?z(te,O,_,!0):(Nt[Jt-ut]=j+1,Jt>=ee?ee=Jt:Yt=!0,h(te,L[Jt],f,null,O,_,S,B,K),Mt++)}const Ke=Yt?$d(Nt):Fi;for(bt=Ke.length-1,j=Vt-1;j>=0;j--){const te=ut+j,Jt=L[te],mi=L[te+1],Bi=te+1<H?mi.el||Ml(mi):F;Nt[j]===0?h(null,Jt,f,Bi,O,_,S,B,K):Yt&&(bt<0||j!==Ke[bt]?W(Jt,f,Bi,2):bt--)}}},W=(E,L,f,F,O=null)=>{const{el:_,type:S,transition:B,children:K,shapeFlag:j}=E;if(j&6){W(E.component.subTree,L,f,F);return}if(j&128){E.suspense.move(L,f,F);return}if(j&64){S.move(E,L,f,ot);return}if(S===Gt){s(_,L,f);for(let G=0;G<K.length;G++)W(K[G],L,f,F);s(E.anchor,L,f);return}if(S===Hn){$(E,L,f);return}if(F!==2&&j&1&&B)if(F===0)B.persisted&&!_[$s]?s(_,L,f):(B.beforeEnter(_),s(_,L,f),ge(()=>B.enter(_),O));else{const{leave:G,delayLeave:it,afterLeave:tt}=B,ut=()=>{E.ctx.isUnmounted?n(_):s(_,L,f)},xt=()=>{const bt=_._isLeaving||!!_[$s];_._isLeaving&&_[$s](!0),B.persisted&&!bt?ut():G(_,()=>{ut(),tt&&tt()})};it?it(_,ut,xt):xt()}else s(_,L,f)},z=(E,L,f,F=!1,O=!1)=>{const{type:_,props:S,ref:B,children:K,dynamicChildren:j,shapeFlag:H,patchFlag:G,dirs:it,cacheIndex:tt,memo:ut}=E;if(G===-2&&(O=!1),B!=null&&(ii(),pn(B,null,f,E,!0),ni()),tt!=null&&(L.renderCache[tt]=void 0),H&256){L.ctx.deactivate(E);return}const xt=H&1&&it,bt=!Ui(E);let Mt;if(bt&&(Mt=S&&S.onVnodeBeforeUnmount)&&ze(Mt,L,E),H&6)st(E.component,f,F);else{if(H&128){E.suspense.unmount(f,F);return}xt&&yi(E,null,L,"beforeUnmount"),H&64?E.type.remove(E,L,f,ot,F):j&&!j.hasOnce&&(_!==Gt||G>0&&G&64)?J(j,L,f,!1,!0):(_===Gt&&G&384||!O&&H&16)&&J(K,L,f),F&&ct(E)}const Vt=ut!=null&&tt==null;(bt&&(Mt=S&&S.onVnodeUnmounted)||xt||Vt)&&ge(()=>{Mt&&ze(Mt,L,E),xt&&yi(E,null,L,"unmounted"),Vt&&(E.el=null)},f)},ct=E=>{const{type:L,el:f,anchor:F,transition:O}=E;if(L===Gt){rt(f,F);return}if(L===Hn){I(E);return}const _=()=>{n(f),O&&!O.persisted&&O.afterLeave&&O.afterLeave()};if(E.shapeFlag&1&&O&&!O.persisted){const{leave:S,delayLeave:B}=O,K=()=>S(f,_);B?B(E.el,_,K):K()}else _()},rt=(E,L)=>{let f;for(;E!==L;)f=g(E),n(E),E=f;n(L)},st=(E,L,f)=>{const{bum:F,scope:O,job:_,subTree:S,um:B,m:K,a:j}=E;tr(K),tr(j),F&&jn(F),O.stop(),_&&(_.flags|=8,z(S,E,L,f)),B&&ge(B,L),ge(()=>{E.isUnmounted=!0},L)},J=(E,L,f,F=!1,O=!1,_=0)=>{for(let S=_;S<E.length;S++)z(E[S],L,f,F,O)},gt=E=>{if(E.shapeFlag&6)return gt(E.component.subTree);if(E.shapeFlag&128)return E.suspense.next();const L=g(E.anchor||E.el),f=L&&L[Fc];return f?g(f):L};let mt=!1;const Z=(E,L,f)=>{let F;E==null?L._vnode&&(z(L._vnode,null,null,!0),F=L._vnode.component):h(L._vnode||null,E,L,null,null,null,f),L._vnode=E,mt||(mt=!0,Uo(F),rl(),mt=!1)},ot={p:h,um:z,m:W,r:ct,mt:y,mc:M,pc:at,pbc:N,n:gt,o:t};return{render:Z,hydrate:void 0,createApp:cd(Z)}}function As({type:t,props:i},e){return e==="svg"&&t==="foreignObject"||e==="mathml"&&t==="annotation-xml"&&i&&i.encoding&&i.encoding.includes("html")?void 0:e}function ki({effect:t,job:i},e){e?(t.flags|=32,i.flags|=4):(t.flags&=-33,i.flags&=-5)}function Cd(t,i){return(!t||t&&!t.pendingBranch)&&i&&!i.persisted}function Tl(t,i,e=!1){const s=t.children,n=i.children;if(Ct(s)&&Ct(n))for(let r=0;r<s.length;r++){const l=s[r];let o=n[r];o.shapeFlag&1&&!o.dynamicChildren&&((o.patchFlag<=0||o.patchFlag===32)&&(o=n[r]=Ye(n[r]),o.el=l.el),!e&&o.patchFlag!==-2&&Tl(l,o)),o.type===ps&&(o.patchFlag===-1&&(o=n[r]=Ye(o)),o.el=l.el),o.type===oi&&!o.el&&(o.el=l.el)}}function $d(t){const i=t.slice(),e=[0];let s,n,r,l,o;const a=t.length;for(s=0;s<a;s++){const c=t[s];if(c!==0){if(n=e[e.length-1],t[n]<c){i[s]=n,e.push(s);continue}for(r=0,l=e.length-1;r<l;)o=r+l>>1,t[e[o]]<c?r=o+1:l=o;c<t[e[r]]&&(r>0&&(i[s]=e[r-1]),e[r]=s)}}for(r=e.length,l=e[r-1];r-- >0;)e[r]=l,l=i[l];return e}function El(t){const i=t.subTree.component;if(i)return i.asyncDep&&!i.asyncResolved?i:El(i)}function tr(t){if(t)for(let i=0;i<t.length;i++)t[i].flags|=8}function Ml(t){if(t.placeholder)return t.placeholder;const i=t.component;return i?Ml(i.subTree):null}const Bl=t=>t.__isSuspense;function Id(t,i){i&&i.pendingBranch?Ct(t)?i.effects.push(...t):i.effects.push(t):Pc(t)}const Gt=Symbol.for("v-fgt"),ps=Symbol.for("v-txt"),oi=Symbol.for("v-cmt"),Hn=Symbol.for("v-stc"),ti=[];let ke=null;function et(t=!1){ti.push(ke=t?null:[])}function wo(){ti.pop(),ke=ti[ti.length-1]||null}let kn=1;function er(t,i=!1){kn+=t,t<0&&ke&&i&&(ke.hasOnce=!0)}function Dl(t){return t.dynamicChildren=kn>0?ke||Fi:null,wo(),kn>0&&ke&&ke.push(t),t}function nt(t,i,e,s,n,r){return Dl(m(t,i,e,s,n,r,!0))}function Ee(t,i,e,s,n){return Dl(ht(t,i,e,s,n,!0))}function xo(t){return t?t.__v_isVNode===!0:!1}function tn(t,i){return t.type===i.type&&t.key===i.key}const Ol=({key:t})=>t??null,Un=({ref:t,ref_key:i,ref_for:e})=>(typeof t=="number"&&(t=""+t),t!=null?Qt(t)||ue(t)||It(t)?{i:oe,r:t,k:i,f:!!e}:t:null);function m(t,i=null,e=null,s=0,n=null,r=t===Gt?0:1,l=!1,o=!1){const a={__v_isVNode:!0,__v_skip:!0,type:t,props:i,key:i&&Ol(i),ref:i&&Un(i),scopeId:al,slotScopeIds:null,children:e,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:r,patchFlag:s,dynamicProps:n,dynamicChildren:null,appContext:null,ctx:oe};return o?(Qn(a,e),r&128&&t.normalize(a)):e&&(a.shapeFlag|=Qt(e)?8:16),kn>0&&!l&&ke&&(a.patchFlag>0||r&6)&&a.patchFlag!==32&&ke.push(a),a}const ht=Ad;function Ad(t,i=null,e=null,s=0,n=null,r=!1){if((!t||t===td)&&(t=oi),xo(t)){const o=Gi(t,i,!0);return e&&Qn(o,e),kn>0&&!r&&ke&&(o.shapeFlag&6?ke[ke.indexOf(t)]=o:ke.push(o)),o.patchFlag=-2,o}if(Fd(t)&&(t=t.__vccOpts),i){i=Td(i);let{class:o,style:a}=i;o&&!Qt(o)&&(i.class=Et(o)),jt(a)&&(po(a)&&!Ct(a)&&(a=re({},a)),i.style=oo(a))}const l=Qt(t)?1:Bl(t)?128:jc(t)?64:jt(t)?4:It(t)?2:0;return m(t,i,e,s,n,l,r,!0)}function Td(t){return t?po(t)||_l(t)?re({},t):t:null}function Gi(t,i,e=!1,s=!1){const{props:n,ref:r,patchFlag:l,children:o,transition:a}=t,c=i?Ed(n||{},i):n,d={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&Ol(c),ref:i&&i.ref?e&&r?Ct(r)?r.concat(Un(i)):[r,Un(i)]:Un(i):r,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:o,target:t.target,targetStart:t.targetStart,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:i&&t.type!==Gt?l===-1?16:l|16:l,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:a,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&Gi(t.ssContent),ssFallback:t.ssFallback&&Gi(t.ssFallback),placeholder:t.placeholder,el:t.el,anchor:t.anchor,ctx:t.ctx,ce:t.ce};return a&&s&&go(d,a.clone(d)),d}function Ys(t=" ",i=0){return ht(ps,null,t,i)}function $e(t,i){const e=ht(Hn,null,t);return e.staticCount=i,e}function Ft(t="",i=!1){return i?(et(),Ee(oi,null,t)):ht(oi,null,t)}function je(t){return t==null||typeof t=="boolean"?ht(oi):Ct(t)?ht(Gt,null,t.slice()):xo(t)?Ye(t):ht(ps,null,String(t))}function Ye(t){return t.el===null&&t.patchFlag!==-1||t.memo?t:Gi(t)}function Qn(t,i){let e=0;const{shapeFlag:s}=t;if(i==null)i=null;else if(Ct(i))e=16;else if(typeof i=="object")if(s&65){const n=i.default;n&&(n._c&&(n._d=!1),Qn(t,n()),n._c&&(n._d=!0));return}else{e=32;const n=i._;!n&&!_l(i)?i._ctx=oe:n===3&&oe&&(oe.slots._===1?i._=1:(i._=2,t.patchFlag|=1024))}else if(It(i)){if(s&65){Qn(t,{default:i});return}i={default:i,_ctx:oe},e=32}else i=String(i),s&64?(e=16,i=[Ys(i)]):e=8;t.children=i,t.shapeFlag|=e}function Ed(...t){const i={};for(let e=0;e<t.length;e++){const s=t[e];for(const n in s)if(n==="class")i.class!==s.class&&(i.class=Et([i.class,s.class]));else if(n==="style")i.style=oo([i.style,s.style]);else if(ns(n)){const r=i[n],l=s[n];l&&r!==l&&!(Ct(r)&&r.includes(l))?i[n]=r?[].concat(r,l):l:l==null&&r==null&&!ss(n)&&(i[n]=l)}else n!==""&&(i[n]=s[n])}return i}function ze(t,i,e,s=null){Pe(t,i,7,[e,s])}const Md=bl();let Bd=0;function Dd(t,i,e){const s=t.type,n=(i?i.appContext:t.appContext)||Md,r={uid:Bd++,vnode:t,type:s,parent:i,appContext:n,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new oc(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:i?i.provides:Object.create(n.provides),ids:i?i.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Cl(s,n),emitsOptions:yl(s,n),emit:null,emitted:null,propsDefaults:Wt,inheritAttrs:s.inheritAttrs,ctx:Wt,data:Wt,props:Wt,attrs:Wt,slots:Wt,refs:Wt,setupState:Wt,setupContext:null,suspense:e,suspenseId:e?e.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return r.ctx={_:r},r.root=i?i.root:r,r.emit=ud.bind(null,r),t.ce&&t.ce(r),r}let ce=null;const Od=()=>ce||oe;let ts,Js;{const t=as(),i=(e,s)=>{let n;return(n=t[e])||(n=t[e]=[]),n.push(s),r=>{n.length>1?n.forEach(l=>l(r)):n[0](r)}};ts=i("__VUE_INSTANCE_SETTERS__",e=>ce=e),Js=i("__VUE_SSR_SETTERS__",e=>wn=e)}const In=t=>{const i=ce;return ts(t),t.scope.on(),()=>{t.scope.off(),ts(i)}},ir=()=>{ce&&ce.scope.off(),ts(null)};function Pl(t){return t.vnode.shapeFlag&4}let wn=!1;function Pd(t,i=!1,e=!1){i&&Js(i);const{props:s,children:n}=t.vnode,r=Pl(t);vd(t,s,r,i),wd(t,n,e||i);const l=r?Ld(t,i):void 0;return i&&Js(!1),l}function Ld(t,i){const e=t.type;t.accessCache=Object.create(null),t.proxy=new Proxy(t.ctx,id);const{setup:s}=e;if(s){ii();const n=t.setupContext=s.length>1?zd(t):null,r=In(t),l=Cn(s,t,0,[t.props,n]),o=Pr(l);if(ni(),r(),(o||t.sp)&&!Ui(t)&&fl(t),o){if(l.then(ir,ir),i)return l.then(a=>{nr(t,a)}).catch(a=>{us(a,t,0)});t.asyncDep=l}else nr(t,l)}else Ll(t)}function nr(t,i,e){It(i)?t.type.__ssrInlineRender?t.ssrRender=i:t.render=i:jt(i)&&(t.setupState=il(i)),Ll(t)}function Ll(t,i,e){const s=t.type;t.render||(t.render=s.render||Ve);{const n=In(t);ii();try{nd(t)}finally{ni(),n()}}}const Rd={get(t,i){return ae(t,"get",""),t[i]}};function zd(t){const i=e=>{t.exposed=e||{}};return{attrs:new Proxy(t.attrs,Rd),slots:t.slots,emit:t.emit,expose:i}}function ms(t){return t.exposed?t.exposeProxy||(t.exposeProxy=new Proxy(il(Cc(t.exposed)),{get(i,e){if(e in i)return i[e];if(e in mn)return mn[e](t)},has(i,e){return e in i||e in mn}})):t.proxy}function Nd(t,i=!0){return It(t)?t.displayName||t.name:t.name||i&&t.__name}function Fd(t){return It(t)&&"__vccOpts"in t}const $t=(t,i)=>Ec(t,i,wn),jd="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Xs;const sr=typeof window<"u"&&window.trustedTypes;if(sr)try{Xs=sr.createPolicy("vue",{createHTML:t=>t})}catch{}const Rl=Xs?t=>Xs.createHTML(t):t=>t,Hd="http://www.w3.org/2000/svg",Ud="http://www.w3.org/1998/Math/MathML",Ze=typeof document<"u"?document:null,or=Ze&&Ze.createElement("template"),Wd={insert:(t,i,e)=>{i.insertBefore(t,e||null)},remove:t=>{const i=t.parentNode;i&&i.removeChild(t)},createElement:(t,i,e,s)=>{const n=i==="svg"?Ze.createElementNS(Hd,t):i==="mathml"?Ze.createElementNS(Ud,t):e?Ze.createElement(t,{is:e}):Ze.createElement(t);return t==="select"&&s&&s.multiple!=null&&n.setAttribute("multiple",s.multiple),n},createText:t=>Ze.createTextNode(t),createComment:t=>Ze.createComment(t),setText:(t,i)=>{t.nodeValue=i},setElementText:(t,i)=>{t.textContent=i},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>Ze.querySelector(t),setScopeId(t,i){t.setAttribute(i,"")},insertStaticContent(t,i,e,s,n,r){const l=e?e.previousSibling:i.lastChild;if(n&&(n===r||n.nextSibling))for(;i.insertBefore(n.cloneNode(!0),e),!(n===r||!(n=n.nextSibling)););else{or.innerHTML=Rl(s==="svg"?`<svg>${t}</svg>`:s==="mathml"?`<math>${t}</math>`:t);const o=or.content;if(s==="svg"||s==="mathml"){const a=o.firstChild;for(;a.firstChild;)o.appendChild(a.firstChild);o.removeChild(a)}i.insertBefore(o,e)}return[l?l.nextSibling:i.firstChild,e?e.previousSibling:i.lastChild]}},Vd=Symbol("_vtc");function Kd(t,i,e){const s=t[Vd];s&&(i=(i?[i,...s]:[...s]).join(" ")),i==null?t.removeAttribute("class"):e?t.setAttribute("class",i):t.className=i}const es=Symbol("_vod"),zl=Symbol("_vsh"),Nl={name:"show",beforeMount(t,{value:i},{transition:e}){t[es]=t.style.display==="none"?"":t.style.display,e&&i?e.beforeEnter(t):en(t,i)},mounted(t,{value:i},{transition:e}){e&&i&&e.enter(t)},updated(t,{value:i,oldValue:e},{transition:s}){!i!=!e&&(s?i?(s.beforeEnter(t),en(t,!0),s.enter(t)):s.leave(t,()=>{en(t,!1)}):en(t,i))},beforeUnmount(t,{value:i}){en(t,i)}};function en(t,i){t.style.display=i?t[es]:"none",t[zl]=!i}const qd=Symbol(""),Gd=/(?:^|;)\s*display\s*:/;function Zd(t,i,e){const s=t.style,n=Qt(e);let r=!1;if(e&&!n){if(i)if(Qt(i))for(const l of i.split(";")){const o=l.slice(0,l.indexOf(":")).trim();e[o]==null&&on(s,o,"")}else for(const l in i)e[l]==null&&on(s,l,"");for(const l in e){l==="display"&&(r=!0);const o=e[l];o!=null?Jd(t,l,!Qt(i)&&i?i[l]:void 0,o)||on(s,l,o):on(s,l,"")}}else if(n){if(i!==e){const l=s[qd];l&&(e+=";"+l),s.cssText=e,r=Gd.test(e)}}else i&&t.removeAttribute("style");es in t&&(t[es]=r?s.display:"",t[zl]&&(s.display="none"))}const rr=/\s*!important$/;function on(t,i,e){if(Ct(e))e.forEach(s=>on(t,i,s));else if(e==null&&(e=""),i.startsWith("--"))t.setProperty(i,e);else{const s=Yd(t,i);rr.test(e)?t.setProperty(pi(s),e.replace(rr,""),"important"):t[s]=e}}const lr=["Webkit","Moz","ms"],Ts={};function Yd(t,i){const e=Ts[i];if(e)return e;let s=pe(i);if(s!=="filter"&&s in t)return Ts[i]=s;s=rs(s);for(let n=0;n<lr.length;n++){const r=lr[n]+s;if(r in t)return Ts[i]=r}return i}function Jd(t,i,e,s){return t.tagName==="TEXTAREA"&&(i==="width"||i==="height")&&Qt(s)&&e===s}const ar="http://www.w3.org/1999/xlink";function cr(t,i,e,s,n,r=nc(i)){s&&i.startsWith("xlink:")?e==null?t.removeAttributeNS(ar,i.slice(6,i.length)):t.setAttributeNS(ar,i,e):e==null||r&&!Nr(e)?t.removeAttribute(i):t.setAttribute(i,r?"":De(e)?String(e):e)}function dr(t,i,e,s,n){if(i==="innerHTML"||i==="textContent"){e!=null&&(t[i]=i==="innerHTML"?Rl(e):e);return}const r=t.tagName;if(i==="value"&&r!=="PROGRESS"&&!r.includes("-")){const o=r==="OPTION"?t.getAttribute("value")||"":t.value,a=e==null?t.type==="checkbox"?"on":"":String(e);(o!==a||!("_value"in t))&&(t.value=a),e==null&&t.removeAttribute(i),t._value=e;return}let l=!1;if(e===""||e==null){const o=typeof t[i];o==="boolean"?e=Nr(e):e==null&&o==="string"?(e="",l=!0):o==="number"&&(e=0,l=!0)}try{t[i]=e}catch{}l&&t.removeAttribute(n||i)}function ci(t,i,e,s){t.addEventListener(i,e,s)}function Xd(t,i,e,s){t.removeEventListener(i,e,s)}const ur=Symbol("_vei");function Qd(t,i,e,s,n=null){const r=t[ur]||(t[ur]={}),l=r[i];if(s&&l)l.value=s;else{const[o,a]=iu(i);if(s){const c=r[i]=ou(s,n);ci(t,o,c,a)}else l&&(Xd(t,o,l,a),r[i]=void 0)}}const tu=/(Once|Passive|Capture)$/,eu=/^on:?(?:Once|Passive|Capture)$/;function iu(t){let i,e;for(;(e=t.match(tu))&&!eu.test(t);)i||(i={}),t=t.slice(0,t.length-e[1].length),i[e[1].toLowerCase()]=!0;return[t[2]===":"?t.slice(3):pi(t.slice(2)),i]}let Es=0;const nu=Promise.resolve(),su=()=>Es||(nu.then(()=>Es=0),Es=Date.now());function ou(t,i){const e=s=>{if(!s._vts)s._vts=Date.now();else if(s._vts<=e.attached)return;const n=e.value;if(Ct(n)){const r=s.stopImmediatePropagation;s.stopImmediatePropagation=()=>{r.call(s),s._stopped=!0};const l=n.slice(),o=[s];for(let a=0;a<l.length&&!s._stopped;a++){const c=l[a];c&&Pe(c,i,5,o)}}else Pe(n,i,5,[s])};return e.value=t,e.attached=su(),e}const fr=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&t.charCodeAt(2)>96&&t.charCodeAt(2)<123,ru=(t,i,e,s,n,r)=>{const l=n==="svg";i==="class"?Kd(t,s,l):i==="style"?Zd(t,e,s):ns(i)?ss(i)||Qd(t,i,e,s,r):(i[0]==="."?(i=i.slice(1),!0):i[0]==="^"?(i=i.slice(1),!1):lu(t,i,s,l))?(dr(t,i,s),!t.tagName.includes("-")&&(i==="value"||i==="checked"||i==="selected")&&cr(t,i,s,l,r,i!=="value")):t._isVueCE&&(au(t,i)||t._def.__asyncLoader&&(/[A-Z]/.test(i)||!Qt(s)))?dr(t,pe(i),s,r,i):(i==="true-value"?t._trueValue=s:i==="false-value"&&(t._falseValue=s),cr(t,i,s,l))};function lu(t,i,e,s){if(s)return!!(i==="innerHTML"||i==="textContent"||i in t&&fr(i)&&It(e));if(i==="spellcheck"||i==="draggable"||i==="translate"||i==="autocorrect"||i==="sandbox"&&t.tagName==="IFRAME"||i==="form"||i==="list"&&t.tagName==="INPUT"||i==="type"&&t.tagName==="TEXTAREA")return!1;if(i==="width"||i==="height"){const n=t.tagName;if(n==="IMG"||n==="VIDEO"||n==="CANVAS"||n==="SOURCE")return!1}return fr(i)&&Qt(e)?!1:i in t}function au(t,i){const e=t._def.props;if(!e)return!1;const s=pe(i);return Array.isArray(e)?e.some(n=>pe(n)===s):Object.keys(e).some(n=>pe(n)===s)}const Zi=t=>{const i=t.props["onUpdate:modelValue"]||!1;return Ct(i)?e=>jn(i,e):i};function cu(t){t.target.composing=!0}function hr(t){const i=t.target;i.composing&&(i.composing=!1,i.dispatchEvent(new Event("input")))}const ei=Symbol("_assign");function pr(t,i,e){return i&&(t=t.trim()),e&&(t=ls(t)),t}const is={created(t,{modifiers:{lazy:i,trim:e,number:s}},n){t[ei]=Zi(n);const r=s||n.props&&n.props.type==="number";ci(t,i?"change":"input",l=>{l.target.composing||t[ei](pr(t.value,e,r))}),(e||r)&&ci(t,"change",()=>{t.value=pr(t.value,e,r)}),i||(ci(t,"compositionstart",cu),ci(t,"compositionend",hr),ci(t,"change",hr))},mounted(t,{value:i}){t.value=i??""},beforeUpdate(t,{value:i,oldValue:e,modifiers:{lazy:s,trim:n,number:r}},l){if(t[ei]=Zi(l),t.composing)return;const o=(r||t.type==="number")&&!/^0\d/.test(t.value)?ls(t.value):t.value,a=i??"";if(o===a)return;const c=t.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===t&&t.type!=="range"&&(s&&i===e||n&&t.value.trim()===a)||(t.value=a)}},Rn={deep:!0,created(t,i,e){t[ei]=Zi(e),ci(t,"change",()=>{const s=t._modelValue,n=xn(t),r=t.checked,l=t[ei];if(Ct(s)){const o=ro(s,n),a=o!==-1;if(r&&!a)l(s.concat(n));else if(!r&&a){const c=[...s];c.splice(o,1),l(c)}}else if(Ji(s)){const o=new Set(s);r?o.add(n):o.delete(n),l(o)}else l(Fl(t,r))})},mounted:mr,beforeUpdate(t,i,e){t[ei]=Zi(e),mr(t,i,e)}};function mr(t,{value:i,oldValue:e},s){t._modelValue=i;let n;if(Ct(i))n=ro(i,s.props.value)>-1;else if(Ji(i))n=i.has(s.props.value);else{if(i===e)return;n=Xi(i,Fl(t,!0))}t.checked!==n&&(t.checked=n)}const du={deep:!0,created(t,{value:i,modifiers:{number:e}},s){t._modelValue=i,ci(t,"change",()=>{const n=Array.prototype.filter.call(t.options,r=>r.selected).map(r=>e?ls(xn(r)):xn(r));t[ei](t.multiple?Ji(t._modelValue)?new Set(n):n:n[0]),t._assigning=!0,sl(()=>{t._assigning=!1})}),t[ei]=Zi(s)},mounted(t,{value:i}){gr(t,i)},beforeUpdate(t,{value:i},e){t._modelValue=i,t[ei]=Zi(e)},updated(t,{value:i}){t._assigning||gr(t,i)}};function gr(t,i){const e=t.multiple,s=Ct(i);if(!(e&&!s&&!Ji(i))){for(let n=0,r=t.options.length;n<r;n++){const l=t.options[n],o=xn(l);if(e)if(s){const a=typeof o;a==="string"||a==="number"?l.selected=i.some(c=>String(c)===String(o)):l.selected=ro(i,o)>-1}else l.selected=i.has(o);else if(Xi(xn(l),i)){t.selectedIndex!==n&&(t.selectedIndex=n);return}}!e&&t.selectedIndex!==-1&&(t.selectedIndex=-1)}}function xn(t){return"_value"in t?t._value:t.value}function Fl(t,i){const e=i?"_trueValue":"_falseValue";return e in t?t[e]:i}const uu=["ctrl","shift","alt","meta"],fu={stop:t=>t.stopPropagation(),prevent:t=>t.preventDefault(),self:t=>t.target!==t.currentTarget,ctrl:t=>!t.ctrlKey,shift:t=>!t.shiftKey,alt:t=>!t.altKey,meta:t=>!t.metaKey,left:t=>"button"in t&&t.button!==0,middle:t=>"button"in t&&t.button!==1,right:t=>"button"in t&&t.button!==2,exact:(t,i)=>uu.some(e=>t[`${e}Key`]&&!i.includes(e))},Te=(t,i)=>{if(!t)return t;const e=t._withMods||(t._withMods={}),s=i.join(".");return e[s]||(e[s]=((n,...r)=>{for(let l=0;l<i.length;l++){const o=fu[i[l]];if(o&&o(n,i))return}return t(n,...r)}))},hu={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},pu=(t,i)=>{const e=t._withKeys||(t._withKeys={}),s=i.join(".");return e[s]||(e[s]=(n=>{if(!("key"in n))return;const r=pi(n.key);if(i.some(l=>l===r||hu[l]===r))return t(n)}))},mu=re({patchProp:ru},Wd);let vr;function gu(){return vr||(vr=_d(mu))}const jl=((...t)=>{const i=gu().createApp(...t),{mount:e}=i;return i.mount=s=>{const n=bu(s);if(!n)return;const r=i._component;!It(r)&&!r.render&&!r.template&&(r.template=n.innerHTML),n.nodeType===1&&(n.textContent="");const l=e(n,!1,vu(n));return n instanceof Element&&(n.removeAttribute("v-cloak"),n.setAttribute("data-v-app","")),l},i});function vu(t){if(t instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&t instanceof MathMLElement)return"mathml"}function bu(t){return Qt(t)?document.querySelector(t):t}function yu(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function we(t){const i=yu();if(i)try{return i(t)}catch{try{const e=t.startsWith("node:")?t.slice(5):`node:${t}`;return i(e)}catch{}}}function _o(){var i;if(typeof window<"u"&&window.process)return window.process;const t=we("process");return t&&t.versions?t:typeof process<"u"&&((i=process.versions)!=null&&i.node)?process:globalThis.process}function Hl(){var i,e;const t=_o();if(t&&((i=t.versions)!=null&&i.node))return!0;if(typeof window<"u"&&window.siyuan){const s=we("child_process");if(s&&typeof s.spawn=="function")return!0}return!!(typeof process<"u"&&((e=process.versions)!=null&&e.node))}function _n(){const t=_o();if(t!=null&&t.platform)return t.platform;if(typeof process<"u"&&process.platform)return process.platform;const i=we("os");if(i&&typeof i.platform=="function")return i.platform();if(typeof navigator<"u"){const e=navigator.userAgent.toLowerCase();if(e.includes("win"))return"win32";if(e.includes("mac"))return"darwin";if(e.includes("linux"))return"linux"}return"web"}function Ul(){var s,n;const t=_o(),i={...(t==null?void 0:t.env)||{}};if(_n()==="win32"){const r=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(s=t==null?void 0:t.env)!=null&&s.APPDATA?`${t.env.APPDATA}\\npm`:"",(n=t==null?void 0:t.env)!=null&&n.USERPROFILE?`${t.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(i).find(c=>c.toLowerCase()==="path")||"PATH",a=(i[l]||"").split(";").filter(Boolean);for(const c of r)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);i[l]=a.join(";")}return i}function Qs(t){var e,s,n;if(!t)return"";if(/^[a-zA-Z]:[/\\]/.test(t))return t.replace(/\\/g,"/");let i="";if(typeof window<"u"&&((n=(s=(e=window.siyuan)==null?void 0:e.config)==null?void 0:s.system)!=null&&n.dataDir)&&(i=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),i&&t.startsWith("/data/")){const r=t.slice(6);return`${i}/${r}`.replace(/\\/g,"/")}return t}function ku(){const t=we("os"),i=we("path");if(t&&typeof t.tmpdir=="function"){const e=t.tmpdir();return i&&typeof i.join=="function"?i.join(e,"siyuan-slidev-pro").replace(/\\/g,"/"):`${e}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class So{constructor(i){wt(this,"runner");this.runner=i||So.defaultRunner}static async defaultRunner(i,e){var s;try{let n=(s=we("child_process"))==null?void 0:s.execFile;if(!n){const a=await import("node:child_process").catch(()=>({}));n=a==null?void 0:a.execFile}if(!n)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=_n()==="win32",o=Ul();return await new Promise(a=>{n(i,e,{timeout:5e3,shell:l,env:o},(c,d,p)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:p?String(p).trim():""})})})}catch(n){return{code:-1,stdout:"",stderr:String(n)}}}async detect(){const i=Hl(),e=_n();if(!i)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let s=!1,n,r=!1,l;try{const o=await this.runner("node",["-v"]);o.code===0&&o.stdout.startsWith("v")&&(s=!0,n=o.stdout)}catch{}if(s){try{const o=e==="win32"?"slidev.cmd":"slidev",a=await this.runner(o,["--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}if(!r)try{const o=e==="win32"?"npx.cmd":"npx",a=await this.runner(o,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}}return{hasNode:s,nodeVersion:n,hasSlidevCli:r,slidevVersion:l,platform:e,isDesktop:i}}}class wu{constructor(){wt(this,"iframe",null);wt(this,"isReady",!1);wt(this,"pageChangedHandlers",[]);wt(this,"readyHandlers",[]);wt(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(i,e){var n;if(!((n=this.iframe)!=null&&n.contentWindow))return;const s={target:"slidev",sender:"siyuan",type:i,...e};try{this.iframe.contentWindow.postMessage(s,"*")}catch(r){console.warn("[NativeSlidevBridge] postMessage error:",r)}}navigateToPage(i){this.postMessage("navigate",{no:i})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(i){return this.pageChangedHandlers.push(i),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(e=>e!==i)}}onReady(i){return this.readyHandlers.push(i),()=>{this.readyHandlers=this.readyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){const e=i.data;if(!(!e||e.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const s of this.readyHandlers)s()}if(e.type==="update-state"&&e.navState){const s=e.navState;this.currentState={no:s.no??this.currentState.no,clicks:s.clicks??this.currentState.clicks,total:s.total??this.currentState.total,hasNext:s.hasNext,hasPrev:s.hasPrev};for(const n of this.pageChangedHandlers)n(this.currentState.no,this.currentState.total||1,this.currentState)}else if(e.type==="navigate"&&typeof e.no=="number"){this.currentState.no=e.no;for(const s of this.pageChangedHandlers)s(e.no,this.currentState.total||1,this.currentState)}}}}class xu{constructor(i){wt(this,"childProcess",null);wt(this,"activePort",null);wt(this,"isRunning",!1);wt(this,"defaultPort");wt(this,"maxPortRetries");wt(this,"probeTimeoutMs");wt(this,"customSpawner");wt(this,"customPortChecker");this.defaultPort=(i==null?void 0:i.defaultPort)||3030,this.maxPortRetries=(i==null?void 0:i.maxPortRetries)||20,this.probeTimeoutMs=(i==null?void 0:i.probeTimeoutMs)||1e4,this.customSpawner=i==null?void 0:i.customSpawner,this.customPortChecker=i==null?void 0:i.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(i){if(this.customPortChecker)return this.customPortChecker(i);try{let e=we("net");return e||(e=await import("node:net").catch(()=>({}))),e!=null&&e.createServer?await new Promise(s=>{const n=e.createServer();n.once("error",()=>s(!1)),n.once("listening",()=>{n.close(()=>s(!0))}),n.listen(i,"127.0.0.1")}):!0}catch{return!0}}async allocPort(i){const e=i||this.defaultPort;for(let s=0;s<this.maxPortRetries;s++){const n=e+s;if(await this.isPortAvailable(n))return n}return e}async pollServerReady(i,e=8e3,s=300){const n=Date.now();for(;Date.now()-n<e;){try{const r=new AbortController,l=setTimeout(()=>r.abort(),s),o=await fetch(i,{method:"HEAD",mode:"no-cors",signal:r.signal}).catch(()=>null);if(clearTimeout(l),o)return!0}catch{}await new Promise(r=>setTimeout(r,s))}return!1}async startServer(i,e){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const s=await this.allocPort(e);this.activePort=s;const r=_n()==="win32"?"npx.cmd":"npx",l=Qs(i),o=["@slidev/cli",l,"--port",String(s),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(r,o,{detached:!1});else{let p=(a=we("child_process"))==null?void 0:a.spawn;if(!p){const k=await import("node:child_process").catch(()=>({}));p=k==null?void 0:k.spawn}if(!p)throw new Error("child_process spawn not available in current runtime");const g=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,u=Ul();this.childProcess=p(r,o,{cwd:g,detached:!1,shell:!0,env:{...u,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${s}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:s,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${s})`}):{success:!0,port:s,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:s,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var i;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),_n()==="win32"&&this.childProcess.pid&&!this.customSpawner){const s=(i=we("child_process"))==null?void 0:i.exec;s?s(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:n})=>{var r;n(`taskkill /pid ${(r=this.childProcess)==null?void 0:r.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Co{constructor(){wt(this,"iframe",null);wt(this,"isReady",!1);wt(this,"pendingMessages",[]);wt(this,"slideChangedHandlers",[]);wt(this,"blockClickedHandlers",[]);wt(this,"openInEditorHandlers",[]);wt(this,"clientReadyHandlers",[]);wt(this,"openPeekDrawerHandlers",[]);wt(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(i,e){var n;const s={source:"siyuan-slidev-host",action:i,payload:e};if(!((n=this.iframe)!=null&&n.contentWindow)||!this.isReady){this.pendingMessages.push(s);return}try{this.iframe.contentWindow.postMessage(s,"*")}catch(r){console.warn("[WebSandboxBridge] postMessage error:",r)}}updateSlides(i,e,s,n){this.postMessage("UPDATE_SLIDES",{slides:i,config:e,fullMarkdown:s,customThemeCss:n})}navigatePage(i){this.postMessage("NAVIGATE_PAGE",{pageIndex:i})}highlightElement(i){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:i})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(i){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:i})}onSlideChanged(i){return this.slideChangedHandlers.push(i),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(e=>e!==i)}}onBlockClicked(i){return this.blockClickedHandlers.push(i),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(e=>e!==i)}}onOpenInEditor(i){return this.openInEditorHandlers.push(i),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(e=>e!==i)}}onOpenPeekDrawer(i){return this.openPeekDrawerHandlers.push(i),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(e=>e!==i)}}onRequestToggleFullscreen(i){return this.toggleFullscreenHandlers.push(i),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(e=>e!==i)}}onClientReady(i){return this.clientReadyHandlers.push(i),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){var s;const e=i.data;if(!(!e||e.source!=="siyuan-slidev-client"))switch(e.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const n=this.pendingMessages.shift();n&&((s=this.iframe)!=null&&s.contentWindow)&&this.iframe.contentWindow.postMessage(n,"*")}for(const n of this.clientReadyHandlers)n();break;case"SLIDE_CHANGED":if(e.payload.currentPage!==void 0)for(const n of this.slideChangedHandlers)n(e.payload.currentPage,e.payload.totalPages||1,e.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(e.payload.clickedBlockId)for(const n of this.blockClickedHandlers)n(e.payload.clickedBlockId,e.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(e.payload.blockId||e.payload.clickedBlockId){const n=e.payload.blockId||e.payload.clickedBlockId||"";for(const r of this.openInEditorHandlers)r(n,e.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(e.payload.peekType){const n=e.payload.blockId||e.payload.url||"",r={peekType:e.payload.peekType,target:n,title:e.payload.title};for(const l of this.openPeekDrawerHandlers)l(r)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const n of this.toggleFullscreenHandlers)n();break}}}const Wl={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},_u=`<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-3 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,Su=`// Auto-generated by SiYuan Slidev Studio
export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,Cu=`${Fs}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: 100% !important;
  height: 100% !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
}
.slide-list-media {
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: 100% !important;
  height: 100% !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
}
.slide-video-container {
  display: flex !important;
  justify-content: center !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与三栏（超级块分栏）布局：去除列表圆点标记与缩进 */
.three-cols-header ul,
.three-cols-header ol,
.two-cols-header ul,
.two-cols-header ol,
.two-cols ul,
.two-cols ol,
.col-1 ul,
.col-1 ol,
.col-2 ul,
.col-2 ol,
.col-3 ul,
.col-3 ol,
.grid-cols-2 ul,
.grid-cols-2 ol,
.grid-cols-3 ul,
.grid-cols-3 ol {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
  margin-left: 0 !important;
}
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.grid-cols-2 li,
.grid-cols-3 li {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
  margin-left: 0 !important;
}
.three-cols-header li::marker,
.two-cols-header li::marker,
.two-cols li::marker,
.col-1 li::marker,
.col-2 li::marker,
.col-3 li::marker {
  content: none !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function $u(t){var n;const i=[],e=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let s;for(;(s=e.exec(t))!==null;){const r=(n=s[1])==null?void 0:n.trim();r&&!i.includes(r)&&i.push(r)}return i}class Iu{constructor(i){wt(this,"workspacePath");wt(this,"slidesFileName");wt(this,"cliBridge",new eo);const e=ku();!(i!=null&&i.workspacePath)||i.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=e:this.workspacePath=i.workspacePath,this.slidesFileName=(i==null?void 0:i.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(i="default"){const e={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return i&&i!=="default"&&(e.dependencies[`@slidev/theme-${i}`]="latest"),JSON.stringify(e,null,2)}buildSlidesMarkdown(i){return this.cliBridge.buildStandardSlidevMarkdown(i)}async scaffold(i,e){const s=this.buildSlidesMarkdown(i),n=this.generatePackageJson(i.config.theme),r=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,o=Qs(r),a=Qs(l),c=$u(s);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const v of c){const w=Wl[v]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${v}
// #endregion snippet
`;d.set(v,w)}i.slides.some(v=>{var w;return((w=v.frontmatter)==null?void 0:w.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",_u),d.set("setup/root.ts",Su),d.set("styles/index.css",Cu);const g=we("fs"),u=we("path");let k=!1;const h=u!=null&&u.dirname?u.dirname(o):"",b=/^[a-zA-Z]:[/\\]/.test(o)||o.includes("siyuan-slidev-pro");if(g&&u&&b)try{g.existsSync(h)||g.mkdirSync(h,{recursive:!0}),g.writeFileSync(a,n,"utf-8"),g.writeFileSync(o,s,"utf-8");for(const[v,w]of d.entries()){const $=u.join(h,v),I=u.dirname($);g.existsSync(I)||g.mkdirSync(I,{recursive:!0}),g.existsSync($)||g.writeFileSync($,w,"utf-8")}k=!0}catch{}if(!k&&e)try{const v=typeof Blob<"u"?new Blob([s],{type:"text/markdown;charset=utf-8"}):Buffer.from(s,"utf-8"),w=typeof Blob<"u"?new Blob([n],{type:"application/json;charset=utf-8"}):Buffer.from(n,"utf-8");await e(l,!1,w),await e(r,!1,v);for(const[$,I]of d.entries()){const x=`${this.workspacePath}/${$}`,C=typeof Blob<"u"?new Blob([I],{type:"text/plain;charset=utf-8"}):Buffer.from(I,"utf-8");await e(x,!1,C).catch(()=>{})}return{success:!0,slidesPath:r,physicalSlidesPath:o,packageJsonPath:l}}catch(v){return{success:!1,slidesPath:r,physicalSlidesPath:o,packageJsonPath:l,error:String(v)}}return{success:!0,slidesPath:r,physicalSlidesPath:o,packageJsonPath:l}}}class Au{constructor(){wt(this,"mode","web-sandbox");wt(this,"webBridge");wt(this,"cliBridge");wt(this,"nativeBridge");wt(this,"processManager");wt(this,"scaffolder");wt(this,"envDetector");this.webBridge=new Co,this.cliBridge=new eo,this.nativeBridge=new wu,this.processManager=new xu,this.scaffolder=new Iu,this.envDetector=new So}getMode(){return this.mode}setMode(i){this.mode=i}async startProMode(i,e){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const n=await this.scaffolder.scaffold(i,e);if(!n.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${n.error}`};const r=n.physicalSlidesPath||n.slidesPath,l=await this.processManager.startServer(r);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const Tu={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Eu={key:0},Mu={key:1},Bu={key:2},Du={key:3},Ou={key:4},Pu={key:5},Lu={key:6},Ru={key:7},zu={key:8},Nu={key:9},Fu={key:10},ju={key:11},Hu={key:12},Uu={key:13},Wu={key:14},Vu={key:15},Ku={key:16},qu={key:17},Gu={key:18},Zu={key:19},Yu={key:20},Ju={key:21},Xu={key:22},Qu={key:23},tf={key:24},ef={key:25},nf={key:26},sf={key:27},of={key:28},rf={key:29},lf={key:30},af={key:31},cf={key:32},df={key:33},uf={key:34},ff={key:35},hf={key:36},pf={key:37},mf={key:38},gf={key:39},vf={key:40},bf={key:41},yf={key:42},kf={key:43},wf={key:44},xf={key:45},_f={key:46},Sf={key:47},Cf={key:48},$f={key:49},If={key:50},Af={key:51},Tf={key:52},Ef=be({__name:"SlidevIcon",props:{name:{}},setup(t){return(i,e)=>(et(),nt("svg",Tu,[t.name==="fullscreen"||t.name==="maximize"?(et(),nt("g",Eu,[...e[0]||(e[0]=[m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("polyline",{points:"9 21 3 21 3 15"},null,-1),m("polyline",{points:"21 15 21 21 15 21"},null,-1),m("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):t.name==="minimize"?(et(),nt("g",Mu,[...e[1]||(e[1]=[m("polyline",{points:"4 14 10 14 10 20"},null,-1),m("polyline",{points:"20 10 14 10 14 4"},null,-1),m("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),m("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):t.name==="close"||t.name==="x"?(et(),nt("g",Bu,[...e[2]||(e[2]=[m("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),m("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):t.name==="edit"?(et(),nt("g",Du,[...e[3]||(e[3]=[m("path",{d:"M12 20h9"},null,-1),m("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):t.name==="eye"?(et(),nt("g",Ou,[...e[4]||(e[4]=[m("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),m("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):t.name==="external-link"||t.name==="window"?(et(),nt("g",Pu,[...e[5]||(e[5]=[m("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):t.name==="arrow-left"?(et(),nt("g",Lu,[...e[6]||(e[6]=[m("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),m("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):t.name==="arrow-right"?(et(),nt("g",Ru,[...e[7]||(e[7]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):t.name==="plus"?(et(),nt("g",zu,[...e[8]||(e[8]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="minus"?(et(),nt("g",Nu,[...e[9]||(e[9]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="split-preview"?(et(),nt("g",Fu,[...e[10]||(e[10]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),m("path",{d:"M12 3v18"},null,-1)])])):t.name==="import"?(et(),nt("g",ju,[...e[11]||(e[11]=[m("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),m("polyline",{points:"7 9 12 14 17 9"},null,-1),m("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):t.name==="presenter"?(et(),nt("g",Hu,[...e[12]||(e[12]=[m("path",{d:"M2 3h20"},null,-1),m("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),m("path",{d:"m7 21 5-5 5 5"},null,-1)])])):t.name==="video"?(et(),nt("g",Uu,[...e[13]||(e[13]=[m("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),m("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):t.name==="step"?(et(),nt("g",Wu,[...e[14]||(e[14]=[m("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):t.name==="motion"?(et(),nt("g",Vu,[...e[15]||(e[15]=[m("path",{d:"M5 12h14"},null,-1),m("path",{d:"m12 5 7 7-7 7"},null,-1),m("path",{d:"M5 6h4"},null,-1),m("path",{d:"M5 18h4"},null,-1)])])):t.name==="columns"?(et(),nt("g",Ku,[...e[16]||(e[16]=[m("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),m("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):t.name==="code"?(et(),nt("g",qu,[...e[17]||(e[17]=[m("polyline",{points:"16 18 22 12 16 6"},null,-1),m("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):t.name==="insert-above"?(et(),nt("g",Gu,[...e[18]||(e[18]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),m("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),m("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):t.name==="insert-below"?(et(),nt("g",Zu,[...e[19]||(e[19]=[m("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),m("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="broom"?(et(),nt("g",Yu,[...e[20]||(e[20]=[m("path",{d:"m18 15-6-6"},null,-1),m("path",{d:"M4 20h16"},null,-1),m("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):t.name==="trash"?(et(),nt("g",Ju,[...e[21]||(e[21]=[m("path",{d:"M3 6h18"},null,-1),m("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),m("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):t.name==="ai"||t.name==="sparkles"?(et(),nt("g",Xu,[...e[22]||(e[22]=[m("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):t.name==="palette"?(et(),nt("g",Qu,[...e[23]||(e[23]=[$e('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-b8552023></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-b8552023></path>',5)])])):t.name==="ratio"?(et(),nt("g",tf,[...e[24]||(e[24]=[m("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):t.name==="transition"?(et(),nt("g",ef,[...e[25]||(e[25]=[m("path",{d:"M8 3 4 7l4 4"},null,-1),m("path",{d:"M4 7h16"},null,-1),m("path",{d:"m16 21 4-4-4-4"},null,-1),m("path",{d:"M20 17H4"},null,-1)])])):t.name==="export-html"?(et(),nt("g",nf,[...e[26]||(e[26]=[m("polyline",{points:"16 16 12 12 8 16"},null,-1),m("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),m("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):t.name==="export-pdf"?(et(),nt("g",sf,[...e[27]||(e[27]=[m("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),m("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),m("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):t.name==="pin"?(et(),nt("g",of,[...e[28]||(e[28]=[m("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),m("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):t.name==="refresh"?(et(),nt("g",rf,[...e[29]||(e[29]=[m("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),m("path",{d:"M21 3v5h-5"},null,-1),m("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),m("path",{d:"M8 16H3v5"},null,-1)])])):t.name==="outline"?(et(),nt("g",lf,[...e[30]||(e[30]=[m("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),m("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),m("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):t.name==="chevron-left"?(et(),nt("g",af,[...e[31]||(e[31]=[m("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):t.name==="chevron-right"?(et(),nt("g",cf,[...e[32]||(e[32]=[m("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):t.name==="copy"?(et(),nt("g",df,[...e[33]||(e[33]=[m("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),m("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):t.name==="image"?(et(),nt("g",uf,[...e[34]||(e[34]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),m("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),m("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):t.name==="search"?(et(),nt("g",ff,[...e[35]||(e[35]=[m("circle",{cx:"11",cy:"11",r:"7"},null,-1),m("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):t.name==="settings"||t.name==="gear"?(et(),nt("g",hf,[...e[36]||(e[36]=[m("circle",{cx:"12",cy:"12",r:"3"},null,-1),m("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):t.name==="notes"||t.name==="file-text"?(et(),nt("g",pf,[...e[37]||(e[37]=[$e('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-b8552023></path><polyline points="14 2 14 8 20 8" data-v-b8552023></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-b8552023></line><line x1="16" y1="17" x2="8" y2="17" data-v-b8552023></line><line x1="10" y1="9" x2="8" y2="9" data-v-b8552023></line>',5)])])):t.name==="focus"||t.name==="target"?(et(),nt("g",mf,[...e[38]||(e[38]=[m("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),m("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),m("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):t.name==="layout-cover"||t.name==="cover"?(et(),nt("g",gf,[...e[39]||(e[39]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),m("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),m("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):t.name==="layout-default"||t.name==="default"?(et(),nt("g",vf,[...e[40]||(e[40]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-b8552023></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-b8552023></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-b8552023></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-b8552023></line>',5)])])):t.name==="layout-two-cols"||t.name==="two-cols"?(et(),nt("g",bf,[...e[41]||(e[41]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-b8552023></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-b8552023></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-b8552023></line><line x1="5" y1="15" x2="8" y2="15" data-v-b8552023></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-b8552023></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-b8552023></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-b8552023></line>',8)])])):t.name==="layout-two-cols-header"||t.name==="two-cols-header"?(et(),nt("g",yf,[...e[42]||(e[42]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b8552023></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-b8552023></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-b8552023></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-b8552023></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-b8552023></line>',7)])])):t.name==="layout-three-cols-header"||t.name==="three-cols-header"?(et(),nt("g",kf,[...e[43]||(e[43]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b8552023></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-b8552023></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-b8552023></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-b8552023></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-b8552023></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-b8552023></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-b8552023></line>',10)])])):t.name==="layout-image-right"||t.name==="image-right"?(et(),nt("g",wf,[...e[44]||(e[44]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b8552023></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-b8552023></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-b8552023></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-b8552023></line><circle cx="15.5" cy="8.5" r="1.2" data-v-b8552023></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-b8552023></polyline>',7)])])):t.name==="layout-image-left"||t.name==="image-left"?(et(),nt("g",xf,[...e[45]||(e[45]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b8552023></line><circle cx="6" cy="8.5" r="1.2" data-v-b8552023></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-b8552023></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-b8552023></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-b8552023></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-b8552023></line>',7)])])):t.name==="layout-center"||t.name==="center"?(et(),nt("g",_f,[...e[46]||(e[46]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="layout-fact"||t.name==="fact"?(et(),nt("g",Sf,[...e[47]||(e[47]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><circle cx="8" cy="9" r="1.5" data-v-b8552023></circle><line x1="14" y1="8" x2="9" y2="14" data-v-b8552023></line><circle cx="15" cy="13" r="1.5" data-v-b8552023></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-b8552023></line>',5)])])):t.name==="layout-intro"||t.name==="intro"?(et(),nt("g",Cf,[...e[48]||(e[48]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><circle cx="7.5" cy="9.5" r="2" data-v-b8552023></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-b8552023></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-b8552023></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-b8552023></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-b8552023></line>',6)])])):t.name==="layout-quote"||t.name==="quote"?(et(),nt("g",$f,[...e[49]||(e[49]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-b8552023></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-b8552023></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-b8552023></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-b8552023></line>',5)])])):t.name==="desktop"||t.name==="monitor"?(et(),nt("g",If,[...e[50]||(e[50]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):t.name==="mobile"||t.name==="smartphone"||t.name==="phone"?(et(),nt("g",Af,[...e[51]||(e[51]=[m("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),m("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):(et(),nt("g",Tf,[...e[52]||(e[52]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Le=(t,i)=>{const e=t.__vccOpts||t;for(const[s,n]of i)e[s]=n;return e},kt=Le(Ef,[["__scopeId","data-v-b8552023"]]);function se(t,i){var n;if(typeof document>"u"||!t)return;const e=(n=globalThis.CSS)!=null&&n.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),s=document.querySelectorAll(`[data-node-id="${e}"]`);!s||s.length===0||s.forEach(r=>{for(const[l,o]of Object.entries(i))o!=null&&o!==""?r.setAttribute(l,String(o)):r.removeAttribute(l)})}function Mf(t){if(typeof document>"u")return;const i=`.protyle-wysiwyg [${ft}], .protyle-wysiwyg [${qt}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,e=document.querySelectorAll(i);!e||e.length===0||e.forEach(s=>{const n=s.getAttribute("data-node-id");if(!n){s.removeAttribute(ft),s.removeAttribute("custom-slidev-layout"),s.removeAttribute(qt),s.removeAttribute("custom-slidev-role");return}const r=t.get(n),l=(r==null?void 0:r[ft])||(r==null?void 0:r["custom-slidev-layout"])||"",o=s.getAttribute(ft)||s.getAttribute("custom-slidev-layout");o&&o!==l&&(l?s.setAttribute(ft,l):(s.removeAttribute(ft),s.removeAttribute("custom-slidev-layout")));const a=(r==null?void 0:r[qt])||(r==null?void 0:r["custom-slidev-role"])||"",c=s.getAttribute(qt)||s.getAttribute("custom-slidev-role");c&&c!==a&&(a?s.setAttribute(qt,a):(s.removeAttribute(qt),s.removeAttribute("custom-slidev-role")))})}const Bf={class:"spm-layout-picker"},Df={class:"spm-layout-picker__grid"},Of=["title","onClick"],Pf={class:"spm-layout-icon"},Lf={class:"spm-layout-label"},Rf=be({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,s=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"two-cols-header",label:"表头双栏",desc:"顶部通栏标题，下方左右双栏"},{name:"three-cols-header",label:"表头三栏",desc:"顶部通栏标题，下方等宽三栏"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function n(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(et(),nt("div",Bf,[l[0]||(l[0]=m("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),m("div",Df,[(et(),nt(Gt,null,ye(s,o=>m("div",{key:o.name,class:Et(["spm-layout-item",{active:t.modelValue===o.name}]),title:o.desc,onClick:a=>n(o.name)},[m("div",Pf,[ht(kt,{name:"layout-"+o.name},null,8,["name"])]),m("span",Lf,St(o.label),1)],10,Of)),64))])]))}}),Vl=Le(Rf,[["__scopeId","data-v-c57441d5"]]),zf={key:0,class:"spm-transition-selector__header"},Nf={class:"spm-transition-list"},Ff=["onClick"],jf={class:"spm-transition-meta"},Hf={class:"spm-transition-label"},Uf={class:"spm-transition-name"},Wf={class:"spm-transition-preview-box"},Vf=be({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,s=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function n(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(et(),nt("div",{class:Et(["spm-transition-selector",{"spm-transition-selector--no-header":t.hideHeader}])},[t.hideHeader?Ft("",!0):(et(),nt("div",zf,St(t.title||"转场动效"),1)),m("div",Nf,[(et(),nt(Gt,null,ye(s,o=>m("div",{key:o.name,class:Et(["spm-transition-item",{active:t.modelValue===o.name}]),onClick:a=>n(o.name)},[m("div",jf,[m("span",Hf,St(o.label),1),m("span",Uf,"("+St(o.name)+")",1)]),m("div",Wf,[m("div",{class:Et(["spm-anim-cube","anim-"+o.name])},null,2)])],10,Ff)),64))])],2))}}),$o=Le(Vf,[["__scopeId","data-v-b0aa61ff"]]),Kf={class:"spm-divider-popover"},qf={class:"spm-divider-popover__title"},Gf={class:"spm-form-item"},Zf={class:"spm-popover-footer"},Yf={class:"spm-save-hint"},Jf=be({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(t,{emit:i}){var g,u,k;const e=t,s=i,n=pt(((g=e.initialAttrs)==null?void 0:g[ft])||"default"),r=pt(((u=e.initialAttrs)==null?void 0:u[Xt])||"slide-left"),l=pt(((k=e.initialAttrs)==null?void 0:k[Ut])||""),o=pt("");Ti(()=>e.initialAttrs,h=>{n.value=(h==null?void 0:h[ft])||"default",r.value=(h==null?void 0:h[Xt])||"slide-left",l.value=(h==null?void 0:h[Ut])||""},{deep:!0});async function a(h,b){if(e.blockId){o.value="正在同步...",Ht.setBlockAttrOverride(e.blockId,{[h]:b}),se(e.blockId,{[h]:b});try{await zt(e.blockId,{[h]:b}),o.value="已同步至块属性",s("updated",{[h]:b}),setTimeout(()=>{o.value=""},1500)}catch{o.value="同步失败"}}}function c(h){a(ft,h)}function d(h){a(Xt,h)}function p(){a(Ut,l.value.trim())}return(h,b)=>(et(),nt("div",Kf,[m("div",qf,[b[4]||(b[4]=m("span",null,"幻灯片页面设置",-1)),m("button",{class:"spm-close-btn",onClick:b[0]||(b[0]=v=>s("close"))},"✕")]),ht(Vl,{modelValue:n.value,"onUpdate:modelValue":b[1]||(b[1]=v=>n.value=v),onChange:c},null,8,["modelValue"]),ht($o,{modelValue:r.value,"onUpdate:modelValue":b[2]||(b[2]=v=>r.value=v),onChange:d},null,8,["modelValue"]),m("div",Gf,[b[5]||(b[5]=m("label",{class:"spm-form-label"},"页面背景",-1)),Ie(m("input",{"onUpdate:modelValue":b[3]||(b[3]=v=>l.value=v),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:p},null,544),[[is,l.value]])]),m("div",Zf,[m("span",Yf,St(o.value),1)])]))}}),Xf=Le(Jf,[["__scopeId","data-v-e4871368"]]),Qf={class:"spm-slide-inspector"},th={class:"spm-inspector-header"},eh={class:"spm-inspector-list"},ih=["onClick"],nh={class:"spm-card-top"},sh={class:"spm-card-badge"},oh={class:"spm-card-layout"},rh=["onClick"],lh={class:"spm-card-preview"},ah={key:0,class:"spm-card-notes",title:"演讲备忘录"},ch={class:"spm-inspector-modal-content"},dh=be({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(t,{emit:i}){const e=i,s=pt(null);function n(c){s.value=c}function r(c){const d={};return c.frontmatter.layout&&(d[ft]=c.frontmatter.layout),c.frontmatter.transition&&(d[Xt]=c.frontmatter.transition),c.frontmatter.background&&(d[Ut]=c.frontmatter.background),c.notes&&(d[zi]=c.notes),d}function l(c){s.value&&(c[ft]&&(s.value.frontmatter.layout=c[ft]),c[Xt]&&(s.value.frontmatter.transition=c[Xt]),c[Ut]&&(s.value.frontmatter.background=c[Ut]),c[zi]&&(s.value.notes=c[zi]),e("refresh"))}function o(c){e("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const d=c.blocks[0],p=d.content||d.rawMarkdown||"";return p.slice(0,40)+(p.length>40?"...":"")}return(c,d)=>(et(),nt("div",Qf,[m("div",th,[m("span",null,"幻灯片大纲 ("+St(t.slides.length)+" 页)",1)]),m("div",eh,[(et(!0),nt(Gt,null,ye(t.slides,p=>(et(),nt("div",{key:p.pageIndex,class:Et(["spm-card",{active:t.currentActivePage===p.pageIndex}]),onClick:g=>o(p.pageIndex)},[m("div",nh,[m("span",sh,"P"+St(p.pageIndex),1),m("span",oh,St(p.frontmatter.layout||"default"),1),m("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Te(g=>n(p),["stop"])},[ht(kt,{name:"settings"})],8,rh)]),m("div",lh,St(a(p)),1),p.notes?(et(),nt("div",ah,[ht(kt,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),m("span",null,St(p.notes),1)])):Ft("",!0)],10,ih))),128))]),s.value?(et(),nt("div",{key:0,class:"spm-inspector-modal-mask",onClick:d[1]||(d[1]=Te(p=>s.value=null,["self"]))},[m("div",ch,[ht(Xf,{"block-id":s.value.startBlockId,"initial-attrs":r(s.value),onClose:d[0]||(d[0]=p=>s.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Ft("",!0)]))}}),uh=Le(dh,[["__scopeId","data-v-68b25edd"]]),fh={class:"spm-immersion-header"},hh={class:"spm-immersion-header__left"},ph={class:"spm-immersion-title"},mh={class:"spm-immersion-header__center"},gh={class:"spm-immersion-header__actions"},vh=["aria-label"],bh={class:"spm-immersion-body"},yh=be({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(t,{emit:i}){const e=t,s=i;function n(){s("update:visible",!1),s("close")}function r(){e.closeOnClickMask&&n()}function l(){s("update:isMaximized",!e.isMaximized),s("toggle-maximize")}function o(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),n())}return(a,c)=>Ie((et(),nt("div",{class:Et(["spm-immersion-container",{"is-maximized":t.isMaximized}]),onKeydown:Te(o,["stop"])},[m("div",{class:"spm-immersion-mask",onClick:r}),m("div",{class:Et(["spm-immersion-drawer",{"is-maximized":t.isMaximized}])},[m("div",fh,[m("div",hh,[Ln(a.$slots,"header-left",{},()=>[m("span",ph,St(t.title),1)])]),m("div",mh,[Ln(a.$slots,"header-center",{},void 0)]),m("div",gh,[Ln(a.$slots,"header-actions",{},void 0),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":t.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[ht(kt,{name:t.isMaximized?"minimize":"maximize"},null,8,["name"])],8,vh),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:n},[ht(kt,{name:"close"})])])]),m("div",bh,[Ln(a.$slots,"default",{},void 0)])],2)],34)),[[Nl,t.visible]])}}),kh=Le(yh,[["__scopeId","data-v-3f1665db"]]),wh="slidev-config.json",Yi={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806"},$i=ds({...Yi});function xh(t){if(!t||typeof t!="object")return{...Yi};const i=t;return{enableWebServeJump:!!i.enableWebServeJump,webServeUrl:typeof i.webServeUrl=="string"&&i.webServeUrl.trim()?i.webServeUrl.trim():Yi.webServeUrl}}function Vi(t){if(!t||typeof t!="object")return{...$i};const i=t;return i.enableWebServeJump!==void 0&&($i.enableWebServeJump=!!i.enableWebServeJump),i.webServeUrl!==void 0&&($i.webServeUrl=String(i.webServeUrl)),{...$i}}function Io(){return{...$i}}function Kl(t,i,e){const s=(t||Yi.webServeUrl).trim(),n=s.startsWith("http://")||s.startsWith("https://")?s:`http://${s}`,r=(e==null?void 0:e.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(n);let o=l.pathname.replace(/\/+$/,"");return o.endsWith("/stage/build/desktop")||(o=o?`${o}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${o}/`,l.searchParams.set("id",i),e!=null&&e.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",r),l.toString()}catch{const l=e!=null&&e.focus?"&focus=1":"";return`${n.replace(/\/+$/,"")}/stage/build/desktop/?id=${i}${l}&r=${r}`}}const _h={class:"spm-protyle-drawer"},Sh={class:"spm-protyle-drawer__subbar"},Ch={class:"spm-protyle-drawer__nav"},$h=["title"],Ih={class:"spm-protyle-drawer__actions"},Ah=["aria-label"],Th=["aria-label"],Eh=be({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(t,{emit:i}){const e=i,s=t,n=pt(s.blockId),r=pt(s.title||""),l=pt(!1),o=pt(!0),a=pt(!1),c=pt(""),d=$i,p=pt([]),g=pt(null);let u=null;Ti(()=>s.blockId,A=>{A&&A!==n.value&&(n.value=A,r.value=s.title||"",p.value=[],h(A))}),$n(()=>{n.value&&h(n.value)}),vo(()=>{b()});async function k(A){try{const M=await gn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${A}' LIMIT 1`);if(Array.isArray(M)&&M.length>0){const P=M[0];c.value=P.root_id||"";const N=P.id===P.root_id||P.type==="d";a.value=N,o.value=!N,!r.value&&P.content&&(r.value=P.content.trim().slice(0,30));return}}catch(M){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",M)}a.value=!1,o.value=!0}async function h(A,M){if(!g.value||!A)return;b(),await k(A),typeof M=="boolean"&&(o.value=!a.value&&M);let P,N;o.value&&!a.value?(P=["cb-get-all","cb-get-hl","cb-get-focus"],N={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(P=["cb-get-context","cb-get-hl"],N={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{u=new vt.Protyle(s.plugin.app,g.value,{blockId:A,action:P,render:N}),!l.value&&u&&typeof u.disable=="function"&&u.disable()}catch(X){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",X)}}function b(){if(u){try{typeof u.destroy=="function"&&u.destroy()}catch(A){console.warn("[ProtylePeekDrawer] Error destroying protyle:",A)}u=null}g.value&&(g.value.innerHTML="")}function v(){a.value||(o.value=!o.value,h(n.value,o.value))}function w(){l.value=!l.value,u&&(l.value?(typeof u.enable=="function"&&u.enable(),typeof u.focus=="function"&&u.focus()):typeof u.disable=="function"&&u.disable())}function $(){if(n.value)try{vt.openWindow({doc:{id:n.value},alwaysOnTop:!0})}catch(A){console.warn("[ProtylePeekDrawer] openWindow failed:",A)}}function I(){var P;if(!n.value)return;const A=Io(),M=Kl(A.webServeUrl,n.value,{focus:!a.value});if(typeof window<"u"){const N=we("electron");(P=N==null?void 0:N.shell)!=null&&P.openExternal?N.shell.openExternal(M).catch(()=>{window.open(M,"_blank")}):window.open(M,"_blank")}e("external-jump",M)}function x(){if(p.value.length>0){const A=p.value.pop();A&&(n.value=A.blockId,r.value=A.title,o.value=A.isFocusMode,a.value=A.isDoc,h(A.blockId,A.isFocusMode))}}function C(A){const M=A.target;if(!M)return;const P=M.closest('[data-type="block-ref"]');if(P){const X=P.getAttribute("data-id");if(X&&X!==n.value){A.preventDefault(),A.stopPropagation(),p.value.push({blockId:n.value,title:r.value||n.value,isFocusMode:o.value,isDoc:a.value}),n.value=X,r.value=P.innerText.trim()||X,h(X);return}}const N=M.closest("a");if(N&&N.href&&N.href.startsWith("siyuan://blocks/")){A.preventDefault(),A.stopPropagation();const X=N.href.replace("siyuan://blocks/","").split("?")[0];X&&X!==n.value&&(p.value.push({blockId:n.value,title:r.value||n.value,isFocusMode:o.value,isDoc:a.value}),n.value=X,r.value=N.innerText.trim()||X,h(X))}}return(A,M)=>(et(),nt("div",_h,[m("div",Sh,[m("div",Ch,[p.value.length>0?(et(),nt("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:x},[ht(kt,{name:"arrow-left"}),M[0]||(M[0]=m("span",null,"返回",-1))])):Ft("",!0),m("span",{class:Et(["spm-protyle-badge",{"is-focus":o.value&&!a.value}])},St(o.value&&!a.value?"思源块聚焦":"思源文档速览"),3),m("span",{class:"spm-protyle-id",title:r.value||n.value},St(r.value||n.value),9,$h)]),m("div",Ih,[a.value?Ft("",!0):(et(),nt("button",{key:0,class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":o.value}]),"aria-label":o.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:v},[ht(kt,{name:o.value?"focus":"file-text"},null,8,["name"]),m("span",null,St(o.value?"块聚焦":"展开全文"),1)],10,Ah)),m("button",{class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:w},[ht(kt,{name:l.value?"edit":"eye"},null,8,["name"]),m("span",null,St(l.value?"编辑中":"只读"),1)],10,Th),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:$},[ht(kt,{name:"window"}),M[1]||(M[1]=m("span",null,"独立窗口",-1))]),Ci(d).enableWebServeJump?(et(),nt("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:I},[ht(kt,{name:"external-link"}),M[2]||(M[2]=m("span",null,"外跳",-1))])):Ft("",!0)])]),m("div",{ref_key:"mountEl",ref:g,class:Et(["spm-protyle-mount",{"is-focus-mode":o.value&&!a.value}]),onClick:C},null,2)]))}}),Mh=Le(Eh,[["__scopeId","data-v-7e586ef3"]]),Bh={class:"spm-webview-drawer"},Dh={class:"spm-webview-toolbar"},Oh={class:"spm-webview-toolbar__nav"},Ph=["disabled"],Lh=["disabled"],Rh=["aria-label"],zh={class:"spm-webview-toolbar__address"},Nh=["aria-label"],Fh={class:"spm-webview-toolbar__actions"},jh=["aria-label"],Hh={class:"spm-zoom-controller"},Uh=["disabled"],Wh=["disabled"],Vh={key:1,class:"spm-webview-fallback"},Kh=["src"],br="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",ql="siyuan-slidev-peek-view-mode";let Gl="desktop";function qh(){if(typeof window<"u"&&window.localStorage)try{const t=window.localStorage.getItem(ql);if(t==="mobile"||t==="desktop")return t}catch{}return Gl}function Gh(t){if(Gl=t,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(ql,t)}catch{}}const Zh=be({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(t,{emit:i}){const e=i,s=t,n=pt(Hl()),r=pt(s.url),l=pt(s.url),o=pt(!1),a=pt(!1),c=pt(!1),d=pt(1),p=pt(!1),g=pt(qh());let u=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const k=$t(()=>g.value==="mobile"?br:u||void 0),h=pt(null),b=pt(null);let v=null,w=null,$=null;Ti(()=>s.url,J=>{J&&J!==r.value&&(r.value=J,l.value=J,g.value==="mobile"&&M(!1),h.value&&typeof h.value.loadURL=="function"&&h.value.loadURL(J))}),Ti(()=>s.visible,J=>{if(J)V(),g.value==="mobile"&&M(!1);else if(h.value)try{typeof h.value.stop=="function"&&h.value.stop()}catch{}}),$n(()=>{I(),b.value&&typeof ResizeObserver<"u"&&(v=new ResizeObserver(()=>{const J=h.value;if(J&&typeof J.invalidate=="function")try{J.invalidate()}catch{}}),v.observe(b.value)),w=J=>{var mt;const gt=J.message||((mt=J.error)==null?void 0:mt.message);if(typeof gt=="string"&&gt.includes("Invalid guestInstanceId"))return J.preventDefault(),J.stopImmediatePropagation(),!0},window.addEventListener("error",w,!0),$=J=>{const gt=J.reason,mt=typeof gt=="string"?gt:gt==null?void 0:gt.message;typeof mt=="string"&&mt.includes("Invalid guestInstanceId")&&J.preventDefault()},window.addEventListener("unhandledrejection",$)}),vo(()=>{if(x(),v&&(v.disconnect(),v=null),w&&(window.removeEventListener("error",w,!0),w=null),$&&(window.removeEventListener("unhandledrejection",$),$=null),h.value)try{typeof h.value.stop=="function"&&h.value.stop()}catch{}});function I(){const J=h.value;J&&(J.addEventListener("dom-ready",C),J.addEventListener("did-start-loading",P),J.addEventListener("did-stop-loading",N),J.addEventListener("did-navigate",X),J.addEventListener("did-navigate-in-page",T),J.addEventListener("new-window",D))}function x(){const J=h.value;if(J)try{J.removeEventListener("dom-ready",C),J.removeEventListener("did-start-loading",P),J.removeEventListener("did-stop-loading",N),J.removeEventListener("did-navigate",X),J.removeEventListener("did-navigate-in-page",T),J.removeEventListener("new-window",D)}catch{}}function C(){const J=h.value;if(J&&typeof J.getUserAgent=="function"&&!u)try{const gt=J.getUserAgent();gt&&!gt.includes("iPhone")&&(u=gt)}catch{}g.value==="mobile"&&M(!1),V(),y()}function A(){const J=g.value==="mobile"?"desktop":"mobile";g.value=J,Gh(J),M(!0)}function M(J=!1){const gt=h.value;if(!gt)return;const mt=g.value==="mobile"?br:u;if(typeof gt.setUserAgent=="function"&&mt)try{gt.setUserAgent(mt)}catch(Z){console.warn("[WebviewPeekDrawer] setUserAgent error:",Z)}if(J&&typeof gt.reload=="function")try{gt.reload()}catch(Z){console.warn("[WebviewPeekDrawer] reload error:",Z)}}function P(){o.value=!0}function N(){if(o.value=!1,y(),h.value&&typeof h.value.getURL=="function"){const J=h.value.getURL();J&&J!=="about:blank"&&(r.value=J,l.value=J)}}function X(J){J!=null&&J.url&&(r.value=J.url,l.value=J.url),y()}function T(J){J!=null&&J.url&&(r.value=J.url,l.value=J.url),y()}function D(J){J&&J.url&&(J.preventDefault(),h.value&&typeof h.value.loadURL=="function"&&h.value.loadURL(J.url))}function y(){const J=h.value;J&&(typeof J.canGoBack=="function"&&(a.value=J.canGoBack()),typeof J.canGoForward=="function"&&(c.value=J.canGoForward()))}function R(){h.value&&typeof h.value.goBack=="function"&&h.value.goBack()}function Q(){h.value&&typeof h.value.goForward=="function"&&h.value.goForward()}function U(){h.value&&typeof h.value.reload=="function"&&h.value.reload()}function at(){let J=l.value.trim();J&&(/^https?:\/\//i.test(J)||(J=`https://${J}`),r.value=J,l.value=J,h.value&&typeof h.value.loadURL=="function"&&h.value.loadURL(J))}function V(){const J=h.value;if(J&&typeof J.setZoomFactor=="function")try{J.setZoomFactor(d.value)}catch(gt){console.warn("[WebviewPeekDrawer] setZoomFactor error:",gt)}}function Y(){d.value=Math.min(2.5,Math.round((d.value+.1)*10)/10),V()}function W(){d.value=Math.max(.5,Math.round((d.value-.1)*10)/10),V()}function z(){d.value=1,V()}function ct(J){J.preventDefault(),J.deltaY<0?Y():J.deltaY>0&&W()}async function rt(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(r.value),p.value=!0,setTimeout(()=>{p.value=!1},2e3)}catch(J){console.warn("Copy url failed:",J)}}function st(){var gt;const J=r.value;if(typeof window<"u"){const mt=we("electron");(gt=mt==null?void 0:mt.shell)!=null&&gt.openExternal?mt.shell.openExternal(J).catch(()=>{window.open(J,"_blank")}):window.open(J,"_blank")}e("external-jump",J)}return(J,gt)=>{const mt=Qc("webview");return et(),nt("div",Bh,[m("div",Dh,[m("div",Oh,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!a.value,"aria-label":"后退",onClick:R},[ht(kt,{name:"arrow-left"})],8,Ph),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"前进",onClick:Q},[ht(kt,{name:"arrow-right"})],8,Lh),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":o.value?"正在加载...":"刷新页面",onClick:U},[ht(kt,{name:"refresh"})],8,Rh)]),m("div",zh,[Ie(m("input",{"onUpdate:modelValue":gt[0]||(gt[0]=Z=>l.value=Z),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:pu(at,["enter"])},null,544),[[is,l.value]]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":p.value?"已复制地址！":"复制网址",onClick:rt},[ht(kt,{name:"copy"})],8,Nh)]),m("div",Fh,[m("button",{class:Et(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":g.value==="mobile"}]),"aria-label":g.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:A},[ht(kt,{name:g.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,jh),m("div",Hh,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:d.value<=.5,onClick:W},[ht(kt,{name:"minus"})],8,Uh),m("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:z},St(Math.round(d.value*100))+"% ",1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:d.value>=2.5,onClick:Y},[ht(kt,{name:"plus"})],8,Wh)]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:st},[ht(kt,{name:"external-link"}),gt[1]||(gt[1]=m("span",null,"外跳",-1))])])]),m("div",{ref_key:"containerEl",ref:b,class:Et(["spm-webview-body",{"is-mobile":g.value==="mobile"}]),onWheel:Te(ct,["ctrl"])},[m("div",{class:Et(["spm-webview-viewport",{"is-mobile":g.value==="mobile"}])},[n.value?(et(),Ee(mt,{key:0,ref_key:"webviewRef",ref:h,class:"spm-webview-frame",src:r.value,useragent:k.value,allowpopups:"true",partition:"persist:slidev-peek",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(et(),nt("div",Vh,[m("iframe",{class:"spm-webview-fallback-frame",src:r.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Kh),m("div",{class:"spm-fallback-bar"},[gt[2]||(gt[2]=m("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),m("button",{class:"spm-icon-btn is-primary",onClick:st}," 在新标签页中打开 ↗ ")])]))],2)],34)])}}}),Yh=Le(Zh,[["__scopeId","data-v-40e35375"]]);class Jh{constructor(){wt(this,"timers",new Map)}debounce(i,e,s=150){this.cancel(i);const n=setTimeout(()=>{this.timers.delete(i),e()},s);this.timers.set(i,n)}cancel(i){this.timers.has(i)&&(clearTimeout(this.timers.get(i)),this.timers.delete(i))}cancelAll(){for(const i of this.timers.values())clearTimeout(i);this.timers.clear()}hasPending(i){return this.timers.has(i)}}class Xh{constructor(i){wt(this,"blockToPageMap",new Map);wt(this,"debounceCtrl",new Jh);wt(this,"activeBlockId","");wt(this,"activePageIndex",1);wt(this,"currentDocId","");wt(this,"bridge",null);i&&(this.bridge=i)}setBridge(i){this.bridge=i}setDocId(i){this.currentDocId=i}updateSlidesIndex(i){this.blockToPageMap.clear();for(const e of i){e.startBlockId&&this.blockToPageMap.set(e.startBlockId,e.pageIndex);for(const s of e.blocks)this.blockToPageMap.set(s.id,e.pageIndex)}}getPageByBlockId(i){return this.blockToPageMap.get(i)??null}onCursorFocusBlock(i){if(!i||i===this.activeBlockId)return;this.activeBlockId=i;let e=this.getPageByBlockId(i);!e&&(i===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(e=1),e&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=e,this.bridge&&(this.bridge.navigatePage(e),this.bridge.highlightElement(i))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(i){this.activeBlockId=i;const e=this.getPageByBlockId(i);e&&(this.activePageIndex=e)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Ei(t,i){var r,l;if(!t||typeof document>"u")return!1;const e=(r=globalThis.CSS)!=null&&r.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),s=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`);if(!s){if(i)try{return vt.openTab({app:i,doc:{id:t,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(o){console.warn("[SelectionMirror] openTab fallback failed:",o)}return!1}try{s.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{s.scrollIntoView()}try{(l=s.focus)==null||l.call(s,{preventScroll:!0})}catch{}s.classList.add("protyle-wysiwyg--select");const n=s.style.outline;return s.style.outline="2px solid #3b82f6",s.style.transition="outline 0.3s ease",setTimeout(()=>{s.classList.remove("protyle-wysiwyg--select"),s.style.outline=n},1200),!0}function le(t){return t?t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Qh(t){if(!t||t.trim()===""||t.trim()==="all")return"all";const i=new Set,e=t.split("|");for(const s of e){const n=s.trim();if(n==="all")return"all";if(n.includes("-")){const[r,l]=n.split("-"),o=parseInt(r,10),a=parseInt(l,10);if(!isNaN(o)&&!isNaN(a))for(let c=Math.min(o,a);c<=Math.max(o,a);c++)i.add(c)}else{const r=parseInt(n,10);isNaN(r)||i.add(r)}}return i}const tp=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function Me(t){if(!t)return"";const i=Mr(t),e=[],s=i.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(r,l)=>{const o=l.toLowerCase();if(!tp.has(o)||/on\w+\s*=|javascript:/i.test(r))return r;if(o==="v-mark"){const a=r.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return r.startsWith("</")?e.push("</mark>"):e.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${e.length-1}%%`}return e.push(r),`%%SAFE_HTML_${e.length-1}%%`});let n=le(s);return n=n.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(r,l,o,a,c,d,p)=>{const u=(o??a??c??d??p??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${u}</a>`}),n=n.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),n=n.replace(/!\[(.*?)\]\((.*?)\)/g,(r,l,o)=>{const c=/\.gif(?:\?|$)/i.test(o)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${o}" class="${c}" />`}),n=n.replace(/\[(.*?)\]\((.*?)\)/g,(r,l,o)=>{if(o.startsWith("siyuan://blocks/")){const a=o.replace("siyuan://blocks/","").split("?")[0];return`<a href="${o}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${o}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),n=n.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(r,l,o,a)=>`${l}<a href="${o}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${o}</a>`),n=n.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),n=n.replace(/\*(.*?)\*/g,"<em>$1</em>"),n=n.replace(/~~(.*?)~~/g,"<del>$1</del>"),n=n.replace(/`([^`]+)`/g,"<code>$1</code>"),n=n.replace(/%%SAFE_HTML_(\d+)%%/g,(r,l)=>{const o=parseInt(l,10);return e[o]||""}),n}function ep(t,i="pdf-table"){if(t.length<2)return"";const e=t.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),s=e[0];let n=[],r=1;t.length>=2&&e[1].every(a=>/^:?-+:?$/.test(a))&&(n=e[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),r=2);const l=`<thead><tr>${s.map((a,c)=>`<th${n[c]?` style="text-align: ${n[c]}"`:""}>${Me(a)}</th>`).join("")}</tr></thead>`,o=e.slice(r).map(a=>`<tr>${a.map((c,d)=>`<td${n[d]?` style="text-align: ${n[d]}"`:""}>${Me(c)}</td>`).join("")}</tr>`).join("");return`<table class="${i}">${l}<tbody>${o}</tbody></table>`}function Ms(t){return String(t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function ip(t,i="ts"){if(!t)return"";if(t.trim().startsWith("//"))return`<span class="token-comment">${Ms(t)}</span>`;const e=[];function s(r,l){return e.push(`<span class="${r}">${Ms(l)}</span>`),`__TOK_${e.length-1}__`}let n=t.replace(/(['"`])(.*?)\1/g,(r,l,o)=>s("token-string",`${l}${o}${l}`));return n=n.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,r=>s("token-keyword",r)),n=n.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,r=>s("token-type",r)),n=n.replace(/\b(\d+)\b/g,r=>s("token-number",r)),n=Ms(n),n=n.replace(/__TOK_(\d+)__/g,(r,l)=>e[parseInt(l,10)]||""),n}function np(t,i){if(!t)return null;const e=t.frontmatter||{};if(e.hideInToc===!0||e.hideInToc==="true")return null;let s=(e.title||"").trim(),n=e.level?parseInt(e.level,10):0;if(!s){const r=t.blocks||[];for(const l of r){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){n||(n=a[1].length),s=a[2].trim();break}}}return s?((!n||isNaN(n))&&(n=1),{pageIndex:t.pageIndex||i,title:s,level:n}):null}function sp(t,i=1,e={}){const s=e.minDepth!==void 0?Number(e.minDepth):1,n=e.maxDepth!==void 0?Number(e.maxDepth):1/0,r=[];Array.isArray(t)&&t.forEach((c,d)=>{const p=np(c,d+1);p&&r.push(p)});const l=[];let o=null;for(const c of r){const d={...c,active:c.pageIndex===i,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),o=d):o?(d.active&&(o.hasActiveChild=!0),o.children.push(d)):l.push(d)}function a(c,d=1){if(d>n)return[];const p=[];for(const g of c){const u=a(g.children,d+1);d>=s?p.push({...g,children:u}):p.push(...u)}return p}return a(l,1)}function op(t,i=1,e={}){const s=sp(t,i,e),n=e.columns?Number(e.columns):1,r=n>1?` style="column-count: ${n};"`:"",l=e.textSm?" text-sm":"";function o(c,d=1){if(!c||c.length===0)return"";const p=`slidev-toc-list slidev-toc-list-level-${d}`,g=c.map(u=>{const k=u.active?" slidev-toc-item-active":u.hasActiveChild?" slidev-toc-item-parent-active":"",h=u.children&&u.children.length>0?o(u.children,d+1):"";let b=Me(u.title);return b.includes("LaTeX")&&(b=b.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${k}" data-page="${u.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${b}</span>
          </a>
          ${h}
        </li>
      `}).join("");return`<ol class="${p}">${g}</ol>`}const a=o(s,1);return`<div class="slidev-toc${l}"${r}>${a}</div>`}function rp(t,i,e){var u,k,h,b;const s=t.split(`
`);if(!s.some(v=>/^(\s*)([-*+]|\d+\.)\s+/.test(v)))return null;const r=[],l=[];let o=!1;for(let v=0;v<s.length;v++){const w=s[v];if(!w.trim())continue;const $=w.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if($){l.push({type:"task",checked:$[2].toLowerCase()==="x",text:$[3],media:[]});continue}const I=w.match(/^(\s*)[-*+]\s+(.*)$/);if(I){l.push({type:"unordered",text:I[2],media:[]});continue}const x=w.match(/^(\s*)\d+\.\s+(.*)$/);if(x){l.length===0&&(o=!0),l.push({type:"ordered",text:x[2],media:[]});continue}const C=w.trim();if(l.length>0){const A=C.match(/^!\[(.*?)\]\((.*?)\)$/);if(A){const N=/\.gif(?:\?|$)/i.test(A[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${le(A[1])}" src="${A[2]}" class="${N}" /></div>`);continue}if(C.match(/^<img\b[\s\S]*?\/?>$/i)){l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${C}</div>`);continue}if(/<video\b/i.test(C)){let P=C;if(!/<\/video>/i.test(P))for(;v+1<s.length&&!/<\/video>/i.test(P);)v++,P+=" "+s[v].trim();const N=((u=e==null?void 0:e.attributes)==null?void 0:u["custom-slidev-autoplay"])==="true"||/autoplay/i.test(P),X=((k=e==null?void 0:e.attributes)==null?void 0:k["custom-slidev-loop"])==="true"||/loop/i.test(P),T=((h=e==null?void 0:e.attributes)==null?void 0:h["custom-slidev-muted"])==="true"||N||/muted/i.test(P),D=((b=e==null?void 0:e.attributes)==null?void 0:b["custom-slidev-controls"])==="false",y=P.match(/\bsrc=["']([^"']+)["']/i),R=y?y[1]:"",Q=['class="slide-video-player"'];D||Q.push("controls"),N&&(Q.push("autoplay"),Q.push("playsinline")),X&&Q.push("loop"),T&&Q.push("muted"),Q.push('preload="metadata"'),R&&Q.push(`src="${R}"`);const U=P.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let at=U?U[1].trim():"";!at&&R&&(at=`<source src="${R}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${N?"true":"false"}" data-muted="${T?"true":"false"}"><video ${Q.join(" ")}>${at}</video></div>`);continue}l[l.length-1].text+=`
`+C}else r.push(C)}if(l.length===0)return null;function a(v){if(!v)return"";const w=v.split(`
`).map(A=>A.trim()).filter(Boolean);if(w.length===0)return"";if(!w.some(A=>/^#{1,6}\s+/.test(A)))return Me(w.join(" "));const I=[];let x=[];const C=()=>{if(x.length>0){const A=x.join(" ");I.push(`<p class="slide-list-item-desc">${Me(A)}</p>`),x=[]}};for(const A of w){const M=A.match(/^(#{1,6})\s+(.*)$/);if(M){C();const P=M[1].length,N=M[2].trim();I.push(`<h${P} class="slide-list-item-title">${Me(N)}</h${P}>`)}else x.push(A)}return C(),I.join(`
`)}const c=o?"ol":"ul",d=o?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered",p=l.map(v=>{const w=a(v.text),$=v.media&&v.media.length>0?`
${v.media.join(`
`)}`:"";return v.type==="task"?`<li class="pdf-task-item"><label><input type="checkbox" disabled=""${v.checked?' checked=""':""}/> <span>${w}</span></label>${$}</li>`:`<li>${w}${$}</li>`}).join(`
`);return`${r.length>0?`<p>${Me(r.join(" "))}</p>
`:""}<${c} class="${d}">
${p}
</${c}>`}function xe(t,i){var h,b,v,w,$,I,x,C,A;let e="",s="",n="";const r=[];(h=t.motion)!=null&&h.preset&&t.motion.preset!=="none"&&(e=` slidev-motion-${t.motion.preset.toLowerCase()}`,typeof t.motion.duration=="number"&&t.motion.duration>0&&r.push(`--motion-duration:${t.motion.duration}ms`),typeof t.motion.delay=="number"&&t.motion.delay>0&&r.push(`--motion-delay:${t.motion.delay}ms`));const l=((b=t.attributes)==null?void 0:b.style)||"";l&&(r.push(l),n=" slide-styled-block"),r.length>0&&(s=` style="${le(r.join(";"))}"`);const a=`pdf-block${e}${n}`,c=(t.rawMarkdown||t.content||"").trim();if(!c)return`<div class="${a}"${s}></div>`;if(c.includes('class="slidev-block-ref"')||c.includes('class="slidev-ref-tag"'))return`<div class="${a}"${s}>${c}</div>`;if(c.startsWith("$$")&&c.endsWith("$$")){const M=c.slice(2,-2).trim();return`<div class="${a} katex-display-container"${s}><div class="katex-display font-math"><em>${le(M)}</em></div></div>`}const d=c.match(/^(#{1,6})\s+(.*)$/);if(d){const M=d[1].length,P=Me(d[2]);return`<div class="${a}"${s}><h${M}>${P}</h${M}></div>`}if(c.startsWith(":::")){const M=c.split(`
`),N=M[0].replace(/^:::\s*/,"").trim()||"info",X=M.slice(1,M[M.length-1].startsWith(":::")?-1:void 0).join(`
`),T="pdf-callout";return`<div class="${a}"${s}><div class="${T} ${T}--${N}"><div class="${T}-title">${N.toUpperCase()}</div><div class="${T}-body">${Me(X)}</div></div></div>`}if(c.startsWith("<<<")){const N=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((y,R)=>`<span class="code-line shiki-focus"><span class="line-no">${R+1}</span><span class="line-content">${ip(y,"ts")}</span></span>`).join(`
`),X="pdf-code shiki-container",T=((v=t.attrs)==null?void 0:v["custom-slidev-max-height"])||t.maxHeight||"",D=T?` style="max-height:${le(T)};overflow-y:auto;"`:"";return`<div class="${a}"${s}><pre class="${X}"${D}><span class="lang-badge">TS</span><code>${N}</code></pre></div>`}if(c.startsWith("<style")||c.startsWith("<!-- Inline style -->")||c.startsWith(`<!--
Notes`))return"";if(c.startsWith("```")){const M=c.split(`
`),P=M[0].slice(3).trim(),N=P.match(/^([^\s{\[]+)/),X=N?N[1]:"",T=P.match(/\[([^\]]+)\]/),D=T?T[1]:"",y=P.includes("twoslash"),R=t.shikiLines||((w=P.match(/\{([^}]+)\}/))==null?void 0:w[1])||"",Q=Qh(R),U=M.length>2?M[M.length-1]==="```"?M.slice(1,-1):M.slice(1):[c.slice(3).replace(/```$/,"")],at="pdf-code shiki-container",V=D?`${at} has-filename`:at,Y=Q!=="all",W=U.map((J,gt)=>{const mt=gt+1,ot=Q==="all"||Q.has(mt)?"code-line shiki-focus":Y?"code-line shiki-dimmed":"code-line";let dt=le(J);return y&&J.includes("doubled.value = 2")?(dt=dt.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${ot}"><span class="line-no">${mt}</span><span class="line-content">${dt}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${ot}"><span class="line-no">${mt}</span><span class="line-content">${dt}</span></span>`}).join(`
`),z=X?`<span class="lang-badge">${le(X)}</span>`:"",ct=D?`<span class="code-filename">${le(D)}</span>`:"",rt=(($=t.attrs)==null?void 0:$["custom-slidev-max-height"])||t.maxHeight||"",st=rt?` style="max-height:${le(rt)};overflow-y:auto;"`:"";return`<div class="${a}"${s}><pre class="${V}"${st}>${ct}${z}<code>${W}</code></pre></div>`}if(c.includes("|")&&c.split(`
`).filter(M=>M.trim().startsWith("|")).length>=2){const M=c.split(`
`).filter(N=>N.trim().startsWith("|")),P=ep(M,i==null?void 0:i.tableClassName);return`<div class="${a}"${s}>${P}</div>`}if(c.startsWith("> "))return`<div class="${a}"${s}><blockquote class="pdf-quote"><p>${Me(c.slice(2))}</p></blockquote></div>`;const p=/<video\b/i.test(c)||t.type==="video"||t.type==="NodeVideo",g=/^(\s*)([-*+]|\d+\.)\s+/m.test(c);if(p&&!g){const M=((I=t.attributes)==null?void 0:I["custom-slidev-autoplay"])==="true"||/autoplay/i.test(c),P=((x=t.attributes)==null?void 0:x["custom-slidev-loop"])==="true"||/loop/i.test(c),N=((C=t.attributes)==null?void 0:C["custom-slidev-muted"])==="true"||M||/muted/i.test(c),X=((A=t.attributes)==null?void 0:A["custom-slidev-controls"])==="false",T=c.match(/\bsrc=["']([^"']+)["']/i),D=T?T[1]:"",y=['class="slide-video-player"'];X||y.push("controls"),M&&(y.push("autoplay"),y.push("playsinline")),P&&y.push("loop"),N&&y.push("muted"),y.push('preload="metadata"'),D&&y.push(`src="${D}"`);const R=c.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let Q=R?R[1].trim():"";return!Q&&D&&(Q=`<source src="${D}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${a} ${a}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${M?"true":"false"}" data-muted="${N?"true":"false"}"${s}><video ${y.join(" ")}>${Q}</video></div>`}const u=c.match(/^!\[(.*?)\]\((.*?)\)$/);if(u)return`<div class="${a} ${a}--image slide-media-block slide-media-container"${s}><img alt="${le(u[1])}" src="${u[2]}" class="pdf-image slide-media-img" /></div>`;const k=rp(c,i,t);if(k)return`<div class="${a} pdf-list-item"${s}>${k}</div>`;if(/<(?:Toc|toc)\b/i.test(c)&&!c.startsWith("```")){const M=c.match(/minDepth=["']?(\d+)["']?/i),P=c.match(/maxDepth=["']?(\d+)["']?/i),N=c.match(/columns=["']?(\d+)["']?/i);return`<div class="${a}"${s}>${op([],1,{minDepth:M?parseInt(M[1],10):1,maxDepth:P?parseInt(P[1],10):1/0,columns:N?parseInt(N[1],10):1,textSm:c.includes("text-sm")})}</div>`}return`<div class="${a}"${s}><p>${Me(c)}</p></div>`}function lp(t,i){var r,l,o,a;const e=((r=t.frontmatter)==null?void 0:r.layout)||"default",n=(t.blocks||[]).filter(c=>c.slot!=="slot-divider-right");if(e==="two-cols"){const c=n.some(w=>w.slot==="right");let d=[],p=[];if(c)d=n.filter(w=>w.slot!=="right"),p=n.filter(w=>w.slot==="right");else{const w=Math.ceil(n.length/2);d=n.slice(0,w),p=n.slice(w)}const g=d.map(w=>xe(w,i)).join(`
`),u=p.map(w=>xe(w,i)).join(`
`),k="pdf-two-cols-wrapper layout-two-cols-grid",h=(l=t.frontmatter)!=null&&l.layoutClass?` ${t.frontmatter.layoutClass}`:"";return`
      <div class="${k}${h}">
        <div class="pdf-col pdf-col--left">${g}</div>
        <div class="pdf-col pdf-col--right">${u}</div>
      </div>
    `}if(e==="two-cols-header"){let c=[];const d=n.filter(w=>w.slot==="header");if(d.length>0)c=d;else if(n.length>0){const w=n.find($=>$.type==="h"&&(!$.slot||$.slot==="default"));w&&(c=[w])}const p=n.filter(w=>!c.includes(w)),g=p.filter(w=>w.slot==="right"||w.slot==="col-2"),u=p.filter(w=>!g.includes(w)),k=w=>{if(w.length===1&&Ki(w[0])){const $=Ns(w[0].rawMarkdown);return xe({...w[0],rawMarkdown:$},i)}return w.map($=>xe($,i)).join(`
`)},h=c.map(w=>xe(w,i)).join(`
`),b=k(u),v=k(g);return`
      <div class="layout-two-cols-header-container">
        <div class="layout-header-section">${h}</div>
        <div class="pdf-two-cols-wrapper layout-two-cols-grid">
          <div class="pdf-col pdf-col--left">${b}</div>
          <div class="pdf-col pdf-col--right">${v}</div>
        </div>
      </div>
    `}if(e==="three-cols-header"){let c=[];const d=n.filter(I=>I.slot==="header");if(d.length>0)c=d;else if(n.length>0){const I=n.find(x=>x.type==="h"&&(!x.slot||x.slot==="default"));I&&(c=[I])}const p=n.filter(I=>!c.includes(I)),{col1:g,col2:u,col3:k}=Dr(p),h=I=>{if(I.length===1&&Ki(I[0])){const x=Ns(I[0].rawMarkdown);return xe({...I[0],rawMarkdown:x},i)}return I.map(x=>xe(x,i)).join(`
`)},b=c.map(I=>xe(I,i)).join(`
`),v=h(g),w=h(u),$=h(k);return`
      <div class="layout-three-cols-header-container">
        <div class="layout-header-section">${b}</div>
        <div class="pdf-three-cols-wrapper layout-three-cols-grid">
          <div class="pdf-col pdf-col--1">${v}</div>
          <div class="pdf-col pdf-col--2">${w}</div>
          <div class="pdf-col pdf-col--3">${$}</div>
        </div>
      </div>
    `}if(e==="image-right"||e==="image-left"){const c=e==="image-right",d=n.map(h=>xe(h,i)).join(`
`),p=((o=t.frontmatter)==null?void 0:o.image)||((a=t.frontmatter)==null?void 0:a.background)||"",g=`<div class="pdf-image-col" style="background-image:url('${le(p)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${le(p)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,u=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${d}</div>`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:1fr 1fr;grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${c?`${u}
${g}`:`${g}
${u}`}
      </div>
    `}return e==="fact"?`<div class="layout-fact-container">${n.map(d=>xe(d,i)).join(`
`)}</div>`:e==="cover"?`<div class="layout-cover-container">${n.map(d=>xe(d,i)).join(`
`)}</div>`:n.map(c=>xe(c,i)).join(`
`)}function Zl(t,i){const e="Slidev 演示文稿";let s=t.slides;const n=JSON.stringify(s),r=JSON.stringify(t.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${le(e)}</title>
  <style>
    ${dn(i==null?void 0:i.customInlineStyles)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      gap: 32px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: 24px;
      flex-shrink: 0;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      gap: 24px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏（超级块分栏）布局：去除列表圆点标记与缩进 */
    .layout-two-cols ul,
    .layout-two-cols ol,
    .layout-two-cols-header ul,
    .layout-two-cols-header ol,
    .layout-three-cols ul,
    .layout-three-cols ol,
    .layout-three-cols-header ul,
    .layout-three-cols-header ol,
    .two-cols-left ul,
    .two-cols-left ol,
    .two-cols-right ul,
    .two-cols-right ol,
    .three-cols-col ul,
    .three-cols-col ol,
    .pdf-col ul,
    .pdf-col ol,
    .pdf-col .pdf-list,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }

    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }

    .layout-two-cols li::marker,
    .layout-two-cols-header li::marker,
    .layout-three-cols li::marker,
    .layout-three-cols-header li::marker,
    .two-cols-left li::marker,
    .two-cols-right li::marker,
    .pdf-col li::marker {
      content: none !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .pdf-col .slide-block {
      flex: 0 0 auto !important;
      min-height: auto !important;
      height: auto !important;
      max-height: none !important;
      width: 100% !important;
      display: block !important;
      overflow: visible !important;
      margin-bottom: 8px !important;
      box-sizing: border-box !important;
    }

    .pdf-col .slide-block:has(video),
    .pdf-col .slide-block:has(img),
    .pdf-col .slide-block:has(.slide-media-container),
    .pdf-col .slide-block:has(.slide-video-container),
    .pdf-col .slide-block:has(.slide-list-media),
    .pdf-col .slide-block.slide-block--media,
    .pdf-col .slide-block.slide-block--video,
    .pdf-col .slide-block.slide-block--image,
    .pdf-col .slide-block:only-child {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
    }

    .slide-list-media {
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: auto !important;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 auto;
      min-height: 0;
      height: 100%;
      max-height: 100%;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      flex: 1 1 auto;
      min-height: 0;
      height: 100%;
      max-height: 100%;
      overflow: hidden !important;
      overflow-y: hidden !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container,
    .two-cols-left img,
    .two-cols-right img,
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .layout-three-cols-grid video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: auto !important;
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(t.docId)},
      slides: ${n},
      config: ${r}
    };
  <\/script>
</head>
<body>
  <div id="app">
    <div class="slide-viewport slidev-theme-${t.config.theme||"default"}" id="viewport" data-slidev-theme="${t.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">⛶ 全屏</button>
    </div>
  </div>

  <script>
    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function renderBlock(block) {
        const div = document.createElement("div");
        div.className = "slide-block";
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        if (md.startsWith("### ")) div.innerHTML = "<h3>" + md.slice(4) + "</h3>";
        else if (md.startsWith("## ")) div.innerHTML = "<h2>" + md.slice(3) + "</h2>";
        else if (md.startsWith("# ")) div.innerHTML = "<h1>" + md.slice(2) + "</h1>";
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md)) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md)) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) { items.push({ text: um[2], media: [] }); continue; }
            if (om) { if (items.length === 0) isOrdered = true; items.push({ text: om[2], media: [] }); continue; }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                items[items.length - 1].media.push('<div class="slide-list-media">' + tr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            }
          }
          const tag = isOrdered ? "ol" : "ul";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            if (!hasHeading) {
              let h = it.text.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return "<li>" + h + med + "</li>";
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.join(" ").replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const lvl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return "<li>" + parts.join("
") + med + "</li>";
          }).join("
");
          div.innerHTML = "<" + tag + " class="pdf-list">
" + liHtml + "
</" + tag + ">";
        }
        else {
          const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
          if (imgMatch) {
            div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
            div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
          } else {
            let html = md.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
            div.innerHTML = "<p>" + html + "</p>";
          }
        }
        return div;
      }

      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default");
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          for (const block of (slide.blocks || [])) {
            const el = renderBlock(block);
            if (block.slot === "right") rightCol.appendChild(el);
            else leftCol.appendChild(el);
          }
          container.appendChild(leftCol);
        } else if (slide.frontmatter?.layout === "two-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-two-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-two-cols-wrapper layout-two-cols-grid";
          const leftCol = document.createElement("div");
          leftCol.className = "pdf-col pdf-col--left";
          const rightCol = document.createElement("div");
          rightCol.className = "pdf-col pdf-col--right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of rem) {
            if (b.slot === "right" || b.slot === "col-2") rightCol.appendChild(renderBlock(b));
            else leftCol.appendChild(renderBlock(b));
          }
          gridDiv.appendChild(leftCol);
          gridDiv.appendChild(rightCol);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "three-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-three-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-three-cols-wrapper layout-three-cols-grid";
          const col1 = document.createElement("div");
          col1.className = "pdf-col pdf-col--1";
          const col2 = document.createElement("div");
          col2.className = "pdf-col pdf-col--2";
          const col3 = document.createElement("div");
          col3.className = "pdf-col pdf-col--3";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          let c1 = [], c2 = [], c3 = [];
          const hasExplicitCols = rem.some(b => b.slot === "col-1" || b.slot === "col-2" || b.slot === "col-3" || b.slot === "center" || b.slot === "left" || b.slot === "right");
          if (hasExplicitCols) {
            c2 = rem.filter(b => b.slot === "col-2" || b.slot === "center");
            c3 = rem.filter(b => b.slot === "col-3" || b.slot === "right");
            c1 = rem.filter(b => !c2.includes(b) && !c3.includes(b));
          } else if (rem.length >= 3) {
            const count1 = Math.ceil(rem.length / 3);
            const count2 = Math.ceil((rem.length - count1) / 2);
            c1 = rem.slice(0, count1);
            c2 = rem.slice(count1, count1 + count2);
            c3 = rem.slice(count1 + count2);
          } else if (rem.length === 2) {
            c1 = [rem[0]];
            c2 = [rem[1]];
            c3 = [];
          } else if (rem.length === 1) {
            const lines = (rem[0].rawMarkdown || rem[0].content || "").trim().split(/\r?
/);
            const itemStartIndices = [];
            for (let i = 0; i < lines.length; i++) {
              if (/^[ 	]*[-*+]s+|^[ 	]*d+.s+/.test(lines[i])) itemStartIndices.push(i);
            }
            if (itemStartIndices.length >= 3) {
              const count1 = Math.ceil(itemStartIndices.length / 3);
              const count2 = Math.ceil((itemStartIndices.length - count1) / 2);
              const items1 = lines.slice(itemStartIndices[0], itemStartIndices[count1]).join("
");
              const items2 = lines.slice(itemStartIndices[count1], itemStartIndices[count1 + count2]).join("
");
              const items3 = lines.slice(itemStartIndices[count1 + count2]).join("
");
              c1 = [{ ...rem[0], rawMarkdown: items1, content: items1 }];
              c2 = [{ ...rem[0], id: rem[0].id + "-col2", rawMarkdown: items2, content: items2 }];
              c3 = [{ ...rem[0], id: rem[0].id + "-col3", rawMarkdown: items3, content: items3 }];
            } else {
              c1 = rem;
            }
          } else {
            c1 = rem;
          }
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of c1) col1.appendChild(renderBlock(b));
          for (const b of c2) col2.appendChild(renderBlock(b));
          for (const b of c3) col3.appendChild(renderBlock(b));
          gridDiv.appendChild(col1);
          gridDiv.appendChild(col2);
          gridDiv.appendChild(col3);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of (slide.blocks || [])) {
            contentCol.appendChild(renderBlock(block));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          if (isImageRight) {
            container.appendChild(contentCol);
            container.appendChild(imgCol);
          } else {
            container.appendChild(imgCol);
            container.appendChild(contentCol);
          }
        } else {
          for (const block of (slide.blocks || [])) {
            container.appendChild(renderBlock(block));
          }
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      btnPrev.addEventListener("click", () => renderSlide(currentIndex - 1));
      btnNext.addEventListener("click", () => renderSlide(currentIndex + 1));
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "ArrowRight" || e.key === " ") renderSlide(currentIndex + 1);
        if (e.key === "ArrowLeft") renderSlide(currentIndex - 1);
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      document.addEventListener("click", (e) => {
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          renderSlide(currentIndex - 1);
        } else {
          renderSlide(currentIndex + 1);
        }
      });

      renderSlide(0);
      updateScale();
    })();
  <\/script>
</body>
</html>`}function Yl(t,i){if(typeof document>"u")return!1;const e=new Blob([i],{type:"text/html;charset=utf-8"}),s=URL.createObjectURL(e),n=document.createElement("a");return n.href=s,n.download=t.endsWith(".html")?t:`${t}.html`,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(s),!0}function ap(t){switch(t){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function cp(t,i){const e="Slidev 演示讲义",s="16:9",n="light",r=ap(s),l=t.slides.map((o,a)=>{const c=o.frontmatter.layout||"default",d=lp(o),p=`${a+1} / ${t.slides.length}`;return`
      <section class="pdf-slide-page layout-${c} theme-${n}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${le(e)}</span>
          ${`<span class="pdf-page-badge">P. ${p}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${d}
        </div>
        ${o.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${le(o.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${le(e)} - 高保真讲义</title>
  <style>
    ${dn(i==null?void 0:i.customInlineStyles)}

    @page {
      ${r}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: 40px 60px;
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      align-items: center;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      gap: 36px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: 24px;
      flex-shrink: 0;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      gap: 24px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏（超级块分栏）布局：去除列表圆点标记与缩进 */
    .layout-two-cols ul,
    .layout-two-cols ol,
    .layout-two-cols-header ul,
    .layout-two-cols-header ol,
    .layout-three-cols ul,
    .layout-three-cols ol,
    .layout-three-cols-header ul,
    .layout-three-cols-header ol,
    .pdf-two-cols-wrapper ul,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ul,
    .pdf-three-cols-wrapper ol,
    .pdf-col ul,
    .pdf-col ol,
    .pdf-col .pdf-list,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    .layout-two-cols li::marker,
    .layout-two-cols-header li::marker,
    .layout-three-cols li::marker,
    .layout-three-cols-header li::marker,
    .pdf-col li::marker {
      content: none !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
    }
  </style>
</head>
<body>
  ${l}
</body>
</html>`}function Jl(t,i){var n;if(typeof window>"u"||typeof document>"u")return!1;const e=cp(t,i);try{const r=document.createElement("iframe");r.style.position="fixed",r.style.right="0",r.style.bottom="0",r.style.width="0",r.style.height="0",r.style.border="none",r.style.visibility="hidden",document.body.appendChild(r);const l=(n=r.contentWindow)==null?void 0:n.document;if(l)return l.open(),l.write(e),l.close(),setTimeout(()=>{var o,a;try{(o=r.contentWindow)==null||o.focus(),(a=r.contentWindow)==null||a.print()}finally{setTimeout(()=>{r.remove()},2e3)}},350),!0}catch(r){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",r)}const s=window.open("","_blank");return s?(s.document.write(e),s.document.close(),s.focus(),setTimeout(()=>{s.print(),s.close()},350),!0):!1}const dp={class:"spm-slidev-preview-tab"},up={class:"spm-slidev-tab__toolbar"},fp={class:"spm-slidev-tab__actions"},hp=["disabled"],pp={class:"spm-page-badge"},mp=["disabled"],gp=["aria-label"],vp=["aria-label"],bp=["src"],yp=be({__name:"SlidevPreviewTab",setup(t,{expose:i}){const e=Qe("plugin"),s=Qe("sandboxBridge",new Co),n=new Xh(s),r=new Au,l=pt("web-sandbox"),o=pt(3030),a=pt(null),c=pt(!1),d=pt(null),p=pt(1),g=pt(1),u=pt([]),k=pt(!1),h=pt(!1),b=pt(!1),v=pt("siyuan"),w=pt(""),$=pt(""),I=pt(""),x=pt(!1),C=pt(!1),A=pt(""),M=pt("/plugins/siyuan-slidev/slidev-client/index.html");let P=null,N=null,X=null,T=null,D=null,y=null,R=null;$n(()=>{d.value&&(s.attach(d.value),r.nativeBridge.attach(d.value)),P=s.onSlideChanged((Z,ot)=>{p.value=Z,g.value=ot}),N=s.onBlockClicked((Z,ot)=>{p.value=ot,n.setActiveBlockId(Z),e&&typeof e.handleBlockClickedFromSlide=="function"?e.handleBlockClickedFromSlide(Z,ot):Ei(Z,e==null?void 0:e.app)}),X=s.onOpenInEditor((Z,ot)=>{p.value=ot,n.setActiveBlockId(Z),Ei(Z,e==null?void 0:e.app)}),T=r.nativeBridge.onPageChanged((Z,ot)=>{p.value=Z,g.value=ot}),D=s.onOpenPeekDrawer(async Z=>{const ot=Io();if(Z.peekType==="siyuan"&&ot.enableWebServeJump){let dt=!1;if(R&&R.docId===Z.target)dt=!0;else if(R&&R.slides&&R.slides.some(E=>{var L;return(L=E.blocks)==null?void 0:L.some(f=>f.id===Z.target)}))dt=!1;else try{const E=await gn(`SELECT id, root_id, type FROM blocks WHERE id = '${Z.target}' LIMIT 1`);E&&E.length>0&&(dt=E[0].type==="d"||E[0].id===E[0].root_id)}catch(E){console.warn("[SlidevPreviewTab] detect block type failed:",E)}v.value="web",x.value=!0,$.value=Kl(ot.webServeUrl,Z.target,{focus:!dt}),I.value=Z.title||`${dt?"思源文档":"思源块"}: ${Z.target.slice(0,8)}`,h.value=!0,s.freezeKeyboardNav(!0)}else v.value=Z.peekType,Z.peekType==="siyuan"?(w.value=Z.target,I.value=Z.title||`块速览: ${Z.target.slice(0,8)}`):(x.value=!0,$.value=Z.target,I.value=Z.title||Z.target),h.value=!0,s.freezeKeyboardNav(!0)}),y=s.onRequestToggleFullscreen(()=>{st()}),typeof document<"u"&&document.addEventListener("fullscreenchange",rt)}),bo(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",rt),D&&D(),y&&y(),P&&P(),N&&N(),X&&X(),T&&T(),s.detach(),n.destroy(),r.destroy()});async function Q(){if(l.value==="web-sandbox"){if(!R){vt.showMessage("请先在主编辑区打开演示文档");return}vt.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const Z=await r.startProMode(R,Ps);if(!Z.success){vt.showMessage(`无法启动官方 Pro 模式：${Z.error}`);return}l.value="pro-cli",o.value=Z.port||3030,M.value=Z.url,d.value&&r.nativeBridge.attach(d.value),vt.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${o.value})`)}else r.stopProMode(),l.value="web-sandbox",M.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&s.attach(d.value),vt.showMessage("已切回内置高保真沙箱")}function U(){C.value=!C.value,C.value?A.value=(R==null?void 0:R.docId)||"":(A.value="",W())}function at(){p.value>1&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(p.value-1):s.navigatePage(p.value-1))}function V(){p.value<g.value&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(p.value+1):s.navigatePage(p.value+1))}function Y(Z){p.value=Z,l.value==="pro-cli"?r.nativeBridge.navigateToPage(Z):s.navigatePage(Z)}function W(){e&&typeof e.compileCurrentDocument=="function"?e.compileCurrentDocument():e!=null&&e.eventBus&&typeof e.eventBus.emit=="function"&&e.eventBus.emit("slidev:request-compile")}function z(){h.value=!1,s.freezeKeyboardNav(!1)}function ct(){z()}function rt(){typeof document<"u"&&(c.value=!!document.fullscreenElement,s.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function st(){const Z=a.value||d.value;Z&&(document.fullscreenElement?document.exitFullscreen().then(()=>{s.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):Z.requestFullscreen().then(()=>{s.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function J(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function gt(){if(!R){vt.showMessage("请先在主编辑区打开幻灯片文档");return}const Z=Zl(R);Yl("presentation.html",Z)&&vt.showMessage("已开始下载单文件离线 HTML 演示包")}function mt(){if(!R){vt.showMessage("请先在主编辑区打开幻灯片文档");return}Jl(R)&&vt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({updateDocument(Z,ot){C.value&&A.value&&ot&&ot!==A.value||(R=Z,C.value&&!A.value&&(A.value=Z.docId),u.value=Z.slides,g.value=Z.slides.length,n.setDocId(Z.docId),n.updateSlidesIndex(Z.slides),l.value==="pro-cli"?r.scaffolder.scaffold(Z,Ps).catch(()=>{}):s.updateSlides(Z.slides,Z.config,Z.fullMarkdown,Z.customThemeCss))},navigateToBlock(Z){n.onCursorFocusBlock(Z)},isPinned:C,pinnedDocId:A,engineMode:l,toggleEngineMode:Q}),(Z,ot)=>(et(),nt("div",dp,[m("div",up,[ot[4]||(ot[4]=m("div",{class:"spm-slidev-tab__title"},[m("svg",{class:"spm-slidev-tab__icon","aria-hidden":"true"},[m("use",{"xlink:href":"#iconSlidev"})]),m("span",null,"Slidev 演示预览")],-1)),m("div",fp,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value<=1,"aria-label":"上一页",onClick:at},[ht(kt,{name:"chevron-left"})],8,hp),m("span",pp,St(p.value)+" / "+St(g.value||1),1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value>=g.value,"aria-label":"下一页",onClick:V},[ht(kt,{name:"chevron-right"})],8,mp),m("button",{class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":C.value}]),"aria-label":C.value?"已锁定当前文档（点击解除）："+A.value:"点击锁定当前文档（不随主编辑区切换）",onClick:U},[ht(kt,{name:"pin"}),m("span",null,St(C.value?"已锁定":"跟随"),1)],10,gp),m("button",{class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+o.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:Q},[ht(kt,{name:"step"}),m("span",null,St(l.value==="pro-cli"?"Pro ("+o.value+")":"沙箱"),1)],10,vp),ot[3]||(ot[3]=m("span",{class:"spm-toolbar-divider"},null,-1)),m("button",{class:Et(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":k.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:ot[0]||(ot[0]=dt=>k.value=!k.value)},[ht(kt,{name:"outline"})],2),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:J},[ht(kt,{name:"presenter"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:gt},[ht(kt,{name:"export-html"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:mt},[ht(kt,{name:"export-pdf"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:W},[ht(kt,{name:"refresh"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:st},[ht(kt,{name:"fullscreen"})])])]),m("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container"},[m("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:M.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,bp),ht(kh,{visible:h.value,"onUpdate:visible":ot[1]||(ot[1]=dt=>h.value=dt),"is-maximized":b.value,"onUpdate:isMaximized":ot[2]||(ot[2]=dt=>b.value=dt),title:I.value,onClose:z},{default:cl(()=>[v.value==="siyuan"&&w.value?(et(),Ee(Mh,{key:0,"block-id":w.value,title:I.value,plugin:Ci(e),onExternalJump:ct},null,8,["block-id","title","plugin"])):Ft("",!0),x.value?Ie((et(),Ee(Yh,{key:1,visible:h.value&&v.value==="web",url:$.value,title:I.value,onExternalJump:ct},null,8,["visible","url","title"])),[[Nl,v.value==="web"]]):Ft("",!0)]),_:1},8,["visible","is-maximized","title"])],512),k.value&&u.value.length>0?(et(),Ee(uh,{key:0,slides:u.value,"current-active-page":p.value,onNavigate:Y,onRefresh:W},null,8,["slides","current-active-page"])):Ft("",!0)]))}}),kp=Le(yp,[["__scopeId","data-v-2622f6d8"]]),wp={class:"spm-section spm-section--page"},xp={class:"spm-section-header"},_p={class:"spm-card-control"},Sp={class:"spm-control-header"},Cp={class:"spm-control-title-group"},$p={class:"spm-control-title"},Ip={class:"spm-quick-chips"},Ap=["onClick"],Tp=["value"],Ep={key:0,class:"spm-card-control"},Mp={class:"spm-control-header"},Bp={class:"spm-control-title-group"},Dp={class:"spm-control-title"},Op={class:"spm-quick-chips"},Pp=["onClick"],Lp=["value"],Rp={class:"spm-card-control"},zp={class:"spm-control-header"},Np={class:"spm-control-title-group"},Fp={class:"spm-control-title"},jp={key:0,class:"spm-note-status-box"},Hp=["title"],Up={class:"spm-action-grid",style:{"margin-top":"6px"}},Wp={key:1,class:"spm-note-empty-box"},Vp={class:"spm-card-control"},Kp={class:"spm-action-grid"},qp=be({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageImage:{},pageNotes:{},pageIndex:{}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageImage","addNoteBlock","locateNoteBlock","generateNotes","insertDividerAfter","deleteDivider"],setup(t,{emit:i}){const e=t,s=$t(()=>{if(!e.pageNotes)return"";const l=e.pageNotes.replace(/[\r\n]+/g," ").trim();return l.length>50?l.slice(0,50)+"...":l}),n=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],r=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(l,o)=>(et(),nt("div",wp,[m("div",xp,[m("span",null,"幻灯片页面设置"+St(t.pageIndex?` (第 ${t.pageIndex} 页)`:""),1)]),ht(Vl,{"model-value":t.pageLayout,onChange:o[0]||(o[0]=a=>l.$emit("update:pageLayout",a))},null,8,["model-value"]),ht($o,{"model-value":t.pageTransition,onChange:o[1]||(o[1]=a=>l.$emit("update:pageTransition",a))},null,8,["model-value"]),m("div",_p,[m("div",Sp,[m("div",Cp,[m("div",$p,[ht(kt,{name:"palette"}),o[12]||(o[12]=m("span",null,"页面背景 (Background)",-1))]),o[13]||(o[13]=m("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),m("div",Ip,[(et(),nt(Gt,null,ye(n,a=>m("button",{key:a.value,class:Et(["spm-chip",{active:t.pageBackground===a.value}]),onClick:c=>l.$emit("update:pageBackground",a.value)},St(a.label),11,Ap)),64))]),m("input",{value:t.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:o[2]||(o[2]=a=>l.$emit("update:pageBackground",a.target.value)),onChange:o[3]||(o[3]=a=>l.$emit("update:pageBackground",a.target.value))},null,40,Tp)]),t.pageLayout==="image-right"||t.pageLayout==="image-left"||t.pageImage?(et(),nt("div",Ep,[m("div",Mp,[m("div",Bp,[m("div",Dp,[ht(kt,{name:"image"}),o[14]||(o[14]=m("span",null,"页面图片 (Image)",-1))]),o[15]||(o[15]=m("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),m("div",Op,[(et(),nt(Gt,null,ye(r,a=>m("button",{key:a.value,class:Et(["spm-chip",{active:t.pageImage===a.value}]),onClick:c=>l.$emit("update:pageImage",a.value)},St(a.label),11,Pp)),64))]),m("input",{value:t.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:o[4]||(o[4]=a=>l.$emit("update:pageImage",a.target.value)),onChange:o[5]||(o[5]=a=>l.$emit("update:pageImage",a.target.value))},null,40,Lp)])):Ft("",!0),m("div",Rp,[m("div",zp,[m("div",Np,[m("div",Fp,[ht(kt,{name:"presenter"}),o[16]||(o[16]=m("span",null,"演讲者提词 (Notes)",-1))]),o[17]||(o[17]=m("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),m("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:o[6]||(o[6]=a=>l.$emit("generateNotes"))},[ht(kt,{name:"sparkles"}),o[18]||(o[18]=m("span",null,"AI 讲稿",-1))])]),t.pageNotes?(et(),nt("div",jp,[o[21]||(o[21]=m("div",{class:"spm-note-status-badge"},[m("span",{class:"spm-badge-dot"}),m("span",null,"已配置正文讲稿")],-1)),m("div",{class:"spm-note-preview-text",title:t.pageNotes},St(s.value),9,Hp),m("div",Up,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:o[7]||(o[7]=a=>l.$emit("locateNoteBlock"))},[ht(kt,{name:"search"}),o[19]||(o[19]=m("span",null,"定位讲稿块",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:o[8]||(o[8]=a=>l.$emit("addNoteBlock"))},[ht(kt,{name:"insert-below"}),o[20]||(o[20]=m("span",null,"追加讲稿块",-1))])])])):(et(),nt("div",Wp,[o[23]||(o[23]=m("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:o[9]||(o[9]=a=>l.$emit("addNoteBlock"))},[ht(kt,{name:"insert-below"}),o[22]||(o[22]=m("span",null,"添加讲稿备注块",-1))])]))]),m("div",Vp,[o[26]||(o[26]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),m("div",Kp,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:o[10]||(o[10]=a=>l.$emit("insertDividerAfter"))},[ht(kt,{name:"insert-below"}),o[24]||(o[24]=m("span",null,"插入新页",-1))]),m("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:o[11]||(o[11]=a=>l.$emit("deleteDivider"))},[ht(kt,{name:"trash"}),o[25]||(o[25]=m("span",null,"删除此页",-1))])])])]))}}),Gp=Le(qp,[["__scopeId","data-v-4916b87e"]]),Zp={class:"spm-section spm-section--block"},Yp={class:"spm-card-control"},Jp={class:"spm-control-header"},Xp={class:"spm-control-title-group"},Qp={class:"spm-control-title"},tm=["aria-label"],em=["checked"],im={key:0,class:"spm-card-control"},nm={class:"spm-control-header"},sm={class:"spm-control-title-group"},om={class:"spm-control-title"},rm={class:"spm-quick-chips"},lm={key:1,class:"spm-card-control"},am={class:"spm-control-header"},cm={class:"spm-control-title-group"},dm={class:"spm-control-title"},um={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},fm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},hm=["aria-label"],pm=["checked"],mm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},gm=["aria-label"],vm=["checked"],bm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},ym=["aria-label"],km=["checked"],wm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},xm=["aria-label"],_m=["checked"],Sm={class:"spm-card-control"},Cm={class:"spm-control-header"},$m={class:"spm-control-title-group"},Im={class:"spm-control-title"},Am=["aria-label"],Tm=["checked"],Em={key:0,class:"spm-quick-chips"},Mm=["onClick"],Bm={class:"spm-card-control"},Dm={class:"spm-control-header"},Om={class:"spm-control-title-group"},Pm={class:"spm-control-title"},Lm=["aria-label"],Rm=["checked"],zm={key:0,class:"spm-quick-chips"},Nm=["onClick"],Fm={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},jm={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},Hm={style:{display:"flex",gap:"6px"}},Um=["value"],Wm=["value"],Vm={key:2,class:"spm-card-control"},Km={class:"spm-control-header"},qm={class:"spm-control-title-group"},Gm={class:"spm-control-title"},Zm={class:"spm-control-desc"},Ym={class:"spm-segmented-group"},Jm=["onClick"],Xm={key:3,class:"spm-card-control"},Qm={class:"spm-control-header"},tg={class:"spm-control-title-group"},eg={class:"spm-control-title"},ig={class:"spm-quick-chips"},ng=["onClick"],sg=["value"],og={key:4,class:"spm-card-control"},rg={class:"spm-control-header"},lg={class:"spm-control-title-group"},ag={class:"spm-control-title"},cg={class:"spm-quick-chips"},dg=["onClick"],ug=["value"],fg={class:"spm-card-control"},hg={class:"spm-action-grid"},pg=["aria-label"],mg=be({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(t,{emit:i}){const e=t,s=$t(()=>{const x=e.currentSlideLayout||"";return["col-1","col-2","col-3"].includes(e.elemSlot)?"three-cols-header":x}),n=$t(()=>{const x=s.value;return["two-cols","two-cols-header","three-cols-header"].includes(x)}),r=$t(()=>{const x=s.value;return x==="three-cols-header"?"三栏插槽归属 (Slot)":x==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),l=$t(()=>{const x=s.value;return x==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":x==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":x==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),o=$t(()=>{const x=s.value;return x==="three-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}]:x==="two-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]:x==="two-cols"?[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}]:[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]});function a(x){const C=e.elemSlot||"";return x?C===x||x==="col-1"&&C==="left"||x==="col-2"&&C==="center"||x==="col-3"&&C==="right"||x==="left"&&C==="col-1"||x==="right"&&(C==="col-2"||C==="col-3"):!C||C==="default"}const c=i,d=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],p=$t(()=>{if(!e.elemMotion||e.elemMotion.trim()===""||e.elemMotion.trim()==="none")return null;try{const x=JSON.parse(e.elemMotion);if(typeof x=="object"&&x!==null)return{preset:x.preset||x.type||"slide-up",duration:typeof x.duration=="number"?x.duration:0,delay:typeof x.delay=="number"?x.delay:0}}catch{}return{preset:e.elemMotion.trim(),duration:0,delay:0}}),g=$t(()=>!!p.value),u=$t(()=>{var x;return((x=p.value)==null?void 0:x.preset)||"slide-up"}),k=$t(()=>{var x;return((x=p.value)==null?void 0:x.duration)||0}),h=$t(()=>{var x;return((x=p.value)==null?void 0:x.delay)||0});function b(){g.value?c("update:elemMotion",""):c("update:elemMotion","slide-up")}function v(x){I(x,k.value,h.value)}function w(x){I(u.value,x,h.value)}function $(x){I(u.value,k.value,x)}function I(x,C,A){if(!x||x==="none"){c("update:elemMotion","");return}if(!C&&!A){c("update:elemMotion",x);return}const M={preset:x};C>0&&(M.duration=C),A>0&&(M.delay=A),c("update:elemMotion",JSON.stringify(M))}return(x,C)=>(et(),nt("div",Zp,[C[53]||(C[53]=m("div",{class:"spm-section-header"},[m("span",null,"元素动效与排版")],-1)),m("div",Yp,[m("div",Jp,[m("div",Xp,[m("div",Qp,[ht(kt,{name:"presenter"}),C[22]||(C[22]=m("span",null,"设为讲稿备注 (slidev-note)",-1))]),C[23]||(C[23]=m("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.isNote?"取消讲稿备注":"设为讲稿备注"},[m("input",{type:"checkbox",checked:!!t.isNote,onChange:C[0]||(C[0]=A=>x.$emit("toggleNote"))},null,40,em),C[24]||(C[24]=m("span",{class:"spm-switch-slider"},null,-1))],8,tm)])]),t.isImage||t.imageRole?(et(),nt("div",im,[m("div",nm,[m("div",sm,[m("div",om,[ht(kt,{name:"image"}),C[25]||(C[25]=m("span",null,"图片角色与分栏 (Image & Layout)",-1))]),C[26]||(C[26]=m("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),m("div",rm,[m("button",{class:Et(["spm-chip",{active:!t.imageRole}]),onClick:C[1]||(C[1]=A=>x.$emit("update:imageRole",""))}," 普通内容 ",2),m("button",{class:Et(["spm-chip",{active:t.imageRole==="background"}]),onClick:C[2]||(C[2]=A=>x.$emit("update:imageRole","background"))}," 🖼️ 背景图 ",2),m("button",{class:Et(["spm-chip",{active:t.imageRole==="image-left"}]),onClick:C[3]||(C[3]=A=>x.$emit("update:imageRole","image-left"))}," 🎨 图左 ",2),m("button",{class:Et(["spm-chip",{active:t.imageRole==="image-right"}]),onClick:C[4]||(C[4]=A=>x.$emit("update:imageRole","image-right"))}," 🖼️ 图右 ",2)])])):Ft("",!0),t.isVideo?(et(),nt("div",lm,[m("div",am,[m("div",cm,[m("div",dm,[ht(kt,{name:"video"}),C[27]||(C[27]=m("span",null,"视频播放设置 (Video Playback)",-1))]),C[28]||(C[28]=m("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),m("div",um,[m("div",fm,[C[30]||(C[30]=m("span",{style:{"font-size":"11px"}},"🎛️ 控制条",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoControls?"关闭控制条":"开启控制条"},[m("input",{type:"checkbox",checked:!!t.videoControls,onChange:C[5]||(C[5]=A=>x.$emit("toggleVideoControls"))},null,40,pm),C[29]||(C[29]=m("span",{class:"spm-switch-slider"},null,-1))],8,hm)]),m("div",mm,[C[32]||(C[32]=m("span",{style:{"font-size":"11px"}},"▶️ 自动播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoAutoplay?"关闭自动播放":"开启自动播放"},[m("input",{type:"checkbox",checked:!!t.videoAutoplay,onChange:C[6]||(C[6]=A=>x.$emit("toggleVideoAutoplay"))},null,40,vm),C[31]||(C[31]=m("span",{class:"spm-switch-slider"},null,-1))],8,gm)]),m("div",bm,[C[34]||(C[34]=m("span",{style:{"font-size":"11px"}},"🔁 循环播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoLoop?"关闭循环播放":"开启循环播放"},[m("input",{type:"checkbox",checked:!!t.videoLoop,onChange:C[7]||(C[7]=A=>x.$emit("toggleVideoLoop"))},null,40,km),C[33]||(C[33]=m("span",{class:"spm-switch-slider"},null,-1))],8,ym)]),m("div",wm,[C[36]||(C[36]=m("span",{style:{"font-size":"11px"}},"🔇 静音播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoMuted?"关闭静音":"开启静音"},[m("input",{type:"checkbox",checked:!!t.videoMuted,onChange:C[8]||(C[8]=A=>x.$emit("toggleVideoMuted"))},null,40,_m),C[35]||(C[35]=m("span",{class:"spm-switch-slider"},null,-1))],8,xm)])])])):Ft("",!0),m("div",Sm,[m("div",Cm,[m("div",$m,[m("div",Im,[ht(kt,{name:"step"}),C[37]||(C[37]=m("span",null,"逐步呈现 (v-click)",-1))]),C[38]||(C[38]=m("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[m("input",{type:"checkbox",checked:!!t.elemClick,onChange:C[9]||(C[9]=A=>x.$emit("toggleElemClick"))},null,40,Tm),C[39]||(C[39]=m("span",{class:"spm-switch-slider"},null,-1))],8,Am)]),t.elemClick?(et(),nt("div",Em,[(et(),nt(Gt,null,ye(["+1","1","2","hide"],A=>m("button",{key:A,class:Et(["spm-chip",{active:t.elemClick===A}]),onClick:M=>x.$emit("update:elemClick",A)},St(A==="+1"?"顺延 (+1)":A==="hide"?"隐藏 (hide)":"第 "+A+" 步"),11,Mm)),64))])):Ft("",!0)]),m("div",Bm,[m("div",Dm,[m("div",Om,[m("div",Pm,[ht(kt,{name:"motion"}),C[40]||(C[40]=m("span",null,"入场微动效 (v-motion)",-1))]),C[41]||(C[41]=m("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":g.value?"关闭微动效":"开启微动效 (slide-up)"},[m("input",{type:"checkbox",checked:g.value,onChange:b},null,40,Rm),C[42]||(C[42]=m("span",{class:"spm-switch-slider"},null,-1))],8,Lm)]),g.value?(et(),nt("div",zm,[(et(),nt(Gt,null,ye(d,A=>m("button",{key:A.value,class:Et(["spm-chip",{active:u.value===A.value}]),onClick:M=>v(A.value)},St(A.label),11,Nm)),64))])):Ft("",!0),g.value?(et(),nt("div",Fm,[m("div",jm,[m("span",null,"时长: "+St(k.value?k.value+"ms":"默认 (450ms)"),1),m("span",null,"延迟: "+St(h.value?h.value+"ms":"0ms"),1)]),m("div",Hm,[m("select",{class:"spm-select",style:{flex:"1"},value:k.value,onChange:C[10]||(C[10]=A=>w(Number(A.target.value)))},[...C[43]||(C[43]=[m("option",{value:0},"默认耗时",-1),m("option",{value:200},"极速 (200ms)",-1),m("option",{value:350},"较快 (350ms)",-1),m("option",{value:500},"平滑 (500ms)",-1),m("option",{value:800},"缓慢 (800ms)",-1)])],40,Um),m("select",{class:"spm-select",style:{flex:"1"},value:h.value,onChange:C[11]||(C[11]=A=>$(Number(A.target.value)))},[...C[44]||(C[44]=[m("option",{value:0},"无延迟",-1),m("option",{value:150},"延迟 150ms",-1),m("option",{value:300},"延迟 300ms",-1),m("option",{value:500},"延迟 500ms",-1)])],40,Wm)])])):Ft("",!0)]),n.value||t.elemSlot?(et(),nt("div",Vm,[m("div",Km,[m("div",qm,[m("div",Gm,[ht(kt,{name:"columns"}),m("span",null,St(r.value),1)]),m("span",Zm,St(l.value),1)])]),m("div",Ym,[(et(!0),nt(Gt,null,ye(o.value,A=>(et(),nt("button",{key:A.value,class:Et(["spm-segmented-item",{active:a(A.value)}]),onClick:M=>x.$emit("update:elemSlot",A.value)},St(A.label),11,Jm))),128))])])):Ft("",!0),t.isCodeBlock?(et(),nt("div",Xm,[m("div",Qm,[m("div",tg,[m("div",eg,[ht(kt,{name:"code"}),C[45]||(C[45]=m("span",null,"代码逐行聚光 (Shiki)",-1))]),C[46]||(C[46]=m("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),m("div",ig,[(et(),nt(Gt,null,ye(["1-3","all","1|2|3","2-5"],A=>m("button",{key:A,class:Et(["spm-chip",{active:t.elemShikiLines===A}]),onClick:M=>x.$emit("update:elemShikiLines",A)},St(A),11,ng)),64)),t.elemShikiLines?(et(),nt("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[12]||(C[12]=A=>x.$emit("update:elemShikiLines",""))}," 清空 ")):Ft("",!0)]),m("input",{value:t.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:C[13]||(C[13]=A=>x.$emit("update:elemShikiLines",A.target.value)),onChange:C[14]||(C[14]=A=>x.$emit("update:elemShikiLines",A.target.value))},null,40,sg)])):Ft("",!0),t.isCodeBlock?(et(),nt("div",og,[m("div",rg,[m("div",lg,[m("div",ag,[ht(kt,{name:"code"}),C[47]||(C[47]=m("span",null,"代码块限高 (Max Height)",-1))]),C[48]||(C[48]=m("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),m("div",cg,[(et(),nt(Gt,null,ye(["240px","320px","400px","50vh"],A=>m("button",{key:A,class:Et(["spm-chip",{active:t.elemMaxHeight===A}]),onClick:M=>x.$emit("update:elemMaxHeight",A)},St(A),11,dg)),64)),t.elemMaxHeight?(et(),nt("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[15]||(C[15]=A=>x.$emit("update:elemMaxHeight",""))}," 自适应 ")):Ft("",!0)]),m("input",{value:t.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:C[16]||(C[16]=A=>x.$emit("update:elemMaxHeight",A.target.value)),onChange:C[17]||(C[17]=A=>x.$emit("update:elemMaxHeight",A.target.value))},null,40,ug)])):Ft("",!0),m("div",fg,[C[52]||(C[52]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"快捷操作")])],-1)),m("div",hg,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:C[18]||(C[18]=A=>x.$emit("insertDividerBefore"))},[ht(kt,{name:"insert-above"}),C[49]||(C[49]=m("span",null,"上方分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:C[19]||(C[19]=A=>x.$emit("insertDividerAfter"))},[ht(kt,{name:"insert-below"}),C[50]||(C[50]=m("span",null,"下方分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":s.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:C[20]||(C[20]=A=>x.$emit("setTwoColsContrast"))},[ht(kt,{name:"columns"}),m("span",null,St(s.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,pg),t.hasBlockAttrs?(et(),nt("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:C[21]||(C[21]=A=>x.$emit("clearBlockAttrs"))},[ht(kt,{name:"broom"}),C[51]||(C[51]=m("span",null,"清除属性",-1))])):Ft("",!0)])])]))}}),gg={class:"spm-section spm-section--doc"},vg={class:"spm-card-control"},bg={class:"spm-control-header"},yg={class:"spm-control-title-group"},kg={class:"spm-control-title"},wg={class:"spm-segmented-group"},xg=["aria-label","onClick"],_g={class:"spm-card-control"},Sg={class:"spm-control-header"},Cg={class:"spm-control-title-group"},$g={class:"spm-control-title"},Ig={class:"spm-segmented-group"},Ag={class:"spm-card-control"},Tg={class:"spm-control-header"},Eg={class:"spm-control-title-group"},Mg={class:"spm-control-title"},Bg={class:"spm-card-control"},Dg={class:"spm-control-header"},Og={class:"spm-control-title-group"},Pg={class:"spm-control-title"},Lg=["aria-label"],Rg=["checked"],zg={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},Ng=["value"],Fg={class:"spm-card-control"},jg={class:"spm-action-grid"},Hg=be({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(t){const i=Qe("plugin"),e=$i,s=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function n(o){Vi({enableWebServeJump:o}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({enableWebServeJump:o})}function r(o){Vi({webServeUrl:o})}function l(o){Vi({webServeUrl:o}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({webServeUrl:o})}return(o,a)=>(et(),nt("div",gg,[a[30]||(a[30]=m("div",{class:"spm-section-header"},[m("span",null,"全局演示配置")],-1)),m("div",vg,[m("div",bg,[m("div",yg,[m("div",kg,[ht(kt,{name:"palette"}),a[14]||(a[14]=m("span",null,"幻灯片主题 (Theme)",-1))]),a[15]||(a[15]=m("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),m("div",wg,[(et(),nt(Gt,null,ye(s,c=>m("button",{key:c.value,class:Et(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:t.docTheme===c.value}]),"aria-label":c.desc,onClick:d=>o.$emit("update:docTheme",c.value)},St(c.label),11,xg)),64))])]),m("div",_g,[m("div",Sg,[m("div",Cg,[m("div",$g,[ht(kt,{name:"ratio"}),a[16]||(a[16]=m("span",null,"画幅比例 (Aspect Ratio)",-1))]),a[17]||(a[17]=m("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),m("div",Ig,[m("button",{class:Et(["spm-segmented-item",{active:t.docAspectRatio==="16/9"}]),onClick:a[0]||(a[0]=c=>o.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),m("button",{class:Et(["spm-segmented-item",{active:t.docAspectRatio==="4/3"}]),onClick:a[1]||(a[1]=c=>o.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),m("button",{class:Et(["spm-segmented-item",{active:t.docAspectRatio==="16/10"}]),onClick:a[2]||(a[2]=c=>o.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),m("div",Ag,[m("div",Tg,[m("div",Eg,[m("div",Mg,[ht(kt,{name:"transition"}),a[18]||(a[18]=m("span",null,"全局默认转场",-1))]),a[19]||(a[19]=m("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),ht($o,{"model-value":t.docDefaultTransition,"hide-header":!0,onChange:a[3]||(a[3]=c=>o.$emit("update:docDefaultTransition",c))},null,8,["model-value"])]),m("div",Bg,[m("div",Dg,[m("div",Og,[m("div",Pg,[ht(kt,{name:"external-link"}),a[20]||(a[20]=m("span",null,"本地网络伺服预览 (Web Serve)",-1))]),a[21]||(a[21]=m("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":Ci(e).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[m("input",{type:"checkbox",checked:Ci(e).enableWebServeJump,onChange:a[4]||(a[4]=c=>n(c.target.checked))},null,40,Rg),a[22]||(a[22]=m("span",{class:"spm-switch-slider"},null,-1))],8,Lg)]),Ci(e).enableWebServeJump?(et(),nt("div",zg,[m("input",{value:Ci(e).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:a[5]||(a[5]=Te(()=>{},["stop"])),onKeyup:a[6]||(a[6]=Te(()=>{},["stop"])),onInput:a[7]||(a[7]=c=>r(c.target.value)),onChange:a[8]||(a[8]=c=>l(c.target.value))},null,40,Ng),a[23]||(a[23]=m("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Ft("",!0)]),m("div",Fg,[a[29]||(a[29]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"演示全局操作")])],-1)),m("div",jg,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:a[9]||(a[9]=c=>o.$emit("openBottomPreview"))},[ht(kt,{name:"split-preview"}),a[24]||(a[24]=m("span",null,"分屏预览",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:a[10]||(a[10]=c=>o.$emit("openPresenter"))},[ht(kt,{name:"presenter"}),a[25]||(a[25]=m("span",null,"演讲者视图",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:a[11]||(a[11]=c=>o.$emit("aiAutoSplit"))},[ht(kt,{name:"sparkles"}),a[26]||(a[26]=m("span",null,"AI 智能分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:a[12]||(a[12]=c=>o.$emit("exportHtml"))},[ht(kt,{name:"export-html"}),a[27]||(a[27]=m("span",null,"导出 HTML",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:a[13]||(a[13]=c=>o.$emit("exportPdf"))},[ht(kt,{name:"export-pdf"}),a[28]||(a[28]=m("span",null,"导出 PDF",-1))])])])]))}});var zn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function Ug(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}function Nn(t){throw new Error('Could not dynamically require "'+t+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Bs={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var yr;function Wg(){return yr||(yr=1,(function(t,i){(function(e){t.exports=e()})(function(){return(function e(s,n,r){function l(c,d){if(!n[c]){if(!s[c]){var p=typeof Nn=="function"&&Nn;if(!d&&p)return p(c,!0);if(o)return o(c,!0);var g=new Error("Cannot find module '"+c+"'");throw g.code="MODULE_NOT_FOUND",g}var u=n[c]={exports:{}};s[c][0].call(u.exports,function(k){var h=s[c][1][k];return l(h||k)},u,u.exports,e,s,n,r)}return n[c].exports}for(var o=typeof Nn=="function"&&Nn,a=0;a<r.length;a++)l(r[a]);return l})({1:[function(e,s,n){var r=e("./utils"),l=e("./support"),o="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";n.encode=function(a){for(var c,d,p,g,u,k,h,b=[],v=0,w=a.length,$=w,I=r.getTypeOf(a)!=="string";v<a.length;)$=w-v,p=I?(c=a[v++],d=v<w?a[v++]:0,v<w?a[v++]:0):(c=a.charCodeAt(v++),d=v<w?a.charCodeAt(v++):0,v<w?a.charCodeAt(v++):0),g=c>>2,u=(3&c)<<4|d>>4,k=1<$?(15&d)<<2|p>>6:64,h=2<$?63&p:64,b.push(o.charAt(g)+o.charAt(u)+o.charAt(k)+o.charAt(h));return b.join("")},n.decode=function(a){var c,d,p,g,u,k,h=0,b=0,v="data:";if(a.substr(0,v.length)===v)throw new Error("Invalid base64 input, it looks like a data url.");var w,$=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===o.charAt(64)&&$--,a.charAt(a.length-2)===o.charAt(64)&&$--,$%1!=0)throw new Error("Invalid base64 input, bad content length.");for(w=l.uint8array?new Uint8Array(0|$):new Array(0|$);h<a.length;)c=o.indexOf(a.charAt(h++))<<2|(g=o.indexOf(a.charAt(h++)))>>4,d=(15&g)<<4|(u=o.indexOf(a.charAt(h++)))>>2,p=(3&u)<<6|(k=o.indexOf(a.charAt(h++))),w[b++]=c,u!==64&&(w[b++]=d),k!==64&&(w[b++]=p);return w}},{"./support":30,"./utils":32}],2:[function(e,s,n){var r=e("./external"),l=e("./stream/DataWorker"),o=e("./stream/Crc32Probe"),a=e("./stream/DataLengthProbe");function c(d,p,g,u,k){this.compressedSize=d,this.uncompressedSize=p,this.crc32=g,this.compression=u,this.compressedContent=k}c.prototype={getContentWorker:function(){var d=new l(r.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),p=this;return d.on("end",function(){if(this.streamInfo.data_length!==p.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(r.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,p,g){return d.pipe(new o).pipe(new a("uncompressedSize")).pipe(p.compressWorker(g)).pipe(new a("compressedSize")).withStreamInfo("compression",p)},s.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(e,s,n){var r=e("./stream/GenericWorker");n.STORE={magic:"\0\0",compressWorker:function(){return new r("STORE compression")},uncompressWorker:function(){return new r("STORE decompression")}},n.DEFLATE=e("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(e,s,n){var r=e("./utils"),l=(function(){for(var o,a=[],c=0;c<256;c++){o=c;for(var d=0;d<8;d++)o=1&o?3988292384^o>>>1:o>>>1;a[c]=o}return a})();s.exports=function(o,a){return o!==void 0&&o.length?r.getTypeOf(o)!=="string"?(function(c,d,p,g){var u=l,k=g+p;c^=-1;for(var h=g;h<k;h++)c=c>>>8^u[255&(c^d[h])];return-1^c})(0|a,o,o.length,0):(function(c,d,p,g){var u=l,k=g+p;c^=-1;for(var h=g;h<k;h++)c=c>>>8^u[255&(c^d.charCodeAt(h))];return-1^c})(0|a,o,o.length,0):0}},{"./utils":32}],5:[function(e,s,n){n.base64=!1,n.binary=!1,n.dir=!1,n.createFolders=!0,n.date=null,n.compression=null,n.compressionOptions=null,n.comment=null,n.unixPermissions=null,n.dosPermissions=null},{}],6:[function(e,s,n){var r=null;r=typeof Promise<"u"?Promise:e("lie"),s.exports={Promise:r}},{lie:37}],7:[function(e,s,n){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=e("pako"),o=e("./utils"),a=e("./stream/GenericWorker"),c=r?"uint8array":"array";function d(p,g){a.call(this,"FlateWorker/"+p),this._pako=null,this._pakoAction=p,this._pakoOptions=g,this.meta={}}n.magic="\b\0",o.inherits(d,a),d.prototype.processChunk=function(p){this.meta=p.meta,this._pako===null&&this._createPako(),this._pako.push(o.transformTo(c,p.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var p=this;this._pako.onData=function(g){p.push({data:g,meta:p.meta})}},n.compressWorker=function(p){return new d("Deflate",p)},n.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(e,s,n){function r(u,k){var h,b="";for(h=0;h<k;h++)b+=String.fromCharCode(255&u),u>>>=8;return b}function l(u,k,h,b,v,w){var $,I,x=u.file,C=u.compression,A=w!==c.utf8encode,M=o.transformTo("string",w(x.name)),P=o.transformTo("string",c.utf8encode(x.name)),N=x.comment,X=o.transformTo("string",w(N)),T=o.transformTo("string",c.utf8encode(N)),D=P.length!==x.name.length,y=T.length!==N.length,R="",Q="",U="",at=x.dir,V=x.date,Y={crc32:0,compressedSize:0,uncompressedSize:0};k&&!h||(Y.crc32=u.crc32,Y.compressedSize=u.compressedSize,Y.uncompressedSize=u.uncompressedSize);var W=0;k&&(W|=8),A||!D&&!y||(W|=2048);var z=0,ct=0;at&&(z|=16),v==="UNIX"?(ct=798,z|=(function(st,J){var gt=st;return st||(gt=J?16893:33204),(65535&gt)<<16})(x.unixPermissions,at)):(ct=20,z|=(function(st){return 63&(st||0)})(x.dosPermissions)),$=V.getUTCHours(),$<<=6,$|=V.getUTCMinutes(),$<<=5,$|=V.getUTCSeconds()/2,I=V.getUTCFullYear()-1980,I<<=4,I|=V.getUTCMonth()+1,I<<=5,I|=V.getUTCDate(),D&&(Q=r(1,1)+r(d(M),4)+P,R+="up"+r(Q.length,2)+Q),y&&(U=r(1,1)+r(d(X),4)+T,R+="uc"+r(U.length,2)+U);var rt="";return rt+=`
\0`,rt+=r(W,2),rt+=C.magic,rt+=r($,2),rt+=r(I,2),rt+=r(Y.crc32,4),rt+=r(Y.compressedSize,4),rt+=r(Y.uncompressedSize,4),rt+=r(M.length,2),rt+=r(R.length,2),{fileRecord:p.LOCAL_FILE_HEADER+rt+M+R,dirRecord:p.CENTRAL_FILE_HEADER+r(ct,2)+rt+r(X.length,2)+"\0\0\0\0"+r(z,4)+r(b,4)+M+R+X}}var o=e("../utils"),a=e("../stream/GenericWorker"),c=e("../utf8"),d=e("../crc32"),p=e("../signature");function g(u,k,h,b){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=k,this.zipPlatform=h,this.encodeFileName=b,this.streamFiles=u,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}o.inherits(g,a),g.prototype.push=function(u){var k=u.meta.percent||0,h=this.entriesCount,b=this._sources.length;this.accumulate?this.contentBuffer.push(u):(this.bytesWritten+=u.data.length,a.prototype.push.call(this,{data:u.data,meta:{currentFile:this.currentFile,percent:h?(k+100*(h-b-1))/h:100}}))},g.prototype.openedSource=function(u){this.currentSourceOffset=this.bytesWritten,this.currentFile=u.file.name;var k=this.streamFiles&&!u.file.dir;if(k){var h=l(u,k,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:h.fileRecord,meta:{percent:0}})}else this.accumulate=!0},g.prototype.closedSource=function(u){this.accumulate=!1;var k=this.streamFiles&&!u.file.dir,h=l(u,k,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(h.dirRecord),k)this.push({data:(function(b){return p.DATA_DESCRIPTOR+r(b.crc32,4)+r(b.compressedSize,4)+r(b.uncompressedSize,4)})(u),meta:{percent:100}});else for(this.push({data:h.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},g.prototype.flush=function(){for(var u=this.bytesWritten,k=0;k<this.dirRecords.length;k++)this.push({data:this.dirRecords[k],meta:{percent:100}});var h=this.bytesWritten-u,b=(function(v,w,$,I,x){var C=o.transformTo("string",x(I));return p.CENTRAL_DIRECTORY_END+"\0\0\0\0"+r(v,2)+r(v,2)+r(w,4)+r($,4)+r(C.length,2)+C})(this.dirRecords.length,h,u,this.zipComment,this.encodeFileName);this.push({data:b,meta:{percent:100}})},g.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},g.prototype.registerPrevious=function(u){this._sources.push(u);var k=this;return u.on("data",function(h){k.processChunk(h)}),u.on("end",function(){k.closedSource(k.previous.streamInfo),k._sources.length?k.prepareNextSource():k.end()}),u.on("error",function(h){k.error(h)}),this},g.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},g.prototype.error=function(u){var k=this._sources;if(!a.prototype.error.call(this,u))return!1;for(var h=0;h<k.length;h++)try{k[h].error(u)}catch{}return!0},g.prototype.lock=function(){a.prototype.lock.call(this);for(var u=this._sources,k=0;k<u.length;k++)u[k].lock()},s.exports=g},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(e,s,n){var r=e("../compressions"),l=e("./ZipFileWorker");n.generateWorker=function(o,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),p=0;try{o.forEach(function(g,u){p++;var k=(function(w,$){var I=w||$,x=r[I];if(!x)throw new Error(I+" is not a valid compression method !");return x})(u.options.compression,a.compression),h=u.options.compressionOptions||a.compressionOptions||{},b=u.dir,v=u.date;u._compressWorker(k,h).withStreamInfo("file",{name:g,dir:b,date:v,comment:u.comment||"",unixPermissions:u.unixPermissions,dosPermissions:u.dosPermissions}).pipe(d)}),d.entriesCount=p}catch(g){d.error(g)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(e,s,n){function r(){if(!(this instanceof r))return new r;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new r;for(var o in this)typeof this[o]!="function"&&(l[o]=this[o]);return l}}(r.prototype=e("./object")).loadAsync=e("./load"),r.support=e("./support"),r.defaults=e("./defaults"),r.version="3.10.1",r.loadAsync=function(l,o){return new r().loadAsync(l,o)},r.external=e("./external"),s.exports=r},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(e,s,n){var r=e("./utils"),l=e("./external"),o=e("./utf8"),a=e("./zipEntries"),c=e("./stream/Crc32Probe"),d=e("./nodejsUtils");function p(g){return new l.Promise(function(u,k){var h=g.decompressed.getContentWorker().pipe(new c);h.on("error",function(b){k(b)}).on("end",function(){h.streamInfo.crc32!==g.decompressed.crc32?k(new Error("Corrupted zip : CRC32 mismatch")):u()}).resume()})}s.exports=function(g,u){var k=this;return u=r.extend(u||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:o.utf8decode}),d.isNode&&d.isStream(g)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):r.prepareContent("the loaded zip file",g,!0,u.optimizedBinaryString,u.base64).then(function(h){var b=new a(u);return b.load(h),b}).then(function(h){var b=[l.Promise.resolve(h)],v=h.files;if(u.checkCRC32)for(var w=0;w<v.length;w++)b.push(p(v[w]));return l.Promise.all(b)}).then(function(h){for(var b=h.shift(),v=b.files,w=0;w<v.length;w++){var $=v[w],I=$.fileNameStr,x=r.resolve($.fileNameStr);k.file(x,$.decompressed,{binary:!0,optimizedBinaryString:!0,date:$.date,dir:$.dir,comment:$.fileCommentStr.length?$.fileCommentStr:null,unixPermissions:$.unixPermissions,dosPermissions:$.dosPermissions,createFolders:u.createFolders}),$.dir||(k.file(x).unsafeOriginalName=I)}return b.zipComment.length&&(k.comment=b.zipComment),k})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(e,s,n){var r=e("../utils"),l=e("../stream/GenericWorker");function o(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}r.inherits(o,l),o.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},o.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},o.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},s.exports=o},{"../stream/GenericWorker":28,"../utils":32}],13:[function(e,s,n){var r=e("readable-stream").Readable;function l(o,a,c){r.call(this,a),this._helper=o;var d=this;o.on("data",function(p,g){d.push(p)||d._helper.pause(),c&&c(g)}).on("error",function(p){d.emit("error",p)}).on("end",function(){d.push(null)})}e("../utils").inherits(l,r),l.prototype._read=function(){this._helper.resume()},s.exports=l},{"../utils":32,"readable-stream":16}],14:[function(e,s,n){s.exports={isNode:typeof Buffer<"u",newBufferFrom:function(r,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(r,l);if(typeof r=="number")throw new Error('The "data" argument must not be a number');return new Buffer(r,l)},allocBuffer:function(r){if(Buffer.alloc)return Buffer.alloc(r);var l=new Buffer(r);return l.fill(0),l},isBuffer:function(r){return Buffer.isBuffer(r)},isStream:function(r){return r&&typeof r.on=="function"&&typeof r.pause=="function"&&typeof r.resume=="function"}}},{}],15:[function(e,s,n){function r(x,C,A){var M,P=o.getTypeOf(C),N=o.extend(A||{},d);N.date=N.date||new Date,N.compression!==null&&(N.compression=N.compression.toUpperCase()),typeof N.unixPermissions=="string"&&(N.unixPermissions=parseInt(N.unixPermissions,8)),N.unixPermissions&&16384&N.unixPermissions&&(N.dir=!0),N.dosPermissions&&16&N.dosPermissions&&(N.dir=!0),N.dir&&(x=v(x)),N.createFolders&&(M=b(x))&&w.call(this,M,!0);var X=P==="string"&&N.binary===!1&&N.base64===!1;A&&A.binary!==void 0||(N.binary=!X),(C instanceof p&&C.uncompressedSize===0||N.dir||!C||C.length===0)&&(N.base64=!1,N.binary=!0,C="",N.compression="STORE",P="string");var T=null;T=C instanceof p||C instanceof a?C:k.isNode&&k.isStream(C)?new h(x,C):o.prepareContent(x,C,N.binary,N.optimizedBinaryString,N.base64);var D=new g(x,T,N);this.files[x]=D}var l=e("./utf8"),o=e("./utils"),a=e("./stream/GenericWorker"),c=e("./stream/StreamHelper"),d=e("./defaults"),p=e("./compressedObject"),g=e("./zipObject"),u=e("./generate"),k=e("./nodejsUtils"),h=e("./nodejs/NodejsStreamInputAdapter"),b=function(x){x.slice(-1)==="/"&&(x=x.substring(0,x.length-1));var C=x.lastIndexOf("/");return 0<C?x.substring(0,C):""},v=function(x){return x.slice(-1)!=="/"&&(x+="/"),x},w=function(x,C){return C=C!==void 0?C:d.createFolders,x=v(x),this.files[x]||r.call(this,x,null,{dir:!0,createFolders:C}),this.files[x]};function $(x){return Object.prototype.toString.call(x)==="[object RegExp]"}var I={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(x){var C,A,M;for(C in this.files)M=this.files[C],(A=C.slice(this.root.length,C.length))&&C.slice(0,this.root.length)===this.root&&x(A,M)},filter:function(x){var C=[];return this.forEach(function(A,M){x(A,M)&&C.push(M)}),C},file:function(x,C,A){if(arguments.length!==1)return x=this.root+x,r.call(this,x,C,A),this;if($(x)){var M=x;return this.filter(function(N,X){return!X.dir&&M.test(N)})}var P=this.files[this.root+x];return P&&!P.dir?P:null},folder:function(x){if(!x)return this;if($(x))return this.filter(function(P,N){return N.dir&&x.test(P)});var C=this.root+x,A=w.call(this,C),M=this.clone();return M.root=A.name,M},remove:function(x){x=this.root+x;var C=this.files[x];if(C||(x.slice(-1)!=="/"&&(x+="/"),C=this.files[x]),C&&!C.dir)delete this.files[x];else for(var A=this.filter(function(P,N){return N.name.slice(0,x.length)===x}),M=0;M<A.length;M++)delete this.files[A[M].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(x){var C,A={};try{if((A=o.extend(x||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=A.type.toLowerCase(),A.compression=A.compression.toUpperCase(),A.type==="binarystring"&&(A.type="string"),!A.type)throw new Error("No output type specified.");o.checkSupport(A.type),A.platform!=="darwin"&&A.platform!=="freebsd"&&A.platform!=="linux"&&A.platform!=="sunos"||(A.platform="UNIX"),A.platform==="win32"&&(A.platform="DOS");var M=A.comment||this.comment||"";C=u.generateWorker(this,A,M)}catch(P){(C=new a("error")).error(P)}return new c(C,A.type||"string",A.mimeType)},generateAsync:function(x,C){return this.generateInternalStream(x).accumulate(C)},generateNodeStream:function(x,C){return(x=x||{}).type||(x.type="nodebuffer"),this.generateInternalStream(x).toNodejsStream(C)}};s.exports=I},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(e,s,n){s.exports=e("stream")},{stream:void 0}],17:[function(e,s,n){var r=e("./DataReader");function l(o){r.call(this,o);for(var a=0;a<this.data.length;a++)o[a]=255&o[a]}e("../utils").inherits(l,r),l.prototype.byteAt=function(o){return this.data[this.zero+o]},l.prototype.lastIndexOfSignature=function(o){for(var a=o.charCodeAt(0),c=o.charCodeAt(1),d=o.charCodeAt(2),p=o.charCodeAt(3),g=this.length-4;0<=g;--g)if(this.data[g]===a&&this.data[g+1]===c&&this.data[g+2]===d&&this.data[g+3]===p)return g-this.zero;return-1},l.prototype.readAndCheckSignature=function(o){var a=o.charCodeAt(0),c=o.charCodeAt(1),d=o.charCodeAt(2),p=o.charCodeAt(3),g=this.readData(4);return a===g[0]&&c===g[1]&&d===g[2]&&p===g[3]},l.prototype.readData=function(o){if(this.checkOffset(o),o===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},s.exports=l},{"../utils":32,"./DataReader":18}],18:[function(e,s,n){var r=e("../utils");function l(o){this.data=o,this.length=o.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(o){this.checkIndex(this.index+o)},checkIndex:function(o){if(this.length<this.zero+o||o<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+o+"). Corrupted zip ?")},setIndex:function(o){this.checkIndex(o),this.index=o},skip:function(o){this.setIndex(this.index+o)},byteAt:function(){},readInt:function(o){var a,c=0;for(this.checkOffset(o),a=this.index+o-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=o,c},readString:function(o){return r.transformTo("string",this.readData(o))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var o=this.readInt(4);return new Date(Date.UTC(1980+(o>>25&127),(o>>21&15)-1,o>>16&31,o>>11&31,o>>5&63,(31&o)<<1))}},s.exports=l},{"../utils":32}],19:[function(e,s,n){var r=e("./Uint8ArrayReader");function l(o){r.call(this,o)}e("../utils").inherits(l,r),l.prototype.readData=function(o){this.checkOffset(o);var a=this.data.slice(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},s.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(e,s,n){var r=e("./DataReader");function l(o){r.call(this,o)}e("../utils").inherits(l,r),l.prototype.byteAt=function(o){return this.data.charCodeAt(this.zero+o)},l.prototype.lastIndexOfSignature=function(o){return this.data.lastIndexOf(o)-this.zero},l.prototype.readAndCheckSignature=function(o){return o===this.readData(4)},l.prototype.readData=function(o){this.checkOffset(o);var a=this.data.slice(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},s.exports=l},{"../utils":32,"./DataReader":18}],21:[function(e,s,n){var r=e("./ArrayReader");function l(o){r.call(this,o)}e("../utils").inherits(l,r),l.prototype.readData=function(o){if(this.checkOffset(o),o===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},s.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(e,s,n){var r=e("../utils"),l=e("../support"),o=e("./ArrayReader"),a=e("./StringReader"),c=e("./NodeBufferReader"),d=e("./Uint8ArrayReader");s.exports=function(p){var g=r.getTypeOf(p);return r.checkSupport(g),g!=="string"||l.uint8array?g==="nodebuffer"?new c(p):l.uint8array?new d(r.transformTo("uint8array",p)):new o(r.transformTo("array",p)):new a(p)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(e,s,n){n.LOCAL_FILE_HEADER="PK",n.CENTRAL_FILE_HEADER="PK",n.CENTRAL_DIRECTORY_END="PK",n.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",n.ZIP64_CENTRAL_DIRECTORY_END="PK",n.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(e,s,n){var r=e("./GenericWorker"),l=e("../utils");function o(a){r.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(o,r),o.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},s.exports=o},{"../utils":32,"./GenericWorker":28}],25:[function(e,s,n){var r=e("./GenericWorker"),l=e("../crc32");function o(){r.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}e("../utils").inherits(o,r),o.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},s.exports=o},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(e,s,n){var r=e("../utils"),l=e("./GenericWorker");function o(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}r.inherits(o,l),o.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},s.exports=o},{"../utils":32,"./GenericWorker":28}],27:[function(e,s,n){var r=e("../utils"),l=e("./GenericWorker");function o(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=r.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}r.inherits(o,l),o.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},o.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,r.delay(this._tickAndRepeat,[],this)),!0)},o.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(r.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},o.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},s.exports=o},{"../utils":32,"./GenericWorker":28}],28:[function(e,s,n){function r(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}r.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,o){return this._listeners[l].push(o),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,o){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,o)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var o=this;return l.on("data",function(a){o.processChunk(a)}),l.on("end",function(){o.end()}),l.on("error",function(a){o.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,o){return this.extraStreamInfo[l]=o,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},s.exports=r},{}],29:[function(e,s,n){var r=e("../utils"),l=e("./ConvertWorker"),o=e("./GenericWorker"),a=e("../base64"),c=e("../support"),d=e("../external"),p=null;if(c.nodestream)try{p=e("../nodejs/NodejsStreamOutputAdapter")}catch{}function g(k,h){return new d.Promise(function(b,v){var w=[],$=k._internalType,I=k._outputType,x=k._mimeType;k.on("data",function(C,A){w.push(C),h&&h(A)}).on("error",function(C){w=[],v(C)}).on("end",function(){try{var C=(function(A,M,P){switch(A){case"blob":return r.newBlob(r.transformTo("arraybuffer",M),P);case"base64":return a.encode(M);default:return r.transformTo(A,M)}})(I,(function(A,M){var P,N=0,X=null,T=0;for(P=0;P<M.length;P++)T+=M[P].length;switch(A){case"string":return M.join("");case"array":return Array.prototype.concat.apply([],M);case"uint8array":for(X=new Uint8Array(T),P=0;P<M.length;P++)X.set(M[P],N),N+=M[P].length;return X;case"nodebuffer":return Buffer.concat(M);default:throw new Error("concat : unsupported type '"+A+"'")}})($,w),x);b(C)}catch(A){v(A)}w=[]}).resume()})}function u(k,h,b){var v=h;switch(h){case"blob":case"arraybuffer":v="uint8array";break;case"base64":v="string"}try{this._internalType=v,this._outputType=h,this._mimeType=b,r.checkSupport(v),this._worker=k.pipe(new l(v)),k.lock()}catch(w){this._worker=new o("error"),this._worker.error(w)}}u.prototype={accumulate:function(k){return g(this,k)},on:function(k,h){var b=this;return k==="data"?this._worker.on(k,function(v){h.call(b,v.data,v.meta)}):this._worker.on(k,function(){r.delay(h,arguments,b)}),this},resume:function(){return r.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(k){if(r.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new p(this,{objectMode:this._outputType!=="nodebuffer"},k)}},s.exports=u},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(e,s,n){if(n.base64=!0,n.array=!0,n.string=!0,n.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",n.nodebuffer=typeof Buffer<"u",n.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")n.blob=!1;else{var r=new ArrayBuffer(0);try{n.blob=new Blob([r],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(r),n.blob=l.getBlob("application/zip").size===0}catch{n.blob=!1}}}try{n.nodestream=!!e("readable-stream").Readable}catch{n.nodestream=!1}},{"readable-stream":16}],31:[function(e,s,n){for(var r=e("./utils"),l=e("./support"),o=e("./nodejsUtils"),a=e("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function p(){a.call(this,"utf-8 decode"),this.leftOver=null}function g(){a.call(this,"utf-8 encode")}n.utf8encode=function(u){return l.nodebuffer?o.newBufferFrom(u,"utf-8"):(function(k){var h,b,v,w,$,I=k.length,x=0;for(w=0;w<I;w++)(64512&(b=k.charCodeAt(w)))==55296&&w+1<I&&(64512&(v=k.charCodeAt(w+1)))==56320&&(b=65536+(b-55296<<10)+(v-56320),w++),x+=b<128?1:b<2048?2:b<65536?3:4;for(h=l.uint8array?new Uint8Array(x):new Array(x),w=$=0;$<x;w++)(64512&(b=k.charCodeAt(w)))==55296&&w+1<I&&(64512&(v=k.charCodeAt(w+1)))==56320&&(b=65536+(b-55296<<10)+(v-56320),w++),b<128?h[$++]=b:(b<2048?h[$++]=192|b>>>6:(b<65536?h[$++]=224|b>>>12:(h[$++]=240|b>>>18,h[$++]=128|b>>>12&63),h[$++]=128|b>>>6&63),h[$++]=128|63&b);return h})(u)},n.utf8decode=function(u){return l.nodebuffer?r.transformTo("nodebuffer",u).toString("utf-8"):(function(k){var h,b,v,w,$=k.length,I=new Array(2*$);for(h=b=0;h<$;)if((v=k[h++])<128)I[b++]=v;else if(4<(w=c[v]))I[b++]=65533,h+=w-1;else{for(v&=w===2?31:w===3?15:7;1<w&&h<$;)v=v<<6|63&k[h++],w--;1<w?I[b++]=65533:v<65536?I[b++]=v:(v-=65536,I[b++]=55296|v>>10&1023,I[b++]=56320|1023&v)}return I.length!==b&&(I.subarray?I=I.subarray(0,b):I.length=b),r.applyFromCharCode(I)})(u=r.transformTo(l.uint8array?"uint8array":"array",u))},r.inherits(p,a),p.prototype.processChunk=function(u){var k=r.transformTo(l.uint8array?"uint8array":"array",u.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var h=k;(k=new Uint8Array(h.length+this.leftOver.length)).set(this.leftOver,0),k.set(h,this.leftOver.length)}else k=this.leftOver.concat(k);this.leftOver=null}var b=(function(w,$){var I;for(($=$||w.length)>w.length&&($=w.length),I=$-1;0<=I&&(192&w[I])==128;)I--;return I<0||I===0?$:I+c[w[I]]>$?I:$})(k),v=k;b!==k.length&&(l.uint8array?(v=k.subarray(0,b),this.leftOver=k.subarray(b,k.length)):(v=k.slice(0,b),this.leftOver=k.slice(b,k.length))),this.push({data:n.utf8decode(v),meta:u.meta})},p.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:n.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},n.Utf8DecodeWorker=p,r.inherits(g,a),g.prototype.processChunk=function(u){this.push({data:n.utf8encode(u.data),meta:u.meta})},n.Utf8EncodeWorker=g},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(e,s,n){var r=e("./support"),l=e("./base64"),o=e("./nodejsUtils"),a=e("./external");function c(h){return h}function d(h,b){for(var v=0;v<h.length;++v)b[v]=255&h.charCodeAt(v);return b}e("setimmediate"),n.newBlob=function(h,b){n.checkSupport("blob");try{return new Blob([h],{type:b})}catch{try{var v=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return v.append(h),v.getBlob(b)}catch{throw new Error("Bug : can't construct the Blob.")}}};var p={stringifyByChunk:function(h,b,v){var w=[],$=0,I=h.length;if(I<=v)return String.fromCharCode.apply(null,h);for(;$<I;)b==="array"||b==="nodebuffer"?w.push(String.fromCharCode.apply(null,h.slice($,Math.min($+v,I)))):w.push(String.fromCharCode.apply(null,h.subarray($,Math.min($+v,I)))),$+=v;return w.join("")},stringifyByChar:function(h){for(var b="",v=0;v<h.length;v++)b+=String.fromCharCode(h[v]);return b},applyCanBeUsed:{uint8array:(function(){try{return r.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return r.nodebuffer&&String.fromCharCode.apply(null,o.allocBuffer(1)).length===1}catch{return!1}})()}};function g(h){var b=65536,v=n.getTypeOf(h),w=!0;if(v==="uint8array"?w=p.applyCanBeUsed.uint8array:v==="nodebuffer"&&(w=p.applyCanBeUsed.nodebuffer),w)for(;1<b;)try{return p.stringifyByChunk(h,v,b)}catch{b=Math.floor(b/2)}return p.stringifyByChar(h)}function u(h,b){for(var v=0;v<h.length;v++)b[v]=h[v];return b}n.applyFromCharCode=g;var k={};k.string={string:c,array:function(h){return d(h,new Array(h.length))},arraybuffer:function(h){return k.string.uint8array(h).buffer},uint8array:function(h){return d(h,new Uint8Array(h.length))},nodebuffer:function(h){return d(h,o.allocBuffer(h.length))}},k.array={string:g,array:c,arraybuffer:function(h){return new Uint8Array(h).buffer},uint8array:function(h){return new Uint8Array(h)},nodebuffer:function(h){return o.newBufferFrom(h)}},k.arraybuffer={string:function(h){return g(new Uint8Array(h))},array:function(h){return u(new Uint8Array(h),new Array(h.byteLength))},arraybuffer:c,uint8array:function(h){return new Uint8Array(h)},nodebuffer:function(h){return o.newBufferFrom(new Uint8Array(h))}},k.uint8array={string:g,array:function(h){return u(h,new Array(h.length))},arraybuffer:function(h){return h.buffer},uint8array:c,nodebuffer:function(h){return o.newBufferFrom(h)}},k.nodebuffer={string:g,array:function(h){return u(h,new Array(h.length))},arraybuffer:function(h){return k.nodebuffer.uint8array(h).buffer},uint8array:function(h){return u(h,new Uint8Array(h.length))},nodebuffer:c},n.transformTo=function(h,b){if(b=b||"",!h)return b;n.checkSupport(h);var v=n.getTypeOf(b);return k[v][h](b)},n.resolve=function(h){for(var b=h.split("/"),v=[],w=0;w<b.length;w++){var $=b[w];$==="."||$===""&&w!==0&&w!==b.length-1||($===".."?v.pop():v.push($))}return v.join("/")},n.getTypeOf=function(h){return typeof h=="string"?"string":Object.prototype.toString.call(h)==="[object Array]"?"array":r.nodebuffer&&o.isBuffer(h)?"nodebuffer":r.uint8array&&h instanceof Uint8Array?"uint8array":r.arraybuffer&&h instanceof ArrayBuffer?"arraybuffer":void 0},n.checkSupport=function(h){if(!r[h.toLowerCase()])throw new Error(h+" is not supported by this platform")},n.MAX_VALUE_16BITS=65535,n.MAX_VALUE_32BITS=-1,n.pretty=function(h){var b,v,w="";for(v=0;v<(h||"").length;v++)w+="\\x"+((b=h.charCodeAt(v))<16?"0":"")+b.toString(16).toUpperCase();return w},n.delay=function(h,b,v){setImmediate(function(){h.apply(v||null,b||[])})},n.inherits=function(h,b){function v(){}v.prototype=b.prototype,h.prototype=new v},n.extend=function(){var h,b,v={};for(h=0;h<arguments.length;h++)for(b in arguments[h])Object.prototype.hasOwnProperty.call(arguments[h],b)&&v[b]===void 0&&(v[b]=arguments[h][b]);return v},n.prepareContent=function(h,b,v,w,$){return a.Promise.resolve(b).then(function(I){return r.blob&&(I instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(I))!==-1)&&typeof FileReader<"u"?new a.Promise(function(x,C){var A=new FileReader;A.onload=function(M){x(M.target.result)},A.onerror=function(M){C(M.target.error)},A.readAsArrayBuffer(I)}):I}).then(function(I){var x=n.getTypeOf(I);return x?(x==="arraybuffer"?I=n.transformTo("uint8array",I):x==="string"&&($?I=l.decode(I):v&&w!==!0&&(I=(function(C){return d(C,r.uint8array?new Uint8Array(C.length):new Array(C.length))})(I))),I):a.Promise.reject(new Error("Can't read the data of '"+h+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(e,s,n){var r=e("./reader/readerFor"),l=e("./utils"),o=e("./signature"),a=e("./zipEntry"),c=e("./support");function d(p){this.files=[],this.loadOptions=p}d.prototype={checkSignature:function(p){if(!this.reader.readAndCheckSignature(p)){this.reader.index-=4;var g=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(g)+", expected "+l.pretty(p)+")")}},isSignature:function(p,g){var u=this.reader.index;this.reader.setIndex(p);var k=this.reader.readString(4)===g;return this.reader.setIndex(u),k},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var p=this.reader.readData(this.zipCommentLength),g=c.uint8array?"uint8array":"array",u=l.transformTo(g,p);this.zipComment=this.loadOptions.decodeFileName(u)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var p,g,u,k=this.zip64EndOfCentralSize-44;0<k;)p=this.reader.readInt(2),g=this.reader.readInt(4),u=this.reader.readData(g),this.zip64ExtensibleData[p]={id:p,length:g,value:u}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var p,g;for(p=0;p<this.files.length;p++)g=this.files[p],this.reader.setIndex(g.localHeaderOffset),this.checkSignature(o.LOCAL_FILE_HEADER),g.readLocalPart(this.reader),g.handleUTF8(),g.processAttributes()},readCentralDir:function(){var p;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(o.CENTRAL_FILE_HEADER);)(p=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(p);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var p=this.reader.lastIndexOfSignature(o.CENTRAL_DIRECTORY_END);if(p<0)throw this.isSignature(0,o.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(p);var g=p;if(this.checkSignature(o.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(p=this.reader.lastIndexOfSignature(o.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(p),this.checkSignature(o.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,o.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(o.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(o.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var u=this.centralDirOffset+this.centralDirSize;this.zip64&&(u+=20,u+=12+this.zip64EndOfCentralSize);var k=g-u;if(0<k)this.isSignature(g,o.CENTRAL_FILE_HEADER)||(this.reader.zero=k);else if(k<0)throw new Error("Corrupted zip: missing "+Math.abs(k)+" bytes.")},prepareReader:function(p){this.reader=r(p)},load:function(p){this.prepareReader(p),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},s.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(e,s,n){var r=e("./reader/readerFor"),l=e("./utils"),o=e("./compressedObject"),a=e("./crc32"),c=e("./utf8"),d=e("./compressions"),p=e("./support");function g(u,k){this.options=u,this.loadOptions=k}g.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(u){var k,h;if(u.skip(22),this.fileNameLength=u.readInt(2),h=u.readInt(2),this.fileName=u.readData(this.fileNameLength),u.skip(h),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((k=(function(b){for(var v in d)if(Object.prototype.hasOwnProperty.call(d,v)&&d[v].magic===b)return d[v];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new o(this.compressedSize,this.uncompressedSize,this.crc32,k,u.readData(this.compressedSize))},readCentralPart:function(u){this.versionMadeBy=u.readInt(2),u.skip(2),this.bitFlag=u.readInt(2),this.compressionMethod=u.readString(2),this.date=u.readDate(),this.crc32=u.readInt(4),this.compressedSize=u.readInt(4),this.uncompressedSize=u.readInt(4);var k=u.readInt(2);if(this.extraFieldsLength=u.readInt(2),this.fileCommentLength=u.readInt(2),this.diskNumberStart=u.readInt(2),this.internalFileAttributes=u.readInt(2),this.externalFileAttributes=u.readInt(4),this.localHeaderOffset=u.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");u.skip(k),this.readExtraFields(u),this.parseZIP64ExtraField(u),this.fileComment=u.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var u=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),u==0&&(this.dosPermissions=63&this.externalFileAttributes),u==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var u=r(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=u.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=u.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=u.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=u.readInt(4))}},readExtraFields:function(u){var k,h,b,v=u.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});u.index+4<v;)k=u.readInt(2),h=u.readInt(2),b=u.readData(h),this.extraFields[k]={id:k,length:h,value:b};u.setIndex(v)},handleUTF8:function(){var u=p.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var k=this.findExtraFieldUnicodePath();if(k!==null)this.fileNameStr=k;else{var h=l.transformTo(u,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(h)}var b=this.findExtraFieldUnicodeComment();if(b!==null)this.fileCommentStr=b;else{var v=l.transformTo(u,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(v)}}},findExtraFieldUnicodePath:function(){var u=this.extraFields[28789];if(u){var k=r(u.value);return k.readInt(1)!==1||a(this.fileName)!==k.readInt(4)?null:c.utf8decode(k.readData(u.length-5))}return null},findExtraFieldUnicodeComment:function(){var u=this.extraFields[25461];if(u){var k=r(u.value);return k.readInt(1)!==1||a(this.fileComment)!==k.readInt(4)?null:c.utf8decode(k.readData(u.length-5))}return null}},s.exports=g},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(e,s,n){function r(k,h,b){this.name=k,this.dir=b.dir,this.date=b.date,this.comment=b.comment,this.unixPermissions=b.unixPermissions,this.dosPermissions=b.dosPermissions,this._data=h,this._dataBinary=b.binary,this.options={compression:b.compression,compressionOptions:b.compressionOptions}}var l=e("./stream/StreamHelper"),o=e("./stream/DataWorker"),a=e("./utf8"),c=e("./compressedObject"),d=e("./stream/GenericWorker");r.prototype={internalStream:function(k){var h=null,b="string";try{if(!k)throw new Error("No output type specified.");var v=(b=k.toLowerCase())==="string"||b==="text";b!=="binarystring"&&b!=="text"||(b="string"),h=this._decompressWorker();var w=!this._dataBinary;w&&!v&&(h=h.pipe(new a.Utf8EncodeWorker)),!w&&v&&(h=h.pipe(new a.Utf8DecodeWorker))}catch($){(h=new d("error")).error($)}return new l(h,b,"")},async:function(k,h){return this.internalStream(k).accumulate(h)},nodeStream:function(k,h){return this.internalStream(k||"nodebuffer").toNodejsStream(h)},_compressWorker:function(k,h){if(this._data instanceof c&&this._data.compression.magic===k.magic)return this._data.getCompressedWorker();var b=this._decompressWorker();return this._dataBinary||(b=b.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(b,k,h)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new o(this._data)}};for(var p=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],g=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},u=0;u<p.length;u++)r.prototype[p[u]]=g;s.exports=r},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(e,s,n){(function(r){var l,o,a=r.MutationObserver||r.WebKitMutationObserver;if(a){var c=0,d=new a(k),p=r.document.createTextNode("");d.observe(p,{characterData:!0}),l=function(){p.data=c=++c%2}}else if(r.setImmediate||r.MessageChannel===void 0)l="document"in r&&"onreadystatechange"in r.document.createElement("script")?function(){var h=r.document.createElement("script");h.onreadystatechange=function(){k(),h.onreadystatechange=null,h.parentNode.removeChild(h),h=null},r.document.documentElement.appendChild(h)}:function(){setTimeout(k,0)};else{var g=new r.MessageChannel;g.port1.onmessage=k,l=function(){g.port2.postMessage(0)}}var u=[];function k(){var h,b;o=!0;for(var v=u.length;v;){for(b=u,u=[],h=-1;++h<v;)b[h]();v=u.length}o=!1}s.exports=function(h){u.push(h)!==1||o||l()}}).call(this,typeof zn<"u"?zn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(e,s,n){var r=e("immediate");function l(){}var o={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function p(v){if(typeof v!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,v!==l&&h(this,v)}function g(v,w,$){this.promise=v,typeof w=="function"&&(this.onFulfilled=w,this.callFulfilled=this.otherCallFulfilled),typeof $=="function"&&(this.onRejected=$,this.callRejected=this.otherCallRejected)}function u(v,w,$){r(function(){var I;try{I=w($)}catch(x){return o.reject(v,x)}I===v?o.reject(v,new TypeError("Cannot resolve promise with itself")):o.resolve(v,I)})}function k(v){var w=v&&v.then;if(v&&(typeof v=="object"||typeof v=="function")&&typeof w=="function")return function(){w.apply(v,arguments)}}function h(v,w){var $=!1;function I(A){$||($=!0,o.reject(v,A))}function x(A){$||($=!0,o.resolve(v,A))}var C=b(function(){w(x,I)});C.status==="error"&&I(C.value)}function b(v,w){var $={};try{$.value=v(w),$.status="success"}catch(I){$.status="error",$.value=I}return $}(s.exports=p).prototype.finally=function(v){if(typeof v!="function")return this;var w=this.constructor;return this.then(function($){return w.resolve(v()).then(function(){return $})},function($){return w.resolve(v()).then(function(){throw $})})},p.prototype.catch=function(v){return this.then(null,v)},p.prototype.then=function(v,w){if(typeof v!="function"&&this.state===c||typeof w!="function"&&this.state===a)return this;var $=new this.constructor(l);return this.state!==d?u($,this.state===c?v:w,this.outcome):this.queue.push(new g($,v,w)),$},g.prototype.callFulfilled=function(v){o.resolve(this.promise,v)},g.prototype.otherCallFulfilled=function(v){u(this.promise,this.onFulfilled,v)},g.prototype.callRejected=function(v){o.reject(this.promise,v)},g.prototype.otherCallRejected=function(v){u(this.promise,this.onRejected,v)},o.resolve=function(v,w){var $=b(k,w);if($.status==="error")return o.reject(v,$.value);var I=$.value;if(I)h(v,I);else{v.state=c,v.outcome=w;for(var x=-1,C=v.queue.length;++x<C;)v.queue[x].callFulfilled(w)}return v},o.reject=function(v,w){v.state=a,v.outcome=w;for(var $=-1,I=v.queue.length;++$<I;)v.queue[$].callRejected(w);return v},p.resolve=function(v){return v instanceof this?v:o.resolve(new this(l),v)},p.reject=function(v){var w=new this(l);return o.reject(w,v)},p.all=function(v){var w=this;if(Object.prototype.toString.call(v)!=="[object Array]")return this.reject(new TypeError("must be an array"));var $=v.length,I=!1;if(!$)return this.resolve([]);for(var x=new Array($),C=0,A=-1,M=new this(l);++A<$;)P(v[A],A);return M;function P(N,X){w.resolve(N).then(function(T){x[X]=T,++C!==$||I||(I=!0,o.resolve(M,x))},function(T){I||(I=!0,o.reject(M,T))})}},p.race=function(v){var w=this;if(Object.prototype.toString.call(v)!=="[object Array]")return this.reject(new TypeError("must be an array"));var $=v.length,I=!1;if(!$)return this.resolve([]);for(var x=-1,C=new this(l);++x<$;)A=v[x],w.resolve(A).then(function(M){I||(I=!0,o.resolve(C,M))},function(M){I||(I=!0,o.reject(C,M))});var A;return C}},{immediate:36}],38:[function(e,s,n){var r={};(0,e("./lib/utils/common").assign)(r,e("./lib/deflate"),e("./lib/inflate"),e("./lib/zlib/constants")),s.exports=r},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(e,s,n){var r=e("./zlib/deflate"),l=e("./utils/common"),o=e("./utils/strings"),a=e("./zlib/messages"),c=e("./zlib/zstream"),d=Object.prototype.toString,p=0,g=-1,u=0,k=8;function h(v){if(!(this instanceof h))return new h(v);this.options=l.assign({level:g,method:k,chunkSize:16384,windowBits:15,memLevel:8,strategy:u,to:""},v||{});var w=this.options;w.raw&&0<w.windowBits?w.windowBits=-w.windowBits:w.gzip&&0<w.windowBits&&w.windowBits<16&&(w.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var $=r.deflateInit2(this.strm,w.level,w.method,w.windowBits,w.memLevel,w.strategy);if($!==p)throw new Error(a[$]);if(w.header&&r.deflateSetHeader(this.strm,w.header),w.dictionary){var I;if(I=typeof w.dictionary=="string"?o.string2buf(w.dictionary):d.call(w.dictionary)==="[object ArrayBuffer]"?new Uint8Array(w.dictionary):w.dictionary,($=r.deflateSetDictionary(this.strm,I))!==p)throw new Error(a[$]);this._dict_set=!0}}function b(v,w){var $=new h(w);if($.push(v,!0),$.err)throw $.msg||a[$.err];return $.result}h.prototype.push=function(v,w){var $,I,x=this.strm,C=this.options.chunkSize;if(this.ended)return!1;I=w===~~w?w:w===!0?4:0,typeof v=="string"?x.input=o.string2buf(v):d.call(v)==="[object ArrayBuffer]"?x.input=new Uint8Array(v):x.input=v,x.next_in=0,x.avail_in=x.input.length;do{if(x.avail_out===0&&(x.output=new l.Buf8(C),x.next_out=0,x.avail_out=C),($=r.deflate(x,I))!==1&&$!==p)return this.onEnd($),!(this.ended=!0);x.avail_out!==0&&(x.avail_in!==0||I!==4&&I!==2)||(this.options.to==="string"?this.onData(o.buf2binstring(l.shrinkBuf(x.output,x.next_out))):this.onData(l.shrinkBuf(x.output,x.next_out)))}while((0<x.avail_in||x.avail_out===0)&&$!==1);return I===4?($=r.deflateEnd(this.strm),this.onEnd($),this.ended=!0,$===p):I!==2||(this.onEnd(p),!(x.avail_out=0))},h.prototype.onData=function(v){this.chunks.push(v)},h.prototype.onEnd=function(v){v===p&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=v,this.msg=this.strm.msg},n.Deflate=h,n.deflate=b,n.deflateRaw=function(v,w){return(w=w||{}).raw=!0,b(v,w)},n.gzip=function(v,w){return(w=w||{}).gzip=!0,b(v,w)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(e,s,n){var r=e("./zlib/inflate"),l=e("./utils/common"),o=e("./utils/strings"),a=e("./zlib/constants"),c=e("./zlib/messages"),d=e("./zlib/zstream"),p=e("./zlib/gzheader"),g=Object.prototype.toString;function u(h){if(!(this instanceof u))return new u(h);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},h||{});var b=this.options;b.raw&&0<=b.windowBits&&b.windowBits<16&&(b.windowBits=-b.windowBits,b.windowBits===0&&(b.windowBits=-15)),!(0<=b.windowBits&&b.windowBits<16)||h&&h.windowBits||(b.windowBits+=32),15<b.windowBits&&b.windowBits<48&&(15&b.windowBits)==0&&(b.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var v=r.inflateInit2(this.strm,b.windowBits);if(v!==a.Z_OK)throw new Error(c[v]);this.header=new p,r.inflateGetHeader(this.strm,this.header)}function k(h,b){var v=new u(b);if(v.push(h,!0),v.err)throw v.msg||c[v.err];return v.result}u.prototype.push=function(h,b){var v,w,$,I,x,C,A=this.strm,M=this.options.chunkSize,P=this.options.dictionary,N=!1;if(this.ended)return!1;w=b===~~b?b:b===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof h=="string"?A.input=o.binstring2buf(h):g.call(h)==="[object ArrayBuffer]"?A.input=new Uint8Array(h):A.input=h,A.next_in=0,A.avail_in=A.input.length;do{if(A.avail_out===0&&(A.output=new l.Buf8(M),A.next_out=0,A.avail_out=M),(v=r.inflate(A,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&P&&(C=typeof P=="string"?o.string2buf(P):g.call(P)==="[object ArrayBuffer]"?new Uint8Array(P):P,v=r.inflateSetDictionary(this.strm,C)),v===a.Z_BUF_ERROR&&N===!0&&(v=a.Z_OK,N=!1),v!==a.Z_STREAM_END&&v!==a.Z_OK)return this.onEnd(v),!(this.ended=!0);A.next_out&&(A.avail_out!==0&&v!==a.Z_STREAM_END&&(A.avail_in!==0||w!==a.Z_FINISH&&w!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?($=o.utf8border(A.output,A.next_out),I=A.next_out-$,x=o.buf2string(A.output,$),A.next_out=I,A.avail_out=M-I,I&&l.arraySet(A.output,A.output,$,I,0),this.onData(x)):this.onData(l.shrinkBuf(A.output,A.next_out)))),A.avail_in===0&&A.avail_out===0&&(N=!0)}while((0<A.avail_in||A.avail_out===0)&&v!==a.Z_STREAM_END);return v===a.Z_STREAM_END&&(w=a.Z_FINISH),w===a.Z_FINISH?(v=r.inflateEnd(this.strm),this.onEnd(v),this.ended=!0,v===a.Z_OK):w!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(A.avail_out=0))},u.prototype.onData=function(h){this.chunks.push(h)},u.prototype.onEnd=function(h){h===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=h,this.msg=this.strm.msg},n.Inflate=u,n.inflate=k,n.inflateRaw=function(h,b){return(b=b||{}).raw=!0,k(h,b)},n.ungzip=k},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(e,s,n){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";n.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var p in d)d.hasOwnProperty(p)&&(a[p]=d[p])}}return a},n.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,p,g){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+p),g);else for(var u=0;u<p;u++)a[g+u]=c[d+u]},flattenChunks:function(a){var c,d,p,g,u,k;for(c=p=0,d=a.length;c<d;c++)p+=a[c].length;for(k=new Uint8Array(p),c=g=0,d=a.length;c<d;c++)u=a[c],k.set(u,g),g+=u.length;return k}},o={arraySet:function(a,c,d,p,g){for(var u=0;u<p;u++)a[g+u]=c[d+u]},flattenChunks:function(a){return[].concat.apply([],a)}};n.setTyped=function(a){a?(n.Buf8=Uint8Array,n.Buf16=Uint16Array,n.Buf32=Int32Array,n.assign(n,l)):(n.Buf8=Array,n.Buf16=Array,n.Buf32=Array,n.assign(n,o))},n.setTyped(r)},{}],42:[function(e,s,n){var r=e("./common"),l=!0,o=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{o=!1}for(var a=new r.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(p,g){if(g<65537&&(p.subarray&&o||!p.subarray&&l))return String.fromCharCode.apply(null,r.shrinkBuf(p,g));for(var u="",k=0;k<g;k++)u+=String.fromCharCode(p[k]);return u}a[254]=a[254]=1,n.string2buf=function(p){var g,u,k,h,b,v=p.length,w=0;for(h=0;h<v;h++)(64512&(u=p.charCodeAt(h)))==55296&&h+1<v&&(64512&(k=p.charCodeAt(h+1)))==56320&&(u=65536+(u-55296<<10)+(k-56320),h++),w+=u<128?1:u<2048?2:u<65536?3:4;for(g=new r.Buf8(w),h=b=0;b<w;h++)(64512&(u=p.charCodeAt(h)))==55296&&h+1<v&&(64512&(k=p.charCodeAt(h+1)))==56320&&(u=65536+(u-55296<<10)+(k-56320),h++),u<128?g[b++]=u:(u<2048?g[b++]=192|u>>>6:(u<65536?g[b++]=224|u>>>12:(g[b++]=240|u>>>18,g[b++]=128|u>>>12&63),g[b++]=128|u>>>6&63),g[b++]=128|63&u);return g},n.buf2binstring=function(p){return d(p,p.length)},n.binstring2buf=function(p){for(var g=new r.Buf8(p.length),u=0,k=g.length;u<k;u++)g[u]=p.charCodeAt(u);return g},n.buf2string=function(p,g){var u,k,h,b,v=g||p.length,w=new Array(2*v);for(u=k=0;u<v;)if((h=p[u++])<128)w[k++]=h;else if(4<(b=a[h]))w[k++]=65533,u+=b-1;else{for(h&=b===2?31:b===3?15:7;1<b&&u<v;)h=h<<6|63&p[u++],b--;1<b?w[k++]=65533:h<65536?w[k++]=h:(h-=65536,w[k++]=55296|h>>10&1023,w[k++]=56320|1023&h)}return d(w,k)},n.utf8border=function(p,g){var u;for((g=g||p.length)>p.length&&(g=p.length),u=g-1;0<=u&&(192&p[u])==128;)u--;return u<0||u===0?g:u+a[p[u]]>g?u:g}},{"./common":41}],43:[function(e,s,n){s.exports=function(r,l,o,a){for(var c=65535&r|0,d=r>>>16&65535|0,p=0;o!==0;){for(o-=p=2e3<o?2e3:o;d=d+(c=c+l[a++]|0)|0,--p;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(e,s,n){s.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(e,s,n){var r=(function(){for(var l,o=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;o[a]=l}return o})();s.exports=function(l,o,a,c){var d=r,p=c+a;l^=-1;for(var g=c;g<p;g++)l=l>>>8^d[255&(l^o[g])];return-1^l}},{}],46:[function(e,s,n){var r,l=e("../utils/common"),o=e("./trees"),a=e("./adler32"),c=e("./crc32"),d=e("./messages"),p=0,g=4,u=0,k=-2,h=-1,b=4,v=2,w=8,$=9,I=286,x=30,C=19,A=2*I+1,M=15,P=3,N=258,X=N+P+1,T=42,D=113,y=1,R=2,Q=3,U=4;function at(f,F){return f.msg=d[F],F}function V(f){return(f<<1)-(4<f?9:0)}function Y(f){for(var F=f.length;0<=--F;)f[F]=0}function W(f){var F=f.state,O=F.pending;O>f.avail_out&&(O=f.avail_out),O!==0&&(l.arraySet(f.output,F.pending_buf,F.pending_out,O,f.next_out),f.next_out+=O,F.pending_out+=O,f.total_out+=O,f.avail_out-=O,F.pending-=O,F.pending===0&&(F.pending_out=0))}function z(f,F){o._tr_flush_block(f,0<=f.block_start?f.block_start:-1,f.strstart-f.block_start,F),f.block_start=f.strstart,W(f.strm)}function ct(f,F){f.pending_buf[f.pending++]=F}function rt(f,F){f.pending_buf[f.pending++]=F>>>8&255,f.pending_buf[f.pending++]=255&F}function st(f,F){var O,_,S=f.max_chain_length,B=f.strstart,K=f.prev_length,j=f.nice_match,H=f.strstart>f.w_size-X?f.strstart-(f.w_size-X):0,G=f.window,it=f.w_mask,tt=f.prev,ut=f.strstart+N,xt=G[B+K-1],bt=G[B+K];f.prev_length>=f.good_match&&(S>>=2),j>f.lookahead&&(j=f.lookahead);do if(G[(O=F)+K]===bt&&G[O+K-1]===xt&&G[O]===G[B]&&G[++O]===G[B+1]){B+=2,O++;do;while(G[++B]===G[++O]&&G[++B]===G[++O]&&G[++B]===G[++O]&&G[++B]===G[++O]&&G[++B]===G[++O]&&G[++B]===G[++O]&&G[++B]===G[++O]&&G[++B]===G[++O]&&B<ut);if(_=N-(ut-B),B=ut-N,K<_){if(f.match_start=F,j<=(K=_))break;xt=G[B+K-1],bt=G[B+K]}}while((F=tt[F&it])>H&&--S!=0);return K<=f.lookahead?K:f.lookahead}function J(f){var F,O,_,S,B,K,j,H,G,it,tt=f.w_size;do{if(S=f.window_size-f.lookahead-f.strstart,f.strstart>=tt+(tt-X)){for(l.arraySet(f.window,f.window,tt,tt,0),f.match_start-=tt,f.strstart-=tt,f.block_start-=tt,F=O=f.hash_size;_=f.head[--F],f.head[F]=tt<=_?_-tt:0,--O;);for(F=O=tt;_=f.prev[--F],f.prev[F]=tt<=_?_-tt:0,--O;);S+=tt}if(f.strm.avail_in===0)break;if(K=f.strm,j=f.window,H=f.strstart+f.lookahead,G=S,it=void 0,it=K.avail_in,G<it&&(it=G),O=it===0?0:(K.avail_in-=it,l.arraySet(j,K.input,K.next_in,it,H),K.state.wrap===1?K.adler=a(K.adler,j,it,H):K.state.wrap===2&&(K.adler=c(K.adler,j,it,H)),K.next_in+=it,K.total_in+=it,it),f.lookahead+=O,f.lookahead+f.insert>=P)for(B=f.strstart-f.insert,f.ins_h=f.window[B],f.ins_h=(f.ins_h<<f.hash_shift^f.window[B+1])&f.hash_mask;f.insert&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[B+P-1])&f.hash_mask,f.prev[B&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=B,B++,f.insert--,!(f.lookahead+f.insert<P)););}while(f.lookahead<X&&f.strm.avail_in!==0)}function gt(f,F){for(var O,_;;){if(f.lookahead<X){if(J(f),f.lookahead<X&&F===p)return y;if(f.lookahead===0)break}if(O=0,f.lookahead>=P&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+P-1])&f.hash_mask,O=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart),O!==0&&f.strstart-O<=f.w_size-X&&(f.match_length=st(f,O)),f.match_length>=P)if(_=o._tr_tally(f,f.strstart-f.match_start,f.match_length-P),f.lookahead-=f.match_length,f.match_length<=f.max_lazy_match&&f.lookahead>=P){for(f.match_length--;f.strstart++,f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+P-1])&f.hash_mask,O=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart,--f.match_length!=0;);f.strstart++}else f.strstart+=f.match_length,f.match_length=0,f.ins_h=f.window[f.strstart],f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+1])&f.hash_mask;else _=o._tr_tally(f,0,f.window[f.strstart]),f.lookahead--,f.strstart++;if(_&&(z(f,!1),f.strm.avail_out===0))return y}return f.insert=f.strstart<P-1?f.strstart:P-1,F===g?(z(f,!0),f.strm.avail_out===0?Q:U):f.last_lit&&(z(f,!1),f.strm.avail_out===0)?y:R}function mt(f,F){for(var O,_,S;;){if(f.lookahead<X){if(J(f),f.lookahead<X&&F===p)return y;if(f.lookahead===0)break}if(O=0,f.lookahead>=P&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+P-1])&f.hash_mask,O=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart),f.prev_length=f.match_length,f.prev_match=f.match_start,f.match_length=P-1,O!==0&&f.prev_length<f.max_lazy_match&&f.strstart-O<=f.w_size-X&&(f.match_length=st(f,O),f.match_length<=5&&(f.strategy===1||f.match_length===P&&4096<f.strstart-f.match_start)&&(f.match_length=P-1)),f.prev_length>=P&&f.match_length<=f.prev_length){for(S=f.strstart+f.lookahead-P,_=o._tr_tally(f,f.strstart-1-f.prev_match,f.prev_length-P),f.lookahead-=f.prev_length-1,f.prev_length-=2;++f.strstart<=S&&(f.ins_h=(f.ins_h<<f.hash_shift^f.window[f.strstart+P-1])&f.hash_mask,O=f.prev[f.strstart&f.w_mask]=f.head[f.ins_h],f.head[f.ins_h]=f.strstart),--f.prev_length!=0;);if(f.match_available=0,f.match_length=P-1,f.strstart++,_&&(z(f,!1),f.strm.avail_out===0))return y}else if(f.match_available){if((_=o._tr_tally(f,0,f.window[f.strstart-1]))&&z(f,!1),f.strstart++,f.lookahead--,f.strm.avail_out===0)return y}else f.match_available=1,f.strstart++,f.lookahead--}return f.match_available&&(_=o._tr_tally(f,0,f.window[f.strstart-1]),f.match_available=0),f.insert=f.strstart<P-1?f.strstart:P-1,F===g?(z(f,!0),f.strm.avail_out===0?Q:U):f.last_lit&&(z(f,!1),f.strm.avail_out===0)?y:R}function Z(f,F,O,_,S){this.good_length=f,this.max_lazy=F,this.nice_length=O,this.max_chain=_,this.func=S}function ot(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=w,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*A),this.dyn_dtree=new l.Buf16(2*(2*x+1)),this.bl_tree=new l.Buf16(2*(2*C+1)),Y(this.dyn_ltree),Y(this.dyn_dtree),Y(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(M+1),this.heap=new l.Buf16(2*I+1),Y(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*I+1),Y(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function dt(f){var F;return f&&f.state?(f.total_in=f.total_out=0,f.data_type=v,(F=f.state).pending=0,F.pending_out=0,F.wrap<0&&(F.wrap=-F.wrap),F.status=F.wrap?T:D,f.adler=F.wrap===2?0:1,F.last_flush=p,o._tr_init(F),u):at(f,k)}function E(f){var F=dt(f);return F===u&&(function(O){O.window_size=2*O.w_size,Y(O.head),O.max_lazy_match=r[O.level].max_lazy,O.good_match=r[O.level].good_length,O.nice_match=r[O.level].nice_length,O.max_chain_length=r[O.level].max_chain,O.strstart=0,O.block_start=0,O.lookahead=0,O.insert=0,O.match_length=O.prev_length=P-1,O.match_available=0,O.ins_h=0})(f.state),F}function L(f,F,O,_,S,B){if(!f)return k;var K=1;if(F===h&&(F=6),_<0?(K=0,_=-_):15<_&&(K=2,_-=16),S<1||$<S||O!==w||_<8||15<_||F<0||9<F||B<0||b<B)return at(f,k);_===8&&(_=9);var j=new ot;return(f.state=j).strm=f,j.wrap=K,j.gzhead=null,j.w_bits=_,j.w_size=1<<j.w_bits,j.w_mask=j.w_size-1,j.hash_bits=S+7,j.hash_size=1<<j.hash_bits,j.hash_mask=j.hash_size-1,j.hash_shift=~~((j.hash_bits+P-1)/P),j.window=new l.Buf8(2*j.w_size),j.head=new l.Buf16(j.hash_size),j.prev=new l.Buf16(j.w_size),j.lit_bufsize=1<<S+6,j.pending_buf_size=4*j.lit_bufsize,j.pending_buf=new l.Buf8(j.pending_buf_size),j.d_buf=1*j.lit_bufsize,j.l_buf=3*j.lit_bufsize,j.level=F,j.strategy=B,j.method=O,E(f)}r=[new Z(0,0,0,0,function(f,F){var O=65535;for(O>f.pending_buf_size-5&&(O=f.pending_buf_size-5);;){if(f.lookahead<=1){if(J(f),f.lookahead===0&&F===p)return y;if(f.lookahead===0)break}f.strstart+=f.lookahead,f.lookahead=0;var _=f.block_start+O;if((f.strstart===0||f.strstart>=_)&&(f.lookahead=f.strstart-_,f.strstart=_,z(f,!1),f.strm.avail_out===0)||f.strstart-f.block_start>=f.w_size-X&&(z(f,!1),f.strm.avail_out===0))return y}return f.insert=0,F===g?(z(f,!0),f.strm.avail_out===0?Q:U):(f.strstart>f.block_start&&(z(f,!1),f.strm.avail_out),y)}),new Z(4,4,8,4,gt),new Z(4,5,16,8,gt),new Z(4,6,32,32,gt),new Z(4,4,16,16,mt),new Z(8,16,32,32,mt),new Z(8,16,128,128,mt),new Z(8,32,128,256,mt),new Z(32,128,258,1024,mt),new Z(32,258,258,4096,mt)],n.deflateInit=function(f,F){return L(f,F,w,15,8,0)},n.deflateInit2=L,n.deflateReset=E,n.deflateResetKeep=dt,n.deflateSetHeader=function(f,F){return f&&f.state?f.state.wrap!==2?k:(f.state.gzhead=F,u):k},n.deflate=function(f,F){var O,_,S,B;if(!f||!f.state||5<F||F<0)return f?at(f,k):k;if(_=f.state,!f.output||!f.input&&f.avail_in!==0||_.status===666&&F!==g)return at(f,f.avail_out===0?-5:k);if(_.strm=f,O=_.last_flush,_.last_flush=F,_.status===T)if(_.wrap===2)f.adler=0,ct(_,31),ct(_,139),ct(_,8),_.gzhead?(ct(_,(_.gzhead.text?1:0)+(_.gzhead.hcrc?2:0)+(_.gzhead.extra?4:0)+(_.gzhead.name?8:0)+(_.gzhead.comment?16:0)),ct(_,255&_.gzhead.time),ct(_,_.gzhead.time>>8&255),ct(_,_.gzhead.time>>16&255),ct(_,_.gzhead.time>>24&255),ct(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),ct(_,255&_.gzhead.os),_.gzhead.extra&&_.gzhead.extra.length&&(ct(_,255&_.gzhead.extra.length),ct(_,_.gzhead.extra.length>>8&255)),_.gzhead.hcrc&&(f.adler=c(f.adler,_.pending_buf,_.pending,0)),_.gzindex=0,_.status=69):(ct(_,0),ct(_,0),ct(_,0),ct(_,0),ct(_,0),ct(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),ct(_,3),_.status=D);else{var K=w+(_.w_bits-8<<4)<<8;K|=(2<=_.strategy||_.level<2?0:_.level<6?1:_.level===6?2:3)<<6,_.strstart!==0&&(K|=32),K+=31-K%31,_.status=D,rt(_,K),_.strstart!==0&&(rt(_,f.adler>>>16),rt(_,65535&f.adler)),f.adler=1}if(_.status===69)if(_.gzhead.extra){for(S=_.pending;_.gzindex<(65535&_.gzhead.extra.length)&&(_.pending!==_.pending_buf_size||(_.gzhead.hcrc&&_.pending>S&&(f.adler=c(f.adler,_.pending_buf,_.pending-S,S)),W(f),S=_.pending,_.pending!==_.pending_buf_size));)ct(_,255&_.gzhead.extra[_.gzindex]),_.gzindex++;_.gzhead.hcrc&&_.pending>S&&(f.adler=c(f.adler,_.pending_buf,_.pending-S,S)),_.gzindex===_.gzhead.extra.length&&(_.gzindex=0,_.status=73)}else _.status=73;if(_.status===73)if(_.gzhead.name){S=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>S&&(f.adler=c(f.adler,_.pending_buf,_.pending-S,S)),W(f),S=_.pending,_.pending===_.pending_buf_size)){B=1;break}B=_.gzindex<_.gzhead.name.length?255&_.gzhead.name.charCodeAt(_.gzindex++):0,ct(_,B)}while(B!==0);_.gzhead.hcrc&&_.pending>S&&(f.adler=c(f.adler,_.pending_buf,_.pending-S,S)),B===0&&(_.gzindex=0,_.status=91)}else _.status=91;if(_.status===91)if(_.gzhead.comment){S=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>S&&(f.adler=c(f.adler,_.pending_buf,_.pending-S,S)),W(f),S=_.pending,_.pending===_.pending_buf_size)){B=1;break}B=_.gzindex<_.gzhead.comment.length?255&_.gzhead.comment.charCodeAt(_.gzindex++):0,ct(_,B)}while(B!==0);_.gzhead.hcrc&&_.pending>S&&(f.adler=c(f.adler,_.pending_buf,_.pending-S,S)),B===0&&(_.status=103)}else _.status=103;if(_.status===103&&(_.gzhead.hcrc?(_.pending+2>_.pending_buf_size&&W(f),_.pending+2<=_.pending_buf_size&&(ct(_,255&f.adler),ct(_,f.adler>>8&255),f.adler=0,_.status=D)):_.status=D),_.pending!==0){if(W(f),f.avail_out===0)return _.last_flush=-1,u}else if(f.avail_in===0&&V(F)<=V(O)&&F!==g)return at(f,-5);if(_.status===666&&f.avail_in!==0)return at(f,-5);if(f.avail_in!==0||_.lookahead!==0||F!==p&&_.status!==666){var j=_.strategy===2?(function(H,G){for(var it;;){if(H.lookahead===0&&(J(H),H.lookahead===0)){if(G===p)return y;break}if(H.match_length=0,it=o._tr_tally(H,0,H.window[H.strstart]),H.lookahead--,H.strstart++,it&&(z(H,!1),H.strm.avail_out===0))return y}return H.insert=0,G===g?(z(H,!0),H.strm.avail_out===0?Q:U):H.last_lit&&(z(H,!1),H.strm.avail_out===0)?y:R})(_,F):_.strategy===3?(function(H,G){for(var it,tt,ut,xt,bt=H.window;;){if(H.lookahead<=N){if(J(H),H.lookahead<=N&&G===p)return y;if(H.lookahead===0)break}if(H.match_length=0,H.lookahead>=P&&0<H.strstart&&(tt=bt[ut=H.strstart-1])===bt[++ut]&&tt===bt[++ut]&&tt===bt[++ut]){xt=H.strstart+N;do;while(tt===bt[++ut]&&tt===bt[++ut]&&tt===bt[++ut]&&tt===bt[++ut]&&tt===bt[++ut]&&tt===bt[++ut]&&tt===bt[++ut]&&tt===bt[++ut]&&ut<xt);H.match_length=N-(xt-ut),H.match_length>H.lookahead&&(H.match_length=H.lookahead)}if(H.match_length>=P?(it=o._tr_tally(H,1,H.match_length-P),H.lookahead-=H.match_length,H.strstart+=H.match_length,H.match_length=0):(it=o._tr_tally(H,0,H.window[H.strstart]),H.lookahead--,H.strstart++),it&&(z(H,!1),H.strm.avail_out===0))return y}return H.insert=0,G===g?(z(H,!0),H.strm.avail_out===0?Q:U):H.last_lit&&(z(H,!1),H.strm.avail_out===0)?y:R})(_,F):r[_.level].func(_,F);if(j!==Q&&j!==U||(_.status=666),j===y||j===Q)return f.avail_out===0&&(_.last_flush=-1),u;if(j===R&&(F===1?o._tr_align(_):F!==5&&(o._tr_stored_block(_,0,0,!1),F===3&&(Y(_.head),_.lookahead===0&&(_.strstart=0,_.block_start=0,_.insert=0))),W(f),f.avail_out===0))return _.last_flush=-1,u}return F!==g?u:_.wrap<=0?1:(_.wrap===2?(ct(_,255&f.adler),ct(_,f.adler>>8&255),ct(_,f.adler>>16&255),ct(_,f.adler>>24&255),ct(_,255&f.total_in),ct(_,f.total_in>>8&255),ct(_,f.total_in>>16&255),ct(_,f.total_in>>24&255)):(rt(_,f.adler>>>16),rt(_,65535&f.adler)),W(f),0<_.wrap&&(_.wrap=-_.wrap),_.pending!==0?u:1)},n.deflateEnd=function(f){var F;return f&&f.state?(F=f.state.status)!==T&&F!==69&&F!==73&&F!==91&&F!==103&&F!==D&&F!==666?at(f,k):(f.state=null,F===D?at(f,-3):u):k},n.deflateSetDictionary=function(f,F){var O,_,S,B,K,j,H,G,it=F.length;if(!f||!f.state||(B=(O=f.state).wrap)===2||B===1&&O.status!==T||O.lookahead)return k;for(B===1&&(f.adler=a(f.adler,F,it,0)),O.wrap=0,it>=O.w_size&&(B===0&&(Y(O.head),O.strstart=0,O.block_start=0,O.insert=0),G=new l.Buf8(O.w_size),l.arraySet(G,F,it-O.w_size,O.w_size,0),F=G,it=O.w_size),K=f.avail_in,j=f.next_in,H=f.input,f.avail_in=it,f.next_in=0,f.input=F,J(O);O.lookahead>=P;){for(_=O.strstart,S=O.lookahead-(P-1);O.ins_h=(O.ins_h<<O.hash_shift^O.window[_+P-1])&O.hash_mask,O.prev[_&O.w_mask]=O.head[O.ins_h],O.head[O.ins_h]=_,_++,--S;);O.strstart=_,O.lookahead=P-1,J(O)}return O.strstart+=O.lookahead,O.block_start=O.strstart,O.insert=O.lookahead,O.lookahead=0,O.match_length=O.prev_length=P-1,O.match_available=0,f.next_in=j,f.input=H,f.avail_in=K,O.wrap=B,u},n.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(e,s,n){s.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(e,s,n){s.exports=function(r,l){var o,a,c,d,p,g,u,k,h,b,v,w,$,I,x,C,A,M,P,N,X,T,D,y,R;o=r.state,a=r.next_in,y=r.input,c=a+(r.avail_in-5),d=r.next_out,R=r.output,p=d-(l-r.avail_out),g=d+(r.avail_out-257),u=o.dmax,k=o.wsize,h=o.whave,b=o.wnext,v=o.window,w=o.hold,$=o.bits,I=o.lencode,x=o.distcode,C=(1<<o.lenbits)-1,A=(1<<o.distbits)-1;t:do{$<15&&(w+=y[a++]<<$,$+=8,w+=y[a++]<<$,$+=8),M=I[w&C];e:for(;;){if(w>>>=P=M>>>24,$-=P,(P=M>>>16&255)===0)R[d++]=65535&M;else{if(!(16&P)){if((64&P)==0){M=I[(65535&M)+(w&(1<<P)-1)];continue e}if(32&P){o.mode=12;break t}r.msg="invalid literal/length code",o.mode=30;break t}N=65535&M,(P&=15)&&($<P&&(w+=y[a++]<<$,$+=8),N+=w&(1<<P)-1,w>>>=P,$-=P),$<15&&(w+=y[a++]<<$,$+=8,w+=y[a++]<<$,$+=8),M=x[w&A];i:for(;;){if(w>>>=P=M>>>24,$-=P,!(16&(P=M>>>16&255))){if((64&P)==0){M=x[(65535&M)+(w&(1<<P)-1)];continue i}r.msg="invalid distance code",o.mode=30;break t}if(X=65535&M,$<(P&=15)&&(w+=y[a++]<<$,($+=8)<P&&(w+=y[a++]<<$,$+=8)),u<(X+=w&(1<<P)-1)){r.msg="invalid distance too far back",o.mode=30;break t}if(w>>>=P,$-=P,(P=d-p)<X){if(h<(P=X-P)&&o.sane){r.msg="invalid distance too far back",o.mode=30;break t}if(D=v,(T=0)===b){if(T+=k-P,P<N){for(N-=P;R[d++]=v[T++],--P;);T=d-X,D=R}}else if(b<P){if(T+=k+b-P,(P-=b)<N){for(N-=P;R[d++]=v[T++],--P;);if(T=0,b<N){for(N-=P=b;R[d++]=v[T++],--P;);T=d-X,D=R}}}else if(T+=b-P,P<N){for(N-=P;R[d++]=v[T++],--P;);T=d-X,D=R}for(;2<N;)R[d++]=D[T++],R[d++]=D[T++],R[d++]=D[T++],N-=3;N&&(R[d++]=D[T++],1<N&&(R[d++]=D[T++]))}else{for(T=d-X;R[d++]=R[T++],R[d++]=R[T++],R[d++]=R[T++],2<(N-=3););N&&(R[d++]=R[T++],1<N&&(R[d++]=R[T++]))}break}}break}}while(a<c&&d<g);a-=N=$>>3,w&=(1<<($-=N<<3))-1,r.next_in=a,r.next_out=d,r.avail_in=a<c?c-a+5:5-(a-c),r.avail_out=d<g?g-d+257:257-(d-g),o.hold=w,o.bits=$}},{}],49:[function(e,s,n){var r=e("../utils/common"),l=e("./adler32"),o=e("./crc32"),a=e("./inffast"),c=e("./inftrees"),d=1,p=2,g=0,u=-2,k=1,h=852,b=592;function v(T){return(T>>>24&255)+(T>>>8&65280)+((65280&T)<<8)+((255&T)<<24)}function w(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new r.Buf16(320),this.work=new r.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function $(T){var D;return T&&T.state?(D=T.state,T.total_in=T.total_out=D.total=0,T.msg="",D.wrap&&(T.adler=1&D.wrap),D.mode=k,D.last=0,D.havedict=0,D.dmax=32768,D.head=null,D.hold=0,D.bits=0,D.lencode=D.lendyn=new r.Buf32(h),D.distcode=D.distdyn=new r.Buf32(b),D.sane=1,D.back=-1,g):u}function I(T){var D;return T&&T.state?((D=T.state).wsize=0,D.whave=0,D.wnext=0,$(T)):u}function x(T,D){var y,R;return T&&T.state?(R=T.state,D<0?(y=0,D=-D):(y=1+(D>>4),D<48&&(D&=15)),D&&(D<8||15<D)?u:(R.window!==null&&R.wbits!==D&&(R.window=null),R.wrap=y,R.wbits=D,I(T))):u}function C(T,D){var y,R;return T?(R=new w,(T.state=R).window=null,(y=x(T,D))!==g&&(T.state=null),y):u}var A,M,P=!0;function N(T){if(P){var D;for(A=new r.Buf32(512),M=new r.Buf32(32),D=0;D<144;)T.lens[D++]=8;for(;D<256;)T.lens[D++]=9;for(;D<280;)T.lens[D++]=7;for(;D<288;)T.lens[D++]=8;for(c(d,T.lens,0,288,A,0,T.work,{bits:9}),D=0;D<32;)T.lens[D++]=5;c(p,T.lens,0,32,M,0,T.work,{bits:5}),P=!1}T.lencode=A,T.lenbits=9,T.distcode=M,T.distbits=5}function X(T,D,y,R){var Q,U=T.state;return U.window===null&&(U.wsize=1<<U.wbits,U.wnext=0,U.whave=0,U.window=new r.Buf8(U.wsize)),R>=U.wsize?(r.arraySet(U.window,D,y-U.wsize,U.wsize,0),U.wnext=0,U.whave=U.wsize):(R<(Q=U.wsize-U.wnext)&&(Q=R),r.arraySet(U.window,D,y-R,Q,U.wnext),(R-=Q)?(r.arraySet(U.window,D,y-R,R,0),U.wnext=R,U.whave=U.wsize):(U.wnext+=Q,U.wnext===U.wsize&&(U.wnext=0),U.whave<U.wsize&&(U.whave+=Q))),0}n.inflateReset=I,n.inflateReset2=x,n.inflateResetKeep=$,n.inflateInit=function(T){return C(T,15)},n.inflateInit2=C,n.inflate=function(T,D){var y,R,Q,U,at,V,Y,W,z,ct,rt,st,J,gt,mt,Z,ot,dt,E,L,f,F,O,_,S=0,B=new r.Buf8(4),K=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!T||!T.state||!T.output||!T.input&&T.avail_in!==0)return u;(y=T.state).mode===12&&(y.mode=13),at=T.next_out,Q=T.output,Y=T.avail_out,U=T.next_in,R=T.input,V=T.avail_in,W=y.hold,z=y.bits,ct=V,rt=Y,F=g;t:for(;;)switch(y.mode){case k:if(y.wrap===0){y.mode=13;break}for(;z<16;){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}if(2&y.wrap&&W===35615){B[y.check=0]=255&W,B[1]=W>>>8&255,y.check=o(y.check,B,2,0),z=W=0,y.mode=2;break}if(y.flags=0,y.head&&(y.head.done=!1),!(1&y.wrap)||(((255&W)<<8)+(W>>8))%31){T.msg="incorrect header check",y.mode=30;break}if((15&W)!=8){T.msg="unknown compression method",y.mode=30;break}if(z-=4,f=8+(15&(W>>>=4)),y.wbits===0)y.wbits=f;else if(f>y.wbits){T.msg="invalid window size",y.mode=30;break}y.dmax=1<<f,T.adler=y.check=1,y.mode=512&W?10:12,z=W=0;break;case 2:for(;z<16;){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}if(y.flags=W,(255&y.flags)!=8){T.msg="unknown compression method",y.mode=30;break}if(57344&y.flags){T.msg="unknown header flags set",y.mode=30;break}y.head&&(y.head.text=W>>8&1),512&y.flags&&(B[0]=255&W,B[1]=W>>>8&255,y.check=o(y.check,B,2,0)),z=W=0,y.mode=3;case 3:for(;z<32;){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}y.head&&(y.head.time=W),512&y.flags&&(B[0]=255&W,B[1]=W>>>8&255,B[2]=W>>>16&255,B[3]=W>>>24&255,y.check=o(y.check,B,4,0)),z=W=0,y.mode=4;case 4:for(;z<16;){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}y.head&&(y.head.xflags=255&W,y.head.os=W>>8),512&y.flags&&(B[0]=255&W,B[1]=W>>>8&255,y.check=o(y.check,B,2,0)),z=W=0,y.mode=5;case 5:if(1024&y.flags){for(;z<16;){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}y.length=W,y.head&&(y.head.extra_len=W),512&y.flags&&(B[0]=255&W,B[1]=W>>>8&255,y.check=o(y.check,B,2,0)),z=W=0}else y.head&&(y.head.extra=null);y.mode=6;case 6:if(1024&y.flags&&(V<(st=y.length)&&(st=V),st&&(y.head&&(f=y.head.extra_len-y.length,y.head.extra||(y.head.extra=new Array(y.head.extra_len)),r.arraySet(y.head.extra,R,U,st,f)),512&y.flags&&(y.check=o(y.check,R,st,U)),V-=st,U+=st,y.length-=st),y.length))break t;y.length=0,y.mode=7;case 7:if(2048&y.flags){if(V===0)break t;for(st=0;f=R[U+st++],y.head&&f&&y.length<65536&&(y.head.name+=String.fromCharCode(f)),f&&st<V;);if(512&y.flags&&(y.check=o(y.check,R,st,U)),V-=st,U+=st,f)break t}else y.head&&(y.head.name=null);y.length=0,y.mode=8;case 8:if(4096&y.flags){if(V===0)break t;for(st=0;f=R[U+st++],y.head&&f&&y.length<65536&&(y.head.comment+=String.fromCharCode(f)),f&&st<V;);if(512&y.flags&&(y.check=o(y.check,R,st,U)),V-=st,U+=st,f)break t}else y.head&&(y.head.comment=null);y.mode=9;case 9:if(512&y.flags){for(;z<16;){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}if(W!==(65535&y.check)){T.msg="header crc mismatch",y.mode=30;break}z=W=0}y.head&&(y.head.hcrc=y.flags>>9&1,y.head.done=!0),T.adler=y.check=0,y.mode=12;break;case 10:for(;z<32;){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}T.adler=y.check=v(W),z=W=0,y.mode=11;case 11:if(y.havedict===0)return T.next_out=at,T.avail_out=Y,T.next_in=U,T.avail_in=V,y.hold=W,y.bits=z,2;T.adler=y.check=1,y.mode=12;case 12:if(D===5||D===6)break t;case 13:if(y.last){W>>>=7&z,z-=7&z,y.mode=27;break}for(;z<3;){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}switch(y.last=1&W,z-=1,3&(W>>>=1)){case 0:y.mode=14;break;case 1:if(N(y),y.mode=20,D!==6)break;W>>>=2,z-=2;break t;case 2:y.mode=17;break;case 3:T.msg="invalid block type",y.mode=30}W>>>=2,z-=2;break;case 14:for(W>>>=7&z,z-=7&z;z<32;){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}if((65535&W)!=(W>>>16^65535)){T.msg="invalid stored block lengths",y.mode=30;break}if(y.length=65535&W,z=W=0,y.mode=15,D===6)break t;case 15:y.mode=16;case 16:if(st=y.length){if(V<st&&(st=V),Y<st&&(st=Y),st===0)break t;r.arraySet(Q,R,U,st,at),V-=st,U+=st,Y-=st,at+=st,y.length-=st;break}y.mode=12;break;case 17:for(;z<14;){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}if(y.nlen=257+(31&W),W>>>=5,z-=5,y.ndist=1+(31&W),W>>>=5,z-=5,y.ncode=4+(15&W),W>>>=4,z-=4,286<y.nlen||30<y.ndist){T.msg="too many length or distance symbols",y.mode=30;break}y.have=0,y.mode=18;case 18:for(;y.have<y.ncode;){for(;z<3;){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}y.lens[K[y.have++]]=7&W,W>>>=3,z-=3}for(;y.have<19;)y.lens[K[y.have++]]=0;if(y.lencode=y.lendyn,y.lenbits=7,O={bits:y.lenbits},F=c(0,y.lens,0,19,y.lencode,0,y.work,O),y.lenbits=O.bits,F){T.msg="invalid code lengths set",y.mode=30;break}y.have=0,y.mode=19;case 19:for(;y.have<y.nlen+y.ndist;){for(;Z=(S=y.lencode[W&(1<<y.lenbits)-1])>>>16&255,ot=65535&S,!((mt=S>>>24)<=z);){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}if(ot<16)W>>>=mt,z-=mt,y.lens[y.have++]=ot;else{if(ot===16){for(_=mt+2;z<_;){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}if(W>>>=mt,z-=mt,y.have===0){T.msg="invalid bit length repeat",y.mode=30;break}f=y.lens[y.have-1],st=3+(3&W),W>>>=2,z-=2}else if(ot===17){for(_=mt+3;z<_;){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}z-=mt,f=0,st=3+(7&(W>>>=mt)),W>>>=3,z-=3}else{for(_=mt+7;z<_;){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}z-=mt,f=0,st=11+(127&(W>>>=mt)),W>>>=7,z-=7}if(y.have+st>y.nlen+y.ndist){T.msg="invalid bit length repeat",y.mode=30;break}for(;st--;)y.lens[y.have++]=f}}if(y.mode===30)break;if(y.lens[256]===0){T.msg="invalid code -- missing end-of-block",y.mode=30;break}if(y.lenbits=9,O={bits:y.lenbits},F=c(d,y.lens,0,y.nlen,y.lencode,0,y.work,O),y.lenbits=O.bits,F){T.msg="invalid literal/lengths set",y.mode=30;break}if(y.distbits=6,y.distcode=y.distdyn,O={bits:y.distbits},F=c(p,y.lens,y.nlen,y.ndist,y.distcode,0,y.work,O),y.distbits=O.bits,F){T.msg="invalid distances set",y.mode=30;break}if(y.mode=20,D===6)break t;case 20:y.mode=21;case 21:if(6<=V&&258<=Y){T.next_out=at,T.avail_out=Y,T.next_in=U,T.avail_in=V,y.hold=W,y.bits=z,a(T,rt),at=T.next_out,Q=T.output,Y=T.avail_out,U=T.next_in,R=T.input,V=T.avail_in,W=y.hold,z=y.bits,y.mode===12&&(y.back=-1);break}for(y.back=0;Z=(S=y.lencode[W&(1<<y.lenbits)-1])>>>16&255,ot=65535&S,!((mt=S>>>24)<=z);){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}if(Z&&(240&Z)==0){for(dt=mt,E=Z,L=ot;Z=(S=y.lencode[L+((W&(1<<dt+E)-1)>>dt)])>>>16&255,ot=65535&S,!(dt+(mt=S>>>24)<=z);){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}W>>>=dt,z-=dt,y.back+=dt}if(W>>>=mt,z-=mt,y.back+=mt,y.length=ot,Z===0){y.mode=26;break}if(32&Z){y.back=-1,y.mode=12;break}if(64&Z){T.msg="invalid literal/length code",y.mode=30;break}y.extra=15&Z,y.mode=22;case 22:if(y.extra){for(_=y.extra;z<_;){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}y.length+=W&(1<<y.extra)-1,W>>>=y.extra,z-=y.extra,y.back+=y.extra}y.was=y.length,y.mode=23;case 23:for(;Z=(S=y.distcode[W&(1<<y.distbits)-1])>>>16&255,ot=65535&S,!((mt=S>>>24)<=z);){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}if((240&Z)==0){for(dt=mt,E=Z,L=ot;Z=(S=y.distcode[L+((W&(1<<dt+E)-1)>>dt)])>>>16&255,ot=65535&S,!(dt+(mt=S>>>24)<=z);){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}W>>>=dt,z-=dt,y.back+=dt}if(W>>>=mt,z-=mt,y.back+=mt,64&Z){T.msg="invalid distance code",y.mode=30;break}y.offset=ot,y.extra=15&Z,y.mode=24;case 24:if(y.extra){for(_=y.extra;z<_;){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}y.offset+=W&(1<<y.extra)-1,W>>>=y.extra,z-=y.extra,y.back+=y.extra}if(y.offset>y.dmax){T.msg="invalid distance too far back",y.mode=30;break}y.mode=25;case 25:if(Y===0)break t;if(st=rt-Y,y.offset>st){if((st=y.offset-st)>y.whave&&y.sane){T.msg="invalid distance too far back",y.mode=30;break}J=st>y.wnext?(st-=y.wnext,y.wsize-st):y.wnext-st,st>y.length&&(st=y.length),gt=y.window}else gt=Q,J=at-y.offset,st=y.length;for(Y<st&&(st=Y),Y-=st,y.length-=st;Q[at++]=gt[J++],--st;);y.length===0&&(y.mode=21);break;case 26:if(Y===0)break t;Q[at++]=y.length,Y--,y.mode=21;break;case 27:if(y.wrap){for(;z<32;){if(V===0)break t;V--,W|=R[U++]<<z,z+=8}if(rt-=Y,T.total_out+=rt,y.total+=rt,rt&&(T.adler=y.check=y.flags?o(y.check,Q,rt,at-rt):l(y.check,Q,rt,at-rt)),rt=Y,(y.flags?W:v(W))!==y.check){T.msg="incorrect data check",y.mode=30;break}z=W=0}y.mode=28;case 28:if(y.wrap&&y.flags){for(;z<32;){if(V===0)break t;V--,W+=R[U++]<<z,z+=8}if(W!==(4294967295&y.total)){T.msg="incorrect length check",y.mode=30;break}z=W=0}y.mode=29;case 29:F=1;break t;case 30:F=-3;break t;case 31:return-4;case 32:default:return u}return T.next_out=at,T.avail_out=Y,T.next_in=U,T.avail_in=V,y.hold=W,y.bits=z,(y.wsize||rt!==T.avail_out&&y.mode<30&&(y.mode<27||D!==4))&&X(T,T.output,T.next_out,rt-T.avail_out)?(y.mode=31,-4):(ct-=T.avail_in,rt-=T.avail_out,T.total_in+=ct,T.total_out+=rt,y.total+=rt,y.wrap&&rt&&(T.adler=y.check=y.flags?o(y.check,Q,rt,T.next_out-rt):l(y.check,Q,rt,T.next_out-rt)),T.data_type=y.bits+(y.last?64:0)+(y.mode===12?128:0)+(y.mode===20||y.mode===15?256:0),(ct==0&&rt===0||D===4)&&F===g&&(F=-5),F)},n.inflateEnd=function(T){if(!T||!T.state)return u;var D=T.state;return D.window&&(D.window=null),T.state=null,g},n.inflateGetHeader=function(T,D){var y;return T&&T.state?(2&(y=T.state).wrap)==0?u:((y.head=D).done=!1,g):u},n.inflateSetDictionary=function(T,D){var y,R=D.length;return T&&T.state?(y=T.state).wrap!==0&&y.mode!==11?u:y.mode===11&&l(1,D,R,0)!==y.check?-3:X(T,D,R,R)?(y.mode=31,-4):(y.havedict=1,g):u},n.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(e,s,n){var r=e("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],o=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];s.exports=function(d,p,g,u,k,h,b,v){var w,$,I,x,C,A,M,P,N,X=v.bits,T=0,D=0,y=0,R=0,Q=0,U=0,at=0,V=0,Y=0,W=0,z=null,ct=0,rt=new r.Buf16(16),st=new r.Buf16(16),J=null,gt=0;for(T=0;T<=15;T++)rt[T]=0;for(D=0;D<u;D++)rt[p[g+D]]++;for(Q=X,R=15;1<=R&&rt[R]===0;R--);if(R<Q&&(Q=R),R===0)return k[h++]=20971520,k[h++]=20971520,v.bits=1,0;for(y=1;y<R&&rt[y]===0;y++);for(Q<y&&(Q=y),T=V=1;T<=15;T++)if(V<<=1,(V-=rt[T])<0)return-1;if(0<V&&(d===0||R!==1))return-1;for(st[1]=0,T=1;T<15;T++)st[T+1]=st[T]+rt[T];for(D=0;D<u;D++)p[g+D]!==0&&(b[st[p[g+D]]++]=D);if(A=d===0?(z=J=b,19):d===1?(z=l,ct-=257,J=o,gt-=257,256):(z=a,J=c,-1),T=y,C=h,at=D=W=0,I=-1,x=(Y=1<<(U=Q))-1,d===1&&852<Y||d===2&&592<Y)return 1;for(;;){for(M=T-at,N=b[D]<A?(P=0,b[D]):b[D]>A?(P=J[gt+b[D]],z[ct+b[D]]):(P=96,0),w=1<<T-at,y=$=1<<U;k[C+(W>>at)+($-=w)]=M<<24|P<<16|N|0,$!==0;);for(w=1<<T-1;W&w;)w>>=1;if(w!==0?(W&=w-1,W+=w):W=0,D++,--rt[T]==0){if(T===R)break;T=p[g+b[D]]}if(Q<T&&(W&x)!==I){for(at===0&&(at=Q),C+=y,V=1<<(U=T-at);U+at<R&&!((V-=rt[U+at])<=0);)U++,V<<=1;if(Y+=1<<U,d===1&&852<Y||d===2&&592<Y)return 1;k[I=W&x]=Q<<24|U<<16|C-h|0}}return W!==0&&(k[C+W]=T-at<<24|64<<16|0),v.bits=Q,0}},{"../utils/common":41}],51:[function(e,s,n){s.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(e,s,n){var r=e("../utils/common"),l=0,o=1;function a(S){for(var B=S.length;0<=--B;)S[B]=0}var c=0,d=29,p=256,g=p+1+d,u=30,k=19,h=2*g+1,b=15,v=16,w=7,$=256,I=16,x=17,C=18,A=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],M=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],P=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],N=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],X=new Array(2*(g+2));a(X);var T=new Array(2*u);a(T);var D=new Array(512);a(D);var y=new Array(256);a(y);var R=new Array(d);a(R);var Q,U,at,V=new Array(u);function Y(S,B,K,j,H){this.static_tree=S,this.extra_bits=B,this.extra_base=K,this.elems=j,this.max_length=H,this.has_stree=S&&S.length}function W(S,B){this.dyn_tree=S,this.max_code=0,this.stat_desc=B}function z(S){return S<256?D[S]:D[256+(S>>>7)]}function ct(S,B){S.pending_buf[S.pending++]=255&B,S.pending_buf[S.pending++]=B>>>8&255}function rt(S,B,K){S.bi_valid>v-K?(S.bi_buf|=B<<S.bi_valid&65535,ct(S,S.bi_buf),S.bi_buf=B>>v-S.bi_valid,S.bi_valid+=K-v):(S.bi_buf|=B<<S.bi_valid&65535,S.bi_valid+=K)}function st(S,B,K){rt(S,K[2*B],K[2*B+1])}function J(S,B){for(var K=0;K|=1&S,S>>>=1,K<<=1,0<--B;);return K>>>1}function gt(S,B,K){var j,H,G=new Array(b+1),it=0;for(j=1;j<=b;j++)G[j]=it=it+K[j-1]<<1;for(H=0;H<=B;H++){var tt=S[2*H+1];tt!==0&&(S[2*H]=J(G[tt]++,tt))}}function mt(S){var B;for(B=0;B<g;B++)S.dyn_ltree[2*B]=0;for(B=0;B<u;B++)S.dyn_dtree[2*B]=0;for(B=0;B<k;B++)S.bl_tree[2*B]=0;S.dyn_ltree[2*$]=1,S.opt_len=S.static_len=0,S.last_lit=S.matches=0}function Z(S){8<S.bi_valid?ct(S,S.bi_buf):0<S.bi_valid&&(S.pending_buf[S.pending++]=S.bi_buf),S.bi_buf=0,S.bi_valid=0}function ot(S,B,K,j){var H=2*B,G=2*K;return S[H]<S[G]||S[H]===S[G]&&j[B]<=j[K]}function dt(S,B,K){for(var j=S.heap[K],H=K<<1;H<=S.heap_len&&(H<S.heap_len&&ot(B,S.heap[H+1],S.heap[H],S.depth)&&H++,!ot(B,j,S.heap[H],S.depth));)S.heap[K]=S.heap[H],K=H,H<<=1;S.heap[K]=j}function E(S,B,K){var j,H,G,it,tt=0;if(S.last_lit!==0)for(;j=S.pending_buf[S.d_buf+2*tt]<<8|S.pending_buf[S.d_buf+2*tt+1],H=S.pending_buf[S.l_buf+tt],tt++,j===0?st(S,H,B):(st(S,(G=y[H])+p+1,B),(it=A[G])!==0&&rt(S,H-=R[G],it),st(S,G=z(--j),K),(it=M[G])!==0&&rt(S,j-=V[G],it)),tt<S.last_lit;);st(S,$,B)}function L(S,B){var K,j,H,G=B.dyn_tree,it=B.stat_desc.static_tree,tt=B.stat_desc.has_stree,ut=B.stat_desc.elems,xt=-1;for(S.heap_len=0,S.heap_max=h,K=0;K<ut;K++)G[2*K]!==0?(S.heap[++S.heap_len]=xt=K,S.depth[K]=0):G[2*K+1]=0;for(;S.heap_len<2;)G[2*(H=S.heap[++S.heap_len]=xt<2?++xt:0)]=1,S.depth[H]=0,S.opt_len--,tt&&(S.static_len-=it[2*H+1]);for(B.max_code=xt,K=S.heap_len>>1;1<=K;K--)dt(S,G,K);for(H=ut;K=S.heap[1],S.heap[1]=S.heap[S.heap_len--],dt(S,G,1),j=S.heap[1],S.heap[--S.heap_max]=K,S.heap[--S.heap_max]=j,G[2*H]=G[2*K]+G[2*j],S.depth[H]=(S.depth[K]>=S.depth[j]?S.depth[K]:S.depth[j])+1,G[2*K+1]=G[2*j+1]=H,S.heap[1]=H++,dt(S,G,1),2<=S.heap_len;);S.heap[--S.heap_max]=S.heap[1],(function(bt,Mt){var Vt,Yt,ee,Nt,Ke,te,Jt=Mt.dyn_tree,mi=Mt.max_code,Bi=Mt.stat_desc.static_tree,gs=Mt.stat_desc.has_stree,vs=Mt.stat_desc.extra_bits,Tn=Mt.stat_desc.extra_base,gi=Mt.stat_desc.max_length,Di=0;for(Nt=0;Nt<=b;Nt++)bt.bl_count[Nt]=0;for(Jt[2*bt.heap[bt.heap_max]+1]=0,Vt=bt.heap_max+1;Vt<h;Vt++)gi<(Nt=Jt[2*Jt[2*(Yt=bt.heap[Vt])+1]+1]+1)&&(Nt=gi,Di++),Jt[2*Yt+1]=Nt,mi<Yt||(bt.bl_count[Nt]++,Ke=0,Tn<=Yt&&(Ke=vs[Yt-Tn]),te=Jt[2*Yt],bt.opt_len+=te*(Nt+Ke),gs&&(bt.static_len+=te*(Bi[2*Yt+1]+Ke)));if(Di!==0){do{for(Nt=gi-1;bt.bl_count[Nt]===0;)Nt--;bt.bl_count[Nt]--,bt.bl_count[Nt+1]+=2,bt.bl_count[gi]--,Di-=2}while(0<Di);for(Nt=gi;Nt!==0;Nt--)for(Yt=bt.bl_count[Nt];Yt!==0;)mi<(ee=bt.heap[--Vt])||(Jt[2*ee+1]!==Nt&&(bt.opt_len+=(Nt-Jt[2*ee+1])*Jt[2*ee],Jt[2*ee+1]=Nt),Yt--)}})(S,B),gt(G,xt,S.bl_count)}function f(S,B,K){var j,H,G=-1,it=B[1],tt=0,ut=7,xt=4;for(it===0&&(ut=138,xt=3),B[2*(K+1)+1]=65535,j=0;j<=K;j++)H=it,it=B[2*(j+1)+1],++tt<ut&&H===it||(tt<xt?S.bl_tree[2*H]+=tt:H!==0?(H!==G&&S.bl_tree[2*H]++,S.bl_tree[2*I]++):tt<=10?S.bl_tree[2*x]++:S.bl_tree[2*C]++,G=H,xt=(tt=0)===it?(ut=138,3):H===it?(ut=6,3):(ut=7,4))}function F(S,B,K){var j,H,G=-1,it=B[1],tt=0,ut=7,xt=4;for(it===0&&(ut=138,xt=3),j=0;j<=K;j++)if(H=it,it=B[2*(j+1)+1],!(++tt<ut&&H===it)){if(tt<xt)for(;st(S,H,S.bl_tree),--tt!=0;);else H!==0?(H!==G&&(st(S,H,S.bl_tree),tt--),st(S,I,S.bl_tree),rt(S,tt-3,2)):tt<=10?(st(S,x,S.bl_tree),rt(S,tt-3,3)):(st(S,C,S.bl_tree),rt(S,tt-11,7));G=H,xt=(tt=0)===it?(ut=138,3):H===it?(ut=6,3):(ut=7,4)}}a(V);var O=!1;function _(S,B,K,j){rt(S,(c<<1)+(j?1:0),3),(function(H,G,it,tt){Z(H),ct(H,it),ct(H,~it),r.arraySet(H.pending_buf,H.window,G,it,H.pending),H.pending+=it})(S,B,K)}n._tr_init=function(S){O||((function(){var B,K,j,H,G,it=new Array(b+1);for(H=j=0;H<d-1;H++)for(R[H]=j,B=0;B<1<<A[H];B++)y[j++]=H;for(y[j-1]=H,H=G=0;H<16;H++)for(V[H]=G,B=0;B<1<<M[H];B++)D[G++]=H;for(G>>=7;H<u;H++)for(V[H]=G<<7,B=0;B<1<<M[H]-7;B++)D[256+G++]=H;for(K=0;K<=b;K++)it[K]=0;for(B=0;B<=143;)X[2*B+1]=8,B++,it[8]++;for(;B<=255;)X[2*B+1]=9,B++,it[9]++;for(;B<=279;)X[2*B+1]=7,B++,it[7]++;for(;B<=287;)X[2*B+1]=8,B++,it[8]++;for(gt(X,g+1,it),B=0;B<u;B++)T[2*B+1]=5,T[2*B]=J(B,5);Q=new Y(X,A,p+1,g,b),U=new Y(T,M,0,u,b),at=new Y(new Array(0),P,0,k,w)})(),O=!0),S.l_desc=new W(S.dyn_ltree,Q),S.d_desc=new W(S.dyn_dtree,U),S.bl_desc=new W(S.bl_tree,at),S.bi_buf=0,S.bi_valid=0,mt(S)},n._tr_stored_block=_,n._tr_flush_block=function(S,B,K,j){var H,G,it=0;0<S.level?(S.strm.data_type===2&&(S.strm.data_type=(function(tt){var ut,xt=4093624447;for(ut=0;ut<=31;ut++,xt>>>=1)if(1&xt&&tt.dyn_ltree[2*ut]!==0)return l;if(tt.dyn_ltree[18]!==0||tt.dyn_ltree[20]!==0||tt.dyn_ltree[26]!==0)return o;for(ut=32;ut<p;ut++)if(tt.dyn_ltree[2*ut]!==0)return o;return l})(S)),L(S,S.l_desc),L(S,S.d_desc),it=(function(tt){var ut;for(f(tt,tt.dyn_ltree,tt.l_desc.max_code),f(tt,tt.dyn_dtree,tt.d_desc.max_code),L(tt,tt.bl_desc),ut=k-1;3<=ut&&tt.bl_tree[2*N[ut]+1]===0;ut--);return tt.opt_len+=3*(ut+1)+5+5+4,ut})(S),H=S.opt_len+3+7>>>3,(G=S.static_len+3+7>>>3)<=H&&(H=G)):H=G=K+5,K+4<=H&&B!==-1?_(S,B,K,j):S.strategy===4||G===H?(rt(S,2+(j?1:0),3),E(S,X,T)):(rt(S,4+(j?1:0),3),(function(tt,ut,xt,bt){var Mt;for(rt(tt,ut-257,5),rt(tt,xt-1,5),rt(tt,bt-4,4),Mt=0;Mt<bt;Mt++)rt(tt,tt.bl_tree[2*N[Mt]+1],3);F(tt,tt.dyn_ltree,ut-1),F(tt,tt.dyn_dtree,xt-1)})(S,S.l_desc.max_code+1,S.d_desc.max_code+1,it+1),E(S,S.dyn_ltree,S.dyn_dtree)),mt(S),j&&Z(S)},n._tr_tally=function(S,B,K){return S.pending_buf[S.d_buf+2*S.last_lit]=B>>>8&255,S.pending_buf[S.d_buf+2*S.last_lit+1]=255&B,S.pending_buf[S.l_buf+S.last_lit]=255&K,S.last_lit++,B===0?S.dyn_ltree[2*K]++:(S.matches++,B--,S.dyn_ltree[2*(y[K]+p+1)]++,S.dyn_dtree[2*z(B)]++),S.last_lit===S.lit_bufsize-1},n._tr_align=function(S){rt(S,2,3),st(S,$,X),(function(B){B.bi_valid===16?(ct(B,B.bi_buf),B.bi_buf=0,B.bi_valid=0):8<=B.bi_valid&&(B.pending_buf[B.pending++]=255&B.bi_buf,B.bi_buf>>=8,B.bi_valid-=8)})(S)}},{"../utils/common":41}],53:[function(e,s,n){s.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(e,s,n){(function(r){(function(l,o){if(!l.setImmediate){var a,c,d,p,g=1,u={},k=!1,h=l.document,b=Object.getPrototypeOf&&Object.getPrototypeOf(l);b=b&&b.setTimeout?b:l,a={}.toString.call(l.process)==="[object process]"?function(I){process.nextTick(function(){w(I)})}:(function(){if(l.postMessage&&!l.importScripts){var I=!0,x=l.onmessage;return l.onmessage=function(){I=!1},l.postMessage("","*"),l.onmessage=x,I}})()?(p="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",$,!1):l.attachEvent("onmessage",$),function(I){l.postMessage(p+I,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(I){w(I.data)},function(I){d.port2.postMessage(I)}):h&&"onreadystatechange"in h.createElement("script")?(c=h.documentElement,function(I){var x=h.createElement("script");x.onreadystatechange=function(){w(I),x.onreadystatechange=null,c.removeChild(x),x=null},c.appendChild(x)}):function(I){setTimeout(w,0,I)},b.setImmediate=function(I){typeof I!="function"&&(I=new Function(""+I));for(var x=new Array(arguments.length-1),C=0;C<x.length;C++)x[C]=arguments[C+1];var A={callback:I,args:x};return u[g]=A,a(g),g++},b.clearImmediate=v}function v(I){delete u[I]}function w(I){if(k)setTimeout(w,0,I);else{var x=u[I];if(x){k=!0;try{(function(C){var A=C.callback,M=C.args;switch(M.length){case 0:A();break;case 1:A(M[0]);break;case 2:A(M[0],M[1]);break;case 3:A(M[0],M[1],M[2]);break;default:A.apply(o,M)}})(x)}finally{v(I),k=!1}}}}function $(I){I.source===l&&typeof I.data=="string"&&I.data.indexOf(p)===0&&w(+I.data.slice(p.length))}})(typeof self>"u"?r===void 0?this:r:self)}).call(this,typeof zn<"u"?zn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Bs)),Bs.exports}var Vg=Wg();const Kg=Ug(Vg),qg=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,Gg=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function Zg(t){const i=await Kg.loadAsync(t),e={},s=[];let n="",r="";const l=[];i.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let o=l.find(a=>a.path.toLowerCase()==="slides.md");o||(o=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),o||(o=l.find(a=>a.path.toLowerCase().endsWith(".md"))),o&&(n=await o.file.async("string"),r=o.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||Gg.test(c)||c.includes("snippets/")){const d=await a.file.async("string");e[c]=d;const p=c.split("/");p.length>1&&(e[p.slice(1).join("/")]=d)}else if(qg.test(c)){const d=await a.file.async("uint8array"),p=c.split("/").pop()||c,g=typeof Blob<"u"?new Blob([d]):void 0;s.push({zipPath:c,fileName:p,data:d,blob:g})}}return{entryMarkdown:n,entryMarkdownPath:r,virtualFiles:e,assets:s}}function Yg(t,i){if(Object.keys(i).length===0)return t;function e(n){const r=n.trim().replace(/^['"]|['"]$/g,""),l=r.split("/").pop()||r;if(i[r])return i[r];const o=r.replace(/^\.?\//,"");return i[o]?i[o]:i[l]?i[l]:null}function s(n){let r=n;return r=r.replace(/!\[(.*?)\]\((.*?)\)/g,(l,o,a)=>{const c=e(a);return c?`![${o}](${c})`:l}),r=r.replace(/\bsrc=["'](.*?)["']/gi,(l,o)=>{const a=e(o);return a?`src="${a}"`:l}),r}for(const n of t.slides)if(n.rawMarkdown=s(n.rawMarkdown),n.pageAttrs["custom-slidev-background"]){const r=n.pageAttrs["custom-slidev-background"],l=e(r);l&&(n.pageAttrs["custom-slidev-background"]=l)}if(t.flattenedMarkdown=s(t.flattenedMarkdown),t.docRootAttrs["custom-slidev-background"]){const n=t.docRootAttrs["custom-slidev-background"],r=e(n);r&&(t.docRootAttrs["custom-slidev-background"]=r)}return t}function Xl(t){try{if(typeof process<"u"&&typeof require<"u"){const i=require("fs");if(i.existsSync(t))return i.readFileSync(t,"utf-8")}}catch{}return null}function Jg(t,i){const e=t.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!e)return null;const s=e[1].trim(),n=s.indexOf("#"),r=n!==-1?s.slice(0,n):s,l=n!==-1?s.slice(n+1):"",o=r.replace(/^@\//,"").replace(/^\.\//,""),a=(i==null?void 0:i.virtualFiles)||{};let c=a[r]||a[o]||a[`./${o}`]||a[`@/${o}`];if(!c&&Object.keys(a).length>0){const u=o.split("/").pop();for(const[k,h]of Object.entries(a))if(k.endsWith(`/${o}`)||u&&k.endsWith(`/${u}`)){c=h;break}}if(!c){const u=[];if(i!=null&&i.baseDir)try{const k=require("path");u.push(k.resolve(i.baseDir,o)),u.push(k.resolve(i.baseDir,r))}catch{}try{const k=require("path");u.push(k.resolve(process.cwd(),o))}catch{}for(const k of u){const h=Xl(k);if(h!==null){c=h;break}}}if(!c){const u=Wl||{};if(c=u[r]||u[o]||u[`snippets/${o}`],!c){const k=o.split("/").pop();for(const[h,b]of Object.entries(u))if(h.endsWith(`/${o}`)||k&&h.endsWith(`/${k}`)){c=b;break}}}if(!c)return null;let d=c;if(l){const u=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),k=c.match(u);if(k){const h=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(h?h[1]:"")+k[1].trimEnd()}}const p=o.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${p?p[1]:""}
${d}
\`\`\``}function Xg(t){let i=!1,e=!1;for(let s=0;s<t.length;s++){const n=t[s];if(n==="'"&&!e)i=!i;else if(n==='"'&&!i)e=!e;else if(n==="#"&&!i&&!e)return t.slice(0,s).trim()}return t.trim()}function Wn(t){const i={},e=t.split(/\r?\n/);let s=0;for(;s<e.length;){const n=e[s],r=n.trim();if(!r||r.startsWith("#")){s++;continue}const l=n.indexOf(":");if(l>0){const o=n.slice(0,l).trim();let a=n.slice(l+1).trim();if(a==="|"||a===">"){s++;const c=[];let d=-1;for(;s<e.length;){const p=e[s];if(!p.trim()){c.push(""),s++;continue}const u=p.match(/^(\s+)/),k=u?u[1].length:0;if(d===-1&&(d=k),k<d)break;c.push(p.slice(d)),s++}for(;c.length>0&&c[c.length-1]==="";)c.pop();i[o]=a===">"?c.join(" "):c.join(`
`);continue}if(a=Xg(a),!a){let c=s+1;const d=[];let p=-1;for(;c<e.length;){const g=e[c],u=g.trim();if(!u||u.startsWith("#")){p!==-1&&d.push(""),c++;continue}const k=g.match(/^(\s+)/),h=k?k[1].length:0;if(p===-1)if(h>0)p=h;else break;if(h<p)break;d.push(g.slice(p)),c++}if(d.length>0){i[o]=Wn(d.join(`
`)),s=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),i[o]=a}s++}return i}const Qg=/^\s*```ya?ml([\s\S]*?)```/;function kr(t){let i={},e=t.trim();const s=e.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(s&&!s[1].includes("```")){const r=Wn(s[1]);if(Object.keys(r).length>0||!s[1].trim())return i=r,e=e.slice(s[0].length).trim(),{frontmatter:i,content:e}}if(e.startsWith("---")){const r=e.match(/^---[^\n\r]*(?:\r?\n|$)/);r&&(e=e.slice(r[0].length).trim())}const n=e.match(Qg);if(n)i=Wn(n[1]),e=e.slice(n[0].length).trim();else{const r=e.split(/\r?\n/),l=[];let o=0;for(let a=0;a<r.length;a++){const c=r[a].trim();if(!c){if(l.length>0){o=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{o=a;break}}l.length>0&&(i=Wn(l.join(`
`)),e=r.slice(o).join(`
`).trim())}return{frontmatter:i,content:e}}function tv(t){const i=t.split(/\r?\n/),e=[];let s=0,n=!1;function r(l){if(s>=l)return;const o=i.slice(s,l).join(`
`).trim();o&&e.push(o),s=l+1}for(let l=0;l<i.length;l++){const a=i[l].trimEnd();if(n){a.includes("-->")&&(n=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(n=!0);continue}if(a.startsWith("---")){r(l);const c=i[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(s=l,l+=1;l<i.length&&i[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let p=l+1;for(;p<i.length&&!i[p].trimStart().startsWith(d);p++);p<i.length&&(l=p)}}return s<i.length&&r(i.length),e}function Vn(t,i={}){const{stripNotesFromMarkdown:e=!0,cleanVClicks:s=!0,cleanShikiLines:n=!0,cleanSlots:r=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:o=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=i;let d=t;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const p=tv(d),g={};let u="",k="",h=0;if(p.length>0){const N=p[0],X=kr(N),T=Object.keys(X.frontmatter).length>0,D=X.content.length>0;T&&!D&&p.length>1?(h=1,b(X.frontmatter)):T&&b(X.frontmatter)}function b(N){u=N.title||"",N.theme&&(g[rn]=String(N.theme)),N.aspectRatio&&(g[ln]=String(N.aspectRatio)),N.highlighter&&(g[Cr]=String(N.highlighter)),N.transition&&(g[an]=String(N.transition)),N.colorSchema&&(g[$r]=String(N.colorSchema)),N.layout&&(g[ft]=String(N.layout)),N.background&&(g[Ut]=String(N.background)),N.image&&(g[Ae]=String(N.image)),N.class&&(g[Ni]=String(N.class));for(const[X,T]of Object.entries(N))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(X)||(g[`custom-slidev-${X}`]=typeof T=="object"?JSON.stringify(T):String(T))}const v=[];let w=0,$=0,I=0,x=0;const C=new Set,A={};let M=1;for(let N=h;N<p.length;N++){const X=p[N],{frontmatter:T,content:D}=kr(X),y=X.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),R=T.src||(y?y[1]:void 0);if(R){const Z=String(R).trim().replace(/^['"]|['"]$/g,"");let ot=c[Z]||c[Z.replace(/^\.\//,"")]||c[`pages/${Z.replace(/^.*pages\//,"")}`];if(!ot){const E=Z.replace(/^\.\//,""),L=[];if(i.baseDir)try{const f=require("path");L.push(f.resolve(i.baseDir,E)),L.push(f.resolve(i.baseDir,Z))}catch{}try{const f=require("path");L.push(f.resolve(process.cwd(),E)),L.push(f.resolve(process.cwd(),Z))}catch{}for(const f of L){const F=Xl(f);if(F!==null){ot=F;break}}}const dt={};T.layout&&(dt[ft]=String(T.layout)),T.transition&&(dt[Xt]=String(T.transition)),T.background&&(dt[Ut]=String(T.background)),T.image&&(dt[Ae]=String(T.image)),T.class&&(dt[Ni]=String(T.class));for(const[E,L]of Object.entries(T))["src","layout","transition","background","image","class"].includes(E)||(dt[`custom-slidev-${E}`]=typeof L=="object"?JSON.stringify(L):String(L));if(ot){const E=Vn(ot,{...i,virtualFiles:c});for(const L of E.slides){L.pageIndex=M++,L.pageAttrs={...dt,...L.pageAttrs},v.push(L);const f=L.pageAttrs[ft]||"default";A[f]=(A[f]||0)+1}continue}else{v.push({pageIndex:M++,pageAttrs:{...dt,"custom-slidev-src":Z},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${Z}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const E=dt[ft]||"default";A[E]=(A[E]||0)+1;continue}}const Q={};T.layout&&(Q[ft]=String(T.layout)),T.transition&&(Q[Xt]=String(T.transition)),T.background&&(Q[Ut]=String(T.background)),T.image&&(Q[Ae]=String(T.image)),T.class&&(Q[Ni]=String(T.class));for(const[Z,ot]of Object.entries(T))["layout","transition","background","image","class"].includes(Z)||(Q[`custom-slidev-${Z}`]=typeof ot=="object"?JSON.stringify(ot):String(ot));let U=D;const at=[];let V=U.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,Z=>{const ot=`__CODE_TOKEN_NOTE_${at.length}__`;return at.push(Z),ot});V=V.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,Z=>{const ot=`__CODE_TOKEN_NOTE_${at.length}__`;return at.push(Z),ot});let Y="";const W=Array.from(V.matchAll(/<!--([\s\S]*?)-->/g));if(W.length>0){const Z=W[W.length-1],ot=V.slice(Z.index+Z[0].length).trim();if(!ot||!ot.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const E=Z[1].trim();E.startsWith("TODO:")||(Y=E,w++),e&&(V=V.slice(0,Z.index).trimEnd()+V.slice(Z.index+Z[0].length))}}e&&(V=V.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let Z=0;Z<at.length;Z++)V=V.replace(`__CODE_TOKEN_NOTE_${Z}__`,at[Z]);if(U=V,Y){for(let dt=0;dt<at.length;dt++)Y=Y.replace(`__CODE_TOKEN_NOTE_${dt}__`,at[dt]);const ot=`> [!NOTE] 💡 演讲备注
${Y.split(/\r?\n/).map(dt=>`> ${dt}`).join(`
`)}
{: custom-slidev-note="true"}`;U=U?`${U}

${ot}`:ot}let z=!1;if(/<style\b/i.test(U)){z=!0;const Z=U.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(Z){for(const ot of Z){const dt=ot.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();k=k?`${k}

${dt}`:dt}l&&(U=U.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const ct=U.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);ct&&($+=ct.length);const rt=U.match(/```\w+\s+\{[^}]+\}/g);rt&&(I+=rt.length);const st=U.match(/::\w+::|<template\s+#[^>]+>/g);if(st&&(x+=st.length),U=U.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,Z=>Jg(Z,{...i,virtualFiles:c})||Z),s&&(U=U.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),n&&(U=U.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),U=U.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),r&&(U=U.replace(/^::\w+::\s*$/gm,"")),o&&(U=Na(U)),a){let Z=U.trim(),ot="";const dt=Z.lastIndexOf("> [!NOTE] 💡 演讲备注");if(dt!==-1&&(ot=Z.slice(dt),Z=Z.slice(0,dt).trim()),(T.layout==="image-left"||T.layout==="image-right")&&T.image){const E=String(T.image).trim(),L=T.layout==="image-left"?"image-left":"image-right",f=`![配图](${E})
{: custom-slidev-layout="${L}" }`;T.layout==="image-left"?Z=`{{{col

${f}

${Z}

}}}`:Z=`{{{col

${Z}

${f}

}}}`}if(T.background){const L=`![背景图](${String(T.background).trim()})
{: custom-slidev-role="background" }`;Z=Z?`${L}

${Z}`:L}U=ot?`${Z}

${ot}`:Z}const J=ev(U);Q[Ut]&&J.push(Q[Ut]),Q[Ae]&&J.push(Q[Ae]);for(const Z of J)C.add(Z);const gt=/<[A-Z][a-zA-Z0-9]+/.test(U),mt=Q[ft]||(M===1?g[ft]||"cover":"default");A[mt]=(A[mt]||0)+1,v.push({pageIndex:M++,pageAttrs:Q,notes:Y,rawMarkdown:U,hasVueComponent:gt,hasStyleTag:z,assetReferences:J})}if(!u&&v.length>0){const N=v[0].rawMarkdown.match(/^#\s+(.+)$/m);N&&(u=N[1].trim())}k&&(g["custom-slidev-custom-css"]=k);let P=v.map(N=>`---

${N.rawMarkdown}`).join(`

`);return P.trimStart().startsWith("---")||(P=`---

${P.trimStart()}`),{docTitle:u||"Slidev 演示文稿",docRootAttrs:g,slides:v,totalSlides:v.length,stats:{totalNotes:w,totalVClicks:$,totalShikiHighlights:I,totalSlots:x,discoveredAssets:Array.from(C),layoutDistribution:A},flattenedMarkdown:P,customCss:k}}function ev(t){const i=[],e=/!\[.*?\]\((.*?)\)/g;let s;for(;(s=e.exec(t))!==null;){const r=s[1].split(/\s+/)[0].trim();r&&i.push(r)}const n=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(s=n.exec(t))!==null;){const r=s[1].trim();r&&i.push(r)}return i}const iv={class:"spm-import-dialog"},nv={class:"spm-tabs-header"},sv={class:"spm-dialog-body"},ov={key:0,class:"spm-file-section"},rv={key:0,class:"spm-dropzone-prompt"},lv={key:1,class:"spm-dropzone-active"},av={class:"spm-file-badge"},cv={class:"spm-file-size"},dv={key:1,class:"spm-text-section"},uv={key:2,class:"spm-error-banner"},fv={key:3,class:"spm-preview-card"},hv={class:"spm-config-grid"},pv={class:"spm-form-item"},mv={class:"spm-form-item"},gv=["value"],vv={class:"spm-stats-grid"},bv={class:"spm-stat-box"},yv={class:"spm-stat-value"},kv={class:"spm-stat-box"},wv={class:"spm-stat-value"},xv={class:"spm-stat-box"},_v={class:"spm-stat-value"},Sv={class:"spm-stat-box"},Cv={class:"spm-stat-value"},$v={key:0,class:"spm-chips-row"},Iv={class:"spm-options-group"},Av={class:"spm-checkbox-label"},Tv={class:"spm-checkbox-label"},Ev={class:"spm-checkbox-label"},Mv={class:"spm-checkbox-label"},Bv={class:"spm-dialog-footer"},Dv=["disabled"],Ov=["disabled"],Pv={key:0},Lv={key:1},Rv=be({__name:"SlidevImportDialog",emits:["close","success"],setup(t,{emit:i}){const e=i,s=Qe("plugin"),n=pt("file"),r=pt(!1),l=pt(!1),o=pt(""),a=pt(null),c=pt(null),d=pt(""),p=pt(0),g=pt(""),u=pt([]),k=pt(null),h=pt(""),b=pt([]),v=pt(""),w=pt(!0),$=pt(!0),I=pt(!0),x=pt(!0);async function C(){c.value?await R(c.value):g.value&&Q()}const A=$t(()=>{const V=p.value;if(V===0)return"0 B";const Y=1024,W=["B","KB","MB","GB"],z=Math.floor(Math.log(V)/Math.log(Y));return`${(V/Y**z).toFixed(1)} ${W[z]}`}),M=$t(()=>{var V;return((V=k.value)==null?void 0:V.docRootAttrs["custom-slidev-theme"])||"default"}),P=$t(()=>{var V;return u.value.length>0?u.value.length:((V=k.value)==null?void 0:V.stats.discoveredAssets.length)||0}),N=$t(()=>{var Y;const V=((Y=k.value)==null?void 0:Y.stats.layoutDistribution)||{};return Object.entries(V).map(([W,z])=>({name:W,count:z}))});$n(async()=>{try{const V=await ma();V!=null&&V.notebooks&&Array.isArray(V.notebooks)&&(b.value=V.notebooks.filter(Y=>!Y.closed),b.value.length>0&&(v.value=b.value[0].id))}catch(V){console.warn("获取笔记本列表失败:",V)}});function X(){var V;(V=a.value)==null||V.click()}function T(){c.value=null,d.value="",p.value=0,k.value=null,u.value=[],o.value=""}async function D(V){const Y=V.target;Y.files&&Y.files[0]&&await R(Y.files[0])}async function y(V){var Y;r.value=!1,(Y=V.dataTransfer)!=null&&Y.files&&V.dataTransfer.files[0]&&await R(V.dataTransfer.files[0])}async function R(V){o.value="",c.value=V,d.value=V.name,p.value=V.size;try{if(V.name.toLowerCase().endsWith(".zip")){const W=await V.arrayBuffer(),z=await Zg(W);if(!z.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=z.assets;const ct=Vn(z.entryMarkdown,{stripNotesFromMarkdown:$.value,cleanHtmlToMarkdown:w.value,cleanSlots:!1,virtualFiles:z.virtualFiles});k.value=ct,h.value=ct.docTitle||V.name.replace(/\.zip$/i,"")}else{const W=await V.text();u.value=[];const z=V.path||"",ct=z?z.replace(/[\\/][^\\/]+$/,""):"",rt=Vn(W,{stripNotesFromMarkdown:$.value,cleanHtmlToMarkdown:w.value,cleanSlots:!1,baseDir:ct||void 0});k.value=rt,h.value=rt.docTitle||V.name.replace(/\.md$/i,"")}}catch(Y){console.error("解析文件失败:",Y),o.value=`解析文件失败: ${Y.message||String(Y)}`}}function Q(){if(o.value="",!g.value.trim()){k.value=null;return}try{const V=Vn(g.value,{stripNotesFromMarkdown:$.value,cleanHtmlToMarkdown:w.value,cleanSlots:!1});k.value=V,h.value=V.docTitle||"Slidev 演示文稿"}catch(V){o.value=`解析 Markdown 源码失败: ${V.message||String(V)}`}}async function U(){var V;if(k.value){if(!v.value&&b.value.length>0&&(v.value=b.value[0].id),!v.value){o.value="请先选择目标笔记本";return}l.value=!0,o.value="";try{const Y=k.value,W={};if(I.value&&u.value.length>0){const ot=[];for(const dt of u.value){const E=new File([dt.data],dt.fileName,{type:"application/octet-stream"});ot.push(E)}try{const dt=await va("/data/assets",ot);if(dt!=null&&dt.succMap)for(const[E,L]of Object.entries(dt.succMap))W[E]=String(L)}catch(dt){console.warn("上传本地静态资产失败，保留原路径:",dt)}}Object.keys(W).length>0&&Yg(Y,W);const z=(h.value.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_"),ct=`/${z}`,rt=await ga(v.value,ct,Y.flattenedMarkdown);if(!rt)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const st=((V=Y.slides[0])==null?void 0:V.pageAttrs)||{};await zt(rt,{...st,...Y.docRootAttrs});const J=await Kn(rt).catch(()=>[]),gt=ot=>{if(!ot)return!1;const dt=String(ot.type||"").toLowerCase(),E=String(ot.markdown||"").trim(),L=String(ot.content||"").trim();return dt==="tb"||dt==="thematic-break"||dt==="nodethematicbreak"||E==="---"||E==="***"||L==="---"||L==="***"},mt=J.filter(gt);if(mt.length>=Y.slides.length)for(let ot=0;ot<Y.slides.length;ot++){const dt=Y.slides[ot],E=mt[ot];E&&E.id&&Object.keys(dt.pageAttrs).length>0&&await zt(E.id,dt.pageAttrs)}else for(let ot=1;ot<Y.slides.length;ot++){const dt=Y.slides[ot],E=mt[ot-1];E&&E.id&&Object.keys(dt.pageAttrs).length>0&&await zt(E.id,dt.pageAttrs)}let Z=!1;for(const ot of J){if(gt(ot)){Z=!1;continue}const dt=(ot.markdown||ot.content||"").trim();if(dt==="::right::"||dt.startsWith("::right::")){Z=!0;continue}Z&&ot.id&&await zt(ot.id,{[Tt]:"right"}).catch(()=>{})}vt.showMessage(`🎉 成功导入 Slidev 演示文档《${z}》！`),e("success",{docId:rt}),e("close"),x.value&&s&&(s.currentDocId=rt,await vt.openTab({app:s.app,doc:{id:rt}}),s.openBottomPreviewTab&&s.openBottomPreviewTab())}catch(Y){console.error("导入 Slidev 演示失败:",Y),o.value=`导入执行失败: ${Y.message||String(Y)}`}finally{l.value=!1}}}function at(){e("close")}return(V,Y)=>(et(),nt("div",{class:"spm-modal-overlay",onClick:Te(at,["self"])},[m("div",iv,[m("div",{class:"spm-dialog-header"},[Y[11]||(Y[11]=m("div",{class:"spm-dialog-title"},[m("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[m("use",{"xlink:href":"#iconSlidev"})]),m("span",null,"导入 Slidev 演示文档")],-1)),m("button",{class:"spm-close-btn",title:"关闭",onClick:at},"✕")]),m("div",nv,[m("button",{class:Et(["spm-tab-btn",{active:n.value==="file"}]),onClick:Y[0]||(Y[0]=W=>n.value="file")}," 📦 文件 / 压缩包导入 (.zip / .md) ",2),m("button",{class:Et(["spm-tab-btn",{active:n.value==="text"}]),onClick:Y[1]||(Y[1]=W=>n.value="text")}," 📝 粘贴 Markdown 源码 ",2)]),m("div",sv,[n.value==="file"?(et(),nt("div",ov,[m("div",{class:Et(["spm-dropzone",{dragover:r.value,"has-file":!!d.value}]),onDragover:Y[2]||(Y[2]=Te(W=>r.value=!0,["prevent"])),onDragleave:Y[3]||(Y[3]=Te(W=>r.value=!1,["prevent"])),onDrop:Te(y,["prevent"]),onClick:X},[m("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:D},null,544),d.value?(et(),nt("div",lv,[m("span",av,"📄 "+St(d.value),1),m("span",cv,"("+St(A.value)+")",1),m("button",{class:"spm-btn-text",onClick:Te(T,["stop"])},"更换文件")])):(et(),nt("div",rv,[...Y[12]||(Y[12]=[m("span",{class:"spm-dropzone-icon"},"📁",-1),m("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1),m("p",{class:"spm-dropzone-hint"},[Ys(" 支持 Slidev 完整工程 "),m("strong",null,".zip"),Ys("（自动解包 public/ 静态素材）或单文件 "),m("strong",null,".md")],-1)])]))],34)])):(et(),nt("div",dv,[Ie(m("textarea",{"onUpdate:modelValue":Y[4]||(Y[4]=W=>g.value=W),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:Q},null,544),[[is,g.value]])])),o.value?(et(),nt("div",uv," ⚠️ "+St(o.value),1)):Ft("",!0),k.value?(et(),nt("div",fv,[Y[24]||(Y[24]=m("div",{class:"spm-preview-card__header"},[m("span",null,"✨ 演示解析摘要"),m("span",{class:"spm-badge-success"},"预检就绪")],-1)),m("div",hv,[m("div",pv,[Y[13]||(Y[13]=m("label",{class:"spm-form-label"},"笔记文档标题",-1)),Ie(m("input",{"onUpdate:modelValue":Y[5]||(Y[5]=W=>h.value=W),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[is,h.value]])]),m("div",mv,[Y[14]||(Y[14]=m("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Ie(m("select",{"onUpdate:modelValue":Y[6]||(Y[6]=W=>v.value=W),class:"spm-select"},[(et(!0),nt(Gt,null,ye(b.value,W=>(et(),nt("option",{key:W.id,value:W.id},St(W.name),9,gv))),128))],512),[[du,v.value]])])]),m("div",vv,[m("div",bv,[m("span",yv,St(k.value.totalSlides),1),Y[15]||(Y[15]=m("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),m("div",kv,[m("span",wv,St(M.value),1),Y[16]||(Y[16]=m("span",{class:"spm-stat-label"},"演示主题",-1))]),m("div",xv,[m("span",_v,St(k.value.stats.totalNotes),1),Y[17]||(Y[17]=m("span",{class:"spm-stat-label"},"演讲者提词",-1))]),m("div",Sv,[m("span",Cv,St(P.value),1),Y[18]||(Y[18]=m("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),N.value.length>0?(et(),nt("div",$v,[Y[19]||(Y[19]=m("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(et(!0),nt(Gt,null,ye(N.value,W=>(et(),nt("span",{key:W.name,class:"spm-chip-badge"},St(W.name)+": "+St(W.count),1))),128))])):Ft("",!0),m("div",Iv,[m("label",Av,[Ie(m("input",{"onUpdate:modelValue":Y[7]||(Y[7]=W=>w.value=W),type:"checkbox",onChange:C},null,544),[[Rn,w.value]]),Y[20]||(Y[20]=m("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),m("label",Tv,[Ie(m("input",{"onUpdate:modelValue":Y[8]||(Y[8]=W=>$.value=W),type:"checkbox",onChange:C},null,544),[[Rn,$.value]]),Y[21]||(Y[21]=m("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),m("label",Ev,[Ie(m("input",{"onUpdate:modelValue":Y[9]||(Y[9]=W=>I.value=W),type:"checkbox"},null,512),[[Rn,I.value]]),Y[22]||(Y[22]=m("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),m("label",Mv,[Ie(m("input",{"onUpdate:modelValue":Y[10]||(Y[10]=W=>x.value=W),type:"checkbox"},null,512),[[Rn,x.value]]),Y[23]||(Y[23]=m("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Ft("",!0)]),m("div",Bv,[m("button",{class:"spm-btn-secondary",disabled:l.value,onClick:at}," 取消 ",8,Dv),m("button",{class:"spm-btn-primary",disabled:!k.value||l.value,onClick:U},[l.value?(et(),nt("span",Pv,"⏳ 正在导入生成中...")):(et(),nt("span",Lv,"🚀 确认导入思源笔记"))],8,Ov)])])]))}}),zv=Le(Rv,[["__scopeId","data-v-8771dc8a"]]),Nv={class:"spm-slidev-inspector"},Fv={class:"spm-inspector-topbar"},jv={class:"spm-inspector-title"},Hv={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},Uv={class:"spm-inspector-topbar-actions"},Wv={class:"spm-target-banner"},Vv={class:"spm-target-info"},Kv=["aria-label"],qv={key:0,class:"spm-save-status"},Gv=["title"],Zv={class:"spm-inspector-body"},Yv=be({__name:"SlidevInspectorDockView",setup(t,{expose:i}){const e=Qe("plugin"),s=pt(!1);function n(q){s.value=!1,c.value=q.docId,e!=null&&e.compileCurrentDocument&&e.compileCurrentDocument(q.docId)}const r=pt(""),l=pt(""),o=pt({}),a=pt(""),c=pt(""),d=pt(""),p=pt(""),g=pt(""),u=pt(null),k=pt(""),h=pt("");let b=null;function v(q="已同步"){k.value=q,b&&window.clearTimeout(b),b=window.setTimeout(()=>{k.value=""},1200)}function w(){var lt;const q=r.value||c.value;q&&(lt=navigator==null?void 0:navigator.clipboard)!=null&&lt.writeText&&navigator.clipboard.writeText(q).then(()=>{h.value="已复制！",setTimeout(()=>{h.value=""},1500)}).catch(()=>{})}const $=$t(()=>l.value==="NodeThematicBreak"),I=$t(()=>l.value==="NodeCodeBlock"),x=pt(!1),C=$t(()=>{if(x.value||B.value)return!0;const q=a.value||"";return!!fi(q)}),A=$t(()=>{const q=l.value||"";if(q==="NodeVideo"||q==="video")return!0;const lt=a.value||"";return!!(/<video\b/i.test(lt)||/\.mp4\b/i.test(lt))}),M=$t(()=>!r.value||r.value===c.value||l.value==="doc"||l.value==="NodeDocument"),P=$t(()=>{const q=r.value||c.value||"";return q.length>8?q.slice(-8):q||"无"}),N=$t(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),X=$t(()=>{if($.value)return"分页符 (---)";if(M.value)return"全局文档";if(A.value)return"视频块";switch(l.value){case"NodeHeading":return"标题块";case"NodeParagraph":return"段落块";case"NodeCodeBlock":return"代码块";case"NodeVideo":return"视频块";case"NodeList":case"NodeListItem":return"列表项";case"NodeBlockquote":return"引述块";case"NodeTable":return"表格块";case"NodeSuperBlock":case"s":case"sb":return"超级块";default:return"内容块"}}),T=$t(()=>$.value?"tag-divider":M.value?"tag-doc":"tag-block"),D=$t(()=>o.value[ft]||"default"),y=$t(()=>o.value[Xt]||"slide-left"),R=pt(""),Q=pt(""),U=$t(()=>{var At;if(!((At=u.value)!=null&&At.slides)||u.value.slides.length===0)return null;const q=r.value,lt=d.value,yt=p.value;if(yt){let _t=u.value.slides.find(Dt=>Dt.startBlockId===yt);if(_t||(_t=u.value.slides.find(Dt=>{var Ot,Pt;return((Pt=(Ot=Dt.blocks)==null?void 0:Ot[0])==null?void 0:Pt.id)===yt}),_t))return _t}if(q){let _t=u.value.slides.find(Ot=>Ot.startBlockId===q);if(_t||(_t=u.value.slides.find(Ot=>{var Pt,Zt;return((Pt=Ot.blocks)==null?void 0:Pt.some(Bt=>Bt.id===q))||((Zt=Ot.allBlockIds)==null?void 0:Zt.includes(q))}),_t)||lt&&lt!==q&&(_t=u.value.slides.find(Ot=>{var Pt,Zt;return((Pt=Ot.blocks)==null?void 0:Pt.some(Bt=>Bt.id===lt))||((Zt=Ot.allBlockIds)==null?void 0:Zt.includes(lt))}),_t)||(_t=u.value.slides.find(Ot=>{var Pt;return(Pt=Ot.noteBlocks)==null?void 0:Pt.some(Zt=>Zt.id===q||Zt.id===lt)}),_t))return _t;const Dt=o.value[Tt];if(Dt&&["col-1","col-2","col-3"].includes(Dt)&&(_t=u.value.slides.find(Ot=>{var Pt,Zt;return((Pt=Ot.frontmatter)==null?void 0:Pt.layout)==="three-cols-header"||((Zt=Ot.blocks)==null?void 0:Zt.some(Bt=>Bt.slot==="col-1"||Bt.slot==="col-2"||Bt.slot==="col-3"))}),_t))return _t}return u.value.slides[0]||null}),at=$t(()=>{var q;return((q=U.value)==null?void 0:q.notes)||""}),V=$t(()=>{var q,lt,yt;return((yt=(lt=(q=U.value)==null?void 0:q.noteBlocks)==null?void 0:lt[0])==null?void 0:yt.id)||""}),Y=$t(()=>{var At,_t,Dt,Ot,Pt,Zt;if($.value){const Bt=o.value[ft]||o.value["custom-slidev-layout"];if(Bt)return Bt}const q=o.value[Tt]||o.value["custom-slidev-slot"];if(q&&["col-1","col-2","col-3"].includes(q))return"three-cols-header";if(g.value)return g.value;const lt=p.value||($.value?r.value:"");if(lt){const Bt=Ht.getBlockAttrOverride(lt);if(Bt!=null&&Bt[ft])return Bt[ft]}if(lt&&((At=u.value)!=null&&At.slides)){const Bt=u.value.slides.find(li=>li.startBlockId===lt);if((_t=Bt==null?void 0:Bt.frontmatter)!=null&&_t.layout)return Bt.frontmatter.layout}if((Ot=(Dt=U.value)==null?void 0:Dt.frontmatter)!=null&&Ot.layout)return U.value.frontmatter.layout;if((Zt=(Pt=U.value)==null?void 0:Pt.blocks)!=null&&Zt.some(Bt=>Bt.slot==="col-1"||Bt.slot==="col-2"||Bt.slot==="col-3"))return"three-cols-header";const yt=Ht.getBlockAttrOverride(c.value);return yt!=null&&yt[ft]?yt[ft]:"default"}),W=$t(()=>{var q;return((q=U.value)==null?void 0:q.pageIndex)||1}),z=$t(()=>!!(o.value[ie]||o.value["slidev-note"])),ct=$t(()=>{var lt;if(o.value[Se])return o.value[Se];const q=r.value;if(q&&((lt=U.value)!=null&&lt.blocks)){const yt=U.value.blocks.find(At=>At.id===q);if(yt!=null&&yt.clicks)return yt.clicks}return""}),rt=$t(()=>{var lt;if(o.value[He])return o.value[He];const q=r.value;if(q&&((lt=U.value)!=null&&lt.blocks)){const yt=U.value.blocks.find(At=>At.id===q);if(yt!=null&&yt.motion)return typeof yt.motion=="string"?yt.motion:JSON.stringify(yt.motion)}return""}),st=$t(()=>{var lt;if(o.value[Tt])return o.value[Tt];const q=r.value;if(q&&((lt=U.value)!=null&&lt.blocks)){const yt=U.value.blocks.find(At=>At.id===q);if(yt!=null&&yt.slot)return yt.slot}return""}),J=pt(""),gt=pt(""),mt=$t(()=>o.value[vi]==="true"),Z=$t(()=>o.value[Mn]==="true"),ot=$t(()=>o.value[Oi]==="true"),dt=$t(()=>o.value[Bn]!=="false");async function E(){(mt.value?"false":"true")==="true"?(await j({[vi]:"true",[Oi]:"true"}),o.value[vi]="true",o.value[Oi]="true"):(await G(vi,"false"),o.value[vi]="false")}async function L(){const q=Z.value?"false":"true";await G(Mn,q)}async function f(){const q=ot.value?"false":"true";await G(Oi,q)}async function F(){const q=dt.value?"false":"true";await G(Bn,q)}const O=$t(()=>{var q,lt;return((lt=(q=u.value)==null?void 0:q.config)==null?void 0:lt.theme)||o.value[rn]||"default"}),_=$t(()=>{var q,lt;return((lt=(q=u.value)==null?void 0:q.config)==null?void 0:lt.aspectRatio)||o.value[ln]||"16/9"}),S=$t(()=>{var q,lt;return((lt=(q=u.value)==null?void 0:q.config)==null?void 0:lt.defaultTransition)||o.value[an]||"slide-left"}),B=$t(()=>{var _t,Dt;if((o.value[qt]||o.value["slidev-role"])===Ir||o.value[Ut]==="true")return"background";const lt=o.value[ft]||o.value["slidev-layout"];if(lt==="image-left"||lt==="image-right")return lt;const yt=a.value||"",At=fi(yt);if(At&&((Dt=(_t=U.value)==null?void 0:_t.frontmatter)!=null&&Dt.background)){const Ot=U.value.frontmatter.background;if(Ot===At||Ot.endsWith(At)||At.endsWith(Ot))return"background"}return""});async function K(q){var Dt;const lt=r.value;if(!lt)return;const yt=a.value||"",At=fi(yt)||"",_t=p.value||c.value;if(q)if(q==="background"){const Ot={[qt]:"background",[ft]:""};_t&&At&&(R.value=At,await zt(_t,{[Ut]:At}).catch(()=>{}),Ht.setBlockAttrOverride(_t,{[Ut]:At}),se(_t,{[Ut]:At}),U.value&&(U.value.frontmatter||(U.value.frontmatter={}),U.value.frontmatter.background=At)),await j(Ot)}else(q==="image-left"||q==="image-right")&&await j({[ft]:q,[qt]:""});else{const Ot={[qt]:"",[ft]:""};if(o.value[Ut]==="true"&&(Ot[Ut]=""),_t&&At&&R.value===At&&(R.value="",await zt(_t,{[Ut]:""}).catch(()=>{}),Ht.setBlockAttrOverride(_t,{[Ut]:""}),se(_t,{[Ut]:""}),(Dt=U.value)!=null&&Dt.frontmatter&&delete U.value.frontmatter.background),await j(Ot),typeof document<"u"){const Pt=document.querySelector(`.protyle-wysiwyg [data-node-id="${lt}"]`),Zt=Pt==null?void 0:Pt.closest('[data-type="NodeListItem"]'),Bt=Zt==null?void 0:Zt.getAttribute("data-node-id");if(Bt&&Bt!==lt){const li={[ft]:"",[qt]:""};se(Bt,li),Ht.setBlockAttrOverride(Bt,li),await zt(Bt,li).catch(()=>{})}}}}async function j(q){const lt=r.value||c.value;if(lt){for(const[yt,At]of Object.entries(q))o.value[yt]=At;if(Ht.setBlockAttrOverride(lt,q),se(lt,q),ft in q){const yt=q[ft];g.value=yt,U.value&&(U.value.frontmatter||(U.value.frontmatter={}),U.value.frontmatter.layout=yt)}v("保存中...");try{await zt(lt,q),v("已同步"),e&&await e.compileCurrentDocument()}catch{v("同步失败")}}}const H=$t(()=>!!(o.value[Se]||o.value[He]||o.value[Tt]||o.value[Si]||o.value[ie]||o.value["slidev-note"]||o.value[qt]||o.value[ft]||o.value[vi]||o.value[Mn]||o.value[Oi]||o.value[Bn]));async function G(q,lt){const yt=r.value||c.value;if(yt){o.value[q]=lt,Ht.setBlockAttrOverride(yt,{[q]:lt}),se(yt,{[q]:lt}),q===ft&&(g.value=lt,U.value&&(U.value.frontmatter||(U.value.frontmatter={}),U.value.frontmatter.layout=lt)),v("保存中...");try{await zt(yt,{[q]:lt}),v("已同步"),e&&await e.compileCurrentDocument()}catch{v("同步失败")}}}async function it(q,lt){var At;const yt=c.value||r.value;if(yt){o.value[q]=lt,Ht.setBlockAttrOverride(yt,{[q]:lt}),se(yt,{[q]:lt}),(At=u.value)!=null&&At.config&&(q===rn&&(u.value.config.theme=lt),q===ln&&(u.value.config.aspectRatio=lt),q===an&&(u.value.config.defaultTransition=lt)),v("更新中...");try{await zt(yt,{[q]:lt}),v("已更新"),e&&await e.compileCurrentDocument(yt)}catch{v("更新失败")}}}function tt(q){G(ft,q)}function ut(q){G(Xt,q)}function xt(q){R.value=q,G(Ut,q)}function bt(q){Q.value=q,G(Ae,q)}async function Mt(){const q=r.value;if(q)if(z.value){v("取消中...");try{await zt(q,{[ie]:"","slidev-note":""}),Ht.setBlockAttrOverride(q,{[ie]:"","slidev-note":""}),se(q,{[ie]:"","slidev-note":""}),delete o.value[ie],delete o.value["slidev-note"],v("已取消备注"),vt.showMessage("已取消讲稿备注"),e&&await e.compileCurrentDocument()}catch(lt){console.error("[SiYuanSlidev] 取消讲稿备注失败:",lt),v("取消失败"),vt.showMessage("取消讲稿备注失败")}}else{v("转换中...");try{let lt=a.value;try{const Dt=await ya(q);Dt!=null&&Dt.kramdown&&(lt=Dt.kramdown)}catch{}const _t=`> [!NOTE] 💡 演讲备注
${(Br(lt)||lt.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(Dt=>`> ${Dt}`).join(`
`)}
{: custom-slidev-note="true"}`;await Po("markdown",_t,q),await zt(q,{[ie]:"true"}),Ht.setBlockAttrOverride(q,{[ie]:"true"}),se(q,{[ie]:"true"}),o.value[ie]="true",l.value="NodeCallout",v("已设为讲稿备注"),vt.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e&&await e.compileCurrentDocument()}catch(lt){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",lt),v("设置失败"),vt.showMessage("转为讲稿备注提示块失败")}}}async function Vt(q){var Bt,li,Eo,Mo,Bo,Do,Oo;const At=`> [!NOTE] 💡 演讲备注
${(q||"在此输入本页讲稿提词...").split(/\r?\n/).map(Re=>`> ${Re}`).join(`
`)}
{: custom-slidev-note="true"}`,_t=((Bt=u.value)==null?void 0:Bt.slides)||[],Dt=U.value,Ot=Dt?_t.findIndex(Re=>Re===Dt):-1;let Pt=null;if(Ot!==-1&&Ot<_t.length-1){const Re=_t[Ot+1];Pt=await nn("markdown",At,Re.startBlockId)}else{const Re=((li=Dt==null?void 0:Dt.noteBlocks)==null?void 0:li.slice(-1)[0])||((Eo=Dt==null?void 0:Dt.blocks)==null?void 0:Eo.slice(-1)[0]);Re!=null&&Re.id?Pt=await nn("markdown",At,void 0,Re.id):Pt=await _r("markdown",At,c.value)}const Zt=((Do=(Bo=(Mo=Pt==null?void 0:Pt[0])==null?void 0:Mo.doOperations)==null?void 0:Bo[0])==null?void 0:Do.id)||((Oo=Pt==null?void 0:Pt[0])==null?void 0:Oo.id);return Zt&&(await zt(Zt,{[ie]:"true"}),Ht.setBlockAttrOverride(Zt,{[ie]:"true"}),Ei(Zt,e==null?void 0:e.app)),e&&await e.compileCurrentDocument(),Zt}async function Yt(){try{await Vt(),vt.showMessage("已在正文末尾插入讲稿备注提示块")}catch(q){vt.showMessage("插入讲稿备注块失败"),console.error(q)}}function ee(){const q=V.value;if(!q){vt.showMessage("未找到本页关联的讲稿备注块");return}Ei(q,e==null?void 0:e.app)?vt.showMessage("已在编辑区定位讲稿备注块"):vt.showMessage("定位讲稿备注块失败")}async function Nt(){if(!c.value)return;const q=U.value||{startBlockId:r.value||c.value,blocks:a.value&&a.value!=="---"?[{id:r.value,type:l.value,content:a.value,rawMarkdown:""}]:[],rawMarkdown:a.value&&a.value!=="---"?a.value:""};vt.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const lt=await Ar(q,Sr);if(lt.notes){const yt=V.value;if(yt){const At=`> [!NOTE] 💡 演讲备注
${lt.notes.split(/\r?\n/).map(_t=>`> ${_t}`).join(`
`)}
{: custom-slidev-note="true"}`;await Po("markdown",At,yt),await zt(yt,{[ie]:"true"}),Ht.setBlockAttrOverride(yt,{[ie]:"true"}),Ei(yt,e==null?void 0:e.app)}else await Vt(lt.notes);lt.isAiGenerated?vt.showMessage("思源 AI 演讲提词卡生成成功！"):vt.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e&&await e.compileCurrentDocument()}}function Ke(){ct.value?G(Se,""):G(Se,"+1")}function te(q){G(Se,q)}function Jt(q){G(He,q)}function mi(q){(o.value[Tt]||"")===q?G(Tt,""):G(Tt,q)}function Bi(q){J.value=q,G(Si,q)}function gs(q){gt.value=q,G(cn,q)}async function vs(){const q=Y.value==="three-cols-header";await G(Tt,q?"col-1":"left"),vt.showMessage(q?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function Tn(){const q=r.value;if(!q)return;const lt={[Se]:"",[He]:"",[Tt]:"",[Si]:"",[cn]:"",[ie]:"","slidev-note":"",[ft]:"",[qt]:"",[Xt]:"",[Ut]:"",[Ae]:"",[vi]:"",[Mn]:"",[Oi]:"",[Bn]:""};if(se(q,lt),await zt(q,lt),Ht.clearBlockAttrOverride(q),typeof document<"u"){const yt=document.querySelector(`.protyle-wysiwyg [data-node-id="${q}"]`),At=yt==null?void 0:yt.closest('[data-type="NodeListItem"]'),_t=At==null?void 0:At.getAttribute("data-node-id");_t&&_t!==q&&(se(_t,lt),await zt(_t,lt).catch(()=>{}),Ht.clearBlockAttrOverride(_t))}o.value={},J.value="",gt.value="",R.value="",Q.value="",vt.showMessage("已清除本块演示属性"),e&&await e.compileCurrentDocument()}function gi(q){it(rn,q)}function Di(q){it(ln,q)}function ea(q){it(an,q)}async function ia(){if(r.value)try{await nn("markdown","---",r.value,void 0),vt.showMessage("已在上方插入分页符 (---)"),e&&e.compileCurrentDocument()}catch{vt.showMessage("插入分页符失败")}}async function Ao(){const q=r.value||c.value;if(q)try{await nn("markdown","---",void 0,q),vt.showMessage("已在下方插入分页符 (---)"),e&&e.compileCurrentDocument()}catch{vt.showMessage("插入分页符失败")}}async function na(){if(r.value)try{await ba(r.value),vt.showMessage("已删除该分页符"),r.value="",l.value="",e&&e.compileCurrentDocument()}catch{vt.showMessage("删除失败")}}function To(){e!=null&&e.openBottomPreviewTab&&e.openBottomPreviewTab()}function sa(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function oa(){e!=null&&e.executeCommand&&e.executeCommand("slidevAiSplit")}function ra(){if(!u.value){vt.showMessage("请先在主编辑区打开幻灯片文档");return}const q=Zl(u.value);Yl("presentation.html",q)&&vt.showMessage("已开始下载单文件离线 HTML 演示包")}function la(){if(!u.value){vt.showMessage("请先在主编辑区打开幻灯片文档");return}Jl(u.value)&&vt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({setActiveBlock(q){r.value=q.id,l.value=q.type,o.value={...q.attrs},a.value=q.content||q.markdown||"",d.value=q.topBlockId||q.id,p.value=q.pageDividerId||"",g.value=q.pageDividerLayout||"",q.rootId?c.value=q.rootId:(q.type==="doc"||q.type==="NodeDocument")&&q.id&&(c.value=q.id),R.value=q.attrs[Ut]||"",Q.value=q.attrs[Ae]||"",J.value=q.attrs[Si]||"",gt.value=q.attrs[cn]||"",x.value=!!q.isImage},updateDocument(q){u.value=q,c.value=q.docId},openImportDialog(){s.value=!0},setCurrentDocId(q){c.value=q}}),(q,lt)=>(et(),nt("div",Nv,[m("div",Fv,[m("div",jv,[(et(),nt("svg",Hv,[...lt[2]||(lt[2]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),lt[3]||(lt[3]=m("span",null,"演示配置",-1))]),m("div",Uv,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:lt[0]||(lt[0]=yt=>s.value=!0)},[ht(kt,{name:"import"}),lt[4]||(lt[4]=m("span",null,"导入",-1))]),m("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:To},[ht(kt,{name:"split-preview"}),lt[5]||(lt[5]=m("span",null,"分屏预览",-1))])])]),m("div",Wv,[m("div",Vv,[m("span",{class:Et(["spm-target-tag",T.value])},St(X.value),3),m("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":h.value||"点击复制 ID: "+(r.value||c.value),onClick:w},[ht(kt,{name:"copy"}),m("span",null,"#"+St(P.value),1)],8,Kv)]),k.value?(et(),nt("span",qv,"● "+St(k.value),1)):Ft("",!0)]),N.value?(et(),nt("div",{key:0,class:"spm-context-quote",title:a.value},St(N.value),9,Gv)):Ft("",!0),m("div",Zv,[$.value?(et(),Ee(Gp,{key:0,"page-layout":D.value,"page-transition":y.value,"page-background":R.value,"page-image":Q.value,"page-notes":at.value,"page-index":W.value,"onUpdate:pageLayout":tt,"onUpdate:pageTransition":ut,"onUpdate:pageBackground":xt,"onUpdate:pageImage":bt,onAddNoteBlock:Yt,onLocateNoteBlock:ee,onGenerateNotes:Nt,onInsertDividerAfter:Ao,onDeleteDivider:na},null,8,["page-layout","page-transition","page-background","page-image","page-notes","page-index"])):r.value&&!M.value?(et(),Ee(mg,{key:1,"elem-click":ct.value,"elem-motion":rt.value,"elem-slot":st.value,"elem-shiki-lines":J.value,"elem-max-height":gt.value,"is-code-block":I.value,"is-image":C.value,"is-video":A.value,"video-autoplay":mt.value,"video-loop":Z.value,"video-muted":ot.value,"video-controls":dt.value,"has-block-attrs":H.value,"is-note":z.value,"image-role":B.value,"current-slide-layout":Y.value,onToggleNote:Mt,onToggleElemClick:Ke,onToggleVideoAutoplay:E,onToggleVideoLoop:L,onToggleVideoMuted:f,onToggleVideoControls:F,"onUpdate:imageRole":K,"onUpdate:elemClick":te,"onUpdate:elemMotion":Jt,"onUpdate:elemSlot":mi,"onUpdate:elemShikiLines":Bi,"onUpdate:elemMaxHeight":gs,onInsertDividerBefore:ia,onInsertDividerAfter:Ao,onSetTwoColsContrast:vs,onClearBlockAttrs:Tn},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout"])):(et(),Ee(Hg,{key:2,"doc-theme":O.value,"doc-aspect-ratio":_.value,"doc-default-transition":S.value,"onUpdate:docTheme":gi,"onUpdate:docAspectRatio":Di,"onUpdate:docDefaultTransition":ea,onOpenBottomPreview:To,onOpenPresenter:sa,onAiAutoSplit:oa,onExportHtml:ra,onExportPdf:la},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition"]))]),s.value?(et(),Ee(zv,{key:1,onClose:lt[1]||(lt[1]=yt=>s.value=!1),onSuccess:n})):Ft("",!0)]))}}),An=new Co;let di=null,We=null;function Jv(t,i){di&&Ql(),di=jl(kp),di.provide("plugin",i),di.provide("sandboxBridge",An);const e=di.mount(t);return We=e,e}function Ql(t){di&&(di.unmount(),di=null,We=null)}let ui=null,ve=null;function Xv(t,i){ui&&ta(),ui=jl(Yv),ui.provide("plugin",i),ui.provide("sandboxBridge",An);const e=ui.mount(t);return ve=e,e}function ta(t){ui&&(ui.unmount(),ui=null,ve=null)}function Qv(t,i){ve!=null&&ve.updateDocument&&ve.updateDocument(t),We!=null&&We.updateDocument?We.updateDocument(t,i):An.updateSlides(t.slides,t.config,t.fullMarkdown)}function Ds(t){We!=null&&We.navigateToBlock?We.navigateToBlock(t):An.highlightElement(t)}function Fn(t){ve!=null&&ve.setActiveBlock&&ve.setActiveBlock(t)}function tb(){return ve!=null&&ve.openImportDialog?(ve.openImportDialog(),!0):!1}const eb=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:xi,value:"true"},{key:ft,value:"cover"},{key:Xt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:xi,value:"true"},{key:ft,value:"two-cols"},{key:Xt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:xi,value:"true"},{key:ft,value:"fact"},{key:Xt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:xi,value:"true"},{key:ft,value:"intro"},{key:Xt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:xi,value:"true"},{key:ft,value:"quote"},{key:Xt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Se,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Se,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Tt,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Si,value:"1-3"}]}];class Os{getPresetTemplates(){return eb}buildScanSlidevBlocksSql(i="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${i}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${Xt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(i,e,s,n){const r=`SELECT block_id FROM attributes WHERE name = '${Xt}' AND value = '${i}'`,l=await s(r);let o=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{[Xt]:e}),o++)}return{updatedCount:o}}async batchUpdateLayout(i,e,s,n){const r=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${i}'`,l=await s(r);let o=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{"custom-slidev-layout":e}),o++)}return{updatedCount:o}}exportTemplatesJson(){const i=this.getPresetTemplates();return JSON.stringify({templates:i,counter:i.length},null,2)}formatTransitionSummary(i){return!i||i.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${i.map(s=>`${s.value}: ${s.count} 个`).join("，")}`}}const ib=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,nb="slidev-dock",wr="slidev-preview-tab",xr=wh;class sb extends vt.Plugin{constructor(){super(...arguments);wt(this,"isMobile",!1);wt(this,"currentDocId","");wt(this,"latestCompiledDoc",null);wt(this,"cliBridge",new eo);wt(this,"debounceTimer",null);wt(this,"activeCursorBlockId","");wt(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));wt(this,"onWsMainBound",this.onWsMain.bind(this));wt(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));wt(this,"onClickEditorTitleIconBound",this.onClickEditorTitleIcon.bind(this));wt(this,"onEditorClickBound",this.onEditorClick.bind(this));wt(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));wt(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this))}async onload(){const e=vt.getFrontend();this.isMobile=e==="mobile"||e==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(ib),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"Slidev 演示 (下方分屏)",position:"right",callback:()=>{this.openBottomPreviewTab()}}),this.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{this.openBottomPreviewTab()}}),this.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{tb()||vt.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),this.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!this.currentDocId){const n=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(n==null?void 0:n.getAttribute("data-doc-id"))||""}this.currentDocId&&(await zt(this.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),vt.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(this.currentDocId))}}),this.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!this.currentDocId){const a=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(a==null?void 0:a.getAttribute("data-doc-id"))||""}if(!this.currentDocId){vt.showMessage("请先打开一篇思源笔记文档");return}const n=await Kn(this.currentDocId).catch(()=>[]);if(!n||n.length===0){vt.showMessage("当前文档无内容，无需断页");return}const r=n.map(a=>({id:a.id,type:a.type,subType:a.subType,content:a.content||"",markdown:a.markdown||""})),l=_a(r);if(l.length===0){vt.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}vt.showMessage(`AI 分析完毕：发现 ${l.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const a of l)try{await nn("markdown","---",void 0,a.blockId),await zt(a.blockId,{"custom-slidev-layout":a.recommendedLayout}),o++}catch(c){console.warn("Failed to insert divider:",c)}vt.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),this.compileCurrentDocument(this.currentDocId)}}),this.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var p,g,u,k;if(!this.currentDocId){const h=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(h==null?void 0:h.getAttribute("data-doc-id"))||""}if(!this.currentDocId){vt.showMessage("请先打开一篇思源笔记文档");return}vt.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const n=await Kn(this.currentDocId).catch(()=>[]),r={startBlockId:this.currentDocId,blocks:n.map(h=>({id:h.id,type:h.type,content:h.content||"",rawMarkdown:h.markdown||""})),rawMarkdown:""},a=`> [!NOTE] 💡 演讲备注
${(await Sa(r,Sr)).split(/\r?\n/).map(h=>`> ${h}`).join(`
`)}
{: custom-slidev-note="true"}`,c=await _r("markdown",a,this.currentDocId).catch(()=>null),d=((u=(g=(p=c==null?void 0:c[0])==null?void 0:p.doOperations)==null?void 0:g[0])==null?void 0:u.id)||((k=c==null?void 0:c[0])==null?void 0:k.id);d&&(await zt(d,{"custom-slidev-note":"true"}),Ht.setBlockAttrOverride(d,{"custom-slidev-note":"true"}),Ei(d,this.app)),vt.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),this.compileCurrentDocument(this.currentDocId)}}),this.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const n=new Os,r=n.buildTransitionStatsSql(),l=await gn(r).catch(()=>[]),o=n.formatTransitionSummary(l||[]);vt.showMessage(o)}}),this.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const r=new Os().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(r),vt.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):vt.showMessage(`已生成模板数据（请在控制台查看）：
`+r)}}),this.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const r=await new Os().batchUpdateTransitions("fade","slide-left",l=>gn(l).catch(()=>[]),(l,o)=>zt(l,o));vt.showMessage(`全库批量替换完成：已将 ${r.updatedCount} 处 fade 转场更新为 slide-left`),this.compileCurrentDocument()}}),this.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),this.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(this.latestCompiledDoc||await this.compileCurrentDocument(),!this.latestCompiledDoc){vt.showMessage("请先打开并放映一篇思源笔记文档");return}this.cliBridge.downloadSlidesMd(this.latestCompiledDoc,`slides-${this.currentDocId||"demo"}.md`)&&vt.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),this.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{vt.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await this.cliBridge.probeServer(1500)?vt.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):vt.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),this.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(this.latestCompiledDoc||await this.compileCurrentDocument(),!this.latestCompiledDoc){vt.showMessage("请先打开并放映一篇思源笔记文档");return}const n=await this.cliBridge.syncToWorkspaceFile(this.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",Ps);n.success?vt.showMessage(`已成功同步最新 slides.md 至工作空间：${n.path}`):vt.showMessage(`同步失败：${n.error}`)}});const s=this;if(this.addTab({type:wr,init(){Jv(this.element,s)},destroy(){Ql(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:nb,init(){Xv(this.element,s)},destroy(){ta(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(n,r)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${n}`,{detail:r}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound)),typeof document<"u"){const n=()=>{const r=this.getActiveDocumentId();r&&(r!==this.currentDocId&&(this.currentDocId=r),this.latestCompiledDoc||this.compileCurrentDocument(r))};setTimeout(n,300),setTimeout(n,1e3)}}async onDataChanged(e){await this.loadGlobalSettings(),this.currentDocId&&await this.compileCurrentDocument(this.currentDocId)}async loadGlobalSettings(){try{const e=await this.loadData(xr),s=xh(e);return Vi(s),s}catch{return Vi(Yi),Yi}}async saveGlobalSettings(e){const s=Io(),n=Vi({...s,...e||{}});try{await this.saveData(xr,n)}catch(r){console.error("保存 Slidev 全局配置失败",r)}return n}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound)),An.detach()}async openBottomPreviewTab(){if(!this.currentDocId){const e=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(e==null?void 0:e.getAttribute("data-doc-id"))||""}await vt.openTab({app:this.app,custom:{id:this.name+wr,title:"Slidev 演示预览",icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId)}onClickEditorTitleIcon(e){var l;const s=e.detail,n=s==null?void 0:s.menu,r=((l=s==null?void 0:s.data)==null?void 0:l.id)||this.currentDocId;!n||!r||n.addItem({icon:"iconSlidev",label:"Slidev 全局演示配置",submenu:[{label:"初始化演示属性 (custom-slidev-*)",click:async()=>{await zt(r,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),vt.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"主题: 默认 (default)",click:async()=>{await zt(r,{"custom-slidev-theme":"default"}),vt.showMessage("已切换为 default 主题"),this.compileCurrentDocument(r)}},{label:"主题: 优雅衬线 (seriph)",click:async()=>{await zt(r,{"custom-slidev-theme":"seriph"}),vt.showMessage("已切换为 seriph 主题"),this.compileCurrentDocument(r)}},{label:"主题: 苹果极简 (apple-basic)",click:async()=>{await zt(r,{"custom-slidev-theme":"apple-basic"}),vt.showMessage("已切换为 apple-basic 主题"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"画幅: 16 / 9 (宽屏)",click:async()=>{await zt(r,{"custom-slidev-aspect-ratio":"16/9"}),vt.showMessage("已切换画幅为 16/9"),this.compileCurrentDocument(r)}},{label:"画幅: 4 / 3 (标屏)",click:async()=>{await zt(r,{"custom-slidev-aspect-ratio":"4/3"}),vt.showMessage("已切换画幅为 4/3"),this.compileCurrentDocument(r)}}]})}async onSwitchProtyle(e){var r,l;const s=(r=e.detail)==null?void 0:r.protyle,n=(l=s==null?void 0:s.block)==null?void 0:l.rootID;if(n&&n!==this.currentDocId){this.currentDocId=n,this.activeCursorBlockId=n;const o=await Ge(n).catch(()=>({}));Fn({id:n,rootId:n,type:"doc",attrs:o}),this.compileCurrentDocument(n)}}onClickEditorContent(e){var r,l;const s=e==null?void 0:e.detail;if(!s)return;const n=(l=(r=s.protyle)==null?void 0:r.block)==null?void 0:l.rootID;n&&(!this.currentDocId||this.currentDocId!==n)&&(this.currentDocId=n),s.event&&this.onEditorClick(s.event)}getActiveDocumentId(){if(typeof document>"u")return"";const e=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),s=e==null?void 0:e.getAttribute("data-node-id");if(s)return s;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),r=n==null?void 0:n.getAttribute("data-node-id");if(r)return r;const l=document.querySelector("[data-doc-id]"),o=l==null?void 0:l.getAttribute("data-doc-id");return o||""}resolveDocIdFromElement(e){const s=e.closest(".protyle-title"),n=s==null?void 0:s.getAttribute("data-node-id");if(n)return n;const r=e.closest(".protyle"),l=r==null?void 0:r.querySelector(".protyle-title"),o=l==null?void 0:l.getAttribute("data-node-id");if(o)return o;const a=e.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||this.currentDocId}async switchToDocGlobalInspector(e,s){var l;if(!e)return;this.activeCursorBlockId=e,this.currentDocId=e;let n=s||"";if(!n&&typeof document<"u"){const o=document.querySelector(`.protyle-title[data-node-id="${e}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${e}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((l=o==null?void 0:o.innerText)==null?void 0:l.trim())||""}const r=await Ge(e).catch(()=>({}));Fn({id:e,rootId:e,type:"doc",content:n,attrs:r,isDivider:!1,isCode:!1}),Ds(e)}onWsMain(e){const s=e.detail;if(s){if(s.cmd==="transactions"&&Array.isArray(s.data)){for(const n of s.data)if(Array.isArray(n==null?void 0:n.doOperations)){for(const r of n.doOperations)if((r==null?void 0:r.action)==="updateAttrs"&&r.id&&r.data){const l=r.data.old||{},o=r.data.new||{},a={};for(const c of Object.keys(l))c in o||(a[c]="");for(const[c,d]of Object.entries(o))a[c]=String(d??"");se(r.id,a),Ht.setBlockAttrOverride(r.id,a)}}}this.debounceTimer&&window.clearTimeout(this.debounceTimer),this.debounceTimer=window.setTimeout(()=>{this.compileCurrentDocument()},150)}}handleBlockClickedFromSlide(e,s){var o,a;if(!e)return!1;this.activeCursorBlockId=e;const n=Ei(e,this.app),r=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`),l=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,e,l);else{let c="",d="";if((o=this.latestCompiledDoc)!=null&&o.slides){const p=this.latestCompiledDoc.slides.find(g=>{var u,k,h;return g.startBlockId===e||((u=g.blocks)==null?void 0:u.some(b=>b.id===e))||((k=g.allBlockIds)==null?void 0:k.includes(e))||((h=g.noteBlocks)==null?void 0:h.some(b=>b.id===e))});p!=null&&p.startBlockId&&(c=p.startBlockId),(a=p==null?void 0:p.frontmatter)!=null&&a.layout&&(d=p.frontmatter.layout)}Ge(e).then(async p=>{if(c&&!d){const g=Ht.getBlockAttrOverride(c);if(g!=null&&g[ft]||g!=null&&g["custom-slidev-layout"])d=g[ft]||g["custom-slidev-layout"]||"";else{const u=await Ge(c).catch(()=>({}))||{};d=u[ft]||u["custom-slidev-layout"]||"",u&&Object.keys(u).length>0&&Ht.setBlockAttrOverride(c,u)}}Fn({id:e,rootId:this.currentDocId,type:l||"NodeParagraph",attrs:p||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return n}onBlockClickedFromSlide(e){const s=(e==null?void 0:e.detail)||e;s!=null&&s.blockId&&this.handleBlockClickedFromSlide(s.blockId,s.page)}onEditorClick(e){const s=e.target;if(!s)return;const n=s.closest(".protyle-title")||s.closest(".protyle-background");if(!!(n||s.closest(".protyle-content")&&!s.closest(".protyle-wysiwyg")&&!s.closest(".protyle-breadcrumb")&&!s.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(s);if(d&&this.activeCursorBlockId!==d){const p=n||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=p==null?void 0:p.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!s.closest(".protyle-wysiwyg"))return;const o=s.closest("[data-node-id]");if(!o)return;const a=o.getAttribute("data-node-id"),c=o.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(s)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Ds(a)),this.syncInspectorBlock(o,a,c))}onSelectionChange(){if(typeof window>"u")return;const e=window.getSelection();if(!e||e.rangeCount===0)return;const s=e.anchorNode;if(!s)return;const n=s.nodeType===Node.ELEMENT_NODE?s:s.parentElement;if(!n)return;const r=n.closest(".protyle-title");if(!!(r||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const p=r||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=p==null?void 0:p.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!n.closest(".protyle-wysiwyg"))return;const o=n.closest("[data-node-id]"),a=o==null?void 0:o.getAttribute("data-node-id"),c=(o==null?void 0:o.getAttribute("data-type"))||"";o&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Ds(a)),this.syncInspectorBlock(o,a,c))}async syncInspectorBlock(e,s,n){var T,D,y,R,Q,U,at,V,Y,W;let r=e,l=s,o=n;const a=e.closest('[data-type="NodeCallout"]');if(a&&a!==e){const z=a.getAttribute("data-node-id");if(z){const ct=await Ge(z).catch(()=>({}))||{},rt=Ht.getBlockAttrOverride(z)||{},st={...ct,...rt};(st[ie]||st["slidev-note"])&&(r=a,l=z,o="NodeCallout")}}const c=o==="NodeThematicBreak",d=o==="NodeCodeBlock",p=((T=r.innerText)==null?void 0:T.trim())||"",g=await Ge(l).catch(()=>({}))||{},u=Ht.getBlockAttrOverride(l)||{},k={...g,...u},h=r.closest(".protyle-wysiwyg > [data-node-id]")||r,b=(h==null?void 0:h.getAttribute("data-node-id"))||l;let v="",w="",$=h.previousElementSibling;for(;$;){const z=$.getAttribute("data-type");if(z==="NodeThematicBreak"||z==="tb"||(D=$.classList)!=null&&D.contains("hr")){v=$.getAttribute("data-node-id")||"";break}$=$.previousElementSibling}if((y=this.latestCompiledDoc)!=null&&y.slides){const z=[l,b];let ct=r.parentElement;for(;ct&&!ct.classList.contains("protyle-wysiwyg");){const st=ct.getAttribute("data-node-id");st&&!z.includes(st)&&z.push(st),ct=ct.parentElement}const rt=this.latestCompiledDoc.slides.find(st=>{var J,gt,mt;return z.includes(st.startBlockId)||((J=st.blocks)==null?void 0:J.some(Z=>z.includes(Z.id)))||((gt=st.allBlockIds)==null?void 0:gt.some(Z=>z.includes(Z)))||((mt=st.noteBlocks)==null?void 0:mt.some(Z=>z.includes(Z.id)))});rt&&(!v&&rt.startBlockId&&(v=rt.startBlockId),!w&&((R=rt.frontmatter)!=null&&R.layout)&&(w=rt.frontmatter.layout))}if(v){const z=Ht.getBlockAttrOverride(v);if(z&&(ft in z||"custom-slidev-layout"in z)&&(w=z[ft]||z["custom-slidev-layout"]||""),!w&&((Q=this.latestCompiledDoc)!=null&&Q.slides)){const ct=this.latestCompiledDoc.slides.find(rt=>rt.startBlockId===v);(U=ct==null?void 0:ct.frontmatter)!=null&&U.layout&&(w=ct.frontmatter.layout)}if(!w){const ct=await Ge(v).catch(()=>({}))||{};w=ct[ft]||ct["custom-slidev-layout"]||"",ct&&Object.keys(ct).length>0&&Ht.setBlockAttrOverride(v,ct)}se(v,{[ft]:w||""})}else if(this.currentDocId){const z=Ht.getBlockAttrOverride(this.currentDocId);z&&(ft in z||"custom-slidev-layout"in z)?w=z[ft]||z["custom-slidev-layout"]||"":!w&&((W=(Y=(V=(at=this.latestCompiledDoc)==null?void 0:at.slides)==null?void 0:V[0])==null?void 0:Y.frontmatter)!=null&&W.layout)&&(w=this.latestCompiledDoc.slides[0].frontmatter.layout)}const I=r.getAttribute(ft)||r.getAttribute("custom-slidev-layout"),x=k[ft]||k["custom-slidev-layout"]||"";I&&I!==x&&se(l,{[ft]:x});const C=r.getAttribute(qt)||r.getAttribute("custom-slidev-role"),A=k[qt]||k["custom-slidev-role"]||"";C&&C!==A&&se(l,{[qt]:A});const M=r.closest('[data-type="NodeListItem"]');if(M&&M!==r){const z=M.getAttribute("data-node-id");if(z){const ct=await Ge(z).catch(()=>({}))||{},rt=Ht.getBlockAttrOverride(z)||{},st={...ct,...rt},J=st[ft]||st["custom-slidev-layout"]||"",gt=M.getAttribute(ft)||M.getAttribute("custom-slidev-layout");gt&&gt!==J&&se(z,{[ft]:J});const mt=st[qt]||st["custom-slidev-role"]||"",Z=M.getAttribute(qt)||M.getAttribute("custom-slidev-role");Z&&Z!==mt&&se(z,{[qt]:mt})}}const P=!!r.querySelector("img, span[data-type='img']"),N=(r.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),X=P&&N.length<=50;Fn({id:l,rootId:this.currentDocId,type:o,content:p,attrs:k,isDivider:c,isCode:d,isImage:X,topBlockId:b,pageDividerId:v,pageDividerLayout:w})}async compileCurrentDocument(e){var n,r,l,o;let s=e||this.currentDocId;if(!s){const a=document.querySelector(".protyle.layout__wnd--active, .layout__wnd--active .protyle, .protyle"),c=(a==null?void 0:a.getAttribute("data-doc-id"))||((n=a==null?void 0:a.querySelector(".protyle-wysiwyg"))==null?void 0:n.getAttribute("data-doc-id"))||((r=a==null?void 0:a.querySelector(".protyle-title"))==null?void 0:r.getAttribute("data-node-id"))||((l=document.querySelector(".protyle-content[data-doc-id]"))==null?void 0:l.getAttribute("data-doc-id"))||((o=document.querySelector("[data-doc-id]"))==null?void 0:o.getAttribute("data-doc-id"));if(c)this.currentDocId=c,s=c;else return}try{const a=await Ht.compile(s);this.latestCompiledDoc=a,Qv(a,s),this.purgeStaleDomSlidevAttrs(a)}catch(a){console.error("[SiYuanSlidev] Failed to compile document:",a)}}purgeStaleDomSlidevAttrs(e){var r,l,o;if(typeof document>"u"||!e)return;const s=new Map;if(Array.isArray(e.slides))for(const a of e.slides){if(a.startBlockId){const c=s.get(a.startBlockId)||{};(r=a.frontmatter)!=null&&r.layout&&(c[ft]=a.frontmatter.layout),s.set(a.startBlockId,c)}if(Array.isArray(a.blocks)){for(const c of a.blocks)if(c.id){const d=s.get(c.id)||{};(l=c.ial)!=null&&l[ft]&&(d[ft]=c.ial[ft]),(o=c.ial)!=null&&o[qt]&&(d[qt]=c.ial[qt]),Object.keys(d).length>0&&s.set(c.id,d)}}}const n=Ht.getAllAttrOverrides();for(const[a,c]of n.entries()){const d=s.get(a)||{};c[ft]!==void 0&&(d[ft]=c[ft]),c[qt]!==void 0&&(d[qt]=c[qt]),s.set(a,d)}Mf(s)}}module.exports=sb;
