"use strict";Object.defineProperty(exports,Symbol.toStringTag,{value:"Module"});function n(t){return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>Slidev PDF 讲义导出</title>
  <style>
    @page {
      size: 16in 9in;
      margin: 0;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: system-ui, -apple-system, sans-serif; background: #fff; color: #111; }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: 40px 60px;
      display: flex;
      flex-direction: column;
      position: relative;
    }
    .pdf-slide-header { font-size: 14px; color: #888; margin-bottom: 20px; }
    .pdf-slide-body { flex: 1; display: flex; flex-direction: column; gap: 16px; font-size: 24px; line-height: 1.5; }
    .pdf-slide-notes { font-size: 14px; color: #059669; border-top: 1px dashed #ccc; padding-top: 8px; margin-top: auto; }
    .layout-cover { justify-content: center; align-items: center; text-align: center; }
  </style>
</head>
<body>
  ${t.slides.map((e,l)=>{const d=e.blocks.map(i=>`<div class="pdf-block">${i.rawMarkdown||i.content||""}</div>`).join(`
`);return`
      <section class="pdf-slide-page layout-${e.frontmatter.layout||"default"}">
        <header class="pdf-slide-header">Page ${l+1}</header>
        <div class="pdf-slide-body">${d}</div>
        ${e.notes?`<footer class="pdf-slide-notes">备注: ${e.notes}</footer>`:""}
      </section>
    `}).join(`
`)}
</body>
</html>`}function s(t){if(typeof window>"u")return!1;const o=n(t),e=window.open("","_blank");return e?(e.document.write(o),e.document.close(),e.focus(),setTimeout(()=>{e.print(),e.close()},300),!0):!1}exports.buildPrintableHtml=n;exports.triggerPdfExport=s;
